.class public final LCb/f;
.super Lxk/z;
.source "VarysHandshakeResponse$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LCb/g;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LCb/g;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 4

    invoke-direct {p0}, Lxk/z;-><init>()V

    new-instance p1, LJn/a$r;

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v1, LJn/a$k;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {p1, v0, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object p1, p0, LCb/f;->a:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LCb/g;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LCb/g;

    invoke-direct {v0}, LCb/g;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_d0

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_d4

    goto :goto_7f

    :sswitch_33
    const-string v2, "bodyWhitelist"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_7f

    :cond_3c
    const/4 v3, 0x6

    goto :goto_7f

    :sswitch_3e
    const-string v2, "senderBlacklist"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_7f

    :cond_47
    const/4 v3, 0x5

    goto :goto_7f

    :sswitch_49
    const-string v2, "bodyBlacklist"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_7f

    :cond_52
    const/4 v3, 0x4

    goto :goto_7f

    :sswitch_54
    const-string v2, "keyid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_7f

    :cond_5d
    const/4 v3, 0x3

    goto :goto_7f

    :sswitch_5f
    const-string v2, "key"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto :goto_7f

    :cond_68
    const/4 v3, 0x2

    goto :goto_7f

    :sswitch_6a
    const-string v2, "fromTime"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_73

    goto :goto_7f

    :cond_73
    const/4 v3, 0x1

    goto :goto_7f

    :sswitch_75
    const-string v2, "senderWhitelist"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7e

    goto :goto_7f

    :cond_7e
    const/4 v3, 0x0

    :goto_7f
    iget-object v1, p0, LCb/f;->a:LJn/a$r;

    packed-switch v3, :pswitch_data_f2

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_88
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    iput-object v1, v0, LCb/g;->a:Ljava/util/ArrayList;

    goto :goto_1d

    :pswitch_91
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    iput-object v1, v0, LCb/g;->c:Ljava/util/ArrayList;

    goto :goto_1d

    :pswitch_9a
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    iput-object v1, v0, LCb/g;->d:Ljava/util/ArrayList;

    goto/16 :goto_1d

    :pswitch_a4
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LCb/g;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_b0
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LCb/g;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_bc
    iget-wide v1, v0, LCb/g;->e:J

    invoke-static {p1, v1, v2}, LJn/a$B;->a(LBk/a;J)J

    move-result-wide v1

    iput-wide v1, v0, LCb/g;->e:J

    goto/16 :goto_1d

    :pswitch_c6
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    iput-object v1, v0, LCb/g;->b:Ljava/util/ArrayList;

    goto/16 :goto_1d

    :cond_d0
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    :sswitch_data_d4
    .sparse-switch
        -0x6c700e6e -> :sswitch_75
        -0x4a300669 -> :sswitch_6a
        0x19e5f -> :sswitch_5f
        0x6138fba -> :sswitch_54
        0xb21c59b -> :sswitch_49
        0x4597da68 -> :sswitch_3e
        0x5919dcc5 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_f2
    .packed-switch 0x0
        :pswitch_c6
        :pswitch_bc
        :pswitch_b0
        :pswitch_a4
        :pswitch_9a
        :pswitch_91
        :pswitch_88
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LCb/f;->read(LBk/a;)LCb/g;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LCb/g;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "bodyWhitelist"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCb/g;->a:Ljava/util/ArrayList;

    iget-object v1, p0, LCb/f;->a:LJn/a$r;

    if-eqz v0, :cond_1b

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_1e

    :cond_1b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1e
    const-string v0, "senderWhitelist"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCb/g;->b:Ljava/util/ArrayList;

    if-eqz v0, :cond_2e

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_31

    :cond_2e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_31
    const-string v0, "senderBlacklist"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCb/g;->c:Ljava/util/ArrayList;

    if-eqz v0, :cond_41

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_44

    :cond_41
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_44
    const-string v0, "bodyBlacklist"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCb/g;->d:Ljava/util/ArrayList;

    if-eqz v0, :cond_54

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_57

    :cond_54
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_57
    const-string v0, "fromTime"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, LCb/g;->e:J

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "key"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCb/g;->f:Ljava/lang/String;

    if-eqz v0, :cond_70

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_73

    :cond_70
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_73
    const-string v0, "keyid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LCb/g;->g:Ljava/lang/String;

    if-eqz p2, :cond_82

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_85

    :cond_82
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_85
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LCb/g;

    invoke-virtual {p0, p1, p2}, LCb/f;->write(LBk/c;LCb/g;)V

    return-void
.end method
