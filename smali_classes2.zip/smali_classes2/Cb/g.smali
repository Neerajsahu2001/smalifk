.class public final LCb/g;
.super Ljava/lang/Object;
.source "VarysHandshakeResponse.java"


# instance fields
.field public a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation runtime Lyk/b;
        value = "bodyWhitelist"
    .end annotation
.end field

.field public b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation runtime Lyk/b;
        value = "senderWhitelist"
    .end annotation
.end field

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation runtime Lyk/b;
        value = "senderBlacklist"
    .end annotation
.end field

.field public d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation runtime Lyk/b;
        value = "bodyBlacklist"
    .end annotation
.end field

.field public e:J
    .annotation runtime Lyk/b;
        value = "fromTime"
    .end annotation
.end field

.field public f:Ljava/lang/String;
    .annotation runtime Lyk/b;
        value = "key"
    .end annotation
.end field

.field public g:Ljava/lang/String;
    .annotation runtime Lyk/b;
        value = "keyid"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
