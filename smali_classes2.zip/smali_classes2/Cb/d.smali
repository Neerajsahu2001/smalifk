.class public final Lcb/d;
.super Ljava/lang/Object;
.source "InAppNotificationResponse.java"


# instance fields
.field public a:I

.field public b:I

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcb/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getNotifications()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcb/b;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcb/d;->c:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getTotal()I
    .registers 2

    iget v0, p0, Lcb/d;->b:I

    return v0
.end method

.method public getUnreadCount()I
    .registers 2

    iget v0, p0, Lcb/d;->a:I

    return v0
.end method

.method public setNotifications(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcb/b;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcb/d;->c:Ljava/util/ArrayList;

    return-void
.end method

.method public setTotal(I)V
    .registers 2

    iput p1, p0, Lcb/d;->b:I

    return-void
.end method

.method public setUnreadCount(I)V
    .registers 2

    iput p1, p0, Lcb/d;->a:I

    return-void
.end method
