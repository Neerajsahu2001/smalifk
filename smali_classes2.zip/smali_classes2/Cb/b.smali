.class public final Lcb/b;
.super Ljava/lang/Object;
.source "InAppNotification.java"


# instance fields
.field public a:Lcom/flipkart/mapi/model/component/data/renderables/b;

.field public b:Ljava/lang/Long;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Z

.field public f:Ljava/lang/String;

.field public g:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public k:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getAction()Lcom/flipkart/mapi/model/component/data/renderables/b;
    .registers 2

    iget-object v0, p0, Lcb/b;->a:Lcom/flipkart/mapi/model/component/data/renderables/b;

    return-object v0
.end method

.method public getDynamicImageUrl()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcb/b;->j:Ljava/lang/String;

    return-object v0
.end method

.method public getId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcb/b;->h:Ljava/lang/String;

    return-object v0
.end method

.method public getImages()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcb/b;->g:Ljava/util/Map;

    return-object v0
.end method

.method public getLayoutType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcb/b;->f:Ljava/lang/String;

    return-object v0
.end method

.method public getText()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcb/b;->d:Ljava/lang/String;

    return-object v0
.end method

.method public getTimestamp()Ljava/lang/Long;
    .registers 2

    iget-object v0, p0, Lcb/b;->b:Ljava/lang/Long;

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcb/b;->c:Ljava/lang/String;

    return-object v0
.end method

.method public getType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcb/b;->i:Ljava/lang/String;

    return-object v0
.end method

.method public getUid()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcb/b;->k:Ljava/lang/String;

    return-object v0
.end method

.method public isRead()Z
    .registers 2

    iget-boolean v0, p0, Lcb/b;->e:Z

    return v0
.end method

.method public setAction(Lcom/flipkart/mapi/model/component/data/renderables/b;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->a:Lcom/flipkart/mapi/model/component/data/renderables/b;

    return-void
.end method

.method public setDynamicImageUrl(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->j:Ljava/lang/String;

    return-void
.end method

.method public setId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->h:Ljava/lang/String;

    return-void
.end method

.method public setImages(Ljava/util/Map;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcb/b;->g:Ljava/util/Map;

    return-void
.end method

.method public setLayoutType(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->f:Ljava/lang/String;

    return-void
.end method

.method public setRead(Z)V
    .registers 2

    iput-boolean p1, p0, Lcb/b;->e:Z

    return-void
.end method

.method public setText(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->d:Ljava/lang/String;

    return-void
.end method

.method public setTimestamp(Ljava/lang/Long;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->b:Ljava/lang/Long;

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->c:Ljava/lang/String;

    return-void
.end method

.method public setType(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->i:Ljava/lang/String;

    return-void
.end method

.method public setUid(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcb/b;->k:Ljava/lang/String;

    return-void
.end method
