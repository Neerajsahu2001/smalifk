.class public final LCb/e;
.super Ljava/lang/Object;
.source "VarysErrorResponse.java"


# instance fields
.field public a:Lcom/flipkart/mapi/model/varys/ErrorCode;
    .annotation runtime Lyk/b;
        value = "errorCode"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
