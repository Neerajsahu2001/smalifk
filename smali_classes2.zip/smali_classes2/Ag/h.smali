.class public final LAg/h;
.super Ljg/g0;
.source "MultimediaWidgetData.java"


# instance fields
.field public a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LLe/f<",
            "LTe/s0;",
            ">;>;"
        }
    .end annotation
.end field

.field public b:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/O0;",
            ">;"
        }
    .end annotation
.end field

.field public c:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/O0;",
            ">;"
        }
    .end annotation
.end field

.field public d:Lhi/f;

.field public e:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/O0;",
            ">;"
        }
    .end annotation
.end field

.field public f:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/O0;",
            ">;"
        }
    .end annotation
.end field

.field public g:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/h;",
            ">;"
        }
    .end annotation
.end field

.field public h:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/O;",
            ">;"
        }
    .end annotation
.end field

.field public i:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/c1;",
            ">;"
        }
    .end annotation
.end field

.field public j:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/G3;",
            ">;"
        }
    .end annotation
.end field

.field public k:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "Lrf/b;",
            ">;"
        }
    .end annotation
.end field

.field public l:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/O0;",
            ">;"
        }
    .end annotation
.end field

.field public m:LXg/l;

.field public n:Ljava/lang/String;

.field public o:LTe/Q;

.field public p:LMe/r1;

.field public q:LMe/r1;

.field public r:J

.field public s:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LTe/A1;",
            ">;"
        }
    .end annotation
.end field

.field public t:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/i1;",
            ">;"
        }
    .end annotation
.end field

.field public u:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/T2;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljg/g0;-><init>()V

    return-void
.end method
