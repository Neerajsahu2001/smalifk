.class public final LAg/c;
.super Lxk/z;
.source "ComposedSwatchWidgetData$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LAg/d;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/c1;",
            ">;>;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/i1;",
            ">;>;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/u1;",
            ">;>;"
        }
    .end annotation
.end field

.field private final d:LJn/a$r;

.field private final e:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/F2;",
            ">;>;"
        }
    .end annotation
.end field

.field private final f:LJn/a$r;

.field private final g:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LAg/d;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 12

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/reflect/Type;

    const-class v2, LTe/c1;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-class v2, LLe/f;

    invoke-static {v2, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v1

    new-array v4, v0, [Ljava/lang/reflect/Type;

    const-class v5, LTe/i1;

    aput-object v5, v4, v3

    invoke-static {v2, v4}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v4

    new-array v5, v0, [Ljava/lang/reflect/Type;

    const-class v6, LTe/u1;

    aput-object v6, v5, v3

    invoke-static {v2, v5}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v5

    new-array v6, v0, [Ljava/lang/reflect/Type;

    const-class v7, LGe/h;

    aput-object v7, v6, v3

    invoke-static {v2, v6}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v6

    new-array v7, v0, [Ljava/lang/reflect/Type;

    const-class v8, LMe/F2;

    aput-object v8, v7, v3

    invoke-static {v2, v7}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v7

    new-array v8, v0, [Ljava/lang/reflect/Type;

    const-class v9, LMe/G3;

    aput-object v9, v8, v3

    invoke-static {v2, v8}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v8

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v9, LTe/E0;

    aput-object v9, v0, v3

    invoke-static {v2, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/c;->a:Lxk/z;

    invoke-virtual {p1, v4}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/c;->b:Lxk/z;

    invoke-virtual {p1, v5}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/c;->c:Lxk/z;

    invoke-virtual {p1, v6}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/c;->d:LJn/a$r;

    invoke-virtual {p1, v7}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/c;->e:Lxk/z;

    invoke-virtual {p1, v8}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/c;->f:LJn/a$r;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, LAg/c;->g:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LAg/d;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LAg/d;

    invoke-direct {v0}, LAg/d;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_125

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_12a

    goto/16 :goto_a7

    :sswitch_34
    const-string v2, "sizeChartData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_a7

    :cond_3e
    const/16 v3, 0x9

    goto/16 :goto_a7

    :sswitch_42
    const-string v2, "hasMultiTryOn"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_a7

    :cond_4c
    const/16 v3, 0x8

    goto/16 :goto_a7

    :sswitch_50
    const-string v2, "categoryNodeId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_59

    goto :goto_a7

    :cond_59
    const/4 v3, 0x7

    goto :goto_a7

    :sswitch_5b
    const-string v2, "swatchComponent"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_64

    goto :goto_a7

    :cond_64
    const/4 v3, 0x6

    goto :goto_a7

    :sswitch_66
    const-string v2, "ratingsAndReviews"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6f

    goto :goto_a7

    :cond_6f
    const/4 v3, 0x5

    goto :goto_a7

    :sswitch_71
    const-string v2, "callouts"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7a

    goto :goto_a7

    :cond_7a
    const/4 v3, 0x4

    goto :goto_a7

    :sswitch_7c
    const-string v2, "singleAttributeSwatch"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_85

    goto :goto_a7

    :cond_85
    const/4 v3, 0x3

    goto :goto_a7

    :sswitch_87
    const-string v2, "alternativeCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_90

    goto :goto_a7

    :cond_90
    const/4 v3, 0x2

    goto :goto_a7

    :sswitch_92
    const-string v2, "onboardingData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9b

    goto :goto_a7

    :cond_9b
    const/4 v3, 0x1

    goto :goto_a7

    :sswitch_9d
    const-string v2, "clearAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a6

    goto :goto_a7

    :cond_a6
    const/4 v3, 0x0

    :goto_a7
    iget-object v1, p0, LAg/c;->a:Lxk/z;

    packed-switch v3, :pswitch_data_154

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_b1
    iget-object v1, p0, LAg/c;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/d;->c:LLe/f;

    goto/16 :goto_1d

    :pswitch_bd
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, LAg/d;->f:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_c9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAg/d;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_d5
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/D;->a:LLe/f;

    goto/16 :goto_1d

    :pswitch_df
    iget-object v1, p0, LAg/c;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/D;->b:LLe/f;

    goto/16 :goto_1d

    :pswitch_eb
    iget-object v1, p0, LAg/c;->d:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/d;->e:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_f7
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/d;->d:LLe/f;

    goto/16 :goto_1d

    :pswitch_101
    iget-object v1, p0, LAg/c;->f:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/d;->i:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_10d
    iget-object v1, p0, LAg/c;->g:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/d;->j:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_119
    iget-object v1, p0, LAg/c;->e:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/d;->g:LLe/f;

    goto/16 :goto_1d

    :cond_125
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_12a
    .sparse-switch
        -0x7e268d1d -> :sswitch_9d
        -0x752beb9b -> :sswitch_92
        -0x56f76c3d -> :sswitch_87
        -0x51ae9f70 -> :sswitch_7c
        -0xa3da9bd -> :sswitch_71
        0x2b9be55a -> :sswitch_66
        0x2e162c21 -> :sswitch_5b
        0x54d9b15b -> :sswitch_50
        0x72f8557b -> :sswitch_42
        0x785acda7 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_154
    .packed-switch 0x0
        :pswitch_119
        :pswitch_10d
        :pswitch_101
        :pswitch_f7
        :pswitch_eb
        :pswitch_df
        :pswitch_d5
        :pswitch_c9
        :pswitch_bd
        :pswitch_b1
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LAg/c;->read(LBk/a;)LAg/d;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LAg/d;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "swatchComponent"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/D;->a:LLe/f;

    iget-object v1, p0, LAg/c;->a:Lxk/z;

    if-eqz v0, :cond_18

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "ratingsAndReviews"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/D;->b:LLe/f;

    if-eqz v0, :cond_2a

    iget-object v2, p0, LAg/c;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "sizeChartData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/d;->c:LLe/f;

    if-eqz v0, :cond_3c

    iget-object v2, p0, LAg/c;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "singleAttributeSwatch"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/d;->d:LLe/f;

    if-eqz v0, :cond_4c

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_4f

    :cond_4c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_4f
    const-string v0, "callouts"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/d;->e:Ljava/util/List;

    if-eqz v0, :cond_63

    iget-object v1, p0, LAg/c;->d:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_66

    :cond_63
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_66
    const-string v0, "hasMultiTryOn"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/d;->f:Ljava/lang/Boolean;

    if-eqz v0, :cond_75

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_78

    :cond_75
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_78
    const-string v0, "clearAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/d;->g:LLe/f;

    if-eqz v0, :cond_87

    iget-object v1, p0, LAg/c;->e:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_8a

    :cond_87
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_8a
    const-string v0, "categoryNodeId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/d;->h:Ljava/lang/String;

    if-eqz v0, :cond_99

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_9c

    :cond_99
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_9c
    const-string v0, "alternativeCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/d;->i:Ljava/util/List;

    if-eqz v0, :cond_b0

    iget-object v1, p0, LAg/c;->f:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_b3

    :cond_b0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_b3
    const-string v0, "onboardingData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LAg/d;->j:Ljava/util/List;

    if-eqz p2, :cond_c7

    iget-object v0, p0, LAg/c;->g:LJn/a$r;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/util/Collection;

    invoke-virtual {v0, p1, p2}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_ca

    :cond_c7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ca
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LAg/d;

    invoke-virtual {p0, p1, p2}, LAg/c;->write(LBk/c;LAg/d;)V

    return-void
.end method
