.class public final LAg/w;
.super Lxk/z;
.source "SellerV4WidgetData$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LAg/x;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lgh/b;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/G3;",
            ">;"
        }
    .end annotation
.end field

.field private final c:LJn/a$r;

.field private final d:LJn/a$r;

.field private final e:LJn/a$r;

.field private final f:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/T2;",
            ">;"
        }
    .end annotation
.end field

.field private final g:LJn/a$r;

.field private final h:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/m1;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LAg/x;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 8

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/reflect/Type;

    const-class v2, Lbh/i;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-class v2, LLe/f;

    invoke-static {v2, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v1

    new-array v4, v0, [Ljava/lang/reflect/Type;

    const-class v5, LMe/h;

    aput-object v5, v4, v3

    invoke-static {v2, v4}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v4

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v5, LTe/m1;

    aput-object v5, v0, v3

    invoke-static {v2, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v2, Lgh/a;->d:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v2

    iput-object v2, p0, LAg/w;->a:Lxk/z;

    sget-object v2, LMe/F3;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v2

    iput-object v2, p0, LAg/w;->b:Lxk/z;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/w;->c:LJn/a$r;

    sget-object v1, Lof/a;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/w;->d:LJn/a$r;

    new-instance v1, LJn/a$t;

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v3, LJn/a$o;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v2, v2, v3}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/w;->e:LJn/a$r;

    sget-object v1, LMe/S2;->d:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/w;->f:Lxk/z;

    invoke-virtual {p1, v4}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/w;->g:LJn/a$r;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LAg/w;->h:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LAg/x;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LAg/x;

    invoke-direct {v0}, LAg/x;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_157

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_168

    goto/16 :goto_c3

    :sswitch_34
    const-string v2, "paymentOptions"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_c3

    :cond_3e
    const/16 v3, 0xb

    goto/16 :goto_c3

    :sswitch_42
    const-string v2, "offerTags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_c3

    :cond_4c
    const/16 v3, 0xa

    goto/16 :goto_c3

    :sswitch_50
    const-string v2, "saalListings"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_c3

    :cond_5a
    const/16 v3, 0x9

    goto/16 :goto_c3

    :sswitch_5e
    const-string v2, "primitiveTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_c3

    :cond_68
    const/16 v3, 0x8

    goto/16 :goto_c3

    :sswitch_6c
    const-string v2, "selected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_75

    goto :goto_c3

    :cond_75
    const/4 v3, 0x7

    goto :goto_c3

    :sswitch_77
    const-string v2, "deliveryInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_80

    goto :goto_c3

    :cond_80
    const/4 v3, 0x6

    goto :goto_c3

    :sswitch_82
    const-string v2, "announcements"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8b

    goto :goto_c3

    :cond_8b
    const/4 v3, 0x5

    goto :goto_c3

    :sswitch_8d
    const-string v2, "sellerInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_96

    goto :goto_c3

    :cond_96
    const/4 v3, 0x4

    goto :goto_c3

    :sswitch_98
    const-string v2, "pricing"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a1

    goto :goto_c3

    :cond_a1
    const/4 v3, 0x3

    goto :goto_c3

    :sswitch_a3
    const-string v2, "fasterDeliveryCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ac

    goto :goto_c3

    :cond_ac
    const/4 v3, 0x2

    goto :goto_c3

    :sswitch_ae
    const-string v2, "fkAssured"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b7

    goto :goto_c3

    :cond_b7
    const/4 v3, 0x1

    goto :goto_c3

    :sswitch_b9
    const-string v2, "listingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c2

    goto :goto_c3

    :cond_c2
    const/4 v3, 0x0

    :goto_c3
    packed-switch v3, :pswitch_data_19a

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_cb
    iget-object v1, p0, LAg/w;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/G3;

    iput-object v1, v0, LAg/x;->b:LMe/G3;

    goto/16 :goto_1d

    :pswitch_d7
    iget-object v1, p0, LAg/w;->d:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/x;->d:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_e3
    iget-object v1, p0, LAg/w;->e:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/x;->f:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_ef
    iget-object v1, p0, LAg/w;->f:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/T2;

    iput-object v1, v0, LAg/x;->g:LMe/T2;

    goto/16 :goto_1d

    :pswitch_fb
    iget-boolean v1, v0, LAg/x;->k:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LAg/x;->k:Z

    goto/16 :goto_1d

    :pswitch_105
    iget-object v1, p0, LAg/w;->c:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/x;->c:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_111
    iget-object v1, p0, LAg/w;->g:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/x;->h:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_11d
    iget-object v1, p0, LAg/w;->h:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/x;->i:LLe/f;

    goto/16 :goto_1d

    :pswitch_129
    iget-object v1, p0, LAg/w;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lgh/b;

    iput-object v1, v0, LAg/x;->a:Lgh/b;

    goto/16 :goto_1d

    :pswitch_135
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAg/x;->l:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_141
    iget-boolean v1, v0, LAg/x;->j:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LAg/x;->j:Z

    goto/16 :goto_1d

    :pswitch_14b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAg/x;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_157
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LAg/x;->i:LLe/f;

    if-eqz p1, :cond_15f

    return-object v0

    :cond_15f
    new-instance p1, Ljava/io/IOException;

    const-string v0, "sellerInfo cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_168
    .sparse-switch
        -0x486bcd41 -> :sswitch_b9
        -0x48603288 -> :sswitch_ae
        -0x12f9e7ad -> :sswitch_a3
        -0x12c7603a -> :sswitch_98
        0x12e050cd -> :sswitch_8d
        0x21b15c0c -> :sswitch_82
        0x28a0dac2 -> :sswitch_77
        0x4705f29b -> :sswitch_6c
        0x4c5bbd33 -> :sswitch_5e
        0x5040b088 -> :sswitch_50
        0x73e73495 -> :sswitch_42
        0x7a2db9b8 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_19a
    .packed-switch 0x0
        :pswitch_14b
        :pswitch_141
        :pswitch_135
        :pswitch_129
        :pswitch_11d
        :pswitch_111
        :pswitch_105
        :pswitch_fb
        :pswitch_ef
        :pswitch_e3
        :pswitch_d7
        :pswitch_cb
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LAg/w;->read(LBk/a;)LAg/x;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LAg/x;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "pricing"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->a:Lgh/b;

    if-eqz v0, :cond_18

    iget-object v1, p0, LAg/w;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "paymentOptions"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->b:LMe/G3;

    if-eqz v0, :cond_2a

    iget-object v1, p0, LAg/w;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "deliveryInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->c:Ljava/util/List;

    if-eqz v0, :cond_41

    iget-object v1, p0, LAg/w;->c:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_44

    :cond_41
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_44
    const-string v0, "offerTags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->d:Ljava/util/List;

    if-eqz v0, :cond_58

    iget-object v1, p0, LAg/w;->d:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_5b

    :cond_58
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_5b
    const-string v0, "listingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->e:Ljava/lang/String;

    if-eqz v0, :cond_6a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_6d

    :cond_6a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_6d
    const-string v0, "saalListings"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->f:Ljava/util/List;

    if-eqz v0, :cond_81

    iget-object v1, p0, LAg/w;->e:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_84

    :cond_81
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_84
    const-string v0, "primitiveTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->g:LMe/T2;

    if-eqz v0, :cond_93

    iget-object v1, p0, LAg/w;->f:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_96

    :cond_93
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_96
    const-string v0, "announcements"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->h:Ljava/util/List;

    if-eqz v0, :cond_aa

    iget-object v1, p0, LAg/w;->g:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_ad

    :cond_aa
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ad
    const-string v0, "sellerInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/x;->i:LLe/f;

    if-eqz v0, :cond_e5

    iget-object v1, p0, LAg/w;->h:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "fkAssured"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LAg/x;->j:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "selected"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LAg/x;->k:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "fasterDeliveryCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LAg/x;->l:Ljava/lang/String;

    if-eqz p2, :cond_de

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_e1

    :cond_de
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_e1
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_e5
    new-instance p1, Ljava/io/IOException;

    const-string p2, "sellerInfo cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LAg/x;

    invoke-virtual {p0, p1, p2}, LAg/w;->write(LBk/c;LAg/x;)V

    return-void
.end method
