.class public final LAg/v;
.super LAg/t;
.source "ProductOffersV4WidgetData.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LAg/t;-><init>()V

    return-void
.end method
