.class public final LAg/q;
.super Lxk/z;
.source "ProductOffersV2WidgetData$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LAg/r;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LAg/r;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v1, LTe/Y0;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-class v1, LLe/f;

    invoke-static {v1, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, LAg/q;->a:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LAg/r;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LAg/r;

    invoke-direct {v0}, LAg/r;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3a

    const-string v1, "renderableComponents"

    invoke-static {p1, v1}, Landroidx/exifinterface/media/a;->d(LBk/a;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2f

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :cond_2f
    iget-object v1, p0, LAg/q;->a:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Ljg/p;->a:Ljava/util/List;

    goto :goto_1d

    :cond_3a
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LAg/q;->read(LBk/a;)LAg/r;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LAg/r;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "renderableComponents"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Ljg/p;->a:Ljava/util/List;

    if-eqz p2, :cond_1d

    iget-object v0, p0, LAg/q;->a:LJn/a$r;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/util/Collection;

    invoke-virtual {v0, p1, p2}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_20

    :cond_1d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_20
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LAg/r;

    invoke-virtual {p0, p1, p2}, LAg/q;->write(LBk/c;LAg/r;)V

    return-void
.end method
