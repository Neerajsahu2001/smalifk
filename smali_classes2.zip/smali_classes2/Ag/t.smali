.class public LAg/t;
.super LAg/r;
.source "ProductOffersV3WidgetData.java"


# instance fields
.field public b:Lbf/h;

.field public c:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LAg/r;-><init>()V

    return-void
.end method
