.class public final LAg/p;
.super Ljg/g0;
.source "ProductActionWidgetData.java"


# instance fields
.field public a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LLe/f<",
            "LTe/O0;",
            ">;>;"
        }
    .end annotation
.end field

.field public b:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljg/g0;-><init>()V

    return-void
.end method
