.class public final LAg/n;
.super Ljg/g0;
.source "PolicyDetailsWidgetData.java"


# instance fields
.field public a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LLe/f<",
            "LTe/I0;",
            ">;>;"
        }
    .end annotation
.end field

.field public b:Z

.field public c:I

.field public d:LMe/T2;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljg/g0;-><init>()V

    return-void
.end method
