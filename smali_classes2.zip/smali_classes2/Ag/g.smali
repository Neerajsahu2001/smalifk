.class public final LAg/g;
.super Lxk/z;
.source "MultimediaWidgetData$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LAg/h;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:LJn/a$r;

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/O0;",
            ">;>;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lhi/f;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/h;",
            ">;>;"
        }
    .end annotation
.end field

.field private final e:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/O;",
            ">;>;"
        }
    .end annotation
.end field

.field private final f:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/c1;",
            ">;>;"
        }
    .end annotation
.end field

.field private final g:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/G3;",
            ">;>;"
        }
    .end annotation
.end field

.field private final h:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "Lrf/b;",
            ">;>;"
        }
    .end annotation
.end field

.field private final i:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LXg/l;",
            ">;"
        }
    .end annotation
.end field

.field private final j:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field private final k:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field

.field private final l:LJn/a$r;

.field private final m:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/i1;",
            ">;>;"
        }
    .end annotation
.end field

.field private final n:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/T2;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LAg/h;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 14

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/reflect/Type;

    const-class v2, LTe/s0;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-class v2, LLe/f;

    invoke-static {v2, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v1

    new-array v4, v0, [Ljava/lang/reflect/Type;

    const-class v5, LTe/O0;

    aput-object v5, v4, v3

    invoke-static {v2, v4}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v4

    new-array v5, v0, [Ljava/lang/reflect/Type;

    const-class v6, LMe/h;

    aput-object v6, v5, v3

    invoke-static {v2, v5}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v5

    new-array v6, v0, [Ljava/lang/reflect/Type;

    const-class v7, LMe/O;

    aput-object v7, v6, v3

    invoke-static {v2, v6}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v6

    new-array v7, v0, [Ljava/lang/reflect/Type;

    const-class v8, LTe/c1;

    aput-object v8, v7, v3

    invoke-static {v2, v7}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v7

    new-array v8, v0, [Ljava/lang/reflect/Type;

    const-class v9, LMe/G3;

    aput-object v9, v8, v3

    invoke-static {v2, v8}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v8

    new-array v9, v0, [Ljava/lang/reflect/Type;

    const-class v10, Lrf/b;

    aput-object v10, v9, v3

    invoke-static {v2, v9}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v9

    new-array v10, v0, [Ljava/lang/reflect/Type;

    const-class v11, LTe/i1;

    aput-object v11, v10, v3

    invoke-static {v2, v10}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v10

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v11, LMe/T2;

    aput-object v11, v0, v3

    invoke-static {v2, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/g;->a:LJn/a$r;

    invoke-virtual {p1, v4}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->b:Lxk/z;

    sget-object v1, Lhi/e;->h:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->c:Lxk/z;

    invoke-virtual {p1, v5}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->d:Lxk/z;

    invoke-virtual {p1, v6}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->e:Lxk/z;

    invoke-virtual {p1, v7}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->f:Lxk/z;

    invoke-virtual {p1, v8}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->g:Lxk/z;

    invoke-virtual {p1, v9}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->h:Lxk/z;

    sget-object v1, LXg/k;->f:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->i:Lxk/z;

    sget-object v1, LTe/P;->f:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->j:Lxk/z;

    sget-object v1, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->k:Lxk/z;

    sget-object v1, LTe/z1;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LAg/g;->l:LJn/a$r;

    invoke-virtual {p1, v10}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/g;->m:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LAg/g;->n:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LAg/h;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LAg/h;

    invoke-direct {v0}, LAg/h;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_239

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_23e

    goto/16 :goto_141

    :sswitch_34
    const-string v2, "floatingActionValues"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_141

    :cond_3e
    const/16 v3, 0x14

    goto/16 :goto_141

    :sswitch_42
    const-string v2, "autoScrollToIndex"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_141

    :cond_4c
    const/16 v3, 0x13

    goto/16 :goto_141

    :sswitch_50
    const-string v2, "themeTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_141

    :cond_5a
    const/16 v3, 0x12

    goto/16 :goto_141

    :sswitch_5e
    const-string v2, "ratingsAndReviews"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_141

    :cond_68
    const/16 v3, 0x11

    goto/16 :goto_141

    :sswitch_6c
    const-string v2, "trustMarkerCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_141

    :cond_76
    const/16 v3, 0x10

    goto/16 :goto_141

    :sswitch_7a
    const-string v2, "tryTheShadeAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_141

    :cond_84
    const/16 v3, 0xf

    goto/16 :goto_141

    :sswitch_88
    const-string v2, "multimediaComponents"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_141

    :cond_92
    const/16 v3, 0xe

    goto/16 :goto_141

    :sswitch_96
    const-string v2, "offerButton"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_141

    :cond_a0
    const/16 v3, 0xd

    goto/16 :goto_141

    :sswitch_a4
    const-string v2, "shareAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_141

    :cond_ae
    const/16 v3, 0xc

    goto/16 :goto_141

    :sswitch_b2
    const-string v2, "showSimilarAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_141

    :cond_bc
    const/16 v3, 0xb

    goto/16 :goto_141

    :sswitch_c0
    const-string v2, "tagsData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ca

    goto/16 :goto_141

    :cond_ca
    const/16 v3, 0xa

    goto/16 :goto_141

    :sswitch_ce
    const-string v2, "wowTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d8

    goto/16 :goto_141

    :cond_d8
    const/16 v3, 0x9

    goto/16 :goto_141

    :sswitch_dc
    const-string v2, "productDetailsAnnouncement"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e6

    goto/16 :goto_141

    :cond_e6
    const/16 v3, 0x8

    goto/16 :goto_141

    :sswitch_ea
    const-string v2, "spotlight"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f3

    goto :goto_141

    :cond_f3
    const/4 v3, 0x7

    goto :goto_141

    :sswitch_f5
    const-string v2, "wishlistAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_fe

    goto :goto_141

    :cond_fe
    const/4 v3, 0x6

    goto :goto_141

    :sswitch_100
    const-string v2, "eventsRightOverlayImage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_109

    goto :goto_141

    :cond_109
    const/4 v3, 0x5

    goto :goto_141

    :sswitch_10b
    const-string v2, "singleAttributeSwatch"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_114

    goto :goto_141

    :cond_114
    const/4 v3, 0x4

    goto :goto_141

    :sswitch_116
    const-string v2, "virtualTryOnAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11f

    goto :goto_141

    :cond_11f
    const/4 v3, 0x3

    goto :goto_141

    :sswitch_121
    const-string v2, "tryOnLookId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12a

    goto :goto_141

    :cond_12a
    const/4 v3, 0x2

    goto :goto_141

    :sswitch_12c
    const-string v2, "arWidgetData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_135

    goto :goto_141

    :cond_135
    const/4 v3, 0x1

    goto :goto_141

    :sswitch_137
    const-string v2, "eventsLeftOverlayImage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_140

    goto :goto_141

    :cond_140
    const/4 v3, 0x0

    :goto_141
    iget-object v1, p0, LAg/g;->k:Lxk/z;

    iget-object v2, p0, LAg/g;->b:Lxk/z;

    packed-switch v3, :pswitch_data_294

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_14d
    iget-object v1, p0, LAg/g;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lhi/f;

    iput-object v1, v0, LAg/h;->d:Lhi/f;

    goto/16 :goto_1d

    :pswitch_159
    iget-wide v1, v0, LAg/h;->r:J

    invoke-static {p1, v1, v2}, LJn/a$B;->a(LBk/a;J)J

    move-result-wide v1

    iput-wide v1, v0, LAg/h;->r:J

    goto/16 :goto_1d

    :pswitch_163
    iget-object v1, p0, LAg/g;->j:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, LAg/h;->o:LTe/Q;

    goto/16 :goto_1d

    :pswitch_16f
    iget-object v1, p0, LAg/g;->m:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->t:LLe/f;

    goto/16 :goto_1d

    :pswitch_17b
    iget-object v1, p0, LAg/g;->g:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->j:LLe/f;

    goto/16 :goto_1d

    :pswitch_187
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->f:LLe/f;

    goto/16 :goto_1d

    :pswitch_191
    iget-object v1, p0, LAg/g;->a:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/h;->a:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_19d
    iget-object v1, p0, LAg/g;->e:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->h:LLe/f;

    goto/16 :goto_1d

    :pswitch_1a9
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->c:LLe/f;

    goto/16 :goto_1d

    :pswitch_1b3
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->l:LLe/f;

    goto/16 :goto_1d

    :pswitch_1bd
    iget-object v1, p0, LAg/g;->l:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LAg/h;->s:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_1c9
    iget-object v1, p0, LAg/g;->n:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->u:LLe/f;

    goto/16 :goto_1d

    :pswitch_1d5
    iget-object v1, p0, LAg/g;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->g:LLe/f;

    goto/16 :goto_1d

    :pswitch_1e1
    iget-object v1, p0, LAg/g;->h:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->k:LLe/f;

    goto/16 :goto_1d

    :pswitch_1ed
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->b:LLe/f;

    goto/16 :goto_1d

    :pswitch_1f7
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, LAg/h;->q:LMe/r1;

    goto/16 :goto_1d

    :pswitch_201
    iget-object v1, p0, LAg/g;->f:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->i:LLe/f;

    goto/16 :goto_1d

    :pswitch_20d
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/h;->e:LLe/f;

    goto/16 :goto_1d

    :pswitch_217
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAg/h;->n:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_223
    iget-object v1, p0, LAg/g;->i:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LXg/l;

    iput-object v1, v0, LAg/h;->m:LXg/l;

    goto/16 :goto_1d

    :pswitch_22f
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, LAg/h;->p:LMe/r1;

    goto/16 :goto_1d

    :cond_239
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_23e
    .sparse-switch
        -0x780a6435 -> :sswitch_137
        -0x635de4e1 -> :sswitch_12c
        -0x59e74a4c -> :sswitch_121
        -0x55aa2c3b -> :sswitch_116
        -0x51ae9f70 -> :sswitch_10b
        -0x488ff8f2 -> :sswitch_100
        -0x465807a5 -> :sswitch_f5
        -0x36d572ac -> :sswitch_ea
        -0x332520c6 -> :sswitch_dc
        -0x2e9bbd85 -> :sswitch_ce
        -0x2c831c9d -> :sswitch_c0
        -0x2c1043fc -> :sswitch_b2
        -0x1bcfe90b -> :sswitch_a4
        -0x6ab0752 -> :sswitch_96
        0x16e533c1 -> :sswitch_88
        0x1d02f42d -> :sswitch_7a
        0x20ee5f1e -> :sswitch_6c
        0x2b9be55a -> :sswitch_5e
        0x42191111 -> :sswitch_50
        0x5387261b -> :sswitch_42
        0x56d58a1e -> :sswitch_34
    .end sparse-switch

    :pswitch_data_294
    .packed-switch 0x0
        :pswitch_22f
        :pswitch_223
        :pswitch_217
        :pswitch_20d
        :pswitch_201
        :pswitch_1f7
        :pswitch_1ed
        :pswitch_1e1
        :pswitch_1d5
        :pswitch_1c9
        :pswitch_1bd
        :pswitch_1b3
        :pswitch_1a9
        :pswitch_19d
        :pswitch_191
        :pswitch_187
        :pswitch_17b
        :pswitch_16f
        :pswitch_163
        :pswitch_159
        :pswitch_14d
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LAg/g;->read(LBk/a;)LAg/h;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LAg/h;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "multimediaComponents"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->a:Ljava/util/List;

    if-eqz v0, :cond_1d

    iget-object v1, p0, LAg/g;->a:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_20

    :cond_1d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_20
    const-string v0, "wishlistAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->b:LLe/f;

    iget-object v1, p0, LAg/g;->b:Lxk/z;

    if-eqz v0, :cond_2f

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_32

    :cond_2f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_32
    const-string v0, "shareAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->c:LLe/f;

    if-eqz v0, :cond_3f

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_42

    :cond_3f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_42
    const-string v0, "floatingActionValues"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->d:Lhi/f;

    if-eqz v0, :cond_51

    iget-object v2, p0, LAg/g;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_54

    :cond_51
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_54
    const-string v0, "virtualTryOnAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->e:LLe/f;

    if-eqz v0, :cond_61

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_64

    :cond_61
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_64
    const-string v0, "tryTheShadeAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->f:LLe/f;

    if-eqz v0, :cond_71

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_74

    :cond_71
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_74
    const-string v0, "productDetailsAnnouncement"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->g:LLe/f;

    if-eqz v0, :cond_83

    iget-object v2, p0, LAg/g;->d:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_86

    :cond_83
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_86
    const-string v0, "offerButton"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->h:LLe/f;

    if-eqz v0, :cond_95

    iget-object v2, p0, LAg/g;->e:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_98

    :cond_95
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_98
    const-string v0, "singleAttributeSwatch"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->i:LLe/f;

    if-eqz v0, :cond_a7

    iget-object v2, p0, LAg/g;->f:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_aa

    :cond_a7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_aa
    const-string v0, "trustMarkerCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->j:LLe/f;

    if-eqz v0, :cond_b9

    iget-object v2, p0, LAg/g;->g:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_bc

    :cond_b9
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_bc
    const-string v0, "spotlight"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->k:LLe/f;

    if-eqz v0, :cond_cb

    iget-object v2, p0, LAg/g;->h:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ce

    :cond_cb
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ce
    const-string v0, "showSimilarAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->l:LLe/f;

    if-eqz v0, :cond_db

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_de

    :cond_db
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_de
    const-string v0, "arWidgetData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->m:LXg/l;

    if-eqz v0, :cond_ed

    iget-object v1, p0, LAg/g;->i:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_f0

    :cond_ed
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_f0
    const-string v0, "tryOnLookId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->n:Ljava/lang/String;

    if-eqz v0, :cond_ff

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_102

    :cond_ff
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_102
    const-string v0, "themeTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->o:LTe/Q;

    if-eqz v0, :cond_111

    iget-object v1, p0, LAg/g;->j:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_114

    :cond_111
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_114
    const-string v0, "eventsLeftOverlayImage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->p:LMe/r1;

    iget-object v1, p0, LAg/g;->k:Lxk/z;

    if-eqz v0, :cond_123

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_126

    :cond_123
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_126
    const-string v0, "eventsRightOverlayImage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->q:LMe/r1;

    if-eqz v0, :cond_133

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_136

    :cond_133
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_136
    const-string v0, "autoScrollToIndex"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, LAg/h;->r:J

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "tagsData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->s:Ljava/util/List;

    if-eqz v0, :cond_154

    iget-object v1, p0, LAg/g;->l:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_157

    :cond_154
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_157
    const-string v0, "ratingsAndReviews"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/h;->t:LLe/f;

    if-eqz v0, :cond_166

    iget-object v1, p0, LAg/g;->m:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_169

    :cond_166
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_169
    const-string v0, "wowTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LAg/h;->u:LLe/f;

    if-eqz p2, :cond_178

    iget-object v0, p0, LAg/g;->n:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_17b

    :cond_178
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_17b
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LAg/h;

    invoke-virtual {p0, p1, p2}, LAg/g;->write(LBk/c;LAg/h;)V

    return-void
.end method
