.class public LAg/r;
.super Ljg/p;
.source "ProductOffersV2WidgetData.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljg/p<",
        "LTe/Y0;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljg/p;-><init>()V

    return-void
.end method
