.class public final LAg/y;
.super Lxk/z;
.source "SizeChartSwatchWidgetData$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LAg/z;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/c1;",
            ">;>;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/u1;",
            ">;>;"
        }
    .end annotation
.end field

.field private final c:LJn/a$t;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LAg/z;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 7

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/reflect/Type;

    const-class v2, LTe/c1;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-class v2, LLe/f;

    invoke-static {v2, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v4, LTe/u1;

    aput-object v4, v0, v3

    invoke-static {v2, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LAg/y;->a:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LAg/y;->b:Lxk/z;

    new-instance p1, LJn/a$r;

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {p1, v0, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    new-instance v1, LJn/a$t;

    new-instance v2, LJn/a$s;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, p1, v2}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, LAg/y;->c:LJn/a$t;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LAg/z;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LAg/z;

    invoke-direct {v0}, LAg/z;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7b

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_80

    goto :goto_53

    :sswitch_33
    const-string v2, "sizeChartData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_53

    :cond_3c
    const/4 v3, 0x2

    goto :goto_53

    :sswitch_3e
    const-string v2, "swatchComponent"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_53

    :cond_47
    const/4 v3, 0x1

    goto :goto_53

    :sswitch_49
    const-string v2, "urlParams"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_53

    :cond_52
    const/4 v3, 0x0

    :goto_53
    packed-switch v3, :pswitch_data_8e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_5a
    iget-object v1, p0, LAg/y;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/z;->b:LLe/f;

    goto :goto_1d

    :pswitch_65
    iget-object v1, p0, LAg/y;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LAg/z;->a:LLe/f;

    goto :goto_1d

    :pswitch_70
    iget-object v1, p0, LAg/y;->c:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, LAg/z;->c:Ljava/util/Map;

    goto :goto_1d

    :cond_7b
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_80
    .sparse-switch
        -0x1b42642b -> :sswitch_49
        0x2e162c21 -> :sswitch_3e
        0x785acda7 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_8e
    .packed-switch 0x0
        :pswitch_70
        :pswitch_65
        :pswitch_5a
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LAg/y;->read(LBk/a;)LAg/z;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LAg/z;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "swatchComponent"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/z;->a:LLe/f;

    if-eqz v0, :cond_18

    iget-object v1, p0, LAg/y;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "sizeChartData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAg/z;->b:LLe/f;

    if-eqz v0, :cond_2a

    iget-object v1, p0, LAg/y;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "urlParams"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LAg/z;->c:Ljava/util/Map;

    if-eqz p2, :cond_3c

    iget-object v0, p0, LAg/y;->c:LJn/a$t;

    invoke-virtual {v0, p1, p2}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LAg/z;

    invoke-virtual {p0, p1, p2}, LAg/y;->write(LBk/c;LAg/z;)V

    return-void
.end method
