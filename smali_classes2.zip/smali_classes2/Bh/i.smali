.class public final Lbh/i;
.super LMe/R3;
.source "DeliveryInfoMessage.java"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:LMe/j0;

.field public f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/flipkart/rome/datatypes/response/product/Price;",
            ">;"
        }
    .end annotation
.end field

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Z

.field public j:Z

.field public k:Z

.field public l:LTe/Q;

.field public m:Z

.field public n:LTe/Q;

.field public o:Ljava/lang/String;

.field public p:LMe/r1;

.field public q:LTe/Q;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LMe/R3;-><init>()V

    return-void
.end method
