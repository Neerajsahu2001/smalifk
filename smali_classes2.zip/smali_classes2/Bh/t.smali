.class public final Lbh/t;
.super Lxk/z;
.source "PricePerUnitAttributes$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lbh/t;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;

    invoke-direct {v0}, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8b

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_9c

    goto :goto_5e

    :sswitch_33
    const-string v2, "pricePerUnit"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_5e

    :cond_3c
    const/4 v3, 0x3

    goto :goto_5e

    :sswitch_3e
    const-string v2, "pivotValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_5e

    :cond_47
    const/4 v3, 0x2

    goto :goto_5e

    :sswitch_49
    const-string v2, "bestValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_5e

    :cond_52
    const/4 v3, 0x1

    goto :goto_5e

    :sswitch_54
    const-string v2, "pivotQualifier"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_5e

    :cond_5d
    const/4 v3, 0x0

    :goto_5e
    packed-switch v3, :pswitch_data_ae

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_65
    iget-wide v1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pricePerUnit:D

    invoke-static {p1, v1, v2}, LJn/a$x;->a(LBk/a;D)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pricePerUnit:D

    goto :goto_1d

    :pswitch_6e
    iget-wide v1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pivotValue:D

    invoke-static {p1, v1, v2}, LJn/a$x;->a(LBk/a;D)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pivotValue:D

    goto :goto_1d

    :pswitch_77
    iget-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->bestValue:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->bestValue:Z

    goto :goto_1d

    :pswitch_80
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pivotQualifier:Ljava/lang/String;

    goto :goto_1d

    :cond_8b
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pivotQualifier:Ljava/lang/String;

    if-eqz p1, :cond_93

    return-object v0

    :cond_93
    new-instance p1, Ljava/io/IOException;

    const-string v0, "pivotQualifier cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_9c
    .sparse-switch
        -0x61d71178 -> :sswitch_54
        0x4c5199ed -> :sswitch_49
        0x4cad2e4f -> :sswitch_3e
        0x6ab7bab8 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_ae
    .packed-switch 0x0
        :pswitch_80
        :pswitch_77
        :pswitch_6e
        :pswitch_65
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbh/t;->read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "pricePerUnit"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pricePerUnit:D

    invoke-virtual {p1, v0, v1}, LBk/c;->value(D)LBk/c;

    const-string v0, "pivotQualifier"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pivotQualifier:Ljava/lang/String;

    if-eqz v0, :cond_39

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "pivotValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->pivotValue:D

    invoke-virtual {p1, v0, v1}, LBk/c;->value(D)LBk/c;

    const-string v0, "bestValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;->bestValue:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_39
    new-instance p1, Ljava/io/IOException;

    const-string p2, "pivotQualifier cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;

    invoke-virtual {p0, p1, p2}, Lbh/t;->write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/PricePerUnitAttributes;)V

    return-void
.end method
