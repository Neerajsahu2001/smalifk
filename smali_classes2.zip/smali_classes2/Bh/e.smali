.class public final Lbh/e;
.super Ljg/g0;
.source "ChildProductInfo.java"


# instance fields
.field public a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lad/d;",
            ">;"
        }
    .end annotation
.end field

.field public b:Lad/d;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljg/g0;-><init>()V

    return-void
.end method
