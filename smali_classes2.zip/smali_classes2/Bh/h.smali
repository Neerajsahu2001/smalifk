.class public final Lbh/h;
.super Lxk/z;
.source "DeliveryInfoMessage$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lbh/i;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/j0;",
            ">;"
        }
    .end annotation
.end field

.field private final b:LJn/a$r;

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lbh/i;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, LMe/i0;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lbh/h;->a:Lxk/z;

    sget-object v0, Lbh/s;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Lbh/h;->b:LJn/a$r;

    sget-object v0, LTe/P;->f:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lbh/h;->c:Lxk/z;

    sget-object v0, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lbh/h;->d:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lbh/i;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lbh/i;

    invoke-direct {v0}, Lbh/i;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1eb

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_214

    goto/16 :goto_117

    :sswitch_34
    const-string v2, "slaTextFormattedValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_117

    :cond_3e
    const/16 v3, 0x11

    goto/16 :goto_117

    :sswitch_42
    const-string v2, "expressDeliveryCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_117

    :cond_4c
    const/16 v3, 0x10

    goto/16 :goto_117

    :sswitch_50
    const-string v2, "dateText"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_117

    :cond_5a
    const/16 v3, 0xf

    goto/16 :goto_117

    :sswitch_5e
    const-string v2, "countdownTimerData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_117

    :cond_68
    const/16 v3, 0xe

    goto/16 :goto_117

    :sswitch_6c
    const-string v2, "installationDeliveryMessage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_117

    :cond_76
    const/16 v3, 0xd

    goto/16 :goto_117

    :sswitch_7a
    const-string v2, "deliveryMessageType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_117

    :cond_84
    const/16 v3, 0xc

    goto/16 :goto_117

    :sswitch_88
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_117

    :cond_92
    const/16 v3, 0xb

    goto/16 :goto_117

    :sswitch_96
    const-string v2, "text"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_117

    :cond_a0
    const/16 v3, 0xa

    goto/16 :goto_117

    :sswitch_a4
    const-string v2, "alternateText"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_117

    :cond_ae
    const/16 v3, 0x9

    goto/16 :goto_117

    :sswitch_b2
    const-string v2, "fasterDelivery"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_117

    :cond_bc
    const/16 v3, 0x8

    goto/16 :goto_117

    :sswitch_c0
    const-string v2, "vipDelivery"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c9

    goto :goto_117

    :cond_c9
    const/4 v3, 0x7

    goto :goto_117

    :sswitch_cb
    const-string v2, "vipDeliveryMessage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d4

    goto :goto_117

    :cond_d4
    const/4 v3, 0x6

    goto :goto_117

    :sswitch_d6
    const-string v2, "imageUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_df

    goto :goto_117

    :cond_df
    const/4 v3, 0x5

    goto :goto_117

    :sswitch_e1
    const-string v2, "freeOption"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ea

    goto :goto_117

    :cond_ea
    const/4 v3, 0x4

    goto :goto_117

    :sswitch_ec
    const-string v2, "charge"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f5

    goto :goto_117

    :cond_f5
    const/4 v3, 0x3

    goto :goto_117

    :sswitch_f7
    const-string v2, "plusIcon"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_100

    goto :goto_117

    :cond_100
    const/4 v3, 0x2

    goto :goto_117

    :sswitch_102
    const-string v2, "subtext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10b

    goto :goto_117

    :cond_10b
    const/4 v3, 0x1

    goto :goto_117

    :sswitch_10d
    const-string v2, "suffixImage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_116

    goto :goto_117

    :cond_116
    const/4 v3, 0x0

    :goto_117
    iget-object v1, p0, Lbh/h;->c:Lxk/z;

    packed-switch v3, :pswitch_data_25e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_121
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Lbh/i;->q:LTe/Q;

    goto/16 :goto_1d

    :pswitch_12b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbh/i;->o:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_137
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbh/i;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_143
    iget-object v1, p0, Lbh/h;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/j0;

    iput-object v1, v0, Lbh/i;->e:LMe/j0;

    goto/16 :goto_1d

    :pswitch_14f
    iget-boolean v1, v0, Lbh/i;->k:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lbh/i;->k:Z

    goto/16 :goto_1d

    :pswitch_159
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbh/i;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_165
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_171
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbh/i;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_17d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbh/i;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_189
    iget-boolean v1, v0, Lbh/i;->i:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lbh/i;->i:Z

    goto/16 :goto_1d

    :pswitch_193
    iget-boolean v1, v0, Lbh/i;->m:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lbh/i;->m:Z

    goto/16 :goto_1d

    :pswitch_19d
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Lbh/i;->n:LTe/Q;

    goto/16 :goto_1d

    :pswitch_1a7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbh/i;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1b3
    iget-boolean v1, v0, Lbh/i;->j:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lbh/i;->j:Z

    goto/16 :goto_1d

    :pswitch_1bd
    iget-object v1, p0, Lbh/h;->b:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lbh/i;->f:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_1c9
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Lbh/i;->l:LTe/Q;

    goto/16 :goto_1d

    :pswitch_1d3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbh/i;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1df
    iget-object v1, p0, Lbh/h;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, Lbh/i;->p:LMe/r1;

    goto/16 :goto_1d

    :cond_1eb
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_20b

    iget-object p1, v0, Lbh/i;->b:Ljava/lang/String;

    if-eqz p1, :cond_203

    iget-object p1, v0, Lbh/i;->c:Ljava/lang/String;

    if-eqz p1, :cond_1fb

    return-object v0

    :cond_1fb
    new-instance p1, Ljava/io/IOException;

    const-string v0, "text cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_203
    new-instance p1, Ljava/io/IOException;

    const-string v0, "dateText cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_20b
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_214
    .sparse-switch
        -0x7d4b5376 -> :sswitch_10d
        -0x6f511c93 -> :sswitch_102
        -0x6e3d1ecd -> :sswitch_f7
        -0x5128dd4c -> :sswitch_ec
        -0x3c67f5ff -> :sswitch_e1
        -0x333c9dec -> :sswitch_d6
        -0x1ee90c6a -> :sswitch_cb
        -0x199624cf -> :sswitch_c0
        -0x192b5ae3 -> :sswitch_b2
        -0x8add339 -> :sswitch_a4
        0x36452d -> :sswitch_96
        0x368f3a -> :sswitch_88
        0xecf34d -> :sswitch_7a
        0x9d2bfd9 -> :sswitch_6c
        0x342d715e -> :sswitch_5e
        0x6adb21fb -> :sswitch_50
        0x6daaec0c -> :sswitch_42
        0x746d83ea -> :sswitch_34
    .end sparse-switch

    :pswitch_data_25e
    .packed-switch 0x0
        :pswitch_1df
        :pswitch_1d3
        :pswitch_1c9
        :pswitch_1bd
        :pswitch_1b3
        :pswitch_1a7
        :pswitch_19d
        :pswitch_193
        :pswitch_189
        :pswitch_17d
        :pswitch_171
        :pswitch_165
        :pswitch_159
        :pswitch_14f
        :pswitch_143
        :pswitch_137
        :pswitch_12b
        :pswitch_121
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbh/h;->read(LBk/a;)Lbh/i;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lbh/i;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_128

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "deliveryMessageType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->a:Ljava/lang/String;

    if-eqz v0, :cond_24

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_27

    :cond_24
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_27
    const-string v0, "dateText"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->b:Ljava/lang/String;

    if-eqz v0, :cond_120

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "text"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->c:Ljava/lang/String;

    if-eqz v0, :cond_118

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "subtext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->d:Ljava/lang/String;

    if-eqz v0, :cond_4c

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_4f

    :cond_4c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_4f
    const-string v0, "countdownTimerData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->e:LMe/j0;

    if-eqz v0, :cond_5e

    iget-object v2, p0, Lbh/h;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_61

    :cond_5e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_61
    const-string v0, "charge"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->f:Ljava/util/List;

    if-eqz v0, :cond_75

    iget-object v2, p0, Lbh/h;->b:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_78

    :cond_75
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_78
    const-string v0, "alternateText"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->g:Ljava/lang/String;

    if-eqz v0, :cond_85

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_88

    :cond_85
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_88
    const-string v0, "imageUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->h:Ljava/lang/String;

    if-eqz v0, :cond_95

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_98

    :cond_95
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_98
    const-string v0, "fasterDelivery"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lbh/i;->i:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "freeOption"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lbh/i;->j:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "installationDeliveryMessage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lbh/i;->k:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "plusIcon"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->l:LTe/Q;

    iget-object v2, p0, Lbh/h;->c:Lxk/z;

    if-eqz v0, :cond_c5

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_c8

    :cond_c5
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_c8
    const-string v0, "vipDelivery"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lbh/i;->m:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "vipDeliveryMessage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->n:LTe/Q;

    if-eqz v0, :cond_df

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_e2

    :cond_df
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_e2
    const-string v0, "expressDeliveryCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->o:Ljava/lang/String;

    if-eqz v0, :cond_ef

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_f2

    :cond_ef
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_f2
    const-string v0, "suffixImage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/i;->p:LMe/r1;

    if-eqz v0, :cond_101

    iget-object v1, p0, Lbh/h;->d:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_104

    :cond_101
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_104
    const-string v0, "slaTextFormattedValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lbh/i;->q:LTe/Q;

    if-eqz p2, :cond_111

    invoke-virtual {v2, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_114

    :cond_111
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_114
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_118
    new-instance p1, Ljava/io/IOException;

    const-string p2, "text cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_120
    new-instance p1, Ljava/io/IOException;

    const-string p2, "dateText cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_128
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lbh/i;

    invoke-virtual {p0, p1, p2}, Lbh/h;->write(LBk/c;Lbh/i;)V

    return-void
.end method
