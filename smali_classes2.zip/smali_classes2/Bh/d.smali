.class public final Lbh/d;
.super Lxk/z;
.source "ChildProductInfo$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lbh/e;",
        ">;"
    }
.end annotation


# static fields
.field public static final c:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lbh/e;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lad/d;",
            ">;"
        }
    .end annotation
.end field

.field private final b:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lbh/e;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lbh/d;->c:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 4

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Lad/c;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lbh/d;->a:Lxk/z;

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lbh/d;->b:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lbh/e;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lbh/e;

    invoke-direct {v0}, Lbh/e;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_54

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "childProducts"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_49

    const-string v2, "parentProductContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :cond_3e
    iget-object v1, p0, Lbh/d;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lad/d;

    iput-object v1, v0, Lbh/e;->b:Lad/d;

    goto :goto_1d

    :cond_49
    iget-object v1, p0, Lbh/d;->b:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lbh/e;->a:Ljava/util/List;

    goto :goto_1d

    :cond_54
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbh/d;->read(LBk/a;)Lbh/e;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lbh/e;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "childProducts"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbh/e;->a:Ljava/util/List;

    if-eqz v0, :cond_1d

    iget-object v1, p0, Lbh/d;->b:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_20

    :cond_1d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_20
    const-string v0, "parentProductContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lbh/e;->b:Lad/d;

    if-eqz p2, :cond_2f

    iget-object v0, p0, Lbh/d;->a:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_32

    :cond_2f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_32
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lbh/e;

    invoke-virtual {p0, p1, p2}, Lbh/d;->write(LBk/c;Lbh/e;)V

    return-void
.end method
