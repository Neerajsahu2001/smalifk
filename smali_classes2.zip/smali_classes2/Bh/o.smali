.class public final Lbh/o;
.super Ljava/lang/Object;
.source "ImportanceType.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
