.class public final Lbh/u;
.super Lxk/z;
.source "ProductPricingSummary$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;",
        ">;"
    }
.end annotation


# static fields
.field public static final d:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/Price;",
            ">;"
        }
    .end annotation
.end field

.field private final b:LJn/a$r;

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/partorder/PartPriceInfo;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lbh/u;->d:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Lbh/s;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lbh/u;->a:Lxk/z;

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Lbh/u;->b:LJn/a$r;

    sget-object v0, LYg/b;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lbh/u;->c:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    invoke-direct {v0}, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_d7

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_dc

    goto :goto_7f

    :sswitch_33
    const-string v2, "partPriceInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_7f

    :cond_3c
    const/4 v3, 0x6

    goto :goto_7f

    :sswitch_3e
    const-string v2, "totalDiscount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_7f

    :cond_47
    const/4 v3, 0x5

    goto :goto_7f

    :sswitch_49
    const-string v2, "mrp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_7f

    :cond_52
    const/4 v3, 0x4

    goto :goto_7f

    :sswitch_54
    const-string v2, "fsp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_7f

    :cond_5d
    const/4 v3, 0x3

    goto :goto_7f

    :sswitch_5f
    const-string v2, "prices"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto :goto_7f

    :cond_68
    const/4 v3, 0x2

    goto :goto_7f

    :sswitch_6a
    const-string v2, "minPrice"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_73

    goto :goto_7f

    :cond_73
    const/4 v3, 0x1

    goto :goto_7f

    :sswitch_75
    const-string v2, "finalPrice"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7e

    goto :goto_7f

    :cond_7e
    const/4 v3, 0x0

    :goto_7f
    iget-object v1, p0, Lbh/u;->a:Lxk/z;

    packed-switch v3, :pswitch_data_fa

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_88
    iget-object v1, p0, Lbh/u;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/partorder/PartPriceInfo;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->partPriceInfo:Lcom/flipkart/rome/datatypes/response/partorder/PartPriceInfo;

    goto :goto_1d

    :pswitch_93
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->totalDiscount:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_9f
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->mrp:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_ab
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->fsp:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_b7
    iget-object v1, p0, Lbh/u;->b:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->prices:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_c3
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/Price;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->minPrice:Lcom/flipkart/rome/datatypes/response/product/Price;

    goto/16 :goto_1d

    :pswitch_cd
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/Price;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->finalPrice:Lcom/flipkart/rome/datatypes/response/product/Price;

    goto/16 :goto_1d

    :cond_d7
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_dc
    .sparse-switch
        -0x6fc5868d -> :sswitch_75
        -0x525fc1e9 -> :sswitch_6a
        -0x3a6987b6 -> :sswitch_5f
        0x18d43 -> :sswitch_54
        0x1a76b -> :sswitch_49
        0x11dc30a5 -> :sswitch_3e
        0x3b7a3ae4 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_fa
    .packed-switch 0x0
        :pswitch_cd
        :pswitch_c3
        :pswitch_b7
        :pswitch_ab
        :pswitch_9f
        :pswitch_93
        :pswitch_88
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbh/u;->read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "totalDiscount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->totalDiscount:Ljava/lang/Integer;

    if-eqz v0, :cond_18

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "mrp"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->mrp:Ljava/lang/Integer;

    if-eqz v0, :cond_2a

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "fsp"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->fsp:Ljava/lang/Integer;

    if-eqz v0, :cond_3c

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "minPrice"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->minPrice:Lcom/flipkart/rome/datatypes/response/product/Price;

    iget-object v1, p0, Lbh/u;->a:Lxk/z;

    if-eqz v0, :cond_4e

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_51

    :cond_4e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_51
    const-string v0, "finalPrice"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->finalPrice:Lcom/flipkart/rome/datatypes/response/product/Price;

    if-eqz v0, :cond_5e

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_61

    :cond_5e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_61
    const-string v0, "prices"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->prices:Ljava/util/List;

    if-eqz v0, :cond_75

    iget-object v1, p0, Lbh/u;->b:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_78

    :cond_75
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_78
    const-string v0, "partPriceInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;->partPriceInfo:Lcom/flipkart/rome/datatypes/response/partorder/PartPriceInfo;

    if-eqz p2, :cond_87

    iget-object v0, p0, Lbh/u;->c:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_8a

    :cond_87
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_8a
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    invoke-virtual {p0, p1, p2}, Lbh/u;->write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;)V

    return-void
.end method
