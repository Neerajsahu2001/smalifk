.class public final Lbh/r;
.super Lxk/z;
.source "ListingPreservationState$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lbh/r;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;

    invoke-direct {v0}, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_50

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "listingUnavailable"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_47

    const-string v2, "listingNotServiceable"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :cond_3e
    iget-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;->listingNotServiceable:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;->listingNotServiceable:Z

    goto :goto_1d

    :cond_47
    iget-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;->listingUnavailable:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;->listingUnavailable:Z

    goto :goto_1d

    :cond_50
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbh/r;->read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "listingUnavailable"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;->listingUnavailable:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "listingNotServiceable"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;->listingNotServiceable:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;

    invoke-virtual {p0, p1, p2}, Lbh/r;->write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/ListingPreservationState;)V

    return-void
.end method
