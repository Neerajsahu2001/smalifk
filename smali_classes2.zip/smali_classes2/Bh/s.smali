.class public final Lbh/s;
.super Lxk/z;
.source "Price$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcom/flipkart/rome/datatypes/response/product/Price;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lcom/flipkart/rome/datatypes/response/product/Price;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/common/leaf/value/TextStyle;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcom/flipkart/rome/datatypes/response/product/Price;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lbh/s;->b:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 3

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, LMe/E3;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lbh/s;->a:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/Price;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcom/flipkart/rome/datatypes/response/product/Price;

    invoke-direct {v0}, Lcom/flipkart/rome/datatypes/response/product/Price;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_139

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_162

    goto/16 :goto_b5

    :sswitch_34
    const-string v2, "currency"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_b5

    :cond_3e
    const/16 v3, 0xa

    goto/16 :goto_b5

    :sswitch_42
    const-string v2, "discount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_b5

    :cond_4c
    const/16 v3, 0x9

    goto/16 :goto_b5

    :sswitch_50
    const-string v2, "decimalValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_b5

    :cond_5a
    const/16 v3, 0x8

    goto/16 :goto_b5

    :sswitch_5e
    const-string v2, "value"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_67

    goto :goto_b5

    :cond_67
    const/4 v3, 0x7

    goto :goto_b5

    :sswitch_69
    const-string v2, "name"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_72

    goto :goto_b5

    :cond_72
    const/4 v3, 0x6

    goto :goto_b5

    :sswitch_74
    const-string v2, "strikeOff"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7d

    goto :goto_b5

    :cond_7d
    const/4 v3, 0x5

    goto :goto_b5

    :sswitch_7f
    const-string v2, "downpaymentRate"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_88

    goto :goto_b5

    :cond_88
    const/4 v3, 0x4

    goto :goto_b5

    :sswitch_8a
    const-string v2, "additionalText"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_93

    goto :goto_b5

    :cond_93
    const/4 v3, 0x3

    goto :goto_b5

    :sswitch_95
    const-string v2, "textStyle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9e

    goto :goto_b5

    :cond_9e
    const/4 v3, 0x2

    goto :goto_b5

    :sswitch_a0
    const-string v2, "downpaymentRequired"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a9

    goto :goto_b5

    :cond_a9
    const/4 v3, 0x1

    goto :goto_b5

    :sswitch_ab
    const-string v2, "priceType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b4

    goto :goto_b5

    :cond_b4
    const/4 v3, 0x0

    :goto_b5
    packed-switch v3, :pswitch_data_190

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_bd
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->currency:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_c9
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->discount:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_d5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->decimalValue:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_e1
    iget v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->value:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->value:I

    goto/16 :goto_1d

    :pswitch_eb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->name:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_f7
    iget-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->strikeOff:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->strikeOff:Z

    goto/16 :goto_1d

    :pswitch_101
    iget-wide v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->downpaymentRate:D

    invoke-static {p1, v1, v2}, LJn/a$x;->a(LBk/a;D)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->downpaymentRate:D

    goto/16 :goto_1d

    :pswitch_10b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->additionalText:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_117
    iget-object v1, p0, Lbh/s;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/common/leaf/value/TextStyle;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->textStyle:Lcom/flipkart/rome/datatypes/response/common/leaf/value/TextStyle;

    goto/16 :goto_1d

    :pswitch_123
    iget-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->downpaymentRequired:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->downpaymentRequired:Z

    goto/16 :goto_1d

    :pswitch_12d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->priceType:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_139
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->name:Ljava/lang/String;

    if-eqz p1, :cond_159

    iget-object p1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->decimalValue:Ljava/lang/String;

    if-eqz p1, :cond_151

    iget-object p1, v0, Lcom/flipkart/rome/datatypes/response/product/Price;->currency:Ljava/lang/String;

    if-eqz p1, :cond_149

    return-object v0

    :cond_149
    new-instance p1, Ljava/io/IOException;

    const-string v0, "currency cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_151
    new-instance p1, Ljava/io/IOException;

    const-string v0, "decimalValue cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_159
    new-instance p1, Ljava/io/IOException;

    const-string v0, "name cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_162
    .sparse-switch
        -0x7eb417dd -> :sswitch_ab
        -0x49bce11d -> :sswitch_a0
        -0x3e80e37c -> :sswitch_95
        -0x3a0dba0c -> :sswitch_8a
        -0x25b47ddc -> :sswitch_7f
        -0xb739fa3 -> :sswitch_74
        0x337a8b -> :sswitch_69
        0x6ac9171 -> :sswitch_5e
        0xb68f8a0 -> :sswitch_50
        0x10487541 -> :sswitch_42
        0x224bf011 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_190
    .packed-switch 0x0
        :pswitch_12d
        :pswitch_123
        :pswitch_117
        :pswitch_10b
        :pswitch_101
        :pswitch_f7
        :pswitch_eb
        :pswitch_e1
        :pswitch_d5
        :pswitch_c9
        :pswitch_bd
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbh/s;->read(LBk/a;)Lcom/flipkart/rome/datatypes/response/product/Price;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/Price;)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "name"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->name:Ljava/lang/String;

    if-eqz v0, :cond_b0

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "value"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->value:I

    int-to-long v2, v0

    invoke-virtual {p1, v2, v3}, LBk/c;->value(J)LBk/c;

    const-string v0, "decimalValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->decimalValue:Ljava/lang/String;

    if-eqz v0, :cond_a8

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "additionalText"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->additionalText:Ljava/lang/String;

    if-eqz v0, :cond_3b

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3e

    :cond_3b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3e
    const-string v0, "discount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->discount:Ljava/lang/Integer;

    if-eqz v0, :cond_4d

    sget-object v2, LJn/a;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_50

    :cond_4d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_50
    const-string v0, "strikeOff"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->strikeOff:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "currency"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->currency:Ljava/lang/String;

    if-eqz v0, :cond_a0

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "priceType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->priceType:Ljava/lang/String;

    if-eqz v0, :cond_73

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_76

    :cond_73
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_76
    const-string v0, "downpaymentRequired"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->downpaymentRequired:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "downpaymentRate"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->downpaymentRate:D

    invoke-virtual {p1, v0, v1}, LBk/c;->value(D)LBk/c;

    const-string v0, "textStyle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcom/flipkart/rome/datatypes/response/product/Price;->textStyle:Lcom/flipkart/rome/datatypes/response/common/leaf/value/TextStyle;

    if-eqz p2, :cond_99

    iget-object v0, p0, Lbh/s;->a:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_9c

    :cond_99
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_9c
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_a0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "currency cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_a8
    new-instance p1, Ljava/io/IOException;

    const-string p2, "decimalValue cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_b0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "name cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcom/flipkart/rome/datatypes/response/product/Price;

    invoke-virtual {p0, p1, p2}, Lbh/s;->write(LBk/c;Lcom/flipkart/rome/datatypes/response/product/Price;)V

    return-void
.end method
