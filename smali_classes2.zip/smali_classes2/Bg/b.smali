.class public final Lbg/b;
.super Lcg/d;
.source "ToastMessageResponse.java"


# instance fields
.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcg/d;-><init>()V

    return-void
.end method
