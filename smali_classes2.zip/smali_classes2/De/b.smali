.class public final Lde/b;
.super Ljava/lang/Object;
.source "AbbResponse.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:LTe/y0;

.field public b:Lde/h;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
