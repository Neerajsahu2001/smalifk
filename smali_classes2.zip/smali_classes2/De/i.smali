.class public final Lde/i;
.super Lxk/z;
.source "TenureRate$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lde/j;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lde/j;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lde/j;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lde/i;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lde/j;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lde/j;

    invoke-direct {v0}, Lde/j;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_52

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "bumpedUp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_49

    const-string v2, "value"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :cond_3e
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lde/j;->a:Ljava/lang/String;

    goto :goto_1d

    :cond_49
    iget-boolean v1, v0, Lde/j;->b:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lde/j;->b:Z

    goto :goto_1d

    :cond_52
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Lde/j;->a:Ljava/lang/String;

    if-eqz p1, :cond_5a

    return-object v0

    :cond_5a
    new-instance p1, Ljava/io/IOException;

    const-string v0, "value cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lde/i;->read(LBk/a;)Lde/j;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lde/j;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "value"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lde/j;->a:Ljava/lang/String;

    if-eqz v0, :cond_25

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "bumpedUp"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Lde/j;->b:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_25
    new-instance p1, Ljava/io/IOException;

    const-string p2, "value cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lde/j;

    invoke-virtual {p0, p1, p2}, Lde/i;->write(LBk/c;Lde/j;)V

    return-void
.end method
