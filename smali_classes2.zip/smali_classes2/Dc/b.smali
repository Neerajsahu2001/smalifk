.class public interface abstract LDc/b;
.super Ljava/lang/Object;
.source "ChunkLoaderCallbacks.kt"


# virtual methods
.method public abstract chunkLoaded(Ljava/lang/String;I)V
.end method
