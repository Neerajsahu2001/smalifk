.class public interface abstract LDc/d;
.super Ljava/lang/Object;
.source "VMChunkLoaderCallback.kt"


# virtual methods
.method public abstract allChunksLoadedInVM()V
.end method

.method public abstract chunkLoadError(Ljava/lang/Exception;)V
.end method
