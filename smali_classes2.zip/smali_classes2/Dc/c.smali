.class public interface abstract LDc/c;
.super Ljava/lang/Object;
.source "ChunkProvider.kt"

# interfaces
.implements LDc/b;


# virtual methods
.method public abstract synthetic chunkLoaded(Ljava/lang/String;I)V
.end method

.method public abstract dependentOnChunks()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getDownloader()LDc/a;
.end method
