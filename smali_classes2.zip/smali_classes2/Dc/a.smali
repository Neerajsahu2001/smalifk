.class public interface abstract LDc/a;
.super Ljava/lang/Object;
.source "ChunkDownloader.kt"

# interfaces
.implements LE8/a;


# virtual methods
.method public abstract synthetic downloadData(Ljava/lang/String;LXn/d;)Ljava/lang/Object;
.end method

.method public abstract getChunkServerConfig(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;LXn/d;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            "LXn/d<",
            "-",
            "Ljava/util/List<",
            "LEc/a;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
