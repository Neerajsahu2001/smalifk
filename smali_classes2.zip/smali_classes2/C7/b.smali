.class public final Lc7/b;
.super Ljava/lang/Object;
.source "FkVideoPlayerListener.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc7/b$a;
    }
.end annotation


# static fields
.field public static final d:Lc7/b$a;

.field private static final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lcom/facebook/react/bridge/ReactContext;

.field private b:Lcom/facebook/react/uimanager/events/RCTEventEmitter;

.field private c:Lcom/facebook/react/bridge/ReadableMap;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    new-instance v0, Lc7/b$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc7/b$a;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, Lc7/b;->d:Lc7/b$a;

    const-string v7, "onPlayerMuteUnmuteEvent"

    const-string v8, "onPlayStateEvent"

    const-string v2, "onPlayProgress"

    const-string v3, "onPlayerStateChanged"

    const-string v4, "onPlayerError"

    const-string v5, "onMediaClick"

    const-string v6, "onRenderFirstFrame"

    filled-new-array/range {v2 .. v8}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lc7/b;->e:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Lcom/facebook/react/bridge/ReactContext;)V
    .registers 3

    const-string v0, "reactContext"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc7/b;->a:Lcom/facebook/react/bridge/ReactContext;

    return-void
.end method

.method private final a(ILjava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V
    .registers 6

    invoke-direct {p0, p2}, Lc7/b;->b(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1d

    iget-object v0, p0, Lc7/b;->b:Lcom/facebook/react/uimanager/events/RCTEventEmitter;

    if-nez v0, :cond_16

    iget-object v0, p0, Lc7/b;->a:Lcom/facebook/react/bridge/ReactContext;

    const-class v1, Lcom/facebook/react/uimanager/events/RCTEventEmitter;

    invoke-virtual {v0, v1}, Lcom/facebook/react/bridge/ReactContext;->getJSModule(Ljava/lang/Class;)Lcom/facebook/react/bridge/JavaScriptModule;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/uimanager/events/RCTEventEmitter;

    iput-object v0, p0, Lc7/b;->b:Lcom/facebook/react/uimanager/events/RCTEventEmitter;

    :cond_16
    iget-object v0, p0, Lc7/b;->b:Lcom/facebook/react/uimanager/events/RCTEventEmitter;

    if-eqz v0, :cond_1d

    invoke-interface {v0, p1, p2, p3}, Lcom/facebook/react/uimanager/events/RCTEventEmitter;->receiveEvent(ILjava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    :cond_1d
    return-void
.end method

.method public static final synthetic access$getEvents$cp()Ljava/util/List;
    .registers 1

    sget-object v0, Lc7/b;->e:Ljava/util/List;

    return-object v0
.end method

.method private final b(Ljava/lang/String;)Z
    .registers 4

    iget-object v0, p0, Lc7/b;->c:Lcom/facebook/react/bridge/ReadableMap;

    if-eqz v0, :cond_12

    invoke-interface {v0, p1}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_12

    invoke-interface {v0, p1}, Lcom/facebook/react/bridge/ReadableMap;->getBoolean(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_12

    const/4 p1, 0x1

    return p1

    :cond_12
    const/4 p1, 0x0

    return p1
.end method


# virtual methods
.method public final handleEventToRN(Li9/a;I)V
    .registers 10

    const-string v0, "event"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Li9/b$b;->a:Li9/b$b;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1b

    const-string p1, "onRenderFirstFrame"

    invoke-direct {p0, p1}, Lc7/b;->b(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_f6

    invoke-direct {p0, p2, p1, v1}, Lc7/b;->a(ILjava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V

    goto/16 :goto_f6

    :cond_1b
    instance-of v0, p1, Li9/b$c;

    if-eqz v0, :cond_51

    check-cast p1, Li9/b$c;

    const-string v0, "onPlayProgress"

    invoke-direct {p0, v0}, Lc7/b;->b(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f6

    new-instance v1, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-direct {v1}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    invoke-virtual {p1}, Li9/b$c;->getDuration()J

    move-result-wide v2

    long-to-double v2, v2

    const-string v4, "videoTime"

    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    invoke-virtual {p1}, Li9/b$c;->getCurrentPosition()J

    move-result-wide v2

    long-to-double v2, v2

    const-string v4, "playedTime"

    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    invoke-virtual {p1}, Li9/b$c;->getBufferedPosition()J

    move-result-wide v2

    long-to-double v2, v2

    const-string p1, "bufferedTime"

    invoke-interface {v1, p1, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    invoke-direct {p0, p2, v0, v1}, Lc7/b;->a(ILjava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V

    goto/16 :goto_f6

    :cond_51
    instance-of v0, p1, Li9/b$d;

    if-eqz v0, :cond_56

    goto :goto_69

    :cond_56
    instance-of v0, p1, Li9/b$e;

    if-eqz v0, :cond_5b

    goto :goto_69

    :cond_5b
    instance-of v0, p1, Li9/b$f;

    if-eqz v0, :cond_60

    goto :goto_69

    :cond_60
    instance-of v0, p1, Li9/b$g;

    if-eqz v0, :cond_65

    goto :goto_69

    :cond_65
    instance-of v0, p1, Li9/b$h;

    if-eqz v0, :cond_af

    :goto_69
    const-string v0, "onPlayerStateChanged"

    invoke-direct {p0, v0}, Lc7/b;->b(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_f6

    instance-of v2, p1, Li9/b;

    if-eqz v2, :cond_f6

    new-instance v2, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-direct {v2}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    instance-of v3, p1, Li9/b$g;

    if-eqz v3, :cond_81

    move-object v1, p1

    check-cast v1, Li9/b$g;

    :cond_81
    if-eqz v1, :cond_88

    invoke-virtual {v1}, Li9/b$g;->isPlayWhenReady()Z

    move-result v1

    goto :goto_89

    :cond_88
    const/4 v1, 0x0

    :goto_89
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    new-instance v5, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-direct {v5}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    const-string v6, "t"

    long-to-double v3, v3

    invoke-interface {v5, v6, v3, v4}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    const-string v3, "et"

    invoke-interface {v2, v3, v5}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    const-string v3, "isPlaying"

    invoke-interface {v2, v3, v1}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    const-string v1, "playbackState"

    invoke-static {p1}, LA9/d;->getPlayBackState(Li9/a;)I

    move-result p1

    invoke-interface {v2, v1, p1}, Lcom/facebook/react/bridge/WritableMap;->putInt(Ljava/lang/String;I)V

    invoke-direct {p0, p2, v0, v2}, Lc7/b;->a(ILjava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V

    goto :goto_f6

    :cond_af
    instance-of v0, p1, Li9/b$a;

    if-eqz v0, :cond_d3

    check-cast p1, Li9/b$a;

    const-string v0, "onPlayerError"

    invoke-direct {p0, v0}, Lc7/b;->b(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f6

    new-instance v1, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-direct {v1}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    invoke-virtual {p1}, Li9/b$a;->getError()Ljava/lang/Exception;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string v2, "msg"

    invoke-interface {v1, v2, p1}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, p2, v0, v1}, Lc7/b;->a(ILjava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V

    goto :goto_f6

    :cond_d3
    instance-of v0, p1, Li9/c;

    if-eqz v0, :cond_f1

    check-cast p1, Li9/c;

    const-string v0, "onPlayerMuteUnmuteEvent"

    invoke-direct {p0, v0}, Lc7/b;->b(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f6

    new-instance v1, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-direct {v1}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    instance-of p1, p1, Li9/c$a;

    const-string v2, "isSelected"

    invoke-interface {v1, v2, p1}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    invoke-direct {p0, p2, v0, v1}, Lc7/b;->a(ILjava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V

    goto :goto_f6

    :cond_f1
    const-string p1, "Unhandled video event sent to RN"

    invoke-static {p1}, Lpa/a;->warn(Ljava/lang/String;)V

    :cond_f6
    :goto_f6
    return-void
.end method

.method public final setEnabledListeners(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 2

    iput-object p1, p0, Lc7/b;->c:Lcom/facebook/react/bridge/ReadableMap;

    return-void
.end method
