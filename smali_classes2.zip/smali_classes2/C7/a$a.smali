.class public interface abstract LC7/a$a;
.super Ljava/lang/Object;
.source "UltraTrackingAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LC7/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract getContextManager()Lcom/flipkart/android/datagovernance/ContextManager;
.end method
