.class public final Lc7/a;
.super Ljava/lang/Object;
.source "FkVideoCommandHandler.kt"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private a:Ljava/util/LinkedHashMap;

.field private b:Lcom/flipkart/android/reactmultiwidget/fragments/a;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lc7/a;->a:Ljava/util/LinkedHashMap;

    return-void
.end method

.method private static a(Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;Lorg/json/JSONObject;Lg0/u0;)V
    .registers 15

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    instance-of v0, p0, Lcom/facebook/react/uimanager/ThemedReactContext;

    const/4 v1, 0x0

    if-eqz v0, :cond_c

    check-cast p0, Lcom/facebook/react/uimanager/ThemedReactContext;

    goto :goto_d

    :cond_c
    move-object p0, v1

    :goto_d
    if-eqz p0, :cond_14

    invoke-virtual {p0}, Lcom/facebook/react/uimanager/ThemedReactContext;->getCurrentActivity()Landroid/app/Activity;

    move-result-object p0

    goto :goto_15

    :cond_14
    move-object p0, v1

    :goto_15
    instance-of v0, p0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    if-eqz v0, :cond_1c

    check-cast p0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    goto :goto_1d

    :cond_1c
    move-object p0, v1

    :goto_1d
    if-eqz p0, :cond_27

    iget-object p0, p0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->q:Lcom/flipkart/android/datagovernance/GlobalContextInfo;

    if-eqz p0, :cond_27

    invoke-virtual {p0}, Lcom/flipkart/android/datagovernance/GlobalContextInfo;->getCurrentNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v1

    :cond_27
    if-eqz v1, :cond_184

    iget p0, p2, Lg0/u0;->a:I

    iget v0, p2, Lg0/u0;->e:I

    sub-int/2addr p0, v0

    iget v2, p2, Lg0/u0;->f:I

    sub-int/2addr v2, p0

    const/4 p0, 0x0

    if-nez v0, :cond_36

    const/4 v2, 0x0

    goto :goto_39

    :cond_36
    int-to-float v2, v2

    int-to-float v3, v0

    div-float/2addr v2, v3

    :goto_39
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    const-string v3, "abrr"

    invoke-virtual {p1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p2}, Lg0/u0;->a()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    const-string v3, "dfr"

    invoke-virtual {p1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    if-nez v0, :cond_53

    const/4 v2, 0x0

    goto :goto_58

    :cond_53
    iget v2, p2, Lg0/u0;->I:I

    int-to-float v2, v2

    int-to-float v3, v0

    div-float/2addr v2, v3

    :goto_58
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    const-string v3, "fer"

    invoke-virtual {p1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-wide/16 v2, 0x0

    const/4 v4, -0x1

    iget-wide v5, p2, Lg0/u0;->w:J

    cmp-long v7, v5, v2

    if-nez v7, :cond_6c

    const/4 v5, -0x1

    goto :goto_70

    :cond_6c
    iget-wide v7, p2, Lg0/u0;->x:J

    div-long/2addr v7, v5

    long-to-int v5, v7

    :goto_70
    const-string v6, "mafb"

    invoke-virtual {p1, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    iget-wide v5, p2, Lg0/u0;->E:J

    cmp-long v7, v5, v2

    if-nez v7, :cond_7d

    const/4 v5, -0x1

    goto :goto_85

    :cond_7d
    iget-wide v7, p2, Lg0/u0;->F:J

    const-wide/16 v9, 0x1f40

    mul-long v7, v7, v9

    div-long/2addr v7, v5

    long-to-int v5, v7

    :goto_85
    const-string v6, "mb"

    invoke-virtual {p1, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    iget v5, p2, Lg0/u0;->C:I

    if-nez v5, :cond_90

    const/4 v5, -0x1

    goto :goto_95

    :cond_90
    iget-wide v6, p2, Lg0/u0;->D:J

    int-to-long v8, v5

    div-long/2addr v6, v8

    long-to-int v5, v6

    :goto_95
    const-string v6, "miafb"

    invoke-virtual {p1, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    iget v5, p2, Lg0/u0;->z:I

    if-nez v5, :cond_a0

    const/4 v5, -0x1

    goto :goto_a5

    :cond_a0
    iget-wide v6, p2, Lg0/u0;->B:J

    int-to-long v8, v5

    div-long/2addr v6, v8

    long-to-int v5, v6

    :goto_a5
    const-string v6, "mivfb"

    invoke-virtual {p1, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-wide v5, -0x7fffffffffffffffL    # -4.9E-324

    iget v7, p2, Lg0/u0;->j:I

    if-nez v7, :cond_b5

    move-wide v8, v5

    goto :goto_b9

    :cond_b5
    iget-wide v8, p2, Lg0/u0;->i:J

    int-to-long v10, v7

    div-long/2addr v8, v10

    :goto_b9
    const-string v7, "mjtm"

    invoke-virtual {p1, v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    if-nez v0, :cond_c1

    goto :goto_c6

    :cond_c1
    iget p0, p2, Lg0/u0;->n:I

    int-to-float p0, p0

    int-to-float v7, v0

    div-float/2addr p0, v7

    :goto_c6
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const-string v7, "mrc"

    invoke-virtual {p1, v7, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    if-nez v0, :cond_d3

    move-wide v7, v5

    goto :goto_d9

    :cond_d3
    invoke-virtual {p2}, Lg0/u0;->f()J

    move-result-wide v7

    int-to-long v9, v0

    div-long/2addr v7, v9

    :goto_d9
    const-string p0, "mrtm"

    invoke-virtual {p1, p0, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string p0, "msrtm"

    invoke-virtual {p2}, Lg0/u0;->b()J

    move-result-wide v7

    invoke-virtual {p1, p0, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    iget-wide v7, p2, Lg0/u0;->u:J

    cmp-long p0, v7, v2

    if-nez p0, :cond_ee

    goto :goto_f2

    :cond_ee
    iget-wide v2, p2, Lg0/u0;->v:J

    div-long/2addr v2, v7

    long-to-int v4, v2

    :goto_f2
    const-string p0, "mvfb"

    invoke-virtual {p1, p0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    if-nez v0, :cond_fa

    goto :goto_101

    :cond_fa
    invoke-virtual {p2}, Lg0/u0;->g()J

    move-result-wide v2

    int-to-long v4, v0

    div-long v5, v2, v4

    :goto_101
    const-string p0, "mwtm"

    invoke-virtual {p1, p0, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    invoke-virtual {p2}, Lg0/u0;->c()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const-string v0, "rtr"

    invoke-virtual {p1, v0, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p0, "tjtm"

    invoke-virtual {p2}, Lg0/u0;->d()J

    move-result-wide v2

    invoke-virtual {p1, p0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string p0, "tptm"

    invoke-virtual {p2}, Lg0/u0;->e()J

    move-result-wide v2

    invoke-virtual {p1, p0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string p0, "trtm"

    invoke-virtual {p2}, Lg0/u0;->f()J

    move-result-wide v2

    invoke-virtual {p1, p0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string p0, "twtm"

    invoke-virtual {p2}, Lg0/u0;->g()J

    move-result-wide v2

    invoke-virtual {p1, p0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-object p0, p2, Lg0/u0;->b:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 p2, 0x0

    :goto_142
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_15a

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lg0/u0$c;

    iget-object v4, v0, Lg0/u0$c;->a:Lg0/b$a;

    iget-wide v4, v4, Lg0/b$a;->a:J

    cmp-long v6, v4, v2

    if-lez v6, :cond_157

    goto :goto_15a

    :cond_157
    iget p2, v0, Lg0/u0$c;->b:I

    goto :goto_142

    :cond_15a
    :goto_15a
    const-string p0, "pbs"

    invoke-virtual {p1, p0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    invoke-static {}, Lcom/flipkart/android/utils/f1;->getTimestampForDG()J

    move-result-wide v2

    const-string p0, "t"

    invoke-virtual {p1, p0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    invoke-static {p1}, Lcom/newrelic/agent/android/instrumentation/JSONObjectInstrumentation;->toString(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "rnVideoData.toString()"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object p1

    invoke-virtual {p1, p0}, Lcom/flipkart/android/gson/Serializer;->deserializeRNDGEvent(Ljava/lang/String;)LO6/j;

    move-result-object p0

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object p1

    invoke-virtual {p1, v1, p0}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEvent(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    :cond_184
    return-void
.end method


# virtual methods
.method public final getCommandsMap()Ljava/util/Map;
    .registers 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/16 v0, 0x8

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    move-object/from16 v7, p0

    iget-object v8, v7, Lc7/a;->a:Ljava/util/LinkedHashMap;

    invoke-interface {v8}, Ljava/util/Map;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_d6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v10, LUn/j;

    const-string v11, "PLAY"

    invoke-direct {v10, v11, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v11, LUn/j;

    const-string v12, "PAUSE"

    invoke-direct {v11, v12, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v12, LUn/j;

    const-string v13, "MUTE"

    invoke-direct {v12, v13, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v13, LUn/j;

    const-string v14, "UN_MUTE"

    invoke-direct {v13, v14, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v14, LUn/j;

    const-string v15, "SEEK_TO"

    invoke-direct {v14, v15, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v15, LUn/j;

    const-string v1, "VOLUME"

    invoke-direct {v15, v1, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    new-instance v9, LUn/j;

    const-string v0, "GET_CURRENT_STATUS"

    invoke-direct {v9, v0, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0xb

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    new-instance v1, LUn/j;

    const-string v2, "CHANGE_SOURCE"

    invoke-direct {v1, v2, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0xd

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    new-instance v2, LUn/j;

    const-string v3, "INGEST_EPPSE"

    invoke-direct {v2, v3, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0xe

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    new-instance v3, LUn/j;

    const-string v4, "SET_PLAYBACK_STATS_IN_PERSISTENCE"

    invoke-direct {v3, v4, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0xa

    new-array v0, v0, [LUn/j;

    const/4 v4, 0x0

    aput-object v10, v0, v4

    aput-object v11, v0, v6

    aput-object v12, v0, v5

    const/4 v4, 0x3

    aput-object v13, v0, v4

    const/4 v4, 0x4

    aput-object v14, v0, v4

    const/4 v4, 0x5

    aput-object v15, v0, v4

    const/4 v4, 0x6

    aput-object v9, v0, v4

    const/4 v4, 0x7

    aput-object v1, v0, v4

    const/16 v1, 0x8

    aput-object v2, v0, v1

    const/16 v1, 0x9

    aput-object v3, v0, v1

    invoke-static {v0}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_b2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_d6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LUn/j;

    invoke-virtual {v1}, LUn/j;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1}, LUn/j;->b()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v8, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_b2

    :cond_d6
    return-object v8
.end method

.method public final handleCommand(Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;ILcom/facebook/react/bridge/ReadableArray;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;I",
            "Lcom/facebook/react/bridge/ReadableArray;",
            ")V"
        }
    .end annotation

    const-string v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eq p2, v0, :cond_93

    const/4 v0, 0x2

    if-eq p2, v0, :cond_8f

    const/4 v0, 0x3

    if-eq p2, v0, :cond_8b

    const/4 v0, 0x4

    if-eq p2, v0, :cond_87

    const/4 v0, 0x5

    const/4 v2, 0x0

    if-eq p2, v0, :cond_62

    const/4 v0, 0x7

    if-eq p2, v0, :cond_3d

    const/16 v0, 0xd

    if-eq p2, v0, :cond_1f

    goto/16 :goto_b1

    :cond_1f
    if-eqz p3, :cond_b1

    invoke-interface {p3, v2}, Lcom/facebook/react/bridge/ReadableArray;->getString(I)Ljava/lang/String;

    move-result-object p2

    if-eqz p2, :cond_b1

    invoke-virtual {p1}, Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;->getPlaybackStats()Lg0/u0;

    move-result-object p3

    if-eqz p3, :cond_b1

    :try_start_2d
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {p1, v0, p3}, Lc7/a;->a(Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;Lorg/json/JSONObject;Lg0/u0;)V
    :try_end_35
    .catch Lorg/json/JSONException; {:try_start_2d .. :try_end_35} :catch_37

    goto/16 :goto_b1

    :catch_37
    move-exception p1

    invoke-static {p1}, LO7/c;->logException(Ljava/lang/Throwable;)V

    goto/16 :goto_b1

    :cond_3d
    sget-object p2, Lcom/facebook/react/bridge/ReadableType;->Number:Lcom/facebook/react/bridge/ReadableType;

    if-eqz p3, :cond_b1

    invoke-interface {p3}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    move-result v0

    if-lez v0, :cond_b1

    invoke-interface {p3, v2}, Lcom/facebook/react/bridge/ReadableArray;->getType(I)Lcom/facebook/react/bridge/ReadableType;

    move-result-object v0

    if-ne p2, v0, :cond_b1

    if-eqz p3, :cond_57

    invoke-interface {p3, v2}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    move-result-wide p2

    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    :cond_57
    if-eqz v1, :cond_b1

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide p2

    double-to-float p2, p2

    invoke-virtual {p1, p2}, Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;->setVolume(F)V

    goto :goto_b1

    :cond_62
    sget-object p2, Lcom/facebook/react/bridge/ReadableType;->Number:Lcom/facebook/react/bridge/ReadableType;

    if-eqz p3, :cond_b1

    invoke-interface {p3}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    move-result v0

    if-lez v0, :cond_b1

    invoke-interface {p3, v2}, Lcom/facebook/react/bridge/ReadableArray;->getType(I)Lcom/facebook/react/bridge/ReadableType;

    move-result-object v0

    if-ne p2, v0, :cond_b1

    if-eqz p3, :cond_7c

    invoke-interface {p3, v2}, Lcom/facebook/react/bridge/ReadableArray;->getInt(I)I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    :cond_7c
    if-eqz v1, :cond_b1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result p2

    int-to-long p2, p2

    invoke-virtual {p1, p2, p3}, Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;->seekTo(J)V

    goto :goto_b1

    :cond_87
    invoke-virtual {p1}, Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;->unMute()V

    goto :goto_b1

    :cond_8b
    invoke-virtual {p1}, Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;->mute()V

    goto :goto_b1

    :cond_8f
    invoke-virtual {p1}, Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;->pause()V

    goto :goto_b1

    :cond_93
    iget-object p2, p0, Lc7/a;->b:Lcom/flipkart/android/reactmultiwidget/fragments/a;

    if-eqz p2, :cond_a6

    invoke-interface {p2}, Lcom/flipkart/android/reactmultiwidget/fragments/a;->isScrolling()Z

    move-result p2

    if-ne p2, v0, :cond_a6

    iget-object p2, p0, Lc7/a;->b:Lcom/flipkart/android/reactmultiwidget/fragments/a;

    if-nez p2, :cond_a2

    goto :goto_b1

    :cond_a2
    invoke-interface {p2, p1}, Lcom/flipkart/android/reactmultiwidget/fragments/a;->setPendingVideoRef(Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;)V

    goto :goto_b1

    :cond_a6
    iget-object p2, p0, Lc7/a;->b:Lcom/flipkart/android/reactmultiwidget/fragments/a;

    if-nez p2, :cond_ab

    goto :goto_ae

    :cond_ab
    invoke-interface {p2, v1}, Lcom/flipkart/android/reactmultiwidget/fragments/a;->setPendingVideoRef(Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;)V

    :goto_ae
    invoke-virtual {p1}, Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;->play()V

    :cond_b1
    :goto_b1
    return-void
.end method

.method public final handleCommand(Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Ljava/lang/String;",
            "Lcom/facebook/react/bridge/ReadableArray;",
            ")V"
        }
    .end annotation

    const-string v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "commandName"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lc7/a;->a:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    if-eqz p2, :cond_1b

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-virtual {p0, p1, p2, p3}, Lc7/a;->handleCommand(Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;ILcom/facebook/react/bridge/ReadableArray;)V

    :cond_1b
    return-void
.end method

.method public final setListener(Lcom/flipkart/android/reactmultiwidget/fragments/a;)V
    .registers 2

    iput-object p1, p0, Lc7/a;->b:Lcom/flipkart/android/reactmultiwidget/fragments/a;

    return-void
.end method
