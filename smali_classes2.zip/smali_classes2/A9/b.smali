.class final LA9/b;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ImageUtil.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.chitrahar.util.ImageUtilKt$setBitmapFromUrl$1"
    f = "ImageUtil.kt"
    l = {
        0x1f
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:I

.field final synthetic d:I

.field final synthetic e:Landroid/widget/ImageView;


# direct methods
.method constructor <init>(Ljava/lang/String;IILandroid/widget/ImageView;LXn/d;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "II",
            "Landroid/widget/ImageView;",
            "LXn/d<",
            "-",
            "LA9/b;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LA9/b;->b:Ljava/lang/String;

    iput p2, p0, LA9/b;->c:I

    iput p3, p0, LA9/b;->d:I

    iput-object p4, p0, LA9/b;->e:Landroid/widget/ImageView;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LA9/b;

    iget v3, p0, LA9/b;->d:I

    iget-object v4, p0, LA9/b;->e:Landroid/widget/ImageView;

    iget-object v1, p0, LA9/b;->b:Ljava/lang/String;

    iget v2, p0, LA9/b;->c:I

    move-object v0, p1

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, LA9/b;-><init>(Ljava/lang/String;IILandroid/widget/ImageView;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LA9/b;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LA9/b;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LA9/b;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LA9/b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LA9/b;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_3b

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget p1, p0, LA9/b;->c:I

    iget v1, p0, LA9/b;->d:I

    iget-object v3, p0, LA9/b;->b:Ljava/lang/String;

    invoke-static {v3, p1, v1}, LA9/a;->access$getUrl(Ljava/lang/String;II)Ljava/net/URL;

    move-result-object p1

    invoke-static {p1}, LA9/a;->access$getBitmap(Ljava/net/URL;)Landroid/graphics/Bitmap;

    move-result-object p1

    sget v1, Lkotlinx/coroutines/S;->c:I

    sget-object v1, Lkotlinx/coroutines/internal/n;->a:Lkotlinx/coroutines/u0;

    new-instance v3, LA9/b$a;

    iget-object v4, p0, LA9/b;->e:Landroid/widget/ImageView;

    const/4 v5, 0x0

    invoke-direct {v3, v4, p1, v5}, LA9/b$a;-><init>(Landroid/widget/ImageView;Landroid/graphics/Bitmap;LXn/d;)V

    iput v2, p0, LA9/b;->a:I

    invoke-static {v1, v3, p0}, Lkotlinx/coroutines/h;->d(LXn/f;Leo/p;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3b

    return-object v0

    :cond_3b
    :goto_3b
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
