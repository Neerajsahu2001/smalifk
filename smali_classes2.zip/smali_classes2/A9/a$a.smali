.class public final LA9/a$a;
.super Ljava/lang/Object;
.source "ImageUtil.kt"

# interfaces
.implements Le9/a$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LA9/a;->getDefaultImageInflator()Le9/a$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# virtual methods
.method public inflate(Landroid/widget/ImageView;Ljava/lang/String;)V
    .registers 11

    const-string v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "url"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lkotlinx/coroutines/S;->b()Lkotlinx/coroutines/scheduling/b;

    move-result-object v0

    invoke-static {v0}, LHj/a;->a(LXn/f;)Lkotlinx/coroutines/internal/d;

    move-result-object v0

    new-instance v7, LA9/b;

    const/16 v3, 0x64

    const/16 v4, 0x64

    const/4 v6, 0x0

    move-object v1, v7

    move-object v2, p2

    move-object v5, p1

    invoke-direct/range {v1 .. v6}, LA9/b;-><init>(Ljava/lang/String;IILandroid/widget/ImageView;LXn/d;)V

    const/4 p1, 0x3

    const/4 p2, 0x0

    invoke-static {v0, p2, v7, p1}, Lkotlinx/coroutines/h;->b(Lkotlinx/coroutines/G;LXn/f$a;Leo/p;I)Lkotlinx/coroutines/j0;

    return-void
.end method
