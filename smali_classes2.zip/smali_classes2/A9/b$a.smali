.class final LA9/b$a;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ImageUtil.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LA9/b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.chitrahar.util.ImageUtilKt$setBitmapFromUrl$1$1"
    f = "ImageUtil.kt"
    l = {}
    m = "invokeSuspend"
.end annotation


# instance fields
.field final synthetic a:Landroid/widget/ImageView;

.field final synthetic b:Landroid/graphics/Bitmap;


# direct methods
.method constructor <init>(Landroid/widget/ImageView;Landroid/graphics/Bitmap;LXn/d;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/ImageView;",
            "Landroid/graphics/Bitmap;",
            "LXn/d<",
            "-",
            "LA9/b$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LA9/b$a;->a:Landroid/widget/ImageView;

    iput-object p2, p0, LA9/b$a;->b:Landroid/graphics/Bitmap;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LA9/b$a;

    iget-object v0, p0, LA9/b$a;->a:Landroid/widget/ImageView;

    iget-object v1, p0, LA9/b$a;->b:Landroid/graphics/Bitmap;

    invoke-direct {p1, v0, v1, p2}, LA9/b$a;-><init>(Landroid/widget/ImageView;Landroid/graphics/Bitmap;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LA9/b$a;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LA9/b$a;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LA9/b$a;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LA9/b$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LA9/b$a;->a:Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_10

    iget-object v0, p0, LA9/b$a;->b:Landroid/graphics/Bitmap;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_10
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
