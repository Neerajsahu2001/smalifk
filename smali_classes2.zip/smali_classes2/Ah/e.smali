.class public final LAh/e;
.super Lxk/z;
.source "FDPTracking$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LAh/f;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "LAh/f;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LAh/f;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, LAh/e;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LAh/f;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LAh/f;

    invoke-direct {v0}, LAh/f;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_a8

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_d0

    goto :goto_69

    :sswitch_33
    const-string v2, "DCEEventType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_69

    :cond_3c
    const/4 v3, 0x4

    goto :goto_69

    :sswitch_3e
    const-string v2, "impressionId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_69

    :cond_47
    const/4 v3, 0x3

    goto :goto_69

    :sswitch_49
    const-string v2, "contentType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_69

    :cond_52
    const/4 v3, 0x2

    goto :goto_69

    :sswitch_54
    const-string v2, "widgetKey"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_69

    :cond_5d
    const/4 v3, 0x1

    goto :goto_69

    :sswitch_5f
    const-string v2, "findingMethod"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto :goto_69

    :cond_68
    const/4 v3, 0x0

    :goto_69
    packed-switch v3, :pswitch_data_e6

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_70
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAh/f;->d:Ljava/lang/String;

    goto :goto_1d

    :pswitch_7b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAh/f;->a:Ljava/lang/String;

    goto :goto_1d

    :pswitch_86
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAh/f;->c:Ljava/lang/String;

    goto :goto_1d

    :pswitch_91
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAh/f;->e:Ljava/lang/String;

    goto :goto_1d

    :pswitch_9c
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LAh/f;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_a8
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LAh/f;->a:Ljava/lang/String;

    if-eqz p1, :cond_c8

    iget-object p1, v0, LAh/f;->b:Ljava/lang/String;

    if-eqz p1, :cond_c0

    iget-object p1, v0, LAh/f;->c:Ljava/lang/String;

    if-eqz p1, :cond_b8

    return-object v0

    :cond_b8
    new-instance p1, Ljava/io/IOException;

    const-string v0, "contentType cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_c0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "findingMethod cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_c8
    new-instance p1, Ljava/io/IOException;

    const-string v0, "impressionId cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :sswitch_data_d0
    .sparse-switch
        -0x245a3236 -> :sswitch_5f
        -0x195d8a85 -> :sswitch_54
        -0x1731acad -> :sswitch_49
        -0x2abc2fc -> :sswitch_3e
        0x5427ebee -> :sswitch_33
    .end sparse-switch

    :pswitch_data_e6
    .packed-switch 0x0
        :pswitch_9c
        :pswitch_91
        :pswitch_86
        :pswitch_7b
        :pswitch_70
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LAh/e;->read(LBk/a;)LAh/f;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LAh/f;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "impressionId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAh/f;->a:Ljava/lang/String;

    if-eqz v0, :cond_63

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "findingMethod"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAh/f;->b:Ljava/lang/String;

    if-eqz v0, :cond_5b

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "contentType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAh/f;->c:Ljava/lang/String;

    if-eqz v0, :cond_53

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "DCEEventType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LAh/f;->d:Ljava/lang/String;

    if-eqz v0, :cond_3c

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "widgetKey"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LAh/f;->e:Ljava/lang/String;

    if-eqz p2, :cond_4c

    invoke-virtual {v1, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_4f

    :cond_4c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_4f
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_53
    new-instance p1, Ljava/io/IOException;

    const-string p2, "contentType cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5b
    new-instance p1, Ljava/io/IOException;

    const-string p2, "findingMethod cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_63
    new-instance p1, Ljava/io/IOException;

    const-string p2, "impressionId cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LAh/f;

    invoke-virtual {p0, p1, p2}, LAh/e;->write(LBk/c;LAh/f;)V

    return-void
.end method
