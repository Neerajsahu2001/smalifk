.class public final LAh/o;
.super Ljava/lang/Object;
.source "PageTracking.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:LAh/u;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
