.class public final LAh/w;
.super Ljava/lang/Object;
.source "TrackingEventType.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
