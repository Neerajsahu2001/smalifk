.class public final LAh/s;
.super Ljava/lang/Object;
.source "TrackingData.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:LAh/l;

.field public b:LAh/f;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
