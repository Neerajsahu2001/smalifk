.class public final LAh/C;
.super Ljava/lang/Object;
.source "WidgetLevelTracking.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:LAh/b;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
