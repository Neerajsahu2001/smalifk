.class final LCi/e$a;
.super LCi/k$a;
.source "AutoValue_ClientInfo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field private a:LCi/k$b;

.field private b:LCi/a;


# virtual methods
.method public final a()LCi/k;
    .registers 4

    new-instance v0, LCi/e;

    iget-object v1, p0, LCi/e$a;->a:LCi/k$b;

    iget-object v2, p0, LCi/e$a;->b:LCi/a;

    invoke-direct {v0, v1, v2}, LCi/e;-><init>(LCi/k$b;LCi/a;)V

    return-object v0
.end method

.method public final b(LCi/a;)LCi/k$a;
    .registers 2

    iput-object p1, p0, LCi/e$a;->b:LCi/a;

    return-object p0
.end method

.method public final c(LCi/k$b;)LCi/k$a;
    .registers 2

    iput-object p1, p0, LCi/e$a;->a:LCi/k$b;

    return-object p0
.end method
