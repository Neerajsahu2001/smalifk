.class final LCi/i;
.super LCi/o;
.source "AutoValue_NetworkConnectionInfo.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCi/i$a;
    }
.end annotation


# instance fields
.field private final a:LCi/o$c;

.field private final b:LCi/o$b;


# direct methods
.method constructor <init>(LCi/o$c;LCi/o$b;)V
    .registers 3

    invoke-direct {p0}, LCi/o;-><init>()V

    iput-object p1, p0, LCi/i;->a:LCi/o$c;

    iput-object p2, p0, LCi/i;->b:LCi/o$b;

    return-void
.end method


# virtual methods
.method public final b()LCi/o$b;
    .registers 2

    iget-object v0, p0, LCi/i;->b:LCi/o$b;

    return-object v0
.end method

.method public final c()LCi/o$c;
    .registers 2

    iget-object v0, p0, LCi/i;->a:LCi/o$c;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LCi/o;

    const/4 v2, 0x0

    if-eqz v1, :cond_38

    check-cast p1, LCi/o;

    iget-object v1, p0, LCi/i;->a:LCi/o$c;

    if-nez v1, :cond_16

    invoke-virtual {p1}, LCi/o;->c()LCi/o$c;

    move-result-object v1

    if-nez v1, :cond_36

    goto :goto_20

    :cond_16
    invoke-virtual {p1}, LCi/o;->c()LCi/o$c;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_36

    :goto_20
    iget-object v1, p0, LCi/i;->b:LCi/o$b;

    if-nez v1, :cond_2b

    invoke-virtual {p1}, LCi/o;->b()LCi/o$b;

    move-result-object p1

    if-nez p1, :cond_36

    goto :goto_37

    :cond_2b
    invoke-virtual {p1}, LCi/o;->b()LCi/o$b;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_36

    goto :goto_37

    :cond_36
    const/4 v0, 0x0

    :goto_37
    return v0

    :cond_38
    return v2
.end method

.method public final hashCode()I
    .registers 4

    const/4 v0, 0x0

    iget-object v1, p0, LCi/i;->a:LCi/o$c;

    if-nez v1, :cond_7

    const/4 v1, 0x0

    goto :goto_b

    :cond_7
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_b
    const v2, 0xf4243

    xor-int/2addr v1, v2

    mul-int v1, v1, v2

    iget-object v2, p0, LCi/i;->b:LCi/o$b;

    if-nez v2, :cond_16

    goto :goto_1a

    :cond_16
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_1a
    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "NetworkConnectionInfo{networkType="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LCi/i;->a:LCi/o$c;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", mobileSubtype="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/i;->b:LCi/o$b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
