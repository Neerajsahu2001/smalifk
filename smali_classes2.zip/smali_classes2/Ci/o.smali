.class public abstract LCi/o;
.super Ljava/lang/Object;
.source "NetworkConnectionInfo.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCi/o$a;,
        LCi/o$b;,
        LCi/o$c;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()LCi/o$a;
    .registers 1

    new-instance v0, LCi/i$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-object v0
.end method


# virtual methods
.method public abstract b()LCi/o$b;
.end method

.method public abstract c()LCi/o$c;
.end method
