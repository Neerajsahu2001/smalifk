.class public abstract LCi/j;
.super Ljava/lang/Object;
.source "BatchedLogRequest.java"


# annotations
.annotation runtime Lcom/google/firebase/encoders/annotations/Encodable;
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Ljava/util/ArrayList;)LCi/j;
    .registers 2

    new-instance v0, LCi/d;

    invoke-direct {v0, p0}, LCi/d;-><init>(Ljava/util/ArrayList;)V

    return-object v0
.end method


# virtual methods
.method public abstract b()Ljava/util/List;
    .annotation runtime Lcom/google/firebase/encoders/annotations/Encodable$Field;
        name = "logRequest"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "LCi/m;",
            ">;"
        }
    .end annotation
.end method
