.class public abstract LCi/m$a;
.super Ljava/lang/Object;
.source "LogRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# virtual methods
.method public abstract a()LCi/m;
.end method

.method public abstract b(LCi/k;)LCi/m$a;
.end method

.method public abstract c(Ljava/util/ArrayList;)LCi/m$a;
.end method

.method abstract d(Ljava/lang/Integer;)LCi/m$a;
.end method

.method abstract e(Ljava/lang/String;)LCi/m$a;
.end method

.method public abstract f(LCi/p;)LCi/m$a;
.end method

.method public abstract g(J)LCi/m$a;
.end method

.method public abstract h(J)LCi/m$a;
.end method

.method public final i(I)V
    .registers 2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p1}, LCi/m$a;->d(Ljava/lang/Integer;)LCi/m$a;

    return-void
.end method

.method public final j(Ljava/lang/String;)V
    .registers 2

    invoke-virtual {p0, p1}, LCi/m$a;->e(Ljava/lang/String;)LCi/m$a;

    return-void
.end method
