.class final LCi/f;
.super LCi/l;
.source "AutoValue_LogEvent.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCi/f$a;
    }
.end annotation


# instance fields
.field private final a:J

.field private final b:Ljava/lang/Integer;

.field private final c:J

.field private final d:[B

.field private final e:Ljava/lang/String;

.field private final f:J

.field private final g:LCi/o;


# direct methods
.method constructor <init>(JLjava/lang/Integer;J[BLjava/lang/String;JLCi/o;)V
    .registers 11

    invoke-direct {p0}, LCi/l;-><init>()V

    iput-wide p1, p0, LCi/f;->a:J

    iput-object p3, p0, LCi/f;->b:Ljava/lang/Integer;

    iput-wide p4, p0, LCi/f;->c:J

    iput-object p6, p0, LCi/f;->d:[B

    iput-object p7, p0, LCi/f;->e:Ljava/lang/String;

    iput-wide p8, p0, LCi/f;->f:J

    iput-object p10, p0, LCi/f;->g:LCi/o;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Integer;
    .registers 2

    iget-object v0, p0, LCi/f;->b:Ljava/lang/Integer;

    return-object v0
.end method

.method public final b()J
    .registers 3

    iget-wide v0, p0, LCi/f;->a:J

    return-wide v0
.end method

.method public final c()J
    .registers 3

    iget-wide v0, p0, LCi/f;->c:J

    return-wide v0
.end method

.method public final d()LCi/o;
    .registers 2

    iget-object v0, p0, LCi/f;->g:LCi/o;

    return-object v0
.end method

.method public final e()[B
    .registers 2

    iget-object v0, p0, LCi/f;->d:[B

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LCi/l;

    const/4 v2, 0x0

    if-eqz v1, :cond_81

    check-cast p1, LCi/l;

    invoke-virtual {p1}, LCi/l;->b()J

    move-result-wide v3

    iget-wide v5, p0, LCi/f;->a:J

    cmp-long v1, v5, v3

    if-nez v1, :cond_7f

    iget-object v1, p0, LCi/f;->b:Ljava/lang/Integer;

    if-nez v1, :cond_20

    invoke-virtual {p1}, LCi/l;->a()Ljava/lang/Integer;

    move-result-object v1

    if-nez v1, :cond_7f

    goto :goto_2a

    :cond_20
    invoke-virtual {p1}, LCi/l;->a()Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7f

    :goto_2a
    iget-wide v3, p0, LCi/f;->c:J

    invoke-virtual {p1}, LCi/l;->c()J

    move-result-wide v5

    cmp-long v1, v3, v5

    if-nez v1, :cond_7f

    instance-of v1, p1, LCi/f;

    if-eqz v1, :cond_3e

    move-object v1, p1

    check-cast v1, LCi/f;

    iget-object v1, v1, LCi/f;->d:[B

    goto :goto_42

    :cond_3e
    invoke-virtual {p1}, LCi/l;->e()[B

    move-result-object v1

    :goto_42
    iget-object v3, p0, LCi/f;->d:[B

    invoke-static {v3, v1}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v1

    if-eqz v1, :cond_7f

    iget-object v1, p0, LCi/f;->e:Ljava/lang/String;

    if-nez v1, :cond_55

    invoke-virtual {p1}, LCi/l;->f()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_7f

    goto :goto_5f

    :cond_55
    invoke-virtual {p1}, LCi/l;->f()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7f

    :goto_5f
    iget-wide v3, p0, LCi/f;->f:J

    invoke-virtual {p1}, LCi/l;->g()J

    move-result-wide v5

    cmp-long v1, v3, v5

    if-nez v1, :cond_7f

    iget-object v1, p0, LCi/f;->g:LCi/o;

    if-nez v1, :cond_74

    invoke-virtual {p1}, LCi/l;->d()LCi/o;

    move-result-object p1

    if-nez p1, :cond_7f

    goto :goto_80

    :cond_74
    invoke-virtual {p1}, LCi/l;->d()LCi/o;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7f

    goto :goto_80

    :cond_7f
    const/4 v0, 0x0

    :goto_80
    return v0

    :cond_81
    return v2
.end method

.method public final f()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LCi/f;->e:Ljava/lang/String;

    return-object v0
.end method

.method public final g()J
    .registers 3

    iget-wide v0, p0, LCi/f;->f:J

    return-wide v0
.end method

.method public final hashCode()I
    .registers 9

    iget-wide v0, p0, LCi/f;->a:J

    const/16 v2, 0x20

    ushr-long v3, v0, v2

    xor-long/2addr v0, v3

    long-to-int v1, v0

    const v0, 0xf4243

    xor-int/2addr v1, v0

    mul-int v1, v1, v0

    const/4 v3, 0x0

    iget-object v4, p0, LCi/f;->b:Ljava/lang/Integer;

    if-nez v4, :cond_15

    const/4 v4, 0x0

    goto :goto_19

    :cond_15
    invoke-virtual {v4}, Ljava/lang/Integer;->hashCode()I

    move-result v4

    :goto_19
    xor-int/2addr v1, v4

    mul-int v1, v1, v0

    iget-wide v4, p0, LCi/f;->c:J

    ushr-long v6, v4, v2

    xor-long/2addr v4, v6

    long-to-int v5, v4

    xor-int/2addr v1, v5

    mul-int v1, v1, v0

    iget-object v4, p0, LCi/f;->d:[B

    invoke-static {v4}, Ljava/util/Arrays;->hashCode([B)I

    move-result v4

    xor-int/2addr v1, v4

    mul-int v1, v1, v0

    iget-object v4, p0, LCi/f;->e:Ljava/lang/String;

    if-nez v4, :cond_34

    const/4 v4, 0x0

    goto :goto_38

    :cond_34
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v4

    :goto_38
    xor-int/2addr v1, v4

    mul-int v1, v1, v0

    iget-wide v4, p0, LCi/f;->f:J

    ushr-long v6, v4, v2

    xor-long/2addr v4, v6

    long-to-int v2, v4

    xor-int/2addr v1, v2

    mul-int v1, v1, v0

    iget-object v0, p0, LCi/f;->g:LCi/o;

    if-nez v0, :cond_49

    goto :goto_4d

    :cond_49
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v3

    :goto_4d
    xor-int v0, v1, v3

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "LogEvent{eventTimeMs="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, LCi/f;->a:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", eventCode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/f;->b:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", eventUptimeMs="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, LCi/f;->c:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", sourceExtension="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/f;->d:[B

    invoke-static {v1}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", sourceExtensionJsonProto3="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/f;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", timezoneOffsetSeconds="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, LCi/f;->f:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", networkConnectionInfo="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/f;->g:LCi/o;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
