.class final LCi/g;
.super LCi/m;
.source "AutoValue_LogRequest.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCi/g$a;
    }
.end annotation


# instance fields
.field private final a:J

.field private final b:J

.field private final c:LCi/k;

.field private final d:Ljava/lang/Integer;

.field private final e:Ljava/lang/String;

.field private final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCi/l;",
            ">;"
        }
    .end annotation
.end field

.field private final g:LCi/p;


# direct methods
.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method constructor <init>(JJLCi/k;Ljava/lang/Integer;Ljava/lang/String;Ljava/util/List;LCi/p;)V
    .registers 10

    invoke-direct {p0}, LCi/m;-><init>()V

    iput-wide p1, p0, LCi/g;->a:J

    iput-wide p3, p0, LCi/g;->b:J

    iput-object p5, p0, LCi/g;->c:LCi/k;

    iput-object p6, p0, LCi/g;->d:Ljava/lang/Integer;

    iput-object p7, p0, LCi/g;->e:Ljava/lang/String;

    iput-object p8, p0, LCi/g;->f:Ljava/util/List;

    iput-object p9, p0, LCi/g;->g:LCi/p;

    return-void
.end method


# virtual methods
.method public final b()LCi/k;
    .registers 2

    iget-object v0, p0, LCi/g;->c:LCi/k;

    return-object v0
.end method

.method public final c()Ljava/util/List;
    .registers 2
    .annotation runtime Lcom/google/firebase/encoders/annotations/Encodable$Field;
        name = "logEvent"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "LCi/l;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LCi/g;->f:Ljava/util/List;

    return-object v0
.end method

.method public final d()Ljava/lang/Integer;
    .registers 2

    iget-object v0, p0, LCi/g;->d:Ljava/lang/Integer;

    return-object v0
.end method

.method public final e()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LCi/g;->e:Ljava/lang/String;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LCi/m;

    const/4 v2, 0x0

    if-eqz v1, :cond_8b

    check-cast p1, LCi/m;

    invoke-virtual {p1}, LCi/m;->g()J

    move-result-wide v3

    iget-wide v5, p0, LCi/g;->a:J

    cmp-long v1, v5, v3

    if-nez v1, :cond_89

    iget-wide v3, p0, LCi/g;->b:J

    invoke-virtual {p1}, LCi/m;->h()J

    move-result-wide v5

    cmp-long v1, v3, v5

    if-nez v1, :cond_89

    iget-object v1, p0, LCi/g;->c:LCi/k;

    if-nez v1, :cond_2a

    invoke-virtual {p1}, LCi/m;->b()LCi/k;

    move-result-object v1

    if-nez v1, :cond_89

    goto :goto_34

    :cond_2a
    invoke-virtual {p1}, LCi/m;->b()LCi/k;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_89

    :goto_34
    iget-object v1, p0, LCi/g;->d:Ljava/lang/Integer;

    if-nez v1, :cond_3f

    invoke-virtual {p1}, LCi/m;->d()Ljava/lang/Integer;

    move-result-object v1

    if-nez v1, :cond_89

    goto :goto_49

    :cond_3f
    invoke-virtual {p1}, LCi/m;->d()Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_89

    :goto_49
    iget-object v1, p0, LCi/g;->e:Ljava/lang/String;

    if-nez v1, :cond_54

    invoke-virtual {p1}, LCi/m;->e()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_89

    goto :goto_5e

    :cond_54
    invoke-virtual {p1}, LCi/m;->e()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_89

    :goto_5e
    iget-object v1, p0, LCi/g;->f:Ljava/util/List;

    if-nez v1, :cond_69

    invoke-virtual {p1}, LCi/m;->c()Ljava/util/List;

    move-result-object v1

    if-nez v1, :cond_89

    goto :goto_73

    :cond_69
    invoke-virtual {p1}, LCi/m;->c()Ljava/util/List;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_89

    :goto_73
    iget-object v1, p0, LCi/g;->g:LCi/p;

    if-nez v1, :cond_7e

    invoke-virtual {p1}, LCi/m;->f()LCi/p;

    move-result-object p1

    if-nez p1, :cond_89

    goto :goto_8a

    :cond_7e
    invoke-virtual {p1}, LCi/m;->f()LCi/p;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_89

    goto :goto_8a

    :cond_89
    const/4 v0, 0x0

    :goto_8a
    return v0

    :cond_8b
    return v2
.end method

.method public final f()LCi/p;
    .registers 2

    iget-object v0, p0, LCi/g;->g:LCi/p;

    return-object v0
.end method

.method public final g()J
    .registers 3

    iget-wide v0, p0, LCi/g;->a:J

    return-wide v0
.end method

.method public final h()J
    .registers 3

    iget-wide v0, p0, LCi/g;->b:J

    return-wide v0
.end method

.method public final hashCode()I
    .registers 8

    iget-wide v0, p0, LCi/g;->a:J

    const/16 v2, 0x20

    ushr-long v3, v0, v2

    xor-long/2addr v0, v3

    long-to-int v1, v0

    const v0, 0xf4243

    xor-int/2addr v1, v0

    mul-int v1, v1, v0

    iget-wide v3, p0, LCi/g;->b:J

    ushr-long v5, v3, v2

    xor-long v2, v5, v3

    long-to-int v3, v2

    xor-int/2addr v1, v3

    mul-int v1, v1, v0

    const/4 v2, 0x0

    iget-object v3, p0, LCi/g;->c:LCi/k;

    if-nez v3, :cond_1f

    const/4 v3, 0x0

    goto :goto_23

    :cond_1f
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    :goto_23
    xor-int/2addr v1, v3

    mul-int v1, v1, v0

    iget-object v3, p0, LCi/g;->d:Ljava/lang/Integer;

    if-nez v3, :cond_2c

    const/4 v3, 0x0

    goto :goto_30

    :cond_2c
    invoke-virtual {v3}, Ljava/lang/Integer;->hashCode()I

    move-result v3

    :goto_30
    xor-int/2addr v1, v3

    mul-int v1, v1, v0

    iget-object v3, p0, LCi/g;->e:Ljava/lang/String;

    if-nez v3, :cond_39

    const/4 v3, 0x0

    goto :goto_3d

    :cond_39
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v3

    :goto_3d
    xor-int/2addr v1, v3

    mul-int v1, v1, v0

    iget-object v3, p0, LCi/g;->f:Ljava/util/List;

    if-nez v3, :cond_46

    const/4 v3, 0x0

    goto :goto_4a

    :cond_46
    invoke-interface {v3}, Ljava/util/List;->hashCode()I

    move-result v3

    :goto_4a
    xor-int/2addr v1, v3

    mul-int v1, v1, v0

    iget-object v0, p0, LCi/g;->g:LCi/p;

    if-nez v0, :cond_52

    goto :goto_56

    :cond_52
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_56
    xor-int v0, v1, v2

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "LogRequest{requestTimeMs="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, LCi/g;->a:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", requestUptimeMs="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, LCi/g;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", clientInfo="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/g;->c:LCi/k;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", logSource="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/g;->d:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", logSourceName="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/g;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", logEvents="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/g;->f:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", qosTier="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LCi/g;->g:LCi/p;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
