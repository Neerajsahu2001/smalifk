.class public final Lci/a;
.super Lxk/z;
.source "PlaybackContext$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lci/b;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:LJn/a$r;

.field private final b:LJn/a$r;

.field private final c:LJn/a$t;

.field private final d:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lci/b;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    const-class v0, Ljava/lang/Object;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v1, Lci/c;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, Lci/a;->a:LJn/a$r;

    sget-object v1, Lei/c;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, Lci/a;->b:LJn/a$r;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$t;

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v3, LJn/a$s;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v2, v0, v3}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Lci/a;->c:LJn/a$t;

    sget-object v0, Lbi/a;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lci/a;->d:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lci/b;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lci/b;

    invoke-direct {v0}, Lci/b;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_ee

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_fe

    goto/16 :goto_8b

    :sswitch_34
    const-string v2, "watermarks"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3d

    goto :goto_8b

    :cond_3d
    const/4 v3, 0x7

    goto :goto_8b

    :sswitch_3f
    const-string v2, "cuePoints"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_48

    goto :goto_8b

    :cond_48
    const/4 v3, 0x6

    goto :goto_8b

    :sswitch_4a
    const-string v2, "startPosition"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_53

    goto :goto_8b

    :cond_53
    const/4 v3, 0x5

    goto :goto_8b

    :sswitch_55
    const-string v2, "mode"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5e

    goto :goto_8b

    :cond_5e
    const/4 v3, 0x4

    goto :goto_8b

    :sswitch_60
    const-string v2, "meta"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_69

    goto :goto_8b

    :cond_69
    const/4 v3, 0x3

    goto :goto_8b

    :sswitch_6b
    const-string v2, "ttl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_74

    goto :goto_8b

    :cond_74
    const/4 v3, 0x2

    goto :goto_8b

    :sswitch_76
    const-string v2, "customMeta"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7f

    goto :goto_8b

    :cond_7f
    const/4 v3, 0x1

    goto :goto_8b

    :sswitch_81
    const-string v2, "sources"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8a

    goto :goto_8b

    :cond_8a
    const/4 v3, 0x0

    :goto_8b
    iget-object v1, p0, Lci/a;->c:LJn/a$t;

    packed-switch v3, :pswitch_data_120

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_94
    iget-object v1, p0, Lci/a;->b:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lci/b;->b:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_a0
    iget-object v1, p0, Lci/a;->d:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lci/b;->h:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_ac
    iget v1, v0, Lci/b;->c:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lci/b;->c:I

    goto/16 :goto_1d

    :pswitch_b6
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/b;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_c2
    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Lci/b;->d:Ljava/util/Map;

    goto/16 :goto_1d

    :pswitch_cc
    sget-object v1, LJn/a;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    iput-object v1, v0, Lci/b;->f:Ljava/lang/Long;

    goto/16 :goto_1d

    :pswitch_d8
    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Lci/b;->e:Ljava/util/Map;

    goto/16 :goto_1d

    :pswitch_e2
    iget-object v1, p0, Lci/a;->a:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lci/b;->a:Ljava/util/List;

    goto/16 :goto_1d

    :cond_ee
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Lci/b;->g:Ljava/lang/String;

    if-eqz p1, :cond_f6

    return-object v0

    :cond_f6
    new-instance p1, Ljava/io/IOException;

    const-string v0, "mode cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :sswitch_data_fe
    .sparse-switch
        -0x78836448 -> :sswitch_81
        -0x5e4a0aea -> :sswitch_76
        0x1c1ec -> :sswitch_6b
        0x331605 -> :sswitch_60
        0x3339a3 -> :sswitch_55
        0x34263fab -> :sswitch_4a
        0x3e0718f6 -> :sswitch_3f
        0x75a5a48f -> :sswitch_34
    .end sparse-switch

    :pswitch_data_120
    .packed-switch 0x0
        :pswitch_e2
        :pswitch_d8
        :pswitch_cc
        :pswitch_c2
        :pswitch_b6
        :pswitch_ac
        :pswitch_a0
        :pswitch_94
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lci/a;->read(LBk/a;)Lci/b;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lci/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "sources"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/b;->a:Ljava/util/List;

    if-eqz v0, :cond_1d

    iget-object v1, p0, Lci/a;->a:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_20

    :cond_1d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_20
    const-string v0, "watermarks"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/b;->b:Ljava/util/List;

    if-eqz v0, :cond_34

    iget-object v1, p0, Lci/a;->b:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_37

    :cond_34
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_37
    const-string v0, "startPosition"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lci/b;->c:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "meta"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/b;->d:Ljava/util/Map;

    iget-object v1, p0, Lci/a;->c:LJn/a$t;

    if-eqz v0, :cond_51

    invoke-virtual {v1, p1, v0}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_54

    :cond_51
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_54
    const-string v0, "customMeta"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/b;->e:Ljava/util/Map;

    if-eqz v0, :cond_61

    invoke-virtual {v1, p1, v0}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_64

    :cond_61
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_64
    const-string v0, "ttl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/b;->f:Ljava/lang/Long;

    if-eqz v0, :cond_73

    sget-object v1, LJn/a;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_76

    :cond_73
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_76
    const-string v0, "mode"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/b;->g:Ljava/lang/String;

    if-eqz v0, :cond_9f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "cuePoints"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lci/b;->h:Ljava/util/List;

    if-eqz p2, :cond_98

    iget-object v0, p0, Lci/a;->d:LJn/a$r;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/util/Collection;

    invoke-virtual {v0, p1, p2}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_9b

    :cond_98
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_9b
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_9f
    new-instance p1, Ljava/io/IOException;

    const-string p2, "mode cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lci/b;

    invoke-virtual {p0, p1, p2}, Lci/a;->write(LBk/c;Lci/b;)V

    return-void
.end method
