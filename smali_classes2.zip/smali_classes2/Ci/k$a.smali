.class public abstract LCi/k$a;
.super Ljava/lang/Object;
.source "ClientInfo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# virtual methods
.method public abstract a()LCi/k;
.end method

.method public abstract b(LCi/a;)LCi/k$a;
.end method

.method public abstract c(LCi/k$b;)LCi/k$a;
.end method
