.class public final Lci/c;
.super Lxk/z;
.source "PlaybackSource$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lci/d;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lci/d;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lci/d;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lci/c;->b:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 4

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Ldi/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lci/c;->a:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lci/d;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lci/d;

    invoke-direct {v0}, Lci/d;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_18b

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_190

    goto/16 :goto_df

    :sswitch_34
    const-string v2, "altExternalId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_df

    :cond_3e
    const/16 v3, 0xd

    goto/16 :goto_df

    :sswitch_42
    const-string v2, "defaultLanguage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_df

    :cond_4c
    const/16 v3, 0xc

    goto/16 :goto_df

    :sswitch_50
    const-string v2, "tokenized"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_df

    :cond_5a
    const/16 v3, 0xb

    goto/16 :goto_df

    :sswitch_5e
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_df

    :cond_68
    const/16 v3, 0xa

    goto/16 :goto_df

    :sswitch_6c
    const-string v2, "url"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_df

    :cond_76
    const/16 v3, 0x9

    goto/16 :goto_df

    :sswitch_7a
    const-string v2, "drm"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_df

    :cond_84
    const/16 v3, 0x8

    goto/16 :goto_df

    :sswitch_88
    const-string v2, "id"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_91

    goto :goto_df

    :cond_91
    const/4 v3, 0x7

    goto :goto_df

    :sswitch_93
    const-string v2, "protocols"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9c

    goto :goto_df

    :cond_9c
    const/4 v3, 0x6

    goto :goto_df

    :sswitch_9e
    const-string v2, "outputProtectionLevel"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a7

    goto :goto_df

    :cond_a7
    const/4 v3, 0x5

    goto :goto_df

    :sswitch_a9
    const-string v2, "assetId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b2

    goto :goto_df

    :cond_b2
    const/4 v3, 0x4

    goto :goto_df

    :sswitch_b4
    const-string v2, "format"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bd

    goto :goto_df

    :cond_bd
    const/4 v3, 0x3

    goto :goto_df

    :sswitch_bf
    const-string v2, "language"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c8

    goto :goto_df

    :cond_c8
    const/4 v3, 0x2

    goto :goto_df

    :sswitch_ca
    const-string v2, "externalId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d3

    goto :goto_df

    :cond_d3
    const/4 v3, 0x1

    goto :goto_df

    :sswitch_d5
    const-string v2, "duration"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_de

    goto :goto_df

    :cond_de
    const/4 v3, 0x0

    :goto_df
    packed-switch v3, :pswitch_data_1ca

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_e7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_f3
    iget-boolean v1, v0, Lci/d;->h:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lci/d;->h:Z

    goto/16 :goto_1d

    :pswitch_fd
    iget-boolean v1, v0, Lci/d;->n:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lci/d;->n:Z

    goto/16 :goto_1d

    :pswitch_107
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_113
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_11f
    iget-object v1, p0, Lci/c;->a:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lci/d;->k:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_12b
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lci/d;->c:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_137
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->m:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_143
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->j:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_14f
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lci/d;->b:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_15b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->l:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_167
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->i:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_173
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lci/d;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_17f
    sget-object v1, LJn/a;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    iput-object v1, v0, Lci/d;->e:Ljava/lang/Long;

    goto/16 :goto_1d

    :cond_18b
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_190
    .sparse-switch
        -0x76bbb26c -> :sswitch_d5
        -0x655059ba -> :sswitch_ca
        -0x602d6ca8 -> :sswitch_bf
        -0x4ba00809 -> :sswitch_b4
        -0x2a0207d5 -> :sswitch_a9
        -0x266a3316 -> :sswitch_9e
        -0x23b8bb25 -> :sswitch_93
        0xd1b -> :sswitch_88
        0x1859f -> :sswitch_7a
        0x1c56f -> :sswitch_6c
        0x368f3a -> :sswitch_5e
        0x878a709 -> :sswitch_50
        0x16eafcb9 -> :sswitch_42
        0x27b9bccf -> :sswitch_34
    .end sparse-switch

    :pswitch_data_1ca
    .packed-switch 0x0
        :pswitch_17f
        :pswitch_173
        :pswitch_167
        :pswitch_15b
        :pswitch_14f
        :pswitch_143
        :pswitch_137
        :pswitch_12b
        :pswitch_11f
        :pswitch_113
        :pswitch_107
        :pswitch_fd
        :pswitch_f3
        :pswitch_e7
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lci/c;->read(LBk/a;)Lci/d;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lci/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "url"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "assetId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->b:Ljava/lang/Integer;

    if-eqz v0, :cond_2a

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "id"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->c:Ljava/lang/Integer;

    if-eqz v0, :cond_3c

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->d:Ljava/lang/String;

    if-eqz v0, :cond_4e

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_51

    :cond_4e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_51
    const-string v0, "duration"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->e:Ljava/lang/Long;

    if-eqz v0, :cond_60

    sget-object v1, LJn/a;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_63

    :cond_60
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_63
    const-string v0, "externalId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->f:Ljava/lang/String;

    if-eqz v0, :cond_72

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_75

    :cond_72
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_75
    const-string v0, "altExternalId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->g:Ljava/lang/String;

    if-eqz v0, :cond_84

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_87

    :cond_84
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_87
    const-string v0, "defaultLanguage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lci/d;->h:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "language"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->i:Ljava/lang/String;

    if-eqz v0, :cond_a0

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a3

    :cond_a0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a3
    const-string v0, "outputProtectionLevel"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->j:Ljava/lang/String;

    if-eqz v0, :cond_b2

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_b5

    :cond_b2
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_b5
    const-string v0, "drm"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->k:Ljava/util/List;

    if-eqz v0, :cond_c9

    iget-object v1, p0, Lci/c;->a:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_cc

    :cond_c9
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_cc
    const-string v0, "format"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->l:Ljava/lang/String;

    if-eqz v0, :cond_db

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_de

    :cond_db
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_de
    const-string v0, "protocols"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lci/d;->m:Ljava/lang/String;

    if-eqz v0, :cond_ed

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_f0

    :cond_ed
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_f0
    const-string v0, "tokenized"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Lci/d;->n:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lci/d;

    invoke-virtual {p0, p1, p2}, Lci/c;->write(LBk/c;Lci/d;)V

    return-void
.end method
