.class final LCi/f$a;
.super LCi/l$a;
.source "AutoValue_LogEvent.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field private a:Ljava/lang/Long;

.field private b:Ljava/lang/Integer;

.field private c:Ljava/lang/Long;

.field private d:[B

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/Long;

.field private g:LCi/o;


# virtual methods
.method public final a()LCi/l;
    .registers 14

    iget-object v0, p0, LCi/f$a;->a:Ljava/lang/Long;

    if-nez v0, :cond_7

    const-string v0, " eventTimeMs"

    goto :goto_9

    :cond_7
    const-string v0, ""

    :goto_9
    iget-object v1, p0, LCi/f$a;->c:Ljava/lang/Long;

    if-nez v1, :cond_13

    const-string v1, " eventUptimeMs"

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_13
    iget-object v1, p0, LCi/f$a;->f:Ljava/lang/Long;

    if-nez v1, :cond_1d

    const-string v1, " timezoneOffsetSeconds"

    invoke-static {v0, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_1d
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_44

    new-instance v0, LCi/f;

    iget-object v1, p0, LCi/f$a;->a:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    iget-object v5, p0, LCi/f$a;->b:Ljava/lang/Integer;

    iget-object v1, p0, LCi/f$a;->c:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    iget-object v8, p0, LCi/f$a;->d:[B

    iget-object v9, p0, LCi/f$a;->e:Ljava/lang/String;

    iget-object v1, p0, LCi/f$a;->f:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    iget-object v12, p0, LCi/f$a;->g:LCi/o;

    move-object v2, v0

    invoke-direct/range {v2 .. v12}, LCi/f;-><init>(JLjava/lang/Integer;J[BLjava/lang/String;JLCi/o;)V

    return-object v0

    :cond_44
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Missing required properties:"

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final b(Ljava/lang/Integer;)LCi/l$a;
    .registers 2

    iput-object p1, p0, LCi/f$a;->b:Ljava/lang/Integer;

    return-object p0
.end method

.method public final c(J)LCi/l$a;
    .registers 3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, p0, LCi/f$a;->a:Ljava/lang/Long;

    return-object p0
.end method

.method public final d(J)LCi/l$a;
    .registers 3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, p0, LCi/f$a;->c:Ljava/lang/Long;

    return-object p0
.end method

.method public final e(LCi/o;)LCi/l$a;
    .registers 2

    iput-object p1, p0, LCi/f$a;->g:LCi/o;

    return-object p0
.end method

.method public final f(J)LCi/l$a;
    .registers 3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, p0, LCi/f$a;->f:Ljava/lang/Long;

    return-object p0
.end method

.method final g([B)LCi/l$a;
    .registers 2

    iput-object p1, p0, LCi/f$a;->d:[B

    return-object p0
.end method

.method final h(Ljava/lang/String;)LCi/l$a;
    .registers 2

    iput-object p1, p0, LCi/f$a;->e:Ljava/lang/String;

    return-object p0
.end method
