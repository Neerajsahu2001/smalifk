.class public abstract LCi/o$a;
.super Ljava/lang/Object;
.source "NetworkConnectionInfo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# virtual methods
.method public abstract a()LCi/o;
.end method

.method public abstract b(LCi/o$b;)LCi/o$a;
.end method

.method public abstract c(LCi/o$c;)LCi/o$a;
.end method
