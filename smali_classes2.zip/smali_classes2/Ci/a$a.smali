.class public abstract LCi/a$a;
.super Ljava/lang/Object;
.source "AndroidClientInfo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# virtual methods
.method public abstract a()LCi/a;
.end method

.method public abstract b(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract c(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract d(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract e(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract f(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract g(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract h(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract i(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract j(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract k(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract l(Ljava/lang/String;)LCi/a$a;
.end method

.method public abstract m(Ljava/lang/Integer;)LCi/a$a;
.end method
