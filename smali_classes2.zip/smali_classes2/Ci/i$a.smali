.class final LCi/i$a;
.super LCi/o$a;
.source "AutoValue_NetworkConnectionInfo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field private a:LCi/o$c;

.field private b:LCi/o$b;


# virtual methods
.method public final a()LCi/o;
    .registers 4

    new-instance v0, LCi/i;

    iget-object v1, p0, LCi/i$a;->a:LCi/o$c;

    iget-object v2, p0, LCi/i$a;->b:LCi/o$b;

    invoke-direct {v0, v1, v2}, LCi/i;-><init>(LCi/o$c;LCi/o$b;)V

    return-object v0
.end method

.method public final b(LCi/o$b;)LCi/o$a;
    .registers 2

    iput-object p1, p0, LCi/i$a;->b:LCi/o$b;

    return-object p0
.end method

.method public final c(LCi/o$c;)LCi/o$a;
    .registers 2

    iput-object p1, p0, LCi/i$a;->a:LCi/o$c;

    return-object p0
.end method
