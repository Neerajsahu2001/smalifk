.class final LCi/g$a;
.super LCi/m$a;
.source "AutoValue_LogRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field private a:Ljava/lang/Long;

.field private b:Ljava/lang/Long;

.field private c:LCi/k;

.field private d:Ljava/lang/Integer;

.field private e:Ljava/lang/String;

.field private f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCi/l;",
            ">;"
        }
    .end annotation
.end field

.field private g:LCi/p;


# virtual methods
.method public final a()LCi/m;
    .registers 13

    iget-object v0, p0, LCi/g$a;->a:Ljava/lang/Long;

    if-nez v0, :cond_7

    const-string v0, " requestTimeMs"

    goto :goto_9

    :cond_7
    const-string v0, ""

    :goto_9
    iget-object v1, p0, LCi/g$a;->b:Ljava/lang/Long;

    if-nez v1, :cond_13

    const-string v1, " requestUptimeMs"

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_13
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_36

    new-instance v0, LCi/g;

    iget-object v1, p0, LCi/g$a;->a:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    iget-object v1, p0, LCi/g$a;->b:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    iget-object v7, p0, LCi/g$a;->c:LCi/k;

    iget-object v8, p0, LCi/g$a;->d:Ljava/lang/Integer;

    iget-object v9, p0, LCi/g$a;->e:Ljava/lang/String;

    iget-object v10, p0, LCi/g$a;->f:Ljava/util/List;

    iget-object v11, p0, LCi/g$a;->g:LCi/p;

    move-object v2, v0

    invoke-direct/range {v2 .. v11}, LCi/g;-><init>(JJLCi/k;Ljava/lang/Integer;Ljava/lang/String;Ljava/util/List;LCi/p;)V

    return-object v0

    :cond_36
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Missing required properties:"

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final b(LCi/k;)LCi/m$a;
    .registers 2

    iput-object p1, p0, LCi/g$a;->c:LCi/k;

    return-object p0
.end method

.method public final c(Ljava/util/ArrayList;)LCi/m$a;
    .registers 2

    iput-object p1, p0, LCi/g$a;->f:Ljava/util/List;

    return-object p0
.end method

.method final d(Ljava/lang/Integer;)LCi/m$a;
    .registers 2

    iput-object p1, p0, LCi/g$a;->d:Ljava/lang/Integer;

    return-object p0
.end method

.method final e(Ljava/lang/String;)LCi/m$a;
    .registers 2

    iput-object p1, p0, LCi/g$a;->e:Ljava/lang/String;

    return-object p0
.end method

.method public final f(LCi/p;)LCi/m$a;
    .registers 2

    iput-object p1, p0, LCi/g$a;->g:LCi/p;

    return-object p0
.end method

.method public final g(J)LCi/m$a;
    .registers 3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, p0, LCi/g$a;->a:Ljava/lang/Long;

    return-object p0
.end method

.method public final h(J)LCi/m$a;
    .registers 3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, p0, LCi/g$a;->b:Ljava/lang/Long;

    return-object p0
.end method
