.class public final enum LCi/k$b;
.super Ljava/lang/Enum;
.source "ClientInfo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LCi/k$b;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LCi/k$b;

.field public static final enum ANDROID_FIREBASE:LCi/k$b;

.field public static final enum UNKNOWN:LCi/k$b;


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, LCi/k$b;

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, LCi/k$b;-><init>(Ljava/lang/String;II)V

    sput-object v0, LCi/k$b;->UNKNOWN:LCi/k$b;

    new-instance v1, LCi/k$b;

    const/4 v3, 0x1

    const/16 v4, 0x17

    const-string v5, "ANDROID_FIREBASE"

    invoke-direct {v1, v5, v3, v4}, LCi/k$b;-><init>(Ljava/lang/String;II)V

    sput-object v1, LCi/k$b;->ANDROID_FIREBASE:LCi/k$b;

    const/4 v4, 0x2

    new-array v4, v4, [LCi/k$b;

    aput-object v0, v4, v2

    aput-object v1, v4, v3

    sput-object v4, LCi/k$b;->$VALUES:[LCi/k$b;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, LCi/k$b;->value:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LCi/k$b;
    .registers 2

    const-class v0, LCi/k$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LCi/k$b;

    return-object p0
.end method

.method public static values()[LCi/k$b;
    .registers 1

    sget-object v0, LCi/k$b;->$VALUES:[LCi/k$b;

    invoke-virtual {v0}, [LCi/k$b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LCi/k$b;

    return-object v0
.end method
