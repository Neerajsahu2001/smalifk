.class public abstract LCi/l$a;
.super Ljava/lang/Object;
.source "LogEvent.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCi/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# virtual methods
.method public abstract a()LCi/l;
.end method

.method public abstract b(Ljava/lang/Integer;)LCi/l$a;
.end method

.method public abstract c(J)LCi/l$a;
.end method

.method public abstract d(J)LCi/l$a;
.end method

.method public abstract e(LCi/o;)LCi/l$a;
.end method

.method public abstract f(J)LCi/l$a;
.end method
