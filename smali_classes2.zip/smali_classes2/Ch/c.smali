.class public final LCh/c;
.super LCh/a;
.source "MoqAnnouncement.java"


# instance fields
.field public b:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LCh/a;-><init>()V

    return-void
.end method
