.class public final Lch/b;
.super Ljava/lang/Object;
.source "RegistrationResponse.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:LMe/d2;

.field public b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LLe/f<",
            "LTe/f;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
