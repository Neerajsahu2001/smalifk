.class public final Lbj/a$a;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-auth@@19.2.0"

# interfaces
.implements Lcom/google/android/gms/common/api/Api$ApiOptions$Optional;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbj/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lbj/a$a$a;
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final c:Lbj/a$a;
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation
.end field


# instance fields
.field private final a:Z

.field private final b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lbj/a$a$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object v1, v0, Lbj/a$a$a;->a:Ljava/lang/Boolean;

    new-instance v1, Lbj/a$a;

    invoke-direct {v1, v0}, Lbj/a$a;-><init>(Lbj/a$a$a;)V

    sput-object v1, Lbj/a$a;->c:Lbj/a$a;

    return-void
.end method

.method public constructor <init>(Lbj/a$a$a;)V
    .registers 3
    .param p1    # Lbj/a$a$a;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p1, Lbj/a$a$a;->a:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, p0, Lbj/a$a;->a:Z

    iget-object p1, p1, Lbj/a$a$a;->b:Ljava/lang/String;

    iput-object p1, p0, Lbj/a$a;->b:Ljava/lang/String;

    return-void
.end method

.method static synthetic b(Lbj/a$a;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lbj/a$a;->b:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic c(Lbj/a$a;)Z
    .registers 1

    iget-boolean p0, p0, Lbj/a$a;->a:Z

    return p0
.end method


# virtual methods
.method public final a()Landroid/os/Bundle;
    .registers 4
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    const-string v0, "consumer_package"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroidx/fragment/app/c;->a(Ljava/lang/String;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    const-string v1, "force_save_dialog"

    iget-boolean v2, p0, Lbj/a$a;->a:Z

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v1, "log_session_id"

    iget-object v2, p0, Lbj/a$a;->b:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lbj/a$a;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lbj/a$a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    invoke-static {v1, v1}, Lcom/google/android/gms/common/internal/Objects;->equal(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_27

    iget-boolean v1, p0, Lbj/a$a;->a:Z

    iget-boolean v3, p1, Lbj/a$a;->a:Z

    if-ne v1, v3, :cond_27

    iget-object v1, p0, Lbj/a$a;->b:Ljava/lang/String;

    iget-object p1, p1, Lbj/a$a;->b:Ljava/lang/String;

    invoke-static {v1, p1}, Lcom/google/android/gms/common/internal/Objects;->equal(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_27

    return v0

    :cond_27
    return v2
.end method

.method public final hashCode()I
    .registers 6

    iget-boolean v0, p0, Lbj/a$a;->a:Z

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iget-object v1, p0, Lbj/a$a;->b:Ljava/lang/String;

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const/4 v3, 0x1

    aput-object v0, v2, v3

    const/4 v0, 0x2

    aput-object v1, v2, v0

    invoke-static {v2}, Lcom/google/android/gms/common/internal/Objects;->hashCode([Ljava/lang/Object;)I

    move-result v0

    return v0
.end method
