.class public abstract LBj/i;
.super LAi/b;
.source "com.google.android.gms:play-services-vision@@19.0.0"

# interfaces
.implements LBj/f;


# static fields
.field public static final synthetic a:I
