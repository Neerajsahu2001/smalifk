.class public final LBj/h;
.super Lcom/google/android/gms/internal/vision/m;
.source "com.google.android.gms:play-services-vision@@19.0.0"

# interfaces
.implements LBj/f;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .registers 3

    const-string v0, "com.google.android.gms.vision.face.internal.client.INativeFaceDetectorCreator"

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/internal/vision/m;-><init>(Landroid/os/IBinder;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final a0(Lcom/google/android/gms/dynamic/b;Lcom/google/android/gms/vision/face/internal/client/zzf;)LBj/e;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    invoke-virtual {p0}, Lcom/google/android/gms/internal/vision/m;->e2()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/vision/G;->b(Landroid/os/Parcel;Lcom/google/android/gms/dynamic/b;)V

    invoke-static {v0, p2}, Lcom/google/android/gms/internal/vision/G;->a(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/internal/vision/m;->f2(ILandroid/os/Parcel;)Landroid/os/Parcel;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p2

    if-nez p2, :cond_17

    const/4 p2, 0x0

    goto :goto_2b

    :cond_17
    const-string v0, "com.google.android.gms.vision.face.internal.client.INativeFaceDetector"

    invoke-interface {p2, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    instance-of v1, v0, LBj/e;

    if-eqz v1, :cond_25

    move-object p2, v0

    check-cast p2, LBj/e;

    goto :goto_2b

    :cond_25
    new-instance v0, LBj/g;

    invoke-direct {v0, p2}, LBj/g;-><init>(Landroid/os/IBinder;)V

    move-object p2, v0

    :goto_2b
    invoke-virtual {p1}, Landroid/os/Parcel;->recycle()V

    return-object p2
.end method
