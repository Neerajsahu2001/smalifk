.class public final Lai/j;
.super Ljava/lang/Object;
.source "SeasonResponse.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:Lai/h;

.field public b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lai/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
