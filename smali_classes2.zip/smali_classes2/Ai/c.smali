.class public final Lai/c;
.super Lxk/z;
.source "AssetMetaResponse$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lai/d;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:LJn/a$t;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lai/d;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    const-class v0, Ljava/lang/Object;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$t;

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v2, LJn/a$s;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v1, p1, v2}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lai/c;->a:LJn/a$t;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lai/d;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lai/d;

    invoke-direct {v0}, Lai/d;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3a

    const-string v1, "meta"

    invoke-static {p1, v1}, Landroidx/exifinterface/media/a;->d(LBk/a;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2f

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :cond_2f
    iget-object v1, p0, Lai/c;->a:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Lai/d;->a:Ljava/util/Map;

    goto :goto_1d

    :cond_3a
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lai/c;->read(LBk/a;)Lai/d;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lai/d;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "meta"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lai/d;->a:Ljava/util/Map;

    if-eqz p2, :cond_18

    iget-object v0, p0, Lai/c;->a:LJn/a$t;

    invoke-virtual {v0, p1, p2}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lai/d;

    invoke-virtual {p0, p1, p2}, Lai/c;->write(LBk/c;Lai/d;)V

    return-void
.end method
