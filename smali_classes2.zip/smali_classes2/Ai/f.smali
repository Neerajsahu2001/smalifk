.class public final Lai/f;
.super Lai/l;
.source "EpisodeResponse.java"


# instance fields
.field public m:I

.field public n:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lai/l;-><init>()V

    return-void
.end method
