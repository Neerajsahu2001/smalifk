.class public final Lai/e;
.super Lxk/z;
.source "EpisodeResponse$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lai/f;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lai/f;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lai/f;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lai/e;->b:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 3

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lai/e;->a:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lai/f;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lai/f;

    invoke-direct {v0}, Lai/f;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_189

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_19a

    goto/16 :goto_df

    :sswitch_34
    const-string v2, "bookmarkFrequency"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_df

    :cond_3e
    const/16 v3, 0xd

    goto/16 :goto_df

    :sswitch_42
    const-string v2, "assetType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_df

    :cond_4c
    const/16 v3, 0xc

    goto/16 :goto_df

    :sswitch_50
    const-string v2, "startPosition"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_df

    :cond_5a
    const/16 v3, 0xb

    goto/16 :goto_df

    :sswitch_5e
    const-string v2, "marketplace"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_df

    :cond_68
    const/16 v3, 0xa

    goto/16 :goto_df

    :sswitch_6c
    const-string v2, "mediaEndThreshold"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_df

    :cond_76
    const/16 v3, 0x9

    goto/16 :goto_df

    :sswitch_7a
    const-string v2, "title"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_df

    :cond_84
    const/16 v3, 0x8

    goto/16 :goto_df

    :sswitch_88
    const-string v2, "image"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_91

    goto :goto_df

    :cond_91
    const/4 v3, 0x7

    goto :goto_df

    :sswitch_93
    const-string v2, "parentAssetId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9c

    goto :goto_df

    :cond_9c
    const/4 v3, 0x6

    goto :goto_df

    :sswitch_9e
    const-string v2, "assetId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a7

    goto :goto_df

    :cond_a7
    const/4 v3, 0x5

    goto :goto_df

    :sswitch_a9
    const-string v2, "nowPlaying"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b2

    goto :goto_df

    :cond_b2
    const/4 v3, 0x4

    goto :goto_df

    :sswitch_b4
    const-string v2, "progress"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bd

    goto :goto_df

    :cond_bd
    const/4 v3, 0x3

    goto :goto_df

    :sswitch_bf
    const-string v2, "seasonNumber"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c8

    goto :goto_df

    :cond_c8
    const/4 v3, 0x2

    goto :goto_df

    :sswitch_ca
    const-string v2, "showEpisodes"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d3

    goto :goto_df

    :cond_d3
    const/4 v3, 0x1

    goto :goto_df

    :sswitch_d5
    const-string v2, "mediaStartThreshold"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_de

    goto :goto_df

    :cond_de
    const/4 v3, 0x0

    :goto_df
    packed-switch v3, :pswitch_data_1d4

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_e7
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lai/l;->i:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_f3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lai/l;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_ff
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lai/l;->g:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_10b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lai/l;->l:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_117
    sget-object v1, LJn/a;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Double;

    iput-object v1, v0, Lai/l;->j:Ljava/lang/Double;

    goto/16 :goto_1d

    :pswitch_123
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lai/l;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_12f
    iget-object v1, p0, Lai/e;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, Lai/l;->f:LMe/r1;

    goto/16 :goto_1d

    :pswitch_13b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lai/l;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_147
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lai/l;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_153
    iget-boolean v1, v0, Lai/f;->n:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lai/f;->n:Z

    goto/16 :goto_1d

    :pswitch_15d
    iget v1, v0, Lai/f;->m:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lai/f;->m:I

    goto/16 :goto_1d

    :pswitch_167
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lai/l;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_173
    iget-boolean v1, v0, Lai/l;->h:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lai/l;->h:Z

    goto/16 :goto_1d

    :pswitch_17d
    sget-object v1, LJn/a;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Double;

    iput-object v1, v0, Lai/l;->k:Ljava/lang/Double;

    goto/16 :goto_1d

    :cond_189
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Lai/l;->a:Ljava/lang/String;

    if-eqz p1, :cond_191

    return-object v0

    :cond_191
    new-instance p1, Ljava/io/IOException;

    const-string v0, "assetId cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_19a
    .sparse-switch
        -0x7a8a54d3 -> :sswitch_d5
        -0x58820c0b -> :sswitch_ca
        -0x5118c3f4 -> :sswitch_bf
        -0x3bab3dd3 -> :sswitch_b4
        -0x2f4bff88 -> :sswitch_a9
        -0x2a0207d5 -> :sswitch_9e
        -0xce5abdf -> :sswitch_93
        0x5faa95b -> :sswitch_88
        0x6942258 -> :sswitch_7a
        0x95d4fd4 -> :sswitch_6c
        0x11ef8a4b -> :sswitch_5e
        0x34263fab -> :sswitch_50
        0x4e65f64a -> :sswitch_42
        0x61057cc6 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_1d4
    .packed-switch 0x0
        :pswitch_17d
        :pswitch_173
        :pswitch_167
        :pswitch_15d
        :pswitch_153
        :pswitch_147
        :pswitch_13b
        :pswitch_12f
        :pswitch_123
        :pswitch_117
        :pswitch_10b
        :pswitch_ff
        :pswitch_f3
        :pswitch_e7
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lai/e;->read(LBk/a;)Lai/f;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lai/f;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "assetId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->a:Ljava/lang/String;

    if-eqz v0, :cond_e4

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "parentAssetId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->b:Ljava/lang/String;

    if-eqz v0, :cond_24

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_27

    :cond_24
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_27
    const-string v0, "assetType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->c:Ljava/lang/String;

    if-eqz v0, :cond_34

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_37

    :cond_34
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_37
    const-string v0, "seasonNumber"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->d:Ljava/lang/String;

    if-eqz v0, :cond_44

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_47

    :cond_44
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_47
    const-string v0, "title"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->e:Ljava/lang/String;

    if-eqz v0, :cond_54

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_57

    :cond_54
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_57
    const-string v0, "image"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->f:LMe/r1;

    if-eqz v0, :cond_66

    iget-object v2, p0, Lai/e;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_69

    :cond_66
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_69
    const-string v0, "startPosition"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->g:Ljava/lang/Integer;

    if-eqz v0, :cond_78

    sget-object v2, LJn/a;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_7b

    :cond_78
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_7b
    const-string v0, "showEpisodes"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lai/l;->h:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "bookmarkFrequency"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->i:Ljava/lang/Integer;

    if-eqz v0, :cond_94

    sget-object v2, LJn/a;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_97

    :cond_94
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_97
    const-string v0, "mediaEndThreshold"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->j:Ljava/lang/Double;

    if-eqz v0, :cond_a6

    sget-object v2, LJn/a;->d:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a9

    :cond_a6
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a9
    const-string v0, "mediaStartThreshold"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->k:Ljava/lang/Double;

    if-eqz v0, :cond_b8

    sget-object v2, LJn/a;->d:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_bb

    :cond_b8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_bb
    const-string v0, "marketplace"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lai/l;->l:Ljava/lang/String;

    if-eqz v0, :cond_c8

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_cb

    :cond_c8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_cb
    const-string v0, "progress"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lai/f;->m:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "nowPlaying"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Lai/f;->n:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_e4
    new-instance p1, Ljava/io/IOException;

    const-string p2, "assetId cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lai/f;

    invoke-virtual {p0, p1, p2}, Lai/e;->write(LBk/c;Lai/f;)V

    return-void
.end method
