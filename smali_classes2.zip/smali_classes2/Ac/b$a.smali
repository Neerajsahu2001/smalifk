.class public final LAc/b$a;
.super Ljava/lang/Object;
.source "BinaryFileManagerUtils.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAc/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAc/b$a$a;
    }
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getErrorException(LQ8/b;)Ljava/lang/Exception;
    .registers 4

    instance-of v0, p1, LQ8/b$d;

    if-eqz v0, :cond_37

    check-cast p1, LQ8/b$d;

    invoke-virtual {p1}, LQ8/b$d;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, LQ8/b$d;->getErrorType()LP8/d;

    move-result-object p1

    sget-object v1, LAc/b$a$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v1, p1

    packed-switch p1, :pswitch_data_42

    new-instance p1, LAc/a$d;

    invoke-direct {p1, v0}, LAc/a$d;-><init>(Ljava/lang/String;)V

    goto :goto_41

    :pswitch_1f
    new-instance p1, LAc/a$a;

    invoke-direct {p1, v0}, LAc/a$a;-><init>(Ljava/lang/String;)V

    goto :goto_41

    :pswitch_25
    new-instance p1, LAc/a$e;

    invoke-direct {p1, v0}, LAc/a$e;-><init>(Ljava/lang/String;)V

    goto :goto_41

    :pswitch_2b
    new-instance p1, LAc/a$c;

    invoke-direct {p1, v0}, LAc/a$c;-><init>(Ljava/lang/String;)V

    goto :goto_41

    :pswitch_31
    new-instance p1, LAc/a$f;

    invoke-direct {p1, v0}, LAc/a$f;-><init>(Ljava/lang/String;)V

    goto :goto_41

    :cond_37
    new-instance v0, LAc/a$g;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, LAc/a$g;-><init>(Ljava/lang/String;)V

    move-object p1, v0

    :goto_41
    return-object p1

    :pswitch_data_42
    .packed-switch 0x1
        :pswitch_31
        :pswitch_2b
        :pswitch_2b
        :pswitch_2b
        :pswitch_2b
        :pswitch_25
        :pswitch_1f
        :pswitch_1f
        :pswitch_1f
    .end packed-switch
.end method
