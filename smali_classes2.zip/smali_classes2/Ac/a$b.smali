.class public final LAc/a$b;
.super Ljava/lang/Object;
.source "BinaryFileManagerException.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAc/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getBINARY_FILE_MANAGER_UNAVAILABLE()Ljava/lang/String;
    .registers 2

    invoke-static {}, LAc/a;->access$getBINARY_FILE_MANAGER_UNAVAILABLE$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getUNKNOWN_BUNDLE_FETCH_FAILURE()Ljava/lang/String;
    .registers 2

    invoke-static {}, LAc/a;->access$getUNKNOWN_BUNDLE_FETCH_FAILURE$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
