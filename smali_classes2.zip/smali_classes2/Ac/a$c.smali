.class public final LAc/a$c;
.super LAc/a;
.source "BinaryFileManagerException.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAc/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    const-string v0, "errorMessage"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, LAc/a;-><init>(Ljava/lang/String;Lkotlin/jvm/internal/i;)V

    return-void
.end method
