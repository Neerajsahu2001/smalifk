.class public final LAc/a$g;
.super LAc/a;
.source "BinaryFileManagerException.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAc/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1, v0}, LAc/a$g;-><init>(Ljava/lang/String;ILkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    const-string v0, "errorMessage"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, LAc/a;-><init>(Ljava/lang/String;Lkotlin/jvm/internal/i;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;ILkotlin/jvm/internal/i;)V
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_a

    sget-object p1, LAc/a;->a:LAc/a$b;

    invoke-virtual {p1}, LAc/a$b;->getUNKNOWN_BUNDLE_FETCH_FAILURE()Ljava/lang/String;

    move-result-object p1

    :cond_a
    invoke-direct {p0, p1}, LAc/a$g;-><init>(Ljava/lang/String;)V

    return-void
.end method
