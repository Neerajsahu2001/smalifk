.class public final LC8/d;
.super Ljava/lang/Object;
.source "SizeTimeStrategyFactory.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static createDefault(Landroid/content/Context;Lcom/flipkart/batching/core/data/Tag;Lcom/flipkart/batching/core/SerializationStrategy;)LB8/b;
    .registers 9

    const/4 v3, 0x3

    const-wide/16 v4, 0x2710

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    invoke-static/range {v0 .. v5}, LC8/d;->createWithTapePersistence(Landroid/content/Context;Lcom/flipkart/batching/core/data/Tag;Lcom/flipkart/batching/core/SerializationStrategy;IJ)LB8/b;

    move-result-object p0

    return-object p0
.end method

.method public static createWithInMemoryPersistence(Lcom/flipkart/batching/core/data/Tag;IJ)LB8/b;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Lcom/flipkart/batching/core/Data;",
            ">(",
            "Lcom/flipkart/batching/core/data/Tag;",
            "IJ)",
            "LB8/b;"
        }
    .end annotation

    if-eqz p0, :cond_12

    new-instance v0, LA8/d;

    invoke-direct {v0}, LA8/d;-><init>()V

    new-instance v1, LA8/g;

    invoke-direct {v1, p0, v0}, LA8/g;-><init>(Lcom/flipkart/batching/core/data/Tag;LA8/e;)V

    new-instance p0, LB8/b;

    invoke-direct {p0, v1, p1, p2, p3}, LB8/b;-><init>(LA8/e;IJ)V

    return-object p0

    :cond_12
    new-instance p0, LA8/d;

    invoke-direct {p0}, LA8/d;-><init>()V

    new-instance v0, LB8/b;

    invoke-direct {v0, p0, p1, p2, p3}, LB8/b;-><init>(LA8/e;IJ)V

    return-object v0
.end method

.method public static createWithSQLPersistence(Landroid/content/Context;Lcom/flipkart/batching/core/data/Tag;Lcom/flipkart/batching/core/SerializationStrategy;Ljava/lang/String;IJ)LB8/b;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Lcom/flipkart/batching/core/Data;",
            ">(",
            "Landroid/content/Context;",
            "Lcom/flipkart/batching/core/data/Tag;",
            "Lcom/flipkart/batching/core/SerializationStrategy;",
            "Ljava/lang/String;",
            "IJ)",
            "LB8/b;"
        }
    .end annotation

    if-eqz p1, :cond_12

    new-instance v0, LA8/f;

    invoke-direct {v0, p2, p3, p0}, LA8/f;-><init>(Lcom/flipkart/batching/core/SerializationStrategy;Ljava/lang/String;Landroid/content/Context;)V

    new-instance p0, LA8/g;

    invoke-direct {p0, p1, v0}, LA8/g;-><init>(Lcom/flipkart/batching/core/data/Tag;LA8/e;)V

    new-instance p1, LB8/b;

    invoke-direct {p1, p0, p4, p5, p6}, LB8/b;-><init>(LA8/e;IJ)V

    return-object p1

    :cond_12
    new-instance p1, LA8/f;

    invoke-direct {p1, p2, p3, p0}, LA8/f;-><init>(Lcom/flipkart/batching/core/SerializationStrategy;Ljava/lang/String;Landroid/content/Context;)V

    new-instance p0, LB8/b;

    invoke-direct {p0, p1, p4, p5, p6}, LB8/b;-><init>(LA8/e;IJ)V

    return-object p0
.end method

.method public static createWithTapePersistence(Landroid/content/Context;Lcom/flipkart/batching/core/data/Tag;Lcom/flipkart/batching/core/SerializationStrategy;IJ)LB8/b;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Lcom/flipkart/batching/core/Data;",
            ">(",
            "Landroid/content/Context;",
            "Lcom/flipkart/batching/core/data/Tag;",
            "Lcom/flipkart/batching/core/SerializationStrategy;",
            "IJ)",
            "LB8/b;"
        }
    .end annotation

    new-instance v0, LA8/h;

    invoke-virtual {p1}, Lcom/flipkart/batching/core/data/Tag;->getId()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    const-string v3, "PS"

    invoke-static {v2, p0, v1, v3}, LD/a;->b(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0, p2}, LA8/h;-><init>(Ljava/lang/String;Lcom/flipkart/batching/core/SerializationStrategy;)V

    new-instance p0, LA8/g;

    invoke-direct {p0, p1, v0}, LA8/g;-><init>(Lcom/flipkart/batching/core/data/Tag;LA8/e;)V

    new-instance p1, LB8/b;

    invoke-direct {p1, p0, p3, p4, p5}, LB8/b;-><init>(LA8/e;IJ)V

    return-object p1
.end method

.method public static createWithTapePersistence(Landroid/content/Context;Ljava/lang/String;Lcom/flipkart/batching/core/SerializationStrategy;IJ)LB8/b;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Lcom/flipkart/batching/core/Data;",
            ">(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Lcom/flipkart/batching/core/SerializationStrategy;",
            "IJ)",
            "LB8/b;"
        }
    .end annotation

    new-instance v0, LA8/h;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    const-string v2, "PS"

    invoke-static {v1, p0, p1, v2}, LD/a;->b(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0, p2}, LA8/h;-><init>(Ljava/lang/String;Lcom/flipkart/batching/core/SerializationStrategy;)V

    new-instance p0, LB8/b;

    invoke-direct {p0, v0, p3, p4, p5}, LB8/b;-><init>(LA8/e;IJ)V

    return-object p0
.end method
