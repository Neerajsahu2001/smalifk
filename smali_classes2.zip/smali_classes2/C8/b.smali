.class public final LC8/b;
.super Lcom/flipkart/batching/tape/e;
.source "LenientQueueFile.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LC8/b$a;
    }
.end annotation


# instance fields
.field private final i:LC8/b$a;


# direct methods
.method public constructor <init>(Ljava/io/File;LC8/b$a;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0, p1}, Lcom/flipkart/batching/tape/e;-><init>(Ljava/io/File;)V

    iput-object p2, p0, LC8/b;->i:LC8/b$a;

    return-void
.end method

.method private A(Ljava/lang/Throwable;)V
    .registers 3

    iget-object v0, p0, LC8/b;->i:LC8/b$a;

    if-eqz v0, :cond_7

    invoke-interface {v0, p1}, LC8/b$a;->onQueueFileOperationError(Ljava/lang/Throwable;)V

    :cond_7
    return-void
.end method


# virtual methods
.method public add([B)V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    invoke-super {p0, p1}, Lcom/flipkart/batching/tape/e;->add([B)V
    :try_end_3
    .catchall {:try_start_0 .. :try_end_3} :catchall_4

    goto :goto_8

    :catchall_4
    move-exception p1

    invoke-direct {p0, p1}, LC8/b;->A(Ljava/lang/Throwable;)V

    :goto_8
    return-void
.end method

.method public declared-synchronized add([BII)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0, p1, p2, p3}, Lcom/flipkart/batching/tape/e;->add([BII)V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception p1

    :try_start_6
    invoke-direct {p0, p1}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized clear()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0}, Lcom/flipkart/batching/tape/e;->clear()V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception v0

    :try_start_6
    invoke-direct {p0, v0}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized close()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0}, Lcom/flipkart/batching/tape/e;->close()V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception v0

    :try_start_6
    invoke-direct {p0, v0}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized forEach(Lcom/flipkart/batching/tape/e$f;)I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0, p1}, Lcom/flipkart/batching/tape/e;->forEach(Lcom/flipkart/batching/tape/e$f;)I

    move-result p1
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_7

    monitor-exit p0

    return p1

    :catchall_7
    move-exception p1

    :try_start_8
    invoke-direct {p0, p1}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_b
    .catchall {:try_start_8 .. :try_end_b} :catchall_e

    monitor-exit p0

    const/4 p1, 0x0

    return p1

    :catchall_e
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized forEach(Lcom/flipkart/batching/tape/e$e;)V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0, p1}, Lcom/flipkart/batching/tape/e;->forEach(Lcom/flipkart/batching/tape/e$e;)V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception p1

    :try_start_6
    invoke-direct {p0, p1}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized peek(Lcom/flipkart/batching/tape/e$e;)V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0, p1}, Lcom/flipkart/batching/tape/e;->peek(Lcom/flipkart/batching/tape/e$e;)V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception p1

    :try_start_6
    invoke-direct {p0, p1}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized peek(Lcom/flipkart/batching/tape/e$f;)V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0, p1}, Lcom/flipkart/batching/tape/e;->peek(Lcom/flipkart/batching/tape/e$f;)V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception p1

    :try_start_6
    invoke-direct {p0, p1}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized peek()[B
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0}, Lcom/flipkart/batching/tape/e;->peek()[B

    move-result-object v0
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_7

    monitor-exit p0

    return-object v0

    :catchall_7
    move-exception v0

    :try_start_8
    invoke-direct {p0, v0}, LC8/b;->A(Ljava/lang/Throwable;)V

    const/4 v0, 0x0

    new-array v0, v0, [B
    :try_end_e
    .catchall {:try_start_8 .. :try_end_e} :catchall_10

    monitor-exit p0

    return-object v0

    :catchall_10
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized remove()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0}, Lcom/flipkart/batching/tape/e;->remove()V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception v0

    :try_start_6
    invoke-direct {p0, v0}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized remove(I)V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    invoke-super {p0, p1}, Lcom/flipkart/batching/tape/e;->remove(I)V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception p1

    :try_start_6
    invoke-direct {p0, p1}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_b

    :goto_9
    monitor-exit p0

    return-void

    :catchall_b
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized size()I
    .registers 2

    monitor-enter p0

    :try_start_1
    invoke-super {p0}, Lcom/flipkart/batching/tape/e;->size()I

    move-result v0
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_7

    monitor-exit p0

    return v0

    :catchall_7
    move-exception v0

    :try_start_8
    invoke-direct {p0, v0}, LC8/b;->A(Ljava/lang/Throwable;)V
    :try_end_b
    .catchall {:try_start_8 .. :try_end_b} :catchall_e

    monitor-exit p0

    const/4 v0, 0x0

    return v0

    :catchall_e
    move-exception v0

    monitor-exit p0

    throw v0
.end method
