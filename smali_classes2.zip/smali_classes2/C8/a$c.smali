.class public final Lc8/a$c;
.super Lc8/a;
.source "ChitChatAction.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc8/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field public static final a:Lc8/a$c;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lc8/a$c;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc8/a;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, Lc8/a$c;->a:Lc8/a$c;

    return-void
.end method
