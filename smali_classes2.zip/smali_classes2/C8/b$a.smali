.class public interface abstract LC8/b$a;
.super Ljava/lang/Object;
.source "LenientQueueFile.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LC8/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract onQueueFileOperationError(Ljava/lang/Throwable;)V
.end method
