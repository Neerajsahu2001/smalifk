.class public abstract Lc8/a;
.super Ljava/lang/Object;
.source "ChitChatAction.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc8/a$c;,
        Lc8/a$a;,
        Lc8/a$b;,
        Lc8/a$d;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Lc8/a;-><init>()V

    return-void
.end method
