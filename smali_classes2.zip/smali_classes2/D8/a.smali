.class public final Ld8/a;
.super Ljava/lang/Object;
.source "FlippiContextInterceptor.kt"

# interfaces
.implements Lokhttp3/Interceptor;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld8/a$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String;

.field private static final b:Ljava/lang/String;

.field private static final c:Ljava/lang/String;

.field private static final d:Ljava/lang/String;

.field private static final e:Ljava/lang/String;

.field private static final f:Ljava/lang/String;

.field private static final g:Ljava/lang/String;

.field private static final h:Ljava/lang/String;

.field private static final i:Ljava/lang/String;

.field private static final j:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ld8/a$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld8/a$a;-><init>(Lkotlin/jvm/internal/i;)V

    const-string v0, "conversationId"

    sput-object v0, Ld8/a;->a:Ljava/lang/String;

    const-string v0, "origin"

    sput-object v0, Ld8/a;->b:Ljava/lang/String;

    const-string v0, "chatSession"

    sput-object v0, Ld8/a;->c:Ljava/lang/String;

    const-string v0, "context"

    sput-object v0, Ld8/a;->d:Ljava/lang/String;

    const-string v0, "X-FLIPPI-CONTEXT"

    sput-object v0, Ld8/a;->e:Ljava/lang/String;

    const-string v0, "; "

    sput-object v0, Ld8/a;->f:Ljava/lang/String;

    const-string v0, "="

    sput-object v0, Ld8/a;->g:Ljava/lang/String;

    const-string v0, "URL"

    sput-object v0, Ld8/a;->h:Ljava/lang/String;

    const-string v0, "domain"

    sput-object v0, Ld8/a;->i:Ljava/lang/String;

    const-string v0, "version"

    sput-object v0, Ld8/a;->j:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$getCHAT_SESSION$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->c:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getCONTEXT$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->d:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getCONV_ID$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->a:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getDELIMETER$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->f:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getDOMAIN$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->i:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getEQUAL$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->g:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getFLIPPI_HEADER$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->e:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getORIGIN$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->b:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getURL$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->h:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getVERSION$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, Ld8/a;->j:Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;
    .registers 10

    const-string v0, "chain"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1f

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v0

    if-eqz v0, :cond_18

    iget-boolean v1, v0, Lcom/flipkart/android/configmodel/t2;->o:Z

    :cond_18
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    :cond_1f
    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Request;

    move-result-object v0

    if-nez v1, :cond_2a

    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object p1

    return-object p1

    :cond_2a
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v1

    if-eqz v1, :cond_15a

    iget-object v1, v1, Lcom/flipkart/android/configmodel/t2;->E:Ljava/util/List;

    if-nez v1, :cond_3a

    goto/16 :goto_15a

    :cond_3a
    invoke-virtual {v0}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/HttpUrl;->encodedPath()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4d

    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object p1

    return-object p1

    :cond_4d
    sget-object v1, La8/a;->a:La8/a;

    invoke-virtual {v1}, La8/a;->getAssistPayload()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    move-result-object v1

    if-nez v1, :cond_5a

    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object p1

    return-object p1

    :cond_5a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getConversationId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getOrigin()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getChatSession()Ljava/lang/String;

    move-result-object v5

    sget-object v6, Ld8/a;->a:Ljava/lang/String;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v6, Ld8/a;->g:Ljava/lang/String;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Ld8/a;->f:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v7, Ld8/a;->b:Ljava/lang/String;

    invoke-static {v2, v7, v6, v4, v3}, LDi/q;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sget-object v4, Ld8/a;->c:Ljava/lang/String;

    invoke-static {v2, v4, v6, v5, v3}, LDi/q;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getDomain()Ljava/lang/String;

    move-result-object v4

    const-string v5, ""

    if-nez v4, :cond_90

    move-object v4, v5

    :cond_90
    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getVersion()Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_97

    goto :goto_98

    :cond_97
    move-object v5, v7

    :goto_98
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_a3

    sget-object v7, Ld8/a;->i:Ljava/lang/String;

    invoke-static {v2, v7, v6, v4, v3}, LDi/q;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_a3
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_ae

    sget-object v4, Ld8/a;->j:Ljava/lang/String;

    invoke-static {v2, v4, v6, v5, v3}, LDi/q;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_ae
    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getHeaders()Lxk/s;

    move-result-object v1

    if-eqz v1, :cond_c5

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getInstance()Lcom/flipkart/android/init/FlipkartApplication;

    move-result-object v3

    invoke-virtual {v3}, Lcom/flipkart/android/init/FlipkartApplication;->getSerializer()Lcom/flipkart/android/gson/Serializer;

    move-result-object v3

    invoke-virtual {v1}, Lxk/p;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/flipkart/android/gson/Serializer;->deserializeHashMap$String$String(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v1

    goto :goto_c6

    :cond_c5
    const/4 v1, 0x0

    :goto_c6
    sget-object v3, Lcom/flipkart/android/voice/FlippiRequestInfo;->Companion:Lcom/flipkart/android/voice/FlippiRequestInfo$a;

    invoke-virtual {v3}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v4

    invoke-virtual {v4}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getContext()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_e9

    sget-object v4, Ld8/a;->d:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getContext()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_e9
    invoke-virtual {v0}, Lokhttp3/Request;->newBuilder()Lokhttp3/Request$Builder;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v4, "payloadBuilder.toString()"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_101

    sget-object v4, Ld8/a;->e:Ljava/lang/String;

    invoke-virtual {v3, v4, v2}, Lokhttp3/Request$Builder;->header(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    :cond_101
    if-eqz v1, :cond_148

    sget-object v2, Ld8/a;->h:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-eqz v4, :cond_148

    invoke-virtual {v0}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v5

    if-eqz v5, :cond_148

    invoke-virtual {v0}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/HttpUrl;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v4}, Lvp/k;->w(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_148

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_12c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_148

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v3, v2, v1}, Lokhttp3/Request$Builder;->header(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    goto :goto_12c

    :cond_148
    instance-of v0, v3, Lokhttp3/Request$Builder;

    if-nez v0, :cond_151

    invoke-virtual {v3}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    goto :goto_155

    :cond_151
    invoke-static {v3}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object v0

    :goto_155
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object p1

    return-object p1

    :cond_15a
    :goto_15a
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object p1

    return-object p1
.end method
