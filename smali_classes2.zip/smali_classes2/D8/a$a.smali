.class public final Ld8/a$a;
.super Ljava/lang/Object;
.source "FlippiContextInterceptor.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld8/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getCHAT_SESSION()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getCHAT_SESSION$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getCONTEXT()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getCONTEXT$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getCONV_ID()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getCONV_ID$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getDELIMETER()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getDELIMETER$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getDOMAIN()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getDOMAIN$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getEQUAL()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getEQUAL$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getFLIPPI_HEADER()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getFLIPPI_HEADER$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getORIGIN()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getORIGIN$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getURL()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getURL$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getVERSION()Ljava/lang/String;
    .registers 2

    invoke-static {}, Ld8/a;->access$getVERSION$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
