.class public final Lce/a;
.super Lxk/z;
.source "DigitalFreebie$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lce/b;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lce/b;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/r;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lce/b;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lce/a;->b:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 3

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, LTe/q;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lce/a;->a:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lce/b;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lce/b;

    invoke-direct {v0}, Lce/b;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_79

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_a2

    goto :goto_53

    :sswitch_33
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_53

    :cond_3c
    const/4 v3, 0x2

    goto :goto_53

    :sswitch_3e
    const-string v2, "toastMessage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_53

    :cond_47
    const/4 v3, 0x1

    goto :goto_53

    :sswitch_49
    const-string v2, "priceCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_53

    :cond_52
    const/4 v3, 0x0

    :goto_53
    iget-object v1, p0, Lce/a;->a:Lxk/z;

    packed-switch v3, :pswitch_data_b0

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_5c
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto :goto_1d

    :pswitch_67
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/r;

    iput-object v1, v0, Lce/b;->b:LTe/r;

    goto :goto_1d

    :pswitch_70
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/r;

    iput-object v1, v0, Lce/b;->a:LTe/r;

    goto :goto_1d

    :cond_79
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_99

    iget-object p1, v0, Lce/b;->a:LTe/r;

    if-eqz p1, :cond_91

    iget-object p1, v0, Lce/b;->b:LTe/r;

    if-eqz p1, :cond_89

    return-object v0

    :cond_89
    new-instance p1, Ljava/io/IOException;

    const-string v0, "toastMessage cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_91
    new-instance p1, Ljava/io/IOException;

    const-string v0, "priceCallout cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_99
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_a2
    .sparse-switch
        -0x4c16bd59 -> :sswitch_49
        -0x1b99e820 -> :sswitch_3e
        0x368f3a -> :sswitch_33
    .end sparse-switch

    :pswitch_data_b0
    .packed-switch 0x0
        :pswitch_70
        :pswitch_67
        :pswitch_5c
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lce/a;->read(LBk/a;)Lce/b;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lce/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_45

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "priceCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/b;->a:LTe/r;

    if-eqz v0, :cond_3d

    iget-object v1, p0, Lce/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "toastMessage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lce/b;->b:LTe/r;

    if-eqz p2, :cond_35

    invoke-virtual {v1, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_35
    new-instance p1, Ljava/io/IOException;

    const-string p2, "toastMessage cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3d
    new-instance p1, Ljava/io/IOException;

    const-string p2, "priceCallout cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_45
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lce/b;

    invoke-virtual {p0, p1, p2}, Lce/a;->write(LBk/c;Lce/b;)V

    return-void
.end method
