.class public final Lce/b;
.super LMe/R3;
.source "DigitalFreebie.java"


# instance fields
.field public a:LTe/r;

.field public b:LTe/r;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LMe/R3;-><init>()V

    return-void
.end method
