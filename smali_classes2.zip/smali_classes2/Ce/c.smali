.class public final Lce/c;
.super Lxk/z;
.source "DigitalValue$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lce/d;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/k0;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/Titles;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lce/b;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lde/f;",
            ">;"
        }
    .end annotation
.end field

.field private final e:LJn/a$r;

.field private final f:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lce/d;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, LTe/j0;->i:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lce/c;->a:Lxk/z;

    sget-object v0, Lbh/D;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lce/c;->b:Lxk/z;

    sget-object v0, Lce/a;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lce/c;->c:Lxk/z;

    sget-object v0, Lde/e;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lce/c;->d:Lxk/z;

    sget-object v0, Laf/m;->o:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Lce/c;->e:LJn/a$r;

    sget-object v0, Laf/e;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lce/c;->f:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lce/d;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lce/d;

    invoke-direct {v0}, Lce/d;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1f1

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_23e

    goto/16 :goto_117

    :sswitch_34
    const-string v2, "hideCheckBox"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_117

    :cond_3e
    const/16 v3, 0x11

    goto/16 :goto_117

    :sswitch_42
    const-string v2, "offerSummaries"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_117

    :cond_4c
    const/16 v3, 0x10

    goto/16 :goto_117

    :sswitch_50
    const-string v2, "rateCardId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_117

    :cond_5a
    const/16 v3, 0xf

    goto/16 :goto_117

    :sswitch_5e
    const-string v2, "digitalType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_117

    :cond_68
    const/16 v3, 0xe

    goto/16 :goto_117

    :sswitch_6c
    const-string v2, "hyperlink"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_117

    :cond_76
    const/16 v3, 0xd

    goto/16 :goto_117

    :sswitch_7a
    const-string v2, "checked"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_117

    :cond_84
    const/16 v3, 0xc

    goto/16 :goto_117

    :sswitch_88
    const-string v2, "digitalFreebie"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_117

    :cond_92
    const/16 v3, 0xb

    goto/16 :goto_117

    :sswitch_96
    const-string v2, "showCheckBox"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_117

    :cond_a0
    const/16 v3, 0xa

    goto/16 :goto_117

    :sswitch_a4
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_117

    :cond_ae
    const/16 v3, 0x9

    goto/16 :goto_117

    :sswitch_b2
    const-string v2, "tip"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_117

    :cond_bc
    const/16 v3, 0x8

    goto/16 :goto_117

    :sswitch_c0
    const-string v2, "tag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c9

    goto :goto_117

    :cond_c9
    const/4 v3, 0x7

    goto :goto_117

    :sswitch_cb
    const-string v2, "pricing"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d4

    goto :goto_117

    :cond_d4
    const/4 v3, 0x6

    goto :goto_117

    :sswitch_d6
    const-string v2, "imageUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_df

    goto :goto_117

    :cond_df
    const/4 v3, 0x5

    goto :goto_117

    :sswitch_e1
    const-string v2, "titles"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ea

    goto :goto_117

    :cond_ea
    const/4 v3, 0x4

    goto :goto_117

    :sswitch_ec
    const-string v2, "productId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f5

    goto :goto_117

    :cond_f5
    const/4 v3, 0x3

    goto :goto_117

    :sswitch_f7
    const-string v2, "listingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_100

    goto :goto_117

    :cond_100
    const/4 v3, 0x2

    goto :goto_117

    :sswitch_102
    const-string v2, "description"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10b

    goto :goto_117

    :cond_10b
    const/4 v3, 0x1

    goto :goto_117

    :sswitch_10d
    const-string v2, "bumpUpRates"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_116

    goto :goto_117

    :cond_116
    const/4 v3, 0x0

    :goto_117
    packed-switch v3, :pswitch_data_288

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_11f
    iget-boolean v1, v0, Lce/d;->o:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lce/d;->o:Z

    goto/16 :goto_1d

    :pswitch_129
    iget-object v1, p0, Lce/c;->e:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lce/d;->m:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_135
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_141
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->l:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_14d
    iget-object v1, p0, Lce/c;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lde/f;

    iput-object v1, v0, Lce/d;->k:Lde/f;

    goto/16 :goto_1d

    :pswitch_159
    iget-boolean v1, v0, Lce/d;->a:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lce/d;->a:Z

    goto/16 :goto_1d

    :pswitch_163
    iget-object v1, p0, Lce/c;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lce/b;

    iput-object v1, v0, Lce/d;->f:Lce/b;

    goto/16 :goto_1d

    :pswitch_16f
    iget-boolean v1, v0, Lce/d;->b:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lce/d;->b:Z

    goto/16 :goto_1d

    :pswitch_179
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_185
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->i:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_191
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->j:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_19d
    iget-object v1, p0, Lce/c;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/k0;

    iput-object v1, v0, Lce/d;->d:LTe/k0;

    goto/16 :goto_1d

    :pswitch_1a9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->n:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1b5
    iget-object v1, p0, Lce/c;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/Titles;

    iput-object v1, v0, Lce/d;->e:Lcom/flipkart/rome/datatypes/response/product/Titles;

    goto/16 :goto_1d

    :pswitch_1c1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1cd
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1d9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lce/d;->p:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1e5
    iget-object v1, p0, Lce/c;->f:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lce/d;->q:Ljava/util/List;

    goto/16 :goto_1d

    :cond_1f1
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_235

    iget-object p1, v0, Lce/d;->e:Lcom/flipkart/rome/datatypes/response/product/Titles;

    if-eqz p1, :cond_22d

    iget-object p1, v0, Lce/d;->g:Ljava/lang/String;

    if-eqz p1, :cond_225

    iget-object p1, v0, Lce/d;->h:Ljava/lang/String;

    if-eqz p1, :cond_21d

    iget-object p1, v0, Lce/d;->l:Ljava/lang/String;

    if-eqz p1, :cond_215

    iget-object p1, v0, Lce/d;->n:Ljava/lang/String;

    if-eqz p1, :cond_20d

    return-object v0

    :cond_20d
    new-instance p1, Ljava/io/IOException;

    const-string v0, "imageUrl cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_215
    new-instance p1, Ljava/io/IOException;

    const-string v0, "digitalType cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_21d
    new-instance p1, Ljava/io/IOException;

    const-string v0, "productId cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_225
    new-instance p1, Ljava/io/IOException;

    const-string v0, "listingId cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_22d
    new-instance p1, Ljava/io/IOException;

    const-string v0, "titles cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_235
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_23e
    .sparse-switch
        -0x72fa285e -> :sswitch_10d
        -0x66ca7c04 -> :sswitch_102
        -0x486bcd41 -> :sswitch_f7
        -0x3eb1a996 -> :sswitch_ec
        -0x340fd6e5 -> :sswitch_e1
        -0x333c9dec -> :sswitch_d6
        -0x12c7603a -> :sswitch_cb
        0x1bf9a -> :sswitch_c0
        0x1c09b -> :sswitch_b2
        0x368f3a -> :sswitch_a4
        0x28d295c0 -> :sswitch_96
        0x2a16ddda -> :sswitch_88
        0x2c3ecfa7 -> :sswitch_7a
        0x2cc7d866 -> :sswitch_6c
        0x424c2572 -> :sswitch_5e
        0x5f61114b -> :sswitch_50
        0x60c313c8 -> :sswitch_42
        0x7d1d8305 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_288
    .packed-switch 0x0
        :pswitch_1e5
        :pswitch_1d9
        :pswitch_1cd
        :pswitch_1c1
        :pswitch_1b5
        :pswitch_1a9
        :pswitch_19d
        :pswitch_191
        :pswitch_185
        :pswitch_179
        :pswitch_16f
        :pswitch_163
        :pswitch_159
        :pswitch_14d
        :pswitch_141
        :pswitch_135
        :pswitch_129
        :pswitch_11f
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lce/c;->read(LBk/a;)Lce/d;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lce/d;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_143

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "checked"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lce/d;->a:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "showCheckBox"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lce/d;->b:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "rateCardId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->c:Ljava/lang/String;

    if-eqz v0, :cond_38

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3b

    :cond_38
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3b
    const-string v0, "pricing"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->d:LTe/k0;

    if-eqz v0, :cond_4a

    iget-object v2, p0, Lce/c;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_4d

    :cond_4a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_4d
    const-string v0, "titles"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->e:Lcom/flipkart/rome/datatypes/response/product/Titles;

    if-eqz v0, :cond_13b

    iget-object v2, p0, Lce/c;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "digitalFreebie"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->f:Lce/b;

    if-eqz v0, :cond_6a

    iget-object v2, p0, Lce/c;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_6d

    :cond_6a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_6d
    const-string v0, "listingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->g:Ljava/lang/String;

    if-eqz v0, :cond_133

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "productId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->h:Ljava/lang/String;

    if-eqz v0, :cond_12b

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "tip"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->i:Ljava/lang/String;

    if-eqz v0, :cond_92

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_95

    :cond_92
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_95
    const-string v0, "tag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->j:Ljava/lang/String;

    if-eqz v0, :cond_a2

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a5

    :cond_a2
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a5
    const-string v0, "hyperlink"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->k:Lde/f;

    if-eqz v0, :cond_b4

    iget-object v2, p0, Lce/c;->d:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_b7

    :cond_b4
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_b7
    const-string v0, "digitalType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->l:Ljava/lang/String;

    if-eqz v0, :cond_123

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "offerSummaries"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->m:Ljava/util/List;

    if-eqz v0, :cond_d7

    iget-object v2, p0, Lce/c;->e:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_da

    :cond_d7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_da
    const-string v0, "imageUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->n:Ljava/lang/String;

    if-eqz v0, :cond_11b

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "hideCheckBox"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lce/d;->o:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "description"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lce/d;->p:Ljava/lang/String;

    if-eqz v0, :cond_fd

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_100

    :cond_fd
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_100
    const-string v0, "bumpUpRates"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lce/d;->q:Ljava/util/List;

    if-eqz p2, :cond_114

    iget-object v0, p0, Lce/c;->f:LJn/a$r;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/util/Collection;

    invoke-virtual {v0, p1, p2}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_117

    :cond_114
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_117
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_11b
    new-instance p1, Ljava/io/IOException;

    const-string p2, "imageUrl cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_123
    new-instance p1, Ljava/io/IOException;

    const-string p2, "digitalType cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_12b
    new-instance p1, Ljava/io/IOException;

    const-string p2, "productId cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_133
    new-instance p1, Ljava/io/IOException;

    const-string p2, "listingId cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_13b
    new-instance p1, Ljava/io/IOException;

    const-string p2, "titles cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_143
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lce/d;

    invoke-virtual {p0, p1, p2}, Lce/c;->write(LBk/c;Lce/d;)V

    return-void
.end method
