.class public final LBa/b;
.super Ljava/lang/Object;
.source "ResponseWrapperResponseProcessor.java"

# interfaces
.implements Lta/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lta/d<",
        "LGe/e0<",
        "TT;>;",
        "LGe/e0<",
        "TE;>;>;"
    }
.end annotation


# instance fields
.field private a:Lva/e;

.field private b:Lretrofit2/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lretrofit2/j<",
            "Lokhttp3/ResponseBody;",
            "LGe/e0<",
            "TE;>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lva/e;Lretrofit2/j;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lva/e;",
            "Lretrofit2/j<",
            "Lokhttp3/ResponseBody;",
            "LGe/e0<",
            "TE;>;>;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LBa/b;->a:Lva/e;

    iput-object p2, p0, LBa/b;->b:Lretrofit2/j;

    return-void
.end method


# virtual methods
.method public checkResponseForError(Lretrofit2/F;Lva/a;)Lwa/a;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "TT;>;>;",
            "Lva/a;",
            ")",
            "Lwa/a<",
            "LGe/e0<",
            "TE;>;>;"
        }
    .end annotation

    invoke-static {p1}, Lwa/b;->generateCustomErrorInfo(Lretrofit2/F;)Lwa/a;

    move-result-object v0

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    invoke-static {p1}, Lwa/b;->generateErrorInfo(Lretrofit2/F;)Lwa/a;

    move-result-object v0

    iget-object v1, p0, LBa/b;->a:Lva/e;

    if-nez v0, :cond_8a

    invoke-virtual {p1}, Lretrofit2/F;->b()I

    move-result v2

    const/16 v3, 0xc8

    if-eq v2, v3, :cond_25

    const/16 v3, 0xca

    if-ne v2, v3, :cond_1c

    goto :goto_25

    :cond_1c
    new-instance v0, Lwa/a;

    const/16 p1, 0x8

    invoke-direct {v0, v2, p1}, Lwa/a;-><init>(II)V

    goto/16 :goto_ac

    :cond_25
    :goto_25
    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_2d

    goto/16 :goto_ac

    :cond_2d
    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LGe/e0;

    iget-object v3, v2, LGe/e0;->a:Ljava/lang/Object;

    instance-of v4, v3, LMa/b;

    if-eqz v4, :cond_40

    check-cast v3, LMa/b;

    iget-object v2, v2, LGe/e0;->c:Ljava/lang/String;

    invoke-virtual {v3, v2}, LMa/b;->setRequestId(Ljava/lang/String;)V

    :cond_40
    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LGe/e0;

    iget-object v2, v2, LGe/e0;->i:Lcom/flipkart/rome/datatypes/response/session/v1/SessionResponse;

    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LGe/e0;

    iget-object v3, v3, LGe/e0;->a:Ljava/lang/Object;

    if-eqz v2, :cond_57

    instance-of v3, v3, LOh/b;

    invoke-interface {v1, v2, v3}, Lva/e;->onSessionUpdate(Lcom/flipkart/rome/datatypes/response/session/v1/SessionResponse;Z)V

    :cond_57
    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/e0;

    iget-object v1, v1, LGe/e0;->b:LGe/I;

    if-eqz v1, :cond_74

    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/e0;

    iget-object v1, v1, LGe/e0;->b:LGe/I;

    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LGe/e0;

    iget-object v2, v2, LGe/e0;->a:Ljava/lang/Object;

    invoke-interface {p2, v1, v2}, Lva/a;->onResponseMetaInfoReceived(LGe/I;Ljava/lang/Object;)V

    :cond_74
    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/e0;

    iget-object v1, v1, LGe/e0;->j:LJh/b;

    if-eqz v1, :cond_ac

    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LGe/e0;

    iget-object p1, p1, LGe/e0;->j:LJh/b;

    invoke-interface {p2, p1}, Lva/a;->onUPINPCIInfoReceived(LJh/b;)V

    goto :goto_ac

    :cond_8a
    if-eqz p1, :cond_ac

    invoke-virtual {p1}, Lretrofit2/F;->f()Z

    move-result p2

    if-nez p2, :cond_ac

    invoke-virtual {p1}, Lretrofit2/F;->b()I

    move-result p2

    invoke-virtual {p1}, Lretrofit2/F;->d()Lokhttp3/ResponseBody;

    move-result-object p1

    :try_start_9a
    iget-object v0, p0, LBa/b;->b:Lretrofit2/j;

    invoke-interface {v0, p1}, Lretrofit2/j;->convert(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LGe/e0;
    :try_end_a2
    .catch Ljava/lang/Exception; {:try_start_9a .. :try_end_a2} :catch_a3

    goto :goto_a8

    :catch_a3
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    :goto_a8
    invoke-static {p1, v1, p2}, Lwa/b;->generateErrorInfo(LGe/e0;Lva/e;I)Lwa/a;

    move-result-object v0

    :cond_ac
    :goto_ac
    return-object v0
.end method
