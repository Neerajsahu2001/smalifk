.class public final LBa/a;
.super Ljava/lang/Object;
.source "DefaultResponseProcessor.java"

# interfaces
.implements Lta/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lta/d<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LBa/a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LBa/a;

    invoke-direct {v0}, LBa/a;-><init>()V

    sput-object v0, LBa/a;->a:LBa/a;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public checkResponseForError(Lretrofit2/F;Lva/a;)Lwa/a;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "Ljava/lang/Object;",
            ">;",
            "Lva/a;",
            ")",
            "Lwa/a<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    invoke-static {p1}, Lwa/b;->generateErrorInfo(Lretrofit2/F;)Lwa/a;

    move-result-object p1

    return-object p1
.end method
