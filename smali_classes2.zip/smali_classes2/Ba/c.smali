.class public final LBa/c;
.super Ljava/lang/Object;
.source "ResponseWrapperResponseProcessorFactory.java"

# interfaces
.implements Lta/e;


# instance fields
.field private a:Lva/e;

.field private b:Lxk/j;


# direct methods
.method public constructor <init>(Lxk/j;Lva/e;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LBa/c;->a:Lva/e;

    iput-object p1, p0, LBa/c;->b:Lxk/j;

    return-void
.end method


# virtual methods
.method public getInstance(Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)LBa/b;
    .registers 6

    invoke-static {p1}, Lcom/flipkart/mapi/client/converter/k;->getRawType(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    move-result-object v0

    invoke-static {p2}, Lcom/flipkart/mapi/client/converter/k;->getRawType(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    move-result-object v1

    const-class v2, LGe/e0;

    invoke-virtual {v2, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_2f

    invoke-virtual {v2, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_2f

    const-class v0, LJa/C;

    iget-object v1, p0, LBa/c;->b:Lxk/j;

    if-ne p1, v0, :cond_22

    new-instance p1, Lcom/flipkart/mapi/client/converter/e;

    invoke-direct {p1, v1, p2}, Lcom/flipkart/mapi/client/converter/e;-><init>(Lxk/j;Ljava/lang/reflect/Type;)V

    goto :goto_27

    :cond_22
    new-instance p1, Lcom/flipkart/mapi/client/converter/g;

    invoke-direct {p1, v1, p2}, Lcom/flipkart/mapi/client/converter/g;-><init>(Lxk/j;Ljava/lang/reflect/Type;)V

    :goto_27
    new-instance p2, LBa/b;

    iget-object v0, p0, LBa/c;->a:Lva/e;

    invoke-direct {p2, v0, p1}, LBa/b;-><init>(Lva/e;Lretrofit2/j;)V

    return-object p2

    :cond_2f
    const/4 p1, 0x0

    return-object p1
.end method

.method public bridge synthetic getInstance(Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)Lta/d;
    .registers 3

    invoke-virtual {p0, p1, p2}, LBa/c;->getInstance(Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)LBa/b;

    move-result-object p1

    return-object p1
.end method
