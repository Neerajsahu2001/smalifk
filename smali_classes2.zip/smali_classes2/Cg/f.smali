.class public final Lcg/f;
.super Ljava/lang/Object;
.source "DegradationResponseContext.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:Ljg/y;

.field public b:Lcg/d;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
