.class public final Lcg/a;
.super Lxk/z;
.source "ActionPageResponse$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcg/b;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Ljg/y;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcg/d;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Leg/l;",
            ">;"
        }
    .end annotation
.end field

.field private final d:LJn/a$t;

.field private final e:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcg/f;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcg/b;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Ljg/x;->f:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lcg/a;->a:Lxk/z;

    sget-object v0, Lcg/c;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lcg/a;->b:Lxk/z;

    sget-object v0, Leg/k;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lcg/a;->c:Lxk/z;

    sget-object v0, Ljg/k;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$t;

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v3, LJn/a$s;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v2, v0, v3}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Lcg/a;->d:LJn/a$t;

    sget-object v0, Lcg/e;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lcg/a;->e:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcg/b;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcg/b;

    invoke-direct {v0}, Lcg/b;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_125

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_12a

    goto/16 :goto_a7

    :sswitch_34
    const-string v2, "successMessage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_a7

    :cond_3e
    const/16 v3, 0x9

    goto/16 :goto_a7

    :sswitch_42
    const-string v2, "errorMessage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_a7

    :cond_4c
    const/16 v3, 0x8

    goto/16 :goto_a7

    :sswitch_50
    const-string v2, "degradationContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_59

    goto :goto_a7

    :cond_59
    const/4 v3, 0x7

    goto :goto_a7

    :sswitch_5b
    const-string v2, "actionResponseContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_64

    goto :goto_a7

    :cond_64
    const/4 v3, 0x6

    goto :goto_a7

    :sswitch_66
    const-string v2, "trackingContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6f

    goto :goto_a7

    :cond_6f
    const/4 v3, 0x5

    goto :goto_a7

    :sswitch_71
    const-string v2, "errorCode"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7a

    goto :goto_a7

    :cond_7a
    const/4 v3, 0x4

    goto :goto_a7

    :sswitch_7c
    const-string v2, "actionSuccess"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_85

    goto :goto_a7

    :cond_85
    const/4 v3, 0x3

    goto :goto_a7

    :sswitch_87
    const-string v2, "marketPlaceTrackingDataMap"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_90

    goto :goto_a7

    :cond_90
    const/4 v3, 0x2

    goto :goto_a7

    :sswitch_92
    const-string v2, "degradedExperience"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9b

    goto :goto_a7

    :cond_9b
    const/4 v3, 0x1

    goto :goto_a7

    :sswitch_9d
    const-string v2, "pageResponse"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a6

    goto :goto_a7

    :cond_a6
    const/4 v3, 0x0

    :goto_a7
    packed-switch v3, :pswitch_data_154

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_af
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcg/b;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_bb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcg/b;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_c7
    iget-object v1, p0, Lcg/a;->e:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcg/f;

    iput-object v1, v0, Lcg/b;->j:Lcg/f;

    goto/16 :goto_1d

    :pswitch_d3
    iget-object v1, p0, Lcg/a;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcg/d;

    iput-object v1, v0, Lcg/b;->f:Lcg/d;

    goto/16 :goto_1d

    :pswitch_df
    iget-object v1, p0, Lcg/a;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Leg/l;

    iput-object v1, v0, Lcg/b;->g:Leg/l;

    goto/16 :goto_1d

    :pswitch_eb
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lcg/b;->e:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_f7
    iget-boolean v1, v0, Lcg/b;->b:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcg/b;->b:Z

    goto/16 :goto_1d

    :pswitch_101
    iget-object v1, p0, Lcg/a;->d:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Lcg/b;->h:Ljava/util/Map;

    goto/16 :goto_1d

    :pswitch_10d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Lcg/b;->i:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_119
    iget-object v1, p0, Lcg/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljg/y;

    iput-object v1, v0, Lcg/b;->a:Ljg/y;

    goto/16 :goto_1d

    :cond_125
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_12a
    .sparse-switch
        -0x7f822410 -> :sswitch_9d
        -0x3a3d48c8 -> :sswitch_92
        -0x38a3eb10 -> :sswitch_87
        -0x1c8bef13 -> :sswitch_7c
        0x139cb015 -> :sswitch_71
        0x302f02f8 -> :sswitch_66
        0x3182e518 -> :sswitch_5b
        0x3e0bb4c9 -> :sswitch_50
        0x47b7ecdf -> :sswitch_42
        0x48a9de84 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_154
    .packed-switch 0x0
        :pswitch_119
        :pswitch_10d
        :pswitch_101
        :pswitch_f7
        :pswitch_eb
        :pswitch_df
        :pswitch_d3
        :pswitch_c7
        :pswitch_bb
        :pswitch_af
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcg/a;->read(LBk/a;)Lcg/b;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcg/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "pageResponse"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->a:Ljg/y;

    if-eqz v0, :cond_18

    iget-object v1, p0, Lcg/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "actionSuccess"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcg/b;->b:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "successMessage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->c:Ljava/lang/String;

    if-eqz v0, :cond_34

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_37

    :cond_34
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_37
    const-string v0, "errorMessage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->d:Ljava/lang/String;

    if-eqz v0, :cond_46

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_49

    :cond_46
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_49
    const-string v0, "errorCode"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->e:Ljava/lang/Integer;

    if-eqz v0, :cond_58

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_5b

    :cond_58
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_5b
    const-string v0, "actionResponseContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->f:Lcg/d;

    if-eqz v0, :cond_6a

    iget-object v1, p0, Lcg/a;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_6d

    :cond_6a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_6d
    const-string v0, "trackingContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->g:Leg/l;

    if-eqz v0, :cond_7c

    iget-object v1, p0, Lcg/a;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_7f

    :cond_7c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_7f
    const-string v0, "marketPlaceTrackingDataMap"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->h:Ljava/util/Map;

    if-eqz v0, :cond_8e

    iget-object v1, p0, Lcg/a;->d:LJn/a$t;

    invoke-virtual {v1, p1, v0}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_91

    :cond_8e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_91
    const-string v0, "degradedExperience"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcg/b;->i:Ljava/lang/Boolean;

    if-eqz v0, :cond_a0

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a3

    :cond_a0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a3
    const-string v0, "degradationContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcg/b;->j:Lcg/f;

    if-eqz p2, :cond_b2

    iget-object v0, p0, Lcg/a;->e:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_b5

    :cond_b2
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_b5
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcg/b;

    invoke-virtual {p0, p1, p2}, Lcg/a;->write(LBk/c;Lcg/b;)V

    return-void
.end method
