.class public final Lab/a;
.super Lxk/z;
.source "TrackingParams$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lab/b;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lab/b;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/mapi/model/discovery/r;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lab/b;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lab/a;->b:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 3

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Lcom/flipkart/mapi/model/discovery/q;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lab/a;->a:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lab/b;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lab/b;

    invoke-direct {v0}, Lab/b;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_59b

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_5a0

    goto/16 :goto_30f

    :sswitch_34
    const-string v2, "channelId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_30f

    :cond_3e
    const/16 v3, 0x35

    goto/16 :goto_30f

    :sswitch_42
    const-string v2, "dataKey"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_30f

    :cond_4c
    const/16 v3, 0x34

    goto/16 :goto_30f

    :sswitch_50
    const-string v2, "widgetCategory"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_30f

    :cond_5a
    const/16 v3, 0x33

    goto/16 :goto_30f

    :sswitch_5e
    const-string v2, "dgPageType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_30f

    :cond_68
    const/16 v3, 0x32

    goto/16 :goto_30f

    :sswitch_6c
    const-string v2, "dgPageName"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_30f

    :cond_76
    const/16 v3, 0x31

    goto/16 :goto_30f

    :sswitch_7a
    const-string v2, "semcmpid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_30f

    :cond_84
    const/16 v3, 0x30

    goto/16 :goto_30f

    :sswitch_88
    const-string v2, "errorContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_30f

    :cond_92
    const/16 v3, 0x2f

    goto/16 :goto_30f

    :sswitch_96
    const-string v2, "viewType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_30f

    :cond_a0
    const/16 v3, 0x2e

    goto/16 :goto_30f

    :sswitch_a4
    const-string v2, "trackingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_30f

    :cond_ae
    const/16 v3, 0x2d

    goto/16 :goto_30f

    :sswitch_b2
    const-string v2, "module_position"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_30f

    :cond_bc
    const/16 v3, 0x2c

    goto/16 :goto_30f

    :sswitch_c0
    const-string v2, "pageType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ca

    goto/16 :goto_30f

    :cond_ca
    const/16 v3, 0x2b

    goto/16 :goto_30f

    :sswitch_ce
    const-string v2, "notificationId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d8

    goto/16 :goto_30f

    :cond_d8
    const/16 v3, 0x2a

    goto/16 :goto_30f

    :sswitch_dc
    const-string v2, "position"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e6

    goto/16 :goto_30f

    :cond_e6
    const/16 v3, 0x29

    goto/16 :goto_30f

    :sswitch_ea
    const-string v2, "event639"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f4

    goto/16 :goto_30f

    :cond_f4
    const/16 v3, 0x28

    goto/16 :goto_30f

    :sswitch_f8
    const-string v2, "event638"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_102

    goto/16 :goto_30f

    :cond_102
    const/16 v3, 0x27

    goto/16 :goto_30f

    :sswitch_106
    const-string v2, "announcement"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_110

    goto/16 :goto_30f

    :cond_110
    const/16 v3, 0x26

    goto/16 :goto_30f

    :sswitch_114
    const-string v2, "store"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11e

    goto/16 :goto_30f

    :cond_11e
    const/16 v3, 0x25

    goto/16 :goto_30f

    :sswitch_122
    const-string v2, "offer"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12c

    goto/16 :goto_30f

    :cond_12c
    const/16 v3, 0x24

    goto/16 :goto_30f

    :sswitch_130
    const-string v2, "ef_id"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13a

    goto/16 :goto_30f

    :cond_13a
    const/16 v3, 0x23

    goto/16 :goto_30f

    :sswitch_13e
    const-string v2, "eVar3"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_148

    goto/16 :goto_30f

    :cond_148
    const/16 v3, 0x22

    goto/16 :goto_30f

    :sswitch_14c
    const-string v2, "cmpid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_156

    goto/16 :goto_30f

    :cond_156
    const/16 v3, 0x21

    goto/16 :goto_30f

    :sswitch_15a
    const-string v2, "affid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_164

    goto/16 :goto_30f

    :cond_164
    const/16 v3, 0x20

    goto/16 :goto_30f

    :sswitch_168
    const-string v2, "pev2"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_172

    goto/16 :goto_30f

    :cond_172
    const/16 v3, 0x1f

    goto/16 :goto_30f

    :sswitch_176
    const-string v2, "disp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_180

    goto/16 :goto_30f

    :cond_180
    const/16 v3, 0x1e

    goto/16 :goto_30f

    :sswitch_184
    const-string v2, "baseImpressionId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18e

    goto/16 :goto_30f

    :cond_18e
    const/16 v3, 0x1d

    goto/16 :goto_30f

    :sswitch_192
    const-string v2, "impressionId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19c

    goto/16 :goto_30f

    :cond_19c
    const/16 v3, 0x1c

    goto/16 :goto_30f

    :sswitch_1a0
    const-string v2, "sProduct"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1aa

    goto/16 :goto_30f

    :cond_1aa
    const/16 v3, 0x1b

    goto/16 :goto_30f

    :sswitch_1ae
    const-string v2, "contextType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b8

    goto/16 :goto_30f

    :cond_1b8
    const/16 v3, 0x1a

    goto/16 :goto_30f

    :sswitch_1bc
    const-string v2, "useBaseImpression"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1c6

    goto/16 :goto_30f

    :cond_1c6
    const/16 v3, 0x19

    goto/16 :goto_30f

    :sswitch_1ca
    const-string v2, "parentType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d4

    goto/16 :goto_30f

    :cond_1d4
    const/16 v3, 0x18

    goto/16 :goto_30f

    :sswitch_1d8
    const-string v2, "widgetType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e2

    goto/16 :goto_30f

    :cond_1e2
    const/16 v3, 0x17

    goto/16 :goto_30f

    :sswitch_1e6
    const-string v2, "omnitureDataValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f0

    goto/16 :goto_30f

    :cond_1f0
    const/16 v3, 0x16

    goto/16 :goto_30f

    :sswitch_1f4
    const-string v2, "hasBundleOffer"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1fe

    goto/16 :goto_30f

    :cond_1fe
    const/16 v3, 0x15

    goto/16 :goto_30f

    :sswitch_202
    const-string v2, "contentType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20c

    goto/16 :goto_30f

    :cond_20c
    const/16 v3, 0x14

    goto/16 :goto_30f

    :sswitch_210
    const-string v2, "contentId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_21a

    goto/16 :goto_30f

    :cond_21a
    const/16 v3, 0x13

    goto/16 :goto_30f

    :sswitch_21e
    const-string v2, "widgetKey"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_228

    goto/16 :goto_30f

    :cond_228
    const/16 v3, 0x12

    goto/16 :goto_30f

    :sswitch_22c
    const-string v2, "moduleId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_236

    goto/16 :goto_30f

    :cond_236
    const/16 v3, 0x11

    goto/16 :goto_30f

    :sswitch_23a
    const-string v2, "findingMethod"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_244

    goto/16 :goto_30f

    :cond_244
    const/16 v3, 0x10

    goto/16 :goto_30f

    :sswitch_248
    const-string v2, "preferredSeller"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_252

    goto/16 :goto_30f

    :cond_252
    const/16 v3, 0xf

    goto/16 :goto_30f

    :sswitch_256
    const-string v2, "referrer"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_260

    goto/16 :goto_30f

    :cond_260
    const/16 v3, 0xe

    goto/16 :goto_30f

    :sswitch_264
    const-string v2, "otracker"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_26e

    goto/16 :goto_30f

    :cond_26e
    const/16 v3, 0xd

    goto/16 :goto_30f

    :sswitch_272
    const-string v2, "source"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_27c

    goto/16 :goto_30f

    :cond_27c
    const/16 v3, 0xc

    goto/16 :goto_30f

    :sswitch_280
    const-string v2, "widgetTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_28a

    goto/16 :goto_30f

    :cond_28a
    const/16 v3, 0xb

    goto/16 :goto_30f

    :sswitch_28e
    const-string v2, "prop74"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_298

    goto/16 :goto_30f

    :cond_298
    const/16 v3, 0xa

    goto/16 :goto_30f

    :sswitch_29c
    const-string v2, "ocmpid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2a6

    goto/16 :goto_30f

    :cond_2a6
    const/16 v3, 0x9

    goto/16 :goto_30f

    :sswitch_2aa
    const-string v2, "title_primary"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b4

    goto/16 :goto_30f

    :cond_2b4
    const/16 v3, 0x8

    goto/16 :goto_30f

    :sswitch_2b8
    const-string v2, "icmpid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c1

    goto :goto_30f

    :cond_2c1
    const/4 v3, 0x7

    goto :goto_30f

    :sswitch_2c3
    const-string v2, "eVar50"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2cc

    goto :goto_30f

    :cond_2cc
    const/4 v3, 0x6

    goto :goto_30f

    :sswitch_2ce
    const-string v2, "lockin_tracking"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2d7

    goto :goto_30f

    :cond_2d7
    const/4 v3, 0x5

    goto :goto_30f

    :sswitch_2d9
    const-string v2, "bottomsheetSource"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2e2

    goto :goto_30f

    :cond_2e2
    const/4 v3, 0x4

    goto :goto_30f

    :sswitch_2e4
    const-string v2, "otracker1"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2ed

    goto :goto_30f

    :cond_2ed
    const/4 v3, 0x3

    goto :goto_30f

    :sswitch_2ef
    const-string v2, "omnitureData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2f8

    goto :goto_30f

    :cond_2f8
    const/4 v3, 0x2

    goto :goto_30f

    :sswitch_2fa
    const-string v2, "widgetPageName"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_303

    goto :goto_30f

    :cond_303
    const/4 v3, 0x1

    goto :goto_30f

    :sswitch_305
    const-string v2, "start_url"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_30e

    goto :goto_30f

    :cond_30e
    const/4 v3, 0x0

    :goto_30f
    packed-switch v3, :pswitch_data_67a

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_317
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->q:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_323
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->R:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_32f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->S:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_33b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->A:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_347
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->z:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_353
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_35f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->L:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_36b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->W:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_377
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->v:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_383
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->t:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_38f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->o:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_39b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3a7
    iget v1, v0, Lab/b;->u:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lab/b;->u:I

    goto/16 :goto_1d

    :pswitch_3b1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->z0:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3bd
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->B0:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3c9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->y:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3d5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->Y:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3e1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->m:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3ed
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->D:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3f9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->E0:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_405
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_411
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_41d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->C0:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_429
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_435
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->E:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_441
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->p:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_44d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->G:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_459
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->T:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_465
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->F:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_471
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->B:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_47d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_489
    iget-object v1, p0, Lab/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/mapi/model/discovery/r;

    iput-object v1, v0, Lab/b;->r:Lcom/flipkart/mapi/model/discovery/r;

    goto/16 :goto_1d

    :pswitch_495
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->J:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4a1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->x:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4ad
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->j:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4b9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->C:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4c5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->s:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4d1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->w:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4dd
    iget-boolean v1, v0, Lab/b;->K:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lab/b;->K:Z

    goto/16 :goto_1d

    :pswitch_4e7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->n:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4f3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->k:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4ff
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->H:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_50b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->X:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_517
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->A0:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_523
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_52f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->I:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_53b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->i:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_547
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->D0:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_553
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->Z:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_55f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->Q:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_56b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->l:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_577
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_583
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->M:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_58f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lab/b;->P:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_59b
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_5a0
    .sparse-switch
        -0x7ee547ee -> :sswitch_305
        -0x7db353e2 -> :sswitch_2fa
        -0x757f82a9 -> :sswitch_2ef
        -0x6a99ce98 -> :sswitch_2e4
        -0x67aa24b1 -> :sswitch_2d9
        -0x59dde17a -> :sswitch_2ce
        -0x4ebcd963 -> :sswitch_2c3
        -0x472cd1e8 -> :sswitch_2b8
        -0x455b00e5 -> :sswitch_2aa
        -0x3cefbe2e -> :sswitch_29c
        -0x3a66a280 -> :sswitch_28e
        -0x37a45d8c -> :sswitch_280
        -0x356f97e5 -> :sswitch_272
        -0x34fcb417 -> :sswitch_264
        -0x2b1183e1 -> :sswitch_256
        -0x2a31dca0 -> :sswitch_248
        -0x245a3236 -> :sswitch_23a
        -0x24043b59 -> :sswitch_22c
        -0x195d8a85 -> :sswitch_21e
        -0x1843fc8c -> :sswitch_210
        -0x1731acad -> :sswitch_202
        -0x158bb400 -> :sswitch_1f4
        -0x135b1da6 -> :sswitch_1e6
        -0x124f6462 -> :sswitch_1d8
        -0xe9558fc -> :sswitch_1ca
        -0xe6842df -> :sswitch_1bc
        -0x6213677 -> :sswitch_1ae
        -0x5127304 -> :sswitch_1a0
        -0x2abc2fc -> :sswitch_192
        -0x293198b -> :sswitch_184
        0x2f0da2 -> :sswitch_176
        0x347331 -> :sswitch_168
        0x586d1bc -> :sswitch_15a
        0x5a654e1 -> :sswitch_14c
        0x5b7d7f1 -> :sswitch_13e
        0x5bf1579 -> :sswitch_130
        0x64c1a5c -> :sswitch_122
        0x68af8e1 -> :sswitch_114
        0x9584d47 -> :sswitch_106
        0x10932041 -> :sswitch_f8
        0x10932042 -> :sswitch_ea
        0x2c929929 -> :sswitch_dc
        0x2efc0366 -> :sswitch_ce
        0x333a8669 -> :sswitch_c0
        0x44629d9c -> :sswitch_b2
        0x45ad5632 -> :sswitch_a4
        0x4747637f -> :sswitch_96
        0x47842287 -> :sswitch_88
        0x48a31966 -> :sswitch_7a
        0x4b4aaf5d -> :sswitch_6c
        0x4b4dc40c -> :sswitch_5e
        0x5217f762 -> :sswitch_50
        0x56051e55 -> :sswitch_42
        0x5720517e -> :sswitch_34
    .end sparse-switch

    :pswitch_data_67a
    .packed-switch 0x0
        :pswitch_58f
        :pswitch_583
        :pswitch_577
        :pswitch_56b
        :pswitch_55f
        :pswitch_553
        :pswitch_547
        :pswitch_53b
        :pswitch_52f
        :pswitch_523
        :pswitch_517
        :pswitch_50b
        :pswitch_4ff
        :pswitch_4f3
        :pswitch_4e7
        :pswitch_4dd
        :pswitch_4d1
        :pswitch_4c5
        :pswitch_4b9
        :pswitch_4ad
        :pswitch_4a1
        :pswitch_495
        :pswitch_489
        :pswitch_47d
        :pswitch_471
        :pswitch_465
        :pswitch_459
        :pswitch_44d
        :pswitch_441
        :pswitch_435
        :pswitch_429
        :pswitch_41d
        :pswitch_411
        :pswitch_405
        :pswitch_3f9
        :pswitch_3ed
        :pswitch_3e1
        :pswitch_3d5
        :pswitch_3c9
        :pswitch_3bd
        :pswitch_3b1
        :pswitch_3a7
        :pswitch_39b
        :pswitch_38f
        :pswitch_383
        :pswitch_377
        :pswitch_36b
        :pswitch_35f
        :pswitch_353
        :pswitch_347
        :pswitch_33b
        :pswitch_32f
        :pswitch_323
        :pswitch_317
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lab/a;->read(LBk/a;)Lab/b;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lab/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "ocmpid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "notificationId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->b:Ljava/lang/String;

    if-eqz v0, :cond_2a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "affid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->c:Ljava/lang/String;

    if-eqz v0, :cond_3c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "disp"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->d:Ljava/lang/String;

    if-eqz v0, :cond_4e

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_51

    :cond_4e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_51
    const-string v0, "omnitureData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->e:Ljava/lang/String;

    if-eqz v0, :cond_60

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_63

    :cond_60
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_63
    const-string v0, "cmpid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->f:Ljava/lang/String;

    if-eqz v0, :cond_72

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_75

    :cond_72
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_75
    const-string v0, "semcmpid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->g:Ljava/lang/String;

    if-eqz v0, :cond_84

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_87

    :cond_84
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_87
    const-string v0, "widgetType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->h:Ljava/lang/String;

    if-eqz v0, :cond_96

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_99

    :cond_96
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_99
    const-string v0, "icmpid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->i:Ljava/lang/String;

    if-eqz v0, :cond_a8

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ab

    :cond_a8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ab
    const-string v0, "contentId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->j:Ljava/lang/String;

    if-eqz v0, :cond_ba

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_bd

    :cond_ba
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_bd
    const-string v0, "otracker"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->k:Ljava/lang/String;

    if-eqz v0, :cond_cc

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_cf

    :cond_cc
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_cf
    const-string v0, "otracker1"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->l:Ljava/lang/String;

    if-eqz v0, :cond_de

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_e1

    :cond_de
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_e1
    const-string v0, "offer"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->m:Ljava/lang/String;

    if-eqz v0, :cond_f0

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_f3

    :cond_f0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_f3
    const-string v0, "referrer"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->n:Ljava/lang/String;

    if-eqz v0, :cond_102

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_105

    :cond_102
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_105
    const-string v0, "pageType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->o:Ljava/lang/String;

    if-eqz v0, :cond_114

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_117

    :cond_114
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_117
    const-string v0, "impressionId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->p:Ljava/lang/String;

    if-eqz v0, :cond_126

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_129

    :cond_126
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_129
    const-string v0, "channelId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->q:Ljava/lang/String;

    if-eqz v0, :cond_138

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_13b

    :cond_138
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_13b
    const-string v0, "omnitureDataValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->r:Lcom/flipkart/mapi/model/discovery/r;

    if-eqz v0, :cond_14a

    iget-object v1, p0, Lab/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_14d

    :cond_14a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_14d
    const-string v0, "moduleId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->s:Ljava/lang/String;

    if-eqz v0, :cond_15c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_15f

    :cond_15c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_15f
    const-string v0, "module_position"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->t:Ljava/lang/String;

    if-eqz v0, :cond_16e

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_171

    :cond_16e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_171
    const-string v0, "position"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lab/b;->u:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "trackingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->v:Ljava/lang/String;

    if-eqz v0, :cond_18b

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_18e

    :cond_18b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_18e
    const-string v0, "findingMethod"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->w:Ljava/lang/String;

    if-eqz v0, :cond_19d

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1a0

    :cond_19d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1a0
    const-string v0, "contentType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->x:Ljava/lang/String;

    if-eqz v0, :cond_1af

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b2

    :cond_1af
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b2
    const-string v0, "announcement"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->y:Ljava/lang/String;

    if-eqz v0, :cond_1c1

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1c4

    :cond_1c1
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1c4
    const-string v0, "dgPageName"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->z:Ljava/lang/String;

    if-eqz v0, :cond_1d3

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1d6

    :cond_1d3
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1d6
    const-string v0, "dgPageType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->A:Ljava/lang/String;

    if-eqz v0, :cond_1e5

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1e8

    :cond_1e5
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1e8
    const-string v0, "parentType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->B:Ljava/lang/String;

    if-eqz v0, :cond_1f7

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1fa

    :cond_1f7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1fa
    const-string v0, "widgetKey"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->C:Ljava/lang/String;

    if-eqz v0, :cond_209

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_20c

    :cond_209
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_20c
    const-string v0, "ef_id"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->D:Ljava/lang/String;

    if-eqz v0, :cond_21b

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_21e

    :cond_21b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_21e
    const-string v0, "baseImpressionId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->E:Ljava/lang/String;

    if-eqz v0, :cond_22d

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_230

    :cond_22d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_230
    const-string v0, "useBaseImpression"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->F:Ljava/lang/String;

    if-eqz v0, :cond_23f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_242

    :cond_23f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_242
    const-string v0, "sProduct"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->G:Ljava/lang/String;

    if-eqz v0, :cond_251

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_254

    :cond_251
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_254
    const-string v0, "source"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->H:Ljava/lang/String;

    if-eqz v0, :cond_263

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_266

    :cond_263
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_266
    const-string v0, "title_primary"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->I:Ljava/lang/String;

    if-eqz v0, :cond_275

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_278

    :cond_275
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_278
    const-string v0, "hasBundleOffer"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->J:Ljava/lang/String;

    if-eqz v0, :cond_287

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_28a

    :cond_287
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_28a
    const-string v0, "preferredSeller"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lab/b;->K:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "errorContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->L:Ljava/lang/String;

    if-eqz v0, :cond_2a3

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2a6

    :cond_2a3
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2a6
    const-string v0, "widgetPageName"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->M:Ljava/lang/String;

    if-eqz v0, :cond_2b5

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2b8

    :cond_2b5
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2b8
    const-string v0, "start_url"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->P:Ljava/lang/String;

    if-eqz v0, :cond_2c7

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2ca

    :cond_2c7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2ca
    const-string v0, "bottomsheetSource"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->Q:Ljava/lang/String;

    if-eqz v0, :cond_2d9

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2dc

    :cond_2d9
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2dc
    const-string v0, "dataKey"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->R:Ljava/lang/String;

    if-eqz v0, :cond_2eb

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2ee

    :cond_2eb
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2ee
    const-string v0, "widgetCategory"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->S:Ljava/lang/String;

    if-eqz v0, :cond_2fd

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_300

    :cond_2fd
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_300
    const-string v0, "contextType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->T:Ljava/lang/String;

    if-eqz v0, :cond_30f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_312

    :cond_30f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_312
    const-string v0, "viewType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->W:Ljava/lang/String;

    if-eqz v0, :cond_321

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_324

    :cond_321
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_324
    const-string v0, "widgetTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->X:Ljava/lang/String;

    if-eqz v0, :cond_333

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_336

    :cond_333
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_336
    const-string v0, "store"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->Y:Ljava/lang/String;

    if-eqz v0, :cond_345

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_348

    :cond_345
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_348
    const-string v0, "lockin_tracking"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->Z:Ljava/lang/String;

    if-eqz v0, :cond_357

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_35a

    :cond_357
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_35a
    const-string v0, "event639"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->z0:Ljava/lang/String;

    if-eqz v0, :cond_369

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_36c

    :cond_369
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_36c
    const-string v0, "prop74"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->A0:Ljava/lang/String;

    if-eqz v0, :cond_37b

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_37e

    :cond_37b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_37e
    const-string v0, "event638"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->B0:Ljava/lang/String;

    if-eqz v0, :cond_38d

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_390

    :cond_38d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_390
    const-string v0, "pev2"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->C0:Ljava/lang/String;

    if-eqz v0, :cond_39f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3a2

    :cond_39f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3a2
    const-string v0, "eVar50"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lab/b;->D0:Ljava/lang/String;

    if-eqz v0, :cond_3b1

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3b4

    :cond_3b1
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3b4
    const-string v0, "eVar3"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lab/b;->E0:Ljava/lang/String;

    if-eqz p2, :cond_3c3

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3c6

    :cond_3c3
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3c6
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lab/b;

    invoke-virtual {p0, p1, p2}, Lab/a;->write(LBk/c;Lab/b;)V

    return-void
.end method
