.class public final Lab/b;
.super Ljava/lang/Object;
.source "TrackingParams.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public A:Ljava/lang/String;

.field public A0:Ljava/lang/String;

.field public B:Ljava/lang/String;

.field public B0:Ljava/lang/String;

.field public C:Ljava/lang/String;

.field public C0:Ljava/lang/String;

.field public D:Ljava/lang/String;

.field public D0:Ljava/lang/String;

.field public E:Ljava/lang/String;

.field public E0:Ljava/lang/String;

.field public F:Ljava/lang/String;

.field public G:Ljava/lang/String;

.field public H:Ljava/lang/String;

.field public I:Ljava/lang/String;

.field public J:Ljava/lang/String;

.field public K:Z

.field public L:Ljava/lang/String;

.field public M:Ljava/lang/String;

.field public P:Ljava/lang/String;

.field public Q:Ljava/lang/String;

.field public R:Ljava/lang/String;

.field public S:Ljava/lang/String;

.field public T:Ljava/lang/String;

.field public W:Ljava/lang/String;

.field public X:Ljava/lang/String;

.field public Y:Ljava/lang/String;

.field public Z:Ljava/lang/String;

.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public k:Ljava/lang/String;

.field public l:Ljava/lang/String;

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:Ljava/lang/String;

.field public p:Ljava/lang/String;

.field public q:Ljava/lang/String;

.field public r:Lcom/flipkart/mapi/model/discovery/r;

.field public s:Ljava/lang/String;

.field public t:Ljava/lang/String;

.field public u:I

.field public v:Ljava/lang/String;

.field public w:Ljava/lang/String;

.field public x:Ljava/lang/String;

.field public y:Ljava/lang/String;

.field public z:Ljava/lang/String;

.field public z0:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getAffid()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->c:Ljava/lang/String;

    return-object v0
.end method

.method public getAnnouncement()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->y:Ljava/lang/String;

    return-object v0
.end method

.method public getBaseImpressionId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->E:Ljava/lang/String;

    return-object v0
.end method

.method public getChannelId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->q:Ljava/lang/String;

    return-object v0
.end method

.method public getCmpid()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->f:Ljava/lang/String;

    return-object v0
.end method

.method public getContentId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->j:Ljava/lang/String;

    return-object v0
.end method

.method public getContentType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->x:Ljava/lang/String;

    return-object v0
.end method

.method public getDgPageName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->z:Ljava/lang/String;

    return-object v0
.end method

.method public getDgPageType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->A:Ljava/lang/String;

    return-object v0
.end method

.method public getDisp()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->d:Ljava/lang/String;

    return-object v0
.end method

.method public getEf_Id()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->D:Ljava/lang/String;

    return-object v0
.end method

.method public getFindingMethod()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->w:Ljava/lang/String;

    return-object v0
.end method

.method public getIcmpid()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->i:Ljava/lang/String;

    return-object v0
.end method

.method public getImpressionId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->p:Ljava/lang/String;

    return-object v0
.end method

.method public getModuleId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->s:Ljava/lang/String;

    return-object v0
.end method

.method public getModule_position()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->t:Ljava/lang/String;

    return-object v0
.end method

.method public getNotificationId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->b:Ljava/lang/String;

    return-object v0
.end method

.method public getOcmpid()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->a:Ljava/lang/String;

    return-object v0
.end method

.method public getOffer()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->m:Ljava/lang/String;

    return-object v0
.end method

.method public getOmnitureData()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->e:Ljava/lang/String;

    return-object v0
.end method

.method public getOmnitureDataValue()Lcom/flipkart/mapi/model/discovery/r;
    .registers 2

    iget-object v0, p0, Lab/b;->r:Lcom/flipkart/mapi/model/discovery/r;

    return-object v0
.end method

.method public getOtracker()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->k:Ljava/lang/String;

    return-object v0
.end method

.method public getOtracker1()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->l:Ljava/lang/String;

    return-object v0
.end method

.method public getPageType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->o:Ljava/lang/String;

    return-object v0
.end method

.method public getParentType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->B:Ljava/lang/String;

    return-object v0
.end method

.method public getPosition()I
    .registers 2

    iget v0, p0, Lab/b;->u:I

    return v0
.end method

.method public getReferrer()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->n:Ljava/lang/String;

    return-object v0
.end method

.method public getSemcmpid()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->g:Ljava/lang/String;

    return-object v0
.end method

.method public getTrackingId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->v:Ljava/lang/String;

    return-object v0
.end method

.method public getUseBaseImpression()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->F:Ljava/lang/String;

    return-object v0
.end method

.method public getWidgetKey()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->C:Ljava/lang/String;

    return-object v0
.end method

.method public getWidgetPageName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->M:Ljava/lang/String;

    return-object v0
.end method

.method public getWidgetType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lab/b;->h:Ljava/lang/String;

    return-object v0
.end method

.method public setAffid(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->c:Ljava/lang/String;

    return-void
.end method

.method public setAnnouncement(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->y:Ljava/lang/String;

    return-void
.end method

.method public setChannelId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->q:Ljava/lang/String;

    return-void
.end method

.method public setCmpid(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->f:Ljava/lang/String;

    return-void
.end method

.method public setContentId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->j:Ljava/lang/String;

    return-void
.end method

.method public setContentType(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->x:Ljava/lang/String;

    return-void
.end method

.method public setDgPageName(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->z:Ljava/lang/String;

    return-void
.end method

.method public setDgPageType(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->A:Ljava/lang/String;

    return-void
.end method

.method public setDisp(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->d:Ljava/lang/String;

    return-void
.end method

.method public setEf_Id(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->D:Ljava/lang/String;

    return-void
.end method

.method public setFindingMethod(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->w:Ljava/lang/String;

    return-void
.end method

.method public setIcmpid(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->i:Ljava/lang/String;

    return-void
.end method

.method public setImpressionId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->p:Ljava/lang/String;

    return-void
.end method

.method public setModuleId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->s:Ljava/lang/String;

    return-void
.end method

.method public setModule_position(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->t:Ljava/lang/String;

    return-void
.end method

.method public setNotificationId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->b:Ljava/lang/String;

    return-void
.end method

.method public setOcmpid(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->a:Ljava/lang/String;

    return-void
.end method

.method public setOffer(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->m:Ljava/lang/String;

    return-void
.end method

.method public setOmnitureData(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->e:Ljava/lang/String;

    return-void
.end method

.method public setOmnitureDataValue(Lcom/flipkart/mapi/model/discovery/r;)V
    .registers 2

    iput-object p1, p0, Lab/b;->r:Lcom/flipkart/mapi/model/discovery/r;

    return-void
.end method

.method public setOmnitureDataValue(Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;)V
    .registers 3

    if-eqz p1, :cond_9

    new-instance v0, Lcom/flipkart/mapi/model/discovery/r;

    invoke-direct {v0, p1}, Lcom/flipkart/mapi/model/discovery/r;-><init>(Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;)V

    iput-object v0, p0, Lab/b;->r:Lcom/flipkart/mapi/model/discovery/r;

    :cond_9
    return-void
.end method

.method public setOtracker(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->k:Ljava/lang/String;

    return-void
.end method

.method public setOtracker1(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->l:Ljava/lang/String;

    return-void
.end method

.method public setPageType(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->o:Ljava/lang/String;

    return-void
.end method

.method public setParentType(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->B:Ljava/lang/String;

    return-void
.end method

.method public setPosition(I)V
    .registers 2

    iput p1, p0, Lab/b;->u:I

    return-void
.end method

.method public setReferrer(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->n:Ljava/lang/String;

    return-void
.end method

.method public setSemcmpid(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->g:Ljava/lang/String;

    return-void
.end method

.method public setTrackingId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->v:Ljava/lang/String;

    return-void
.end method

.method public setWidgetKey(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->C:Ljava/lang/String;

    return-void
.end method

.method public setWidgetPageName(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->M:Ljava/lang/String;

    return-void
.end method

.method public setWidgetType(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lab/b;->h:Ljava/lang/String;

    return-void
.end method
