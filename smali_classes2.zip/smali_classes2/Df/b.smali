.class public final Ldf/b;
.super Ljava/lang/Object;
.source "OptionType.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
