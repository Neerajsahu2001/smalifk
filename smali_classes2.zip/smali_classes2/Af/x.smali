.class public final LAf/x;
.super Ljava/lang/Object;
.source "PriceType.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
