.class public final Laf/o;
.super Lxk/z;
.source "ProductSummaryValue$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Laf/p;",
        ">;"
    }
.end annotation


# static fields
.field public static final y:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Laf/p;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/Titles;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lhh/b;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field

.field private final e:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/k0;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/D;",
            ">;"
        }
    .end annotation
.end field

.field private final h:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTc/b;",
            ">;"
        }
    .end annotation
.end field

.field private final i:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lbh/A;",
            ">;"
        }
    .end annotation
.end field

.field private final j:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lbh/c;",
            ">;"
        }
    .end annotation
.end field

.field private final k:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LQc/b;",
            ">;"
        }
    .end annotation
.end field

.field private final l:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Laf/r;",
            ">;"
        }
    .end annotation
.end field

.field private final m:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LGe/f;",
            ">;"
        }
    .end annotation
.end field

.field private final n:LJn/a$r;

.field private final o:LJn/a$r;

.field private final p:LJn/a$r;

.field private final q:LJn/a$r;

.field private final r:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lqf/b;",
            ">;"
        }
    .end annotation
.end field

.field private final s:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/w1;",
            ">;"
        }
    .end annotation
.end field

.field private final t:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Ljh/b;",
            ">;"
        }
    .end annotation
.end field

.field private final u:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field private final v:LJn/a$r;

.field private final w:LJn/a$r;

.field private final x:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Laf/p;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Laf/o;->y:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Lbh/D;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->a:Lxk/z;

    sget-object v0, Lhh/a;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->b:Lxk/z;

    sget-object v0, Lbh/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->c:Lxk/z;

    sget-object v0, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->d:Lxk/z;

    sget-object v0, LTe/j0;->i:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->e:Lxk/z;

    sget-object v0, Lgf/u;->e:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->f:Lxk/z;

    sget-object v0, LTe/C;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->g:Lxk/z;

    sget-object v0, LTc/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->h:Lxk/z;

    sget-object v0, Lbh/z;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->i:Lxk/z;

    sget-object v0, Lbh/b;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->j:Lxk/z;

    sget-object v0, LQc/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->k:Lxk/z;

    sget-object v0, Laf/q;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->l:Lxk/z;

    sget-object v0, LGe/e;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->m:Lxk/z;

    new-instance v0, LJn/a$r;

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v1, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Laf/o;->n:LJn/a$r;

    sget-object v0, Lof/a;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/o;->o:LJn/a$r;

    sget-object v0, Laf/m;->o:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/o;->p:LJn/a$r;

    sget-object v0, Lof/c;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/o;->q:LJn/a$r;

    sget-object v0, Lqf/a;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/o;->r:Lxk/z;

    sget-object v1, LTe/v1;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/o;->s:Lxk/z;

    sget-object v1, Ljh/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/o;->t:Lxk/z;

    sget-object v1, LTe/P;->f:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/o;->u:Lxk/z;

    sget-object v2, LMe/o;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, p1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, Laf/o;->v:LJn/a$r;

    new-instance p1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {p1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object p1, p0, Laf/o;->w:LJn/a$r;

    new-instance p1, LJn/a$r;

    new-instance v0, LJn/a$q;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-direct {p1, v1, v0}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object p1, p0, Laf/o;->x:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Laf/p;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Laf/p;

    invoke-direct {v0}, Laf/p;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4df

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_4fc

    goto/16 :goto_2ad

    :sswitch_34
    const-string v2, "availability"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_2ad

    :cond_3e
    const/16 v3, 0x2e

    goto/16 :goto_2ad

    :sswitch_42
    const-string v2, "offerTags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_2ad

    :cond_4c
    const/16 v3, 0x2d

    goto/16 :goto_2ad

    :sswitch_50
    const-string v2, "minKeySpecs"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_2ad

    :cond_5a
    const/16 v3, 0x2c

    goto/16 :goto_2ad

    :sswitch_5e
    const-string v2, "adProductCard"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_2ad

    :cond_68
    const/16 v3, 0x2b

    goto/16 :goto_2ad

    :sswitch_6c
    const-string v2, "productTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_2ad

    :cond_76
    const/16 v3, 0x2a

    goto/16 :goto_2ad

    :sswitch_7a
    const-string v2, "productCardTagDetails"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_2ad

    :cond_84
    const/16 v3, 0x29

    goto/16 :goto_2ad

    :sswitch_88
    const-string v2, "offerSummaries"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_2ad

    :cond_92
    const/16 v3, 0x28

    goto/16 :goto_2ad

    :sswitch_96
    const-string v2, "adContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_2ad

    :cond_a0
    const/16 v3, 0x27

    goto/16 :goto_2ad

    :sswitch_a4
    const-string v2, "subtitleValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_2ad

    :cond_ae
    const/16 v3, 0x26

    goto/16 :goto_2ad

    :sswitch_b2
    const-string v2, "productBrand"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_2ad

    :cond_bc
    const/16 v3, 0x25

    goto/16 :goto_2ad

    :sswitch_c0
    const-string v2, "checked"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ca

    goto/16 :goto_2ad

    :cond_ca
    const/16 v3, 0x24

    goto/16 :goto_2ad

    :sswitch_ce
    const-string v2, "snippets"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d8

    goto/16 :goto_2ad

    :cond_d8
    const/16 v3, 0x23

    goto/16 :goto_2ad

    :sswitch_dc
    const-string v2, "keySpecs"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e6

    goto/16 :goto_2ad

    :cond_e6
    const/16 v3, 0x22

    goto/16 :goto_2ad

    :sswitch_ea
    const-string v2, "buyability"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f4

    goto/16 :goto_2ad

    :cond_f4
    const/16 v3, 0x21

    goto/16 :goto_2ad

    :sswitch_f8
    const-string v2, "imageGalleryHighlights"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_102

    goto/16 :goto_2ad

    :cond_102
    const/16 v3, 0x20

    goto/16 :goto_2ad

    :sswitch_106
    const-string v2, "primarySaleTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_110

    goto/16 :goto_2ad

    :cond_110
    const/16 v3, 0x1f

    goto/16 :goto_2ad

    :sswitch_114
    const-string v2, "maxOrderQuantityAllowed"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11e

    goto/16 :goto_2ad

    :cond_11e
    const/16 v3, 0x1e

    goto/16 :goto_2ad

    :sswitch_122
    const-string v2, "offerTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12c

    goto/16 :goto_2ad

    :cond_12c
    const/16 v3, 0x1d

    goto/16 :goto_2ad

    :sswitch_130
    const-string v2, "media"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13a

    goto/16 :goto_2ad

    :cond_13a
    const/16 v3, 0x1c

    goto/16 :goto_2ad

    :sswitch_13e
    const-string v2, "grade"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_148

    goto/16 :goto_2ad

    :cond_148
    const/16 v3, 0x1b

    goto/16 :goto_2ad

    :sswitch_14c
    const-string v2, "flags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_156

    goto/16 :goto_2ad

    :cond_156
    const/16 v3, 0x1a

    goto/16 :goto_2ad

    :sswitch_15a
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_164

    goto/16 :goto_2ad

    :cond_164
    const/16 v3, 0x19

    goto/16 :goto_2ad

    :sswitch_168
    const-string v2, "tags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_172

    goto/16 :goto_2ad

    :cond_172
    const/16 v3, 0x18

    goto/16 :goto_2ad

    :sswitch_176
    const-string v2, "id"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_180

    goto/16 :goto_2ad

    :cond_180
    const/16 v3, 0x17

    goto/16 :goto_2ad

    :sswitch_184
    const-string v2, "valueCalloutTags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18e

    goto/16 :goto_2ad

    :cond_18e
    const/16 v3, 0x16

    goto/16 :goto_2ad

    :sswitch_192
    const-string v2, "pricing"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19c

    goto/16 :goto_2ad

    :cond_19c
    const/16 v3, 0x15

    goto/16 :goto_2ad

    :sswitch_1a0
    const-string v2, "baseUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1aa

    goto/16 :goto_2ad

    :cond_1aa
    const/16 v3, 0x14

    goto/16 :goto_2ad

    :sswitch_1ae
    const-string v2, "latestVersionUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b8

    goto/16 :goto_2ad

    :cond_1b8
    const/16 v3, 0x13

    goto/16 :goto_2ad

    :sswitch_1bc
    const-string v2, "smartUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1c6

    goto/16 :goto_2ad

    :cond_1c6
    const/16 v3, 0x12

    goto/16 :goto_2ad

    :sswitch_1ca
    const-string v2, "serviceability"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d4

    goto/16 :goto_2ad

    :cond_1d4
    const/16 v3, 0x11

    goto/16 :goto_2ad

    :sswitch_1d8
    const-string v2, "valueTags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e2

    goto/16 :goto_2ad

    :cond_1e2
    const/16 v3, 0x10

    goto/16 :goto_2ad

    :sswitch_1e6
    const-string v2, "exclusiveTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f0

    goto/16 :goto_2ad

    :cond_1f0
    const/16 v3, 0xf

    goto/16 :goto_2ad

    :sswitch_1f4
    const-string v2, "titles"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1fe

    goto/16 :goto_2ad

    :cond_1fe
    const/16 v3, 0xe

    goto/16 :goto_2ad

    :sswitch_202
    const-string v2, "spotlight"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20c

    goto/16 :goto_2ad

    :cond_20c
    const/16 v3, 0xd

    goto/16 :goto_2ad

    :sswitch_210
    const-string v2, "rating"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_21a

    goto/16 :goto_2ad

    :cond_21a
    const/16 v3, 0xc

    goto/16 :goto_2ad

    :sswitch_21e
    const-string v2, "itemId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_228

    goto/16 :goto_2ad

    :cond_228
    const/16 v3, 0xb

    goto/16 :goto_2ad

    :sswitch_22c
    const-string v2, "listingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_236

    goto/16 :goto_2ad

    :cond_236
    const/16 v3, 0xa

    goto/16 :goto_2ad

    :sswitch_23a
    const-string v2, "pricingAid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_244

    goto/16 :goto_2ad

    :cond_244
    const/16 v3, 0x9

    goto/16 :goto_2ad

    :sswitch_248
    const-string v2, "analyticsData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_252

    goto/16 :goto_2ad

    :cond_252
    const/16 v3, 0x8

    goto/16 :goto_2ad

    :sswitch_256
    const-string v2, "conditionCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_25f

    goto :goto_2ad

    :cond_25f
    const/4 v3, 0x7

    goto :goto_2ad

    :sswitch_261
    const-string v2, "adInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_26a

    goto :goto_2ad

    :cond_26a
    const/4 v3, 0x6

    goto :goto_2ad

    :sswitch_26c
    const-string v2, "deliveryCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_275

    goto :goto_2ad

    :cond_275
    const/4 v3, 0x5

    goto :goto_2ad

    :sswitch_277
    const-string v2, "emiInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_280

    goto :goto_2ad

    :cond_280
    const/4 v3, 0x4

    goto :goto_2ad

    :sswitch_282
    const-string v2, "warrantySummary"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_28b

    goto :goto_2ad

    :cond_28b
    const/4 v3, 0x3

    goto :goto_2ad

    :sswitch_28d
    const-string v2, "vertical"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_296

    goto :goto_2ad

    :cond_296
    const/4 v3, 0x2

    goto :goto_2ad

    :sswitch_298
    const-string v2, "offerTitleIcon"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2a1

    goto :goto_2ad

    :cond_2a1
    const/4 v3, 0x1

    goto :goto_2ad

    :sswitch_2a3
    const-string v2, "latestVersion"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2ac

    goto :goto_2ad

    :cond_2ac
    const/4 v3, 0x0

    :goto_2ad
    iget-object v1, p0, Laf/o;->w:LJn/a$r;

    iget-object v2, p0, Laf/o;->n:LJn/a$r;

    packed-switch v3, :pswitch_data_5ba

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_2b9
    iget-object v1, p0, Laf/o;->h:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTc/b;

    iput-object v1, v0, Laf/p;->o:LTc/b;

    goto/16 :goto_1d

    :pswitch_2c5
    iget-object v1, p0, Laf/o;->o:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->w:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_2d1
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->D:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_2db
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/p;->u:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_2e7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->L:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_2f3
    iget-object v1, p0, Laf/o;->q:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->F:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_2ff
    iget-object v1, p0, Laf/o;->p:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->C:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_30b
    iget-object v1, p0, Laf/o;->k:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LQc/b;

    iput-object v1, v0, Laf/p;->r:LQc/b;

    goto/16 :goto_1d

    :pswitch_317
    iget-object v1, p0, Laf/o;->s:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/w1;

    iput-object v1, v0, Laf/p;->J:LTe/w1;

    goto/16 :goto_1d

    :pswitch_323
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->H:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_32f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/p;->R:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_33b
    iget-object v1, p0, Laf/o;->x:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->X:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_347
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->x:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_351
    iget-object v1, p0, Laf/o;->j:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lbh/c;

    iput-object v1, v0, Laf/p;->q:Lbh/c;

    goto/16 :goto_1d

    :pswitch_35d
    iget-object v1, p0, Laf/o;->v:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->Q:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_369
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->B:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_375
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Laf/p;->S:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_381
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_38d
    iget-object v1, p0, Laf/o;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lhh/b;

    iput-object v1, v0, Laf/j;->d:Lhh/b;

    goto/16 :goto_1d

    :pswitch_399
    iget-object v1, p0, Laf/o;->t:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljh/b;

    iput-object v1, v0, Laf/p;->K:Ljh/b;

    goto/16 :goto_1d

    :pswitch_3a5
    iget-object v1, p0, Laf/o;->l:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Laf/r;

    iput-object v1, v0, Laf/p;->s:Laf/r;

    goto/16 :goto_1d

    :pswitch_3b1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3bd
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->v:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_3c7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/j;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3d3
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->W:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_3dd
    iget-object v1, p0, Laf/o;->e:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/k0;

    iput-object v1, v0, Laf/p;->l:LTe/k0;

    goto/16 :goto_1d

    :pswitch_3e9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->k:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3f5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->z:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_401
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->j:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_40d
    iget-object v1, p0, Laf/o;->i:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lbh/A;

    iput-object v1, v0, Laf/p;->p:Lbh/A;

    goto/16 :goto_1d

    :pswitch_419
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->T:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_423
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->G:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_42f
    iget-object v1, p0, Laf/o;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/Titles;

    iput-object v1, v0, Laf/j;->c:Lcom/flipkart/rome/datatypes/response/product/Titles;

    goto/16 :goto_1d

    :pswitch_43b
    iget-object v1, p0, Laf/o;->r:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lqf/b;

    iput-object v1, v0, Laf/p;->I:Lqf/b;

    goto/16 :goto_1d

    :pswitch_447
    iget-object v1, p0, Laf/o;->f:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    iput-object v1, v0, Laf/p;->m:Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    goto/16 :goto_1d

    :pswitch_453
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_45f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/j;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_46b
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->E:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_475
    iget-object v1, p0, Laf/o;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    iput-object v1, v0, Laf/p;->g:Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    goto/16 :goto_1d

    :pswitch_481
    iget-boolean v1, v0, Laf/p;->M:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/p;->M:Z

    goto/16 :goto_1d

    :pswitch_48b
    iget-object v1, p0, Laf/o;->m:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/f;

    iput-object v1, v0, Laf/p;->t:LGe/f;

    goto/16 :goto_1d

    :pswitch_497
    iget-object v1, p0, Laf/o;->u:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/p;->P:LTe/Q;

    goto/16 :goto_1d

    :pswitch_4a3
    iget-object v1, p0, Laf/o;->g:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/D;

    iput-object v1, v0, Laf/p;->n:LTe/D;

    goto/16 :goto_1d

    :pswitch_4af
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->A:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4bb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4c7
    iget-object v1, p0, Laf/o;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, Laf/p;->i:LMe/r1;

    goto/16 :goto_1d

    :pswitch_4d3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->y:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_4df
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_4f3

    iget-object p1, v0, Laf/j;->a:Ljava/lang/String;

    if-eqz p1, :cond_4eb

    return-object v0

    :cond_4eb
    new-instance p1, Ljava/io/IOException;

    const-string v0, "id cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4f3
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_4fc
    .sparse-switch
        -0x78db10af -> :sswitch_2a3
        -0x78ca2c0b -> :sswitch_298
        -0x7643988a -> :sswitch_28d
        -0x635d94f6 -> :sswitch_282
        -0x613fe6f1 -> :sswitch_277
        -0x5c6e6e64 -> :sswitch_26c
        -0x54d5e48f -> :sswitch_261
        -0x5402096b -> :sswitch_256
        -0x502e33b0 -> :sswitch_248
        -0x4f95fc6a -> :sswitch_23a
        -0x486bcd41 -> :sswitch_22c
        -0x4640f472 -> :sswitch_21e
        -0x37ea4e63 -> :sswitch_210
        -0x36d572ac -> :sswitch_202
        -0x340fd6e5 -> :sswitch_1f4
        -0x2f3f63e4 -> :sswitch_1e6
        -0x2da3e6d6 -> :sswitch_1d8
        -0x2448172b -> :sswitch_1ca
        -0x23cf091a -> :sswitch_1bc
        -0x1cd92fa2 -> :sswitch_1ae
        -0x13d37722 -> :sswitch_1a0
        -0x12c7603a -> :sswitch_192
        -0x85c9c8 -> :sswitch_184
        0xd1b -> :sswitch_176
        0x363419 -> :sswitch_168
        0x368f3a -> :sswitch_15a
        0x5cfee87 -> :sswitch_14c
        0x5e0bfd7 -> :sswitch_13e
        0x62f6fe4 -> :sswitch_130
        0x903315c -> :sswitch_122
        0xd1f3cf3 -> :sswitch_114
        0x16a5f171 -> :sswitch_106
        0x17eef716 -> :sswitch_f8
        0x1943f3e4 -> :sswitch_ea
        0x1d3394f9 -> :sswitch_dc
        0x1ea032f6 -> :sswitch_ce
        0x2c3ecfa7 -> :sswitch_c0
        0x3adf4bd8 -> :sswitch_b2
        0x3e5e2439 -> :sswitch_a4
        0x5dd3640c -> :sswitch_96
        0x60c313c8 -> :sswitch_88
        0x64257747 -> :sswitch_7a
        0x687ca02b -> :sswitch_6c
        0x6b83647c -> :sswitch_5e
        0x6df52d6b -> :sswitch_50
        0x73e73495 -> :sswitch_42
        0x7710155b -> :sswitch_34
    .end sparse-switch

    :pswitch_data_5ba
    .packed-switch 0x0
        :pswitch_4d3
        :pswitch_4c7
        :pswitch_4bb
        :pswitch_4af
        :pswitch_4a3
        :pswitch_497
        :pswitch_48b
        :pswitch_481
        :pswitch_475
        :pswitch_46b
        :pswitch_45f
        :pswitch_453
        :pswitch_447
        :pswitch_43b
        :pswitch_42f
        :pswitch_423
        :pswitch_419
        :pswitch_40d
        :pswitch_401
        :pswitch_3f5
        :pswitch_3e9
        :pswitch_3dd
        :pswitch_3d3
        :pswitch_3c7
        :pswitch_3bd
        :pswitch_3b1
        :pswitch_3a5
        :pswitch_399
        :pswitch_38d
        :pswitch_381
        :pswitch_375
        :pswitch_369
        :pswitch_35d
        :pswitch_351
        :pswitch_347
        :pswitch_33b
        :pswitch_32f
        :pswitch_323
        :pswitch_317
        :pswitch_30b
        :pswitch_2ff
        :pswitch_2f3
        :pswitch_2e7
        :pswitch_2db
        :pswitch_2d1
        :pswitch_2c5
        :pswitch_2b9
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Laf/o;->read(LBk/a;)Laf/p;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Laf/p;)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_366

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "id"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->a:Ljava/lang/String;

    if-eqz v0, :cond_35e

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "listingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->b:Ljava/lang/String;

    if-eqz v0, :cond_30

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_33

    :cond_30
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_33
    const-string v0, "titles"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->c:Lcom/flipkart/rome/datatypes/response/product/Titles;

    if-eqz v0, :cond_42

    iget-object v2, p0, Laf/o;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_45

    :cond_42
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_45
    const-string v0, "media"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->d:Lhh/b;

    if-eqz v0, :cond_54

    iget-object v2, p0, Laf/o;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_57

    :cond_54
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_57
    const-string v0, "itemId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->e:Ljava/lang/String;

    if-eqz v0, :cond_64

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_67

    :cond_64
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_67
    const-string v0, "vertical"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->f:Ljava/lang/String;

    if-eqz v0, :cond_74

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_77

    :cond_74
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_77
    const-string v0, "analyticsData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->g:Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    if-eqz v0, :cond_86

    iget-object v2, p0, Laf/o;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_89

    :cond_86
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_89
    const-string v0, "offerTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->h:Ljava/lang/String;

    if-eqz v0, :cond_96

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_99

    :cond_96
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_99
    const-string v0, "offerTitleIcon"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->i:LMe/r1;

    if-eqz v0, :cond_a8

    iget-object v2, p0, Laf/o;->d:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ab

    :cond_a8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ab
    const-string v0, "smartUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->j:Ljava/lang/String;

    if-eqz v0, :cond_b8

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_bb

    :cond_b8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_bb
    const-string v0, "baseUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->k:Ljava/lang/String;

    if-eqz v0, :cond_c8

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_cb

    :cond_c8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_cb
    const-string v0, "pricing"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->l:LTe/k0;

    if-eqz v0, :cond_da

    iget-object v2, p0, Laf/o;->e:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_dd

    :cond_da
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_dd
    const-string v0, "rating"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->m:Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    if-eqz v0, :cond_ec

    iget-object v2, p0, Laf/o;->f:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ef

    :cond_ec
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ef
    const-string v0, "emiInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->n:LTe/D;

    if-eqz v0, :cond_fe

    iget-object v2, p0, Laf/o;->g:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_101

    :cond_fe
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_101
    const-string v0, "availability"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->o:LTc/b;

    if-eqz v0, :cond_110

    iget-object v2, p0, Laf/o;->h:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_113

    :cond_110
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_113
    const-string v0, "serviceability"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->p:Lbh/A;

    if-eqz v0, :cond_122

    iget-object v2, p0, Laf/o;->i:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_125

    :cond_122
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_125
    const-string v0, "buyability"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->q:Lbh/c;

    if-eqz v0, :cond_134

    iget-object v2, p0, Laf/o;->j:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_137

    :cond_134
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_137
    const-string v0, "adContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->r:LQc/b;

    if-eqz v0, :cond_146

    iget-object v2, p0, Laf/o;->k:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_149

    :cond_146
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_149
    const-string v0, "flags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->s:Laf/r;

    if-eqz v0, :cond_158

    iget-object v2, p0, Laf/o;->l:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_15b

    :cond_158
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_15b
    const-string v0, "adInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->t:LGe/f;

    if-eqz v0, :cond_16a

    iget-object v2, p0, Laf/o;->m:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_16d

    :cond_16a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_16d
    const-string v0, "adProductCard"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->u:Ljava/lang/Boolean;

    if-eqz v0, :cond_17c

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_17f

    :cond_17c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_17f
    const-string v0, "tags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->v:Ljava/util/List;

    iget-object v2, p0, Laf/o;->n:LJn/a$r;

    if-eqz v0, :cond_193

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_196

    :cond_193
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_196
    const-string v0, "offerTags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->w:Ljava/util/List;

    if-eqz v0, :cond_1aa

    iget-object v3, p0, Laf/o;->o:LJn/a$r;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v3, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_1ad

    :cond_1aa
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1ad
    const-string v0, "keySpecs"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->x:Ljava/util/List;

    if-eqz v0, :cond_1bf

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_1c2

    :cond_1bf
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1c2
    const-string v0, "latestVersion"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->y:Ljava/lang/String;

    if-eqz v0, :cond_1cf

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1d2

    :cond_1cf
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1d2
    const-string v0, "latestVersionUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->z:Ljava/lang/String;

    if-eqz v0, :cond_1df

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1e2

    :cond_1df
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1e2
    const-string v0, "warrantySummary"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->A:Ljava/lang/String;

    if-eqz v0, :cond_1ef

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1f2

    :cond_1ef
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1f2
    const-string v0, "primarySaleTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->B:Ljava/lang/String;

    if-eqz v0, :cond_1ff

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_202

    :cond_1ff
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_202
    const-string v0, "offerSummaries"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->C:Ljava/util/List;

    if-eqz v0, :cond_216

    iget-object v3, p0, Laf/o;->p:LJn/a$r;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v3, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_219

    :cond_216
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_219
    const-string v0, "minKeySpecs"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->D:Ljava/util/List;

    if-eqz v0, :cond_22b

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_22e

    :cond_22b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_22e
    const-string v0, "pricingAid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->E:Ljava/util/List;

    if-eqz v0, :cond_240

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_243

    :cond_240
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_243
    const-string v0, "productCardTagDetails"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->F:Ljava/util/List;

    if-eqz v0, :cond_257

    iget-object v2, p0, Laf/o;->q:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_25a

    :cond_257
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_25a
    const-string v0, "exclusiveTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->G:Ljava/lang/String;

    if-eqz v0, :cond_267

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_26a

    :cond_267
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_26a
    const-string v0, "productBrand"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->H:Ljava/lang/String;

    if-eqz v0, :cond_277

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_27a

    :cond_277
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_27a
    const-string v0, "spotlight"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->I:Lqf/b;

    if-eqz v0, :cond_289

    iget-object v2, p0, Laf/o;->r:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_28c

    :cond_289
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_28c
    const-string v0, "subtitleValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->J:LTe/w1;

    if-eqz v0, :cond_29b

    iget-object v2, p0, Laf/o;->s:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_29e

    :cond_29b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_29e
    const-string v0, "grade"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->K:Ljh/b;

    if-eqz v0, :cond_2ad

    iget-object v2, p0, Laf/o;->t:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2b0

    :cond_2ad
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2b0
    const-string v0, "productTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->L:Ljava/lang/String;

    if-eqz v0, :cond_2bd

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2c0

    :cond_2bd
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2c0
    const-string v0, "conditionCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Laf/p;->M:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "deliveryCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->P:LTe/Q;

    if-eqz v0, :cond_2d9

    iget-object v1, p0, Laf/o;->u:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2dc

    :cond_2d9
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2dc
    const-string v0, "imageGalleryHighlights"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->Q:Ljava/util/List;

    if-eqz v0, :cond_2f0

    iget-object v1, p0, Laf/o;->v:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_2f3

    :cond_2f0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2f3
    const-string v0, "checked"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->R:Ljava/lang/Boolean;

    if-eqz v0, :cond_302

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_305

    :cond_302
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_305
    const-string v0, "maxOrderQuantityAllowed"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->S:Ljava/lang/Integer;

    if-eqz v0, :cond_314

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_317

    :cond_314
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_317
    const-string v0, "valueTags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->T:Ljava/util/List;

    iget-object v1, p0, Laf/o;->w:LJn/a$r;

    if-eqz v0, :cond_32b

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_32e

    :cond_32b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_32e
    const-string v0, "valueCalloutTags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->W:Ljava/util/List;

    if-eqz v0, :cond_340

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_343

    :cond_340
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_343
    const-string v0, "snippets"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Laf/p;->X:Ljava/util/List;

    if-eqz p2, :cond_357

    iget-object v0, p0, Laf/o;->x:LJn/a$r;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/util/Collection;

    invoke-virtual {v0, p1, p2}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_35a

    :cond_357
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_35a
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_35e
    new-instance p1, Ljava/io/IOException;

    const-string p2, "id cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_366
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Laf/p;

    invoke-virtual {p0, p1, p2}, Laf/o;->write(LBk/c;Laf/p;)V

    return-void
.end method
