.class public Laf/n;
.super LMe/R3;
.source "ProductOfferSummary.java"


# instance fields
.field public A:Ljava/lang/String;

.field public B:Ljava/lang/String;

.field public C:LMe/T2;

.field public D:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public E:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LLe/f<",
            "LSe/j;",
            ">;>;"
        }
    .end annotation
.end field

.field public F:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field public G:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field public H:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LSe/f;",
            ">;"
        }
    .end annotation
.end field

.field public I:Z

.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:LTe/Q;

.field public f:LTe/Q;

.field public g:LTe/L;

.field public h:Ljava/lang/String;

.field public i:LGe/b;

.field public j:LMe/T2;

.field public k:LVf/f;

.field public l:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field public m:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field public n:LMe/T2;

.field public o:LTe/Q;

.field public p:LGe/w;

.field public q:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Laf/l;",
            ">;"
        }
    .end annotation
.end field

.field public r:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Laf/n;",
            ">;"
        }
    .end annotation
.end field

.field public s:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field public t:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/F2;",
            ">;"
        }
    .end annotation
.end field

.field public u:LTe/Q;

.field public v:Ljava/lang/Boolean;

.field public w:LGe/b;

.field public x:LTe/Q;

.field public y:LTe/Q;

.field public z:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LLe/f<",
            "Lmg/b;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, LMe/R3;-><init>()V

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object v0, p0, Laf/n;->v:Ljava/lang/Boolean;

    return-void
.end method
