.class public final Laf/h;
.super Laf/p;
.source "CartProductValue.java"


# instance fields
.field public Y:Z

.field public Z:Z

.field public z0:LMe/N0;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Laf/p;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Laf/h;->Y:Z

    iput-boolean v0, p0, Laf/h;->Z:Z

    return-void
.end method
