.class public Laf/b;
.super Laf/p;
.source "AttachProductValue.java"


# instance fields
.field public Y:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public Z:Z

.field public z0:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Laf/p;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Laf/b;->Z:Z

    return-void
.end method
