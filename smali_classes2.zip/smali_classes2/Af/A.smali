.class public final Laf/a;
.super Lxk/z;
.source "AttachProductValue$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Laf/b;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/Titles;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lhh/b;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field

.field private final e:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/k0;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/D;",
            ">;"
        }
    .end annotation
.end field

.field private final h:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTc/b;",
            ">;"
        }
    .end annotation
.end field

.field private final i:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lbh/A;",
            ">;"
        }
    .end annotation
.end field

.field private final j:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lbh/c;",
            ">;"
        }
    .end annotation
.end field

.field private final k:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LQc/b;",
            ">;"
        }
    .end annotation
.end field

.field private final l:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Laf/r;",
            ">;"
        }
    .end annotation
.end field

.field private final m:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LGe/f;",
            ">;"
        }
    .end annotation
.end field

.field private final n:LJn/a$r;

.field private final o:LJn/a$r;

.field private final p:LJn/a$r;

.field private final q:LJn/a$r;

.field private final r:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lqf/b;",
            ">;"
        }
    .end annotation
.end field

.field private final s:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/w1;",
            ">;"
        }
    .end annotation
.end field

.field private final t:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Ljh/b;",
            ">;"
        }
    .end annotation
.end field

.field private final u:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field private final v:LJn/a$r;

.field private final w:LJn/a$r;

.field private final x:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Laf/b;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Lbh/D;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->a:Lxk/z;

    sget-object v0, Lhh/a;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->b:Lxk/z;

    sget-object v0, Lbh/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->c:Lxk/z;

    sget-object v0, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->d:Lxk/z;

    sget-object v0, LTe/j0;->i:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->e:Lxk/z;

    sget-object v0, Lgf/u;->e:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->f:Lxk/z;

    sget-object v0, LTe/C;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->g:Lxk/z;

    sget-object v0, LTc/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->h:Lxk/z;

    sget-object v0, Lbh/z;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->i:Lxk/z;

    sget-object v0, Lbh/b;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->j:Lxk/z;

    sget-object v0, LQc/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->k:Lxk/z;

    sget-object v0, Laf/q;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->l:Lxk/z;

    sget-object v0, LGe/e;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->m:Lxk/z;

    new-instance v0, LJn/a$r;

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v1, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Laf/a;->n:LJn/a$r;

    sget-object v0, Lof/a;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/a;->o:LJn/a$r;

    sget-object v0, Laf/m;->o:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/a;->p:LJn/a$r;

    sget-object v0, Lof/c;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/a;->q:LJn/a$r;

    sget-object v0, Lqf/a;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Laf/a;->r:Lxk/z;

    sget-object v1, LTe/v1;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/a;->s:Lxk/z;

    sget-object v1, Ljh/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/a;->t:Lxk/z;

    sget-object v1, LTe/P;->f:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/a;->u:Lxk/z;

    sget-object v2, LMe/o;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, p1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, Laf/a;->v:LJn/a$r;

    new-instance p1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {p1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object p1, p0, Laf/a;->w:LJn/a$r;

    new-instance p1, LJn/a$r;

    new-instance v0, LJn/a$q;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-direct {p1, v1, v0}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object p1, p0, Laf/a;->x:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Laf/b;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Laf/b;

    invoke-direct {v0}, Laf/b;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_50d

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_52a

    goto/16 :goto_2c9

    :sswitch_34
    const-string v2, "additionalMessages"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_2c9

    :cond_3e
    const/16 v3, 0x30

    goto/16 :goto_2c9

    :sswitch_42
    const-string v2, "availability"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_2c9

    :cond_4c
    const/16 v3, 0x2f

    goto/16 :goto_2c9

    :sswitch_50
    const-string v2, "offerTags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_2c9

    :cond_5a
    const/16 v3, 0x2e

    goto/16 :goto_2c9

    :sswitch_5e
    const-string v2, "minKeySpecs"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_2c9

    :cond_68
    const/16 v3, 0x2d

    goto/16 :goto_2c9

    :sswitch_6c
    const-string v2, "adProductCard"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_2c9

    :cond_76
    const/16 v3, 0x2c

    goto/16 :goto_2c9

    :sswitch_7a
    const-string v2, "productTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_2c9

    :cond_84
    const/16 v3, 0x2b

    goto/16 :goto_2c9

    :sswitch_88
    const-string v2, "productCardTagDetails"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_2c9

    :cond_92
    const/16 v3, 0x2a

    goto/16 :goto_2c9

    :sswitch_96
    const-string v2, "offerSummaries"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_2c9

    :cond_a0
    const/16 v3, 0x29

    goto/16 :goto_2c9

    :sswitch_a4
    const-string v2, "adContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_2c9

    :cond_ae
    const/16 v3, 0x28

    goto/16 :goto_2c9

    :sswitch_b2
    const-string v2, "subtitleValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_2c9

    :cond_bc
    const/16 v3, 0x27

    goto/16 :goto_2c9

    :sswitch_c0
    const-string v2, "productBrand"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ca

    goto/16 :goto_2c9

    :cond_ca
    const/16 v3, 0x26

    goto/16 :goto_2c9

    :sswitch_ce
    const-string v2, "checked"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d8

    goto/16 :goto_2c9

    :cond_d8
    const/16 v3, 0x25

    goto/16 :goto_2c9

    :sswitch_dc
    const-string v2, "snippets"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e6

    goto/16 :goto_2c9

    :cond_e6
    const/16 v3, 0x24

    goto/16 :goto_2c9

    :sswitch_ea
    const-string v2, "keySpecs"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f4

    goto/16 :goto_2c9

    :cond_f4
    const/16 v3, 0x23

    goto/16 :goto_2c9

    :sswitch_f8
    const-string v2, "buyability"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_102

    goto/16 :goto_2c9

    :cond_102
    const/16 v3, 0x22

    goto/16 :goto_2c9

    :sswitch_106
    const-string v2, "imageGalleryHighlights"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_110

    goto/16 :goto_2c9

    :cond_110
    const/16 v3, 0x21

    goto/16 :goto_2c9

    :sswitch_114
    const-string v2, "primarySaleTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11e

    goto/16 :goto_2c9

    :cond_11e
    const/16 v3, 0x20

    goto/16 :goto_2c9

    :sswitch_122
    const-string v2, "maxOrderQuantityAllowed"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12c

    goto/16 :goto_2c9

    :cond_12c
    const/16 v3, 0x1f

    goto/16 :goto_2c9

    :sswitch_130
    const-string v2, "offerTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13a

    goto/16 :goto_2c9

    :cond_13a
    const/16 v3, 0x1e

    goto/16 :goto_2c9

    :sswitch_13e
    const-string v2, "media"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_148

    goto/16 :goto_2c9

    :cond_148
    const/16 v3, 0x1d

    goto/16 :goto_2c9

    :sswitch_14c
    const-string v2, "grade"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_156

    goto/16 :goto_2c9

    :cond_156
    const/16 v3, 0x1c

    goto/16 :goto_2c9

    :sswitch_15a
    const-string v2, "flags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_164

    goto/16 :goto_2c9

    :cond_164
    const/16 v3, 0x1b

    goto/16 :goto_2c9

    :sswitch_168
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_172

    goto/16 :goto_2c9

    :cond_172
    const/16 v3, 0x1a

    goto/16 :goto_2c9

    :sswitch_176
    const-string v2, "tags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_180

    goto/16 :goto_2c9

    :cond_180
    const/16 v3, 0x19

    goto/16 :goto_2c9

    :sswitch_184
    const-string v2, "id"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18e

    goto/16 :goto_2c9

    :cond_18e
    const/16 v3, 0x18

    goto/16 :goto_2c9

    :sswitch_192
    const-string v2, "valueCalloutTags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19c

    goto/16 :goto_2c9

    :cond_19c
    const/16 v3, 0x17

    goto/16 :goto_2c9

    :sswitch_1a0
    const-string v2, "pricing"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1aa

    goto/16 :goto_2c9

    :cond_1aa
    const/16 v3, 0x16

    goto/16 :goto_2c9

    :sswitch_1ae
    const-string v2, "baseUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b8

    goto/16 :goto_2c9

    :cond_1b8
    const/16 v3, 0x15

    goto/16 :goto_2c9

    :sswitch_1bc
    const-string v2, "hasBundleOffer"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1c6

    goto/16 :goto_2c9

    :cond_1c6
    const/16 v3, 0x14

    goto/16 :goto_2c9

    :sswitch_1ca
    const-string v2, "latestVersionUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d4

    goto/16 :goto_2c9

    :cond_1d4
    const/16 v3, 0x13

    goto/16 :goto_2c9

    :sswitch_1d8
    const-string v2, "smartUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e2

    goto/16 :goto_2c9

    :cond_1e2
    const/16 v3, 0x12

    goto/16 :goto_2c9

    :sswitch_1e6
    const-string v2, "serviceability"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f0

    goto/16 :goto_2c9

    :cond_1f0
    const/16 v3, 0x11

    goto/16 :goto_2c9

    :sswitch_1f4
    const-string v2, "valueTags"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1fe

    goto/16 :goto_2c9

    :cond_1fe
    const/16 v3, 0x10

    goto/16 :goto_2c9

    :sswitch_202
    const-string v2, "exclusiveTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20c

    goto/16 :goto_2c9

    :cond_20c
    const/16 v3, 0xf

    goto/16 :goto_2c9

    :sswitch_210
    const-string v2, "titles"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_21a

    goto/16 :goto_2c9

    :cond_21a
    const/16 v3, 0xe

    goto/16 :goto_2c9

    :sswitch_21e
    const-string v2, "spotlight"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_228

    goto/16 :goto_2c9

    :cond_228
    const/16 v3, 0xd

    goto/16 :goto_2c9

    :sswitch_22c
    const-string v2, "rating"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_236

    goto/16 :goto_2c9

    :cond_236
    const/16 v3, 0xc

    goto/16 :goto_2c9

    :sswitch_23a
    const-string v2, "itemId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_244

    goto/16 :goto_2c9

    :cond_244
    const/16 v3, 0xb

    goto/16 :goto_2c9

    :sswitch_248
    const-string v2, "listingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_252

    goto/16 :goto_2c9

    :cond_252
    const/16 v3, 0xa

    goto/16 :goto_2c9

    :sswitch_256
    const-string v2, "pricingAid"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_260

    goto/16 :goto_2c9

    :cond_260
    const/16 v3, 0x9

    goto/16 :goto_2c9

    :sswitch_264
    const-string v2, "analyticsData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_26e

    goto/16 :goto_2c9

    :cond_26e
    const/16 v3, 0x8

    goto/16 :goto_2c9

    :sswitch_272
    const-string v2, "conditionCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_27b

    goto :goto_2c9

    :cond_27b
    const/4 v3, 0x7

    goto :goto_2c9

    :sswitch_27d
    const-string v2, "adInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_286

    goto :goto_2c9

    :cond_286
    const/4 v3, 0x6

    goto :goto_2c9

    :sswitch_288
    const-string v2, "deliveryCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_291

    goto :goto_2c9

    :cond_291
    const/4 v3, 0x5

    goto :goto_2c9

    :sswitch_293
    const-string v2, "emiInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_29c

    goto :goto_2c9

    :cond_29c
    const/4 v3, 0x4

    goto :goto_2c9

    :sswitch_29e
    const-string v2, "warrantySummary"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2a7

    goto :goto_2c9

    :cond_2a7
    const/4 v3, 0x3

    goto :goto_2c9

    :sswitch_2a9
    const-string v2, "vertical"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b2

    goto :goto_2c9

    :cond_2b2
    const/4 v3, 0x2

    goto :goto_2c9

    :sswitch_2b4
    const-string v2, "offerTitleIcon"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2bd

    goto :goto_2c9

    :cond_2bd
    const/4 v3, 0x1

    goto :goto_2c9

    :sswitch_2bf
    const-string v2, "latestVersion"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c8

    goto :goto_2c9

    :cond_2c8
    const/4 v3, 0x0

    :goto_2c9
    iget-object v1, p0, Laf/a;->w:LJn/a$r;

    iget-object v2, p0, Laf/a;->n:LJn/a$r;

    packed-switch v3, :pswitch_data_5f0

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_2d5
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/b;->Y:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_2df
    iget-object v1, p0, Laf/a;->h:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTc/b;

    iput-object v1, v0, Laf/p;->o:LTc/b;

    goto/16 :goto_1d

    :pswitch_2eb
    iget-object v1, p0, Laf/a;->o:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->w:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_2f7
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->D:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_301
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/p;->u:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_30d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->L:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_319
    iget-object v1, p0, Laf/a;->q:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->F:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_325
    iget-object v1, p0, Laf/a;->p:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->C:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_331
    iget-object v1, p0, Laf/a;->k:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LQc/b;

    iput-object v1, v0, Laf/p;->r:LQc/b;

    goto/16 :goto_1d

    :pswitch_33d
    iget-object v1, p0, Laf/a;->s:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/w1;

    iput-object v1, v0, Laf/p;->J:LTe/w1;

    goto/16 :goto_1d

    :pswitch_349
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->H:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_355
    iget-boolean v1, v0, Laf/b;->Z:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/b;->Z:Z

    goto/16 :goto_1d

    :pswitch_35f
    iget-object v1, p0, Laf/a;->x:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->X:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_36b
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->x:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_375
    iget-object v1, p0, Laf/a;->j:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lbh/c;

    iput-object v1, v0, Laf/p;->q:Lbh/c;

    goto/16 :goto_1d

    :pswitch_381
    iget-object v1, p0, Laf/a;->v:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->Q:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_38d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->B:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_399
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Laf/p;->S:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_3a5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3b1
    iget-object v1, p0, Laf/a;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lhh/b;

    iput-object v1, v0, Laf/j;->d:Lhh/b;

    goto/16 :goto_1d

    :pswitch_3bd
    iget-object v1, p0, Laf/a;->t:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljh/b;

    iput-object v1, v0, Laf/p;->K:Ljh/b;

    goto/16 :goto_1d

    :pswitch_3c9
    iget-object v1, p0, Laf/a;->l:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Laf/r;

    iput-object v1, v0, Laf/p;->s:Laf/r;

    goto/16 :goto_1d

    :pswitch_3d5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3e1
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->v:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_3eb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/j;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_3f7
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->W:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_401
    iget-object v1, p0, Laf/a;->e:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/k0;

    iput-object v1, v0, Laf/p;->l:LTe/k0;

    goto/16 :goto_1d

    :pswitch_40d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->k:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_419
    iget-boolean v1, v0, Laf/b;->z0:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/b;->z0:Z

    goto/16 :goto_1d

    :pswitch_423
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->z:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_42f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->j:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_43b
    iget-object v1, p0, Laf/a;->i:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lbh/A;

    iput-object v1, v0, Laf/p;->p:Lbh/A;

    goto/16 :goto_1d

    :pswitch_447
    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->T:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_451
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->G:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_45d
    iget-object v1, p0, Laf/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/Titles;

    iput-object v1, v0, Laf/j;->c:Lcom/flipkart/rome/datatypes/response/product/Titles;

    goto/16 :goto_1d

    :pswitch_469
    iget-object v1, p0, Laf/a;->r:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lqf/b;

    iput-object v1, v0, Laf/p;->I:Lqf/b;

    goto/16 :goto_1d

    :pswitch_475
    iget-object v1, p0, Laf/a;->f:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    iput-object v1, v0, Laf/p;->m:Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    goto/16 :goto_1d

    :pswitch_481
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_48d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/j;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_499
    invoke-virtual {v2, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/p;->E:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_4a3
    iget-object v1, p0, Laf/a;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    iput-object v1, v0, Laf/p;->g:Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    goto/16 :goto_1d

    :pswitch_4af
    iget-boolean v1, v0, Laf/p;->M:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/p;->M:Z

    goto/16 :goto_1d

    :pswitch_4b9
    iget-object v1, p0, Laf/a;->m:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/f;

    iput-object v1, v0, Laf/p;->t:LGe/f;

    goto/16 :goto_1d

    :pswitch_4c5
    iget-object v1, p0, Laf/a;->u:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/p;->P:LTe/Q;

    goto/16 :goto_1d

    :pswitch_4d1
    iget-object v1, p0, Laf/a;->g:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/D;

    iput-object v1, v0, Laf/p;->n:LTe/D;

    goto/16 :goto_1d

    :pswitch_4dd
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->A:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4e9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_4f5
    iget-object v1, p0, Laf/a;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, Laf/p;->i:LMe/r1;

    goto/16 :goto_1d

    :pswitch_501
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/p;->y:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_50d
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_521

    iget-object p1, v0, Laf/j;->a:Ljava/lang/String;

    if-eqz p1, :cond_519

    return-object v0

    :cond_519
    new-instance p1, Ljava/io/IOException;

    const-string v0, "id cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_521
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_52a
    .sparse-switch
        -0x78db10af -> :sswitch_2bf
        -0x78ca2c0b -> :sswitch_2b4
        -0x7643988a -> :sswitch_2a9
        -0x635d94f6 -> :sswitch_29e
        -0x613fe6f1 -> :sswitch_293
        -0x5c6e6e64 -> :sswitch_288
        -0x54d5e48f -> :sswitch_27d
        -0x5402096b -> :sswitch_272
        -0x502e33b0 -> :sswitch_264
        -0x4f95fc6a -> :sswitch_256
        -0x486bcd41 -> :sswitch_248
        -0x4640f472 -> :sswitch_23a
        -0x37ea4e63 -> :sswitch_22c
        -0x36d572ac -> :sswitch_21e
        -0x340fd6e5 -> :sswitch_210
        -0x2f3f63e4 -> :sswitch_202
        -0x2da3e6d6 -> :sswitch_1f4
        -0x2448172b -> :sswitch_1e6
        -0x23cf091a -> :sswitch_1d8
        -0x1cd92fa2 -> :sswitch_1ca
        -0x158bb400 -> :sswitch_1bc
        -0x13d37722 -> :sswitch_1ae
        -0x12c7603a -> :sswitch_1a0
        -0x85c9c8 -> :sswitch_192
        0xd1b -> :sswitch_184
        0x363419 -> :sswitch_176
        0x368f3a -> :sswitch_168
        0x5cfee87 -> :sswitch_15a
        0x5e0bfd7 -> :sswitch_14c
        0x62f6fe4 -> :sswitch_13e
        0x903315c -> :sswitch_130
        0xd1f3cf3 -> :sswitch_122
        0x16a5f171 -> :sswitch_114
        0x17eef716 -> :sswitch_106
        0x1943f3e4 -> :sswitch_f8
        0x1d3394f9 -> :sswitch_ea
        0x1ea032f6 -> :sswitch_dc
        0x2c3ecfa7 -> :sswitch_ce
        0x3adf4bd8 -> :sswitch_c0
        0x3e5e2439 -> :sswitch_b2
        0x5dd3640c -> :sswitch_a4
        0x60c313c8 -> :sswitch_96
        0x64257747 -> :sswitch_88
        0x687ca02b -> :sswitch_7a
        0x6b83647c -> :sswitch_6c
        0x6df52d6b -> :sswitch_5e
        0x73e73495 -> :sswitch_50
        0x7710155b -> :sswitch_42
        0x77254693 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_5f0
    .packed-switch 0x0
        :pswitch_501
        :pswitch_4f5
        :pswitch_4e9
        :pswitch_4dd
        :pswitch_4d1
        :pswitch_4c5
        :pswitch_4b9
        :pswitch_4af
        :pswitch_4a3
        :pswitch_499
        :pswitch_48d
        :pswitch_481
        :pswitch_475
        :pswitch_469
        :pswitch_45d
        :pswitch_451
        :pswitch_447
        :pswitch_43b
        :pswitch_42f
        :pswitch_423
        :pswitch_419
        :pswitch_40d
        :pswitch_401
        :pswitch_3f7
        :pswitch_3eb
        :pswitch_3e1
        :pswitch_3d5
        :pswitch_3c9
        :pswitch_3bd
        :pswitch_3b1
        :pswitch_3a5
        :pswitch_399
        :pswitch_38d
        :pswitch_381
        :pswitch_375
        :pswitch_36b
        :pswitch_35f
        :pswitch_355
        :pswitch_349
        :pswitch_33d
        :pswitch_331
        :pswitch_325
        :pswitch_319
        :pswitch_30d
        :pswitch_301
        :pswitch_2f7
        :pswitch_2eb
        :pswitch_2df
        :pswitch_2d5
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Laf/a;->read(LBk/a;)Laf/b;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Laf/b;)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_37d

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "id"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->a:Ljava/lang/String;

    if-eqz v0, :cond_375

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "listingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->b:Ljava/lang/String;

    if-eqz v0, :cond_30

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_33

    :cond_30
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_33
    const-string v0, "titles"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->c:Lcom/flipkart/rome/datatypes/response/product/Titles;

    if-eqz v0, :cond_42

    iget-object v2, p0, Laf/a;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_45

    :cond_42
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_45
    const-string v0, "media"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/j;->d:Lhh/b;

    if-eqz v0, :cond_54

    iget-object v2, p0, Laf/a;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_57

    :cond_54
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_57
    const-string v0, "itemId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->e:Ljava/lang/String;

    if-eqz v0, :cond_64

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_67

    :cond_64
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_67
    const-string v0, "vertical"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->f:Ljava/lang/String;

    if-eqz v0, :cond_74

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_77

    :cond_74
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_77
    const-string v0, "analyticsData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->g:Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    if-eqz v0, :cond_86

    iget-object v2, p0, Laf/a;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_89

    :cond_86
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_89
    const-string v0, "offerTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->h:Ljava/lang/String;

    if-eqz v0, :cond_96

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_99

    :cond_96
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_99
    const-string v0, "offerTitleIcon"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->i:LMe/r1;

    if-eqz v0, :cond_a8

    iget-object v2, p0, Laf/a;->d:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ab

    :cond_a8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ab
    const-string v0, "smartUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->j:Ljava/lang/String;

    if-eqz v0, :cond_b8

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_bb

    :cond_b8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_bb
    const-string v0, "baseUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->k:Ljava/lang/String;

    if-eqz v0, :cond_c8

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_cb

    :cond_c8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_cb
    const-string v0, "pricing"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->l:LTe/k0;

    if-eqz v0, :cond_da

    iget-object v2, p0, Laf/a;->e:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_dd

    :cond_da
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_dd
    const-string v0, "rating"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->m:Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    if-eqz v0, :cond_ec

    iget-object v2, p0, Laf/a;->f:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ef

    :cond_ec
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ef
    const-string v0, "emiInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->n:LTe/D;

    if-eqz v0, :cond_fe

    iget-object v2, p0, Laf/a;->g:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_101

    :cond_fe
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_101
    const-string v0, "availability"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->o:LTc/b;

    if-eqz v0, :cond_110

    iget-object v2, p0, Laf/a;->h:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_113

    :cond_110
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_113
    const-string v0, "serviceability"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->p:Lbh/A;

    if-eqz v0, :cond_122

    iget-object v2, p0, Laf/a;->i:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_125

    :cond_122
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_125
    const-string v0, "buyability"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->q:Lbh/c;

    if-eqz v0, :cond_134

    iget-object v2, p0, Laf/a;->j:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_137

    :cond_134
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_137
    const-string v0, "adContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->r:LQc/b;

    if-eqz v0, :cond_146

    iget-object v2, p0, Laf/a;->k:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_149

    :cond_146
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_149
    const-string v0, "flags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->s:Laf/r;

    if-eqz v0, :cond_158

    iget-object v2, p0, Laf/a;->l:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_15b

    :cond_158
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_15b
    const-string v0, "adInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->t:LGe/f;

    if-eqz v0, :cond_16a

    iget-object v2, p0, Laf/a;->m:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_16d

    :cond_16a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_16d
    const-string v0, "adProductCard"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->u:Ljava/lang/Boolean;

    if-eqz v0, :cond_17c

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_17f

    :cond_17c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_17f
    const-string v0, "tags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->v:Ljava/util/List;

    iget-object v2, p0, Laf/a;->n:LJn/a$r;

    if-eqz v0, :cond_193

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_196

    :cond_193
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_196
    const-string v0, "offerTags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->w:Ljava/util/List;

    if-eqz v0, :cond_1aa

    iget-object v3, p0, Laf/a;->o:LJn/a$r;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v3, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_1ad

    :cond_1aa
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1ad
    const-string v0, "keySpecs"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->x:Ljava/util/List;

    if-eqz v0, :cond_1bf

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_1c2

    :cond_1bf
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1c2
    const-string v0, "latestVersion"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->y:Ljava/lang/String;

    if-eqz v0, :cond_1cf

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1d2

    :cond_1cf
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1d2
    const-string v0, "latestVersionUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->z:Ljava/lang/String;

    if-eqz v0, :cond_1df

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1e2

    :cond_1df
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1e2
    const-string v0, "warrantySummary"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->A:Ljava/lang/String;

    if-eqz v0, :cond_1ef

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1f2

    :cond_1ef
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1f2
    const-string v0, "primarySaleTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->B:Ljava/lang/String;

    if-eqz v0, :cond_1ff

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_202

    :cond_1ff
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_202
    const-string v0, "offerSummaries"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->C:Ljava/util/List;

    if-eqz v0, :cond_216

    iget-object v3, p0, Laf/a;->p:LJn/a$r;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v3, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_219

    :cond_216
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_219
    const-string v0, "minKeySpecs"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->D:Ljava/util/List;

    if-eqz v0, :cond_22b

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_22e

    :cond_22b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_22e
    const-string v0, "pricingAid"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->E:Ljava/util/List;

    if-eqz v0, :cond_240

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_243

    :cond_240
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_243
    const-string v0, "productCardTagDetails"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->F:Ljava/util/List;

    if-eqz v0, :cond_257

    iget-object v3, p0, Laf/a;->q:LJn/a$r;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v3, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_25a

    :cond_257
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_25a
    const-string v0, "exclusiveTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->G:Ljava/lang/String;

    if-eqz v0, :cond_267

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_26a

    :cond_267
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_26a
    const-string v0, "productBrand"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->H:Ljava/lang/String;

    if-eqz v0, :cond_277

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_27a

    :cond_277
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_27a
    const-string v0, "spotlight"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->I:Lqf/b;

    if-eqz v0, :cond_289

    iget-object v3, p0, Laf/a;->r:Lxk/z;

    invoke-virtual {v3, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_28c

    :cond_289
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_28c
    const-string v0, "subtitleValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->J:LTe/w1;

    if-eqz v0, :cond_29b

    iget-object v3, p0, Laf/a;->s:Lxk/z;

    invoke-virtual {v3, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_29e

    :cond_29b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_29e
    const-string v0, "grade"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->K:Ljh/b;

    if-eqz v0, :cond_2ad

    iget-object v3, p0, Laf/a;->t:Lxk/z;

    invoke-virtual {v3, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2b0

    :cond_2ad
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2b0
    const-string v0, "productTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->L:Ljava/lang/String;

    if-eqz v0, :cond_2bd

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2c0

    :cond_2bd
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2c0
    const-string v0, "conditionCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Laf/p;->M:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "deliveryCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->P:LTe/Q;

    if-eqz v0, :cond_2d9

    iget-object v1, p0, Laf/a;->u:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2dc

    :cond_2d9
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2dc
    const-string v0, "imageGalleryHighlights"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->Q:Ljava/util/List;

    if-eqz v0, :cond_2f0

    iget-object v1, p0, Laf/a;->v:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_2f3

    :cond_2f0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2f3
    const-string v0, "maxOrderQuantityAllowed"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->S:Ljava/lang/Integer;

    if-eqz v0, :cond_302

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_305

    :cond_302
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_305
    const-string v0, "valueTags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->T:Ljava/util/List;

    iget-object v1, p0, Laf/a;->w:LJn/a$r;

    if-eqz v0, :cond_319

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_31c

    :cond_319
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_31c
    const-string v0, "valueCalloutTags"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->W:Ljava/util/List;

    if-eqz v0, :cond_32e

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_331

    :cond_32e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_331
    const-string v0, "snippets"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/p;->X:Ljava/util/List;

    if-eqz v0, :cond_345

    iget-object v1, p0, Laf/a;->x:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_348

    :cond_345
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_348
    const-string v0, "additionalMessages"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/b;->Y:Ljava/util/List;

    if-eqz v0, :cond_35a

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_35d

    :cond_35a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_35d
    const-string v0, "checked"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Laf/b;->Z:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "hasBundleOffer"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Laf/b;->z0:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_375
    new-instance p1, Ljava/io/IOException;

    const-string p2, "id cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_37d
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Laf/b;

    invoke-virtual {p0, p1, p2}, Laf/a;->write(LBk/c;Laf/b;)V

    return-void
.end method
