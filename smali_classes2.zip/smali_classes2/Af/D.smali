.class public final Laf/d;
.super Laf/b;
.source "AttachProductValueV2.java"


# instance fields
.field public A0:Ljava/lang/Boolean;

.field public B0:Ljava/lang/Boolean;

.field public C0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LTc/f;",
            ">;"
        }
    .end annotation
.end field

.field public D0:LTe/c1;

.field public E0:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/K3;",
            ">;"
        }
    .end annotation
.end field

.field public F0:Lbh/w;

.field public G0:Z

.field public H0:LVc/f;

.field public I0:Z

.field public J0:Ljava/lang/Boolean;

.field public K0:LTe/r;

.field public L0:LTe/r;

.field public M0:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Laf/b;-><init>()V

    return-void
.end method
