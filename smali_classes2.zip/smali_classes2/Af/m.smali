.class public final Laf/m;
.super Lxk/z;
.source "ProductOfferSummary$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Laf/n;",
        ">;"
    }
.end annotation


# static fields
.field public static final o:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Laf/n;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/L;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LGe/b;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/T2;",
            ">;"
        }
    .end annotation
.end field

.field private final e:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LVf/f;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LTe/Q;",
            ">;>;"
        }
    .end annotation
.end field

.field private final g:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LGe/w;",
            ">;"
        }
    .end annotation
.end field

.field private final h:LJn/a$r;

.field private final i:LJn/a$r;

.field private final j:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/F2;",
            ">;>;"
        }
    .end annotation
.end field

.field private final k:LJn/a$r;

.field private final l:LJn/a$t;

.field private final m:LJn/a$r;

.field private final n:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Laf/n;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Laf/m;->o:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 9

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/reflect/Type;

    const-class v2, LTe/Q;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-class v2, LLe/f;

    invoke-static {v2, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v1

    new-array v4, v0, [Ljava/lang/reflect/Type;

    const-class v5, LMe/F2;

    aput-object v5, v4, v3

    invoke-static {v2, v4}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v4

    new-array v5, v0, [Ljava/lang/reflect/Type;

    const-class v6, Lmg/b;

    aput-object v6, v5, v3

    invoke-static {v2, v5}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v5

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v6, LSe/j;

    aput-object v6, v0, v3

    invoke-static {v2, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v2, LTe/P;->f:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v2

    iput-object v2, p0, Laf/m;->a:Lxk/z;

    sget-object v2, LTe/K;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v2

    iput-object v2, p0, Laf/m;->b:Lxk/z;

    sget-object v2, LGe/a;->l:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v2

    iput-object v2, p0, Laf/m;->c:Lxk/z;

    sget-object v2, LMe/S2;->d:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v2

    iput-object v2, p0, Laf/m;->d:Lxk/z;

    sget-object v2, LVf/e;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v2

    iput-object v2, p0, Laf/m;->e:Lxk/z;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/m;->f:Lxk/z;

    sget-object v1, LGe/v;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/m;->g:Lxk/z;

    sget-object v1, Laf/k;->d:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, Laf/m;->h:LJn/a$r;

    sget-object v1, Laf/m;->o:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, Laf/m;->i:LJn/a$r;

    invoke-virtual {p1, v4}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Laf/m;->j:Lxk/z;

    invoke-virtual {p1, v5}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, Laf/m;->k:LJn/a$r;

    new-instance v1, LJn/a$t;

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v3, LJn/a$s;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v2, v2, v3}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/m;->l:LJn/a$t;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Laf/m;->m:LJn/a$r;

    sget-object v0, LSe/e;->d:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Laf/m;->n:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Laf/n;
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Laf/n;

    invoke-direct {v0}, Laf/n;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3b1

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_3c2

    goto/16 :goto_213

    :sswitch_34
    const-string v2, "checkBoxAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_213

    :cond_3e
    const/16 v3, 0x23

    goto/16 :goto_213

    :sswitch_42
    const-string v2, "offerType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_213

    :cond_4c
    const/16 v3, 0x22

    goto/16 :goto_213

    :sswitch_50
    const-string v2, "offerInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_213

    :cond_5a
    const/16 v3, 0x21

    goto/16 :goto_213

    :sswitch_5e
    const-string v2, "discountLineItemType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_213

    :cond_68
    const/16 v3, 0x20

    goto/16 :goto_213

    :sswitch_6c
    const-string v2, "claimButton"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_213

    :cond_76
    const/16 v3, 0x1f

    goto/16 :goto_213

    :sswitch_7a
    const-string v2, "iconUrl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_213

    :cond_84
    const/16 v3, 0x1e

    goto/16 :goto_213

    :sswitch_88
    const-string v2, "newTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_213

    :cond_92
    const/16 v3, 0x1d

    goto/16 :goto_213

    :sswitch_96
    const-string v2, "nepFomoData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_213

    :cond_a0
    const/16 v3, 0x1c

    goto/16 :goto_213

    :sswitch_a4
    const-string v2, "paymentOffers"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_213

    :cond_ae
    const/16 v3, 0x1b

    goto/16 :goto_213

    :sswitch_b2
    const-string v2, "headerTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_213

    :cond_bc
    const/16 v3, 0x1a

    goto/16 :goto_213

    :sswitch_c0
    const-string v2, "offerCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ca

    goto/16 :goto_213

    :cond_ca
    const/16 v3, 0x19

    goto/16 :goto_213

    :sswitch_ce
    const-string v2, "checked"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d8

    goto/16 :goto_213

    :cond_d8
    const/16 v3, 0x18

    goto/16 :goto_213

    :sswitch_dc
    const-string v2, "exclusiveDealsClaim"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e6

    goto/16 :goto_213

    :cond_e6
    const/16 v3, 0x17

    goto/16 :goto_213

    :sswitch_ea
    const-string v2, "title"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f4

    goto/16 :goto_213

    :cond_f4
    const/16 v3, 0x16

    goto/16 :goto_213

    :sswitch_f8
    const-string v2, "price"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_102

    goto/16 :goto_213

    :cond_102
    const/16 v3, 0x15

    goto/16 :goto_213

    :sswitch_106
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_110

    goto/16 :goto_213

    :cond_110
    const/16 v3, 0x14

    goto/16 :goto_213

    :sswitch_114
    const-string v2, "cta"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11e

    goto/16 :goto_213

    :cond_11e
    const/16 v3, 0x13

    goto/16 :goto_213

    :sswitch_122
    const-string v2, "id"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12c

    goto/16 :goto_213

    :cond_12c
    const/16 v3, 0x12

    goto/16 :goto_213

    :sswitch_130
    const-string v2, "offerBucket"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13a

    goto/16 :goto_213

    :cond_13a
    const/16 v3, 0x11

    goto/16 :goto_213

    :sswitch_13e
    const-string v2, "chevronAction"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_148

    goto/16 :goto_213

    :cond_148
    const/16 v3, 0x10

    goto/16 :goto_213

    :sswitch_14c
    const-string v2, "alternateTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_156

    goto/16 :goto_213

    :cond_156
    const/16 v3, 0xf

    goto/16 :goto_213

    :sswitch_15a
    const-string v2, "inEligible"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_164

    goto/16 :goto_213

    :cond_164
    const/16 v3, 0xe

    goto/16 :goto_213

    :sswitch_168
    const-string v2, "alternateOffersCta"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_172

    goto/16 :goto_213

    :cond_172
    const/16 v3, 0xd

    goto/16 :goto_213

    :sswitch_176
    const-string v2, "fomoUrgencyInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_180

    goto/16 :goto_213

    :cond_180
    const/16 v3, 0xc

    goto/16 :goto_213

    :sswitch_184
    const-string v2, "toggleDetails"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18e

    goto/16 :goto_213

    :cond_18e
    const/16 v3, 0xb

    goto/16 :goto_213

    :sswitch_192
    const-string v2, "trackingMetaData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19c

    goto/16 :goto_213

    :cond_19c
    const/16 v3, 0xa

    goto/16 :goto_213

    :sswitch_1a0
    const-string v2, "moreOffersCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1aa

    goto/16 :goto_213

    :cond_1aa
    const/16 v3, 0x9

    goto/16 :goto_213

    :sswitch_1ae
    const-string v2, "nepOfferType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b8

    goto/16 :goto_213

    :cond_1b8
    const/16 v3, 0x8

    goto/16 :goto_213

    :sswitch_1bc
    const-string v2, "imageIcon"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1c5

    goto :goto_213

    :cond_1c5
    const/4 v3, 0x7

    goto :goto_213

    :sswitch_1c7
    const-string v2, "disclaimerCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d0

    goto :goto_213

    :cond_1d0
    const/4 v3, 0x6

    goto :goto_213

    :sswitch_1d2
    const-string v2, "formattedPrice"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1db

    goto :goto_213

    :cond_1db
    const/4 v3, 0x5

    goto :goto_213

    :sswitch_1dd
    const-string v2, "basketOffers"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e6

    goto :goto_213

    :cond_1e6
    const/4 v3, 0x4

    goto :goto_213

    :sswitch_1e8
    const-string v2, "summaryDescriptions"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f1

    goto :goto_213

    :cond_1f1
    const/4 v3, 0x3

    goto :goto_213

    :sswitch_1f3
    const-string v2, "descriptions"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1fc

    goto :goto_213

    :cond_1fc
    const/4 v3, 0x2

    goto :goto_213

    :sswitch_1fe
    const-string v2, "addToCartCallout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_207

    goto :goto_213

    :cond_207
    const/4 v3, 0x1

    goto :goto_213

    :sswitch_209
    const-string v2, "subTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_212

    goto :goto_213

    :cond_212
    const/4 v3, 0x0

    :goto_213
    iget-object v1, p0, Laf/m;->c:Lxk/z;

    iget-object v2, p0, Laf/m;->d:Lxk/z;

    iget-object v4, p0, Laf/m;->f:Lxk/z;

    iget-object v5, p0, Laf/m;->a:Lxk/z;

    packed-switch v3, :pswitch_data_454

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_223
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/b;

    iput-object v1, v0, Laf/n;->w:LGe/b;

    goto/16 :goto_1d

    :pswitch_22d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/n;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_239
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/T2;

    iput-object v1, v0, Laf/n;->C:LMe/T2;

    goto/16 :goto_1d

    :pswitch_243
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/n;->B:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_24f
    iget-object v1, p0, Laf/m;->j:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Laf/n;->t:LLe/f;

    goto/16 :goto_1d

    :pswitch_25b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/n;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_267
    invoke-virtual {v5, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/n;->e:LTe/Q;

    goto/16 :goto_1d

    :pswitch_271
    invoke-virtual {v5, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/n;->o:LTe/Q;

    goto/16 :goto_1d

    :pswitch_27b
    iget-object v1, p0, Laf/m;->n:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/n;->H:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_287
    invoke-virtual {v5, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/n;->f:LTe/Q;

    goto/16 :goto_1d

    :pswitch_291
    invoke-virtual {v5, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/n;->x:LTe/Q;

    goto/16 :goto_1d

    :pswitch_29b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/n;->v:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_2a7
    iget-object v1, p0, Laf/m;->e:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LVf/f;

    iput-object v1, v0, Laf/n;->k:LVf/f;

    goto/16 :goto_1d

    :pswitch_2b3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/n;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_2bf
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/T2;

    iput-object v1, v0, Laf/n;->n:LMe/T2;

    goto/16 :goto_1d

    :pswitch_2c9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_2d5
    invoke-virtual {v4, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Laf/n;->l:LLe/f;

    goto/16 :goto_1d

    :pswitch_2df
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/n;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_2eb
    invoke-virtual {v2, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/T2;

    iput-object v1, v0, Laf/n;->j:LMe/T2;

    goto/16 :goto_1d

    :pswitch_2f5
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/b;

    iput-object v1, v0, Laf/n;->i:LGe/b;

    goto/16 :goto_1d

    :pswitch_2ff
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/n;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_30b
    iget-boolean v1, v0, Laf/n;->I:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/n;->I:Z

    goto/16 :goto_1d

    :pswitch_315
    invoke-virtual {v4, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Laf/n;->m:LLe/f;

    goto/16 :goto_1d

    :pswitch_31f
    iget-object v1, p0, Laf/m;->g:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/w;

    iput-object v1, v0, Laf/n;->p:LGe/w;

    goto/16 :goto_1d

    :pswitch_32b
    iget-object v1, p0, Laf/m;->k:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/n;->z:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_337
    iget-object v1, p0, Laf/m;->l:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Laf/n;->D:Ljava/util/Map;

    goto/16 :goto_1d

    :pswitch_343
    invoke-virtual {v4, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Laf/n;->s:LLe/f;

    goto/16 :goto_1d

    :pswitch_34d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/n;->A:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_359
    iget-object v1, p0, Laf/m;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/L;

    iput-object v1, v0, Laf/n;->g:LTe/L;

    goto/16 :goto_1d

    :pswitch_365
    invoke-virtual {v4, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Laf/n;->G:LLe/f;

    goto/16 :goto_1d

    :pswitch_36f
    invoke-virtual {v5, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/n;->y:LTe/Q;

    goto/16 :goto_1d

    :pswitch_379
    iget-object v1, p0, Laf/m;->m:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/n;->E:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_385
    iget-object v1, p0, Laf/m;->i:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/n;->r:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_391
    iget-object v1, p0, Laf/m;->h:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Laf/n;->q:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_39d
    invoke-virtual {v4, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Laf/n;->F:LLe/f;

    goto/16 :goto_1d

    :pswitch_3a7
    invoke-virtual {v5, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/Q;

    iput-object v1, v0, Laf/n;->u:LTe/Q;

    goto/16 :goto_1d

    :cond_3b1
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_3b9

    return-object v0

    :cond_3b9
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_3c2
    .sparse-switch
        -0x7c93a408 -> :sswitch_209
        -0x764123ac -> :sswitch_1fe
        -0x72850409 -> :sswitch_1f3
        -0x6e3f5143 -> :sswitch_1e8
        -0x6cf91503 -> :sswitch_1dd
        -0x6560da13 -> :sswitch_1d2
        -0x5ea0a1eb -> :sswitch_1c7
        -0x345ccb8c -> :sswitch_1bc
        -0x27f53de3 -> :sswitch_1ae
        -0x255acabc -> :sswitch_1a0
        -0x235f34da -> :sswitch_192
        -0x1c42d7b2 -> :sswitch_184
        -0x18ec7d94 -> :sswitch_176
        -0x14045a61 -> :sswitch_168
        -0xe9d49e4 -> :sswitch_15a
        -0xd0ad202 -> :sswitch_14c
        -0xa76dfaf -> :sswitch_13e
        -0x6b2e49a -> :sswitch_130
        0xd1b -> :sswitch_122
        0x18210 -> :sswitch_114
        0x368f3a -> :sswitch_106
        0x65fb149 -> :sswitch_f8
        0x6942258 -> :sswitch_ea
        0x21ad7033 -> :sswitch_dc
        0x2c3ecfa7 -> :sswitch_ce
        0x439b0e34 -> :sswitch_c0
        0x45f4dfcb -> :sswitch_b2
        0x4db0333d -> :sswitch_a4
        0x50d1c72e -> :sswitch_96
        0x51788c98 -> :sswitch_88
        0x61ad9236 -> :sswitch_7a
        0x6a049e8e -> :sswitch_6c
        0x70a88ce2 -> :sswitch_5e
        0x73e2652a -> :sswitch_50
        0x73e78fb6 -> :sswitch_42
        0x7b0087b9 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_454
    .packed-switch 0x0
        :pswitch_3a7
        :pswitch_39d
        :pswitch_391
        :pswitch_385
        :pswitch_379
        :pswitch_36f
        :pswitch_365
        :pswitch_359
        :pswitch_34d
        :pswitch_343
        :pswitch_337
        :pswitch_32b
        :pswitch_31f
        :pswitch_315
        :pswitch_30b
        :pswitch_2ff
        :pswitch_2f5
        :pswitch_2eb
        :pswitch_2df
        :pswitch_2d5
        :pswitch_2c9
        :pswitch_2bf
        :pswitch_2b3
        :pswitch_2a7
        :pswitch_29b
        :pswitch_291
        :pswitch_287
        :pswitch_27b
        :pswitch_271
        :pswitch_267
        :pswitch_25b
        :pswitch_24f
        :pswitch_243
        :pswitch_239
        :pswitch_22d
        :pswitch_223
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Laf/m;->read(LBk/a;)Laf/n;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Laf/n;)V
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_27c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "id"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->a:Ljava/lang/String;

    if-eqz v0, :cond_24

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_27

    :cond_24
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_27
    const-string v0, "title"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->b:Ljava/lang/String;

    if-eqz v0, :cond_34

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_37

    :cond_34
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_37
    const-string v0, "alternateTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->c:Ljava/lang/String;

    if-eqz v0, :cond_44

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_47

    :cond_44
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_47
    const-string v0, "offerType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->d:Ljava/lang/String;

    if-eqz v0, :cond_54

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_57

    :cond_54
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_57
    const-string v0, "newTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->e:LTe/Q;

    iget-object v2, p0, Laf/m;->a:Lxk/z;

    if-eqz v0, :cond_66

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_69

    :cond_66
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_69
    const-string v0, "headerTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->f:LTe/Q;

    if-eqz v0, :cond_76

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_79

    :cond_76
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_79
    const-string v0, "imageIcon"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->g:LTe/L;

    if-eqz v0, :cond_88

    iget-object v3, p0, Laf/m;->b:Lxk/z;

    invoke-virtual {v3, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_8b

    :cond_88
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_8b
    const-string v0, "iconUrl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->h:Ljava/lang/String;

    if-eqz v0, :cond_98

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_9b

    :cond_98
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_9b
    const-string v0, "chevronAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->i:LGe/b;

    iget-object v3, p0, Laf/m;->c:Lxk/z;

    if-eqz v0, :cond_aa

    invoke-virtual {v3, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ad

    :cond_aa
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ad
    const-string v0, "offerBucket"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->j:LMe/T2;

    iget-object v4, p0, Laf/m;->d:Lxk/z;

    if-eqz v0, :cond_bc

    invoke-virtual {v4, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_bf

    :cond_bc
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_bf
    const-string v0, "exclusiveDealsClaim"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->k:LVf/f;

    if-eqz v0, :cond_ce

    iget-object v5, p0, Laf/m;->e:Lxk/z;

    invoke-virtual {v5, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_d1

    :cond_ce
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_d1
    const-string v0, "cta"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->l:LLe/f;

    iget-object v5, p0, Laf/m;->f:Lxk/z;

    if-eqz v0, :cond_e0

    invoke-virtual {v5, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_e3

    :cond_e0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_e3
    const-string v0, "alternateOffersCta"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->m:LLe/f;

    if-eqz v0, :cond_f0

    invoke-virtual {v5, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_f3

    :cond_f0
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_f3
    const-string v0, "price"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->n:LMe/T2;

    if-eqz v0, :cond_100

    invoke-virtual {v4, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_103

    :cond_100
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_103
    const-string v0, "nepFomoData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->o:LTe/Q;

    if-eqz v0, :cond_110

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_113

    :cond_110
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_113
    const-string v0, "fomoUrgencyInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->p:LGe/w;

    if-eqz v0, :cond_122

    iget-object v6, p0, Laf/m;->g:Lxk/z;

    invoke-virtual {v6, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_125

    :cond_122
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_125
    const-string v0, "descriptions"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->q:Ljava/util/List;

    if-eqz v0, :cond_139

    iget-object v6, p0, Laf/m;->h:LJn/a$r;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v6, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_13c

    :cond_139
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_13c
    const-string v0, "summaryDescriptions"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->r:Ljava/util/List;

    if-eqz v0, :cond_150

    iget-object v6, p0, Laf/m;->i:LJn/a$r;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v6, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_153

    :cond_150
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_153
    const-string v0, "moreOffersCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->s:LLe/f;

    if-eqz v0, :cond_160

    invoke-virtual {v5, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_163

    :cond_160
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_163
    const-string v0, "claimButton"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->t:LLe/f;

    if-eqz v0, :cond_172

    iget-object v6, p0, Laf/m;->j:Lxk/z;

    invoke-virtual {v6, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_175

    :cond_172
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_175
    const-string v0, "subTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->u:LTe/Q;

    if-eqz v0, :cond_182

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_185

    :cond_182
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_185
    const-string v0, "checked"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->v:Ljava/lang/Boolean;

    if-eqz v0, :cond_194

    sget-object v6, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v6, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_197

    :cond_194
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_197
    const-string v0, "checkBoxAction"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->w:LGe/b;

    if-eqz v0, :cond_1a4

    invoke-virtual {v3, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1a7

    :cond_1a4
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1a7
    const-string v0, "offerCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->x:LTe/Q;

    if-eqz v0, :cond_1b4

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b7

    :cond_1b4
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b7
    const-string v0, "formattedPrice"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->y:LTe/Q;

    if-eqz v0, :cond_1c4

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1c7

    :cond_1c4
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1c7
    const-string v0, "toggleDetails"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->z:Ljava/util/List;

    if-eqz v0, :cond_1db

    iget-object v2, p0, Laf/m;->k:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_1de

    :cond_1db
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1de
    const-string v0, "nepOfferType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->A:Ljava/lang/String;

    if-eqz v0, :cond_1eb

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1ee

    :cond_1eb
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1ee
    const-string v0, "discountLineItemType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->B:Ljava/lang/String;

    if-eqz v0, :cond_1fb

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1fe

    :cond_1fb
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1fe
    const-string v0, "offerInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->C:LMe/T2;

    if-eqz v0, :cond_20b

    invoke-virtual {v4, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_20e

    :cond_20b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_20e
    const-string v0, "trackingMetaData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->D:Ljava/util/Map;

    if-eqz v0, :cond_21d

    iget-object v1, p0, Laf/m;->l:LJn/a$t;

    invoke-virtual {v1, p1, v0}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_220

    :cond_21d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_220
    const-string v0, "basketOffers"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->E:Ljava/util/List;

    if-eqz v0, :cond_234

    iget-object v1, p0, Laf/m;->m:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_237

    :cond_234
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_237
    const-string v0, "addToCartCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->F:LLe/f;

    if-eqz v0, :cond_244

    invoke-virtual {v5, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_247

    :cond_244
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_247
    const-string v0, "disclaimerCallout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->G:LLe/f;

    if-eqz v0, :cond_254

    invoke-virtual {v5, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_257

    :cond_254
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_257
    const-string v0, "paymentOffers"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/n;->H:Ljava/util/List;

    if-eqz v0, :cond_26b

    iget-object v1, p0, Laf/m;->n:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_26e

    :cond_26b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_26e
    const-string v0, "inEligible"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Laf/n;->I:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_27c
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Laf/n;

    invoke-virtual {p0, p1, p2}, Laf/m;->write(LBk/c;Laf/n;)V

    return-void
.end method
