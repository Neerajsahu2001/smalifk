.class public final Laf/l;
.super Ljava/lang/Object;
.source "ProductOfferDescription.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:LTe/Q;

.field public b:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LTe/Q;",
            ">;"
        }
    .end annotation
.end field

.field public c:LMe/T2;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
