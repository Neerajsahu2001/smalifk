.class public final Laf/q;
.super Lxk/z;
.source "SummaryFlags$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Laf/r;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Laf/r;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Laf/r;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Laf/q;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Laf/r;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Laf/r;

    invoke-direct {v0}, Laf/r;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_11f

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_124

    goto/16 :goto_a7

    :sswitch_34
    const-string v2, "enableCompare"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_a7

    :cond_3e
    const/16 v3, 0x9

    goto/16 :goto_a7

    :sswitch_42
    const-string v2, "enableChat"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_a7

    :cond_4c
    const/16 v3, 0x8

    goto/16 :goto_a7

    :sswitch_50
    const-string v2, "enableDiscountTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_59

    goto :goto_a7

    :cond_59
    const/4 v3, 0x7

    goto :goto_a7

    :sswitch_5b
    const-string v2, "showSecondaryTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_64

    goto :goto_a7

    :cond_64
    const/4 v3, 0x6

    goto :goto_a7

    :sswitch_66
    const-string v2, "enableVisualDiscovery"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6f

    goto :goto_a7

    :cond_6f
    const/4 v3, 0x5

    goto :goto_a7

    :sswitch_71
    const-string v2, "enableOfferTag"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7a

    goto :goto_a7

    :cond_7a
    const/4 v3, 0x4

    goto :goto_a7

    :sswitch_7c
    const-string v2, "enableWishlist"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_85

    goto :goto_a7

    :cond_85
    const/4 v3, 0x3

    goto :goto_a7

    :sswitch_87
    const-string v2, "swatchAvailableOnBrowsePage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_90

    goto :goto_a7

    :cond_90
    const/4 v3, 0x2

    goto :goto_a7

    :sswitch_92
    const-string v2, "enableFlipkartAdvantage"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9b

    goto :goto_a7

    :cond_9b
    const/4 v3, 0x1

    goto :goto_a7

    :sswitch_9d
    const-string v2, "similarProductsAvailable"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a6

    goto :goto_a7

    :cond_a6
    const/4 v3, 0x0

    :goto_a7
    packed-switch v3, :pswitch_data_14e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_af
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/r;->c:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_bb
    iget-boolean v1, v0, Laf/r;->i:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/r;->i:Z

    goto/16 :goto_1d

    :pswitch_c5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/r;->j:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_d1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/r;->h:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_dd
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/r;->g:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_e9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/r;->a:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_f5
    iget-boolean v1, v0, Laf/r;->f:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/r;->f:Z

    goto/16 :goto_1d

    :pswitch_ff
    iget-boolean v1, v0, Laf/r;->d:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/r;->d:Z

    goto/16 :goto_1d

    :pswitch_109
    iget-boolean v1, v0, Laf/r;->e:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/r;->e:Z

    goto/16 :goto_1d

    :pswitch_113
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Laf/r;->b:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :cond_11f
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_124
    .sparse-switch
        -0x67c438e6 -> :sswitch_9d
        -0x642b119d -> :sswitch_92
        -0x30ee05fb -> :sswitch_87
        -0x253cf398 -> :sswitch_7c
        -0x194fe9bf -> :sswitch_71
        0x1a16c24d -> :sswitch_66
        0x23acb1a1 -> :sswitch_5b
        0x2e894116 -> :sswitch_50
        0x70d0b37b -> :sswitch_42
        0x7b6105e2 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_14e
    .packed-switch 0x0
        :pswitch_113
        :pswitch_109
        :pswitch_ff
        :pswitch_f5
        :pswitch_e9
        :pswitch_dd
        :pswitch_d1
        :pswitch_c5
        :pswitch_bb
        :pswitch_af
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Laf/q;->read(LBk/a;)Laf/r;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Laf/r;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "enableOfferTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/r;->a:Ljava/lang/Boolean;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "similarProductsAvailable"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/r;->b:Ljava/lang/Boolean;

    if-eqz v0, :cond_2a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "enableCompare"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/r;->c:Ljava/lang/Boolean;

    if-eqz v0, :cond_3c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "swatchAvailableOnBrowsePage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Laf/r;->d:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "enableFlipkartAdvantage"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Laf/r;->e:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "enableWishlist"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Laf/r;->f:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "enableVisualDiscovery"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/r;->g:Ljava/lang/Boolean;

    if-eqz v0, :cond_6c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_6f

    :cond_6c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_6f
    const-string v0, "showSecondaryTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/r;->h:Ljava/lang/Boolean;

    if-eqz v0, :cond_7e

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_81

    :cond_7e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_81
    const-string v0, "enableChat"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Laf/r;->i:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "enableDiscountTag"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Laf/r;->j:Ljava/lang/Boolean;

    if-eqz p2, :cond_9a

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_9d

    :cond_9a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_9d
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Laf/r;

    invoke-virtual {p0, p1, p2}, Laf/q;->write(LBk/c;Laf/r;)V

    return-void
.end method
