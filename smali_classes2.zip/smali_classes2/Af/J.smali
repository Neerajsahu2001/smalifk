.class public Laf/j;
.super LMe/R3;
.source "ProductMinValue.java"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Lcom/flipkart/rome/datatypes/response/product/Titles;

.field public d:Lhh/b;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LMe/R3;-><init>()V

    return-void
.end method
