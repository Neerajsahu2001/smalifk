.class public final Laf/e;
.super Lxk/z;
.source "BumpUpRateValue$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Laf/f;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Laf/f;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Laf/f;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Laf/e;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Laf/f;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Laf/f;

    invoke-direct {v0}, Laf/f;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_79

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_96

    goto :goto_53

    :sswitch_33
    const-string v2, "title"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_53

    :cond_3c
    const/4 v3, 0x2

    goto :goto_53

    :sswitch_3e
    const-string v2, "bumpedUp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_53

    :cond_47
    const/4 v3, 0x1

    goto :goto_53

    :sswitch_49
    const-string v2, "description"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_53

    :cond_52
    const/4 v3, 0x0

    :goto_53
    packed-switch v3, :pswitch_data_a4

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_5a
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/f;->a:Ljava/lang/String;

    goto :goto_1d

    :pswitch_65
    iget-boolean v1, v0, Laf/f;->c:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Laf/f;->c:Z

    goto :goto_1d

    :pswitch_6e
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Laf/f;->b:Ljava/lang/String;

    goto :goto_1d

    :cond_79
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Laf/f;->a:Ljava/lang/String;

    if-eqz p1, :cond_8d

    iget-object p1, v0, Laf/f;->b:Ljava/lang/String;

    if-eqz p1, :cond_85

    return-object v0

    :cond_85
    new-instance p1, Ljava/io/IOException;

    const-string v0, "description cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_8d
    new-instance p1, Ljava/io/IOException;

    const-string v0, "title cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_96
    .sparse-switch
        -0x66ca7c04 -> :sswitch_49
        -0x4e39ce30 -> :sswitch_3e
        0x6942258 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_a4
    .packed-switch 0x0
        :pswitch_6e
        :pswitch_65
        :pswitch_5a
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Laf/e;->read(LBk/a;)Laf/f;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Laf/f;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "title"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/f;->a:Ljava/lang/String;

    if-eqz v0, :cond_39

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "description"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Laf/f;->b:Ljava/lang/String;

    if-eqz v0, :cond_31

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "bumpedUp"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Laf/f;->c:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_31
    new-instance p1, Ljava/io/IOException;

    const-string p2, "description cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_39
    new-instance p1, Ljava/io/IOException;

    const-string p2, "title cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Laf/f;

    invoke-virtual {p0, p1, p2}, Laf/e;->write(LBk/c;Laf/f;)V

    return-void
.end method
