.class public interface abstract LDa/a;
.super Ljava/lang/Object;
.source "FdpHttpService.java"


# virtual methods
.method public abstract sendDataToFDP(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONArray;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "appVersion"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "collectorEndPoint"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Visit-Id"
        .end annotation
    .end param
    .param p4    # Lorg/json/JSONArray;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "{appVersion}/data/collector/{collectorEndPoint}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lorg/json/JSONArray;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/a;
        value = "gzip"
    .end annotation

    .annotation runtime Lua/b;
        value = 0x0
    .end annotation

    .annotation runtime Lua/d;
    .end annotation
.end method
