.class public interface abstract LDa/b;
.super Ljava/lang/Object;
.source "MAPIHttpService.java"


# virtual methods
.method public abstract acknowledgeKevlar(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "rt"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/kevlar/ack"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ltf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract addItemsAndCheckout(ILcd/h;Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # I
        .annotation runtime Laq/s;
            value = "version"
        .end annotation
    .end param
    .param p2    # Lcd/h;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "infoLevel"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Marketplace-Context"
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "{version}/checkout"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcd/h;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract addToBasket(Lbd/d;)Lta/a;
    .param p1    # Lbd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/cart/browse"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lbd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LCe/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract addToCart(Lbd/f;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Lbd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Fetch-Id"
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/cart"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lbd/f;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LEe/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract addToCompareBasket(LRa/b;)Lta/a;
    .param p1    # LRa/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "3/compare/basket"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LRa/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LRa/d;",
            ">;",
            "LGe/e0<",
            "LRa/d;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract addToWishlist(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "productIds"
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "2/ugc/wishlist/add"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LFb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract callCheckoutInit(ILcd/d;Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # I
        .annotation runtime Laq/s;
            value = "version"
        .end annotation
    .end param
    .param p2    # Lcd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "infoLevel"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Marketplace-Context"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "{version}/checkout"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcd/d;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract checkEligibilityApplication(Ljd/c;)Lta/a;
    .param p1    # Ljd/c;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/fintech/application"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljd/c;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LKf/j;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract checkEligibilityApplicationStatus(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "type"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/fintech/application"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LKf/h;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract checkUserEnrolledInProgram(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "type"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/fintech/accountStatus"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LJf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract clearCart(Lad/f;)Lta/a;
    .param p1    # Lad/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/cart/clear"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lad/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LBe/h;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract decodeQrCode(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "qrCode"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/ultra/qr-decoder"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lzb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract decodeUrl(Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "encodedUrl"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "referrer"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/urlencoder/decode"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lzb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract decryptUltraPaymentToken(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "encryptedPaymentToken"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/ultra/decrypt/payment-token"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LGh/j;",
            ">;",
            "LGe/e0<",
            "Lfb/J;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract deleteAnswer(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "answerId"
        .end annotation
    .end param
    .annotation runtime Laq/b;
        value = "1/qna/answers/{answerId}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract deleteDataForReactView(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/b;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation
.end method

.method public abstract deleteDataForReactViewSecure(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/b;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract deleteFromWishlist(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "productIds"
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "2/ugc/wishlist/delete"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LFb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract deleteInAppNotification(Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "notificationId"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "type"
        .end annotation
    .end param
    .annotation runtime Laq/b;
        value = "2/notification/{notificationId}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lcb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract deleteUltraScopes(Ljava/lang/String;Ljava/util/List;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "clientId"
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/h;
        hasBody = true
        method = "DELETE"
        path = "/2/ultra/scopes"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract doSearch(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lcom/flipkart/mapi/model/discovery/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract editQnaQuestion(Ljava/lang/String;LAd/d;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "questionId"
        .end annotation
    .end param
    .param p2    # LAd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "1/qna/questions/{questionId}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LAd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract emailAssociationCheckRequest(LId/b;)Lta/a;
    .param p1    # LId/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/user/association/check/email"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LId/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Loe/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchActionPageData(Lpd/b;)Lta/a;
    .param p1    # Lpd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/action/view"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lpd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lcg/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchActionPageData(Lpd/b;Ljava/util/Map;)Lta/a;
    .param p1    # Lpd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/action/view"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lpd/b;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lcg/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchAppLaunchDetails()Lta/a;
    .annotation runtime Laq/f;
        value = "1/app/launch"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lta/a<",
            "LGe/e0<",
            "LGe/j;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchBottomBarV2Data(LZc/b;)Lta/a;
    .param p1    # LZc/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "2/data/bottomBar"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LZc/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LZf/f;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchBottomNavBarData()Lta/a;
    .annotation runtime Laq/f;
        value = "1/data/bottomBar"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lta/a<",
            "LGe/e0<",
            "LXf/h;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchCompareBasket(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "basketId"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/compare/basket"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LRa/d;",
            ">;",
            "LGe/e0<",
            "LRa/d;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchImageReviewData(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljg/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract fetchInAppNotification(IJ)Lta/a;
    .param p1    # I
        .annotation runtime Laq/t;
            value = "count"
        .end annotation
    .end param
    .param p2    # J
        .annotation runtime Laq/t;
            value = "before"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/notification"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IJ)",
            "Lta/a<",
            "LGe/e0<",
            "Lcb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchPageData(Ljava/lang/String;Lwd/t;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Request-MetaInfo"
        .end annotation
    .end param
    .param p5    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lwd/t;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljg/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract fetchPageData(Lwd/t;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Request-MetaInfo"
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/page/fetch"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd/t;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljg/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract fetchQuestionnaireData(Lwd/j;)Lta/a;
    .param p1    # Lwd/j;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/discover/contextual/content"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd/j;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljg/e0;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract fetchReactPageData(Ljava/lang/String;Lwd/t;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Request-MetaInfo"
        .end annotation
    .end param
    .param p5    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lwd/t;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract fetchReactPageData(Lwd/t;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Request-MetaInfo"
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/page/fetch"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd/t;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract fetchTestSuite(LWd/f;)Lta/a;
    .param p1    # LWd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/condition-assessor/fetch-test-suite"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LWd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lfi/b;",
            ">;",
            "LGe/e0<",
            "Lxk/p;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract fetchTooltipData(Lwd/t;)Lta/a;
    .param p1    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/user/tooltip/fetch"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd/t;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lpg/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract fetchVernacRevertNudge(LTd/f;)Lta/a;
    .param p1    # LTd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/vernac/revertNudge"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LTd/h;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract generate8OTP(LKd/d;)Lta/a;
    .param p1    # LKd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "8/user/otp/generate"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LKd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LQh/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract generateDyrImage(Lid/b;)Lta/a;
    .param p1    # Lid/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/dyr/generateImage"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lid/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lyf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract generateOTP(Ljava/lang/String;ZLjava/lang/String;Z)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "loginId"
        .end annotation
    .end param
    .param p2    # Z
        .annotation runtime Laq/c;
            value = "churnEmailRequest"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "state"
        .end annotation
    .end param
    .param p4    # Z
        .annotation runtime Laq/c;
            value = "addAppHash"
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "5/user/otp/generate"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Z)",
            "Lta/a<",
            "LGe/e0<",
            "LPh/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract generateSSOSessionNonce(Lnd/b;)Lta/a;
    .param p1    # Lnd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/loginV2/sso"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lnd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LWf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getAbbProductDetails(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "listingId"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "productId"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "rateCardId"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "abbListingId"
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "abbProductId"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/abb/rate-card/discovery"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lde/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getAppConfig(LLa/b;)Lta/a;
    .param p1    # LLa/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/resource/android/appConfigs"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LLa/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LLa/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getAsJson(Ljava/lang/String;Ljava/lang/Object;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getAsJson(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getAutoSuggest(Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "q"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "marketplace"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/discover/autosuggest?prefetchOn=false"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lqe/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getAutoSuggestV4(LXc/b;)Lta/a;
    .param p1    # LXc/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/discover/autosuggest"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LXc/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lre/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getAutoSuggestV5(LYc/d;)Lta/a;
    .param p1    # LYc/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/discover/autosuggest"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LYc/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lue/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getBundleServerConfig(LBd/b;)Lta/a;
    .param p1    # LBd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/binary/react"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lmh/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getBundleServerConfigForTestBuild(Ljava/lang/String;LBd/b;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "base_url"
        .end annotation
    .end param
    .param p2    # LBd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "http://{base_url}/1/binary/react"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LBd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lmh/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getComponentsForReact(Ljava/lang/String;LLa/b;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # LLa/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LLa/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lrb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getConditionerAccessorQuote(Lokhttp3/RequestBody;Ljava/lang/String;)Lta/a;
    .param p1    # Lokhttp3/RequestBody;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-APP-CHECKSUM"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/conditionerAccessor/quote"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/RequestBody;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Lxk/p;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getData(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            encoded = true
            value = "screenName"
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/k;
        value = {
            "psv-only: true"
        }
    .end annotation

    .annotation runtime Laq/o;
        value = "3/data/{screenName}/widgets"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/flipkart/mapi/model/component/data/WidgetData;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getDataForReactView(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getDataForReactViewSecure(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getDeferredDeepLinkFeedback(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "value"
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "2/defdl/feedback/{value}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LJa/l;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFacetCountV1(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/u;
            encoded = true
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/page/browse/facets"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFacetCountV2(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/u;
            encoded = true
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/product/smart-browse/facets"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFacets(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lbb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFacetsV1(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/u;
            encoded = true
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/page/browse/facets"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LOa/h;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFacetsV2(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/u;
            encoded = true
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/product/smart-browse/facets"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LOa/h;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFaqData(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFlickAdsVMAP(LUd/b;)Lta/a;
    .param p1    # LUd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/ads/vmap"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lai/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFlickMeta(LUd/f;)Lta/a;
    .param p1    # LUd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/asset/meta"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lai/d;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFlickNextAsset(LUd/f;)Lta/a;
    .param p1    # LUd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/asset/next"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lai/l;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFlickPlaybackContextV1(LUd/f;)Lta/a;
    .param p1    # LUd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/asset/playbackContext"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lci/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFlickPlaybackContextV2(LUd/f;)Lta/a;
    .param p1    # LUd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "2/flick/asset/playbackContext"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lci/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getFlickSeasonResponse(LUd/f;)Lta/a;
    .param p1    # LUd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/asset/season/details"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lai/j;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getInfiniteData(Ljava/lang/String;LWc/b;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # LWc/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LWc/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LYd/a;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getInfiniteListData(Ljava/lang/String;LWc/h;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # LWc/h;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LWc/h;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lnb/d;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getInteractiveGameResponse(LUd/f;)Lta/a;
    .param p1    # LUd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/asset/interactive/gameConfig"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lbi/d;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getInviteStatus(LIg/h;)Lta/a;
    .param p1    # LIg/h;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/referral-service/referral/inviteStatus"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LIg/h;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIg/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getInviteStatus(LIg/h;Ljava/lang/String;)Lta/a;
    .param p1    # LIg/h;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "searchFilter"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/referral-service/v1.1/inviteStatus"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LIg/h;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIg/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getInviteStatusGamification(LIg/h;Ljava/lang/String;Ljava/lang/Long;)Lta/a;
    .param p1    # LIg/h;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "searchFilter"
        .end annotation
    .end param
    .param p3    # Ljava/lang/Long;
        .annotation runtime Laq/t;
            value = "referralProgramId"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/gamification/referral-service/v1/refereeEligibility"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LIg/h;",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIg/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getJWT(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/blobio/authenticate"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LAe/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getLayout(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            encoded = true
            value = "screenName"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "layoutId"
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/layout/page/{screenName}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LYa/f;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getLayouts(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/layout/pages"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LYa/f;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getMarketplaceServicabilityInfo(Lvb/g;)Lta/a;
    .param p1    # Lvb/g;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/marketplace/serviceability"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvb/g;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lvb/a;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getMarketplaceServiceability(Lod/d;)Lta/a;
    .param p1    # Lod/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/marketplace/serviceability"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lod/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lag/b;",
            ">;",
            "LGe/e0<",
            "LKe/d;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getOfferTerms(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "offerId"
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/discover/santaOfferDetails"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lmb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getOfferTermsV3(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "offerId"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/product/offers/{offerId}/tnc"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getPhonePeChecksum(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "type"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/phonepe/checksum"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lah/b;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getPincodeUsingLocation(Ljava/lang/Double;Ljava/lang/Double;)Lta/a;
    .param p1    # Ljava/lang/Double;
        .annotation runtime Laq/t;
            value = "latitude"
        .end annotation
    .end param
    .param p2    # Ljava/lang/Double;
        .annotation runtime Laq/t;
            value = "longitude"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/location/parameterizedAddress"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Double;",
            "Ljava/lang/Double;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ldb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getProductInfo(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/util/Map;)Lta/a;
    .param p1    # I
        .annotation runtime Laq/s;
            value = "infoLevel"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "pids"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "lids"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "offerIds"
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "pin"
        .end annotation
    .end param
    .param p6    # Z
        .annotation runtime Laq/t;
            value = "disableMultipleImage"
        .end annotation
    .end param
    .param p7    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/discover/productInfo/{infoLevel}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lob/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getProductPreview(LRf/b;)Lta/a;
    .param p1    # LRf/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/sharingKit/preview"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LRf/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LSf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getProductServicabiltyInfo(Lvb/g;)Lta/a;
    .param p1    # Lvb/g;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/product/serviceability"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvb/g;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getProductSummary(Lcom/flipkart/mapi/model/discovery/B;)Lta/a;
    .param p1    # Lcom/flipkart/mapi/model/discovery/B;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/product/summary"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flipkart/mapi/model/discovery/B;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/flipkart/mapi/model/discovery/z;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getProductSummaryV3(Ljava/lang/String;Lcom/flipkart/mapi/model/discovery/D;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Lcom/flipkart/mapi/model/discovery/D;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/flipkart/mapi/model/discovery/D;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getProteusResources(Ljava/util/Map;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/layout/query"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lub/b;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getPullNotificationData(Ljb/i;)Lta/a;
    .param p1    # Ljb/i;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/notification/pull"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljb/i;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljb/e;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getPurchaseNudgesConfig(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "source"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "/1/purchaseNudges/{source}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LXd/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getReco(Ljava/lang/String;ILjava/lang/String;ZLjava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "productIds"
        .end annotation
    .end param
    .param p2    # I
        .annotation runtime Laq/t;
            value = "maxItemsToFetch"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "source"
        .end annotation
    .end param
    .param p4    # Z
        .annotation runtime Laq/t;
            value = "disableMultipleImage"
        .end annotation
    .end param
    .param p5    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/recommendation/product"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/flipkart/mapi/model/component/data/WidgetData;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getRecoAndComboData(Ljava/lang/String;ILjava/lang/String;ZLjava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "productId"
        .end annotation
    .end param
    .param p2    # I
        .annotation runtime Laq/t;
            value = "maxItemsToFetch"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "source"
        .end annotation
    .end param
    .param p4    # Z
        .annotation runtime Laq/t;
            value = "disableMultipleImage"
        .end annotation
    .end param
    .param p5    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/hack/product/recommendation"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/flipkart/mapi/model/component/data/WidgetData;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getRefreshedProductCards(LWc/d;)Lta/a;
    .param p1    # LWc/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/product/cardsrefresh"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LWc/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LUa/j;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getReviews(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getShortenedUrl(LRf/d;)Lta/a;
    .param p1    # LRf/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/shortener/shorten"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LRf/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LSf/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getSignupStatus(LMd/b;)Lta/a;
    .param p1    # LMd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "6/user/signup/status"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LMd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LSh/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getSolicitAnswersData(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getUltraCoinEarningInfo(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "clientId"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "4/ultra/coinEarningInfo"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getUltraConfig(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "clientId"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/ultra/config"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LHh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getUltraOfferTerms(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "pzaid"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "1/payzippy/offer/terms/{pzaid}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LZg/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getUltraOffers(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "clientId"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/ultra/offer/active"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LGh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getUltraScopes(Ljava/lang/String;Z)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "clientId"
        .end annotation
    .end param
    .param p2    # Z
        .annotation runtime Laq/t;
            value = "fetchResource"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/ultra/scopes"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)",
            "Lta/a<",
            "LGe/e0<",
            "LGh/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getUltraScopesV3(Ljava/lang/String;Z)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "clientId"
        .end annotation
    .end param
    .param p2    # Z
        .annotation runtime Laq/t;
            value = "fetchResource"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/ultra/scopes"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)",
            "Lta/a<",
            "LGe/e0<",
            "LIh/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getUpdateGraphForReact(Ljava/lang/String;LLa/b;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # LLa/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LLa/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lrb/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getUserState(LQd/b;)Lta/a;
    .param p1    # LQd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/user/state"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LQd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LYh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract getVASStoreListings(Lcom/flipkart/mapi/model/component/PageRequestContext;)Lta/a;
    .param p1    # Lcom/flipkart/mapi/model/component/PageRequestContext;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/discover/data/vas/listings"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flipkart/mapi/model/component/PageRequestContext;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LDb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getWidgetPage(Ljava/lang/String;Ljava/lang/String;Lfb/c0;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            encoded = true
            value = "pageName"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p3    # Lfb/c0;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/page/dynamic/{pageName}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lfb/c0;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lcom/flipkart/mapi/model/component/PageDataResponse;",
            ">;",
            "LGe/e0<",
            "Lcom/flipkart/mapi/model/component/PageDataResponse;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getWidgetPageV2(Ljava/lang/String;Ljava/lang/String;Lfb/c0;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            encoded = true
            value = "pageName"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p3    # Lfb/c0;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/page/dynamic/{pageName}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lfb/c0;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LZa/d;",
            ">;",
            "LGe/e0<",
            "LZa/d;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getWishListSummary(Lcom/flipkart/mapi/model/discovery/B;)Lta/a;
    .param p1    # Lcom/flipkart/mapi/model/discovery/B;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/product/summary"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flipkart/mapi/model/discovery/B;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LLe/f<",
            "Lcom/flipkart/mapi/model/component/data/renderables/y0;",
            ">;>;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract getWishlist(IIILjava/util/Map;)Lta/a;
    .param p1    # I
        .annotation runtime Laq/t;
            value = "start"
        .end annotation
    .end param
    .param p2    # I
        .annotation runtime Laq/t;
            value = "count"
        .end annotation
    .end param
    .param p3    # I
        .annotation runtime Laq/t;
            value = "infoLevel"
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/ugc/wishlist"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(III",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LFb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract googleLogin(Ljava/lang/String;Ljava/lang/String;Z)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "socialType"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "accessToken"
        .end annotation
    .end param
    .param p3    # Z
        .annotation runtime Laq/c;
            value = "mobileLogin"
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "4/user/{socialType}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z)",
            "Lta/a<",
            "LGe/e0<",
            "LTh/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract inAppMarkAllRead()Lta/a;
    .annotation runtime Laq/o;
        value = "2/notification/markAllRead"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lta/a<",
            "LGe/e0<",
            "Lcb/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract ingestGuidedNavigationEvent(Ljava/lang/String;Lpg/A;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "type"
        .end annotation
    .end param
    .param p2    # Lpg/A;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/user/guided/navigation/{type}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lpg/A;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract insertUltraScopes(Ljava/lang/String;Ljava/util/List;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "clientId"
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "2/ultra/scopes"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "LGh/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract joinWaitList(Lbd/f;)Lta/a;
    .param p1    # Lbd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/cart/waitlist"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lbd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LJa/G;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract login(Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "loginId"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "password"
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "4/user/login"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LNh/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract logout()Lta/a;
    .annotation runtime Laq/o;
        value = "2/user/logout"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lta/a<",
            "LGe/e0<",
            "LOh/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract mockDELETE(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/b;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract mockGET(Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/f;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract mockPOST(Ljava/lang/String;Ljava/lang/Object;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract mockPUT(Ljava/lang/String;Ljava/lang/Object;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/p;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract notifyMe(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "email"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "productId"
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "2/ugc/notifyMe"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract postAnswerForQuestion(LUd/d;)Lta/a;
    .param p1    # LUd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/asset/interactive/answers"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/String;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract postDataForReactView(Ljava/lang/String;Ljava/util/Map;Ljava/lang/Object;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Object;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation
.end method

.method public abstract postDataForReactViewSecure(Ljava/lang/String;Ljava/util/Map;Ljava/lang/Object;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Object;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract postFlickBookmark(LVd/d;)Lta/a;
    .param p1    # LVd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/flick/asset/bookmark"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LVd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/String;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract postFormDataForReactView(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/d;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation
.end method

.method public abstract postFormDataForReactViewSecure(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/d;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract postTestResults(Ljava/lang/String;Lokhttp3/RequestBody;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-EsKey"
        .end annotation
    .end param
    .param p2    # Lokhttp3/RequestBody;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/condition-assessor/test-results"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lokhttp3/RequestBody;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/p;",
            ">;",
            "LGe/e0<",
            "Lxk/p;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract postTrafficGenSession(Lcom/flipkart/mapi/model/component/data/renderables/b;)Lta/a;
    .param p1    # Lcom/flipkart/mapi/model/component/data/renderables/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "2/session/tg-info"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flipkart/mapi/model/component/data/renderables/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lzh/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract putDataForReactView(Ljava/lang/String;Ljava/util/Map;Ljava/lang/Object;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/p;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Object;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation
.end method

.method public abstract putDataForReactViewSecure(Ljava/lang/String;Ljava/util/Map;Ljava/lang/Object;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/p;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Object;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract putFormDataForReactView(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/d;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/p;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation
.end method

.method public abstract putFormDataForReactViewSecure(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation runtime Laq/d;
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/p;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LJa/C;",
            "LJa/C;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract refreshKevlarToken(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "rt"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/kevlar/refresh"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ltf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract register(Ljava/lang/String;Lhd/f;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "checksum"
        .end annotation
    .end param
    .param p2    # Lhd/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/register/app"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lhd/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lwf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract registerConditionerAccessorFlow(Lokhttp3/RequestBody;Ljava/lang/String;)Lta/a;
    .param p1    # Lokhttp3/RequestBody;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-APP-CHECKSUM"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/conditionerAccessor/register"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/RequestBody;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LFe/b;",
            ">;",
            "LGe/e0<",
            "Lxk/p;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract registerForSale(Lzd/b;)Lta/a;
    .param p1    # Lzd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "2/sale/register"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LJa/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract registerForSaleV4(Lzd/b;)Lta/a;
    .param p1    # Lzd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "2/sale/register"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lch/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract registerGamificationEvent(LOf/f;)Lta/a;
    .param p1    # LOf/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/gamification/ingest/events"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LOf/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LOf/h;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract registerPushNotification(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "state"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "optIn"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "appType"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "appVersion"
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "appPlatform"
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "deviceId"
        .end annotation
    .end param
    .param p7    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "token"
        .end annotation
    .end param
    .param p8    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "instanceId"
        .end annotation
    .end param
    .param p9    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "osName"
        .end annotation
    .end param
    .param p10    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "osVersion"
        .end annotation
    .end param
    .param p11    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "deviceManufacturer"
        .end annotation
    .end param
    .param p12    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "deviceModel"
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "3/notification/push/register"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract registerReferrer(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "value"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "deviceId"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "rawDeviceId"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "channel"
        .end annotation
    .end param
    .param p5    # J
        .annotation runtime Laq/c;
            value = "firstLaunch"
        .end annotation
    .end param
    .param p7    # Ljava/lang/String;
        .annotation runtime Laq/c;
            value = "installId"
        .end annotation
    .end param
    .annotation runtime Laq/e;
    .end annotation

    .annotation runtime Laq/o;
        value = "2/register/referral"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "J",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract removeFromCompareBasket(Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "basketId"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "productIds"
        .end annotation
    .end param
    .annotation runtime Laq/b;
        value = "3/compare/basket"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LRa/d;",
            ">;",
            "LGe/e0<",
            "LRa/d;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract saveDyrFeedback(Lid/d;)Lta/a;
    .param p1    # Lid/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/dyr/saveFeedback"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lid/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lyf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract saveDyrRoom(Lid/f;)Lta/a;
    .param p1    # Lid/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/dyr/saveRoom"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lid/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lyf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract searchWithAltInput(Lmf/n;)Lta/a;
    .param p1    # Lmf/n;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/action/flippi/altInput"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lmf/n;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lmf/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract secureFetchPageData(Ljava/lang/String;Lwd/t;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/y;
        .end annotation
    .end param
    .param p2    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Request-MetaInfo"
        .end annotation
    .end param
    .param p5    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lwd/t;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljg/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract secureFetchPageData(Lwd/t;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Request-MetaInfo"
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/page/fetch/s"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd/t;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljg/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract secureFetchReactPageData(Lwd/t;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Lwd/t;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Request-MetaInfo"
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/page/fetch/s"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd/t;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract selectLocale(LTd/b;)Lta/a;
    .param p1    # LTd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/vernacular"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LKh/d;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract sendDGDataToFDP(Ljava/lang/String;Lorg/json/JSONObject;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Visit-Id"
        .end annotation
    .end param
    .param p2    # Lorg/json/JSONObject;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/data/collector/business"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lorg/json/JSONObject;",
            ")",
            "Lta/a<",
            "Lokhttp3/ResponseBody;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/a;
        value = "gzip"
    .end annotation

    .annotation runtime Lua/b;
        value = 0x0
    .end annotation
.end method

.method public abstract sendDataToFDP(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONArray;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "appVersion"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "collectorEndPoint"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Visit-Id"
        .end annotation
    .end param
    .param p4    # Lorg/json/JSONArray;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "{appVersion}/data/collector/{collectorEndPoint}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lorg/json/JSONArray;",
            ")",
            "Lta/a<",
            "Lokhttp3/ResponseBody;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation runtime Lua/a;
        value = "gzip"
    .end annotation

    .annotation runtime Lua/b;
        value = 0x0
    .end annotation

    .annotation runtime Lua/d;
    .end annotation
.end method

.method public abstract sendFaqVote(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "1/qna/answers/sentiment"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract sendQnaAnswer(Ljava/lang/String;LAd/b;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "questionId"
        .end annotation
    .end param
    .param p2    # LAd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "1/qna/questions/{questionId}/answers"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LAd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract sendQnaQuestion(LAd/d;)Lta/a;
    .param p1    # LAd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "1/qna/questions"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract sendRating(Ljb/g;)Lta/a;
    .param p1    # Ljb/g;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/reviews/product/rate"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljb/g;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lxb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract sendReferralCode(Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "code"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "campaign"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/user/referral/campaign/{campaign}/code/{code}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lsb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract sendReviewVote(Ljava/util/Map;)Lta/a;
    .param p1    # Ljava/util/Map;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "3/reviews/vote"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract sendTncAccepted()Lta/a;
    .annotation runtime Laq/o;
        value = "1/referral-service/referral/tncPermission"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lta/a<",
            "LGe/e0<",
            "LIg/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract sendTncAcceptedGamification()Lta/a;
    .annotation runtime Laq/o;
        value = "1/gamification/referral-service/v1/recordTncAccess"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lta/a<",
            "LGe/e0<",
            "LIg/p;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract sendUltraBreadcrumbEvents(LGd/d;)Lta/a;
    .param p1    # LGd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/ultra/breadcrumbs/ingest"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LGd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LFh/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract sendUserAttribution(LIg/n;)Lta/a;
    .param p1    # LIg/n;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/referral-service/referral/userAttribution"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LIg/n;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIg/j;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract sendUserAttributionGamification(LIg/n;)Lta/a;
    .param p1    # LIg/n;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/gamification/referral-service/v1/registerReferee"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LIg/n;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIg/j;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract setPassword(LLd/b;)Lta/a;
    .param p1    # LLd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/user/password/set"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LLd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lhb/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract setUserInvited(LIg/l;)Lta/a;
    .param p1    # LIg/l;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/referral-service/referral/invited"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LIg/l;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIg/j;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract setUserInvitedGamification(LIg/l;)Lta/a;
    .param p1    # LIg/l;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/gamification/referral-service/v1/markAsInvited"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LIg/l;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LIg/j;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract signup(LNd/b;)Lta/a;
    .param p1    # LNd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/user/signUp"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LNd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LRh/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract updateBasket(Lbd/d;)Lta/a;
    .param p1    # Lbd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "1/cart/browse"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lbd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LCe/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract updateEligibilityApplication(Ljd/e;Ljava/lang/String;)Lta/a;
    .param p1    # Ljd/e;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "type"
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "1/fintech/application/{type}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljd/e;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LKf/h;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract updateIdentity(LRd/b;)Lta/a;
    .param p1    # LRd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "6/user/identity"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LRd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LKh/d;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract updateRateTheAppState(LPd/b;)Lta/a;
    .param p1    # LPd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/p;
        value = "3/user/state/rta"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LPd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LVh/n;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract updateUserLocation(Lmd/d;)Lta/a;
    .param p1    # Lmd/d;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/location/update"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lmd/d;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LUf/b;",
            ">;",
            "LGe/e0<",
            "Lxk/s;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract updateUserProfile(Lqb/a;)Lta/a;
    .param p1    # Lqb/a;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/user/personalinfo"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lqb/a;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract uploadDyrBaseImage(Lokhttp3/MultipartBody$Part;Ljava/lang/String;ZLMe/p1;Ljava/util/Map;)Lta/a;
    .param p1    # Lokhttp3/MultipartBody$Part;
        .annotation runtime Laq/q;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/q;
            value = "roomType"
        .end annotation
    .end param
    .param p3    # Z
        .annotation runtime Laq/q;
            value = "maskImage"
        .end annotation
    .end param
    .param p4    # LMe/p1;
        .annotation runtime Laq/q;
            value = "metadata"
        .end annotation
    .end param
    .param p5    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .annotation runtime Laq/l;
    .end annotation

    .annotation runtime Laq/o;
        value = "5/dyr/saveImage"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/MultipartBody$Part;",
            "Ljava/lang/String;",
            "Z",
            "LMe/p1;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lyf/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract uploadDyrMaskImage(Lokhttp3/MultipartBody$Part;Ljava/lang/String;ZLOe/b;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Lokhttp3/MultipartBody$Part;
        .annotation runtime Laq/q;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/q;
            value = "baseImgId"
        .end annotation
    .end param
    .param p3    # Z
        .annotation runtime Laq/q;
            value = "maskImage"
        .end annotation
    .end param
    .param p4    # LOe/b;
        .annotation runtime Laq/q;
            value = "maskDetails"
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation runtime Laq/q;
            value = "productVertical"
        .end annotation
    .end param
    .param p6    # Ljava/util/Map;
        .annotation runtime Laq/u;
        .end annotation
    .end param
    .annotation runtime Laq/l;
    .end annotation

    .annotation runtime Laq/o;
        value = "5/dyr/saveImage"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/MultipartBody$Part;",
            "Ljava/lang/String;",
            "Z",
            "LOe/b;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Lyf/b;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract uploadImage(Lokhttp3/MultipartBody$Part;Lokhttp3/RequestBody;Ljava/lang/String;Ljava/util/Map;)Lta/a;
    .param p1    # Lokhttp3/MultipartBody$Part;
        .annotation runtime Laq/q;
        .end annotation
    .end param
    .param p2    # Lokhttp3/RequestBody;
        .annotation runtime Laq/q;
            value = "pageRequest"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Layout-Version"
        .end annotation
    .end param
    .param p4    # Ljava/util/Map;
        .annotation runtime Laq/j;
        .end annotation
    .end param
    .annotation runtime Laq/l;
    .end annotation

    .annotation runtime Laq/o;
        value = "4/page/fetch/image-upload"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/MultipartBody$Part;",
            "Lokhttp3/RequestBody;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lta/a<",
            "LGe/e0<",
            "Ljg/y;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract validateEmail(LSd/b;)Lta/a;
    .param p1    # LSd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/user/otp/validate"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LSd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Leb/e;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract validateEmailAssociation(LJd/b;)Lta/a;
    .param p1    # LJd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "4/user/association/validate"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LJd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lpe/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract validateOTPFor2FA(LPh/f;)Lta/a;
    .param p1    # LPh/f;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "1/user/otp/2fa/validate"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LPh/f;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LKh/d;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract validatePincode(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/s;
            value = "pincode"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/util/pincode/{pincode}"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LBb/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract verfyOTP(LSd/b;)Lta/a;
    .param p1    # LSd/b;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "5/user/otp/verify"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LSd/b;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lhb/d;",
            ">;",
            "LGe/e0<",
            "LKh/b;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract visualBrowse(Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "itemId"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "productId"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/search/visual/browse"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/flipkart/mapi/model/component/data/WidgetData;",
            ">;>;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method
