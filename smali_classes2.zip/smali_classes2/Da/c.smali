.class public interface abstract LDa/c;
.super Ljava/lang/Object;
.source "VarysHttpService.java"


# virtual methods
.method public abstract handshake(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-App-Name"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-NETWORK-TYPE"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-NETWORK-SPEED"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "3/varys/handshake"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;",
            ">;",
            "LGe/e0<",
            "LCb/e;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract uploadToVarys(Lokhttp3/RequestBody;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lta/a;
    .param p1    # Lokhttp3/RequestBody;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Access-Token"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Key-Id"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-EsKey"
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-CRC"
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Start-Time"
        .end annotation
    .end param
    .param p7    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-End-Time"
        .end annotation
    .end param
    .param p8    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Count"
        .end annotation
    .end param
    .param p9    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Domain-Name"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "2/varys/upload"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/RequestBody;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "LCb/e;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract varysHandshake(Ljava/lang/String;)Lta/a;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Domain-Name"
        .end annotation
    .end param
    .annotation runtime Laq/f;
        value = "2/varys/handshake"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lta/a<",
            "LGe/e0<",
            "LCb/g;",
            ">;",
            "LGe/e0<",
            "LCb/e;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method

.method public abstract varysUpload(Lokhttp3/RequestBody;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZIII)Lta/a;
    .param p1    # Lokhttp3/RequestBody;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/t;
            value = "type"
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Access-Token"
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Key-Id"
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-EsKey"
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-CRC"
        .end annotation
    .end param
    .param p7    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Start-Time"
        .end annotation
    .end param
    .param p8    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-End-Time"
        .end annotation
    .end param
    .param p9    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-Count"
        .end annotation
    .end param
    .param p10    # Z
        .annotation runtime Laq/i;
            value = "X-Last-Payload"
        .end annotation
    .end param
    .param p11    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "X-App-Name"
        .end annotation
    .end param
    .param p12    # Z
        .annotation runtime Laq/i;
            value = "X-Periodic"
        .end annotation
    .end param
    .param p13    # I
        .annotation runtime Laq/i;
            value = "X-TOTAL-DATA-COUNT"
        .end annotation
    .end param
    .param p14    # I
        .annotation runtime Laq/i;
            value = "X-TOTAL-NP-SMS-COUNT"
        .end annotation
    .end param
    .param p15    # I
        .annotation runtime Laq/i;
            value = "X-REGEX-NP-SMS-COUNT"
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "3/varys/upload"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/RequestBody;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "ZIII)",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "LCb/e;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Lua/c;
    .end annotation
.end method
