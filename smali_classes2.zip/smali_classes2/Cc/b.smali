.class public final LCc/b;
.super Ljava/lang/Object;
.source "ChunkMetaDataTranspiler.kt"

# interfaces
.implements LE8/b;


# instance fields
.field private final a:LDc/a;

.field private final b:I


# direct methods
.method public constructor <init>(LDc/a;I)V
    .registers 4

    const-string v0, "chunkDownloader"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LCc/b;->a:LDc/a;

    iput p2, p0, LCc/b;->b:I

    return-void
.end method


# virtual methods
.method public downloadData(Ljava/lang/String;LXn/d;)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LXn/d<",
            "-",
            "LQ8/b$c;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    iget-object v0, p0, LCc/b;->a:LDc/a;

    invoke-interface {v0, p1, p2}, LDc/a;->downloadData(Ljava/lang/String;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public getServerConfig(Ljava/lang/String;Ljava/lang/Integer;LXn/d;)Ljava/lang/Object;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            "LXn/d<",
            "-",
            "LQ8/b$b;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    instance-of v0, p3, LCc/b$a;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, LCc/b$a;

    iget v1, v0, LCc/b$a;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LCc/b$a;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, LCc/b$a;

    invoke-direct {v0, p0, p3}, LCc/b$a;-><init>(LCc/b;LXn/d;)V

    :goto_18
    iget-object p3, v0, LCc/b$a;->b:Ljava/lang/Object;

    sget-object v1, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v2, v0, LCc/b$a;->d:I

    const/4 v3, 0x1

    if-eqz v2, :cond_31

    if-ne v2, v3, :cond_29

    iget-object p1, v0, LCc/b$a;->a:LCc/b;

    invoke-static {p3}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_50

    :cond_29
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_31
    invoke-static {p3}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    sget-object p3, LCc/d;->a:LCc/d$a;

    invoke-virtual {p3, p1}, LCc/d$a;->getModuleAndChunkNamesFromId(Ljava/lang/String;)LCc/d$a$a;

    move-result-object p1

    invoke-virtual {p1}, LCc/d$a$a;->getModule()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1}, LCc/d$a$a;->getChunkName()Ljava/lang/String;

    move-result-object p1

    iput-object p0, v0, LCc/b$a;->a:LCc/b;

    iput v3, v0, LCc/b$a;->d:I

    iget-object v2, p0, LCc/b;->a:LDc/a;

    invoke-interface {v2, p3, p1, p2, v0}, LDc/a;->getChunkServerConfig(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;LXn/d;)Ljava/lang/Object;

    move-result-object p3

    if-ne p3, v1, :cond_4f

    return-object v1

    :cond_4f
    move-object p1, p0

    :goto_50
    check-cast p3, Ljava/util/List;

    const/4 p2, 0x0

    if-eqz p3, :cond_77

    iget p1, p1, LCc/b;->b:I

    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :cond_5b
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6e

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LEc/a;

    invoke-virtual {v0}, LEc/a;->getMinMainBundleVersion()I

    move-result v1

    if-lt p1, v1, :cond_5b

    goto :goto_6f

    :cond_6e
    move-object v0, p2

    :goto_6f
    if-eqz v0, :cond_77

    new-instance p1, LQ8/b$b;

    invoke-direct {p1, v0}, LQ8/b$b;-><init>(LP8/b;)V

    return-object p1

    :cond_77
    return-object p2
.end method
