.class public final LCc/a;
.super LF8/a;
.source "ChunkFileManager.kt"


# instance fields
.field private final f:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;LE8/b;)V
    .registers 10

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "chunkMetaDataTranspiler"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    invoke-direct/range {v1 .. v6}, LF8/a;-><init>(Landroid/content/Context;LE8/b;ZILkotlin/jvm/internal/i;)V

    iput-object p1, p0, LCc/a;->f:Landroid/content/Context;

    return-void
.end method

.method public static final synthetic access$syncBundle$s1637863344(LCc/a;Ljava/lang/String;LD8/a;LXn/d;)Ljava/lang/Object;
    .registers 4

    invoke-super {p0, p1, p2, p3}, LF8/a;->syncBundle(Ljava/lang/String;LD8/a;LXn/d;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final getChunks(Ljava/lang/String;Ljava/lang/String;ZLvc/d;)V
    .registers 7

    const-string v0, "module"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "chunk"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "callback"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LCc/d;->a:LCc/d$a;

    invoke-virtual {v0, p1, p2}, LCc/d$a;->getModuleChunkId(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Lwc/a;

    iget-object v0, p0, LCc/a;->f:Landroid/content/Context;

    const/4 v1, 0x0

    invoke-direct {p2, v0, p0, v1, v1}, Lwc/a;-><init>(Landroid/content/Context;LF8/a;Lvc/b;LD8/a;)V

    invoke-virtual {p2, p1, p3, p4}, Lwc/a;->getBundlePathForPage(Ljava/lang/String;ZLvc/d;)V

    return-void
.end method

.method public final getContext()Landroid/content/Context;
    .registers 2

    iget-object v0, p0, LCc/a;->f:Landroid/content/Context;

    return-object v0
.end method

.method public final syncChunks(Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 5

    const-string p3, "module"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p3, "chunk"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p3, LCc/d;->a:LCc/d$a;

    invoke-virtual {p3, p1, p2}, LCc/d$a;->getModuleChunkId(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {}, Lkotlinx/coroutines/S;->a()Lkotlinx/coroutines/scheduling/c;

    move-result-object p2

    invoke-static {p2}, LHj/a;->a(LXn/f;)Lkotlinx/coroutines/internal/d;

    move-result-object p2

    new-instance p3, LCc/a$a;

    const/4 v0, 0x0

    invoke-direct {p3, p0, p1, v0}, LCc/a$a;-><init>(LCc/a;Ljava/lang/String;LXn/d;)V

    const/4 p1, 0x3

    invoke-static {p2, v0, p3, p1}, Lkotlinx/coroutines/h;->b(Lkotlinx/coroutines/G;LXn/f$a;Leo/p;I)Lkotlinx/coroutines/j0;

    return-void
.end method
