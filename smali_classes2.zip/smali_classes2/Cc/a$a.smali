.class final LCc/a$a;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ChunkFileManager.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LCc/a;->syncChunks(Ljava/lang/String;Ljava/lang/String;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.reacthelpersdk.modules.chunkmanager.ChunkFileManager$syncChunks$1"
    f = "ChunkFileManager.kt"
    l = {
        0x17
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field final synthetic b:LCc/a;

.field final synthetic c:Ljava/lang/String;


# direct methods
.method constructor <init>(LCc/a;Ljava/lang/String;LXn/d;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LCc/a;",
            "Ljava/lang/String;",
            "LXn/d<",
            "-",
            "LCc/a$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LCc/a$a;->b:LCc/a;

    iput-object p2, p0, LCc/a$a;->c:Ljava/lang/String;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LCc/a$a;

    iget-object v0, p0, LCc/a$a;->b:LCc/a;

    iget-object v1, p0, LCc/a$a;->c:Ljava/lang/String;

    invoke-direct {p1, v0, v1, p2}, LCc/a$a;-><init>(LCc/a;Ljava/lang/String;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LCc/a$a;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LCc/a$a;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LCc/a$a;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LCc/a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LCc/a$a;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_26

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iput v2, p0, LCc/a$a;->a:I

    iget-object p1, p0, LCc/a$a;->b:LCc/a;

    iget-object v1, p0, LCc/a$a;->c:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-static {p1, v1, v2, p0}, LCc/a;->access$syncBundle$s1637863344(LCc/a;Ljava/lang/String;LD8/a;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_26

    return-object v0

    :cond_26
    :goto_26
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
