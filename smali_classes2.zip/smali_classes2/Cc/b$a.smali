.class final LCc/b$a;
.super Lkotlin/coroutines/jvm/internal/c;
.source "ChunkMetaDataTranspiler.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LCc/b;->getServerConfig(Ljava/lang/String;Ljava/lang/Integer;LXn/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.reacthelpersdk.modules.chunkmanager.ChunkMetaDataTranspiler"
    f = "ChunkMetaDataTranspiler.kt"
    l = {
        0x14
    }
    m = "getServerConfig"
.end annotation


# instance fields
.field a:LCc/b;

.field synthetic b:Ljava/lang/Object;

.field final synthetic c:LCc/b;

.field d:I


# direct methods
.method constructor <init>(LCc/b;LXn/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LCc/b;",
            "LXn/d<",
            "-",
            "LCc/b$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LCc/b$a;->c:LCc/b;

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/c;-><init>(LXn/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LCc/b$a;->b:Ljava/lang/Object;

    iget p1, p0, LCc/b$a;->d:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LCc/b$a;->d:I

    iget-object p1, p0, LCc/b$a;->c:LCc/b;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, v0, p0}, LCc/b;->getServerConfig(Ljava/lang/String;Ljava/lang/Integer;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
