.class public final LCc/c;
.super Ljava/lang/Object;
.source "ChunkQueuer.kt"


# static fields
.field public static final a:LCc/c;

.field private static b:Ljava/util/LinkedHashMap;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LCc/c;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LCc/c;->a:LCc/c;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    sput-object v0, LCc/c;->b:Ljava/util/LinkedHashMap;

    return-void
.end method

.method public static final synthetic access$getLatentChunksMap$p()Ljava/util/Map;
    .registers 1

    sget-object v0, LCc/c;->b:Ljava/util/LinkedHashMap;

    return-object v0
.end method


# virtual methods
.method public final flushLatentChunks(Ljava/lang/String;)V
    .registers 4

    const-string v0, "VMKey"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LCc/c;->b:Ljava/util/LinkedHashMap;

    const/4 v1, 0x0

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final getLatentChunks(Ljava/lang/String;)LCc/e;
    .registers 3

    const-string v0, "VMKey"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LCc/c;->b:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LCc/e;

    return-object p1
.end method

.method public final queueChunks(Ljava/lang/String;LDc/c;)V
    .registers 6

    const-string v0, "VMKey"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "chunkProvider"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lkotlinx/coroutines/S;->a()Lkotlinx/coroutines/scheduling/c;

    move-result-object v0

    invoke-static {v0}, LHj/a;->a(LXn/f;)Lkotlinx/coroutines/internal/d;

    move-result-object v0

    new-instance v1, LCc/c$a;

    const/4 v2, 0x0

    invoke-direct {v1, p1, p2, v2}, LCc/c$a;-><init>(Ljava/lang/String;LDc/c;LXn/d;)V

    const/4 p1, 0x3

    invoke-static {v0, v2, v1, p1}, Lkotlinx/coroutines/h;->b(Lkotlinx/coroutines/G;LXn/f$a;Leo/p;I)Lkotlinx/coroutines/j0;

    return-void
.end method
