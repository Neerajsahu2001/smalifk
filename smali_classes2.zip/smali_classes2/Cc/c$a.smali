.class final LCc/c$a;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ChunkQueuer.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LCc/c;->queueChunks(Ljava/lang/String;LDc/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.reacthelpersdk.modules.chunkmanager.ChunkQueuer$queueChunks$1"
    f = "ChunkQueuer.kt"
    l = {}
    m = "invokeSuspend"
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:LDc/c;


# direct methods
.method constructor <init>(Ljava/lang/String;LDc/c;LXn/d;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LDc/c;",
            "LXn/d<",
            "-",
            "LCc/c$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LCc/c$a;->a:Ljava/lang/String;

    iput-object p2, p0, LCc/c$a;->b:LDc/c;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LCc/c$a;

    iget-object v0, p0, LCc/c$a;->a:Ljava/lang/String;

    iget-object v1, p0, LCc/c$a;->b:LDc/c;

    invoke-direct {p1, v0, v1, p2}, LCc/c$a;-><init>(Ljava/lang/String;LDc/c;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LCc/c$a;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LCc/c$a;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LCc/c$a;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LCc/c$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    invoke-static {}, LCc/c;->access$getLatentChunksMap$p()Ljava/util/Map;

    move-result-object p1

    iget-object v0, p0, LCc/c$a;->a:Ljava/lang/String;

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LCc/e;

    if-nez p1, :cond_1b

    new-instance p1, LCc/e;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-direct {p1, v1}, LCc/e;-><init>(Ljava/util/List;)V

    :cond_1b
    invoke-virtual {p1}, LCc/e;->getChunkProviders()Ljava/util/List;

    move-result-object v1

    iget-object v2, p0, LCc/c$a;->b:LDc/c;

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {}, LCc/c;->access$getLatentChunksMap$p()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
