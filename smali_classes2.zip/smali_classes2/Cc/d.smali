.class public final LCc/d;
.super Ljava/lang/Object;
.source "ChunkUtils.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCc/d$a;
    }
.end annotation


# static fields
.field public static final a:LCc/d$a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LCc/d$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LCc/d$a;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, LCc/d;->a:LCc/d$a;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
