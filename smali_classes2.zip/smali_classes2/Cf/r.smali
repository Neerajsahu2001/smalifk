.class public final LCf/r;
.super Lxk/z;
.source "PlayableMedia$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "LCf/l;",
        ">",
        "Lxk/z<",
        "LCf/s<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Ljava/util/List<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/R2;",
            ">;>;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public varargs constructor <init>(Lxk/j;[Ljava/lang/reflect/Type;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x0

    aget-object p2, p2, v0

    invoke-static {p2}, Lcom/google/gson/reflect/a;->get(Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object p2

    invoke-virtual {p2}, Lcom/google/gson/reflect/a;->getType()Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v1, 0x1

    new-array v2, v1, [Ljava/lang/reflect/Type;

    aput-object p2, v2, v0

    const-class p2, Ljava/util/List;

    invoke-static {p2, v2}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object p2

    new-array v1, v1, [Ljava/lang/reflect/Type;

    const-class v2, LMe/R2;

    aput-object v2, v1, v0

    const-class v0, LLe/f;

    invoke-static {v0, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, p2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p2

    iput-object p2, p0, LCf/r;->a:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p2

    iput-object p2, p0, LCf/r;->b:Lxk/z;

    sget-object p2, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, p2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LCf/r;->c:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LCf/s;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBk/a;",
            ")",
            "LCf/s<",
            "TT;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LCf/s;

    invoke-direct {v0}, LCf/s;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_eb

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_120

    goto/16 :goto_8b

    :sswitch_34
    const-string v2, "autoPlay"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3d

    goto :goto_8b

    :cond_3d
    const/4 v3, 0x7

    goto :goto_8b

    :sswitch_3f
    const-string v2, "thumbnail"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_48

    goto :goto_8b

    :cond_48
    const/4 v3, 0x6

    goto :goto_8b

    :sswitch_4a
    const-string v2, "aspectRatio"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_53

    goto :goto_8b

    :cond_53
    const/4 v3, 0x5

    goto :goto_8b

    :sswitch_55
    const-string v2, "groupId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5e

    goto :goto_8b

    :cond_5e
    const/4 v3, 0x4

    goto :goto_8b

    :sswitch_60
    const-string v2, "durationInSec"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_69

    goto :goto_8b

    :cond_69
    const/4 v3, 0x3

    goto :goto_8b

    :sswitch_6b
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_74

    goto :goto_8b

    :cond_74
    const/4 v3, 0x2

    goto :goto_8b

    :sswitch_76
    const-string v2, "theaterModeCallOut"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7f

    goto :goto_8b

    :cond_7f
    const/4 v3, 0x1

    goto :goto_8b

    :sswitch_81
    const-string v2, "sources"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8a

    goto :goto_8b

    :cond_8a
    const/4 v3, 0x0

    :goto_8b
    packed-switch v3, :pswitch_data_142

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_92
    iget-boolean v1, v0, LCf/s;->e:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LCf/s;->e:Z

    goto :goto_1d

    :pswitch_9b
    iget-object v1, p0, LCf/r;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, LCf/s;->f:LMe/r1;

    goto/16 :goto_1d

    :pswitch_a7
    iget-wide v1, v0, LCf/j;->b:D

    invoke-static {p1, v1, v2}, LJn/a$x;->a(LBk/a;D)D

    move-result-wide v1

    iput-wide v1, v0, LCf/j;->b:D

    goto/16 :goto_1d

    :pswitch_b1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LCf/s;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_bd
    iget v1, v0, LCf/s;->g:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LCf/s;->g:I

    goto/16 :goto_1d

    :pswitch_c7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_d3
    iget-object v1, p0, LCf/r;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LCf/j;->c:LLe/f;

    goto/16 :goto_1d

    :pswitch_df
    iget-object v1, p0, LCf/r;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LCf/j;->a:Ljava/util/List;

    goto/16 :goto_1d

    :cond_eb
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_117

    iget-object p1, v0, LCf/j;->a:Ljava/util/List;

    if-eqz p1, :cond_10f

    iget-object p1, v0, LCf/s;->d:Ljava/lang/String;

    if-eqz p1, :cond_107

    iget-object p1, v0, LCf/s;->f:LMe/r1;

    if-eqz p1, :cond_ff

    return-object v0

    :cond_ff
    new-instance p1, Ljava/io/IOException;

    const-string v0, "thumbnail cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_107
    new-instance p1, Ljava/io/IOException;

    const-string v0, "groupId cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_10f
    new-instance p1, Ljava/io/IOException;

    const-string v0, "sources cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_117
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_120
    .sparse-switch
        -0x78836448 -> :sswitch_81
        -0x1fc74be4 -> :sswitch_76
        0x368f3a -> :sswitch_6b
        0x72907b8 -> :sswitch_60
        0x117d5bfa -> :sswitch_55
        0x41194293 -> :sswitch_4a
        0x4f4e50ec -> :sswitch_3f
        0x55bf6d83 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_142
    .packed-switch 0x0
        :pswitch_df
        :pswitch_d3
        :pswitch_c7
        :pswitch_bd
        :pswitch_b1
        :pswitch_a7
        :pswitch_9b
        :pswitch_92
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LCf/r;->read(LBk/a;)LCf/s;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LCf/s;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBk/c;",
            "LCf/s<",
            "TT;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_8c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "sources"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/j;->a:Ljava/util/List;

    if-eqz v0, :cond_84

    iget-object v2, p0, LCf/r;->a:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "aspectRatio"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v2, p2, LCf/j;->b:D

    invoke-virtual {p1, v2, v3}, LBk/c;->value(D)LBk/c;

    const-string v0, "theaterModeCallOut"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/j;->c:LLe/f;

    if-eqz v0, :cond_3e

    iget-object v2, p0, LCf/r;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_41

    :cond_3e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_41
    const-string v0, "groupId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/s;->d:Ljava/lang/String;

    if-eqz v0, :cond_7c

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "autoPlay"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LCf/s;->e:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "thumbnail"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/s;->f:LMe/r1;

    if-eqz v0, :cond_74

    iget-object v1, p0, LCf/r;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "durationInSec"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget p2, p2, LCf/s;->g:I

    int-to-long v0, p2

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_74
    new-instance p1, Ljava/io/IOException;

    const-string p2, "thumbnail cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7c
    new-instance p1, Ljava/io/IOException;

    const-string p2, "groupId cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_84
    new-instance p1, Ljava/io/IOException;

    const-string p2, "sources cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_8c
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LCf/s;

    invoke-virtual {p0, p1, p2}, LCf/r;->write(LBk/c;LCf/s;)V

    return-void
.end method
