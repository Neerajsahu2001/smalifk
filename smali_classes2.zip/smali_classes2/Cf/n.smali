.class public final LCf/n;
.super Lxk/z;
.source "FeedsVideo$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LCf/o;",
        ">;"
    }
.end annotation


# static fields
.field public static final d:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "LCf/o;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:LJn/a$r;

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/R2;",
            ">;>;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LCf/o;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, LCf/n;->d:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v1, LMe/R2;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-class v1, LLe/f;

    invoke-static {v1, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v1, LCf/p;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v2, LJn/a$r;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v2, v1, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v2, p0, LCf/n;->a:LJn/a$r;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, LCf/n;->b:Lxk/z;

    sget-object v0, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LCf/n;->c:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LCf/o;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LCf/o;

    invoke-direct {v0}, LCf/o;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1b1

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_1e6

    goto/16 :goto_fb

    :sswitch_34
    const-string v2, "resizeMode"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_fb

    :cond_3e
    const/16 v3, 0xf

    goto/16 :goto_fb

    :sswitch_42
    const-string v2, "autoPlay"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_fb

    :cond_4c
    const/16 v3, 0xe

    goto/16 :goto_fb

    :sswitch_50
    const-string v2, "thumbnail"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_fb

    :cond_5a
    const/16 v3, 0xd

    goto/16 :goto_fb

    :sswitch_5e
    const-string v2, "loopCount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_fb

    :cond_68
    const/16 v3, 0xc

    goto/16 :goto_fb

    :sswitch_6c
    const-string v2, "aspectRatio"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_fb

    :cond_76
    const/16 v3, 0xb

    goto/16 :goto_fb

    :sswitch_7a
    const-string v2, "hideTimer"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_fb

    :cond_84
    const/16 v3, 0xa

    goto/16 :goto_fb

    :sswitch_88
    const-string v2, "loopDuration"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_fb

    :cond_92
    const/16 v3, 0x9

    goto/16 :goto_fb

    :sswitch_96
    const-string v2, "groupId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_fb

    :cond_a0
    const/16 v3, 0x8

    goto/16 :goto_fb

    :sswitch_a4
    const-string v2, "durationInSec"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ad

    goto :goto_fb

    :cond_ad
    const/4 v3, 0x7

    goto :goto_fb

    :sswitch_af
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b8

    goto :goto_fb

    :cond_b8
    const/4 v3, 0x6

    goto :goto_fb

    :sswitch_ba
    const-string v2, "theaterModeCallOut"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c3

    goto :goto_fb

    :cond_c3
    const/4 v3, 0x5

    goto :goto_fb

    :sswitch_c5
    const-string v2, "autoplayStart"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ce

    goto :goto_fb

    :cond_ce
    const/4 v3, 0x4

    goto :goto_fb

    :sswitch_d0
    const-string v2, "disableVolumeControl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d9

    goto :goto_fb

    :cond_d9
    const/4 v3, 0x3

    goto :goto_fb

    :sswitch_db
    const-string v2, "showControls"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e4

    goto :goto_fb

    :cond_e4
    const/4 v3, 0x2

    goto :goto_fb

    :sswitch_e6
    const-string v2, "showPlayButton"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ef

    goto :goto_fb

    :cond_ef
    const/4 v3, 0x1

    goto :goto_fb

    :sswitch_f1
    const-string v2, "sources"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_fa

    goto :goto_fb

    :cond_fa
    const/4 v3, 0x0

    :goto_fb
    packed-switch v3, :pswitch_data_228

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_103
    iget v1, v0, LCf/o;->m:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LCf/o;->m:I

    goto/16 :goto_1d

    :pswitch_10d
    iget-boolean v1, v0, LCf/s;->e:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LCf/s;->e:Z

    goto/16 :goto_1d

    :pswitch_117
    iget-object v1, p0, LCf/n;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, LCf/s;->f:LMe/r1;

    goto/16 :goto_1d

    :pswitch_123
    iget v1, v0, LCf/o;->h:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LCf/o;->h:I

    goto/16 :goto_1d

    :pswitch_12d
    iget-wide v1, v0, LCf/j;->b:D

    invoke-static {p1, v1, v2}, LJn/a$x;->a(LBk/a;D)D

    move-result-wide v1

    iput-wide v1, v0, LCf/j;->b:D

    goto/16 :goto_1d

    :pswitch_137
    iget-boolean v1, v0, LCf/o;->l:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LCf/o;->l:Z

    goto/16 :goto_1d

    :pswitch_141
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, LCf/o;->n:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_14d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LCf/s;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_159
    iget v1, v0, LCf/s;->g:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LCf/s;->g:I

    goto/16 :goto_1d

    :pswitch_163
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_16f
    iget-object v1, p0, LCf/n;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LCf/j;->c:LLe/f;

    goto/16 :goto_1d

    :pswitch_17b
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, LCf/o;->o:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_187
    iget-boolean v1, v0, LCf/o;->k:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LCf/o;->k:Z

    goto/16 :goto_1d

    :pswitch_191
    iget-boolean v1, v0, LCf/o;->j:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LCf/o;->j:Z

    goto/16 :goto_1d

    :pswitch_19b
    iget-boolean v1, v0, LCf/o;->i:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LCf/o;->i:Z

    goto/16 :goto_1d

    :pswitch_1a5
    iget-object v1, p0, LCf/n;->a:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LCf/j;->a:Ljava/util/List;

    goto/16 :goto_1d

    :cond_1b1
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_1dd

    iget-object p1, v0, LCf/j;->a:Ljava/util/List;

    if-eqz p1, :cond_1d5

    iget-object p1, v0, LCf/s;->d:Ljava/lang/String;

    if-eqz p1, :cond_1cd

    iget-object p1, v0, LCf/s;->f:LMe/r1;

    if-eqz p1, :cond_1c5

    return-object v0

    :cond_1c5
    new-instance p1, Ljava/io/IOException;

    const-string v0, "thumbnail cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1cd
    new-instance p1, Ljava/io/IOException;

    const-string v0, "groupId cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1d5
    new-instance p1, Ljava/io/IOException;

    const-string v0, "sources cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1dd
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_1e6
    .sparse-switch
        -0x78836448 -> :sswitch_f1
        -0x5f90b99d -> :sswitch_e6
        -0x5492c72d -> :sswitch_db
        -0x48173525 -> :sswitch_d0
        -0x2942bf41 -> :sswitch_c5
        -0x1fc74be4 -> :sswitch_ba
        0x368f3a -> :sswitch_af
        0x72907b8 -> :sswitch_a4
        0x117d5bfa -> :sswitch_96
        0x25029458 -> :sswitch_88
        0x32423323 -> :sswitch_7a
        0x41194293 -> :sswitch_6c
        0x4a5820cb -> :sswitch_5e
        0x4f4e50ec -> :sswitch_50
        0x55bf6d83 -> :sswitch_42
        0x7a2cd077 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_228
    .packed-switch 0x0
        :pswitch_1a5
        :pswitch_19b
        :pswitch_191
        :pswitch_187
        :pswitch_17b
        :pswitch_16f
        :pswitch_163
        :pswitch_159
        :pswitch_14d
        :pswitch_141
        :pswitch_137
        :pswitch_12d
        :pswitch_123
        :pswitch_117
        :pswitch_10d
        :pswitch_103
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LCf/n;->read(LBk/a;)LCf/o;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LCf/o;)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_f3

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "sources"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/j;->a:Ljava/util/List;

    if-eqz v0, :cond_eb

    iget-object v2, p0, LCf/n;->a:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    const-string v0, "aspectRatio"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v2, p2, LCf/j;->b:D

    invoke-virtual {p1, v2, v3}, LBk/c;->value(D)LBk/c;

    const-string v0, "theaterModeCallOut"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/j;->c:LLe/f;

    if-eqz v0, :cond_43

    iget-object v2, p0, LCf/n;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_46

    :cond_43
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_46
    const-string v0, "groupId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/s;->d:Ljava/lang/String;

    if-eqz v0, :cond_e3

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "autoPlay"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LCf/s;->e:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "thumbnail"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/s;->f:LMe/r1;

    if-eqz v0, :cond_db

    iget-object v1, p0, LCf/n;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "durationInSec"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LCf/s;->g:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "loopCount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LCf/o;->h:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "showPlayButton"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LCf/o;->i:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "showControls"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LCf/o;->j:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "disableVolumeControl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LCf/o;->k:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "hideTimer"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LCf/o;->l:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "resizeMode"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LCf/o;->m:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "loopDuration"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/o;->n:Ljava/lang/Integer;

    if-eqz v0, :cond_c2

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_c5

    :cond_c2
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_c5
    const-string v0, "autoplayStart"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LCf/o;->o:Ljava/lang/Integer;

    if-eqz p2, :cond_d4

    sget-object v0, LJn/a;->a:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_d7

    :cond_d4
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_d7
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_db
    new-instance p1, Ljava/io/IOException;

    const-string p2, "thumbnail cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e3
    new-instance p1, Ljava/io/IOException;

    const-string p2, "groupId cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_eb
    new-instance p1, Ljava/io/IOException;

    const-string p2, "sources cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_f3
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LCf/o;

    invoke-virtual {p0, p1, p2}, LCf/n;->write(LBk/c;LCf/o;)V

    return-void
.end method
