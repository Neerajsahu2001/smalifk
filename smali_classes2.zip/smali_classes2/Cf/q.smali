.class public final LCf/q;
.super LCf/l;
.source "FeedsVideoSource.java"


# instance fields
.field public c:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LCf/l;-><init>()V

    return-void
.end method
