.class public final Lcf/c;
.super Lxk/z;
.source "OptionValue$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcf/d;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LMe/r1;",
            ">;"
        }
    .end annotation
.end field

.field private final b:LJn/a$t;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcf/d;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    const-class v0, Ljava/lang/Object;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v1, LMe/q1;->g:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Lcf/c;->a:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$t;

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v2, LJn/a$s;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v1, p1, v2}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lcf/c;->b:LJn/a$t;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcf/d;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcf/d;

    invoke-direct {v0}, Lcf/d;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_ef

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_118

    goto/16 :goto_8b

    :sswitch_34
    const-string v2, "optionMeta"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3d

    goto :goto_8b

    :cond_3d
    const/4 v3, 0x7

    goto :goto_8b

    :sswitch_3f
    const-string v2, "selected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_48

    goto :goto_8b

    :cond_48
    const/4 v3, 0x6

    goto :goto_8b

    :sswitch_4a
    const-string v2, "label"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_53

    goto :goto_8b

    :cond_53
    const/4 v3, 0x5

    goto :goto_8b

    :sswitch_55
    const-string v2, "image"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5e

    goto :goto_8b

    :cond_5e
    const/4 v3, 0x4

    goto :goto_8b

    :sswitch_60
    const-string v2, "color"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_69

    goto :goto_8b

    :cond_69
    const/4 v3, 0x3

    goto :goto_8b

    :sswitch_6b
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_74

    goto :goto_8b

    :cond_74
    const/4 v3, 0x2

    goto :goto_8b

    :sswitch_76
    const-string v2, "id"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7f

    goto :goto_8b

    :cond_7f
    const/4 v3, 0x1

    goto :goto_8b

    :sswitch_81
    const-string v2, "subTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8a

    goto :goto_8b

    :cond_8a
    const/4 v3, 0x0

    :goto_8b
    packed-switch v3, :pswitch_data_13a

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_92
    iget-object v1, p0, Lcf/c;->b:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Lcf/d;->g:Ljava/util/Map;

    goto :goto_1d

    :pswitch_9d
    iget-boolean v1, v0, Lcf/d;->f:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcf/d;->f:Z

    goto/16 :goto_1d

    :pswitch_a7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcf/d;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_b3
    iget-object v1, p0, Lcf/c;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LMe/r1;

    iput-object v1, v0, Lcf/d;->e:LMe/r1;

    goto/16 :goto_1d

    :pswitch_bf
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcf/d;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_cb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_d7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcf/d;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_e3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcf/d;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_ef
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_10f

    iget-object p1, v0, Lcf/d;->a:Ljava/lang/String;

    if-eqz p1, :cond_107

    iget-object p1, v0, Lcf/d;->g:Ljava/util/Map;

    if-eqz p1, :cond_ff

    return-object v0

    :cond_ff
    new-instance p1, Ljava/io/IOException;

    const-string v0, "optionMeta cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_107
    new-instance p1, Ljava/io/IOException;

    const-string v0, "id cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_10f
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_118
    .sparse-switch
        -0x7c93a408 -> :sswitch_81
        0xd1b -> :sswitch_76
        0x368f3a -> :sswitch_6b
        0x5a72f63 -> :sswitch_60
        0x5faa95b -> :sswitch_55
        0x61f7ef4 -> :sswitch_4a
        0x4705f29b -> :sswitch_3f
        0x51dbd01a -> :sswitch_34
    .end sparse-switch

    :pswitch_data_13a
    .packed-switch 0x0
        :pswitch_e3
        :pswitch_d7
        :pswitch_cb
        :pswitch_bf
        :pswitch_b3
        :pswitch_a7
        :pswitch_9d
        :pswitch_92
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcf/c;->read(LBk/a;)Lcf/d;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcf/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_91

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "id"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/d;->a:Ljava/lang/String;

    if-eqz v0, :cond_89

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "label"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/d;->b:Ljava/lang/String;

    if-eqz v0, :cond_30

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_33

    :cond_30
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_33
    const-string v0, "subTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/d;->c:Ljava/lang/String;

    if-eqz v0, :cond_40

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_43

    :cond_40
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_43
    const-string v0, "color"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/d;->d:Ljava/lang/String;

    if-eqz v0, :cond_50

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_53

    :cond_50
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_53
    const-string v0, "image"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/d;->e:LMe/r1;

    if-eqz v0, :cond_62

    iget-object v1, p0, Lcf/c;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_65

    :cond_62
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_65
    const-string v0, "selected"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcf/d;->f:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "optionMeta"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcf/d;->g:Ljava/util/Map;

    if-eqz p2, :cond_81

    iget-object v0, p0, Lcf/c;->b:LJn/a$t;

    invoke-virtual {v0, p1, p2}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_81
    new-instance p1, Ljava/io/IOException;

    const-string p2, "optionMeta cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_89
    new-instance p1, Ljava/io/IOException;

    const-string p2, "id cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_91
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcf/d;

    invoke-virtual {p0, p1, p2}, Lcf/c;->write(LBk/c;Lcf/d;)V

    return-void
.end method
