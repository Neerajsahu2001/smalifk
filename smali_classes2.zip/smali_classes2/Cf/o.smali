.class public final LCf/o;
.super LCf/s;
.source "FeedsVideo.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LCf/s<",
        "LCf/q;",
        ">;"
    }
.end annotation


# instance fields
.field public h:I

.field public i:Z

.field public j:Z

.field public k:Z

.field public l:Z

.field public m:I

.field public n:Ljava/lang/Integer;

.field public o:Ljava/lang/Integer;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LCf/s;-><init>()V

    return-void
.end method
