.class public final LCf/m;
.super LTe/s0;
.source "FeedsMediaValue.java"


# instance fields
.field public n:Ljava/lang/String;

.field public o:LCf/j;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LTe/s0;-><init>()V

    return-void
.end method
