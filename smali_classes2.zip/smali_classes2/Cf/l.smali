.class public LCf/l;
.super LMe/R3;
.source "FeedsMediaSource.java"


# instance fields
.field public a:Ljava/lang/String;

.field public b:D


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LMe/R3;-><init>()V

    return-void
.end method
