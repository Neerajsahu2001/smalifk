.class public final LCf/t;
.super Lxk/z;
.source "StaticMedia$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "LCf/l;",
        ">",
        "Lxk/z<",
        "LCf/u<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Ljava/util/List<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/R2;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public varargs constructor <init>(Lxk/j;[Ljava/lang/reflect/Type;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x0

    aget-object p2, p2, v0

    invoke-static {p2}, Lcom/google/gson/reflect/a;->get(Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object p2

    invoke-virtual {p2}, Lcom/google/gson/reflect/a;->getType()Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v1, 0x1

    new-array v2, v1, [Ljava/lang/reflect/Type;

    aput-object p2, v2, v0

    const-class p2, Ljava/util/List;

    invoke-static {p2, v2}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object p2

    new-array v1, v1, [Ljava/lang/reflect/Type;

    const-class v2, LMe/R2;

    aput-object v2, v1, v0

    const-class v0, LLe/f;

    invoke-static {v0, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, p2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p2

    iput-object p2, p0, LCf/t;->a:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LCf/t;->b:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LCf/u;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBk/a;",
            ")",
            "LCf/u<",
            "TT;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LCf/u;

    invoke-direct {v0}, LCf/u;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_a4

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_c0

    goto :goto_69

    :sswitch_33
    const-string v2, "aspectRatio"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_69

    :cond_3c
    const/4 v3, 0x4

    goto :goto_69

    :sswitch_3e
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_69

    :cond_47
    const/4 v3, 0x3

    goto :goto_69

    :sswitch_49
    const-string v2, "theaterModeCallOut"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_69

    :cond_52
    const/4 v3, 0x2

    goto :goto_69

    :sswitch_54
    const-string v2, "displayDurationInSec"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_69

    :cond_5d
    const/4 v3, 0x1

    goto :goto_69

    :sswitch_5f
    const-string v2, "sources"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto :goto_69

    :cond_68
    const/4 v3, 0x0

    :goto_69
    packed-switch v3, :pswitch_data_d6

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_70
    iget-wide v1, v0, LCf/j;->b:D

    invoke-static {p1, v1, v2}, LJn/a$x;->a(LBk/a;D)D

    move-result-wide v1

    iput-wide v1, v0, LCf/j;->b:D

    goto :goto_1d

    :pswitch_79
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto :goto_1d

    :pswitch_84
    iget-object v1, p0, LCf/t;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, LCf/j;->c:LLe/f;

    goto :goto_1d

    :pswitch_8f
    iget v1, v0, LCf/u;->d:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LCf/u;->d:I

    goto :goto_1d

    :pswitch_98
    iget-object v1, p0, LCf/t;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LCf/j;->a:Ljava/util/List;

    goto/16 :goto_1d

    :cond_a4
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_b8

    iget-object p1, v0, LCf/j;->a:Ljava/util/List;

    if-eqz p1, :cond_b0

    return-object v0

    :cond_b0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "sources cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_b8
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :sswitch_data_c0
    .sparse-switch
        -0x78836448 -> :sswitch_5f
        -0x63c315ea -> :sswitch_54
        -0x1fc74be4 -> :sswitch_49
        0x368f3a -> :sswitch_3e
        0x41194293 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_d6
    .packed-switch 0x0
        :pswitch_98
        :pswitch_8f
        :pswitch_84
        :pswitch_79
        :pswitch_70
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LCf/t;->read(LBk/a;)LCf/u;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LCf/u;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBk/c;",
            "LCf/u<",
            "TT;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_58

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "sources"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/j;->a:Ljava/util/List;

    if-eqz v0, :cond_50

    iget-object v1, p0, LCf/t;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "aspectRatio"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, LCf/j;->b:D

    invoke-virtual {p1, v0, v1}, LBk/c;->value(D)LBk/c;

    const-string v0, "theaterModeCallOut"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LCf/j;->c:LLe/f;

    if-eqz v0, :cond_3e

    iget-object v1, p0, LCf/t;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_41

    :cond_3e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_41
    const-string v0, "displayDurationInSec"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget p2, p2, LCf/u;->d:I

    int-to-long v0, p2

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_50
    new-instance p1, Ljava/io/IOException;

    const-string p2, "sources cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_58
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LCf/u;

    invoke-virtual {p0, p1, p2}, LCf/t;->write(LBk/c;LCf/u;)V

    return-void
.end method
