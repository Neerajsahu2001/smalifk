.class public final Lcf/h;
.super LMe/R3;
.source "QuestionnaireState.java"


# instance fields
.field public a:LMe/T2;

.field public b:LLe/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LLe/f<",
            "LMe/F2;",
            ">;"
        }
    .end annotation
.end field

.field public c:Z

.field public d:LMe/L2;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LMe/R3;-><init>()V

    return-void
.end method
