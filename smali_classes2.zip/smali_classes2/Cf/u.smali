.class public LCf/u;
.super LCf/j;
.source "StaticMedia.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "LCf/l;",
        ">",
        "LCf/j<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public d:I


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LCf/j;-><init>()V

    return-void
.end method
