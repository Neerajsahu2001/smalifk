.class public final Lcf/e;
.super Lxk/z;
.source "QuestionValue$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcf/f;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:LJn/a$r;

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcf/b;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/F2;",
            ">;>;"
        }
    .end annotation
.end field

.field private final d:LJn/a$t;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcf/f;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 7

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/reflect/Type;

    const-class v2, Lcf/d;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-class v2, LLe/f;

    invoke-static {v2, v1}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v4, LMe/F2;

    aput-object v4, v0, v3

    invoke-static {v2, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    const-class v2, Ljava/lang/Object;

    invoke-static {v2}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v2

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    new-instance v3, LJn/a$r;

    new-instance v4, LJn/a$q;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    invoke-direct {v3, v1, v4}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v3, p0, Lcf/e;->a:LJn/a$r;

    sget-object v1, Lcf/a;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Lcf/e;->b:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lcf/e;->c:Lxk/z;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$t;

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v2, LJn/a$s;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v1, p1, v2}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lcf/e;->d:LJn/a$t;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcf/f;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcf/f;

    invoke-direct {v0}, Lcf/f;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_13b

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_194

    goto/16 :goto_b5

    :sswitch_34
    const-string v2, "skippable"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_b5

    :cond_3e
    const/16 v3, 0xa

    goto/16 :goto_b5

    :sswitch_42
    const-string v2, "nextQuestion"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_b5

    :cond_4c
    const/16 v3, 0x9

    goto/16 :goto_b5

    :sswitch_50
    const-string v2, "optionType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_b5

    :cond_5a
    const/16 v3, 0x8

    goto/16 :goto_b5

    :sswitch_5e
    const-string v2, "optionArrangement"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_67

    goto :goto_b5

    :cond_67
    const/4 v3, 0x7

    goto :goto_b5

    :sswitch_69
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_72

    goto :goto_b5

    :cond_72
    const/4 v3, 0x6

    goto :goto_b5

    :sswitch_74
    const-string v2, "leaf"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7d

    goto :goto_b5

    :cond_7d
    const/4 v3, 0x5

    goto :goto_b5

    :sswitch_7f
    const-string v2, "id"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_88

    goto :goto_b5

    :cond_88
    const/4 v3, 0x4

    goto :goto_b5

    :sswitch_8a
    const-string v2, "questionMeta"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_93

    goto :goto_b5

    :cond_93
    const/4 v3, 0x3

    goto :goto_b5

    :sswitch_95
    const-string v2, "multiSelect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9e

    goto :goto_b5

    :cond_9e
    const/4 v3, 0x2

    goto :goto_b5

    :sswitch_a0
    const-string v2, "question"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a9

    goto :goto_b5

    :cond_a9
    const/4 v3, 0x1

    goto :goto_b5

    :sswitch_ab
    const-string v2, "options"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b4

    goto :goto_b5

    :cond_b4
    const/4 v3, 0x0

    :goto_b5
    packed-switch v3, :pswitch_data_1c2

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_bd
    iget-boolean v1, v0, Lcf/f;->g:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcf/f;->g:Z

    goto/16 :goto_1d

    :pswitch_c7
    iget-object v1, p0, Lcf/e;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Lcf/f;->i:LLe/f;

    goto/16 :goto_1d

    :pswitch_d3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcf/f;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_df
    iget-object v1, p0, Lcf/e;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcf/b;

    iput-object v1, v0, Lcf/f;->d:Lcf/b;

    goto/16 :goto_1d

    :pswitch_eb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_f7
    iget-boolean v1, v0, Lcf/f;->h:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcf/f;->h:Z

    goto/16 :goto_1d

    :pswitch_101
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcf/f;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_10d
    iget-object v1, p0, Lcf/e;->d:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Lcf/f;->j:Ljava/util/Map;

    goto/16 :goto_1d

    :pswitch_119
    iget-boolean v1, v0, Lcf/f;->f:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcf/f;->f:Z

    goto/16 :goto_1d

    :pswitch_123
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcf/f;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_12f
    iget-object v1, p0, Lcf/e;->a:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lcf/f;->c:Ljava/util/List;

    goto/16 :goto_1d

    :cond_13b
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_18b

    iget-object p1, v0, Lcf/f;->a:Ljava/lang/String;

    if-eqz p1, :cond_183

    iget-object p1, v0, Lcf/f;->b:Ljava/lang/String;

    if-eqz p1, :cond_17b

    iget-object p1, v0, Lcf/f;->c:Ljava/util/List;

    if-eqz p1, :cond_173

    iget-object p1, v0, Lcf/f;->d:Lcf/b;

    if-eqz p1, :cond_16b

    iget-object p1, v0, Lcf/f;->e:Ljava/lang/String;

    if-eqz p1, :cond_163

    iget-object p1, v0, Lcf/f;->j:Ljava/util/Map;

    if-eqz p1, :cond_15b

    return-object v0

    :cond_15b
    new-instance p1, Ljava/io/IOException;

    const-string v0, "questionMeta cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_163
    new-instance p1, Ljava/io/IOException;

    const-string v0, "optionType cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_16b
    new-instance p1, Ljava/io/IOException;

    const-string v0, "optionArrangement cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_173
    new-instance p1, Ljava/io/IOException;

    const-string v0, "options cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_17b
    new-instance p1, Ljava/io/IOException;

    const-string v0, "question cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_183
    new-instance p1, Ljava/io/IOException;

    const-string v0, "id cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_18b
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_194
    .sparse-switch
        -0x4a797962 -> :sswitch_ab
        -0x457dc41a -> :sswitch_a0
        -0x1055986b -> :sswitch_95
        -0xa459cf5 -> :sswitch_8a
        0xd1b -> :sswitch_7f
        0x329f5e -> :sswitch_74
        0x368f3a -> :sswitch_69
        0x28053755 -> :sswitch_5e
        0x51df494f -> :sswitch_50
        0x7c5b87f9 -> :sswitch_42
        0x7dc08fab -> :sswitch_34
    .end sparse-switch

    :pswitch_data_1c2
    .packed-switch 0x0
        :pswitch_12f
        :pswitch_123
        :pswitch_119
        :pswitch_10d
        :pswitch_101
        :pswitch_f7
        :pswitch_eb
        :pswitch_df
        :pswitch_d3
        :pswitch_c7
        :pswitch_bd
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcf/e;->read(LBk/a;)Lcf/f;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcf/f;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_ce

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "id"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/f;->a:Ljava/lang/String;

    if-eqz v0, :cond_c6

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "question"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/f;->b:Ljava/lang/String;

    if-eqz v0, :cond_be

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "options"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/f;->c:Ljava/util/List;

    if-eqz v0, :cond_b6

    iget-object v2, p0, Lcf/e;->a:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    const-string v0, "optionArrangement"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/f;->d:Lcf/b;

    if-eqz v0, :cond_ae

    iget-object v2, p0, Lcf/e;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "optionType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/f;->e:Ljava/lang/String;

    if-eqz v0, :cond_a6

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "multiSelect"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcf/f;->f:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "skippable"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcf/f;->g:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "leaf"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcf/f;->h:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "nextQuestion"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcf/f;->i:LLe/f;

    if-eqz v0, :cond_89

    iget-object v1, p0, Lcf/e;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_8c

    :cond_89
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_8c
    const-string v0, "questionMeta"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcf/f;->j:Ljava/util/Map;

    if-eqz p2, :cond_9e

    iget-object v0, p0, Lcf/e;->d:LJn/a$t;

    invoke-virtual {v0, p1, p2}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_9e
    new-instance p1, Ljava/io/IOException;

    const-string p2, "questionMeta cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_a6
    new-instance p1, Ljava/io/IOException;

    const-string p2, "optionType cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_ae
    new-instance p1, Ljava/io/IOException;

    const-string p2, "optionArrangement cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_b6
    new-instance p1, Ljava/io/IOException;

    const-string p2, "options cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_be
    new-instance p1, Ljava/io/IOException;

    const-string p2, "question cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_c6
    new-instance p1, Ljava/io/IOException;

    const-string p2, "id cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_ce
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcf/f;

    invoke-virtual {p0, p1, p2}, Lcf/e;->write(LBk/c;Lcf/f;)V

    return-void
.end method
