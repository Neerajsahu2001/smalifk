.class public final LBc/e;
.super Landroid/database/sqlite/SQLiteOpenHelper;
.source "CacheManagerDBHelper.java"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# virtual methods
.method public onCreate(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 4

    instance-of v0, p1, Landroid/database/sqlite/SQLiteDatabase;

    const-string v1, "CREATE TABLE IF NOT EXISTS cache_details_datatable(cache_key TEXT PRIMARY KEY,json_string TEXT,last_Update_Time INTEGER,specified_TTL REAL)"

    if-nez v0, :cond_a

    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    goto :goto_d

    :cond_a
    invoke-static {p1, v1}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->execSQL(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V

    :goto_d
    return-void
.end method

.method public onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .registers 4

    instance-of p2, p1, Landroid/database/sqlite/SQLiteDatabase;

    const-string p3, "DROP TABLE IF EXISTS cache_details_datatable"

    if-nez p2, :cond_a

    invoke-virtual {p1, p3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    goto :goto_d

    :cond_a
    invoke-static {p1, p3}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->execSQL(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V

    :goto_d
    invoke-virtual {p0, p1}, LBc/e;->onCreate(Landroid/database/sqlite/SQLiteDatabase;)V

    return-void
.end method
