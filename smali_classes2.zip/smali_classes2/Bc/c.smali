.class final LBc/c;
.super Ljava/lang/Object;
.source "CacheManager.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:LBc/d;


# direct methods
.method constructor <init>(LBc/d;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LBc/c;->a:LBc/d;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, LBc/c;->a:LBc/d;

    invoke-static {v0}, LBc/d;->a(LBc/d;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, LBc/d;->b(LBc/d;Ljava/lang/String;)V

    return-void
.end method
