.class public interface abstract LBi/f;
.super Ljava/lang/Object;
.source "Transport.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(LBi/c;LBi/h;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBi/c<",
            "TT;>;",
            "LBi/h;",
            ")V"
        }
    .end annotation
.end method

.method public abstract b(LBi/c;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBi/c<",
            "TT;>;)V"
        }
    .end annotation
.end method
