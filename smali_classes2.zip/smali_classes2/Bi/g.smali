.class public interface abstract LBi/g;
.super Ljava/lang/Object;
.source "TransportFactory.java"


# virtual methods
.method public abstract a(Ljava/lang/String;LBi/b;LBi/e;)LBi/f;
.end method
