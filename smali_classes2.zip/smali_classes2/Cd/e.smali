.class public final Lcd/e;
.super Lxk/z;
.source "CheckoutUpdateData$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcd/f;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lcd/f;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcd/n;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcd/f;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lcd/e;->b:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 3

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Lcd/m;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lcd/e;->a:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcd/f;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcd/f;

    invoke-direct {v0}, Lcd/f;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_107

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_10c

    goto/16 :goto_99

    :sswitch_34
    const-string v2, "slotTimings"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_99

    :cond_3e
    const/16 v3, 0x8

    goto/16 :goto_99

    :sswitch_42
    const-string v2, "obdSelected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4b

    goto :goto_99

    :cond_4b
    const/4 v3, 0x7

    goto :goto_99

    :sswitch_4d
    const-string v2, "cartItemRefId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_56

    goto :goto_99

    :cond_56
    const/4 v3, 0x6

    goto :goto_99

    :sswitch_58
    const-string v2, "serviceValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_61

    goto :goto_99

    :cond_61
    const/4 v3, 0x5

    goto :goto_99

    :sswitch_63
    const-string v2, "parentListingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6c

    goto :goto_99

    :cond_6c
    const/4 v3, 0x4

    goto :goto_99

    :sswitch_6e
    const-string v2, "coinSelected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_77

    goto :goto_99

    :cond_77
    const/4 v3, 0x3

    goto :goto_99

    :sswitch_79
    const-string v2, "listingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_82

    goto :goto_99

    :cond_82
    const/4 v3, 0x2

    goto :goto_99

    :sswitch_84
    const-string v2, "quantity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8d

    goto :goto_99

    :cond_8d
    const/4 v3, 0x1

    goto :goto_99

    :sswitch_8f
    const-string v2, "offerId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_98

    goto :goto_99

    :cond_98
    const/4 v3, 0x0

    :goto_99
    packed-switch v3, :pswitch_data_132

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_a1
    iget-object v1, p0, Lcd/e;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcd/n;

    iput-object v1, v0, Lcd/f;->f:Lcd/n;

    goto/16 :goto_1d

    :pswitch_ad
    iget-boolean v1, v0, Lcd/f;->g:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcd/f;->g:Z

    goto/16 :goto_1d

    :pswitch_b7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/f;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_c3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/f;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_cf
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/f;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_db
    iget-boolean v1, v0, Lcd/f;->h:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcd/f;->h:Z

    goto/16 :goto_1d

    :pswitch_e5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/f;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_f1
    iget v1, v0, Lcd/f;->b:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lcd/f;->b:I

    goto/16 :goto_1d

    :pswitch_fb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/f;->i:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_107
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_10c
    .sparse-switch
        -0x5c510369 -> :sswitch_8f
        -0x4c979b75 -> :sswitch_84
        -0x486bcd41 -> :sswitch_79
        -0x44bc1bb4 -> :sswitch_6e
        -0xf696cb -> :sswitch_63
        0x14eec3bc -> :sswitch_58
        0x1d2e9a7b -> :sswitch_4d
        0x48e282ac -> :sswitch_42
        0x62562d8b -> :sswitch_34
    .end sparse-switch

    :pswitch_data_132
    .packed-switch 0x0
        :pswitch_fb
        :pswitch_f1
        :pswitch_e5
        :pswitch_db
        :pswitch_cf
        :pswitch_c3
        :pswitch_b7
        :pswitch_ad
        :pswitch_a1
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcd/e;->read(LBk/a;)Lcd/f;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcd/f;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "serviceValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/f;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "quantity"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lcd/f;->b:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "cartItemRefId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/f;->c:Ljava/lang/String;

    if-eqz v0, :cond_35

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_38

    :cond_35
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_38
    const-string v0, "listingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/f;->d:Ljava/lang/String;

    if-eqz v0, :cond_47

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_4a

    :cond_47
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_4a
    const-string v0, "parentListingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/f;->e:Ljava/lang/String;

    if-eqz v0, :cond_59

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_5c

    :cond_59
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_5c
    const-string v0, "slotTimings"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/f;->f:Lcd/n;

    if-eqz v0, :cond_6b

    iget-object v1, p0, Lcd/e;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_6e

    :cond_6b
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_6e
    const-string v0, "obdSelected"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcd/f;->g:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "coinSelected"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lcd/f;->h:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "offerId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcd/f;->i:Ljava/lang/String;

    if-eqz p2, :cond_91

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_94

    :cond_91
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_94
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcd/f;

    invoke-virtual {p0, p1, p2}, Lcd/e;->write(LBk/c;Lcd/f;)V

    return-void
.end method
