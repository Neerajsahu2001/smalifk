.class public final Lcd/c;
.super Lxk/z;
.source "CheckoutInitRequest$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcd/d;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lbd/f;",
            ">;"
        }
    .end annotation
.end field

.field private final b:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcd/d;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 4

    invoke-direct {p0}, Lxk/z;-><init>()V

    sget-object v0, Lbd/e;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lcd/c;->a:Lxk/z;

    sget-object v0, Lcd/i;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lcd/c;->b:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcd/d;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcd/d;

    invoke-direct {v0}, Lcd/d;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_c0

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_d0

    goto :goto_74

    :sswitch_33
    const-string v2, "checkoutType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_74

    :cond_3c
    const/4 v3, 0x5

    goto :goto_74

    :sswitch_3e
    const-string v2, "egvRequests"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_74

    :cond_47
    const/4 v3, 0x4

    goto :goto_74

    :sswitch_49
    const-string v2, "pageType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_74

    :cond_52
    const/4 v3, 0x3

    goto :goto_74

    :sswitch_54
    const-string v2, "gbFlipkartEligible"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_74

    :cond_5d
    const/4 v3, 0x2

    goto :goto_74

    :sswitch_5f
    const-string v2, "cartRequest"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto :goto_74

    :cond_68
    const/4 v3, 0x1

    goto :goto_74

    :sswitch_6a
    const-string v2, "saleId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_73

    goto :goto_74

    :cond_73
    const/4 v3, 0x0

    :goto_74
    packed-switch v3, :pswitch_data_ea

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_7b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/d;->c:Ljava/lang/String;

    goto :goto_1d

    :pswitch_86
    iget-object v1, p0, Lcd/c;->b:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lcd/d;->e:Ljava/util/List;

    goto :goto_1d

    :pswitch_91
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/d;->a:Ljava/lang/String;

    goto :goto_1d

    :pswitch_9c
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Lcd/d;->f:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_a8
    iget-object v1, p0, Lcd/c;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lbd/f;

    iput-object v1, v0, Lcd/d;->d:Lbd/f;

    goto/16 :goto_1d

    :pswitch_b4
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/d;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_c0
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Lcd/d;->c:Ljava/lang/String;

    if-eqz p1, :cond_c8

    return-object v0

    :cond_c8
    new-instance p1, Ljava/io/IOException;

    const-string v0, "checkoutType cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :sswitch_data_d0
    .sparse-switch
        -0x36392c3e -> :sswitch_6a
        -0x1eb1b4b1 -> :sswitch_5f
        0x2ef123f7 -> :sswitch_54
        0x333a8669 -> :sswitch_49
        0x4bbbf7f8 -> :sswitch_3e
        0x572f3da0 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_ea
    .packed-switch 0x0
        :pswitch_b4
        :pswitch_a8
        :pswitch_9c
        :pswitch_91
        :pswitch_86
        :pswitch_7b
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcd/c;->read(LBk/a;)Lcd/d;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcd/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "pageType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/d;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "saleId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/d;->b:Ljava/lang/String;

    if-eqz v0, :cond_2a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "checkoutType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/d;->c:Ljava/lang/String;

    if-eqz v0, :cond_7a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "cartRequest"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/d;->d:Lbd/f;

    if-eqz v0, :cond_4a

    iget-object v1, p0, Lcd/c;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_4d

    :cond_4a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_4d
    const-string v0, "egvRequests"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/d;->e:Ljava/util/List;

    if-eqz v0, :cond_61

    iget-object v1, p0, Lcd/c;->b:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_64

    :cond_61
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_64
    const-string v0, "gbFlipkartEligible"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcd/d;->f:Ljava/lang/Boolean;

    if-eqz p2, :cond_73

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_76

    :cond_73
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_76
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_7a
    new-instance p1, Ljava/io/IOException;

    const-string p2, "checkoutType cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcd/d;

    invoke-virtual {p0, p1, p2}, Lcd/c;->write(LBk/c;Lcd/d;)V

    return-void
.end method
