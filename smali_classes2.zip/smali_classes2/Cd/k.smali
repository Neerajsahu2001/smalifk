.class public final Lcd/k;
.super Lxk/z;
.source "Giftwrap$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcd/l;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lcd/l;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcd/l;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lcd/k;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcd/l;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcd/l;

    invoke-direct {v0}, Lcd/l;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8f

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_94

    goto :goto_5e

    :sswitch_33
    const-string v2, "message"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_5e

    :cond_3c
    const/4 v3, 0x3

    goto :goto_5e

    :sswitch_3e
    const-string v2, "isChecked"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_5e

    :cond_47
    const/4 v3, 0x2

    goto :goto_5e

    :sswitch_49
    const-string v2, "from"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_5e

    :cond_52
    const/4 v3, 0x1

    goto :goto_5e

    :sswitch_54
    const-string v2, "to"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_5e

    :cond_5d
    const/4 v3, 0x0

    :goto_5e
    packed-switch v3, :pswitch_data_a6

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_65
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/l;->c:Ljava/lang/String;

    goto :goto_1d

    :pswitch_70
    iget-boolean v1, v0, Lcd/l;->d:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lcd/l;->d:Z

    goto :goto_1d

    :pswitch_79
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/l;->a:Ljava/lang/String;

    goto :goto_1d

    :pswitch_84
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/l;->b:Ljava/lang/String;

    goto :goto_1d

    :cond_8f
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_94
    .sparse-switch
        0xe7b -> :sswitch_54
        0x3017aa -> :sswitch_49
        0x9b0171d -> :sswitch_3e
        0x38eb0007 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_a6
    .packed-switch 0x0
        :pswitch_84
        :pswitch_79
        :pswitch_70
        :pswitch_65
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcd/k;->read(LBk/a;)Lcd/l;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcd/l;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "from"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/l;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "to"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/l;->b:Ljava/lang/String;

    if-eqz v0, :cond_2a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "message"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/l;->c:Ljava/lang/String;

    if-eqz v0, :cond_3c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "isChecked"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, Lcd/l;->d:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcd/l;

    invoke-virtual {p0, p1, p2}, Lcd/k;->write(LBk/c;Lcd/l;)V

    return-void
.end method
