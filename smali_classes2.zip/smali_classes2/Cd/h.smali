.class public final Lcd/h;
.super Ljava/lang/Object;
.source "CheckoutUpdateRequest.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcd/f;",
            ">;"
        }
    .end annotation
.end field

.field public d:Lbd/f;

.field public e:Lcd/l;

.field public f:Lcd/b;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
