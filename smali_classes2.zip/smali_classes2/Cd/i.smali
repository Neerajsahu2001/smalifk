.class public final Lcd/i;
.super Lxk/z;
.source "EgvRequest$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lcd/j;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lcd/j;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcd/j;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lcd/i;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lcd/j;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lcd/j;

    invoke-direct {v0}, Lcd/j;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_ed

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_fe

    goto/16 :goto_8b

    :sswitch_34
    const-string v2, "senderName"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3d

    goto :goto_8b

    :cond_3d
    const/4 v3, 0x7

    goto :goto_8b

    :sswitch_3f
    const-string v2, "message"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_48

    goto :goto_8b

    :cond_48
    const/4 v3, 0x6

    goto :goto_8b

    :sswitch_4a
    const-string v2, "noOfVouchers"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_53

    goto :goto_8b

    :cond_53
    const/4 v3, 0x5

    goto :goto_8b

    :sswitch_55
    const-string v2, "confReceiverEmailId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5e

    goto :goto_8b

    :cond_5e
    const/4 v3, 0x4

    goto :goto_8b

    :sswitch_60
    const-string v2, "receiverEmailId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_69

    goto :goto_8b

    :cond_69
    const/4 v3, 0x3

    goto :goto_8b

    :sswitch_6b
    const-string v2, "receiverName"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_74

    goto :goto_8b

    :cond_74
    const/4 v3, 0x2

    goto :goto_8b

    :sswitch_76
    const-string v2, "listingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7f

    goto :goto_8b

    :cond_7f
    const/4 v3, 0x1

    goto :goto_8b

    :sswitch_81
    const-string v2, "amount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8a

    goto :goto_8b

    :cond_8a
    const/4 v3, 0x0

    :goto_8b
    packed-switch v3, :pswitch_data_120

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_92
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/j;->f:Ljava/lang/String;

    goto :goto_1d

    :pswitch_9d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/j;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_a9
    iget v1, v0, Lcd/j;->b:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lcd/j;->b:I

    goto/16 :goto_1d

    :pswitch_b3
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/j;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_bf
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/j;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_cb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/j;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_d7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lcd/j;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_e3
    iget v1, v0, Lcd/j;->a:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lcd/j;->a:I

    goto/16 :goto_1d

    :cond_ed
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, Lcd/j;->c:Ljava/lang/String;

    if-eqz p1, :cond_f5

    return-object v0

    :cond_f5
    new-instance p1, Ljava/io/IOException;

    const-string v0, "receiverEmailId cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_fe
    .sparse-switch
        -0x5445afa8 -> :sswitch_81
        -0x486bcd41 -> :sswitch_76
        -0x2d03b6e6 -> :sswitch_6b
        -0x2b84af18 -> :sswitch_60
        -0x19b152dc -> :sswitch_55
        -0x9cfa0e3 -> :sswitch_4a
        0x38eb0007 -> :sswitch_3f
        0x3b72e660 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_120
    .packed-switch 0x0
        :pswitch_e3
        :pswitch_d7
        :pswitch_cb
        :pswitch_bf
        :pswitch_b3
        :pswitch_a9
        :pswitch_9d
        :pswitch_92
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcd/i;->read(LBk/a;)Lcd/j;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lcd/j;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "amount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lcd/j;->a:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "noOfVouchers"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lcd/j;->b:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "receiverEmailId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/j;->c:Ljava/lang/String;

    if-eqz v0, :cond_81

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "confReceiverEmailId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/j;->d:Ljava/lang/String;

    if-eqz v0, :cond_3a

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3d

    :cond_3a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3d
    const-string v0, "receiverName"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/j;->e:Ljava/lang/String;

    if-eqz v0, :cond_4a

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_4d

    :cond_4a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_4d
    const-string v0, "senderName"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/j;->f:Ljava/lang/String;

    if-eqz v0, :cond_5a

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_5d

    :cond_5a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_5d
    const-string v0, "message"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lcd/j;->g:Ljava/lang/String;

    if-eqz v0, :cond_6a

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_6d

    :cond_6a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_6d
    const-string v0, "listingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lcd/j;->h:Ljava/lang/String;

    if-eqz p2, :cond_7a

    invoke-virtual {v1, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_7d

    :cond_7a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_7d
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_81
    new-instance p1, Ljava/io/IOException;

    const-string p2, "receiverEmailId cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lcd/j;

    invoke-virtual {p0, p1, p2}, Lcd/i;->write(LBk/c;Lcd/j;)V

    return-void
.end method
