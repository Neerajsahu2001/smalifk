.class public interface abstract LD9/b;
.super Ljava/lang/Object;
.source "MediaData.kt"


# virtual methods
.method public abstract getClipRangeMs()LUn/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUn/j<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getRepeatStrategy()LD9/c;
.end method

.method public abstract getShouldCacheMedia()Z
.end method

.method public abstract getUri()Landroid/net/Uri;
.end method
