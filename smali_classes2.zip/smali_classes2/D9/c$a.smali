.class public final LD9/c$a;
.super Ljava/lang/Object;
.source "VideoViewData.kt"

# interfaces
.implements LD9/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD9/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:LD9/c$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LD9/c$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LD9/c$a;->a:LD9/c$a;

    return-void
.end method
