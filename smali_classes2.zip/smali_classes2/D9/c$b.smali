.class public final LD9/c$b;
.super Ljava/lang/Object;
.source "VideoViewData.kt"

# interfaces
.implements LD9/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD9/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private final a:I


# direct methods
.method public constructor <init>()V
    .registers 4

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v2, v0, v1}, LD9/c$b;-><init>(IILkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LD9/c$b;->a:I

    return-void
.end method

.method public synthetic constructor <init>(IILkotlin/jvm/internal/i;)V
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_5

    const/4 p1, 0x2

    :cond_5
    invoke-direct {p0, p1}, LD9/c$b;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final getCount()I
    .registers 2

    iget v0, p0, LD9/c$b;->a:I

    return v0
.end method
