.class public final LD9/a;
.super Ljava/lang/Object;
.source "LoadControl.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD9/a$a;
    }
.end annotation


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LD9/a$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LD9/a$a;-><init>(Lkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 9

    const/16 v6, 0x1f

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v7}, LD9/a;-><init>(IIIIZILkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(IIIIZ)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LD9/a;->a:I

    iput p2, p0, LD9/a;->b:I

    iput p3, p0, LD9/a;->c:I

    iput p4, p0, LD9/a;->d:I

    iput-boolean p5, p0, LD9/a;->e:Z

    return-void
.end method

.method public synthetic constructor <init>(IIIIZILkotlin/jvm/internal/i;)V
    .registers 11

    and-int/lit8 p7, p6, 0x1

    const v0, 0xc350

    if-eqz p7, :cond_b

    const p7, 0xc350

    goto :goto_c

    :cond_b
    move p7, p1

    :goto_c
    and-int/lit8 p1, p6, 0x2

    if-eqz p1, :cond_11

    goto :goto_12

    :cond_11
    move v0, p2

    :goto_12
    and-int/lit8 p1, p6, 0x4

    if-eqz p1, :cond_1b

    const/16 p3, 0x9c4

    const/16 v1, 0x9c4

    goto :goto_1c

    :cond_1b
    move v1, p3

    :goto_1c
    and-int/lit8 p1, p6, 0x8

    if-eqz p1, :cond_25

    const/16 p4, 0x1388

    const/16 v2, 0x1388

    goto :goto_26

    :cond_25
    move v2, p4

    :goto_26
    and-int/lit8 p1, p6, 0x10

    if-eqz p1, :cond_2d

    const/4 p5, 0x0

    const/4 p6, 0x0

    goto :goto_2e

    :cond_2d
    move p6, p5

    :goto_2e
    move-object p1, p0

    move p2, p7

    move p3, v0

    move p4, v1

    move p5, v2

    invoke-direct/range {p1 .. p6}, LD9/a;-><init>(IIIIZ)V

    return-void
.end method


# virtual methods
.method public final getBufferForPlaybackAfterRebufferMs()I
    .registers 2

    iget v0, p0, LD9/a;->d:I

    return v0
.end method

.method public final getBufferForPlaybackMs()I
    .registers 2

    iget v0, p0, LD9/a;->c:I

    return v0
.end method

.method public final getMaxBufferMs()I
    .registers 2

    iget v0, p0, LD9/a;->b:I

    return v0
.end method

.method public final getMinBufferMs()I
    .registers 2

    iget v0, p0, LD9/a;->a:I

    return v0
.end method

.method public final getPrioritizeTimeOverSizeThresholds()Z
    .registers 2

    iget-boolean v0, p0, LD9/a;->e:Z

    return v0
.end method

.method public final setBufferForPlaybackAfterRebufferMs(I)V
    .registers 2

    iput p1, p0, LD9/a;->d:I

    return-void
.end method

.method public final setBufferForPlaybackMs(I)V
    .registers 2

    iput p1, p0, LD9/a;->c:I

    return-void
.end method

.method public final setMaxBufferMs(I)V
    .registers 2

    iput p1, p0, LD9/a;->b:I

    return-void
.end method

.method public final setMinBufferMs(I)V
    .registers 2

    iput p1, p0, LD9/a;->a:I

    return-void
.end method

.method public final setPrioritizeTimeOverSizeThresholds(Z)V
    .registers 2

    iput-boolean p1, p0, LD9/a;->e:Z

    return-void
.end method
