.class public interface abstract LD9/d;
.super Ljava/lang/Object;
.source "VideoViewData.kt"

# interfaces
.implements LD9/b;


# virtual methods
.method public abstract getAspectRatioMode()I
.end method

.method public abstract getBitrateStrategy()Lu9/a$a;
.end method

.method public abstract getBlockSubtitleRendering()Z
.end method

.method public abstract synthetic getClipRangeMs()LUn/j;
.end method

.method public abstract getDoNotPauseVideoFlag()Z
.end method

.method public abstract getPreviewThumbnail()Ljava/lang/String;
.end method

.method public abstract synthetic getRepeatStrategy()LD9/c;
.end method

.method public abstract getResumePlaybackFromPreviousPosition()Z
.end method

.method public abstract getScalingMode()I
.end method

.method public abstract synthetic getShouldCacheMedia()Z
.end method

.method public abstract getShowBufferIndicator()Z
.end method

.method public abstract getShowPlayButton()Z
.end method

.method public abstract getShowReplayButton()Z
.end method

.method public abstract getShowTimer()Z
.end method

.method public abstract getTrackConstraintStrategy()Lu9/a$c;
.end method

.method public abstract synthetic getUri()Landroid/net/Uri;
.end method

.method public abstract getUseControls()Z
.end method

.method public abstract getUseSystemVolumeControl()Z
.end method

.method public abstract isLiveStream()Z
.end method

.method public abstract isMuted()Z
.end method

.method public abstract isSecured()Z
.end method

.method public abstract setMuted(Z)V
.end method
