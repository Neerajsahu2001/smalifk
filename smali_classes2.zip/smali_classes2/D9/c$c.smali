.class public final LD9/c$c;
.super Ljava/lang/Object;
.source "VideoViewData.kt"

# interfaces
.implements LD9/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD9/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field public static final a:LD9/c$c;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LD9/c$c;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LD9/c$c;->a:LD9/c$c;

    return-void
.end method
