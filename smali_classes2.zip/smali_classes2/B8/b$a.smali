.class final LB8/b$a;
.super Ljava/lang/Object;
.source "SizeTimeBatchingStrategy.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LB8/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LB8/b;


# direct methods
.method constructor <init>(LB8/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB8/b$a;->a:LB8/b;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, LB8/b$a;->a:LB8/b;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, LB8/b;->flush(Z)V

    return-void
.end method
