.class public final Lb8/c$b;
.super Ljava/lang/Object;
.source "TtsHelper.kt"

# interfaces
.implements Ldq/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb8/c;->playTts(ZLcom/flipkart/android/datagovernance/NavigationContext;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Leo/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lb8/c;

.field final synthetic d:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Lb8/c;Leo/a;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lb8/c;",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb8/c$b;->a:Ljava/lang/String;

    iput-object p2, p0, Lb8/c$b;->b:Ljava/lang/String;

    iput-object p3, p0, Lb8/c$b;->c:Lb8/c;

    iput-object p4, p0, Lb8/c$b;->d:Leo/a;

    return-void
.end method


# virtual methods
.method public getUniqueId()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lb8/c$b;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x3a

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lb8/c$b;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public onDone(Ljava/lang/String;)V
    .registers 5

    const-string v0, "uniqueId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TtsEvent;->TTS_COMPLETED:Lcom/flipkart/android/voice/flippi/tts/TtsEvent;

    iget-object v0, p0, Lb8/c$b;->c:Lb8/c;

    invoke-static {v0, p1}, Lb8/c;->access$sendTtsEvent(Lb8/c;Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V

    iget-object p1, p0, Lb8/c$b;->d:Leo/a;

    const-wide/16 v1, 0x0

    invoke-static {v0, p1, v1, v2}, Lb8/c;->access$onCompleted(Lb8/c;Leo/a;J)V

    return-void
.end method

.method public onError(Ljava/lang/String;)V
    .registers 3

    const-string v0, "uniqueId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "FAILURE"

    iget-object v0, p0, Lb8/c$b;->c:Lb8/c;

    invoke-static {v0, p1}, Lb8/c;->access$trackTimeTaken(Lb8/c;Ljava/lang/String;)V

    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TtsEvent;->TTS_FAILED:Lcom/flipkart/android/voice/flippi/tts/TtsEvent;

    invoke-static {v0, p1}, Lb8/c;->access$sendTtsEvent(Lb8/c;Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V

    return-void
.end method

.method public onStart(Ljava/lang/String;)V
    .registers 3

    const-string v0, "uniqueId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "SUCCESS"

    iget-object v0, p0, Lb8/c$b;->c:Lb8/c;

    invoke-static {v0, p1}, Lb8/c;->access$trackTimeTaken(Lb8/c;Ljava/lang/String;)V

    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TtsEvent;->TTS_STARTED:Lcom/flipkart/android/voice/flippi/tts/TtsEvent;

    invoke-static {v0, p1}, Lb8/c;->access$sendTtsEvent(Lb8/c;Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V

    return-void
.end method
