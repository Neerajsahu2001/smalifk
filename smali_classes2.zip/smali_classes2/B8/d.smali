.class public final Lb8/d;
.super Ljava/lang/Object;
.source "TtsTrackingHelper.kt"

# interfaces
.implements Ldq/e;


# instance fields
.field private final a:Lcom/flipkart/android/datagovernance/NavigationContext;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private final f:I

.field private final g:I

.field private final h:I

.field private final i:Ljava/lang/String;

.field private final j:J


# direct methods
.method public constructor <init>(Lcom/flipkart/android/datagovernance/NavigationContext;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    const-string v0, "assistantSessionId"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ttsText"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ttsType"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb8/d;->a:Lcom/flipkart/android/datagovernance/NavigationContext;

    iput-object p2, p0, Lb8/d;->b:Ljava/lang/String;

    iput-object p3, p0, Lb8/d;->c:Ljava/lang/String;

    iput-object p4, p0, Lb8/d;->d:Ljava/lang/String;

    const-string p1, "TtsTrackingHelper"

    iput-object p1, p0, Lb8/d;->e:Ljava/lang/String;

    const/4 p1, 0x1

    iput p1, p0, Lb8/d;->f:I

    const/4 p1, 0x2

    iput p1, p0, Lb8/d;->g:I

    const/4 p1, 0x3

    iput p1, p0, Lb8/d;->h:I

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "randomUUID().toString()"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lb8/d;->i:Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide p1

    iput-wide p1, p0, Lb8/d;->j:J

    return-void
.end method


# virtual methods
.method public onError(Ljava/lang/String;)V
    .registers 15

    const-string v0, "errorType"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    iget-wide v3, p0, Lb8/d;->j:J

    sub-long/2addr v1, v3

    sget-object v3, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v1, v2, v3}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    invoke-static {}, LS3/x;->trackTtsFailedEvent()V

    new-instance v2, Lcom/flipkart/android/datagovernance/events/TextToSpeechEvent;

    iget-object v6, p0, Lb8/d;->b:Ljava/lang/String;

    iget-object v7, p0, Lb8/d;->c:Ljava/lang/String;

    iget-object v5, p0, Lb8/d;->i:Ljava/lang/String;

    iget v8, p0, Lb8/d;->h:I

    iget-object v12, p0, Lb8/d;->d:Ljava/lang/String;

    move-object v4, v2

    move-wide v9, v0

    move-object v11, p1

    invoke-direct/range {v4 .. v12}, Lcom/flipkart/android/datagovernance/events/TextToSpeechEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v3

    iget-object v4, p0, Lb8/d;->a:Lcom/flipkart/android/datagovernance/NavigationContext;

    invoke-virtual {v3, v4, v2}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEventImmediate(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "TTS Error | Time elapsed : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, " | Type : "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x21

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lb8/d;->e:Ljava/lang/String;

    invoke-static {v0, p1}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public onReady()V
    .registers 14

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    iget-wide v3, p0, Lb8/d;->j:J

    sub-long/2addr v1, v3

    sget-object v3, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v1, v2, v3}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    new-instance v2, Lcom/flipkart/android/datagovernance/events/TextToSpeechEvent;

    iget-object v7, p0, Lb8/d;->c:Ljava/lang/String;

    iget v8, p0, Lb8/d;->g:I

    iget-object v5, p0, Lb8/d;->i:Ljava/lang/String;

    iget-object v6, p0, Lb8/d;->b:Ljava/lang/String;

    const/4 v11, 0x0

    iget-object v12, p0, Lb8/d;->d:Ljava/lang/String;

    move-object v4, v2

    move-wide v9, v0

    invoke-direct/range {v4 .. v12}, Lcom/flipkart/android/datagovernance/events/TextToSpeechEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v3

    iget-object v4, p0, Lb8/d;->a:Lcom/flipkart/android/datagovernance/NavigationContext;

    invoke-virtual {v3, v4, v2}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEventImmediate(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "TTS Ready | Time elapsed : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lb8/d;->e:Ljava/lang/String;

    invoke-static {v1, v0}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public onStart()V
    .registers 11

    invoke-static {}, LS3/x;->trackTtsRequestEvent()V

    new-instance v9, Lcom/flipkart/android/datagovernance/events/TextToSpeechEvent;

    iget v4, p0, Lb8/d;->f:I

    const-wide/16 v5, 0x0

    iget-object v1, p0, Lb8/d;->i:Ljava/lang/String;

    iget-object v2, p0, Lb8/d;->b:Ljava/lang/String;

    iget-object v3, p0, Lb8/d;->c:Ljava/lang/String;

    const/4 v7, 0x0

    iget-object v8, p0, Lb8/d;->d:Ljava/lang/String;

    move-object v0, v9

    invoke-direct/range {v0 .. v8}, Lcom/flipkart/android/datagovernance/events/TextToSpeechEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v0

    iget-object v1, p0, Lb8/d;->a:Lcom/flipkart/android/datagovernance/NavigationContext;

    invoke-virtual {v0, v1, v9}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEventImmediate(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    iget-object v0, p0, Lb8/d;->e:Ljava/lang/String;

    const-string v1, "TTS request started"

    invoke-static {v0, v1}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
