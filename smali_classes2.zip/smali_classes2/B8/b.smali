.class public final Lb8/b;
.super Ljava/lang/Object;
.source "TtsActionType.kt"


# static fields
.field public static final a:Lb8/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lb8/b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lb8/b;->a:Lb8/b;

    return-void
.end method


# virtual methods
.method public final parse(Ljava/lang/String;)Lcom/flipkart/android/voice/flippi/tts/TtsActionType;
    .registers 2

    if-eqz p1, :cond_a

    :try_start_2
    invoke-static {p1}, Lcom/flipkart/android/voice/flippi/tts/TtsActionType;->valueOf(Ljava/lang/String;)Lcom/flipkart/android/voice/flippi/tts/TtsActionType;

    move-result-object p1
    :try_end_6
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_6} :catch_7

    goto :goto_9

    :catch_7
    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TtsActionType;->NONE:Lcom/flipkart/android/voice/flippi/tts/TtsActionType;

    :goto_9
    return-object p1

    :cond_a
    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TtsActionType;->NONE:Lcom/flipkart/android/voice/flippi/tts/TtsActionType;

    return-object p1
.end method
