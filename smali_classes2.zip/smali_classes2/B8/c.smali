.class public final Lb8/c;
.super Ljava/lang/Object;
.source "TtsHelper.kt"

# interfaces
.implements Ldq/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb8/c$a;
    }
.end annotation


# static fields
.field public static final synthetic j:I


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lcom/flipkart/android/datagovernance/NavigationContext;

.field private final c:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "Lcom/flipkart/android/voice/flippi/tts/TtsEvent;",
            ">;"
        }
    .end annotation
.end field

.field private e:Landroid/os/Handler;

.field private f:Lcq/a;

.field private final g:Ljava/util/Locale;

.field private h:Lcom/flipkart/android/perf/b;

.field private i:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lb8/c$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lb8/c$a;-><init>(Lkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/android/datagovernance/NavigationContext;)V
    .registers 4

    const-string v0, "appContext"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb8/c;->a:Landroid/content/Context;

    iput-object p2, p0, Lb8/c;->b:Lcom/flipkart/android/datagovernance/NavigationContext;

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p1, p0, Lb8/c;->c:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance p1, Landroidx/lifecycle/I;

    invoke-direct {p1}, Landroidx/lifecycle/I;-><init>()V

    iput-object p1, p0, Lb8/c;->d:Landroidx/lifecycle/I;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object p1

    if-eqz p1, :cond_27

    iget-object p1, p1, Lcom/flipkart/android/configmodel/t2;->m:Ljava/lang/String;

    goto :goto_28

    :cond_27
    const/4 p1, 0x0

    :goto_28
    if-nez p1, :cond_2c

    const-string p1, "hi"

    :cond_2c
    new-instance p2, Ljava/util/Locale;

    invoke-direct {p2, p1}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    iput-object p2, p0, Lb8/c;->g:Ljava/util/Locale;

    return-void
.end method

.method public static a(Lb8/c;Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V
    .registers 3

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$ttsEvent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Lb8/c;->d:Landroidx/lifecycle/I;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/I;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static final access$onCompleted(Lb8/c;Leo/a;J)V
    .registers 6

    iget-object v0, p0, Lb8/c;->e:Landroid/os/Handler;

    if-nez v0, :cond_f

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lb8/c;->e:Landroid/os/Handler;

    :cond_f
    iget-object p0, p0, Lb8/c;->e:Landroid/os/Handler;

    if-eqz p0, :cond_1d

    new-instance v0, Landroidx/media3/ui/i;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p1}, Landroidx/media3/ui/i;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p0, v0, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_1d
    const-string p0, "handler"

    invoke-static {p0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public static final synthetic access$sendTtsEvent(Lb8/c;Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V
    .registers 2

    invoke-direct {p0, p1}, Lb8/c;->b(Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V

    return-void
.end method

.method public static final access$trackTimeTaken(Lb8/c;Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Lb8/c;->h:Lcom/flipkart/android/perf/b;

    if-eqz v0, :cond_f

    const-string v1, "state"

    invoke-virtual {v0, v1, p1}, Lcom/flipkart/android/perf/b;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/flipkart/android/perf/b;->stopTrace()V

    const/4 p1, 0x0

    iput-object p1, p0, Lb8/c;->h:Lcom/flipkart/android/perf/b;

    :cond_f
    return-void
.end method

.method private final b(Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V
    .registers 5

    iget-object v0, p0, Lb8/c;->e:Landroid/os/Handler;

    if-nez v0, :cond_f

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lb8/c;->e:Landroid/os/Handler;

    :cond_f
    iget-object v0, p0, Lb8/c;->e:Landroid/os/Handler;

    if-eqz v0, :cond_1d

    new-instance v1, Landroidx/lifecycle/k;

    const/4 v2, 0x2

    invoke-direct {v1, p0, p1, v2}, Landroidx/lifecycle/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_1d
    const-string p1, "handler"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1
.end method


# virtual methods
.method public final attachTtsEventListener(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "Lcom/flipkart/android/voice/flippi/tts/TtsEvent;",
            ">;)V"
        }
    .end annotation

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "observer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lb8/c;->d:Landroidx/lifecycle/I;

    invoke-virtual {v0, p2}, Landroidx/lifecycle/LiveData;->removeObserver(Landroidx/lifecycle/J;)V

    invoke-virtual {v0, p1, p2}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public getContext()Landroid/content/Context;
    .registers 2

    iget-object v0, p0, Lb8/c;->a:Landroid/content/Context;

    return-object v0
.end method

.method public final getTtsEngineInitTracker()Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;
    .registers 2

    iget-object v0, p0, Lb8/c;->i:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    return-object v0
.end method

.method public final getTtsValidity(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Lcom/flipkart/android/voice/flippi/tts/TTSValidity;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/flipkart/android/voice/flippi/tts/TTSValidity;"
        }
    .end annotation

    if-eqz p1, :cond_30

    if-eqz p2, :cond_30

    iget-object v0, p0, Lb8/c;->c:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, p2}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1a

    invoke-virtual {v0, p2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    const/4 v0, 0x1

    invoke-static {p2, p1, v0}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p2

    if-eqz p2, :cond_1a

    goto :goto_30

    :cond_1a
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_2d

    check-cast p3, Ljava/util/Collection;

    if-eqz p3, :cond_2a

    invoke-interface {p3}, Ljava/util/Collection;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_2d

    :cond_2a
    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TTSValidity;->AUTOLISTEN:Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    return-object p1

    :cond_2d
    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TTSValidity;->VALID:Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    goto :goto_32

    :cond_30
    :goto_30
    sget-object p1, Lcom/flipkart/android/voice/flippi/tts/TTSValidity;->INVALID:Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    :goto_32
    return-object p1
.end method

.method public final isSpeaking()Z
    .registers 3

    iget-object v0, p0, Lb8/c;->d:Landroidx/lifecycle/I;

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lcom/flipkart/android/voice/flippi/tts/TtsEvent;->TTS_STARTED:Lcom/flipkart/android/voice/flippi/tts/TtsEvent;

    if-ne v0, v1, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public onError(Ljava/lang/String;)V
    .registers 3

    if-eqz p1, :cond_a

    new-instance v0, Lb8/a;

    invoke-direct {v0, p1}, Lb8/a;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, LO7/c;->logException(Ljava/lang/Throwable;)V

    :cond_a
    return-void
.end method

.method public onInitialized()V
    .registers 4

    iget-object v0, p0, Lb8/c;->f:Lcq/a;

    if-eqz v0, :cond_1d

    invoke-virtual {v0}, Lcq/a;->d()Z

    move-result v0

    iget-object v1, p0, Lb8/c;->i:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    if-eqz v1, :cond_11

    const-string v2, "NETWORK_NEEDED"

    invoke-virtual {v1, v2, v0}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->addAttribute(Ljava/lang/String;I)V

    :cond_11
    iget-object v0, p0, Lb8/c;->b:Lcom/flipkart/android/datagovernance/NavigationContext;

    if-eqz v0, :cond_1c

    iget-object v1, p0, Lb8/c;->i:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    if-eqz v1, :cond_1c

    invoke-virtual {v1, v0}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->stopTraceAndTrackEventWithNC(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_1c
    return-void

    :cond_1d
    const-string v0, "androidTts"

    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method public onPreparedToInitialize()V
    .registers 3

    new-instance v0, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    invoke-virtual {p0}, Lb8/c;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lb8/c;->i:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    const-string v1, "FLIPPI_TTS_ENGINE_INIT_DELAY"

    invoke-virtual {v0, v1}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->startTrace(Ljava/lang/String;)V

    return-void
.end method

.method public onTtsVoiceLoadFail(Z)V
    .registers 12

    iget-object v0, p0, Lb8/c;->b:Lcom/flipkart/android/datagovernance/NavigationContext;

    if-eqz v0, :cond_24

    if-eqz p1, :cond_a

    const-string p1, "TTS_VOICE_NETWORK_REQUIRED"

    :goto_8
    move-object v2, p1

    goto :goto_d

    :cond_a
    const-string p1, "TTS_VOICE_NETWORK_NOT_REQUIRED"

    goto :goto_8

    :goto_d
    new-instance p1, Lcom/flipkart/android/datagovernance/events/common/ClientErrorEvent;

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string v3, "Unknown"

    const-string v4, "Native"

    const-string v5, "Non-Fatal"

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v1, p1

    invoke-direct/range {v1 .. v9}, Lcom/flipkart/android/datagovernance/events/common/ClientErrorEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/flipkart/android/datagovernance/events/common/ApiErrorInfo;)V

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v1

    invoke-virtual {v1, v0, p1}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEvent(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    :cond_24
    return-void
.end method

.method public final playTts(ZLcom/flipkart/android/datagovernance/NavigationContext;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Leo/a;)V
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lcom/flipkart/android/datagovernance/NavigationContext;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    const-string p1, "uniqueId"

    invoke-static {p4, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "ttsString"

    invoke-static {p5, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "ttsUrls"

    invoke-static {p6, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "completedListener"

    invoke-static {p7, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p1, Lcom/flipkart/android/perf/b;

    invoke-direct {p1}, Lcom/flipkart/android/perf/b;-><init>()V

    iput-object p1, p0, Lb8/c;->h:Lcom/flipkart/android/perf/b;

    const-string v0, "TTS_LOAD"

    invoke-virtual {p1, v0}, Lcom/flipkart/android/perf/b;->startTrace(Ljava/lang/String;)V

    iget-object p1, p0, Lb8/c;->c:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p1, p4, p5}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/c;->getTtsConfig()Lcom/flipkart/android/configmodel/M1;

    move-result-object p1

    const-wide/16 v0, 0x7d0

    if-eqz p1, :cond_3b

    iget-wide v2, p1, Lcom/flipkart/android/configmodel/M1;->b:J

    const-wide/16 v4, 0x0

    cmp-long p1, v2, v4

    if-gtz p1, :cond_3a

    goto :goto_3b

    :cond_3a
    move-wide v0, v2

    :cond_3b
    :goto_3b
    iget-object p1, p0, Lb8/c;->f:Lcq/a;

    const/4 v2, 0x0

    if-nez p1, :cond_62

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/c;->getTtsConfig()Lcom/flipkart/android/configmodel/M1;

    move-result-object p1

    if-eqz p1, :cond_4d

    iget-object p1, p1, Lcom/flipkart/android/configmodel/M1;->c:Ljava/lang/String;

    goto :goto_4e

    :cond_4d
    move-object p1, v2

    :goto_4e
    if-nez p1, :cond_56

    sget-object p1, Lfq/b;->CUSTOM:Lfq/b;

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    :cond_56
    new-instance v3, Lcq/a;

    new-instance v4, Lfq/a;

    invoke-direct {v4, v0, v1, p1}, Lfq/a;-><init>(JLjava/lang/String;)V

    invoke-direct {v3, v4}, Lcq/a;-><init>(Lfq/a;)V

    iput-object v3, p0, Lb8/c;->f:Lcq/a;

    :cond_62
    iget-object p1, p0, Lb8/c;->f:Lcq/a;

    if-eqz p1, :cond_93

    iget-object v0, p0, Lb8/c;->h:Lcom/flipkart/android/perf/b;

    const-string v1, "ANDROID_TTS"

    if-eqz v0, :cond_74

    invoke-virtual {p1}, Lcq/a;->b()Ljava/lang/String;

    const-string v2, "type"

    invoke-virtual {v0, v2, v1}, Lcom/flipkart/android/perf/b;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    :cond_74
    iget-object v0, p0, Lb8/c;->g:Ljava/util/Locale;

    invoke-virtual {p1, p0, v0}, Lcq/a;->c(Ldq/a;Ljava/util/Locale;)V

    new-instance v0, Ldq/b;

    new-instance v2, Lb8/c$b;

    invoke-direct {v2, p4, p5, p0, p7}, Lb8/c$b;-><init>(Ljava/lang/String;Ljava/lang/String;Lb8/c;Leo/a;)V

    new-instance p4, Lb8/d;

    if-nez p3, :cond_86

    const-string p3, ""

    :cond_86
    invoke-virtual {p1}, Lcq/a;->b()Ljava/lang/String;

    invoke-direct {p4, p2, p3, p5, v1}, Lb8/d;-><init>(Lcom/flipkart/android/datagovernance/NavigationContext;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, p5, p6, v2, p4}, Ldq/b;-><init>(Ljava/lang/String;Ljava/util/List;Lb8/c$b;Lb8/d;)V

    invoke-virtual {p1, v0}, Lcq/a;->f(Ldq/b;)V

    return-void

    :cond_93
    const-string p1, "androidTts"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v2
.end method

.method public final setTtsEngineInitTracker(Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;)V
    .registers 2

    iput-object p1, p0, Lb8/c;->i:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    return-void
.end method

.method public final stop()V
    .registers 5

    iget-object v0, p0, Lb8/c;->h:Lcom/flipkart/android/perf/b;

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    const-string v2, "state"

    const-string v3, "INTERRUPTED"

    invoke-virtual {v0, v2, v3}, Lcom/flipkart/android/perf/b;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/flipkart/android/perf/b;->stopTrace()V

    iput-object v1, p0, Lb8/c;->h:Lcom/flipkart/android/perf/b;

    :cond_11
    sget-object v0, Lcom/flipkart/android/voice/flippi/tts/TtsEvent;->TTS_COMPLETED:Lcom/flipkart/android/voice/flippi/tts/TtsEvent;

    invoke-direct {p0, v0}, Lb8/c;->b(Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V

    iget-object v0, p0, Lb8/c;->f:Lcq/a;

    if-eqz v0, :cond_26

    if-eqz v0, :cond_20

    invoke-virtual {v0}, Lcq/a;->g()V

    goto :goto_26

    :cond_20
    const-string v0, "androidTts"

    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_26
    :goto_26
    return-void
.end method
