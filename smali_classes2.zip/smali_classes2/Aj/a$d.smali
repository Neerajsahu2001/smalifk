.class final LAj/a$d;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-vision-common@@19.0.0"


# annotations
.annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAj/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "d"
.end annotation


# instance fields
.field private a:Lcom/google/android/gms/common/images/Size;

.field private b:Lcom/google/android/gms/common/images/Size;


# direct methods
.method public constructor <init>(Landroid/hardware/Camera$Size;Landroid/hardware/Camera$Size;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/google/android/gms/common/images/Size;

    iget v1, p1, Landroid/hardware/Camera$Size;->width:I

    iget p1, p1, Landroid/hardware/Camera$Size;->height:I

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/common/images/Size;-><init>(II)V

    iput-object v0, p0, LAj/a$d;->a:Lcom/google/android/gms/common/images/Size;

    if-eqz p2, :cond_1b

    new-instance p1, Lcom/google/android/gms/common/images/Size;

    iget v0, p2, Landroid/hardware/Camera$Size;->width:I

    iget p2, p2, Landroid/hardware/Camera$Size;->height:I

    invoke-direct {p1, v0, p2}, Lcom/google/android/gms/common/images/Size;-><init>(II)V

    iput-object p1, p0, LAj/a$d;->b:Lcom/google/android/gms/common/images/Size;

    :cond_1b
    return-void
.end method


# virtual methods
.method public final a()Lcom/google/android/gms/common/images/Size;
    .registers 2

    iget-object v0, p0, LAj/a$d;->a:Lcom/google/android/gms/common/images/Size;

    return-object v0
.end method

.method public final b()Lcom/google/android/gms/common/images/Size;
    .registers 2

    iget-object v0, p0, LAj/a$d;->b:Lcom/google/android/gms/common/images/Size;

    return-object v0
.end method
