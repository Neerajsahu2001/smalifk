.class final LAj/a$b;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-vision-common@@19.0.0"

# interfaces
.implements Landroid/hardware/Camera$PreviewCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAj/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation


# instance fields
.field private final synthetic a:LAj/a;


# direct methods
.method constructor <init>(LAj/a;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAj/a$b;->a:LAj/a;

    return-void
.end method


# virtual methods
.method public final onPreviewFrame([BLandroid/hardware/Camera;)V
    .registers 4

    iget-object v0, p0, LAj/a$b;->a:LAj/a;

    invoke-static {v0}, LAj/a;->l(LAj/a;)LAj/a$c;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, LAj/a$c;->c([BLandroid/hardware/Camera;)V

    return-void
.end method
