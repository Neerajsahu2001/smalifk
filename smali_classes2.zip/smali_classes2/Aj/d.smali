.class public Laj/d;
.super Ljava/lang/Object;
.source "com.google.firebase:firebase-appindexing@@20.0.0"


# annotations
.annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Laj/d$a;
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
