.class public interface abstract Laj/c;
.super Ljava/lang/Object;
.source "com.google.firebase:firebase-appindexing@@20.0.0"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Laj/c$a;
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
