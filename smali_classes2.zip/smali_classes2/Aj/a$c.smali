.class final LAj/a$c;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-vision-common@@19.0.0"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAj/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "c"
.end annotation


# instance fields
.field private a:LAj/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LAj/b<",
            "*>;"
        }
    .end annotation
.end field

.field private b:J

.field private final c:Ljava/lang/Object;

.field private d:Z

.field private e:J

.field private f:I

.field private g:Ljava/nio/ByteBuffer;

.field private final synthetic h:LAj/a;


# direct methods
.method constructor <init>(LAj/a;LAj/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAj/b<",
            "*>;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAj/a$c;->h:LAj/a;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, LAj/a$c;->b:J

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAj/a$c;->c:Ljava/lang/Object;

    const/4 p1, 0x1

    iput-boolean p1, p0, LAj/a$c;->d:Z

    const/4 p1, 0x0

    iput p1, p0, LAj/a$c;->f:I

    iput-object p2, p0, LAj/a$c;->a:LAj/b;

    return-void
.end method


# virtual methods
.method final a()V
    .registers 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "Assert"
        }
    .end annotation

    iget-object v0, p0, LAj/a$c;->a:LAj/b;

    invoke-virtual {v0}, LAj/b;->release()V

    const/4 v0, 0x0

    iput-object v0, p0, LAj/a$c;->a:LAj/b;

    return-void
.end method

.method final b(Z)V
    .registers 3

    iget-object v0, p0, LAj/a$c;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iput-boolean p1, p0, LAj/a$c;->d:Z

    iget-object p1, p0, LAj/a$c;->c:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v0

    return-void

    :catchall_c
    move-exception p1

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_c

    throw p1
.end method

.method final c([BLandroid/hardware/Camera;)V
    .registers 8

    iget-object v0, p0, LAj/a$c;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LAj/a$c;->g:Ljava/nio/ByteBuffer;

    if-eqz v1, :cond_14

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v1

    invoke-virtual {p2, v1}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    const/4 p2, 0x0

    iput-object p2, p0, LAj/a$c;->g:Ljava/nio/ByteBuffer;

    goto :goto_14

    :catchall_12
    move-exception p1

    goto :goto_4d

    :cond_14
    :goto_14
    iget-object p2, p0, LAj/a$c;->h:LAj/a;

    invoke-static {p2}, LAj/a;->m(LAj/a;)Ljava/util/HashMap;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_29

    const-string p1, "CameraSource"

    const-string p2, "Skipping frame. Could not find ByteBuffer associated with the image data from the camera."

    invoke-static {p1, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    monitor-exit v0

    return-void

    :cond_29
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iget-wide v3, p0, LAj/a$c;->b:J

    sub-long/2addr v1, v3

    iput-wide v1, p0, LAj/a$c;->e:J

    iget p2, p0, LAj/a$c;->f:I

    add-int/lit8 p2, p2, 0x1

    iput p2, p0, LAj/a$c;->f:I

    iget-object p2, p0, LAj/a$c;->h:LAj/a;

    invoke-static {p2}, LAj/a;->m(LAj/a;)Ljava/util/HashMap;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    iput-object p1, p0, LAj/a$c;->g:Ljava/nio/ByteBuffer;

    iget-object p1, p0, LAj/a$c;->c:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v0

    return-void

    :goto_4d
    monitor-exit v0
    :try_end_4e
    .catchall {:try_start_3 .. :try_end_4e} :catchall_12

    throw p1
.end method

.method public final run()V
    .registers 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "InlinedApi"
        }
    .end annotation

    :goto_0
    iget-object v0, p0, LAj/a$c;->c:Ljava/lang/Object;

    monitor-enter v0

    :goto_3
    :try_start_3
    iget-boolean v1, p0, LAj/a$c;->d:Z

    if-eqz v1, :cond_1e

    iget-object v2, p0, LAj/a$c;->g:Ljava/nio/ByteBuffer;
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_11

    if-nez v2, :cond_1e

    :try_start_b
    iget-object v1, p0, LAj/a$c;->c:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->wait()V
    :try_end_10
    .catch Ljava/lang/InterruptedException; {:try_start_b .. :try_end_10} :catch_14
    .catchall {:try_start_b .. :try_end_10} :catchall_11

    goto :goto_3

    :catchall_11
    move-exception v1

    goto/16 :goto_97

    :catch_14
    move-exception v1

    :try_start_15
    const-string v2, "CameraSource"

    const-string v3, "Frame processing loop terminated."

    invoke-static {v2, v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    monitor-exit v0

    return-void

    :cond_1e
    if-nez v1, :cond_22

    monitor-exit v0

    return-void

    :cond_22
    new-instance v1, LAj/c$a;

    invoke-direct {v1}, LAj/c$a;-><init>()V

    iget-object v2, p0, LAj/a$c;->g:Ljava/nio/ByteBuffer;

    iget-object v3, p0, LAj/a$c;->h:LAj/a;

    invoke-static {v3}, LAj/a;->o(LAj/a;)Lcom/google/android/gms/common/images/Size;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/common/images/Size;->getWidth()I

    move-result v3

    iget-object v4, p0, LAj/a$c;->h:LAj/a;

    invoke-static {v4}, LAj/a;->o(LAj/a;)Lcom/google/android/gms/common/images/Size;

    move-result-object v4

    invoke-virtual {v4}, Lcom/google/android/gms/common/images/Size;->getHeight()I

    move-result v4

    invoke-virtual {v1, v2, v3, v4}, LAj/c$a;->d(Ljava/nio/ByteBuffer;II)V

    iget v2, p0, LAj/a$c;->f:I

    invoke-virtual {v1, v2}, LAj/c$a;->c(I)V

    iget-wide v2, p0, LAj/a$c;->e:J

    invoke-virtual {v1, v2, v3}, LAj/c$a;->f(J)V

    iget-object v2, p0, LAj/a$c;->h:LAj/a;

    invoke-static {v2}, LAj/a;->n(LAj/a;)I

    move-result v2

    invoke-virtual {v1, v2}, LAj/c$a;->e(I)V

    invoke-virtual {v1}, LAj/c$a;->a()LAj/c;

    move-result-object v1

    iget-object v2, p0, LAj/a$c;->g:Ljava/nio/ByteBuffer;

    const/4 v3, 0x0

    iput-object v3, p0, LAj/a$c;->g:Ljava/nio/ByteBuffer;

    monitor-exit v0
    :try_end_5d
    .catchall {:try_start_15 .. :try_end_5d} :catchall_11

    :try_start_5d
    iget-object v0, p0, LAj/a$c;->a:LAj/b;

    invoke-virtual {v0, v1}, LAj/b;->receiveFrame(LAj/c;)V
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_5d .. :try_end_62} :catch_72
    .catchall {:try_start_5d .. :try_end_62} :catchall_70

    iget-object v0, p0, LAj/a$c;->h:LAj/a;

    invoke-static {v0}, LAj/a;->j(LAj/a;)Landroid/hardware/Camera;

    move-result-object v0

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    goto :goto_0

    :catchall_70
    move-exception v0

    goto :goto_89

    :catch_72
    move-exception v0

    :try_start_73
    const-string v1, "CameraSource"

    const-string v3, "Exception thrown from receiver."

    invoke-static {v1, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_7a
    .catchall {:try_start_73 .. :try_end_7a} :catchall_70

    iget-object v0, p0, LAj/a$c;->h:LAj/a;

    invoke-static {v0}, LAj/a;->j(LAj/a;)Landroid/hardware/Camera;

    move-result-object v0

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    goto/16 :goto_0

    :goto_89
    iget-object v1, p0, LAj/a$c;->h:LAj/a;

    invoke-static {v1}, LAj/a;->j(LAj/a;)Landroid/hardware/Camera;

    move-result-object v1

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    throw v0

    :goto_97
    :try_start_97
    monitor-exit v0
    :try_end_98
    .catchall {:try_start_97 .. :try_end_98} :catchall_11

    throw v1
.end method
