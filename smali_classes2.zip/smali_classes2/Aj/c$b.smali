.class public final LAj/c$b;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-vision-common@@19.0.0"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAj/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:J

.field private e:I


# direct methods
.method public constructor <init>(LAj/c$b;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget v0, p1, LAj/c$b;->a:I

    iput v0, p0, LAj/c$b;->a:I

    iget v0, p1, LAj/c$b;->b:I

    iput v0, p0, LAj/c$b;->b:I

    iget v0, p1, LAj/c$b;->c:I

    iput v0, p0, LAj/c$b;->c:I

    iget-wide v0, p1, LAj/c$b;->d:J

    iput-wide v0, p0, LAj/c$b;->d:J

    iget p1, p1, LAj/c$b;->e:I

    iput p1, p0, LAj/c$b;->e:I

    return-void
.end method

.method static synthetic f(LAj/c$b;I)V
    .registers 2

    iput p1, p0, LAj/c$b;->a:I

    return-void
.end method

.method static synthetic g(LAj/c$b;J)V
    .registers 3

    iput-wide p1, p0, LAj/c$b;->d:J

    return-void
.end method

.method static synthetic h(LAj/c$b;I)V
    .registers 2

    iput p1, p0, LAj/c$b;->b:I

    return-void
.end method

.method static synthetic j(LAj/c$b;I)V
    .registers 2

    iput p1, p0, LAj/c$b;->c:I

    return-void
.end method

.method static synthetic k(LAj/c$b;I)V
    .registers 2

    iput p1, p0, LAj/c$b;->e:I

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    iget v0, p0, LAj/c$b;->b:I

    return v0
.end method

.method public final b()I
    .registers 2

    iget v0, p0, LAj/c$b;->c:I

    return v0
.end method

.method public final c()I
    .registers 2

    iget v0, p0, LAj/c$b;->e:I

    return v0
.end method

.method public final d()J
    .registers 3

    iget-wide v0, p0, LAj/c$b;->d:J

    return-wide v0
.end method

.method public final e()I
    .registers 2

    iget v0, p0, LAj/c$b;->a:I

    return v0
.end method

.method public final i()V
    .registers 3

    iget v0, p0, LAj/c$b;->e:I

    rem-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_e

    iget v0, p0, LAj/c$b;->a:I

    iget v1, p0, LAj/c$b;->b:I

    iput v1, p0, LAj/c$b;->a:I

    iput v0, p0, LAj/c$b;->b:I

    :cond_e
    const/4 v0, 0x0

    iput v0, p0, LAj/c$b;->e:I

    return-void
.end method
