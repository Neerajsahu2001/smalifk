.class public final Lbf/g;
.super Lxk/z;
.source "OfferSummaryGroup$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lbf/h;",
        ">;"
    }
.end annotation


# static fields
.field public static final e:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lbf/h;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/r;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/O;",
            ">;>;"
        }
    .end annotation
.end field

.field private final c:LJn/a$r;

.field private final d:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lbf/h;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lbf/g;->e:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v1, LMe/O;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-class v1, LLe/f;

    invoke-static {v1, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v1, LTe/q;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Lbf/g;->a:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, Lbf/g;->b:Lxk/z;

    sget-object v0, Laf/m;->o:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    new-instance v1, LJn/a$r;

    new-instance v2, LJn/a$q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v0, v2}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Lbf/g;->c:LJn/a$r;

    sget-object v0, LSe/g;->d:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lbf/g;->d:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lbf/h;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lbf/h;

    invoke-direct {v0}, Lbf/h;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16f

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_180

    goto/16 :goto_d1

    :sswitch_34
    const-string v2, "offerSummaries"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_d1

    :cond_3e
    const/16 v3, 0xc

    goto/16 :goto_d1

    :sswitch_42
    const-string v2, "expandThisOffer"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_d1

    :cond_4c
    const/16 v3, 0xb

    goto/16 :goto_d1

    :sswitch_50
    const-string v2, "newTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_d1

    :cond_5a
    const/16 v3, 0xa

    goto/16 :goto_d1

    :sswitch_5e
    const-string v2, "viewAll"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_d1

    :cond_68
    const/16 v3, 0x9

    goto/16 :goto_d1

    :sswitch_6c
    const-string v2, "bankOfferGroups"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_d1

    :cond_76
    const/16 v3, 0x8

    goto/16 :goto_d1

    :sswitch_7a
    const-string v2, "title"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_83

    goto :goto_d1

    :cond_83
    const/4 v3, 0x7

    goto :goto_d1

    :sswitch_85
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8e

    goto :goto_d1

    :cond_8e
    const/4 v3, 0x6

    goto :goto_d1

    :sswitch_90
    const-string v2, "moreOffers"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_99

    goto :goto_d1

    :cond_99
    const/4 v3, 0x5

    goto :goto_d1

    :sswitch_9b
    const-string v2, "bankOfferEnabled"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a4

    goto :goto_d1

    :cond_a4
    const/4 v3, 0x4

    goto :goto_d1

    :sswitch_a6
    const-string v2, "bankOfferEnabledV1"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_af

    goto :goto_d1

    :cond_af
    const/4 v3, 0x3

    goto :goto_d1

    :sswitch_b1
    const-string v2, "offerGroupType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ba

    goto :goto_d1

    :cond_ba
    const/4 v3, 0x2

    goto :goto_d1

    :sswitch_bc
    const-string v2, "bucketId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c5

    goto :goto_d1

    :cond_c5
    const/4 v3, 0x1

    goto :goto_d1

    :sswitch_c7
    const-string v2, "subTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d0

    goto :goto_d1

    :cond_d0
    const/4 v3, 0x0

    :goto_d1
    iget-object v1, p0, Lbf/g;->a:Lxk/z;

    packed-switch v3, :pswitch_data_1b6

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_db
    iget-object v1, p0, Lbf/g;->c:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lbf/h;->g:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_e7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Lbf/h;->h:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_f3
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/r;

    iput-object v1, v0, Lbf/j;->e:LTe/r;

    goto/16 :goto_1d

    :pswitch_fd
    iget-object v1, p0, Lbf/g;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Lbf/j;->f:LLe/f;

    goto/16 :goto_1d

    :pswitch_109
    iget-object v1, p0, Lbf/g;->d:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lbf/h;->i:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_115
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbf/j;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_121
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_12d
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/r;

    iput-object v1, v0, Lbf/j;->d:LTe/r;

    goto/16 :goto_1d

    :pswitch_137
    iget-boolean v1, v0, Lbf/h;->j:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lbf/h;->j:Z

    goto/16 :goto_1d

    :pswitch_141
    iget-boolean v1, v0, Lbf/h;->k:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lbf/h;->k:Z

    goto/16 :goto_1d

    :pswitch_14b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbf/j;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_157
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbf/h;->l:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_163
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbf/j;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_16f
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_177

    return-object v0

    :cond_177
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_180
    .sparse-switch
        -0x7c93a408 -> :sswitch_c7
        -0x5f907f5b -> :sswitch_bc
        -0x51dc70a3 -> :sswitch_b1
        -0xf3f1004 -> :sswitch_a6
        -0xf33365f -> :sswitch_9b
        -0x5573ab4 -> :sswitch_90
        0x368f3a -> :sswitch_85
        0x6942258 -> :sswitch_7a
        0x13af4f74 -> :sswitch_6c
        0x1b1288bc -> :sswitch_5e
        0x51788c98 -> :sswitch_50
        0x53425ce4 -> :sswitch_42
        0x60c313c8 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_1b6
    .packed-switch 0x0
        :pswitch_163
        :pswitch_157
        :pswitch_14b
        :pswitch_141
        :pswitch_137
        :pswitch_12d
        :pswitch_121
        :pswitch_115
        :pswitch_109
        :pswitch_fd
        :pswitch_f3
        :pswitch_e7
        :pswitch_db
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbf/g;->read(LBk/a;)Lbf/h;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lbf/h;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_e3

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "offerGroupType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->a:Ljava/lang/String;

    if-eqz v0, :cond_24

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_27

    :cond_24
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_27
    const-string v0, "title"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->b:Ljava/lang/String;

    if-eqz v0, :cond_34

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_37

    :cond_34
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_37
    const-string v0, "subTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->c:Ljava/lang/String;

    if-eqz v0, :cond_44

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_47

    :cond_44
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_47
    const-string v0, "moreOffers"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->d:LTe/r;

    iget-object v2, p0, Lbf/g;->a:Lxk/z;

    if-eqz v0, :cond_56

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_59

    :cond_56
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_59
    const-string v0, "newTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->e:LTe/r;

    if-eqz v0, :cond_66

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_69

    :cond_66
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_69
    const-string v0, "viewAll"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->f:LLe/f;

    if-eqz v0, :cond_78

    iget-object v2, p0, Lbf/g;->b:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_7b

    :cond_78
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_7b
    const-string v0, "offerSummaries"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/h;->g:Ljava/util/List;

    if-eqz v0, :cond_8f

    iget-object v2, p0, Lbf/g;->c:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_92

    :cond_8f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_92
    const-string v0, "expandThisOffer"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/h;->h:Ljava/lang/Boolean;

    if-eqz v0, :cond_a1

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v2, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a4

    :cond_a1
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a4
    const-string v0, "bankOfferGroups"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/h;->i:Ljava/util/List;

    if-eqz v0, :cond_b8

    iget-object v2, p0, Lbf/g;->d:LJn/a$r;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v2, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_bb

    :cond_b8
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_bb
    const-string v0, "bankOfferEnabled"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lbf/h;->j:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "bankOfferEnabledV1"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lbf/h;->k:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "bucketId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lbf/h;->l:Ljava/lang/String;

    if-eqz p2, :cond_dc

    invoke-virtual {v1, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_df

    :cond_dc
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_df
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_e3
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lbf/h;

    invoke-virtual {p0, p1, p2}, Lbf/g;->write(LBk/c;Lbf/h;)V

    return-void
.end method
