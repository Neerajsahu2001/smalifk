.class public final Lbf/d;
.super LMe/R3;
.source "OfferInfo.java"


# instance fields
.field public a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LTe/A0;",
            ">;"
        }
    .end annotation
.end field

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:LTe/Q;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LMe/R3;-><init>()V

    return-void
.end method
