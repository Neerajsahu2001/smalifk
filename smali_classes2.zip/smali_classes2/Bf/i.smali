.class public final Lbf/i;
.super Lxk/z;
.source "OfferSummaryGroupBase$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lbf/j;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LTe/r;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LLe/f<",
            "LMe/O;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lbf/j;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v1, LMe/O;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-class v1, LLe/f;

    invoke-static {v1, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v1, LTe/q;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Lbf/i;->a:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, Lbf/i;->b:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lbf/j;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lbf/j;

    invoke-direct {v0}, Lbf/j;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_d6

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_e6

    goto :goto_7f

    :sswitch_33
    const-string v2, "newTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_7f

    :cond_3c
    const/4 v3, 0x6

    goto :goto_7f

    :sswitch_3e
    const-string v2, "viewAll"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_7f

    :cond_47
    const/4 v3, 0x5

    goto :goto_7f

    :sswitch_49
    const-string v2, "title"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_7f

    :cond_52
    const/4 v3, 0x4

    goto :goto_7f

    :sswitch_54
    const-string v2, "type"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_7f

    :cond_5d
    const/4 v3, 0x3

    goto :goto_7f

    :sswitch_5f
    const-string v2, "moreOffers"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto :goto_7f

    :cond_68
    const/4 v3, 0x2

    goto :goto_7f

    :sswitch_6a
    const-string v2, "offerGroupType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_73

    goto :goto_7f

    :cond_73
    const/4 v3, 0x1

    goto :goto_7f

    :sswitch_75
    const-string v2, "subTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7e

    goto :goto_7f

    :cond_7e
    const/4 v3, 0x0

    :goto_7f
    iget-object v1, p0, Lbf/i;->a:Lxk/z;

    packed-switch v3, :pswitch_data_104

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_88
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/r;

    iput-object v1, v0, Lbf/j;->e:LTe/r;

    goto :goto_1d

    :pswitch_91
    iget-object v1, p0, Lbf/i;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LLe/f;

    iput-object v1, v0, Lbf/j;->f:LLe/f;

    goto :goto_1d

    :pswitch_9c
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbf/j;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_a8
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LMe/R3;->type:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_b4
    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTe/r;

    iput-object v1, v0, Lbf/j;->d:LTe/r;

    goto/16 :goto_1d

    :pswitch_be
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbf/j;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_ca
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lbf/j;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_d6
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LMe/R3;->type:Ljava/lang/String;

    if-eqz p1, :cond_de

    return-object v0

    :cond_de
    new-instance p1, Ljava/io/IOException;

    const-string v0, "type cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :sswitch_data_e6
    .sparse-switch
        -0x7c93a408 -> :sswitch_75
        -0x51dc70a3 -> :sswitch_6a
        -0x5573ab4 -> :sswitch_5f
        0x368f3a -> :sswitch_54
        0x6942258 -> :sswitch_49
        0x1b1288bc -> :sswitch_3e
        0x51788c98 -> :sswitch_33
    .end sparse-switch

    :pswitch_data_104
    .packed-switch 0x0
        :pswitch_ca
        :pswitch_be
        :pswitch_b4
        :pswitch_a8
        :pswitch_9c
        :pswitch_91
        :pswitch_88
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lbf/i;->read(LBk/a;)Lbf/j;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lbf/j;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "type"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LMe/R3;->type:Ljava/lang/String;

    if-eqz v0, :cond_7f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "offerGroupType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->a:Ljava/lang/String;

    if-eqz v0, :cond_24

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_27

    :cond_24
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_27
    const-string v0, "title"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->b:Ljava/lang/String;

    if-eqz v0, :cond_34

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_37

    :cond_34
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_37
    const-string v0, "subTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->c:Ljava/lang/String;

    if-eqz v0, :cond_44

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_47

    :cond_44
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_47
    const-string v0, "moreOffers"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->d:LTe/r;

    iget-object v1, p0, Lbf/i;->a:Lxk/z;

    if-eqz v0, :cond_56

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_59

    :cond_56
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_59
    const-string v0, "newTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lbf/j;->e:LTe/r;

    if-eqz v0, :cond_66

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_69

    :cond_66
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_69
    const-string v0, "viewAll"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lbf/j;->f:LLe/f;

    if-eqz p2, :cond_78

    iget-object v0, p0, Lbf/i;->b:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_7b

    :cond_78
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_7b
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_7f
    new-instance p1, Ljava/io/IOException;

    const-string p2, "type cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lbf/j;

    invoke-virtual {p0, p1, p2}, Lbf/i;->write(LBk/c;Lbf/j;)V

    return-void
.end method
