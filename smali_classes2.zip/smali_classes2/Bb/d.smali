.class public final Lbb/d;
.super LMa/b;
.source "FacetResponseWrapper.java"


# instance fields
.field public b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lbb/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, LMa/b;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lbb/d;->b:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public getFacets()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lbb/b;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lbb/d;->b:Ljava/util/ArrayList;

    return-object v0
.end method

.method public setFacets(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lbb/b;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lbb/d;->b:Ljava/util/ArrayList;

    return-void
.end method
