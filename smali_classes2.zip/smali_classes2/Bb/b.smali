.class public final Lbb/b;
.super Ljava/lang/Object;
.source "FacetResponse.java"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lbb/f;",
            ">;"
        }
    .end annotation
.end field

.field public c:Lcom/flipkart/mapi/model/discovery/n;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lbb/b;->b:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public getMetadata()Lcom/flipkart/mapi/model/discovery/n;
    .registers 2

    iget-object v0, p0, Lbb/b;->c:Lcom/flipkart/mapi/model/discovery/n;

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lbb/b;->a:Ljava/lang/String;

    return-object v0
.end method

.method public getValue()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lbb/f;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lbb/b;->b:Ljava/util/ArrayList;

    return-object v0
.end method

.method public setMetadata(Lcom/flipkart/mapi/model/discovery/n;)V
    .registers 2

    iput-object p1, p0, Lbb/b;->c:Lcom/flipkart/mapi/model/discovery/n;

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lbb/b;->a:Ljava/lang/String;

    return-void
.end method

.method public setValues(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lbb/f;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lbb/b;->b:Ljava/util/ArrayList;

    return-void
.end method
