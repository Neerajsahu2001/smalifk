.class public final Lbb/f;
.super Ljava/lang/Object;
.source "FacetValue.java"


# instance fields
.field public a:Ljava/lang/String;

.field public b:I

.field public c:LOa/Q;

.field public d:Lcom/flipkart/mapi/model/discovery/t;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LOa/Q;

    invoke-direct {v0}, LOa/Q;-><init>()V

    iput-object v0, p0, Lbb/f;->c:LOa/Q;

    new-instance v0, Lcom/flipkart/mapi/model/discovery/t;

    invoke-direct {v0}, Lcom/flipkart/mapi/model/discovery/t;-><init>()V

    iput-object v0, p0, Lbb/f;->d:Lcom/flipkart/mapi/model/discovery/t;

    return-void
.end method


# virtual methods
.method public getCount()I
    .registers 2

    iget v0, p0, Lbb/f;->b:I

    return v0
.end method

.method public getMetadata()Lcom/flipkart/mapi/model/discovery/t;
    .registers 2

    iget-object v0, p0, Lbb/f;->d:Lcom/flipkart/mapi/model/discovery/t;

    return-object v0
.end method

.method public getResource()LOa/Q;
    .registers 2

    iget-object v0, p0, Lbb/f;->c:LOa/Q;

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lbb/f;->a:Ljava/lang/String;

    return-object v0
.end method

.method public setCount(I)V
    .registers 2

    iput p1, p0, Lbb/f;->b:I

    return-void
.end method

.method public setMetadata(Lcom/flipkart/mapi/model/discovery/t;)V
    .registers 2

    iput-object p1, p0, Lbb/f;->d:Lcom/flipkart/mapi/model/discovery/t;

    return-void
.end method

.method public setResource(LOa/Q;)V
    .registers 2

    iput-object p1, p0, Lbb/f;->c:LOa/Q;

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lbb/f;->a:Ljava/lang/String;

    return-void
.end method
