.class public interface abstract LB9/a;
.super Ljava/lang/Object;
.source "PlayerListenerConsumer.kt"


# virtual methods
.method public abstract register(Landroidx/media3/common/y;)V
.end method

.method public abstract unRegister()V
.end method
