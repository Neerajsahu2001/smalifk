.class public final LAa/a;
.super Ljava/lang/Object;
.source "JWTTokenPair.java"


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAa/a;->a:Ljava/lang/String;

    iput-object p2, p0, LAa/a;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public getAt()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LAa/a;->a:Ljava/lang/String;

    return-object v0
.end method

.method public getRt()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LAa/a;->b:Ljava/lang/String;

    return-object v0
.end method
