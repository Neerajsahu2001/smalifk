.class public final LAa/d;
.super Ljava/lang/Object;
.source "KevlarStateManagerImpl.java"

# interfaces
.implements LAa/c;


# instance fields
.field private a:Ljava/lang/String;

.field private final b:LAa/b;


# direct methods
.method public constructor <init>(LAa/b;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "NO-OP"

    iput-object v0, p0, LAa/d;->a:Ljava/lang/String;

    iput-object p1, p0, LAa/d;->b:LAa/b;

    return-void
.end method


# virtual methods
.method public getKevlarClient()LAa/b;
    .registers 2

    iget-object v0, p0, LAa/d;->b:LAa/b;

    return-object v0
.end method

.method public getState()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LAa/d;->a:Ljava/lang/String;

    return-object v0
.end method

.method public setState(Ljava/lang/String;)V
    .registers 5

    if-nez p1, :cond_3

    goto :goto_43

    :cond_3
    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, -0x1

    sparse-switch v1, :sswitch_data_48

    goto :goto_40

    :sswitch_15
    const-string v1, "REFRESH"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1e

    goto :goto_40

    :cond_1e
    const/4 v2, 0x3

    goto :goto_40

    :sswitch_20
    const-string v1, "RESET"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_29

    goto :goto_40

    :cond_29
    const/4 v2, 0x2

    goto :goto_40

    :sswitch_2b
    const-string v1, "NO-OP"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_34

    goto :goto_40

    :cond_34
    const/4 v2, 0x1

    goto :goto_40

    :sswitch_36
    const-string v1, "ACK"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3f

    goto :goto_40

    :cond_3f
    const/4 v2, 0x0

    :goto_40
    packed-switch v2, :pswitch_data_5a

    :goto_43
    iget-object p1, p0, LAa/d;->a:Ljava/lang/String;

    :pswitch_45
    iput-object p1, p0, LAa/d;->a:Ljava/lang/String;

    return-void

    :sswitch_data_48
    .sparse-switch
        0xfc69 -> :sswitch_36
        0x46fc56d -> :sswitch_2b
        0x4a4252f -> :sswitch_20
        0x6b7e1ebb -> :sswitch_15
    .end sparse-switch

    :pswitch_data_5a
    .packed-switch 0x0
        :pswitch_45
        :pswitch_45
        :pswitch_45
        :pswitch_45
    .end packed-switch
.end method
