.class public interface abstract LAa/c;
.super Ljava/lang/Object;
.source "KevlarStateManager.java"


# virtual methods
.method public abstract getKevlarClient()LAa/b;
.end method

.method public abstract getState()Ljava/lang/String;
.end method

.method public abstract setState(Ljava/lang/String;)V
.end method
