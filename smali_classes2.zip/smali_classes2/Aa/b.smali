.class public interface abstract LAa/b;
.super Ljava/lang/Object;
.source "KevlarClient.java"


# virtual methods
.method public abstract addKevlarSessionKeysHeader(LAa/a;Lokhttp3/Headers;Ljava/util/Map;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAa/a;",
            "Lokhttp3/Headers;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public abstract performAcknowledgement(LAa/a;)V
.end method

.method public abstract performReset()V
.end method

.method public abstract shouldRefreshAT(Lcom/flipkart/rome/datatypes/response/session/v1/SessionResponse;)Z
.end method

.method public abstract shouldRefreshRefreshToken(Lcom/flipkart/rome/datatypes/response/session/v1/SessionResponse;)Z
.end method
