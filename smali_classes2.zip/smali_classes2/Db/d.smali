.class public final Ldb/d;
.super Ljava/lang/Object;
.source "UserPincodeLocationResponse.java"


# instance fields
.field public a:Ldb/b;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getParameterizedAddress()Ldb/b;
    .registers 2

    iget-object v0, p0, Ldb/d;->a:Ldb/b;

    return-object v0
.end method
