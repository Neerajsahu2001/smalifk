.class public final Ldb/b;
.super Ljava/lang/Object;
.source "ParameterizedAddress.java"


# instance fields
.field public a:I

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;
    .annotation runtime Lyk/b;
        value = "source-id"
    .end annotation
.end field

.field public f:Ljava/lang/String;
    .annotation runtime Lyk/b;
        value = "source-type"
    .end annotation
.end field

.field public g:Ljava/lang/String;

.field public h:I

.field public i:Ljava/lang/String;
    .annotation runtime Lyk/b;
        value = "village-town-city"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getConfidence()I
    .registers 2

    iget v0, p0, Ldb/b;->a:I

    return v0
.end method

.method public getCountry()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldb/b;->b:Ljava/lang/String;

    return-object v0
.end method

.method public getLocality()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldb/b;->c:Ljava/lang/String;

    return-object v0
.end method

.method public getPincode()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldb/b;->d:Ljava/lang/String;

    return-object v0
.end method

.method public getSourceId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldb/b;->e:Ljava/lang/String;

    return-object v0
.end method

.method public getSourceType()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldb/b;->f:Ljava/lang/String;

    return-object v0
.end method

.method public getState()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldb/b;->g:Ljava/lang/String;

    return-object v0
.end method

.method public getStatusCode()I
    .registers 2

    iget v0, p0, Ldb/b;->h:I

    return v0
.end method

.method public getVillageTownCity()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldb/b;->i:Ljava/lang/String;

    return-object v0
.end method
