.class public final Ld7/b;
.super Ljava/lang/Object;
.source "ReviewVideoData.kt"

# interfaces
.implements LD9/d;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private c:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    const-string v0, "src"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "thumbnail"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld7/b;->a:Ljava/lang/String;

    iput-object p2, p0, Ld7/b;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public getAspectRatioMode()I
    .registers 2

    const/4 v0, 0x3

    return v0
.end method

.method public getBitrateStrategy()Lu9/a$a;
    .registers 2

    sget-object v0, Lu9/a$a$a;->a:Lu9/a$a$a;

    return-object v0
.end method

.method public getBlockSubtitleRendering()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public getClipRangeMs()LUn/j;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUn/j<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    return-object v0
.end method

.method public getDoNotPauseVideoFlag()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getPreviewThumbnail()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ld7/b;->b:Ljava/lang/String;

    return-object v0
.end method

.method public getRepeatStrategy()LD9/c;
    .registers 2

    sget-object v0, LD9/c$c;->a:LD9/c$c;

    return-object v0
.end method

.method public getResumePlaybackFromPreviousPosition()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getScalingMode()I
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public getShouldCacheMedia()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public getShowBufferIndicator()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public getShowPlayButton()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getShowReplayButton()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getShowTimer()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final getSrc()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ld7/b;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final getThumbnail()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ld7/b;->b:Ljava/lang/String;

    return-object v0
.end method

.method public getTrackConstraintStrategy()Lu9/a$c;
    .registers 2

    sget-object v0, Lu9/a$c$b;->a:Lu9/a$c$b;

    return-object v0
.end method

.method public getUri()Landroid/net/Uri;
    .registers 3

    iget-object v0, p0, Ld7/b;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v1, "parse(src)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public getUseControls()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public getUseSystemVolumeControl()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public isLiveStream()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public isMuted()Z
    .registers 2

    iget-boolean v0, p0, Ld7/b;->c:Z

    return v0
.end method

.method public isSecured()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public setMuted(Z)V
    .registers 2

    iput-boolean p1, p0, Ld7/b;->c:Z

    return-void
.end method
