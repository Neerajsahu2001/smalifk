.class public final LD7/d;
.super Ljava/lang/Object;
.source "UploadInitiateRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# static fields
.field private static final c:Lokhttp3/MediaType;


# instance fields
.field private final a:Lcom/flipkart/android/services/b;

.field private final b:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "application/json; charset=utf-8"

    invoke-static {v0}, Lokhttp3/MediaType;->parse(Ljava/lang/String;)Lokhttp3/MediaType;

    move-result-object v0

    sput-object v0, LD7/d;->c:Lokhttp3/MediaType;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/android/services/b;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD7/d;->b:Landroid/content/Context;

    iput-object p2, p0, LD7/d;->a:Lcom/flipkart/android/services/b;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 14

    iget-object v6, p0, LD7/d;->a:Lcom/flipkart/android/services/b;

    :try_start_2
    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getCheckSum()Ljava/lang/String;

    move-result-object v0
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_6} :catch_f0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1f

    iget-object v7, p0, LD7/d;->a:Lcom/flipkart/android/services/b;

    invoke-interface {v7}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v9

    const-string v11, "Got blank checksum"

    const/4 v12, 0x0

    const/16 v10, 0x8

    invoke-interface/range {v7 .. v12}, Lcom/flipkart/android/services/b;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    return-void

    :cond_1f
    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x64

    if-le v2, v3, :cond_34

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    sub-int/2addr v2, v3

    invoke-virtual {v1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    :cond_34
    new-instance v2, LNa/f;

    invoke-direct {v2, v1, v0}, LNa/f;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, LD7/d;->b:Landroid/content/Context;

    invoke-static {v0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object v1

    invoke-virtual {v1, v2}, Lcom/flipkart/android/gson/Serializer;->serialize(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    sget-object v2, LD7/d;->c:Lokhttp3/MediaType;

    invoke-static {v2, v1}, Lokhttp3/RequestBody;->create(Lokhttp3/MediaType;Ljava/lang/String;)Lokhttp3/RequestBody;

    move-result-object v1

    new-instance v2, Lokhttp3/Request$Builder;

    invoke-direct {v2}, Lokhttp3/Request$Builder;-><init>()V

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getUploadUrl()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v2

    invoke-virtual {v2, v1}, Lokhttp3/Request$Builder;->post(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object v1

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getHeaders()Ljava/util/Map;

    move-result-object v2

    invoke-static {v2}, LD7/g;->getHeaders(Ljava/util/Map;)Lokhttp3/Headers;

    move-result-object v2

    invoke-virtual {v1, v2}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object v1

    instance-of v2, v1, Lokhttp3/Request$Builder;

    if-nez v2, :cond_6f

    invoke-virtual {v1}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v1

    goto :goto_73

    :cond_6f
    invoke-static {v1}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object v1

    :goto_73
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Upload File Request "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lpa/a;->debug(Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getRequestQueueHelper()Lcom/flipkart/android/init/p;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/flipkart/android/init/p;->getOkHttpClient(Landroid/content/Context;)Lokhttp3/OkHttpClient;

    move-result-object v0

    instance-of v2, v0, Lokhttp3/OkHttpClient;

    if-nez v2, :cond_95

    invoke-virtual {v0, v1}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    goto :goto_99

    :cond_95
    invoke-static {v0, v1}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->newCall(Lokhttp3/OkHttpClient;Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    :goto_99
    :try_start_99
    invoke-interface {v0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v1

    if-eqz v1, :cond_ac

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v1

    goto :goto_ad

    :cond_ac
    const/4 v1, 0x0

    :goto_ad
    invoke-virtual {v0}, Lokhttp3/Response;->isSuccessful()Z

    move-result v2

    if-eqz v2, :cond_c5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_c5

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v6, v0, v2, v1}, Lcom/flipkart/android/services/b;->onUploadInitiateSuccessFull(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_ef

    :cond_c5
    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Lokhttp3/Response;->message()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    const/16 v3, 0x9

    move-object v0, v6

    invoke-interface/range {v0 .. v5}, Lcom/flipkart/android/services/b;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V
    :try_end_d8
    .catch Ljava/io/IOException; {:try_start_99 .. :try_end_d8} :catch_db

    goto :goto_ef

    :goto_d9
    move-object v5, v0

    goto :goto_dd

    :catch_db
    move-exception v0

    goto :goto_d9

    :goto_dd
    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/16 v3, 0x9

    move-object v0, v6

    invoke-interface/range {v0 .. v5}, Lcom/flipkart/android/services/b;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_ef
    return-void

    :catch_f0
    move-exception v12

    iget-object v7, p0, LD7/d;->a:Lcom/flipkart/android/services/b;

    invoke-interface {v7}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v9

    const/16 v10, 0x8

    invoke-virtual {v12}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v11

    invoke-interface/range {v7 .. v12}, Lcom/flipkart/android/services/b;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method
