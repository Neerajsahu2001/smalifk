.class public final Ld7/a;
.super Ljava/lang/Object;
.source "FkVideoData.kt"

# interfaces
.implements LD9/d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld7/a$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/net/Uri;

.field private final b:Ljava/lang/String;

.field private final c:Z

.field private final d:I

.field private final e:I

.field private final f:I

.field private final g:Z

.field private final h:Z

.field private final i:Z

.field private final j:Z

.field private final k:Z

.field private final l:Z

.field private final m:Z

.field private n:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ld7/a$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld7/a$a;-><init>(Lkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 5

    const-string v0, "readableMap"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "src"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    if-nez v0, :cond_13

    move-object v0, v1

    :cond_13
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v2, "parse(this)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Ld7/a;->a:Landroid/net/Uri;

    const-string v0, "thumbnail"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_27

    goto :goto_28

    :cond_27
    move-object v1, v0

    :goto_28
    iput-object v1, p0, Ld7/a;->b:Ljava/lang/String;

    const-string v0, "isSecure"

    invoke-static {p1, v0}, LLc/g;->getBooleanOrDefault(Lcom/facebook/react/bridge/ReadableMap;Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Ld7/a;->c:Z

    const-string v0, "loopCount"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3f

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    move-result v0

    goto :goto_40

    :cond_3f
    const/4 v0, -0x1

    :goto_40
    iput v0, p0, Ld7/a;->d:I

    const-string v0, "resizeMode"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4f

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    move-result v0

    goto :goto_50

    :cond_4f
    const/4 v0, 0x3

    :goto_50
    iput v0, p0, Ld7/a;->e:I

    const-string v0, "videoScalingMode"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_60

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    move-result v0

    goto :goto_61

    :cond_60
    const/4 v0, 0x1

    :goto_61
    iput v0, p0, Ld7/a;->f:I

    const-string v0, "disableVolumeControl"

    invoke-static {p1, v0}, LLc/g;->getBooleanOrDefault(Lcom/facebook/react/bridge/ReadableMap;Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Ld7/a;->g:Z

    const-string v0, "disableControls"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_78

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    goto :goto_79

    :cond_78
    const/4 v0, 0x1

    :goto_79
    iput-boolean v0, p0, Ld7/a;->h:Z

    const-string v0, "hideBufferIndicator"

    invoke-static {p1, v0}, LLc/g;->getBooleanOrDefault(Lcom/facebook/react/bridge/ReadableMap;Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Ld7/a;->i:Z

    const-string v0, "showPlayButton"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_90

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    goto :goto_91

    :cond_90
    const/4 v0, 0x1

    :goto_91
    iput-boolean v0, p0, Ld7/a;->j:Z

    const-string v0, "showReplayButton"

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9f

    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getBoolean(Ljava/lang/String;)Z

    move-result v2

    :cond_9f
    iput-boolean v2, p0, Ld7/a;->k:Z

    const-string v0, "hideTimer"

    invoke-static {p1, v0}, LLc/g;->getBooleanOrDefault(Lcom/facebook/react/bridge/ReadableMap;Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Ld7/a;->l:Z

    const-string v0, "doNotPauseVideo"

    invoke-static {p1, v0}, LLc/g;->getBooleanOrDefault(Lcom/facebook/react/bridge/ReadableMap;Ljava/lang/String;)Z

    move-result p1

    iput-boolean p1, p0, Ld7/a;->m:Z

    return-void
.end method


# virtual methods
.method public getAspectRatioMode()I
    .registers 2

    iget v0, p0, Ld7/a;->e:I

    return v0
.end method

.method public getBitrateStrategy()Lu9/a$a$a;
    .registers 2

    sget-object v0, Lu9/a$a$a;->a:Lu9/a$a$a;

    return-object v0
.end method

.method public bridge synthetic getBitrateStrategy()Lu9/a$a;
    .registers 2

    invoke-virtual {p0}, Ld7/a;->getBitrateStrategy()Lu9/a$a$a;

    move-result-object v0

    return-object v0
.end method

.method public getBlockSubtitleRendering()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public bridge synthetic getClipRangeMs()LUn/j;
    .registers 2

    invoke-virtual {p0}, Ld7/a;->getClipRangeMs()Ljava/lang/Void;

    move-result-object v0

    check-cast v0, LUn/j;

    return-object v0
.end method

.method public getClipRangeMs()Ljava/lang/Void;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getDoNotPauseVideoFlag()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->m:Z

    return v0
.end method

.method public getPreviewThumbnail()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ld7/a;->b:Ljava/lang/String;

    return-object v0
.end method

.method public getRepeatStrategy()LD9/c;
    .registers 3

    const/4 v0, -0x1

    iget v1, p0, Ld7/a;->d:I

    if-eq v1, v0, :cond_13

    if-eqz v1, :cond_10

    const/4 v0, 0x1

    if-eq v1, v0, :cond_10

    new-instance v0, LD9/c$b;

    invoke-direct {v0, v1}, LD9/c$b;-><init>(I)V

    goto :goto_15

    :cond_10
    sget-object v0, LD9/c$c;->a:LD9/c$c;

    goto :goto_15

    :cond_13
    sget-object v0, LD9/c$a;->a:LD9/c$a;

    :goto_15
    return-object v0
.end method

.method public getResumePlaybackFromPreviousPosition()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getScalingMode()I
    .registers 2

    iget v0, p0, Ld7/a;->f:I

    return v0
.end method

.method public getShouldCacheMedia()Z
    .registers 4

    iget-object v0, p0, Ld7/a;->a:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    const-string v1, "file"

    const/4 v2, 0x1

    invoke-static {v1, v0, v2}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    xor-int/2addr v0, v2

    return v0
.end method

.method public getShowBufferIndicator()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->i:Z

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public getShowPlayButton()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->j:Z

    return v0
.end method

.method public getShowReplayButton()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->k:Z

    return v0
.end method

.method public getShowTimer()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->l:Z

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public getTrackConstraintStrategy()Lu9/a$c;
    .registers 5

    sget-object v0, Lq4/a;->a:Lq4/a;

    sget-object v1, Lcom/flipkart/android/configmodel/ABKey;->videoResolutionViewSizeScale:Lcom/flipkart/android/configmodel/ABKey;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v2

    invoke-virtual {v2}, Lcom/flipkart/android/config/c;->getVideoResolutionViewSizeScale()F

    move-result v2

    invoke-virtual {v0, v1, v2}, Lq4/a;->getFloatOrDefault(Lcom/flipkart/android/configmodel/ABKey;F)F

    move-result v1

    sget-object v2, Lcom/flipkart/android/configmodel/ABKey;->isVideoResolutionByViewSizeEnabled:Lcom/flipkart/android/configmodel/ABKey;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v3

    invoke-virtual {v3}, Lcom/flipkart/android/config/c;->isVideoResolutionByViewSizeEnabled()Z

    move-result v3

    invoke-virtual {v0, v2, v3}, Lq4/a;->getBooleanOrDefault(Lcom/flipkart/android/configmodel/ABKey;Z)Z

    move-result v0

    if-eqz v0, :cond_26

    new-instance v0, Lu9/a$c$c;

    invoke-direct {v0, v1}, Lu9/a$c$c;-><init>(F)V

    goto :goto_28

    :cond_26
    sget-object v0, Lu9/a$c$b;->a:Lu9/a$c$b;

    :goto_28
    return-object v0
.end method

.method public getUri()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Ld7/a;->a:Landroid/net/Uri;

    return-object v0
.end method

.method public getUseControls()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->h:Z

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public getUseSystemVolumeControl()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->g:Z

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public isLiveStream()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public isMuted()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->n:Z

    return v0
.end method

.method public isSecured()Z
    .registers 2

    iget-boolean v0, p0, Ld7/a;->c:Z

    return v0
.end method

.method public setMuted(Z)V
    .registers 2

    iput-boolean p1, p0, Ld7/a;->n:Z

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\n    |FkVideoData(\n    |  src=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Ld7/a;->a:Landroid/net/Uri;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\',\n    |  thumbnail=\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Ld7/a;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\',\n    |  secure="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->c:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  loopCount="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Ld7/a;->d:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  resizeMode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Ld7/a;->e:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  scalingMode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Ld7/a;->f:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  disableVolumeControl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->g:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  disableControls="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->h:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  hideBufferIndicator="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->i:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  showPlayButton="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->j:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  showReplayButton="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->k:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  hideTimer="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->l:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  doNotPauseVideo="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->m:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    |  isMuted="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld7/a;->n:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, "\n    |)\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lvp/k;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
