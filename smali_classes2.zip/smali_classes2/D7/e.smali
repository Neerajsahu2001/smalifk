.class public final LD7/e;
.super Ljava/lang/Object;
.source "UploadOneShotFile.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# instance fields
.field private final a:Lcom/flipkart/android/services/b;

.field private final b:Landroid/content/Context;

.field private c:Lxk/j;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/android/services/b;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lxk/k;

    invoke-direct {v0}, Lxk/k;-><init>()V

    invoke-virtual {v0}, Lxk/k;->a()Lxk/j;

    move-result-object v0

    iput-object v0, p0, LD7/e;->c:Lxk/j;

    iput-object p1, p0, LD7/e;->b:Landroid/content/Context;

    iput-object p2, p0, LD7/e;->a:Lcom/flipkart/android/services/b;

    return-void
.end method

.method static synthetic a(LD7/e;)Lcom/flipkart/android/services/b;
    .registers 1

    iget-object p0, p0, LD7/e;->a:Lcom/flipkart/android/services/b;

    return-object p0
.end method

.method static synthetic b(LD7/e;)Lxk/j;
    .registers 1

    iget-object p0, p0, LD7/e;->c:Lxk/j;

    return-object p0
.end method


# virtual methods
.method public run()V
    .registers 6

    new-instance v0, Lokhttp3/MultipartBody$Builder;

    invoke-direct {v0}, Lokhttp3/MultipartBody$Builder;-><init>()V

    sget-object v1, Lokhttp3/MultipartBody;->FORM:Lokhttp3/MediaType;

    invoke-virtual {v0, v1}, Lokhttp3/MultipartBody$Builder;->setType(Lokhttp3/MediaType;)Lokhttp3/MultipartBody$Builder;

    move-result-object v0

    new-instance v1, Lcom/flipkart/android/services/a;

    new-instance v2, Ljava/io/File;

    iget-object v3, p0, LD7/e;->a:Lcom/flipkart/android/services/b;

    invoke-interface {v3}, Lcom/flipkart/android/services/b;->getFilePath()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-interface {v3}, Lcom/flipkart/android/services/b;->getContentType()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v2, v4}, Lcom/flipkart/android/services/a;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const-string v2, "file"

    invoke-virtual {v0, v2, v2, v1}, Lokhttp3/MultipartBody$Builder;->addFormDataPart(Ljava/lang/String;Ljava/lang/String;Lokhttp3/RequestBody;)Lokhttp3/MultipartBody$Builder;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/MultipartBody$Builder;->build()Lokhttp3/MultipartBody;

    move-result-object v0

    new-instance v1, Lokhttp3/Request$Builder;

    invoke-direct {v1}, Lokhttp3/Request$Builder;-><init>()V

    invoke-interface {v3}, Lcom/flipkart/android/services/b;->getUploadUrl()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v1

    invoke-virtual {v1, v0}, Lokhttp3/Request$Builder;->put(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object v0

    invoke-interface {v3}, Lcom/flipkart/android/services/b;->getHeaders()Ljava/util/Map;

    move-result-object v1

    invoke-static {v1}, LD7/g;->getHeaders(Ljava/util/Map;)Lokhttp3/Headers;

    move-result-object v1

    invoke-virtual {v0, v1}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object v0

    instance-of v1, v0, Lokhttp3/Request$Builder;

    if-nez v1, :cond_4f

    invoke-virtual {v0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    goto :goto_53

    :cond_4f
    invoke-static {v0}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object v0

    :goto_53
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Upload File Request "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lpa/a;->debug(Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getRequestQueueHelper()Lcom/flipkart/android/init/p;

    move-result-object v1

    iget-object v2, p0, LD7/e;->b:Landroid/content/Context;

    invoke-virtual {v1, v2}, Lcom/flipkart/android/init/p;->getOkHttpClient(Landroid/content/Context;)Lokhttp3/OkHttpClient;

    move-result-object v1

    instance-of v2, v1, Lokhttp3/OkHttpClient;

    if-nez v2, :cond_77

    invoke-virtual {v1, v0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    goto :goto_7b

    :cond_77
    invoke-static {v1, v0}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->newCall(Lokhttp3/OkHttpClient;Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    :goto_7b
    new-instance v1, LD7/e$a;

    invoke-direct {v1, p0}, LD7/e$a;-><init>(LD7/e;)V

    invoke-interface {v0, v1}, Lokhttp3/Call;->enqueue(Lokhttp3/Callback;)V

    return-void
.end method
