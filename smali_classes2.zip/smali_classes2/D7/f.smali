.class public final LD7/f;
.super Ljava/lang/Object;
.source "UploadStatusRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# static fields
.field private static final c:Lokhttp3/MediaType;


# instance fields
.field private final a:Lcom/flipkart/android/utils/m1;

.field private final b:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "application/json; charset=utf-8"

    invoke-static {v0}, Lokhttp3/MediaType;->parse(Ljava/lang/String;)Lokhttp3/MediaType;

    move-result-object v0

    sput-object v0, LD7/f;->c:Lokhttp3/MediaType;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/android/utils/m1;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD7/f;->b:Landroid/content/Context;

    iput-object p2, p0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    return-void
.end method

.method private a(Lokhttp3/Response;)V
    .registers 20
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v0, p0

    invoke-virtual/range {p1 .. p1}, Lokhttp3/Response;->isSuccessful()Z

    move-result v1

    iget-object v2, v0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    if-eqz v1, :cond_45

    invoke-virtual/range {p1 .. p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v1

    if-eqz v1, :cond_19

    invoke-virtual/range {p1 .. p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v1

    goto :goto_1a

    :cond_19
    const/4 v1, 0x0

    :goto_1a
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_2e

    invoke-virtual {v2}, Lcom/flipkart/android/utils/m1;->getUploadId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Lcom/flipkart/android/utils/m1;->getClientId()Ljava/lang/String;

    move-result-object v4

    iget-object v5, v0, LD7/f;->b:Landroid/content/Context;

    invoke-virtual {v2, v5, v3, v4, v1}, Lcom/flipkart/android/utils/m1;->onChunkUploadSuccess(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_5a

    :cond_2e
    iget-object v6, v0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    invoke-virtual {v6}, Lcom/flipkart/android/utils/m1;->getUploadId()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2}, Lcom/flipkart/android/utils/m1;->getClientId()Ljava/lang/String;

    move-result-object v8

    const-string v2, "resBody is empty: "

    invoke-static {v2, v1}, Landroidx/coordinatorlayout/widget/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x0

    const/16 v9, 0xc

    invoke-virtual/range {v6 .. v11}, Lcom/flipkart/android/utils/m1;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    goto :goto_5a

    :cond_45
    iget-object v12, v0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    invoke-virtual {v12}, Lcom/flipkart/android/utils/m1;->getUploadId()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2}, Lcom/flipkart/android/utils/m1;->getClientId()Ljava/lang/String;

    move-result-object v14

    invoke-virtual/range {p1 .. p1}, Lokhttp3/Response;->message()Ljava/lang/String;

    move-result-object v16

    const/16 v17, 0x0

    const/16 v15, 0xc

    invoke-virtual/range {v12 .. v17}, Lcom/flipkart/android/utils/m1;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_5a
    return-void
.end method


# virtual methods
.method public run()V
    .registers 13

    iget-object v0, p0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    :try_start_2
    invoke-virtual {v0}, Lcom/flipkart/android/utils/m1;->getCheckSum()Ljava/lang/String;

    move-result-object v1
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_6} :catch_a6

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1f

    iget-object v3, p0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    invoke-virtual {v3}, Lcom/flipkart/android/utils/m1;->getUploadId()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Lcom/flipkart/android/utils/m1;->getClientId()Ljava/lang/String;

    move-result-object v5

    const-string v7, "Error calculating checksum while resume"

    const/4 v8, 0x0

    const/16 v6, 0x8

    invoke-virtual/range {v3 .. v8}, Lcom/flipkart/android/utils/m1;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    return-void

    :cond_1f
    iget-object v2, v0, Lcom/flipkart/android/utils/o1;->n:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_3a

    iget-object v4, p0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    invoke-virtual {v4}, Lcom/flipkart/android/utils/m1;->getUploadId()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0}, Lcom/flipkart/android/utils/m1;->getClientId()Ljava/lang/String;

    move-result-object v6

    const-string v8, "Chunk upload url is null in resume action"

    const/4 v9, 0x0

    const/16 v7, 0xd

    invoke-virtual/range {v4 .. v9}, Lcom/flipkart/android/utils/m1;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    return-void

    :cond_3a
    new-instance v3, LNa/h;

    invoke-direct {v3, v1}, LNa/h;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LD7/f;->b:Landroid/content/Context;

    invoke-static {v1}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/flipkart/android/gson/Serializer;->serialize(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    sget-object v4, LD7/f;->c:Lokhttp3/MediaType;

    invoke-static {v4, v3}, Lokhttp3/RequestBody;->create(Lokhttp3/MediaType;Ljava/lang/String;)Lokhttp3/RequestBody;

    move-result-object v3

    new-instance v4, Lokhttp3/Request$Builder;

    invoke-direct {v4}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v4, v2}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v2

    invoke-virtual {v2, v3}, Lokhttp3/Request$Builder;->post(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object v2

    invoke-virtual {v0}, Lcom/flipkart/android/utils/m1;->getHeaders()Ljava/util/Map;

    move-result-object v3

    invoke-static {v3}, LD7/g;->getHeaders(Ljava/util/Map;)Lokhttp3/Headers;

    move-result-object v3

    invoke-virtual {v2, v3}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object v2

    instance-of v3, v2, Lokhttp3/Request$Builder;

    if-nez v3, :cond_71

    invoke-virtual {v2}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v2

    goto :goto_75

    :cond_71
    invoke-static {v2}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object v2

    :goto_75
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getRequestQueueHelper()Lcom/flipkart/android/init/p;

    move-result-object v3

    invoke-virtual {v3, v1}, Lcom/flipkart/android/init/p;->getOkHttpClient(Landroid/content/Context;)Lokhttp3/OkHttpClient;

    move-result-object v1

    instance-of v3, v1, Lokhttp3/OkHttpClient;

    if-nez v3, :cond_86

    invoke-virtual {v1, v2}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v1

    goto :goto_8a

    :cond_86
    invoke-static {v1, v2}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->newCall(Lokhttp3/OkHttpClient;Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v1

    :goto_8a
    :try_start_8a
    invoke-interface {v1}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v1

    invoke-direct {p0, v1}, LD7/f;->a(Lokhttp3/Response;)V
    :try_end_91
    .catch Ljava/io/IOException; {:try_start_8a .. :try_end_91} :catch_92

    goto :goto_a5

    :catch_92
    move-exception v1

    move-object v5, v1

    invoke-virtual {v0}, Lcom/flipkart/android/utils/m1;->getUploadId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lcom/flipkart/android/utils/m1;->getClientId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/16 v3, 0xc

    invoke-virtual/range {v0 .. v5}, Lcom/flipkart/android/utils/m1;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_a5
    return-void

    :catch_a6
    move-exception v11

    iget-object v6, p0, LD7/f;->a:Lcom/flipkart/android/utils/m1;

    invoke-virtual {v6}, Lcom/flipkart/android/utils/m1;->getUploadId()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0}, Lcom/flipkart/android/utils/m1;->getClientId()Ljava/lang/String;

    move-result-object v8

    const/16 v9, 0x8

    invoke-virtual {v11}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v10

    invoke-virtual/range {v6 .. v11}, Lcom/flipkart/android/utils/m1;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method
