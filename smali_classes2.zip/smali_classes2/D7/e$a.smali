.class final LD7/e$a;
.super Ljava/lang/Object;
.source "UploadOneShotFile.java"

# interfaces
.implements Lokhttp3/Callback;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD7/e;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LD7/e;


# direct methods
.method constructor <init>(LD7/e;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD7/e$a;->a:LD7/e;

    return-void
.end method


# virtual methods
.method public onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    .registers 9

    iget-object p1, p0, LD7/e$a;->a:LD7/e;

    invoke-static {p1}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v0

    invoke-static {p1}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v1

    invoke-interface {v1}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v1

    invoke-static {p1}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object p1

    invoke-interface {p1}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x6

    const-string v4, "Error while uploading file"

    move-object v5, p2

    invoke-interface/range {v0 .. v5}, Lcom/flipkart/android/services/b;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method

.method public onResponse(Lokhttp3/Call;Lokhttp3/Response;)V
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string p1, "UploadOneShotFileUpload Complete, response received, resId "

    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    if-eqz v0, :cond_11

    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v0

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    invoke-virtual {p2}, Lokhttp3/Response;->isSuccessful()Z

    move-result v1

    iget-object v2, p0, LD7/e$a;->a:LD7/e;

    if-nez v1, :cond_54

    invoke-virtual {p2}, Lokhttp3/Response;->message()Ljava/lang/String;

    move-result-object p1

    if-eqz v0, :cond_31

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_31

    :try_start_26
    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "message"

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_31
    .catch Lorg/json/JSONException; {:try_start_26 .. :try_end_31} :catch_33

    :cond_31
    :goto_31
    move-object v7, p1

    goto :goto_39

    :catch_33
    const-string p2, "UploadOneShotFileError Processing Failed, Exception Caught "

    invoke-static {p2}, Lpa/a;->debug(Ljava/lang/String;)V

    goto :goto_31

    :goto_39
    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v3

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object p1

    invoke-interface {p1}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object p1

    invoke-interface {p1}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x6

    const/4 v8, 0x0

    invoke-interface/range {v3 .. v8}, Lcom/flipkart/android/services/b;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    goto/16 :goto_d4

    :cond_54
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "UploadOneShotFileUpload Complete, response received, Response "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lpa/a;->debug(Ljava/lang/String;)V

    :try_start_65
    invoke-static {v2}, LD7/e;->b(LD7/e;)Lxk/j;

    move-result-object p2

    const-class v1, Lcom/flipkart/mapi/model/component/data/renderables/V;

    instance-of v3, p2, Lxk/j;

    if-nez v3, :cond_77

    invoke-virtual {p2, v0, v1}, Lxk/j;->e(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p2

    goto :goto_7b

    :catch_74
    move-exception p1

    move-object v8, p1

    goto :goto_b0

    :cond_77
    invoke-static {p2, v0, v1}, Lcom/newrelic/agent/android/instrumentation/GsonInstrumentation;->fromJson(Lxk/j;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p2

    :goto_7b
    check-cast p2, Lcom/flipkart/mapi/model/component/data/renderables/V;

    invoke-virtual {p2}, Lcom/flipkart/mapi/model/component/data/renderables/V;->getResourceId()Ljava/lang/String;

    move-result-object p2

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v0

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v1

    invoke-interface {v1}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v3

    invoke-interface {v3}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v4

    invoke-interface {v4}, Lcom/flipkart/android/services/b;->getCheckSum()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v1, v3, p2, v4}, Lcom/flipkart/android/services/b;->progressCompleted(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lpa/a;->debug(Ljava/lang/String;)V
    :try_end_af
    .catch Ljava/lang/Exception; {:try_start_65 .. :try_end_af} :catch_74

    goto :goto_d4

    :goto_b0
    const-string p1, "UploadOneShotFileUpload Complete, Exception Caught "

    invoke-static {p1}, Lpa/a;->debug(Ljava/lang/String;)V

    invoke-static {v8}, Lpa/a;->printStackTrace(Ljava/lang/Throwable;)V

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object v3

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object p1

    invoke-interface {p1}, Lcom/flipkart/android/services/b;->getUploadId()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2}, LD7/e;->a(LD7/e;)Lcom/flipkart/android/services/b;

    move-result-object p1

    invoke-interface {p1}, Lcom/flipkart/android/services/b;->getClientId()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x6

    invoke-virtual {v8}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-interface/range {v3 .. v8}, Lcom/flipkart/android/services/b;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_d4
    return-void
.end method
