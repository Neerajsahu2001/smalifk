.class public final LD7/c;
.super Ljava/lang/Object;
.source "UploadChunkRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# instance fields
.field private final a:LD7/a;

.field private b:Ljava/lang/String;

.field private c:Landroid/content/Context;

.field private d:[B


# direct methods
.method public constructor <init>(LD7/a;Landroid/content/Context;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "UploadChunkRunnable"

    iput-object v0, p0, LD7/c;->b:Ljava/lang/String;

    iput-object p1, p0, LD7/c;->a:LD7/a;

    iput-object p2, p0, LD7/c;->c:Landroid/content/Context;

    invoke-interface {p1}, LD7/a;->getBytesForChunk()[B

    move-result-object p1

    iput-object p1, p0, LD7/c;->d:[B

    return-void
.end method

.method private a(Lokhttp3/Response;)V
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    if-eqz v0, :cond_f

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v0

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    invoke-virtual {p1}, Lokhttp3/Response;->isSuccessful()Z

    move-result v1

    iget-object v2, p0, LD7/c;->a:LD7/a;

    if-eqz v1, :cond_4d

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1f

    goto :goto_4d

    :cond_1f
    :try_start_1f
    iget-object v3, p0, LD7/c;->a:LD7/a;

    invoke-interface {v3}, LD7/a;->getUploadId()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2}, LD7/a;->getClientId()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v2}, LD7/a;->getEndByte()J

    move-result-wide v6

    invoke-interface {v2}, LD7/a;->getTotalBytes()J

    move-result-wide v8

    invoke-interface/range {v3 .. v9}, LD7/a;->progressStatusUpdate(Ljava/lang/String;Ljava/lang/String;JJ)V
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_34} :catch_35

    goto :goto_3f

    :catch_35
    move-exception p1

    iget-object v1, p0, LD7/c;->b:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lpa/a;->error(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3f
    invoke-interface {v2}, LD7/a;->getUploadId()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v2}, LD7/a;->getClientId()Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, LD7/c;->c:Landroid/content/Context;

    invoke-interface {v2, v3, p1, v1, v0}, LD7/a;->onChunkUploadSuccess(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_60

    :cond_4d
    :goto_4d
    iget-object v4, p0, LD7/c;->a:LD7/a;

    invoke-interface {v4}, LD7/a;->getUploadId()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v2}, LD7/a;->getClientId()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1}, Lokhttp3/Response;->message()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x0

    const/4 v7, 0x0

    invoke-interface/range {v4 .. v9}, LD7/a;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_60
    return-void
.end method


# virtual methods
.method public onFailure(Ljava/io/IOException;)V
    .registers 8

    iget-object v0, p0, LD7/c;->a:LD7/a;

    invoke-interface {v0}, LD7/a;->getUploadId()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, LD7/c;->a:LD7/a;

    invoke-interface {v2}, LD7/a;->getClientId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/4 v3, 0x0

    move-object v5, p1

    invoke-interface/range {v0 .. v5}, LD7/a;->uploadErrorReceived(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method

.method public run()V
    .registers 9

    new-instance v0, Lcom/flipkart/android/services/a;

    iget-object v1, p0, LD7/c;->a:LD7/a;

    invoke-interface {v1}, LD7/a;->getContentType()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, LD7/c;->d:[B

    invoke-direct {v0, v3, v2}, Lcom/flipkart/android/services/a;-><init>([BLjava/lang/String;)V

    new-instance v2, Lokhttp3/Request$Builder;

    invoke-direct {v2}, Lokhttp3/Request$Builder;-><init>()V

    invoke-interface {v1}, LD7/a;->getChunkUploadUrl()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v2

    invoke-virtual {v2, v0}, Lokhttp3/Request$Builder;->put(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object v0

    invoke-interface {v1}, LD7/a;->getHeaders()Ljava/util/Map;

    move-result-object v2

    :try_start_22
    invoke-interface {v1}, LD7/a;->getTotalBytes()J

    move-result-wide v4
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_26} :catch_27

    goto :goto_2d

    :catch_27
    move-exception v4

    invoke-static {v4}, Lpa/a;->printStackTrace(Ljava/lang/Throwable;)V

    const-wide/16 v4, 0x0

    :goto_2d
    invoke-static {v2}, Lokhttp3/Headers;->of(Ljava/util/Map;)Lokhttp3/Headers;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/Headers;->newBuilder()Lokhttp3/Headers$Builder;

    move-result-object v2

    array-length v3, v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const-string v6, "Content-Length"

    invoke-virtual {v2, v6, v3}, Lokhttp3/Headers$Builder;->add(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Headers$Builder;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v6, "bytes "

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {v1}, LD7/a;->getStartByte()J

    move-result-wide v6

    invoke-virtual {v3, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v6, "-"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v1}, LD7/a;->getEndByte()J

    move-result-wide v6

    invoke-virtual {v3, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "Content-Range"

    invoke-virtual {v2, v3, v1}, Lokhttp3/Headers$Builder;->add(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Headers$Builder;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/Headers$Builder;->build()Lokhttp3/Headers;

    move-result-object v1

    invoke-virtual {v0, v1}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object v0

    instance-of v1, v0, Lokhttp3/Request$Builder;

    if-nez v1, :cond_7d

    invoke-virtual {v0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    goto :goto_81

    :cond_7d
    invoke-static {v0}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object v0

    :goto_81
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getRequestQueueHelper()Lcom/flipkart/android/init/p;

    move-result-object v1

    iget-object v2, p0, LD7/c;->c:Landroid/content/Context;

    invoke-virtual {v1, v2}, Lcom/flipkart/android/init/p;->getOkHttpClient(Landroid/content/Context;)Lokhttp3/OkHttpClient;

    move-result-object v1

    instance-of v2, v1, Lokhttp3/OkHttpClient;

    if-nez v2, :cond_94

    invoke-virtual {v1, v0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    goto :goto_98

    :cond_94
    invoke-static {v1, v0}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->newCall(Lokhttp3/OkHttpClient;Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    :goto_98
    :try_start_98
    invoke-interface {v0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v0

    invoke-direct {p0, v0}, LD7/c;->a(Lokhttp3/Response;)V
    :try_end_9f
    .catch Ljava/io/IOException; {:try_start_98 .. :try_end_9f} :catch_a0

    goto :goto_a4

    :catch_a0
    move-exception v0

    invoke-virtual {p0, v0}, LD7/c;->onFailure(Ljava/io/IOException;)V

    :goto_a4
    return-void
.end method
