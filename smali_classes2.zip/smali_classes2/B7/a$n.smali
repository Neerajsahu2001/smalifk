.class final LB7/a$n;
.super Ljava/lang/Object;
.source "UltraMapiNetworkLayer.java"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB7/a;->fetchOffers(Ljava/lang/String;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;Landroid/os/CancellationSignal;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "LGh/d;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lta/a;

.field final synthetic d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

.field final synthetic e:LB7/a;


# direct methods
.method constructor <init>(LB7/a;JLjava/lang/String;Lta/a;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB7/a$n;->e:LB7/a;

    iput-wide p2, p0, LB7/a$n;->a:J

    iput-object p4, p0, LB7/a$n;->b:Ljava/lang/String;

    iput-object p5, p0, LB7/a$n;->c:Lta/a;

    iput-object p6, p0, LB7/a$n;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LGh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$n;->a:J

    sub-long v9, v0, v2

    iget-object p1, p2, Lwa/a;->d:Ljava/lang/String;

    if-eqz p1, :cond_d

    goto :goto_f

    :cond_d
    const-string p1, "Network error"

    :goto_f
    const/4 v0, -0x1

    const/4 v1, 0x2

    iget p2, p2, Lwa/a;->c:I

    if-eq p2, v0, :cond_17

    move v8, p2

    goto :goto_18

    :cond_17
    const/4 v8, 0x2

    :goto_18
    const-string v6, "offer"

    const-string v7, "2/ultra/offer/active"

    iget-object v4, p0, LB7/a$n;->e:LB7/a;

    iget-object v5, p0, LB7/a$n;->b:Ljava/lang/String;

    move-object v11, p1

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p2, p0, LB7/a$n;->e:LB7/a;

    iget-object v0, p0, LB7/a$n;->c:Lta/a;

    invoke-static {p2, v0}, LB7/a;->a(LB7/a;Lta/a;)V

    iget-object p2, p0, LB7/a$n;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    invoke-interface {p2, v1, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LGh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LGh/d;",
            ">;>;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iget-wide v3, v0, LB7/a$n;->a:J

    sub-long/2addr v1, v3

    invoke-virtual/range {p2 .. p2}, Lretrofit2/F;->b()I

    move-result v9

    const-string v12, ""

    iget-object v5, v0, LB7/a$n;->e:LB7/a;

    iget-object v6, v0, LB7/a$n;->b:Ljava/lang/String;

    const-string v7, "offer"

    const-string v8, "2/ultra/offer/active"

    move-wide v10, v1

    invoke-virtual/range {v5 .. v12}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object v3, v0, LB7/a$n;->e:LB7/a;

    iget-object v4, v0, LB7/a$n;->c:Lta/a;

    invoke-static {v3, v4}, LB7/a;->a(LB7/a;Lta/a;)V

    invoke-virtual/range {p2 .. p2}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LGe/e0;

    iget-object v3, v3, LGe/e0;->a:Ljava/lang/Object;

    check-cast v3, LGh/d;

    iget-object v4, v0, LB7/a$n;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    if-eqz v3, :cond_bd

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iget-object v2, v3, LGh/d;->f:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_3b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_8e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LGh/b;

    new-instance v15, Lcom/flipkart/ultra/container/v2/db/model/offers/Offer;

    iget-object v6, v5, LGh/b;->a:Ljava/lang/String;

    invoke-static {v6}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    iget-object v9, v5, LGh/b;->d:Ljava/lang/String;

    iget-object v10, v5, LGh/b;->g:Ljava/lang/String;

    iget-object v11, v5, LGh/b;->h:Ljava/lang/String;

    iget-object v12, v5, LGh/b;->e:Ljava/lang/String;

    iget-object v6, v5, LGh/b;->i:Ljava/lang/Double;

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v13

    iget-object v6, v5, LGh/b;->j:Ljava/lang/Double;

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v16

    iget-object v6, v5, LGh/b;->m:Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v18

    iget-object v6, v5, LGh/b;->l:Ljava/lang/String;

    move-object/from16 p1, v2

    iget-object v2, v5, LGh/b;->k:Ljava/lang/String;

    iget-object v5, v5, LGh/b;->p:Ljava/lang/String;

    move-object/from16 v19, v6

    move-object v6, v15

    move-object v0, v15

    move-wide/from16 v15, v16

    move/from16 v17, v18

    move-object/from16 v18, v19

    move-object/from16 v19, v2

    move-object/from16 v20, v5

    invoke-direct/range {v6 .. v20}, Lcom/flipkart/ultra/container/v2/db/model/offers/Offer;-><init>(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, p0

    move-object/from16 v2, p1

    goto :goto_3b

    :cond_8e
    iget-object v0, v3, LGh/d;->a:Ljava/lang/Double;

    if-eqz v0, :cond_97

    invoke-virtual {v0}, Ljava/lang/Double;->longValue()J

    move-result-wide v5

    goto :goto_99

    :cond_97
    const-wide/16 v5, 0x0

    :goto_99
    iget-object v0, v3, LGh/d;->c:Ljava/lang/Boolean;

    if-eqz v0, :cond_a3

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    move v11, v0

    goto :goto_a5

    :cond_a3
    const/4 v0, 0x0

    const/4 v11, 0x0

    :goto_a5
    new-instance v0, Lcom/flipkart/ultra/container/v2/db/model/offers/UltraOffersResponse;

    long-to-double v8, v5

    new-instance v10, Lcom/flipkart/ultra/container/v2/db/model/offers/UltraOfferList;

    invoke-direct {v10, v1}, Lcom/flipkart/ultra/container/v2/db/model/offers/UltraOfferList;-><init>(Ljava/util/ArrayList;)V

    iget-object v12, v3, LGh/d;->d:Ljava/lang/String;

    iget-object v13, v3, LGh/d;->e:Ljava/lang/String;

    move-object v7, v0

    invoke-direct/range {v7 .. v13}, Lcom/flipkart/ultra/container/v2/db/model/offers/UltraOffersResponse;-><init>(DLcom/flipkart/ultra/container/v2/db/model/offers/UltraOfferList;ZLjava/lang/String;Ljava/lang/String;)V

    const/16 v1, 0xc8

    invoke-interface {v4, v1, v0}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onSuccess(ILjava/lang/Object;)V

    move-object/from16 v0, p0

    goto :goto_d4

    :cond_bd
    const/4 v9, 0x1

    const-string v12, "Unknown response from server"

    move-object/from16 v0, p0

    iget-object v5, v0, LB7/a$n;->e:LB7/a;

    iget-object v6, v0, LB7/a$n;->b:Ljava/lang/String;

    const-string v7, "offer"

    const-string v8, "2/ultra/offer/active"

    move-wide v10, v1

    invoke-virtual/range {v5 .. v12}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    const/4 v1, 0x1

    const-string v2, "Unknown response from server"

    invoke-interface {v4, v1, v2}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    :goto_d4
    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LGh/d;",
            ">;>;)V"
        }
    .end annotation

    return-void
.end method
