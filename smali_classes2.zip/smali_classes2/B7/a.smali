.class public interface abstract Lb7/a;
.super Ljava/lang/Object;
.source "CartUpdateCallback.java"

# interfaces
.implements Lb7/c;


# virtual methods
.method public abstract synthetic isReactRunning()Z
.end method

.method public abstract onCartUpdate(Lcom/facebook/react/bridge/WritableNativeMap;)V
.end method
