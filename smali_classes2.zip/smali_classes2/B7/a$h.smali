.class final LB7/a$h;
.super Ljava/lang/Object;
.source "UltraMapiNetworkLayer.java"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB7/a;->postScopesRequest(Ljava/lang/String;Ljava/util/Collection;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;Landroid/os/CancellationSignal;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "LGh/f;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lta/a;

.field final synthetic d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

.field final synthetic e:LB7/a;


# direct methods
.method constructor <init>(LB7/a;JLjava/lang/String;Lta/a;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB7/a$h;->e:LB7/a;

    iput-wide p2, p0, LB7/a$h;->a:J

    iput-object p4, p0, LB7/a$h;->b:Ljava/lang/String;

    iput-object p5, p0, LB7/a$h;->c:Lta/a;

    iput-object p6, p0, LB7/a$h;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LGh/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$h;->a:J

    sub-long v9, v0, v2

    iget-object p1, p2, Lwa/a;->d:Ljava/lang/String;

    if-eqz p1, :cond_d

    goto :goto_f

    :cond_d
    const-string p1, "Network error"

    :goto_f
    const/4 v0, -0x1

    const/4 v1, 0x2

    iget p2, p2, Lwa/a;->c:I

    if-eq p2, v0, :cond_17

    move v8, p2

    goto :goto_18

    :cond_17
    const/4 v8, 0x2

    :goto_18
    const-string v6, "postScope"

    const-string v7, "2/ultra/scopes"

    iget-object v4, p0, LB7/a$h;->e:LB7/a;

    iget-object v5, p0, LB7/a$h;->b:Ljava/lang/String;

    move-object v11, p1

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p2, p0, LB7/a$h;->e:LB7/a;

    iget-object v0, p0, LB7/a$h;->c:Lta/a;

    invoke-static {p2, v0}, LB7/a;->a(LB7/a;Lta/a;)V

    iget-object p2, p0, LB7/a$h;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    invoke-interface {p2, v1, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LGh/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LGh/f;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$h;->a:J

    sub-long/2addr v0, v2

    invoke-virtual {p2}, Lretrofit2/F;->b()I

    move-result v8

    const-string v11, ""

    iget-object v4, p0, LB7/a$h;->e:LB7/a;

    iget-object v5, p0, LB7/a$h;->b:Ljava/lang/String;

    const-string v6, "postScope"

    const-string v7, "2/ultra/scopes"

    move-wide v9, v0

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p1, p0, LB7/a$h;->e:LB7/a;

    iget-object v2, p0, LB7/a$h;->c:Lta/a;

    invoke-static {p1, v2}, LB7/a;->a(LB7/a;Lta/a;)V

    invoke-virtual {p2}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LGe/e0;

    if-eqz p1, :cond_2d

    iget-object p1, p1, LGe/e0;->a:Ljava/lang/Object;

    check-cast p1, LGh/f;

    goto :goto_2e

    :cond_2d
    const/4 p1, 0x0

    :goto_2e
    iget-object p2, p0, LB7/a$h;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    if-eqz p1, :cond_3a

    const/16 v0, 0xc8

    iget-object p1, p1, LGh/f;->a:Ljava/lang/String;

    invoke-interface {p2, v0, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onSuccess(ILjava/lang/Object;)V

    goto :goto_4f

    :cond_3a
    const/4 v8, 0x1

    const-string v11, "Unknown response from server"

    iget-object v4, p0, LB7/a$h;->e:LB7/a;

    iget-object v5, p0, LB7/a$h;->b:Ljava/lang/String;

    const-string v6, "postScope"

    const-string v7, "2/ultra/scopes"

    move-wide v9, v0

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    const/4 p1, 0x1

    const-string v0, "Unknown response from server"

    invoke-interface {p2, p1, v0}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    :goto_4f
    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LGh/f;",
            ">;>;)V"
        }
    .end annotation

    return-void
.end method
