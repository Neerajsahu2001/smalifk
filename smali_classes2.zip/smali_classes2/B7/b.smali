.class public interface abstract Lb7/b;
.super Ljava/lang/Object;
.source "ReactEventEmitterInterface.java"


# virtual methods
.method public abstract emitReactEvent(Ljava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V
.end method

.method public abstract isReadyToEmit()Z
.end method
