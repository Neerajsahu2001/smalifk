.class public interface abstract Lb7/d;
.super Ljava/lang/Object;
.source "WishListUpdateCallback.java"

# interfaces
.implements Lb7/c;


# virtual methods
.method public abstract synthetic isReactRunning()Z
.end method

.method public abstract onWishListChange(Lcom/facebook/react/bridge/WritableNativeMap;)V
.end method
