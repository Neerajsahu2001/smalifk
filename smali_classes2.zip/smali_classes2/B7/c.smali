.class public interface abstract Lb7/c;
.super Ljava/lang/Object;
.source "ReactReadyCallback.java"


# virtual methods
.method public abstract isReactRunning()Z
.end method
