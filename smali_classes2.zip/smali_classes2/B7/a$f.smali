.class final LB7/a$f;
.super Ljava/lang/Object;
.source "UltraMapiNetworkLayer.java"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB7/a;->getScopesRequest(Ljava/lang/String;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;Landroid/os/CancellationSignal;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "LIh/f;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lta/a;

.field final synthetic d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

.field final synthetic e:LB7/a;


# direct methods
.method constructor <init>(LB7/a;JLjava/lang/String;Lta/a;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB7/a$f;->e:LB7/a;

    iput-wide p2, p0, LB7/a$f;->a:J

    iput-object p4, p0, LB7/a$f;->b:Ljava/lang/String;

    iput-object p5, p0, LB7/a$f;->c:Lta/a;

    iput-object p6, p0, LB7/a$f;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LIh/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$f;->a:J

    sub-long v9, v0, v2

    iget-object p1, p2, Lwa/a;->d:Ljava/lang/String;

    if-eqz p1, :cond_d

    goto :goto_f

    :cond_d
    const-string p1, "Network error"

    :goto_f
    const/4 v0, -0x1

    const/4 v1, 0x2

    iget p2, p2, Lwa/a;->c:I

    if-eq p2, v0, :cond_17

    move v8, p2

    goto :goto_18

    :cond_17
    const/4 v8, 0x2

    :goto_18
    const-string v6, "scope"

    const-string v7, "3/ultra/scopes"

    iget-object v4, p0, LB7/a$f;->e:LB7/a;

    iget-object v5, p0, LB7/a$f;->b:Ljava/lang/String;

    move-object v11, p1

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p2, p0, LB7/a$f;->e:LB7/a;

    iget-object v0, p0, LB7/a$f;->c:Lta/a;

    invoke-static {p2, v0}, LB7/a;->a(LB7/a;Lta/a;)V

    iget-object p2, p0, LB7/a$f;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    invoke-interface {p2, v1, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LIh/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LIh/f;",
            ">;>;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    if-eqz p2, :cond_e

    invoke-virtual/range {p2 .. p2}, Lretrofit2/F;->b()I

    move-result v3

    move v8, v3

    goto :goto_10

    :cond_e
    const/4 v3, -0x1

    const/4 v8, -0x1

    :goto_10
    iget-wide v3, v0, LB7/a$f;->a:J

    sub-long v14, v1, v3

    const-string v7, "3/ultra/scopes"

    const-string v11, ""

    iget-object v4, v0, LB7/a$f;->e:LB7/a;

    iget-object v5, v0, LB7/a$f;->b:Ljava/lang/String;

    const-string v6, "scope"

    move-wide v9, v14

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object v1, v0, LB7/a$f;->c:Lta/a;

    iget-object v2, v0, LB7/a$f;->e:LB7/a;

    invoke-static {v2, v1}, LB7/a;->a(LB7/a;Lta/a;)V

    if-eqz p2, :cond_3c

    invoke-virtual/range {p2 .. p2}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_3c

    invoke-virtual/range {p2 .. p2}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/e0;

    iget-object v1, v1, LGe/e0;->a:Ljava/lang/Object;

    check-cast v1, LIh/f;

    goto :goto_3d

    :cond_3c
    const/4 v1, 0x0

    :goto_3d
    iget-object v3, v0, LB7/a$f;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    const/4 v4, 0x1

    if-eqz v1, :cond_f9

    iget-object v5, v1, LIh/f;->b:Ljava/util/List;

    new-instance v6, Lcom/flipkart/ultra/container/v2/core/components/ScopeList;

    invoke-direct {v6}, Lcom/flipkart/ultra/container/v2/core/components/ScopeList;-><init>()V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    iput-object v7, v6, Lcom/flipkart/ultra/container/v2/core/components/ScopeList;->scopes:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_54
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_e2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LGh/l;

    new-instance v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;

    invoke-direct {v8}, Lcom/flipkart/ultra/container/v2/core/components/Scope;-><init>()V

    iget-object v9, v7, LGh/l;->a:Ljava/lang/String;

    iput-object v9, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->scope:Ljava/lang/String;

    iget-object v9, v7, LGh/l;->b:Ljava/lang/String;

    iput-object v9, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->description:Ljava/lang/String;

    iget-object v9, v7, LGh/l;->f:LGh/h;

    if-eqz v9, :cond_7e

    new-instance v9, Lcom/flipkart/ultra/container/v2/core/components/ScopeTitleMergeConfig;

    iget-object v10, v7, LGh/l;->f:LGh/h;

    iget-object v11, v10, LGh/h;->b:Ljava/lang/String;

    iget-object v10, v10, LGh/h;->a:Ljava/lang/String;

    invoke-direct {v9, v11, v10}, Lcom/flipkart/ultra/container/v2/core/components/ScopeTitleMergeConfig;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    iput-object v9, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->mergeLogic:Lcom/flipkart/ultra/container/v2/core/components/ScopeTitleMergeConfig;

    :cond_7e
    const-string v9, "SELECTED"

    iget-object v10, v7, LGh/l;->d:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8b

    iput-boolean v4, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->granted:Z

    goto :goto_9b

    :cond_8b
    const-string v9, "NOT_SELECTED"

    iget-object v10, v7, LGh/l;->d:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    const/4 v10, 0x0

    if-eqz v9, :cond_99

    iput-boolean v10, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->granted:Z

    goto :goto_9b

    :cond_99
    iput-boolean v10, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->granted:Z

    :goto_9b
    iget-object v9, v7, LGh/l;->e:LGh/w;

    if-eqz v9, :cond_d7

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v10, v9, LGh/t;

    if-eqz v10, :cond_b4

    check-cast v9, LGh/t;

    iget-object v10, v9, LGh/t;->a:Ljava/lang/String;

    iget-object v9, v9, LGh/t;->b:Ljava/lang/String;

    new-instance v11, Lcom/flipkart/ultra/container/v2/ui/form/scopevalues/FullNameScopeValue;

    invoke-direct {v11, v10, v9}, Lcom/flipkart/ultra/container/v2/ui/form/scopevalues/FullNameScopeValue;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    iput-object v11, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->value:Lcom/flipkart/ultra/container/v2/core/components/ScopeValue;

    goto :goto_d7

    :cond_b4
    instance-of v10, v9, LGh/r;

    if-eqz v10, :cond_c6

    check-cast v9, LGh/r;

    iget-boolean v10, v9, LGh/r;->c:Z

    new-instance v11, Lcom/flipkart/ultra/container/v2/ui/form/scopevalues/EmailScopeValue;

    iget-object v9, v9, LGh/r;->a:Ljava/lang/String;

    invoke-direct {v11, v9, v10}, Lcom/flipkart/ultra/container/v2/ui/form/scopevalues/EmailScopeValue;-><init>(Ljava/lang/String;Z)V

    iput-object v11, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->value:Lcom/flipkart/ultra/container/v2/core/components/ScopeValue;

    goto :goto_d7

    :cond_c6
    instance-of v10, v9, LGh/v;

    if-eqz v10, :cond_d7

    check-cast v9, LGh/v;

    iget-boolean v10, v9, LGh/v;->c:Z

    new-instance v11, Lcom/flipkart/ultra/container/v2/ui/form/scopevalues/PhoneScopeValue;

    iget-object v9, v9, LGh/v;->a:Ljava/lang/String;

    invoke-direct {v11, v9, v10}, Lcom/flipkart/ultra/container/v2/ui/form/scopevalues/PhoneScopeValue;-><init>(Ljava/lang/String;Z)V

    iput-object v11, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->value:Lcom/flipkart/ultra/container/v2/core/components/ScopeValue;

    :cond_d7
    :goto_d7
    iget-object v7, v7, LGh/l;->c:Ljava/lang/String;

    iput-object v7, v8, Lcom/flipkart/ultra/container/v2/core/components/Scope;->title:Ljava/lang/String;

    iget-object v7, v6, Lcom/flipkart/ultra/container/v2/core/components/ScopeList;->scopes:Ljava/util/List;

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_54

    :cond_e2
    new-instance v2, Lcom/flipkart/ultra/container/v2/db/model/scope/UltraScopeResponse;

    invoke-direct {v2}, Lcom/flipkart/ultra/container/v2/db/model/scope/UltraScopeResponse;-><init>()V

    iput-object v6, v2, Lcom/flipkart/ultra/container/v2/db/model/scope/UltraScopeResponse;->scopeList:Lcom/flipkart/ultra/container/v2/core/components/ScopeList;

    iget-object v1, v1, LIh/f;->a:Ljava/lang/Double;

    if-eqz v1, :cond_f3

    invoke-virtual {v1}, Ljava/lang/Double;->longValue()J

    move-result-wide v4

    iput-wide v4, v2, Lcom/flipkart/ultra/container/v2/db/model/scope/UltraScopeResponse;->ttl:J

    :cond_f3
    const/16 v1, 0xc8

    invoke-interface {v3, v1, v2}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onSuccess(ILjava/lang/Object;)V

    goto :goto_10c

    :cond_f9
    const/4 v13, 0x1

    const-string v16, "Unknown response from server"

    iget-object v9, v0, LB7/a$f;->e:LB7/a;

    iget-object v10, v0, LB7/a$f;->b:Ljava/lang/String;

    const-string v11, "scope"

    const-string v12, "3/ultra/scopes"

    invoke-virtual/range {v9 .. v16}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    const-string v1, "Unknown response from server"

    invoke-interface {v3, v4, v1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    :goto_10c
    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LIh/f;",
            ">;>;)V"
        }
    .end annotation

    return-void
.end method
