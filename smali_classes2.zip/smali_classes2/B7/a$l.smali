.class final LB7/a$l;
.super Ljava/lang/Object;
.source "UltraMapiNetworkLayer.java"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB7/a;->fetchConfig(Ljava/lang/String;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;Landroid/os/CancellationSignal;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "LHh/d;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lta/a;

.field final synthetic d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

.field final synthetic e:LB7/a;


# direct methods
.method constructor <init>(LB7/a;JLjava/lang/String;Lta/a;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB7/a$l;->e:LB7/a;

    iput-wide p2, p0, LB7/a$l;->a:J

    iput-object p4, p0, LB7/a$l;->b:Ljava/lang/String;

    iput-object p5, p0, LB7/a$l;->c:Lta/a;

    iput-object p6, p0, LB7/a$l;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LHh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$l;->a:J

    sub-long v9, v0, v2

    iget-object p1, p2, Lwa/a;->d:Ljava/lang/String;

    if-eqz p1, :cond_d

    goto :goto_f

    :cond_d
    const-string p1, "Network error"

    :goto_f
    const/4 v0, -0x1

    const/4 v1, 0x2

    iget p2, p2, Lwa/a;->c:I

    if-eq p2, v0, :cond_17

    move v8, p2

    goto :goto_18

    :cond_17
    const/4 v8, 0x2

    :goto_18
    const-string v6, "config"

    const-string v7, "2/ultra/config"

    iget-object v4, p0, LB7/a$l;->e:LB7/a;

    iget-object v5, p0, LB7/a$l;->b:Ljava/lang/String;

    move-object v11, p1

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p2, p0, LB7/a$l;->e:LB7/a;

    iget-object v0, p0, LB7/a$l;->c:Lta/a;

    invoke-static {p2, v0}, LB7/a;->a(LB7/a;Lta/a;)V

    iget-object p2, p0, LB7/a$l;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    invoke-interface {p2, v1, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LHh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LHh/d;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$l;->a:J

    sub-long/2addr v0, v2

    invoke-virtual {p2}, Lretrofit2/F;->b()I

    move-result v8

    const-string v11, ""

    iget-object v4, p0, LB7/a$l;->e:LB7/a;

    iget-object v5, p0, LB7/a$l;->b:Ljava/lang/String;

    const-string v6, "config"

    const-string v7, "2/ultra/config"

    move-wide v9, v0

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p1, p0, LB7/a$l;->e:LB7/a;

    iget-object v2, p0, LB7/a$l;->c:Lta/a;

    invoke-static {p1, v2}, LB7/a;->a(LB7/a;Lta/a;)V

    invoke-virtual {p2}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LGe/e0;

    const/4 p2, 0x0

    if-eqz p1, :cond_2e

    iget-object p1, p1, LGe/e0;->a:Ljava/lang/Object;

    check-cast p1, LHh/d;

    goto :goto_2f

    :cond_2e
    move-object p1, p2

    :goto_2f
    if-eqz p1, :cond_33

    iget-object p2, p1, LHh/d;->c:LHh/b;

    :cond_33
    iget-object v2, p0, LB7/a$l;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    const/4 v3, 0x1

    if-eqz p2, :cond_14c

    new-instance v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;

    invoke-direct {v0}, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;-><init>()V

    iget-object v1, p2, LHh/b;->b:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->logo:Ljava/lang/String;

    iget-object v1, p2, LHh/b;->k:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->title:Ljava/lang/String;

    iget-object v1, p2, LHh/b;->d:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->permittedWebViewUrl:Ljava/lang/String;

    iget-object v1, p2, LHh/b;->c:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->permittedIntentUrl:Ljava/lang/String;

    iget-object v1, p2, LHh/b;->n:Ljava/lang/Long;

    if-eqz v1, :cond_57

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    iput-wide v4, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->ttl:J

    :cond_57
    iget-object v1, p2, LHh/b;->o:Ljava/lang/Boolean;

    if-eqz v1, :cond_61

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->showOfferFlag:Z

    :cond_61
    iget-object v1, p2, LHh/b;->f:Ljava/lang/Boolean;

    if-eqz v1, :cond_6b

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->showAllPermissions:Z

    :cond_6b
    iget-object v1, p2, LHh/b;->h:Ljava/lang/Boolean;

    if-eqz v1, :cond_75

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iput-boolean v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->showBackConfirmation:Z

    :cond_75
    iget-object v1, p2, LHh/b;->a:Ljava/lang/Boolean;

    if-eqz v1, :cond_81

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_80

    goto :goto_81

    :cond_80
    const/4 v3, 0x0

    :cond_81
    :goto_81
    iput-boolean v3, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->showSplash:Z

    iget-object v1, p2, LHh/b;->e:Ljava/util/List;

    if-eqz v1, :cond_bc

    new-instance v1, Lcom/flipkart/ultra/container/v2/db/model/menu/UltraMenuItemList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-direct {v1, v3}, Lcom/flipkart/ultra/container/v2/db/model/menu/UltraMenuItemList;-><init>(Ljava/util/List;)V

    invoke-virtual {v1}, Lcom/flipkart/ultra/container/v2/db/model/menu/UltraMenuItemList;->getMenuItemList()Ljava/util/List;

    move-result-object v3

    iget-object v4, p2, LHh/b;->e:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_9b
    :goto_9b
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_ba

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LHh/h;

    if-eqz v5, :cond_9b

    iget-object v6, v5, LHh/h;->a:Ljava/lang/String;

    if-eqz v6, :cond_9b

    iget-object v5, v5, LHh/h;->b:Ljava/lang/String;

    if-eqz v5, :cond_9b

    new-instance v7, Lcom/flipkart/ultra/container/v2/db/model/menu/UltraMenuItem;

    invoke-direct {v7, v6, v5}, Lcom/flipkart/ultra/container/v2/db/model/menu/UltraMenuItem;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v3, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_9b

    :cond_ba
    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->menuItems:Lcom/flipkart/ultra/container/v2/db/model/menu/UltraMenuItemList;

    :cond_bc
    iget-object v1, p2, LHh/b;->q:Ljava/util/List;

    if-eqz v1, :cond_ce

    new-instance v1, Lcom/flipkart/ultra/container/v2/db/model/JSInterfaceWhitelist;

    new-instance v3, Ljava/util/ArrayList;

    iget-object v4, p2, LHh/b;->q:Ljava/util/List;

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {v1, v3}, Lcom/flipkart/ultra/container/v2/db/model/JSInterfaceWhitelist;-><init>(Ljava/util/ArrayList;)V

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->jsInterfaceWhitelist:Lcom/flipkart/ultra/container/v2/db/model/JSInterfaceWhitelist;

    :cond_ce
    iget-object v1, p2, LHh/b;->j:Ljava/util/List;

    if-eqz v1, :cond_119

    new-instance v1, Ljava/util/ArrayList;

    iget-object v3, p2, LHh/b;->j:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V

    iget-object v3, p2, LHh/b;->j:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_e3
    :goto_e3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_112

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LHh/j;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v5

    invoke-virtual {v5}, Lcom/flipkart/android/config/c;->isReactNativeEnabled()Z

    move-result v5

    if-nez v5, :cond_103

    const-string v5, "REACT_NATIVE"

    iget-object v6, v4, LHh/j;->a:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_e3

    :cond_103
    new-instance v5, Lcom/flipkart/ultra/container/v2/db/model/supportedplatform/SupportedPlatform;

    iget-object v6, v4, LHh/j;->a:Ljava/lang/String;

    iget-object v7, v4, LHh/j;->b:Ljava/lang/String;

    iget-object v4, v4, LHh/j;->c:Ljava/lang/String;

    invoke-direct {v5, v6, v7, v4}, Lcom/flipkart/ultra/container/v2/db/model/supportedplatform/SupportedPlatform;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_e3

    :cond_112
    new-instance v3, Lcom/flipkart/ultra/container/v2/db/model/supportedplatform/SupportedPlatformList;

    invoke-direct {v3, v1}, Lcom/flipkart/ultra/container/v2/db/model/supportedplatform/SupportedPlatformList;-><init>(Ljava/util/ArrayList;)V

    iput-object v3, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->supportedPlatformList:Lcom/flipkart/ultra/container/v2/db/model/supportedplatform/SupportedPlatformList;

    :cond_119
    if-eqz p1, :cond_12b

    iget-object v1, p1, LHh/d;->a:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->clientId:Ljava/lang/String;

    iget-object p1, p1, LHh/d;->b:LHh/f;

    if-eqz p1, :cond_12b

    iget-object v1, p1, LHh/f;->b:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->primaryPermissionText:Ljava/lang/String;

    iget-object p1, p1, LHh/f;->c:Ljava/lang/String;

    iput-object p1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->secondaryPermissionText:Ljava/lang/String;

    :cond_12b
    iget-object p1, p2, LHh/b;->g:Ljava/lang/Boolean;

    if-eqz p1, :cond_13c

    new-instance v1, Lcom/flipkart/ultra/container/v2/db/model/UltraDegrade;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iget-object v3, p2, LHh/b;->m:Ljava/lang/String;

    invoke-direct {v1, p1, v3}, Lcom/flipkart/ultra/container/v2/db/model/UltraDegrade;-><init>(ZLjava/lang/String;)V

    iput-object v1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->ultraDegrade:Lcom/flipkart/ultra/container/v2/db/model/UltraDegrade;

    :cond_13c
    iget-object p1, p2, LHh/b;->p:Ljava/lang/Boolean;

    if-eqz p1, :cond_146

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iput-boolean p1, v0, Lcom/flipkart/ultra/container/v2/db/model/config/UltraConfigResponse;->isUltraPlus:Z

    :cond_146
    const/16 p1, 0xc8

    invoke-interface {v2, p1, v0}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onSuccess(ILjava/lang/Object;)V

    goto :goto_160

    :cond_14c
    const/4 v8, 0x1

    const-string v11, "Unknown response from server"

    iget-object v4, p0, LB7/a$l;->e:LB7/a;

    iget-object v5, p0, LB7/a$l;->b:Ljava/lang/String;

    const-string v6, "config"

    const-string v7, "2/ultra/config"

    move-wide v9, v0

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    const-string p1, "Unknown response from server"

    invoke-interface {v2, v3, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    :goto_160
    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LHh/d;",
            ">;>;)V"
        }
    .end annotation

    return-void
.end method
