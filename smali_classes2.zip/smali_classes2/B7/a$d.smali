.class final LB7/a$d;
.super Ljava/lang/Object;
.source "UltraMapiNetworkLayer.java"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB7/a;->fetchCoinEarningInformation(Ljava/lang/String;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;Landroid/os/CancellationSignal;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "LIh/d;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lta/a;

.field final synthetic d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

.field final synthetic e:LB7/a;


# direct methods
.method constructor <init>(LB7/a;JLjava/lang/String;Lta/a;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB7/a$d;->e:LB7/a;

    iput-wide p2, p0, LB7/a$d;->a:J

    iput-object p4, p0, LB7/a$d;->b:Ljava/lang/String;

    iput-object p5, p0, LB7/a$d;->c:Lta/a;

    iput-object p6, p0, LB7/a$d;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LIh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$d;->a:J

    sub-long v9, v0, v2

    iget p1, p2, Lwa/a;->c:I

    const/4 v0, -0x1

    const/4 v1, 0x2

    if-eq p1, v0, :cond_10

    move v8, p1

    goto :goto_11

    :cond_10
    const/4 v8, 0x2

    :goto_11
    iget-object p1, p2, Lwa/a;->d:Ljava/lang/String;

    if-eqz p1, :cond_16

    goto :goto_18

    :cond_16
    const-string p1, "Network error"

    :goto_18
    const-string v6, "coinInfo"

    const-string v7, "4/ultra/coinEarningInfo"

    iget-object v4, p0, LB7/a$d;->e:LB7/a;

    iget-object v5, p0, LB7/a$d;->b:Ljava/lang/String;

    move-object v11, p1

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p2, p0, LB7/a$d;->e:LB7/a;

    iget-object v0, p0, LB7/a$d;->c:Lta/a;

    invoke-static {p2, v0}, LB7/a;->a(LB7/a;Lta/a;)V

    iget-object p2, p0, LB7/a$d;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    invoke-interface {p2, v1, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LIh/d;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LIh/d;",
            ">;>;)V"
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, LB7/a$d;->a:J

    sub-long/2addr v0, v2

    invoke-virtual {p2}, Lretrofit2/F;->b()I

    move-result v8

    const-string v11, ""

    iget-object v4, p0, LB7/a$d;->e:LB7/a;

    iget-object v5, p0, LB7/a$d;->b:Ljava/lang/String;

    const-string v6, "coinInfo"

    const-string v7, "4/ultra/coinEarningInfo"

    move-wide v9, v0

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    iget-object p1, p0, LB7/a$d;->e:LB7/a;

    iget-object v2, p0, LB7/a$d;->c:Lta/a;

    invoke-static {p1, v2}, LB7/a;->a(LB7/a;Lta/a;)V

    invoke-virtual {p2}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LGe/e0;

    iget-object p1, p1, LGe/e0;->a:Ljava/lang/Object;

    check-cast p1, LIh/d;

    if-eqz p1, :cond_2f

    iget-object p2, p1, LIh/d;->b:LIh/b;

    goto :goto_30

    :cond_2f
    const/4 p2, 0x0

    :goto_30
    iget-object v2, p0, LB7/a$d;->d:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    if-eqz p2, :cond_55

    iget-object v7, p2, LIh/b;->d:Ljava/util/List;

    iget-object p1, p1, LIh/d;->a:Ljava/lang/Double;

    if-eqz p1, :cond_40

    invoke-virtual {p1}, Ljava/lang/Double;->longValue()J

    move-result-wide v0

    :goto_3e
    move-wide v4, v0

    goto :goto_43

    :cond_40
    const-wide/16 v0, 0x0

    goto :goto_3e

    :goto_43
    iget-object v6, p2, LIh/b;->a:Ljava/lang/String;

    iget-object v8, p2, LIh/b;->c:Ljava/lang/String;

    iget-object v9, p2, LIh/b;->b:Ljava/lang/String;

    new-instance p1, Lcom/flipkart/ultra/container/v2/db/model/coinInfo/UltraCoinInfoResponse;

    move-object v3, p1

    invoke-direct/range {v3 .. v9}, Lcom/flipkart/ultra/container/v2/db/model/coinInfo/UltraCoinInfoResponse;-><init>(JLjava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V

    const/16 p2, 0xc8

    invoke-interface {v2, p2, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onSuccess(ILjava/lang/Object;)V

    goto :goto_6a

    :cond_55
    const/4 v8, 0x1

    const-string v11, "Unknown response from server"

    iget-object v4, p0, LB7/a$d;->e:LB7/a;

    iget-object v5, p0, LB7/a$d;->b:Ljava/lang/String;

    const-string v6, "coinInfo"

    const-string v7, "4/ultra/coinEarningInfo"

    move-wide v9, v0

    invoke-virtual/range {v4 .. v11}, LB7/a;->logApiCustomEvents(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJLjava/lang/String;)V

    const/4 p1, 0x1

    const-string p2, "Unknown response from server"

    invoke-interface {v2, p1, p2}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    :goto_6a
    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LIh/d;",
            ">;>;)V"
        }
    .end annotation

    return-void
.end method
