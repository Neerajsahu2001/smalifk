.class final LB7/a$b;
.super Ljava/lang/Object;
.source "UltraMapiNetworkLayer.java"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB7/a;->fetchTermsAndConditions(Ljava/lang/String;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;Landroid/os/CancellationSignal;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "LZg/b;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lta/a;

.field final synthetic b:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

.field final synthetic c:LB7/a;


# direct methods
.method constructor <init>(LB7/a;Lta/a;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB7/a$b;->c:LB7/a;

    iput-object p2, p0, LB7/a$b;->a:Lta/a;

    iput-object p3, p0, LB7/a$b;->b:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LZg/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    iget-object p1, p0, LB7/a$b;->c:LB7/a;

    iget-object v0, p0, LB7/a$b;->a:Lta/a;

    invoke-static {p1, v0}, LB7/a;->a(LB7/a;Lta/a;)V

    iget-object p1, p2, Lwa/a;->d:Ljava/lang/String;

    if-eqz p1, :cond_c

    goto :goto_e

    :cond_c
    const-string p1, "Network error"

    :goto_e
    iget-object p2, p0, LB7/a$b;->b:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    const/4 v0, 0x2

    invoke-interface {p2, v0, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LZg/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LZg/b;",
            ">;>;)V"
        }
    .end annotation

    iget-object p1, p0, LB7/a$b;->c:LB7/a;

    iget-object v0, p0, LB7/a$b;->a:Lta/a;

    invoke-static {p1, v0}, LB7/a;->a(LB7/a;Lta/a;)V

    invoke-virtual {p2}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LGe/e0;

    iget-object p1, p1, LGe/e0;->a:Ljava/lang/Object;

    check-cast p1, LZg/b;

    iget-object p2, p0, LB7/a$b;->b:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    if-eqz p1, :cond_24

    new-instance v0, Lcom/flipkart/ultra/container/v2/db/model/TermsAndConditions;

    iget-object v1, p1, LZg/b;->c:Ljava/lang/String;

    iget-object p1, p1, LZg/b;->d:Ljava/lang/String;

    invoke-direct {v0, v1, p1}, Lcom/flipkart/ultra/container/v2/db/model/TermsAndConditions;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/16 p1, 0xc8

    invoke-interface {p2, p1, v0}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onSuccess(ILjava/lang/Object;)V

    goto :goto_2a

    :cond_24
    const/4 p1, 0x1

    const-string v0, "Unknown response from server"

    invoke-interface {p2, p1, v0}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    :goto_2a
    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "LZg/b;",
            ">;>;)V"
        }
    .end annotation

    return-void
.end method
