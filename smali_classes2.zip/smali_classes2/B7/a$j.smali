.class final LB7/a$j;
.super Ljava/lang/Object;
.source "UltraMapiNetworkLayer.java"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB7/a;->clearPermissionsRequest(Ljava/lang/String;Ljava/util/Collection;Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;Landroid/os/CancellationSignal;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;


# direct methods
.method constructor <init>(Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB7/a$j;->a:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    iget-object p1, p2, Lwa/a;->d:Ljava/lang/String;

    if-eqz p1, :cond_5

    goto :goto_7

    :cond_5
    const-string p1, "Network error"

    :goto_7
    iget-object p2, p0, LB7/a$j;->a:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    const/4 v0, 0x2

    invoke-interface {p2, v0, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onFailure(ILjava/lang/String;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iget-object p2, p0, LB7/a$j;->a:Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;

    const/16 v0, 0xc8

    invoke-interface {p2, v0, p1}, Lcom/flipkart/ultra/container/v2/core/interfaces/NetworkResultListener;->onSuccess(ILjava/lang/Object;)V

    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    return-void
.end method
