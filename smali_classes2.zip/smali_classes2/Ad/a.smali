.class public final Lad/a;
.super Lxk/z;
.source "CartContext$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "Lad/b;",
        ">;"
    }
.end annotation


# static fields
.field public static final e:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "Lad/b;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lad/d;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lad/h;",
            ">;"
        }
    .end annotation
.end field

.field private final c:LJn/a$r;

.field private final d:LJn/a$t;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lad/b;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, Lad/a;->e:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 6

    invoke-direct {p0}, Lxk/z;-><init>()V

    const-class v0, Ljava/lang/Object;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sget-object v1, Lad/c;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Lad/a;->a:Lxk/z;

    sget-object v1, Lad/g;->b:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, Lad/a;->b:Lxk/z;

    new-instance v1, LJn/a$r;

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    new-instance v3, LJn/a$q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v2, v3}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, Lad/a;->c:LJn/a$r;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$t;

    new-instance v1, LJn/a$s;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v2, p1, v1}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, Lad/a;->d:LJn/a$t;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)Lad/b;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, Lad/b;

    invoke-direct {v0}, Lad/b;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_225

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_22a

    goto/16 :goto_133

    :sswitch_34
    const-string v2, "previousQuantity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_133

    :cond_3e
    const/16 v3, 0x13

    goto/16 :goto_133

    :sswitch_42
    const-string v2, "exchangeContextId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_133

    :cond_4c
    const/16 v3, 0x12

    goto/16 :goto_133

    :sswitch_50
    const-string v2, "parentContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_133

    :cond_5a
    const/16 v3, 0x11

    goto/16 :goto_133

    :sswitch_5e
    const-string v2, "exchangeContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_133

    :cond_68
    const/16 v3, 0x10

    goto/16 :goto_133

    :sswitch_6c
    const-string v2, "shopListItemId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_133

    :cond_76
    const/16 v3, 0xf

    goto/16 :goto_133

    :sswitch_7a
    const-string v2, "parentProductContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_133

    :cond_84
    const/16 v3, 0xe

    goto/16 :goto_133

    :sswitch_88
    const-string v2, "reverseBuyingType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_133

    :cond_92
    const/16 v3, 0xd

    goto/16 :goto_133

    :sswitch_96
    const-string v2, "assessmentContextId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_133

    :cond_a0
    const/16 v3, 0xc

    goto/16 :goto_133

    :sswitch_a4
    const-string v2, "shopId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ae

    goto/16 :goto_133

    :cond_ae
    const/16 v3, 0xb

    goto/16 :goto_133

    :sswitch_b2
    const-string v2, "vulcanDiscountApplied"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    goto/16 :goto_133

    :cond_bc
    const/16 v3, 0xa

    goto/16 :goto_133

    :sswitch_c0
    const-string v2, "productId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ca

    goto/16 :goto_133

    :cond_ca
    const/16 v3, 0x9

    goto/16 :goto_133

    :sswitch_ce
    const-string v2, "featureContext"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d8

    goto/16 :goto_133

    :cond_d8
    const/16 v3, 0x8

    goto/16 :goto_133

    :sswitch_dc
    const-string v2, "payWithEMISelected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e5

    goto :goto_133

    :cond_e5
    const/4 v3, 0x7

    goto :goto_133

    :sswitch_e7
    const-string v2, "superCoinSelected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f0

    goto :goto_133

    :cond_f0
    const/4 v3, 0x6

    goto :goto_133

    :sswitch_f2
    const-string v2, "quantity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_fb

    goto :goto_133

    :cond_fb
    const/4 v3, 0x5

    goto :goto_133

    :sswitch_fd
    const-string v2, "bottomSheetDisabled"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_106

    goto :goto_133

    :cond_106
    const/4 v3, 0x4

    goto :goto_133

    :sswitch_108
    const-string v2, "shopListId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_111

    goto :goto_133

    :cond_111
    const/4 v3, 0x3

    goto :goto_133

    :sswitch_113
    const-string v2, "offerId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11c

    goto :goto_133

    :cond_11c
    const/4 v3, 0x2

    goto :goto_133

    :sswitch_11e
    const-string v2, "selectedActions"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_127

    goto :goto_133

    :cond_127
    const/4 v3, 0x1

    goto :goto_133

    :sswitch_129
    const-string v2, "cashifyDiscountApplied"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_132

    goto :goto_133

    :cond_132
    const/4 v3, 0x0

    :goto_133
    packed-switch v3, :pswitch_data_27c

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_13b
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, Lad/b;->k:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_147
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->e:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_153
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_15f
    iget-object v1, p0, Lad/a;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lad/h;

    iput-object v1, v0, Lad/b;->h:Lad/h;

    goto/16 :goto_1d

    :pswitch_16b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->q:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_177
    iget-object v1, p0, Lad/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lad/d;

    iput-object v1, v0, Lad/b;->b:Lad/d;

    goto/16 :goto_1d

    :pswitch_183
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_18f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->i:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_19b
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->l:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1a7
    iget-boolean v1, v0, Lad/b;->d:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lad/b;->d:Z

    goto/16 :goto_1d

    :pswitch_1b1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_1bd
    iget-object v1, p0, Lad/a;->d:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, Lad/b;->t:Ljava/util/Map;

    goto/16 :goto_1d

    :pswitch_1c9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Lad/b;->n:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_1d5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Lad/b;->m:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_1e1
    iget v1, v0, Lad/b;->j:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, Lad/b;->j:I

    goto/16 :goto_1d

    :pswitch_1eb
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    iput-object v1, v0, Lad/b;->r:Ljava/lang/Boolean;

    goto/16 :goto_1d

    :pswitch_1f7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->p:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_203
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lad/b;->o:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_20f
    iget-object v1, p0, Lad/a;->c:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lad/b;->s:Ljava/util/List;

    goto/16 :goto_1d

    :pswitch_21b
    iget-boolean v1, v0, Lad/b;->c:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, Lad/b;->c:Z

    goto/16 :goto_1d

    :cond_225
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_22a
    .sparse-switch
        -0x6708ea2d -> :sswitch_129
        -0x66eb261e -> :sswitch_11e
        -0x5c510369 -> :sswitch_113
        -0x502abf11 -> :sswitch_108
        -0x4e051f70 -> :sswitch_fd
        -0x4c979b75 -> :sswitch_f2
        -0x441fb899 -> :sswitch_e7
        -0x42abf3f2 -> :sswitch_dc
        -0x422ece27 -> :sswitch_ce
        -0x3eb1a996 -> :sswitch_c0
        -0x3e47e9a7 -> :sswitch_b2
        -0x35d5014f -> :sswitch_a4
        -0x143c0d78 -> :sswitch_96
        0x26d09578 -> :sswitch_88
        0x3975c90a -> :sswitch_7a
        0x516e3562 -> :sswitch_6c
        0x51e3a20c -> :sswitch_5e
        0x55d391a5 -> :sswitch_50
        0x67835847 -> :sswitch_42
        0x6f039ca2 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_27c
    .packed-switch 0x0
        :pswitch_21b
        :pswitch_20f
        :pswitch_203
        :pswitch_1f7
        :pswitch_1eb
        :pswitch_1e1
        :pswitch_1d5
        :pswitch_1c9
        :pswitch_1bd
        :pswitch_1b1
        :pswitch_1a7
        :pswitch_19b
        :pswitch_18f
        :pswitch_183
        :pswitch_177
        :pswitch_16b
        :pswitch_15f
        :pswitch_153
        :pswitch_147
        :pswitch_13b
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lad/a;->read(LBk/a;)Lad/b;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;Lad/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "productId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "parentProductContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->b:Lad/d;

    if-eqz v0, :cond_2a

    iget-object v1, p0, Lad/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "cashifyDiscountApplied"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lad/b;->c:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "vulcanDiscountApplied"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, Lad/b;->d:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "exchangeContextId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->e:Ljava/lang/String;

    if-eqz v0, :cond_50

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_53

    :cond_50
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_53
    const-string v0, "reverseBuyingType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->f:Ljava/lang/String;

    if-eqz v0, :cond_62

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_65

    :cond_62
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_65
    const-string v0, "parentContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->g:Ljava/lang/String;

    if-eqz v0, :cond_74

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_77

    :cond_74
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_77
    const-string v0, "exchangeContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->h:Lad/h;

    if-eqz v0, :cond_86

    iget-object v1, p0, Lad/a;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_89

    :cond_86
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_89
    const-string v0, "assessmentContextId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->i:Ljava/lang/String;

    if-eqz v0, :cond_98

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_9b

    :cond_98
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_9b
    const-string v0, "quantity"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, Lad/b;->j:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "previousQuantity"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->k:Ljava/lang/Integer;

    if-eqz v0, :cond_b5

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_b8

    :cond_b5
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_b8
    const-string v0, "shopId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->l:Ljava/lang/String;

    if-eqz v0, :cond_c7

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ca

    :cond_c7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ca
    const-string v0, "superCoinSelected"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->m:Ljava/lang/Boolean;

    if-eqz v0, :cond_d9

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_dc

    :cond_d9
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_dc
    const-string v0, "payWithEMISelected"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->n:Ljava/lang/Boolean;

    if-eqz v0, :cond_eb

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ee

    :cond_eb
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ee
    const-string v0, "offerId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->o:Ljava/lang/String;

    if-eqz v0, :cond_fd

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_100

    :cond_fd
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_100
    const-string v0, "shopListId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->p:Ljava/lang/String;

    if-eqz v0, :cond_10f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_112

    :cond_10f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_112
    const-string v0, "shopListItemId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->q:Ljava/lang/String;

    if-eqz v0, :cond_121

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_124

    :cond_121
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_124
    const-string v0, "bottomSheetDisabled"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->r:Ljava/lang/Boolean;

    if-eqz v0, :cond_133

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_136

    :cond_133
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_136
    const-string v0, "selectedActions"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, Lad/b;->s:Ljava/util/List;

    if-eqz v0, :cond_14a

    iget-object v1, p0, Lad/a;->c:LJn/a$r;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v1, p1, v0}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_14d

    :cond_14a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_14d
    const-string v0, "featureContext"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, Lad/b;->t:Ljava/util/Map;

    if-eqz p2, :cond_15c

    iget-object v0, p0, Lad/a;->d:LJn/a$t;

    invoke-virtual {v0, p1, p2}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_15f

    :cond_15c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_15f
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, Lad/b;

    invoke-virtual {p0, p1, p2}, Lad/a;->write(LBk/c;Lad/b;)V

    return-void
.end method
