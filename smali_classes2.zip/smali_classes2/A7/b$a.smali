.class public final LA7/b$a;
.super Ljava/lang/Object;
.source "FKHealthSplashFragment.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LA7/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic getFRAGMENT_NAME$annotations()V
    .registers 0

    return-void
.end method


# virtual methods
.method public final newInstance()LA7/b;
    .registers 2

    new-instance v0, LA7/b;

    invoke-direct {v0}, LA7/b;-><init>()V

    return-object v0
.end method
