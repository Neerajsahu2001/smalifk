.class public final LA7/b;
.super Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;
.source "FKHealthSplashFragment.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LA7/b$a;
    }
.end annotation


# static fields
.field public static final W:LA7/b$a;


# instance fields
.field private P:Landroid/os/Handler;

.field private final Q:LA7/a;

.field private R:LM4/d;

.field private final S:Landroid/view/animation/ScaleAnimation;

.field private final T:Landroid/view/animation/ScaleAnimation;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LA7/b$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LA7/b$a;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, LA7/b;->W:LA7/b$a;

    return-void
.end method

.method public constructor <init>()V
    .registers 15

    invoke-direct {p0}, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;-><init>()V

    new-instance v0, LA7/a;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p0}, LA7/a;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, LA7/b;->Q:LA7/a;

    new-instance v0, Landroid/view/animation/ScaleAnimation;

    const/4 v7, 0x1

    const/high16 v8, 0x3f000000    # 0.5f

    const/high16 v3, 0x3f800000    # 1.0f

    const v4, 0x3f99999a    # 1.2f

    const/high16 v5, 0x3f800000    # 1.0f

    const v6, 0x3f99999a    # 1.2f

    const/4 v9, 0x1

    const/high16 v10, 0x3f000000    # 0.5f

    move-object v2, v0

    invoke-direct/range {v2 .. v10}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFIFIF)V

    const-wide/16 v1, 0x320

    invoke-virtual {v0, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    const/4 v3, -0x1

    invoke-virtual {v0, v3}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    const/4 v4, 0x2

    invoke-virtual {v0, v4}, Landroid/view/animation/Animation;->setRepeatMode(I)V

    iput-object v0, p0, LA7/b;->S:Landroid/view/animation/ScaleAnimation;

    new-instance v0, Landroid/view/animation/ScaleAnimation;

    const/4 v10, 0x1

    const/high16 v11, 0x3f000000    # 0.5f

    const/high16 v6, 0x3f800000    # 1.0f

    const v7, 0x3f4ccccd    # 0.8f

    const/high16 v8, 0x3f800000    # 1.0f

    const v9, 0x3f4ccccd    # 0.8f

    const/4 v12, 0x1

    const/high16 v13, 0x3f000000    # 0.5f

    move-object v5, v0

    invoke-direct/range {v5 .. v13}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFIFIF)V

    invoke-virtual {v0, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    invoke-virtual {v0, v3}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    invoke-virtual {v0, v4}, Landroid/view/animation/Animation;->setRepeatMode(I)V

    iput-object v0, p0, LA7/b;->T:Landroid/view/animation/ScaleAnimation;

    return-void
.end method

.method public static a(LA7/b;)V
    .registers 4

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA7/b;->R:LM4/d;

    if-eqz v0, :cond_3f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_18

    const v2, 0x7f13024b

    invoke-virtual {v1, v2}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    if-nez v1, :cond_1a

    :cond_18
    const-string v1, ""

    :cond_1a
    iget-object v0, v0, LM4/d;->e:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;->listenerProvider:Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;

    if-eqz v0, :cond_3e

    invoke-interface {v0}, Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;->getConfig()Lcom/flipkart/ultra/container/v2/db/room/entity/UltraConfigEntity;

    move-result-object v0

    if-eqz v0, :cond_3e

    iget-object p0, p0, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;->listenerProvider:Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;

    if-eqz p0, :cond_3e

    invoke-interface {p0}, Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;->getUltraAnalyticsProvider()Lcom/flipkart/ultra/container/v2/analytics/AnalyticsListenerProvider;

    move-result-object p0

    if-eqz p0, :cond_3e

    invoke-interface {p0}, Lcom/flipkart/ultra/container/v2/analytics/AnalyticsListenerProvider;->getAnalyticsListener()Lcom/flipkart/ultra/container/v2/analytics/AnalyticsEventListener;

    move-result-object p0

    if-eqz p0, :cond_3e

    iget-object v0, v0, Lcom/flipkart/ultra/container/v2/db/room/entity/UltraConfigEntity;->requestClientId:Ljava/lang/String;

    invoke-interface {p0, v0}, Lcom/flipkart/ultra/container/v2/analytics/AnalyticsEventListener;->onSplashScreenSlowLoading(Ljava/lang/String;)V

    :cond_3e
    return-void

    :cond_3f
    const-string p0, "binding"

    invoke-static {p0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public static b(LA7/b;)V
    .registers 2

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;->listenerProvider:Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;

    if-eqz p0, :cond_c

    invoke-interface {p0}, Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;->onSplashRetryClicked()V

    :cond_c
    return-void
.end method

.method private final j()V
    .registers 5

    iget-object v0, p0, LA7/b;->R:LM4/d;

    const/4 v1, 0x0

    const-string v2, "binding"

    if-eqz v0, :cond_1e

    iget-object v3, p0, LA7/b;->S:Landroid/view/animation/ScaleAnimation;

    iget-object v0, v0, LM4/d;->d:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    iget-object v0, p0, LA7/b;->R:LM4/d;

    if-eqz v0, :cond_1a

    iget-object v1, p0, LA7/b;->T:Landroid/view/animation/ScaleAnimation;

    iget-object v0, v0, LM4/d;->c:Landroid/widget/ImageView;

    invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    return-void

    :cond_1a
    invoke-static {v2}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_1e
    invoke-static {v2}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1
.end method

.method public static final newInstance()LA7/b;
    .registers 1

    sget-object v0, LA7/b;->W:LA7/b$a;

    invoke-virtual {v0}, LA7/b$a;->newInstance()LA7/b;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public bindView(Landroid/view/View;Landroid/os/Bundle;)V
    .registers 6

    const-string p2, "view"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LA7/b;->R:LM4/d;

    const/4 p2, 0x0

    const-string v0, "binding"

    if-eqz p1, :cond_4f

    iget-object p1, p1, LM4/d;->b:Landroid/widget/Button;

    const/16 v1, 0x8

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object p1, p0, LA7/b;->R:LM4/d;

    if-eqz p1, :cond_4b

    new-instance v1, Lcom/flipkart/android/customviews/h;

    const/4 v2, 0x2

    invoke-direct {v1, v2, p0}, Lcom/flipkart/android/customviews/h;-><init>(ILjava/lang/Object;)V

    iget-object p1, p1, LM4/d;->b:Landroid/widget/Button;

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, LA7/b;->R:LM4/d;

    if-eqz p1, :cond_47

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p2

    if-eqz p2, :cond_35

    const v0, 0x7f13024a

    invoke-virtual {p2, v0}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object p2

    if-nez p2, :cond_37

    :cond_35
    const-string p2, ""

    :cond_37
    iget-object p1, p1, LM4/d;->e:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-direct {p0}, LA7/b;->j()V

    iget-object p1, p0, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;->listenerProvider:Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;

    if-eqz p1, :cond_46

    invoke-interface {p1}, Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;->onSplashShown()V

    :cond_46
    return-void

    :cond_47
    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw p2

    :cond_4b
    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw p2

    :cond_4f
    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw p2
.end method

.method public getDefaultViewModelCreationExtras()LW/a;
    .registers 2

    sget-object v0, LW/a$a;->b:LW/a$a;

    return-object v0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 3

    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onCreate(Landroid/os/Bundle;)V

    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, LA7/b;->P:Landroid/os/Handler;

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 4

    const-string p3, "inflater"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p3, 0x0

    invoke-static {p1, p2, p3}, LM4/d;->inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)LM4/d;

    move-result-object p1

    const-string p2, "inflate(inflater, container, false)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LA7/b;->R:LM4/d;

    invoke-virtual {p1}, LM4/d;->getRoot()Landroid/widget/LinearLayout;

    move-result-object p1

    const-string p2, "binding.root"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1
.end method

.method public onDestroyView()V
    .registers 3

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroyView()V

    iget-object v0, p0, LA7/b;->P:Landroid/os/Handler;

    if-eqz v0, :cond_14

    iget-object v1, p0, LA7/b;->Q:LA7/a;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;->listenerProvider:Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;

    if-eqz v0, :cond_13

    invoke-interface {v0}, Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;->onSplashHidden()V

    :cond_13
    return-void

    :cond_14
    const-string v0, "handler"

    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method public updateState()V
    .registers 9

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->isVisible()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getUltraSplashSlowLoadTime()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-gtz v4, :cond_18

    const-wide/16 v0, 0x2710

    goto :goto_20

    :cond_18
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getUltraSplashSlowLoadTime()J

    move-result-wide v0

    :goto_20
    iget-object v2, p0, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;->listenerProvider:Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;

    if-eqz v2, :cond_a0

    invoke-interface {v2}, Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;->getConfig()Lcom/flipkart/ultra/container/v2/db/room/entity/UltraConfigEntity;

    move-result-object v2

    if-eqz v2, :cond_a0

    invoke-virtual {v2}, Lcom/flipkart/ultra/container/v2/db/room/entity/UltraConfigEntity;->isError()Z

    move-result v3

    const/4 v4, 0x0

    iget-object v5, p0, LA7/b;->Q:LA7/a;

    const-string v6, "handler"

    const-string v7, "binding"

    if-eqz v3, :cond_82

    iget-object v0, p0, LA7/b;->R:LM4/d;

    if-eqz v0, :cond_7e

    iget-object v0, v0, LM4/d;->d:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    iget-object v0, p0, LA7/b;->R:LM4/d;

    if-eqz v0, :cond_7a

    iget-object v0, v0, LM4/d;->c:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    iget-object v0, p0, LA7/b;->R:LM4/d;

    if-eqz v0, :cond_76

    iget-object v0, v0, LM4/d;->b:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, LA7/b;->P:Landroid/os/Handler;

    if-eqz v0, :cond_72

    invoke-virtual {v0, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lcom/flipkart/ultra/container/v2/ui/fragment/splash/AbstractUltraSplashFragment;->listenerProvider:Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;

    if-eqz v0, :cond_a0

    invoke-interface {v0}, Lcom/flipkart/ultra/container/v2/ui/callback/SplashListenerProvider;->getUltraAnalyticsProvider()Lcom/flipkart/ultra/container/v2/analytics/AnalyticsListenerProvider;

    move-result-object v0

    if-eqz v0, :cond_a0

    invoke-interface {v0}, Lcom/flipkart/ultra/container/v2/analytics/AnalyticsListenerProvider;->getAnalyticsListener()Lcom/flipkart/ultra/container/v2/analytics/AnalyticsEventListener;

    move-result-object v0

    if-eqz v0, :cond_a0

    iget-object v1, v2, Lcom/flipkart/ultra/container/v2/db/room/entity/UltraConfigEntity;->requestClientId:Ljava/lang/String;

    iget-object v2, v2, Lcom/flipkart/ultra/container/v2/db/room/entity/UltraConfigEntity;->error:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Lcom/flipkart/ultra/container/v2/analytics/AnalyticsEventListener;->onConfigError(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_a0

    :cond_72
    invoke-static {v6}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v4

    :cond_76
    invoke-static {v7}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v4

    :cond_7a
    invoke-static {v7}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v4

    :cond_7e
    invoke-static {v7}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v4

    :cond_82
    iget-object v2, p0, LA7/b;->R:LM4/d;

    if-eqz v2, :cond_9c

    iget-object v2, v2, LM4/d;->b:Landroid/widget/Button;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    invoke-direct {p0}, LA7/b;->j()V

    iget-object v2, p0, LA7/b;->P:Landroid/os/Handler;

    if-eqz v2, :cond_98

    invoke-virtual {v2, v5, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_a0

    :cond_98
    invoke-static {v6}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v4

    :cond_9c
    invoke-static {v7}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v4

    :cond_a0
    :goto_a0
    return-void
.end method
