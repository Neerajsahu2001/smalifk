.class public final LC9/e;
.super Ljava/lang/Object;
.source "TimerDelegate.kt"

# interfaces
.implements LB9/a;


# instance fields
.field private final a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

.field private b:Landroidx/media3/common/y;

.field private c:Lkotlinx/coroutines/j0;

.field private final d:LUn/e;

.field private final e:LC9/e$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;)V
    .registers 4

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "container"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LC9/e;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    new-instance p2, LC9/e$b;

    invoke-direct {p2, p1, p0}, LC9/e$b;-><init>(Landroid/content/Context;LC9/e;)V

    invoke-static {p2}, LUn/f;->b(Leo/a;)LUn/e;

    move-result-object p1

    iput-object p1, p0, LC9/e;->d:LUn/e;

    new-instance p1, LC9/e$a;

    invoke-direct {p1, p0}, LC9/e$a;-><init>(LC9/e;)V

    iput-object p1, p0, LC9/e;->e:LC9/e$a;

    return-void
.end method

.method private final a()V
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "stopTimer player = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LC9/e;->b:Landroidx/media3/common/y;

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " container = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LC9/e;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/e;->log(Ljava/lang/String;)V

    iget-object v0, p0, LC9/e;->c:Lkotlinx/coroutines/j0;

    const/4 v1, 0x0

    if-eqz v0, :cond_31

    invoke-interface {v0, v1}, Lkotlinx/coroutines/j0;->e(Ljava/util/concurrent/CancellationException;)V

    :cond_31
    iput-object v1, p0, LC9/e;->c:Lkotlinx/coroutines/j0;

    return-void
.end method

.method public static final synthetic access$getContainer$p(LC9/e;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;
    .registers 1

    iget-object p0, p0, LC9/e;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    return-object p0
.end method

.method public static final synthetic access$getPlayer$p(LC9/e;)Landroidx/media3/common/y;
    .registers 1

    iget-object p0, p0, LC9/e;->b:Landroidx/media3/common/y;

    return-object p0
.end method

.method public static final synthetic access$getTimerJob$p(LC9/e;)Lkotlinx/coroutines/j0;
    .registers 1

    iget-object p0, p0, LC9/e;->c:Lkotlinx/coroutines/j0;

    return-object p0
.end method

.method public static final access$startTimer(LC9/e;)V
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "startTimer player = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LC9/e;->b:Landroidx/media3/common/y;

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " container = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LC9/e;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/e;->log(Ljava/lang/String;)V

    iget-object v0, p0, LC9/e;->c:Lkotlinx/coroutines/j0;

    const/4 v1, 0x0

    if-eqz v0, :cond_44

    invoke-interface {v0}, Lkotlinx/coroutines/j0;->isCancelled()Z

    move-result v2

    if-nez v2, :cond_41

    invoke-interface {v0}, Lkotlinx/coroutines/j0;->isActive()Z

    move-result v2

    if-eqz v2, :cond_41

    invoke-interface {v0}, Lkotlinx/coroutines/j0;->c()Z

    move-result v2

    if-nez v2, :cond_41

    goto :goto_42

    :cond_41
    move-object v0, v1

    :goto_42
    if-nez v0, :cond_56

    :cond_44
    invoke-static {}, Lkotlinx/coroutines/S;->a()Lkotlinx/coroutines/scheduling/c;

    move-result-object v0

    invoke-static {v0}, LHj/a;->a(LXn/f;)Lkotlinx/coroutines/internal/d;

    move-result-object v0

    new-instance v2, LC9/f;

    invoke-direct {v2, p0, v1}, LC9/f;-><init>(LC9/e;LXn/d;)V

    const/4 v3, 0x3

    invoke-static {v0, v1, v2, v3}, Lkotlinx/coroutines/h;->b(Lkotlinx/coroutines/G;LXn/f$a;Leo/p;I)Lkotlinx/coroutines/j0;

    move-result-object v0

    :cond_56
    iput-object v0, p0, LC9/e;->c:Lkotlinx/coroutines/j0;

    return-void
.end method

.method public static final synthetic access$stopTimer(LC9/e;)V
    .registers 1

    invoke-direct {p0}, LC9/e;->a()V

    return-void
.end method

.method public static final access$timeTickle(LC9/e;)V
    .registers 11

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "timeTickle player = "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, p0, LC9/e;->b:Landroidx/media3/common/y;

    if-eqz v4, :cond_13

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto :goto_14

    :cond_13
    const/4 v4, 0x0

    :goto_14
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " container = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, LC9/e;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, LC9/e;->log(Ljava/lang/String;)V

    iget-object v3, p0, LC9/e;->b:Landroidx/media3/common/y;

    if-eqz v3, :cond_77

    invoke-interface {v3}, Landroidx/media3/common/y;->getDuration()J

    move-result-wide v4

    invoke-interface {v3}, Landroidx/media3/common/y;->getCurrentPosition()J

    move-result-wide v6

    sub-long/2addr v4, v6

    invoke-interface {v3}, Landroidx/media3/common/y;->getDuration()J

    move-result-wide v6

    const-wide/16 v8, 0x0

    cmp-long v3, v6, v8

    if-lez v3, :cond_77

    cmp-long v3, v4, v8

    if-lez v3, :cond_77

    const/16 v3, 0x3e8

    int-to-long v6, v3

    div-long/2addr v4, v6

    invoke-virtual {p0, v1}, LC9/e;->setVisibility(Z)V

    iget-object p0, p0, LC9/e;->d:LUn/e;

    invoke-interface {p0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/widget/TextView;

    const/16 v3, 0x3c

    int-to-long v6, v3

    div-long v8, v4, v6

    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    rem-long/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    new-array v5, v0, [Ljava/lang/Object;

    aput-object v3, v5, v2

    aput-object v4, v5, v1

    invoke-static {v5, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%02d:%02d"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_77
    return-void
.end method


# virtual methods
.method public final log(Ljava/lang/String;)V
    .registers 4

    const-string v0, "string"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Le9/a;->b:Le9/a$a;

    invoke-virtual {v0}, Le9/a$a;->getInstance()Le9/a;

    move-result-object v0

    invoke-virtual {v0}, Le9/a;->isDebug()Z

    move-result v0

    if-eqz v0, :cond_2e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " log: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "TimerDelegate"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2e
    return-void
.end method

.method public register(Landroidx/media3/common/y;)V
    .registers 4

    const-string v0, "player"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "register player = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " container = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LC9/e;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/e;->log(Ljava/lang/String;)V

    iget-object v0, p0, LC9/e;->b:Landroidx/media3/common/y;

    if-nez v0, :cond_33

    iput-object p1, p0, LC9/e;->b:Landroidx/media3/common/y;

    iget-object v0, p0, LC9/e;->e:LC9/e$a;

    invoke-interface {p1, v0}, Landroidx/media3/common/y;->t(Landroidx/media3/common/y$c;)V

    :cond_33
    return-void
.end method

.method public final setVisibility(Z)V
    .registers 6

    iget-object v0, p0, LC9/e;->d:LUn/e;

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_11

    const/4 v1, 0x1

    goto :goto_12

    :cond_11
    const/4 v1, 0x0

    :goto_12
    if-eq v1, p1, :cond_33

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "setVisibility "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, LC9/e;->log(Ljava/lang/String;)V

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz p1, :cond_2e

    goto :goto_30

    :cond_2e
    const/16 v2, 0x8

    :goto_30
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_33
    return-void
.end method

.method public unRegister()V
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "unRegister player = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LC9/e;->b:Landroidx/media3/common/y;

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " container = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LC9/e;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/e;->log(Ljava/lang/String;)V

    iget-object v0, p0, LC9/e;->d:LUn/e;

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    invoke-direct {p0}, LC9/e;->a()V

    iget-object v0, p0, LC9/e;->b:Landroidx/media3/common/y;

    if-eqz v0, :cond_40

    iget-object v1, p0, LC9/e;->e:LC9/e$a;

    invoke-interface {v0, v1}, Landroidx/media3/common/y;->o(Landroidx/media3/common/y$c;)V

    :cond_40
    const/4 v0, 0x0

    iput-object v0, p0, LC9/e;->b:Landroidx/media3/common/y;

    return-void
.end method
