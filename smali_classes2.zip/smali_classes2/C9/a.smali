.class public final LC9/a;
.super Ljava/lang/Object;
.source "BufferingDelegate.kt"

# interfaces
.implements LB9/a;


# instance fields
.field private final a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

.field private b:Landroidx/media3/common/y;

.field private final c:LUn/e;

.field private final d:LC9/a$b;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;)V
    .registers 4

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "container"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LC9/a;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    new-instance p2, LC9/a$a;

    invoke-direct {p2, p1, p0}, LC9/a$a;-><init>(Landroid/content/Context;LC9/a;)V

    invoke-static {p2}, LUn/f;->b(Leo/a;)LUn/e;

    move-result-object p1

    iput-object p1, p0, LC9/a;->c:LUn/e;

    new-instance p1, LC9/a$b;

    invoke-direct {p1, p0}, LC9/a$b;-><init>(LC9/a;)V

    iput-object p1, p0, LC9/a;->d:LC9/a$b;

    return-void
.end method

.method public static final synthetic access$getContainer$p(LC9/a;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;
    .registers 1

    iget-object p0, p0, LC9/a;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    return-object p0
.end method


# virtual methods
.method public final log(Ljava/lang/String;)V
    .registers 4

    const-string v0, "log"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Le9/a;->b:Le9/a$a;

    invoke-virtual {v0}, Le9/a$a;->getInstance()Le9/a;

    move-result-object v0

    invoke-virtual {v0}, Le9/a;->isDebug()Z

    move-result v0

    if-eqz v0, :cond_2e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " log: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "BufferingDelegate"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2e
    return-void
.end method

.method public register(Landroidx/media3/common/y;)V
    .registers 3

    const-string v0, "player"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "Buffering Loader Register"

    invoke-virtual {p0, v0}, LC9/a;->log(Ljava/lang/String;)V

    iget-object v0, p0, LC9/a;->d:LC9/a$b;

    invoke-interface {p1, v0}, Landroidx/media3/common/y;->t(Landroidx/media3/common/y$c;)V

    iput-object p1, p0, LC9/a;->b:Landroidx/media3/common/y;

    return-void
.end method

.method public final setVisibility(Z)V
    .registers 6

    iget-object v0, p0, LC9/a;->c:LUn/e;

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/ProgressBar;

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_11

    const/4 v1, 0x1

    goto :goto_12

    :cond_11
    const/4 v1, 0x0

    :goto_12
    if-eq v1, p1, :cond_33

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "BufferingLoaderVisibilityUpdated visible= "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, LC9/a;->log(Ljava/lang/String;)V

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    if-eqz p1, :cond_2e

    goto :goto_30

    :cond_2e
    const/16 v2, 0x8

    :goto_30
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_33
    return-void
.end method

.method public unRegister()V
    .registers 3

    const-string v0, "Buffering Loader Unregister"

    invoke-virtual {p0, v0}, LC9/a;->log(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, LC9/a;->setVisibility(Z)V

    iget-object v0, p0, LC9/a;->c:LUn/e;

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    iget-object v1, p0, LC9/a;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v0, p0, LC9/a;->b:Landroidx/media3/common/y;

    if-eqz v0, :cond_1f

    iget-object v1, p0, LC9/a;->d:LC9/a$b;

    invoke-interface {v0, v1}, Landroidx/media3/common/y;->o(Landroidx/media3/common/y$c;)V

    :cond_1f
    const/4 v0, 0x0

    iput-object v0, p0, LC9/a;->b:Landroidx/media3/common/y;

    return-void
.end method
