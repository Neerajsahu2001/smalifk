.class public final LC9/c;
.super Ljava/lang/Object;
.source "PlayButtonDelegate.kt"

# interfaces
.implements LB9/a;


# instance fields
.field private final a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

.field private b:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Landroid/widget/ImageView;

.field private d:Landroidx/media3/common/y;

.field private final e:LC9/c$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;Leo/a;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "container"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LC9/c;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    iput-object p3, p0, LC9/c;->b:Leo/a;

    sget p3, Le9/b;->play_button:I

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-nez v0, :cond_49

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    sget v0, Le9/c;->play_button_layout:I

    const/4 v1, 0x1

    invoke-virtual {p1, v0, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    move-object v0, p1

    check-cast v0, Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    instance-of p2, p1, Landroid/widget/FrameLayout$LayoutParams;

    if-eqz p2, :cond_39

    move-object p2, p1

    check-cast p2, Landroid/widget/FrameLayout$LayoutParams;

    goto :goto_3a

    :cond_39
    const/4 p2, 0x0

    :goto_3a
    if-nez p2, :cond_3d

    goto :goto_41

    :cond_3d
    const/16 p3, 0x11

    iput p3, p2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    :goto_41
    invoke-virtual {v0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const-string p1, "run {\n        LayoutInfl\u2026    }\n            }\n    }"

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_49
    iput-object v0, p0, LC9/c;->c:Landroid/widget/ImageView;

    new-instance p1, Lcom/flipkart/android/feeds/storypages/e;

    const/4 p2, 0x2

    invoke-direct {p1, p2, p0}, Lcom/flipkart/android/feeds/storypages/e;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 p1, 0x0

    invoke-direct {p0, p1}, LC9/c;->b(Z)V

    new-instance p1, LC9/c$a;

    invoke-direct {p1, p0}, LC9/c$a;-><init>(LC9/c;)V

    iput-object p1, p0, LC9/c;->e:LC9/c$a;

    return-void
.end method

.method public static a(LC9/c;)V
    .registers 2

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "OnClickListener"

    invoke-virtual {p0, v0}, LC9/c;->log(Ljava/lang/String;)V

    iget-object p0, p0, LC9/c;->b:Leo/a;

    if-eqz p0, :cond_11

    invoke-interface {p0}, Leo/a;->invoke()Ljava/lang/Object;

    :cond_11
    return-void
.end method

.method public static final synthetic access$updatePlayButtonVisibility(LC9/c;Z)V
    .registers 2

    invoke-direct {p0, p1}, LC9/c;->b(Z)V

    return-void
.end method

.method private final b(Z)V
    .registers 6

    iget-object v0, p0, LC9/c;->c:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_b

    const/4 v1, 0x1

    goto :goto_c

    :cond_b
    const/4 v1, 0x0

    :goto_c
    if-eq v1, p1, :cond_27

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "PlayButtonVisibilityUpdated visible= "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, LC9/c;->log(Ljava/lang/String;)V

    if-eqz p1, :cond_22

    goto :goto_24

    :cond_22
    const/16 v2, 0x8

    :goto_24
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_27
    return-void
.end method


# virtual methods
.method public final clear()V
    .registers 3

    iget-object v0, p0, LC9/c;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    iget-object v1, p0, LC9/c;->c:Landroid/widget/ImageView;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, LC9/c;->b(Z)V

    return-void
.end method

.method public final getContainer()Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;
    .registers 2

    iget-object v0, p0, LC9/c;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    return-object v0
.end method

.method public final getPlay()Leo/a;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LC9/c;->b:Leo/a;

    return-object v0
.end method

.method public final log(Ljava/lang/String;)V
    .registers 4

    const-string v0, "log"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Le9/a;->b:Le9/a$a;

    invoke-virtual {v0}, Le9/a$a;->getInstance()Le9/a;

    move-result-object v0

    invoke-virtual {v0}, Le9/a;->isDebug()Z

    move-result v0

    if-eqz v0, :cond_2e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " log: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "PlayButtonDelegate"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2e
    return-void
.end method

.method public register(Landroidx/media3/common/y;)V
    .registers 4

    const-string v0, "player"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "register player="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/c;->log(Ljava/lang/String;)V

    iget-object v0, p0, LC9/c;->e:LC9/c$a;

    invoke-interface {p1, v0}, Landroidx/media3/common/y;->t(Landroidx/media3/common/y$c;)V

    iput-object p1, p0, LC9/c;->d:Landroidx/media3/common/y;

    return-void
.end method

.method public final setPlay(Leo/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LC9/c;->b:Leo/a;

    return-void
.end method

.method public unRegister()V
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "unregister player="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LC9/c;->d:Landroidx/media3/common/y;

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/c;->log(Ljava/lang/String;)V

    const/4 v0, 0x1

    invoke-direct {p0, v0}, LC9/c;->b(Z)V

    iget-object v0, p0, LC9/c;->c:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    iget-object v0, p0, LC9/c;->d:Landroidx/media3/common/y;

    if-eqz v0, :cond_2d

    iget-object v1, p0, LC9/c;->e:LC9/c$a;

    invoke-interface {v0, v1}, Landroidx/media3/common/y;->o(Landroidx/media3/common/y$c;)V

    :cond_2d
    const/4 v0, 0x0

    iput-object v0, p0, LC9/c;->d:Landroidx/media3/common/y;

    return-void
.end method
