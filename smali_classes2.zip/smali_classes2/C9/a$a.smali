.class final LC9/a$a;
.super Lkotlin/jvm/internal/p;
.source "BufferingDelegate.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC9/a;-><init>(Landroid/content/Context;Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Landroid/widget/ProgressBar;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:LC9/a;


# direct methods
.method constructor <init>(Landroid/content/Context;LC9/a;)V
    .registers 3

    iput-object p1, p0, LC9/a$a;->a:Landroid/content/Context;

    iput-object p2, p0, LC9/a$a;->b:LC9/a;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Landroid/widget/ProgressBar;
    .registers 6

    iget-object v0, p0, LC9/a$a;->a:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Le9/c;->buffering_layout:I

    iget-object v2, p0, LC9/a$a;->b:LC9/a;

    invoke-static {v2}, LC9/a;->access$getContainer$p(LC9/a;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v3, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.widget.ProgressBar"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/widget/ProgressBar;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "Add View Container size: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v2}, LC9/a;->access$getContainer$p(LC9/a;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, LC9/a;->log(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v3, v1, Landroid/widget/FrameLayout$LayoutParams;

    if-eqz v3, :cond_3f

    move-object v3, v1

    check-cast v3, Landroid/widget/FrameLayout$LayoutParams;

    goto :goto_40

    :cond_3f
    const/4 v3, 0x0

    :goto_40
    if-nez v3, :cond_43

    goto :goto_47

    :cond_43
    const/16 v4, 0x11

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    :goto_47
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v2}, LC9/a;->access$getContainer$p(LC9/a;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, LC9/a$a;->invoke()Landroid/widget/ProgressBar;

    move-result-object v0

    return-object v0
.end method
