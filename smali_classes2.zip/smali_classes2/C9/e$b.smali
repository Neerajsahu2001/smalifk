.class final LC9/e$b;
.super Lkotlin/jvm/internal/p;
.source "TimerDelegate.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC9/e;-><init>(Landroid/content/Context;Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Landroid/widget/TextView;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:LC9/e;


# direct methods
.method constructor <init>(Landroid/content/Context;LC9/e;)V
    .registers 3

    iput-object p1, p0, LC9/e$b;->a:Landroid/content/Context;

    iput-object p2, p0, LC9/e$b;->b:LC9/e;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Landroid/widget/TextView;
    .registers 6

    iget-object v0, p0, LC9/e$b;->a:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Le9/c;->timer_view_layout:I

    iget-object v2, p0, LC9/e$b;->b:LC9/e;

    invoke-static {v2}, LC9/e;->access$getContainer$p(LC9/e;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v3, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.widget.TextView"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/widget/TextView;

    invoke-static {v2}, LC9/e;->access$getContainer$p(LC9/e;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/FrameLayout$LayoutParams;

    if-eqz v2, :cond_2d

    move-object v2, v1

    check-cast v2, Landroid/widget/FrameLayout$LayoutParams;

    goto :goto_2e

    :cond_2d
    const/4 v2, 0x0

    :goto_2e
    if-nez v2, :cond_31

    goto :goto_36

    :cond_31
    const v3, 0x800005

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    :goto_36
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, LC9/e$b;->invoke()Landroid/widget/TextView;

    move-result-object v0

    return-object v0
.end method
