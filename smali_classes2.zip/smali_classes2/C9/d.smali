.class public final LC9/d;
.super Ljava/lang/Object;
.source "ShutterDelegate.kt"

# interfaces
.implements LB9/a;


# instance fields
.field private final a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

.field private final b:Le9/a$c;

.field private final c:Landroid/widget/ImageView;

.field private d:Ljava/lang/String;

.field private e:Landroidx/media3/common/y;

.field private final f:LC9/d$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;Le9/a$c;)V
    .registers 5

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "container"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LC9/d;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    iput-object p3, p0, LC9/d;->b:Le9/a$c;

    new-instance p3, Landroid/widget/ImageView;

    invoke-direct {p3, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iput-object p3, p0, LC9/d;->c:Landroid/widget/ImageView;

    invoke-virtual {p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    sget-object p3, Le9/a;->b:Le9/a$a;

    invoke-virtual {p3}, Le9/a$a;->getInstance()Le9/a;

    move-result-object p3

    invoke-virtual {p3}, Le9/a;->isDebug()Z

    move-result p3

    if-eqz p3, :cond_3a

    new-instance p3, Landroid/widget/TextView;

    invoke-direct {p3, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p2}, Ljava/lang/Object;->hashCode()I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p3, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_3a
    new-instance p1, Ljava/lang/StringBuilder;

    const-string p3, "container "

    invoke-direct {p1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, LC9/d;->log(Ljava/lang/String;)V

    new-instance p1, LC9/d$a;

    invoke-direct {p1, p0}, LC9/d$a;-><init>(LC9/d;)V

    iput-object p1, p0, LC9/d;->f:LC9/d$a;

    return-void
.end method

.method private final a(Z)V
    .registers 6

    iget-object v0, p0, LC9/d;->c:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_b

    const/4 v1, 0x1

    goto :goto_c

    :cond_b
    const/4 v1, 0x0

    :goto_c
    if-eq v1, p1, :cond_27

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "ShutterVisibilityUpdated visible= "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, LC9/d;->log(Ljava/lang/String;)V

    if-eqz p1, :cond_22

    goto :goto_24

    :cond_22
    const/16 v2, 0x8

    :goto_24
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_27
    return-void
.end method

.method public static final synthetic access$updateShutterVisibility(LC9/d;Z)V
    .registers 2

    invoke-direct {p0, p1}, LC9/d;->a(Z)V

    return-void
.end method


# virtual methods
.method public final getContainer()Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;
    .registers 2

    iget-object v0, p0, LC9/d;->a:Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    return-object v0
.end method

.method public final log(Ljava/lang/String;)V
    .registers 4

    const-string v0, "log"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Le9/a;->b:Le9/a$a;

    invoke-virtual {v0}, Le9/a$a;->getInstance()Le9/a;

    move-result-object v0

    invoke-virtual {v0}, Le9/a;->isDebug()Z

    move-result v0

    if-eqz v0, :cond_2e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " log: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "ShutterDelegate"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2e
    return-void
.end method

.method public register(Landroidx/media3/common/y;)V
    .registers 4

    const-string v0, "player"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "register player="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/d;->log(Ljava/lang/String;)V

    iget-object v0, p0, LC9/d;->f:LC9/d$a;

    invoke-interface {p1, v0}, Landroidx/media3/common/y;->t(Landroidx/media3/common/y$c;)V

    iput-object p1, p0, LC9/d;->e:Landroidx/media3/common/y;

    return-void
.end method

.method public unRegister()V
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "unregister player="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LC9/d;->e:Landroidx/media3/common/y;

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, LC9/d;->log(Ljava/lang/String;)V

    const/4 v0, 0x1

    invoke-direct {p0, v0}, LC9/d;->a(Z)V

    iget-object v0, p0, LC9/d;->e:Landroidx/media3/common/y;

    if-eqz v0, :cond_28

    iget-object v1, p0, LC9/d;->f:LC9/d$a;

    invoke-interface {v0, v1}, Landroidx/media3/common/y;->o(Landroidx/media3/common/y$c;)V

    :cond_28
    const/4 v0, 0x0

    iput-object v0, p0, LC9/d;->e:Landroidx/media3/common/y;

    return-void
.end method

.method public final updateThumbnailUrl(Ljava/lang/String;Landroid/widget/ImageView$ScaleType;)V
    .registers 5

    const-string v0, "previewThumbnail"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "scaleType"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lvp/k;->B(Ljava/lang/CharSequence;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    if-eqz v0, :cond_28

    iget-object v0, p0, LC9/d;->d:Ljava/lang/String;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_28

    iget-object v0, p0, LC9/d;->b:Le9/a$c;

    if-eqz v0, :cond_28

    iget-object v1, p0, LC9/d;->c:Landroid/widget/ImageView;

    invoke-interface {v0, v1, p1}, Le9/a$c;->inflate(Landroid/widget/ImageView;Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    iput-object p1, p0, LC9/d;->d:Ljava/lang/String;

    :cond_28
    return-void
.end method
