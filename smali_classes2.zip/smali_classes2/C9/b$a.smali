.class public final LC9/b$a;
.super Ljava/lang/Object;
.source "LivePlayerRepairer.kt"

# interfaces
.implements Landroidx/media3/common/y$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC9/b;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:LC9/b;


# direct methods
.method constructor <init>(LC9/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC9/b$a;->a:LC9/b;

    return-void
.end method


# virtual methods
.method public bridge synthetic onAudioAttributesChanged(Landroidx/media3/common/c;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onAudioSessionIdChanged(I)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onAvailableCommandsChanged(Landroidx/media3/common/y$a;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onCues(LZ/b;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onCues(Ljava/util/List;)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onDeviceInfoChanged(Landroidx/media3/common/j;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onDeviceVolumeChanged(IZ)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onEvents(Landroidx/media3/common/y;Landroidx/media3/common/y$b;)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onIsLoadingChanged(Z)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onIsPlayingChanged(Z)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onLoadingChanged(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onMaxSeekToPreviousPositionChanged(J)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onMediaItemTransition(Landroidx/media3/common/q;I)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onMediaMetadataChanged(Landroidx/media3/common/s;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onMetadata(Landroidx/media3/common/Metadata;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPlayWhenReadyChanged(ZI)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onPlaybackParametersChanged(Landroidx/media3/common/x;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPlaybackStateChanged(I)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPlaybackSuppressionReasonChanged(I)V
    .registers 2

    return-void
.end method

.method public onPlayerError(Landroidx/media3/common/w;)V
    .registers 5

    const-string v0, "error"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget v0, p1, Landroidx/media3/common/w;->a:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, LC9/b$a;->a:LC9/b;

    invoke-virtual {v2, v1}, LC9/b;->log(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroidx/media3/common/w;->a()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, LC9/b;->log(Ljava/lang/String;)V

    const/16 p1, 0x3ea

    if-eq v0, p1, :cond_1f

    const/16 p1, 0x7d0

    if-ne v0, p1, :cond_31

    :cond_1f
    invoke-virtual {v2}, LC9/b;->getPlayer()Landroidx/media3/common/y;

    move-result-object p1

    if-eqz p1, :cond_28

    invoke-interface {p1}, Landroidx/media3/common/y;->g()V

    :cond_28
    invoke-virtual {v2}, LC9/b;->getPlayer()Landroidx/media3/common/y;

    move-result-object p1

    if-eqz p1, :cond_31

    invoke-interface {p1}, Landroidx/media3/common/y;->prepare()V

    :cond_31
    return-void
.end method

.method public bridge synthetic onPlayerErrorChanged(Landroidx/media3/common/w;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPlayerStateChanged(ZI)V
    .registers 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onPlaylistMetadataChanged(Landroidx/media3/common/s;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPositionDiscontinuity(I)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onPositionDiscontinuity(Landroidx/media3/common/y$d;Landroidx/media3/common/y$d;I)V
    .registers 4

    return-void
.end method

.method public bridge synthetic onRenderedFirstFrame()V
    .registers 1

    return-void
.end method

.method public bridge synthetic onRepeatModeChanged(I)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onSeekBackIncrementChanged(J)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onSeekForwardIncrementChanged(J)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onShuffleModeEnabledChanged(Z)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onSkipSilenceEnabledChanged(Z)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onSurfaceSizeChanged(II)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onTimelineChanged(Landroidx/media3/common/A;I)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onTrackSelectionParametersChanged(Landroidx/media3/common/TrackSelectionParameters;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onTracksChanged(Landroidx/media3/common/D;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onVideoSizeChanged(Landroidx/media3/common/H;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onVolumeChanged(F)V
    .registers 2

    return-void
.end method
