.class public final LC9/e$a;
.super Ljava/lang/Object;
.source "TimerDelegate.kt"

# interfaces
.implements Landroidx/media3/common/y$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC9/e;-><init>(Landroid/content/Context;Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:LC9/e;


# direct methods
.method constructor <init>(LC9/e;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC9/e$a;->a:LC9/e;

    return-void
.end method


# virtual methods
.method public bridge synthetic onAudioAttributesChanged(Landroidx/media3/common/c;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onAudioSessionIdChanged(I)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onAvailableCommandsChanged(Landroidx/media3/common/y$a;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onCues(LZ/b;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onCues(Ljava/util/List;)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onDeviceInfoChanged(Landroidx/media3/common/j;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onDeviceVolumeChanged(IZ)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onEvents(Landroidx/media3/common/y;Landroidx/media3/common/y$b;)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onIsLoadingChanged(Z)V
    .registers 2

    return-void
.end method

.method public onIsPlayingChanged(Z)V
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "onIsPlayingChanged isPlaying = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, " player = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LC9/e$a;->a:LC9/e;

    invoke-static {v1}, LC9/e;->access$getPlayer$p(LC9/e;)Landroidx/media3/common/y;

    move-result-object v2

    if-eqz v2, :cond_1c

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    goto :goto_1d

    :cond_1c
    const/4 v2, 0x0

    :goto_1d
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " container = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1}, LC9/e;->access$getContainer$p(LC9/e;)Lcom/flipkart/chitrahar/viewHolder/BaseVideoViewHolder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, LC9/e;->log(Ljava/lang/String;)V

    if-eqz p1, :cond_3d

    invoke-static {v1}, LC9/e;->access$startTimer(LC9/e;)V

    goto :goto_40

    :cond_3d
    invoke-static {v1}, LC9/e;->access$stopTimer(LC9/e;)V

    :goto_40
    return-void
.end method

.method public bridge synthetic onLoadingChanged(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onMaxSeekToPreviousPositionChanged(J)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onMediaItemTransition(Landroidx/media3/common/q;I)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onMediaMetadataChanged(Landroidx/media3/common/s;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onMetadata(Landroidx/media3/common/Metadata;)V
    .registers 2

    return-void
.end method

.method public onPlayWhenReadyChanged(ZI)V
    .registers 4

    iget-object p2, p0, LC9/e$a;->a:LC9/e;

    if-eqz p1, :cond_14

    invoke-static {p2}, LC9/e;->access$getPlayer$p(LC9/e;)Landroidx/media3/common/y;

    move-result-object p1

    if-eqz p1, :cond_14

    invoke-interface {p1}, Landroidx/media3/common/y;->P()I

    move-result p1

    const/4 v0, 0x3

    if-ne p1, v0, :cond_14

    invoke-static {p2}, LC9/e;->access$startTimer(LC9/e;)V

    :cond_14
    invoke-static {p2}, LC9/e;->access$timeTickle(LC9/e;)V

    return-void
.end method

.method public bridge synthetic onPlaybackParametersChanged(Landroidx/media3/common/x;)V
    .registers 2

    return-void
.end method

.method public onPlaybackStateChanged(I)V
    .registers 4

    const/4 v0, 0x3

    iget-object v1, p0, LC9/e$a;->a:LC9/e;

    if-ne p1, v0, :cond_15

    invoke-static {v1}, LC9/e;->access$getPlayer$p(LC9/e;)Landroidx/media3/common/y;

    move-result-object p1

    if-eqz p1, :cond_15

    invoke-interface {p1}, Landroidx/media3/common/y;->B()Z

    move-result p1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_15

    invoke-static {v1}, LC9/e;->access$startTimer(LC9/e;)V

    :cond_15
    invoke-static {v1}, LC9/e;->access$timeTickle(LC9/e;)V

    return-void
.end method

.method public bridge synthetic onPlaybackSuppressionReasonChanged(I)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPlayerError(Landroidx/media3/common/w;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPlayerErrorChanged(Landroidx/media3/common/w;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPlayerStateChanged(ZI)V
    .registers 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onPlaylistMetadataChanged(Landroidx/media3/common/s;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onPositionDiscontinuity(I)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public bridge synthetic onPositionDiscontinuity(Landroidx/media3/common/y$d;Landroidx/media3/common/y$d;I)V
    .registers 4

    return-void
.end method

.method public bridge synthetic onRenderedFirstFrame()V
    .registers 1

    return-void
.end method

.method public bridge synthetic onRepeatModeChanged(I)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onSeekBackIncrementChanged(J)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onSeekForwardIncrementChanged(J)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onShuffleModeEnabledChanged(Z)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onSkipSilenceEnabledChanged(Z)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onSurfaceSizeChanged(II)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onTimelineChanged(Landroidx/media3/common/A;I)V
    .registers 3

    return-void
.end method

.method public bridge synthetic onTrackSelectionParametersChanged(Landroidx/media3/common/TrackSelectionParameters;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onTracksChanged(Landroidx/media3/common/D;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onVideoSizeChanged(Landroidx/media3/common/H;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onVolumeChanged(F)V
    .registers 2

    return-void
.end method
