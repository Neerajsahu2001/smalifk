.class final LC9/f$a;
.super Lkotlin/coroutines/jvm/internal/i;
.source "TimerDelegate.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC9/f;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.chitrahar.viewHolder.controllers.impl.TimerDelegate$startTimer$2$1"
    f = "TimerDelegate.kt"
    l = {}
    m = "invokeSuspend"
.end annotation


# instance fields
.field final synthetic a:LC9/e;


# direct methods
.method constructor <init>(LC9/e;LXn/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LC9/e;",
            "LXn/d<",
            "-",
            "LC9/f$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LC9/f$a;->a:LC9/e;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LC9/f$a;

    iget-object v0, p0, LC9/f$a;->a:LC9/e;

    invoke-direct {p1, v0, p2}, LC9/f$a;-><init>(LC9/e;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LC9/f$a;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LC9/f$a;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LC9/f$a;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LC9/f$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LC9/f$a;->a:LC9/e;

    invoke-static {p1}, LC9/e;->access$timeTickle(LC9/e;)V

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
