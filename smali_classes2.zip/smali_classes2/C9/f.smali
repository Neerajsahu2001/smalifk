.class final LC9/f;
.super Lkotlin/coroutines/jvm/internal/i;
.source "TimerDelegate.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.chitrahar.viewHolder.controllers.impl.TimerDelegate$startTimer$2"
    f = "TimerDelegate.kt"
    l = {
        0x44,
        0x47
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field final synthetic b:LC9/e;


# direct methods
.method constructor <init>(LC9/e;LXn/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LC9/e;",
            "LXn/d<",
            "-",
            "LC9/f;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LC9/f;->b:LC9/e;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LC9/f;

    iget-object v0, p0, LC9/f;->b:LC9/e;

    invoke-direct {p1, v0, p2}, LC9/f;-><init>(LC9/e;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LC9/f;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LC9/f;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LC9/f;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LC9/f;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LC9/f;->a:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_19

    if-eq v1, v3, :cond_15

    if-ne v1, v2, :cond_d

    goto :goto_19

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_43

    :cond_19
    :goto_19
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    :cond_1c
    iget-object p1, p0, LC9/f;->b:LC9/e;

    invoke-static {p1}, LC9/e;->access$getPlayer$p(LC9/e;)Landroidx/media3/common/y;

    move-result-object v1

    if-eqz v1, :cond_4e

    invoke-static {p1}, LC9/e;->access$getTimerJob$p(LC9/e;)Lkotlinx/coroutines/j0;

    move-result-object v1

    if-eqz v1, :cond_4e

    invoke-interface {v1}, Lkotlinx/coroutines/j0;->isCancelled()Z

    move-result v1

    if-nez v1, :cond_4e

    sget v1, Lkotlinx/coroutines/S;->c:I

    sget-object v1, Lkotlinx/coroutines/internal/n;->a:Lkotlinx/coroutines/u0;

    new-instance v4, LC9/f$a;

    const/4 v5, 0x0

    invoke-direct {v4, p1, v5}, LC9/f$a;-><init>(LC9/e;LXn/d;)V

    iput v3, p0, LC9/f;->a:I

    invoke-static {v1, v4, p0}, Lkotlinx/coroutines/h;->d(LXn/f;Leo/p;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_43

    return-object v0

    :cond_43
    :goto_43
    iput v2, p0, LC9/f;->a:I

    const-wide/16 v4, 0x3e8

    invoke-static {v4, v5, p0}, Lj3/o;->k(JLXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_1c

    return-object v0

    :cond_4e
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
