.class public final LC9/b;
.super Ljava/lang/Object;
.source "LivePlayerRepairer.kt"

# interfaces
.implements LB9/a;


# instance fields
.field private a:Landroidx/media3/common/y;

.field private final b:LC9/b$a;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LC9/b$a;

    invoke-direct {v0, p0}, LC9/b$a;-><init>(LC9/b;)V

    iput-object v0, p0, LC9/b;->b:LC9/b$a;

    return-void
.end method


# virtual methods
.method public final getPlayer()Landroidx/media3/common/y;
    .registers 2

    iget-object v0, p0, LC9/b;->a:Landroidx/media3/common/y;

    return-object v0
.end method

.method public final log(Ljava/lang/String;)V
    .registers 4

    const-string v0, "str"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Le9/a;->b:Le9/a$a;

    invoke-virtual {v0}, Le9/a$a;->getInstance()Le9/a;

    move-result-object v0

    invoke-virtual {v0}, Le9/a;->isDebug()Z

    move-result v0

    if-eqz v0, :cond_2e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " log: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "LivePlayerRepairer"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2e
    return-void
.end method

.method public register(Landroidx/media3/common/y;)V
    .registers 3

    const-string v0, "player"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LC9/b;->b:LC9/b$a;

    invoke-interface {p1, v0}, Landroidx/media3/common/y;->t(Landroidx/media3/common/y$c;)V

    iput-object p1, p0, LC9/b;->a:Landroidx/media3/common/y;

    return-void
.end method

.method public final setPlayer(Landroidx/media3/common/y;)V
    .registers 2

    iput-object p1, p0, LC9/b;->a:Landroidx/media3/common/y;

    return-void
.end method

.method public unRegister()V
    .registers 3

    iget-object v0, p0, LC9/b;->a:Landroidx/media3/common/y;

    if-eqz v0, :cond_9

    iget-object v1, p0, LC9/b;->b:LC9/b$a;

    invoke-interface {v0, v1}, Landroidx/media3/common/y;->o(Landroidx/media3/common/y$c;)V

    :cond_9
    return-void
.end method
