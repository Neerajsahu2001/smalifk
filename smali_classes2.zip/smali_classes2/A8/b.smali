.class public final La8/b;
.super Ljava/lang/Object;
.source "ErrorLoggingUtil.kt"


# static fields
.field public static final a:La8/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, La8/b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La8/b;->a:La8/b;

    return-void
.end method


# virtual methods
.method public final logError(ILjava/lang/String;Landroid/content/Context;)V
    .registers 15

    const-string v0, "context"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "flippi_error_code"

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    if-nez p2, :cond_18

    const-string v1, "unknown"

    goto :goto_19

    :cond_18
    move-object v1, p2

    :goto_19
    const-string v2, "flippi_error_msg"

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "FLIPPI_ERROR"

    invoke-static {v1, v0}, LO7/c;->logCustomEvents(Ljava/lang/String;Landroid/os/Bundle;)V

    if-eqz p1, :cond_63

    sget-object v0, Lj8/b;->a:Lj8/b;

    invoke-virtual {v0, p1}, Lj8/b;->isDmError(I)Z

    move-result v0

    if-eqz v0, :cond_38

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "FLIPPI_DM_ERROR"

    invoke-static {v1, v0}, LO7/c;->logCustomEvents(Ljava/lang/String;Landroid/os/Bundle;)V

    goto :goto_63

    :cond_38
    const/16 v0, 0xa

    if-eq p1, v0, :cond_59

    const/16 v0, 0x23

    if-eq p1, v0, :cond_56

    const/16 v0, 0x5a

    const-string v1, "FLIPPI_UNKNOWN_ERROR"

    if-eq p1, v0, :cond_5b

    packed-switch p1, :pswitch_data_9a

    packed-switch p1, :pswitch_data_a6

    goto :goto_5b

    :pswitch_4d
    const-string v1, "FLIPPI_THROTTLING_ERROR"

    goto :goto_5b

    :pswitch_50
    const-string v1, "FLIPPI_UPLOAD_ERROR"

    goto :goto_5b

    :pswitch_53
    const-string v1, "FLIPPI_AUDIO_ERROR"

    goto :goto_5b

    :cond_56
    :pswitch_56
    const-string v1, "FLIPPI_TIMEOUT_ERROR"

    goto :goto_5b

    :cond_59
    const-string v1, "FLIPPI_SDK_ERROR"

    :cond_5b
    :goto_5b
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-static {v1, v0}, LO7/c;->logCustomEvents(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_63
    :goto_63
    new-instance v0, Ljava/lang/Throwable;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Code : "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", Message : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, LO7/c;->logException(Ljava/lang/Throwable;)V

    new-instance v0, Lcom/flipkart/android/datagovernance/events/common/ClientErrorEvent;

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string v4, "Action"

    const-string v5, "Native"

    const-string v6, "Non-Fatal"

    const-string v8, "FLIPPI_ERROR"

    move-object v2, v0

    move-object v7, p2

    invoke-direct/range {v2 .. v10}, Lcom/flipkart/android/datagovernance/events/common/ClientErrorEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/flipkart/android/datagovernance/events/common/ApiErrorInfo;)V

    invoke-static {p3, v0}, La8/h;->ingestFdpEvent(Landroid/content/Context;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    return-void

    :pswitch_data_9a
    .packed-switch 0x15
        :pswitch_53
        :pswitch_53
        :pswitch_53
        :pswitch_53
    .end packed-switch

    :pswitch_data_a6
    .packed-switch 0x1f
        :pswitch_56
        :pswitch_50
        :pswitch_4d
    .end packed-switch
.end method

.method public final logError(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;Landroid/content/Context;)V
    .registers 4

    const-string v0, "context"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p1, :cond_c

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getErrNum()I

    move-result v0

    goto :goto_e

    :cond_c
    const/16 v0, 0x5a

    :goto_e
    if-eqz p1, :cond_15

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getMessage()Ljava/lang/String;

    move-result-object p1

    goto :goto_16

    :cond_15
    const/4 p1, 0x0

    :goto_16
    invoke-virtual {p0, v0, p1, p2}, La8/b;->logError(ILjava/lang/String;Landroid/content/Context;)V

    return-void
.end method

.method public final logStaticPanelShownEvent(Ljava/lang/String;)V
    .registers 4

    const-string v0, "assistantType"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "type"

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "FLIPPI_STATIC_PANEL"

    invoke-static {p1, v0}, LO7/c;->logCustomEvents(Ljava/lang/String;Landroid/os/Bundle;)V

    return-void
.end method
