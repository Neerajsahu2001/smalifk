.class public final La8/i;
.super Ljava/lang/Object;
.source "FlippiWidgetInfo.kt"


# instance fields
.field private final a:Lxk/m;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lxk/m;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    const-string v0, "slots"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/i;->a:Lxk/m;

    iput-object p2, p0, La8/i;->b:Ljava/lang/String;

    iput-object p3, p0, La8/i;->c:Ljava/lang/String;

    return-void
.end method

.method public static synthetic copy$default(La8/i;Lxk/m;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)La8/i;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget-object p1, p0, La8/i;->a:Lxk/m;

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget-object p2, p0, La8/i;->b:Ljava/lang/String;

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget-object p3, p0, La8/i;->c:Ljava/lang/String;

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, La8/i;->copy(Lxk/m;Ljava/lang/String;Ljava/lang/String;)La8/i;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Lxk/m;
    .registers 2

    iget-object v0, p0, La8/i;->a:Lxk/m;

    return-object v0
.end method

.method public final component2()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/i;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final component3()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/i;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final copy(Lxk/m;Ljava/lang/String;Ljava/lang/String;)La8/i;
    .registers 5

    const-string v0, "slots"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, La8/i;

    invoke-direct {v0, p1, p2, p3}, La8/i;-><init>(Lxk/m;Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La8/i;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La8/i;

    iget-object v1, p1, La8/i;->a:Lxk/m;

    iget-object v3, p0, La8/i;->a:Lxk/m;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, La8/i;->b:Ljava/lang/String;

    iget-object v3, p1, La8/i;->b:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-object v1, p0, La8/i;->c:Ljava/lang/String;

    iget-object p1, p1, La8/i;->c:Ljava/lang/String;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2d

    return v2

    :cond_2d
    return v0
.end method

.method public final getMarketplace()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/i;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final getPanelOpenInstanceId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/i;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final getSlots()Lxk/m;
    .registers 2

    iget-object v0, p0, La8/i;->a:Lxk/m;

    return-object v0
.end method

.method public hashCode()I
    .registers 4

    iget-object v0, p0, La8/i;->a:Lxk/m;

    invoke-virtual {v0}, Lxk/m;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v1, 0x0

    iget-object v2, p0, La8/i;->b:Ljava/lang/String;

    if-nez v2, :cond_f

    const/4 v2, 0x0

    goto :goto_13

    :cond_f
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_13
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, La8/i;->c:Ljava/lang/String;

    if-nez v2, :cond_1b

    goto :goto_1f

    :cond_1b
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v1

    :goto_1f
    add-int/2addr v0, v1

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "FlippiWidgetInfo(slots="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La8/i;->a:Lxk/m;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", marketplace="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La8/i;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", panelOpenInstanceId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La8/i;->c:Ljava/lang/String;

    const/16 v2, 0x29

    invoke-static {v0, v1, v2}, Landroidx/lifecycle/Z;->d(Ljava/lang/StringBuilder;Ljava/lang/String;C)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
