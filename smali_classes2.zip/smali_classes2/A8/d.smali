.class public final La8/d;
.super Ljava/lang/Object;
.source "FlippiController.kt"

# interfaces
.implements La8/k$a;
.implements Lcom/flipkart/android/voice/c$a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La8/d$b;,
        La8/d$c;
    }
.end annotation


# static fields
.field private static v:Ljava/lang/String;


# instance fields
.field private final a:Landroid/content/Context;

.field private b:Z

.field private final c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

.field private final d:Lb8/c;

.field private final e:Lcom/flipkart/android/gson/Serializer;

.field private f:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "La8/g;",
            ">;"
        }
    .end annotation
.end field

.field private g:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "La8/e;",
            ">;"
        }
    .end annotation
.end field

.field private h:LR7/a;

.field private i:LR7/a;

.field private j:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "La8/c;",
            ">;"
        }
    .end annotation
.end field

.field private final k:Lcom/flipkart/android/configmodel/t2;

.field private final l:Lw4/b;

.field private final m:Landroid/os/Handler;

.field private n:La8/k;

.field private o:La8/f;

.field private p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

.field private q:Lta/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lta/a<",
            "LGe/e0<",
            "Lmf/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private r:Ljava/lang/String;

.field private s:Ljava/lang/String;

.field private t:Ljava/lang/String;

.field private u:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/d$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/d$b;-><init>(Lkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;La8/c;)V
    .registers 7

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "flippiCallback"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/d;->a:Landroid/content/Context;

    new-instance v0, Landroidx/lifecycle/I;

    invoke-direct {v0}, Landroidx/lifecycle/I;-><init>()V

    iput-object v0, p0, La8/d;->f:Landroidx/lifecycle/I;

    new-instance v0, Landroidx/lifecycle/I;

    invoke-direct {v0}, Landroidx/lifecycle/I;-><init>()V

    iput-object v0, p0, La8/d;->g:Landroidx/lifecycle/I;

    new-instance v0, LR7/a;

    invoke-direct {v0}, LR7/a;-><init>()V

    iput-object v0, p0, La8/d;->h:LR7/a;

    new-instance v0, LR7/a;

    invoke-direct {v0}, LR7/a;-><init>()V

    iput-object v0, p0, La8/d;->i:LR7/a;

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v0

    iput-object v0, p0, La8/d;->k:Lcom/flipkart/android/configmodel/t2;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->getFlippiStaticPanelConfig()Lw4/b;

    move-result-object v1

    iput-object v1, p0, La8/d;->l:Lw4/b;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    instance-of v2, v2, Lcom/flipkart/android/init/FlipkartApplication;

    if-eqz v2, :cond_61

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "null cannot be cast to non-null type com.flipkart.android.init.FlipkartApplication"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Lcom/flipkart/android/init/FlipkartApplication;

    new-instance v3, Lcom/flipkart/android/voice/c;

    invoke-direct {v3, p0}, Lcom/flipkart/android/voice/c;-><init>(Lcom/flipkart/android/voice/c$a;)V

    invoke-virtual {v2, v3}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    :cond_61
    new-instance v2, Lcom/flipkart/android/gson/Serializer;

    invoke-direct {v2, p1}, Lcom/flipkart/android/gson/Serializer;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    new-instance v2, Lb8/c;

    invoke-direct {p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v3

    invoke-direct {v2, p1, v3}, Lb8/c;-><init>(Landroid/content/Context;Lcom/flipkart/android/datagovernance/NavigationContext;)V

    iput-object v2, p0, La8/d;->d:Lb8/c;

    if-eqz v0, :cond_80

    iget-boolean v2, v0, Lcom/flipkart/android/configmodel/t2;->L:Z

    if-nez v2, :cond_80

    new-instance v2, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    invoke-direct {v2, p1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    :cond_80
    new-instance v2, Lcom/flipkart/android/voice/flippi/SpeechToTextConfig;

    invoke-direct {v2, v0, p1, v1}, Lcom/flipkart/android/voice/flippi/SpeechToTextConfig;-><init>(Lcom/flipkart/android/configmodel/t2;Landroid/content/Context;Lw4/b;)V

    sget-object v1, Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;->Companion:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani$a;

    new-instance v3, La8/d$a;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v1, p1, v2, v3}, Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani$a;->getInstance(Landroid/content/Context;Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani$d;Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani$b;)Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    move-result-object p1

    iput-object p1, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    if-eqz v0, :cond_97

    iget-object p1, v0, Lcom/flipkart/android/configmodel/t2;->n:Lcom/flipkart/android/configmodel/a0;

    goto :goto_98

    :cond_97
    const/4 p1, 0x0

    :goto_98
    if-eqz p1, :cond_ac

    iget-boolean v0, p1, Lcom/flipkart/android/configmodel/a0;->a:Z

    if-eqz v0, :cond_ac

    sget-object v0, LL7/b;->a:LL7/b;

    invoke-interface {p2}, La8/c;->getContext()Landroid/content/Context;

    move-result-object p2

    const-string v1, "flippiCallback.context"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, p2, p1}, LL7/b;->init(Landroid/content/Context;Lcom/flipkart/android/configmodel/a0;)V

    :cond_ac
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, La8/d;->m:Landroid/os/Handler;

    sget-object p1, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, p1}, La8/d;->setState(La8/g;)V

    return-void
.end method

.method public static a(La8/d;Lcom/flipkart/android/voice/flippi/FlippiEvent;)V
    .registers 3

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$flippiEvent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, La8/d;->h:LR7/a;

    invoke-virtual {p0, p1}, LR7/a;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static final synthetic access$getCurrentAssistantSessionId$cp()Ljava/lang/String;
    .registers 1

    sget-object v0, La8/d;->v:Ljava/lang/String;

    return-object v0
.end method

.method public static final access$sayTts(La8/d;Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lmf/D;

    invoke-direct {v0}, Lmf/D;-><init>()V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;->getTtsText()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lmf/D;->a:Ljava/lang/String;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;->getTtsUrls()Ljava/util/List;

    move-result-object v1

    iput-object v1, v0, Lmf/D;->b:Ljava/util/List;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;->getTtsActionType()Ljava/lang/String;

    move-result-object p1

    iput-object p1, v0, Lmf/D;->c:Ljava/lang/String;

    invoke-direct {p0, v0, p2, p3}, La8/d;->g(Lmf/D;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setCurrentAssistantSessionId$cp(Ljava/lang/String;)V
    .registers 1

    sput-object p0, La8/d;->v:Ljava/lang/String;

    return-void
.end method

.method public static final access$setFlippiStateAutolisten(La8/d;ZLjava/lang/String;)V
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/flipkart/android/voice/flippi/tts/TtsActionType;->AUTO_LISTEN:Lcom/flipkart/android/voice/flippi/tts/TtsActionType;

    sget-object v1, Lb8/b;->a:Lb8/b;

    invoke-virtual {v1, p2}, Lb8/b;->parse(Ljava/lang/String;)Lcom/flipkart/android/voice/flippi/tts/TtsActionType;

    move-result-object p2

    if-ne v0, p2, :cond_24

    iput-boolean p1, p0, La8/d;->u:Z

    iget-object p1, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {p1}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->isRunning()Z

    move-result p1

    if-nez p1, :cond_24

    sget-object p1, Lcom/flipkart/android/voice/flippi/FlippiEvent;->AUTO_LISTEN:Lcom/flipkart/android/voice/flippi/FlippiEvent;

    iget-object p2, p0, La8/d;->m:Landroid/os/Handler;

    new-instance v0, Lh0/e;

    const/4 v1, 0x2

    invoke-direct {v0, p0, p1, v1}, Lh0/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_24
    return-void
.end method

.method public static b(La8/d;La8/g;)V
    .registers 3

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$state"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, La8/d;->f:Landroidx/lifecycle/I;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/I;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static c(La8/d;La8/e;)V
    .registers 3

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$state"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, La8/d;->g:Landroidx/lifecycle/I;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/I;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static d(La8/d;Lmf/D;)V
    .registers 5

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$ttsValue"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p1, Lmf/D;->c:Ljava/lang/String;

    sget-object v0, Lcom/flipkart/android/voice/flippi/tts/TtsActionType;->AUTO_LISTEN:Lcom/flipkart/android/voice/flippi/tts/TtsActionType;

    sget-object v1, Lb8/b;->a:Lb8/b;

    invoke-virtual {v1, p1}, Lb8/b;->parse(Ljava/lang/String;)Lcom/flipkart/android/voice/flippi/tts/TtsActionType;

    move-result-object p1

    if-ne v0, p1, :cond_2e

    const/4 p1, 0x0

    iput-boolean p1, p0, La8/d;->u:Z

    iget-object p1, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {p1}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->isRunning()Z

    move-result p1

    if-nez p1, :cond_2e

    sget-object p1, Lcom/flipkart/android/voice/flippi/FlippiEvent;->AUTO_LISTEN:Lcom/flipkart/android/voice/flippi/FlippiEvent;

    iget-object v0, p0, La8/d;->m:Landroid/os/Handler;

    new-instance v1, Lh0/e;

    const/4 v2, 0x2

    invoke-direct {v1, p0, p1, v2}, Lh0/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2e
    return-void
.end method

.method private final e(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;ZLa8/l;)V
    .registers 20

    move-object/from16 v0, p0

    sget-object v1, La8/a;->a:La8/a;

    move-object/from16 v2, p1

    invoke-virtual {v1, v2}, La8/a;->setAssistPayload(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;)V

    invoke-virtual/range {p1 .. p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getAction()Lxk/s;

    move-result-object v1

    invoke-virtual {v1}, Lxk/p;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v2, v0, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    invoke-virtual {v2, v1}, Lcom/flipkart/android/gson/Serializer;->deserializeAction(Ljava/lang/String;)Lcom/flipkart/mapi/model/component/data/renderables/b;

    move-result-object v1

    if-eqz v1, :cond_1e2

    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v3, "eVar51"

    invoke-interface {v2, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_54

    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v4, "eVar61"

    invoke-interface {v2, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_54

    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const-string v4, "null cannot be cast to non-null type kotlin.String"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/lang/String;

    iget-object v5, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-interface {v5, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ljava/lang/String;

    invoke-static {v2, v3}, LS3/x;->setProductFindingMethod(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct/range {p0 .. p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v3

    iget-object v4, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->g:Lab/b;

    iget-object v4, v4, Lab/b;->w:Ljava/lang/String;

    invoke-static {v3, v2, v4}, Lj8/a;->setGranularFindingMethod(Lcom/flipkart/android/datagovernance/NavigationContext;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_5b

    :cond_54
    const-string v2, "DiscoveryAssistant"

    const-string v3, "Search"

    invoke-static {v2, v3}, LS3/x;->setProductFindingMethod(Ljava/lang/String;Ljava/lang/String;)V

    :goto_5b
    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v3, "it.params"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lj8/a;->setTrackingParams(Ljava/util/Map;)V

    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v4, "assistantActionType"

    invoke-interface {v2, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x1

    if-eqz v2, :cond_87

    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "navigation"

    invoke-static {v2, v4, v5}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    invoke-static {}, Lj8/a;->getTrackingParams()Ljava/util/HashMap;

    move-result-object v4

    invoke-static {v4, v2}, LS3/x;->iterateAndSetAssistantTrackingParams(Ljava/util/Map;Z)V

    :cond_87
    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "IsAssistantQuery"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const-string v4, ""

    if-nez v2, :cond_97

    move-object v2, v4

    :cond_97
    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v2

    iget-object v6, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-static {v6, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "at"

    invoke-interface {v6, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_ab

    move-object v6, v4

    :cond_ab
    check-cast v6, Ljava/lang/String;

    iget-object v8, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-static {v8, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v9, "isSearchQuery"

    invoke-interface {v8, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    if-nez v8, :cond_bb

    move-object v8, v4

    :cond_bb
    check-cast v8, Ljava/lang/String;

    invoke-static {v8}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v8

    iget-object v9, v0, La8/d;->a:Landroid/content/Context;

    if-nez v8, :cond_d3

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v8

    invoke-virtual {v8}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v8

    if-eqz v8, :cond_e3

    iget-boolean v8, v8, Lcom/flipkart/android/configmodel/t2;->C:Z

    if-ne v8, v5, :cond_e3

    :cond_d3
    new-instance v5, Lcom/flipkart/android/datagovernance/events/search/SearchClick;

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->generateImpressionId()Ljava/lang/String;

    move-result-object v8

    const-string v10, "Voice"

    const-string v11, "TEXT"

    invoke-direct {v5, v11, v8, v10}, Lcom/flipkart/android/datagovernance/events/search/SearchClick;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v9, v5}, La8/h;->ingestFdpEvent(Landroid/content/Context;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    :cond_e3
    invoke-static {}, Lcom/flipkart/android/utils/r;->getSQID()Ljava/lang/String;

    move-result-object v5

    iget-object v8, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v10, "sqid"

    if-eqz v8, :cond_f9

    invoke-interface {v8, v10, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v11, "pageUID"

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->generateImpressionId()Ljava/lang/String;

    move-result-object v12

    invoke-interface {v8, v11, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_f9
    invoke-static {v1}, Lcom/flipkart/android/customwidget/k;->makeActionCompatibleWithSearchV4(Lcom/flipkart/mapi/model/component/data/renderables/b;)V

    const/4 v8, 0x0

    if-eqz v2, :cond_19f

    const-string v2, "sqId"

    invoke-static {v5, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    sget-object v3, La8/d;->v:Ljava/lang/String;

    if-nez v3, :cond_10e

    move-object v3, v4

    :cond_10e
    const-string v11, "asid"

    invoke-virtual {v2, v11, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2, v7, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {p3 .. p3}, La8/l;->getVoiceInputInstanceId()Ljava/lang/String;

    move-result-object v3

    const-string v6, "iid"

    invoke-virtual {v2, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "ua"

    const-string v6, "VoiceInput"

    invoke-virtual {v2, v3, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "q"

    invoke-virtual/range {p3 .. p3}, La8/l;->getTranscriptionText()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {p3 .. p3}, La8/l;->isAutoListen()Z

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v3

    const-string v6, "al"

    invoke-virtual {v2, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "aid"

    invoke-virtual/range {p3 .. p3}, La8/l;->getAudioId()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "fs"

    invoke-virtual/range {p3 .. p3}, La8/l;->getFlippiState()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v3, v0, La8/d;->s:Ljava/lang/String;

    if-nez v3, :cond_153

    goto :goto_154

    :cond_153
    move-object v4, v3

    :goto_154
    const-string v3, "ht"

    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-boolean v3, v0, La8/d;->u:Z

    invoke-static {v3}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v3

    const-string v4, "iqa"

    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-boolean v3, v0, La8/d;->b:Z

    invoke-static {v3}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v3

    const-string v4, "iti"

    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2, v10, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    instance-of v3, v9, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    if-eqz v3, :cond_1cc

    check-cast v9, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    invoke-interface {v9}, Lcom/flipkart/android/datagovernance/NavigationStateHolder;->getNavigationState()Lcom/flipkart/android/datagovernance/GlobalContextInfo;

    move-result-object v3

    if-eqz v3, :cond_1cc

    sget-object v4, Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent;->Companion:Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent$Companion;

    invoke-virtual {v4, v2}, Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent$Companion;->construct(Ljava/util/Map;)Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent;

    move-result-object v2

    if-eqz v2, :cond_1cc

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v4

    invoke-virtual {v3}, Lcom/flipkart/android/datagovernance/GlobalContextInfo;->getCurrentNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v3

    if-eqz v3, :cond_19a

    invoke-virtual {v3}, Lcom/flipkart/android/datagovernance/NavigationContext;->getContextInfo()Lcom/flipkart/android/datagovernance/ContextInfo;

    move-result-object v5

    sget-object v6, La8/d;->v:Ljava/lang/String;

    invoke-virtual {v5, v6}, Lcom/flipkart/android/datagovernance/ContextInfo;->setAssistantSessionId(Ljava/lang/String;)V

    goto :goto_19b

    :cond_19a
    move-object v3, v8

    :goto_19b
    invoke-virtual {v4, v3, v2}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEvent(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    goto :goto_1cc

    :cond_19f
    iget-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "processedQuery"

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_1ad

    goto :goto_1ae

    :cond_1ad
    move-object v4, v2

    :goto_1ae
    move-object v11, v4

    check-cast v11, Ljava/lang/String;

    new-instance v2, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;

    invoke-virtual/range {p3 .. p3}, La8/l;->getAudioId()Ljava/lang/String;

    move-result-object v13

    invoke-virtual/range {p3 .. p3}, La8/l;->getTranscriptionText()Ljava/lang/String;

    move-result-object v14

    const-string v10, "AddQuery"

    const/4 v12, 0x0

    const/4 v15, 0x0

    move-object v9, v2

    invoke-direct/range {v9 .. v15}, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct/range {p0 .. p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v3

    if-eqz v3, :cond_1cc

    invoke-static {v3, v2, v1}, Lh4/a;->triggerSearchedByVoiceEvent(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;Lcom/flipkart/mapi/model/component/data/renderables/b;)V

    :cond_1cc
    :goto_1cc
    iget-object v2, v0, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La8/c;

    if-eqz v2, :cond_1e2

    new-instance v3, Lcom/flipkart/android/newmultiwidget/a;

    sget-object v4, Lcom/flipkart/android/analytics/PageTypeUtils;->Voice:Lcom/flipkart/android/analytics/PageTypeUtils;

    invoke-direct {v3, v4, v8, v8, v8}, Lcom/flipkart/android/newmultiwidget/a;-><init>(Lcom/flipkart/android/analytics/PageTypeUtils;Lcom/flipkart/android/datagovernance/utils/WidgetInfo;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/datagovernance/ContextManager;)V

    move/from16 v4, p2

    invoke-interface {v2, v1, v3, v4}, La8/c;->executeDmAction(Lcom/flipkart/mapi/model/component/data/renderables/b;Lcom/flipkart/android/newmultiwidget/a;Z)V

    :cond_1e2
    return-void
.end method

.method private final f()Lcom/flipkart/android/datagovernance/NavigationContext;
    .registers 4

    iget-object v0, p0, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La8/c;

    const/4 v1, 0x0

    if-eqz v0, :cond_10

    invoke-interface {v0}, La8/c;->getContext()Landroid/content/Context;

    move-result-object v0

    goto :goto_11

    :cond_10
    move-object v0, v1

    :goto_11
    instance-of v2, v0, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    if-eqz v2, :cond_21

    check-cast v0, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    invoke-interface {v0}, Lcom/flipkart/android/datagovernance/NavigationStateHolder;->getNavigationState()Lcom/flipkart/android/datagovernance/GlobalContextInfo;

    move-result-object v0

    if-eqz v0, :cond_21

    invoke-virtual {v0}, Lcom/flipkart/android/datagovernance/GlobalContextInfo;->getCurrentNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v1

    :cond_21
    return-object v1
.end method

.method private final g(Lmf/D;Ljava/lang/String;Ljava/lang/String;)V
    .registers 12

    iget-object v0, p1, Lmf/D;->a:Ljava/lang/String;

    iget-object v1, p1, Lmf/D;->b:Ljava/util/List;

    iget-object v2, p0, La8/d;->d:Lb8/c;

    invoke-virtual {v2, v0, p2, v1}, Lb8/c;->getTtsValidity(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    move-result-object v0

    sget-object v1, La8/d$c;->b:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_32

    const/4 p2, 0x2

    if-eq v0, p2, :cond_1a

    goto/16 :goto_88

    :cond_1a
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p3

    invoke-direct {p2, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p3, Lh0/d;

    invoke-direct {p3, p0, p1, v1}, Lh0/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    sget-object p1, La8/h;->a:La8/h;

    invoke-virtual {p1}, La8/h;->getAutoListenDelay()J

    move-result-wide v0

    invoke-virtual {p2, p3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_88

    :cond_32
    iget-object v0, p1, Lmf/D;->a:Ljava/lang/String;

    iput-object v0, p0, La8/d;->t:Ljava/lang/String;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getTtsConfig()Lcom/flipkart/android/configmodel/M1;

    move-result-object v0

    if-eqz v0, :cond_52

    iget-object v0, v0, Lcom/flipkart/android/configmodel/M1;->e:Ljava/util/Map;

    if-eqz v0, :cond_52

    invoke-interface {v0, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Boolean;

    if-eqz p3, :cond_52

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    move v1, p3

    goto :goto_54

    :cond_52
    const/4 p3, 0x0

    const/4 v1, 0x0

    :goto_54
    invoke-direct {p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v2

    invoke-direct {p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object p3

    if-eqz p3, :cond_6a

    invoke-virtual {p3}, Lcom/flipkart/android/datagovernance/NavigationContext;->getContextInfo()Lcom/flipkart/android/datagovernance/ContextInfo;

    move-result-object p3

    if-eqz p3, :cond_6a

    invoke-virtual {p3}, Lcom/flipkart/android/datagovernance/ContextInfo;->getAssistantSessionId()Ljava/lang/String;

    move-result-object p3

    :goto_68
    move-object v3, p3

    goto :goto_6c

    :cond_6a
    const/4 p3, 0x0

    goto :goto_68

    :goto_6c
    iget-object p3, p1, Lmf/D;->a:Ljava/lang/String;

    if-nez p3, :cond_72

    const-string p3, ""

    :cond_72
    move-object v5, p3

    iget-object p3, p1, Lmf/D;->b:Ljava/util/List;

    if-nez p3, :cond_7c

    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    :cond_7c
    move-object v6, p3

    new-instance v7, La8/d$e;

    invoke-direct {v7, p0, p1}, La8/d$e;-><init>(La8/d;Lmf/D;)V

    iget-object v0, p0, La8/d;->d:Lb8/c;

    move-object v4, p2

    invoke-virtual/range {v0 .. v7}, Lb8/c;->playTts(ZLcom/flipkart/android/datagovernance/NavigationContext;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Leo/a;)V

    :goto_88
    return-void
.end method


# virtual methods
.method public final attachFlippiEventObserver(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "Lcom/flipkart/android/voice/flippi/FlippiEvent;",
            ">;)V"
        }
    .end annotation

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "observer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->h:LR7/a;

    invoke-virtual {v0, p1, p2}, LR7/a;->observe(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final attachFlippiPanelStateObserver(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "La8/e;",
            ">;)V"
        }
    .end annotation

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "observer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->g:Landroidx/lifecycle/I;

    invoke-virtual {v0, p1, p2}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final attachFlippiStateObserver(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "La8/g;",
            ">;)V"
        }
    .end annotation

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "observer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->f:Landroidx/lifecycle/I;

    invoke-virtual {v0, p1, p2}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final attachFlippiWidgetObserver(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "La8/i;",
            ">;)V"
        }
    .end annotation

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "observer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->i:LR7/a;

    invoke-virtual {v0, p1, p2}, LR7/a;->observe(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final attachTtsEventListener(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "Lcom/flipkart/android/voice/flippi/tts/TtsEvent;",
            ">;)V"
        }
    .end annotation

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "observer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->d:Lb8/c;

    invoke-virtual {v0, p1, p2}, Lb8/c;->attachTtsEventListener(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final cancelAltInputCall()V
    .registers 2

    iget-object v0, p0, La8/d;->q:Lta/a;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Lta/a;->cancel()V

    :cond_7
    const/4 v0, 0x0

    iput-object v0, p0, La8/d;->q:Lta/a;

    return-void
.end method

.method public final detachFlippiEventObserver(Landroidx/lifecycle/J;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/J<",
            "Lcom/flipkart/android/voice/flippi/FlippiEvent;",
            ">;)V"
        }
    .end annotation

    const-string v0, "observer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->h:LR7/a;

    invoke-virtual {v0, p1}, LR7/a;->removeObserver(Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final detachObserver(Landroidx/lifecycle/J;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/J<",
            "La8/g;",
            ">;)V"
        }
    .end annotation

    const-string v0, "observer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->f:Landroidx/lifecycle/I;

    invoke-virtual {v0, p1}, Landroidx/lifecycle/LiveData;->removeObserver(Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final firstHandShake(Ljava/lang/String;)V
    .registers 24

    move-object/from16 v9, p0

    const-string v0, "marketplace"

    move-object/from16 v15, p1

    invoke-static {v15, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    sget-object v14, La8/b;->a:La8/b;

    iget-object v13, v9, La8/d;->a:Landroid/content/Context;

    if-eqz v0, :cond_2c

    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.voice.flippi.FlippiCallback"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, La8/c;

    invoke-interface {v0}, La8/c;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/flipkart/android/utils/A0;->checkNetworkConnectivity(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_30

    :cond_2c
    move-object v2, v13

    move-object v5, v14

    goto/16 :goto_117

    :cond_30
    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La8/c;

    const/4 v1, 0x0

    if-nez v0, :cond_3d

    :goto_3b
    move-object v0, v1

    goto :goto_48

    :cond_3d
    instance-of v2, v0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    if-nez v2, :cond_42

    goto :goto_3b

    :cond_42
    check-cast v0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    invoke-virtual {v0}, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->getCurrentScreenUri()Ljava/lang/String;

    move-result-object v0

    :goto_48
    sget-object v2, Lcom/flipkart/android/voice/FlippiRequestInfo;->Companion:Lcom/flipkart/android/voice/FlippiRequestInfo$a;

    invoke-virtual {v2}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v3

    invoke-virtual {v3, v0}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getPageRequestString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual {v2}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getConversationId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    iget-object v12, v9, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {v12}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_65

    invoke-interface {v12}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->cancelRecording()V

    :cond_65
    invoke-virtual/range {p0 .. p0}, La8/d;->stopTts()V

    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La8/c;

    const-string v2, "EN"

    if-eqz v0, :cond_82

    invoke-interface {v0}, La8/c;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_82

    invoke-static {v0}, Lcom/flipkart/android/utils/n0;->getSelectedLanguage(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_81

    goto :goto_82

    :cond_81
    move-object v2, v0

    :cond_82
    :goto_82
    move-object/from16 v18, v2

    iget-object v0, v9, La8/d;->k:Lcom/flipkart/android/configmodel/t2;

    if-eqz v0, :cond_8d

    iget-boolean v0, v0, Lcom/flipkart/android/configmodel/t2;->u:Z

    move/from16 v19, v0

    goto :goto_90

    :cond_8d
    const/4 v0, 0x0

    const/16 v19, 0x0

    :goto_90
    sget-object v10, Lj8/c;->a:Lj8/c;

    if-eqz v19, :cond_96

    :goto_94
    move-object v11, v1

    goto :goto_9b

    :cond_96
    invoke-virtual {v10}, Lj8/c;->getDefaultWebsocketParams()Ljava/util/Map;

    move-result-object v1

    goto :goto_94

    :goto_9b
    iget-object v0, v9, La8/d;->n:La8/k;

    if-eqz v0, :cond_a2

    invoke-virtual {v0}, La8/k;->reset()V

    :cond_a2
    new-instance v8, La8/k;

    iget-object v1, v9, La8/d;->m:Landroid/os/Handler;

    sget-object v4, La8/d;->v:Ljava/lang/String;

    iget-object v2, v9, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/16 v20, 0x0

    move-object v0, v8

    move-object/from16 v3, p0

    move-object/from16 v5, p1

    move-object/from16 v21, v12

    move-object v12, v8

    move/from16 v8, v20

    invoke-direct/range {v0 .. v8}, La8/k;-><init>(Landroid/os/Handler;Lcom/flipkart/android/gson/Serializer;La8/k$a;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    iput-object v12, v9, La8/d;->n:La8/k;

    invoke-virtual {v12}, La8/k;->getInstanceId()Ljava/lang/String;

    move-result-object v0

    iget-object v1, v9, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    const/4 v2, 0x1

    move-object v3, v11

    move-object v11, v1

    move-object v4, v12

    move-object/from16 v1, v21

    move v12, v2

    move-object v2, v13

    move-object/from16 v13, v18

    move-object v5, v14

    move-object/from16 v14, v16

    move-object/from16 v15, v17

    move/from16 v16, v19

    move-object/from16 v17, v0

    move-object/from16 v18, p1

    invoke-virtual/range {v10 .. v18}, Lj8/c;->getHttpParamsForFlippi(Lcom/flipkart/android/gson/Serializer;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    invoke-interface {v1, v0, v3, v4}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->sendMessage(Ljava/util/Map;Ljava/util/Map;Lcom/flipkart/android/voice/s2tlibrary/SpeechToText$a;)I

    move-result v0

    if-nez v0, :cond_ed

    sget-object v0, La8/g$d;->b:La8/g$d;

    invoke-virtual {v9, v0}, La8/d;->setState(La8/g;)V

    sget-object v0, La8/e$c;->a:La8/e$c;

    invoke-virtual {v9, v0}, La8/d;->setPanelState(La8/e;)V

    goto :goto_116

    :cond_ed
    const-string v1, "Error while initializing sdk!"

    invoke-virtual {v5, v0, v1, v2}, La8/b;->logError(ILjava/lang/String;Landroid/content/Context;)V

    new-instance v1, La8/g$b;

    new-instance v2, La8/l;

    invoke-virtual {v4}, La8/k;->getInstanceId()Ljava/lang/String;

    move-result-object v11

    const-string v13, ""

    const/4 v14, 0x1

    const-string v12, ""

    const/4 v15, 0x0

    const/16 v16, 0x0

    move-object v10, v2

    invoke-direct/range {v10 .. v16}, La8/l;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    invoke-direct {v1, v0, v2}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {v9, v1}, La8/d;->setState(La8/g;)V

    new-instance v0, La8/e$a;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, La8/e$a;-><init>(I)V

    invoke-virtual {v9, v0}, La8/d;->setPanelState(La8/e;)V

    :goto_116
    return-void

    :goto_117
    const/16 v0, 0x65

    const-string v1, "No internet!"

    invoke-virtual {v5, v0, v1, v2}, La8/b;->logError(ILjava/lang/String;Landroid/content/Context;)V

    new-instance v1, La8/g$b;

    sget-object v2, La8/l;->g:La8/l$a;

    invoke-virtual {v2}, La8/l$a;->default()La8/l;

    move-result-object v2

    invoke-direct {v1, v0, v2}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {v9, v1}, La8/d;->setState(La8/g;)V

    new-instance v1, La8/e$a;

    invoke-direct {v1, v0}, La8/e$a;-><init>(I)V

    invoke-virtual {v9, v1}, La8/d;->setPanelState(La8/e;)V

    return-void
.end method

.method public final flippiWidgetsUpdated()V
    .registers 2

    sget-object v0, La8/e$c;->a:La8/e$c;

    invoke-virtual {p0, v0}, La8/d;->setPanelState(La8/e;)V

    return-void
.end method

.method public final getAltInputCall()Lta/a;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lta/a<",
            "LGe/e0<",
            "Lmf/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, La8/d;->q:Lta/a;

    return-object v0
.end method

.method public final getCurrentSessionID()Ljava/lang/String;
    .registers 2

    sget-object v0, La8/d;->v:Ljava/lang/String;

    return-object v0
.end method

.method public final getHintText()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/d;->s:Ljava/lang/String;

    return-object v0
.end method

.method public final getPanelInstanceId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/d;->r:Ljava/lang/String;

    return-object v0
.end method

.method public final getTtsText()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/d;->t:Ljava/lang/String;

    return-object v0
.end method

.method public final handleDialogResponse(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V
    .registers 15

    const-string v0, "response"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "marketplace"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "trackingValue"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    instance-of v1, v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    if-eqz v1, :cond_2c

    check-cast v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getConversationId()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2c

    sget-object v1, La8/a;->a:La8/a;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getConversationId()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, La8/a;->setConversationId(Ljava/lang/String;)V

    :cond_2c
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getAction()Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    move-result-object v0

    if-nez v0, :cond_34

    const/4 v0, -0x1

    goto :goto_3c

    :cond_34
    sget-object v1, La8/d$c;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    :goto_3c
    iget-object v1, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    const/4 v2, 0x1

    if-eq v0, v2, :cond_210

    const/4 v2, 0x2

    iget-object v3, p0, La8/d;->a:Landroid/content/Context;

    if-eq v0, v2, :cond_1aa

    iget-object v4, p0, La8/d;->i:LR7/a;

    const/4 v5, 0x3

    const-string v6, "payload.getSlots()"

    if-eq v0, v5, :cond_129

    const/4 v2, 0x4

    if-eq v0, v2, :cond_cd

    const/4 v1, 0x5

    if-eq v0, v1, :cond_55

    goto/16 :goto_292

    :cond_55
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    instance-of v1, v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    if-nez v1, :cond_5e

    return-void

    :cond_5e
    iget-object v1, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {v1}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->cancelRecording()V

    iget-object v1, p0, La8/d;->n:La8/k;

    if-eqz v1, :cond_6a

    invoke-virtual {v1}, La8/k;->reset()V

    :cond_6a
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object p1

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.voice.s2tlibrary.common.model.params.AssistPayload"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getThresholdInfo()Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;

    move-result-object p1

    if-eqz p1, :cond_292

    const-string v1, "RENDER"

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;->getThresholdType()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b1

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;->getThresholdSlots()Lxk/m;

    move-result-object p1

    if-eqz p1, :cond_b0

    invoke-virtual {p1}, Lxk/m;->size()I

    move-result p1

    if-nez p1, :cond_94

    goto :goto_b0

    :cond_94
    sget-object p1, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, p1}, La8/d;->setState(La8/g;)V

    new-instance p1, La8/i;

    check-cast v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getSlots()Lxk/m;

    move-result-object v0

    invoke-static {v0, v6}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p3}, La8/l;->getPanelOpenInstanceId()Ljava/lang/String;

    move-result-object p3

    invoke-direct {p1, v0, p2, p3}, La8/i;-><init>(Lxk/m;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v4, p1}, LR7/a;->setValue(Ljava/lang/Object;)V

    goto/16 :goto_292

    :cond_b0
    :goto_b0
    return-void

    :cond_b1
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;->getTts()Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;

    move-result-object v1

    if-eqz v1, :cond_bc

    new-instance v2, La8/d$d;

    invoke-direct {v2, p0, v1, v0, p2}, La8/d$d;-><init>(La8/d;Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;Ljava/lang/String;)V

    :cond_bc
    check-cast v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    const-string p2, "DORMANT"

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;->getPostExecPanelState()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    invoke-direct {p0, v0, p1, p3}, La8/d;->e(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;ZLa8/l;)V

    goto/16 :goto_292

    :cond_cd
    if-eqz v1, :cond_d2

    invoke-virtual {v1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->startMapiResponseTracker()V

    :cond_d2
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object p1

    instance-of v0, p1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    if-eqz v0, :cond_128

    check-cast p1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getAction()Lxk/s;

    move-result-object v0

    if-nez v0, :cond_e3

    goto :goto_128

    :cond_e3
    iget-object v0, p0, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    invoke-static {p1, v0}, La8/h;->getFlippiWidgetData(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;Lcom/flipkart/android/gson/Serializer;)LWg/d;

    move-result-object v2

    if-eqz v2, :cond_fc

    iget-object v2, v2, LWg/d;->b:Lmf/D;

    if-nez v2, :cond_f0

    goto :goto_fc

    :cond_f0
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getConversationId()Ljava/lang/String;

    move-result-object v3

    const-string v4, "assistPayload.conversationId"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v2, v3, p2}, La8/d;->g(Lmf/D;Ljava/lang/String;Ljava/lang/String;)V

    :cond_fc
    :goto_fc
    sget-object p2, La8/e$e;->a:La8/e$e;

    invoke-virtual {p0, p2}, La8/d;->setPanelState(La8/e;)V

    invoke-static {p1, v0}, La8/h;->getFlippiWidgetData(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;Lcom/flipkart/android/gson/Serializer;)LWg/d;

    move-result-object p2

    sget-object v0, La8/h;->a:La8/h;

    if-eqz p2, :cond_10c

    iget-object p2, p2, LWg/d;->a:LLe/f;

    goto :goto_10d

    :cond_10c
    const/4 p2, 0x0

    :goto_10d
    invoke-virtual {v0, p2}, La8/h;->isDormant(LLe/f;)Z

    move-result p2

    invoke-direct {p0, p1, p2, p3}, La8/d;->e(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;ZLa8/l;)V

    if-eqz v1, :cond_292

    invoke-virtual {v1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->getRecordingEndToFinalOutputTracker()Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    move-result-object p1

    if-eqz p1, :cond_123

    invoke-direct {p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->stopTraceAndTrackEventWithNC(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_123
    invoke-virtual {v1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->ingestLastPacketUploadToFinalOutput()V

    goto/16 :goto_292

    :cond_128
    :goto_128
    return-void

    :cond_129
    invoke-virtual {p3}, La8/l;->isFirstHandshake()Z

    move-result v0

    if-eqz v0, :cond_13e

    if-eqz v1, :cond_13e

    invoke-virtual {v1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->getWidgetResponseTracker()Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    move-result-object v0

    if-eqz v0, :cond_13e

    invoke-direct {p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v5

    invoke-virtual {v0, v5}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->stopTraceAndTrackEventWithNC(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_13e
    if-eqz v1, :cond_143

    invoke-virtual {v1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->startWidgetRenderTracker()V

    :cond_143
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object p1

    instance-of v0, p1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    if-eqz v0, :cond_1a9

    check-cast p1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getSlots()Lxk/m;

    move-result-object v0

    if-eqz v0, :cond_1a9

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getSlots()Lxk/m;

    move-result-object v0

    invoke-virtual {v0}, Lxk/m;->size()I

    move-result v0

    if-nez v0, :cond_15e

    goto :goto_1a9

    :cond_15e
    new-instance v0, La8/i;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getSlots()Lxk/m;

    move-result-object v1

    invoke-static {v1, v6}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p3}, La8/l;->getPanelOpenInstanceId()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v1, p2, v5}, La8/i;-><init>(Lxk/m;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v4, v0}, LR7/a;->setValue(Ljava/lang/Object;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getThresholdInfo()Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;

    move-result-object p1

    if-nez p1, :cond_19b

    sget-object p1, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, p1}, La8/d;->setState(La8/g;)V

    invoke-virtual {p3}, La8/l;->isFirstHandshake()Z

    move-result p1

    if-nez p1, :cond_292

    new-instance p1, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;

    invoke-virtual {p3}, La8/l;->getAudioId()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p3}, La8/l;->getTranscriptionText()Ljava/lang/String;

    move-result-object v9

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v5, "Error"

    const-string v10, "not_understood"

    move-object v4, p1

    invoke-direct/range {v4 .. v10}, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, p1}, La8/h;->ingestFdpEvent(Landroid/content/Context;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    goto/16 :goto_292

    :cond_19b
    sget-object p1, Lcom/flipkart/android/voice/flippi/FlippiEvent;->HIDE_TRANSCRIPTION:Lcom/flipkart/android/voice/flippi/FlippiEvent;

    iget-object p2, p0, La8/d;->m:Landroid/os/Handler;

    new-instance p3, Lh0/e;

    invoke-direct {p3, p0, p1, v2}, Lh0/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_292

    :cond_1a9
    :goto_1a9
    return-void

    :cond_1aa
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object p1

    const-string p2, "null cannot be cast to non-null type com.flipkart.android.voice.s2tlibrary.common.model.params.ErrorPayload"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;

    sget-object p2, La8/b;->a:La8/b;

    invoke-virtual {p2, p1, v3}, La8/b;->logError(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;Landroid/content/Context;)V

    sget-object p2, Lj8/b;->a:Lj8/b;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getErrNum()I

    move-result v0

    invoke-virtual {p2, v0}, Lj8/b;->isDmError(I)Z

    move-result p2

    if-eqz p2, :cond_1d9

    new-instance p2, La8/g$b;

    const/16 v0, 0x6a

    invoke-direct {p2, v0, p3}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {p0, p2}, La8/d;->setState(La8/g;)V

    new-instance p2, La8/e$a;

    invoke-direct {p2, v0}, La8/e$a;-><init>(I)V

    invoke-virtual {p0, p2}, La8/d;->setPanelState(La8/e;)V

    goto :goto_1f1

    :cond_1d9
    new-instance p2, La8/g$b;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getErrNum()I

    move-result v0

    invoke-direct {p2, v0, p3}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {p0, p2}, La8/d;->setState(La8/g;)V

    new-instance p2, La8/e$a;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getErrNum()I

    move-result v0

    invoke-direct {p2, v0}, La8/e$a;-><init>(I)V

    invoke-virtual {p0, p2}, La8/d;->setPanelState(La8/e;)V

    :goto_1f1
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getErrNum()I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    new-instance p1, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;

    invoke-virtual {p3}, La8/l;->getAudioId()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p3}, La8/l;->getTranscriptionText()Ljava/lang/String;

    move-result-object v9

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v5, "Error"

    move-object v4, p1

    invoke-direct/range {v4 .. v10}, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, p1}, La8/h;->ingestFdpEvent(Landroid/content/Context;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    goto/16 :goto_292

    :cond_210
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object p2

    const-string v0, "null cannot be cast to non-null type com.flipkart.android.voice.s2tlibrary.common.model.params.TranscriptionPayload"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;

    if-eqz v1, :cond_22d

    invoke-virtual {p2}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;->getRecId()Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "transcriptionPayload.recId"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    invoke-virtual {v1, v3}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->setIndividualTranscriptionDelay(I)V

    :cond_22d
    if-eqz v1, :cond_238

    invoke-virtual {v1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->getFirstTranscriptionReceived()Z

    move-result v3

    if-ne v3, v2, :cond_238

    invoke-virtual {v1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->ingestFirstTranscriptionDelayEvent()V

    :cond_238
    iget-object v1, p0, La8/d;->f:Landroidx/lifecycle/I;

    invoke-virtual {v1}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v3, 0x0

    if-eqz v2, :cond_26a

    invoke-virtual {v1}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, La8/g$c;

    if-eqz v2, :cond_26a

    new-instance p1, La8/g$c;

    invoke-virtual {p2}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;->getTranscriptions()[Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    move-result-object v0

    aget-object v0, v0, v3

    invoke-virtual {p2}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;->getLast()Ljava/lang/Boolean;

    move-result-object p2

    const-string v1, "transcriptionPayload.last"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    invoke-direct {p1, v0, p2, p3}, La8/g$c;-><init>(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ZLa8/l;)V

    invoke-virtual {p0, p1}, La8/d;->setState(La8/g;)V

    sget-object p1, La8/e$b;->a:La8/e$b;

    invoke-virtual {p0, p1}, La8/d;->setPanelState(La8/e;)V

    goto :goto_292

    :cond_26a
    new-instance p2, La8/g$e;

    sget-object p3, La8/g;->a:La8/g$a;

    invoke-virtual {v1}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La8/g;

    invoke-virtual {p3, v1}, La8/g$a;->getOldRms(La8/g;)D

    move-result-wide v1

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object p1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;->getTranscriptions()[Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    move-result-object p1

    aget-object p1, p1, v3

    invoke-direct {p2, v1, v2, p1}, La8/g$e;-><init>(DLcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)V

    invoke-virtual {p0, p2}, La8/d;->setState(La8/g;)V

    sget-object p1, La8/e$d;->a:La8/e$d;

    invoke-virtual {p0, p1}, La8/d;->setPanelState(La8/e;)V

    :cond_292
    :goto_292
    return-void
.end method

.method public final handlePageLoadedEvent()V
    .registers 3

    iget-object v0, p0, La8/d;->g:Landroidx/lifecycle/I;

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->hasActiveObservers()Z

    move-result v1

    if-eqz v1, :cond_1f

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, La8/e$e;

    if-eqz v0, :cond_1f

    sget-object v0, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, v0}, La8/d;->setState(La8/g;)V

    new-instance v0, La8/e$a;

    const/16 v1, 0x6b

    invoke-direct {v0, v1}, La8/e$a;-><init>(I)V

    invoke-virtual {p0, v0}, La8/d;->setPanelState(La8/e;)V

    :cond_1f
    return-void
.end method

.method public final ingestPanelRenderLatency()V
    .registers 4

    iget-object v0, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->getWidgetRenderTracker()Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    move-result-object v1

    if-eqz v1, :cond_11

    invoke-direct {p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->stopTraceAndTrackEventWithNC(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_11
    invoke-virtual {v0}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->startAutolistenTracker()V

    :cond_14
    return-void
.end method

.method public final initialize()I
    .registers 5

    iget-object v0, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {v0}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->initialize()I

    move-result v0

    if-eqz v0, :cond_1b

    sget-object v1, La8/b;->a:La8/b;

    const-string v2, "Error while initializing sdk!"

    iget-object v3, p0, La8/d;->a:Landroid/content/Context;

    invoke-virtual {v1, v0, v2, v3}, La8/b;->logError(ILjava/lang/String;Landroid/content/Context;)V

    new-instance v1, La8/e$a;

    const/16 v2, 0xa

    invoke-direct {v1, v2}, La8/e$a;-><init>(I)V

    invoke-virtual {p0, v1}, La8/d;->setPanelState(La8/e;)V

    :cond_1b
    return v0
.end method

.method public final isFlippiSpeaking()Z
    .registers 2

    iget-object v0, p0, La8/d;->d:Lb8/c;

    invoke-virtual {v0}, Lb8/c;->isSpeaking()Z

    move-result v0

    return v0
.end method

.method public final isQuesAsked()Z
    .registers 2

    iget-boolean v0, p0, La8/d;->u:Z

    return v0
.end method

.method public final loadStaticPanel(Ljava/lang/String;Ljava/lang/String;)V
    .registers 13

    const-string v0, "marketplace"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "staticPanelKey"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {v0}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->isRunning()Z

    move-result v1

    if-eqz v1, :cond_15

    invoke-interface {v0}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->cancelRecording()V

    :cond_15
    invoke-virtual {p0}, La8/d;->stopTts()V

    iget-object v0, p0, La8/d;->n:La8/k;

    if-eqz v0, :cond_1f

    invoke-virtual {v0}, La8/k;->reset()V

    :cond_1f
    new-instance v0, La8/k;

    iget-object v2, p0, La8/d;->m:Landroid/os/Handler;

    sget-object v5, La8/d;->v:Ljava/lang/String;

    iget-object v3, p0, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    move-object v1, v0

    move-object v4, p0

    move-object v6, p1

    invoke-direct/range {v1 .. v9}, La8/k;-><init>(Landroid/os/Handler;Lcom/flipkart/android/gson/Serializer;La8/k$a;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    iput-object v0, p0, La8/d;->n:La8/k;

    sget-object p1, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, p1}, La8/d;->setState(La8/g;)V

    sget-object p1, La8/e$c;->a:La8/e$c;

    invoke-virtual {p0, p1}, La8/d;->setPanelState(La8/e;)V

    invoke-virtual {v0, p2}, La8/k;->emitStaticPanelResponse(Ljava/lang/String;)V

    return-void
.end method

.method public onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V
    .registers 5

    const-string v0, "dialogResponse"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "marketplace"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "trackingValue"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2, p3}, La8/d;->handleDialogResponse(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V

    return-void
.end method

.method public onAmplitudeChanged(D)V
    .registers 5

    new-instance v0, La8/g$e;

    const/4 v1, 0x0

    invoke-direct {v0, p1, p2, v1}, La8/g$e;-><init>(DLcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)V

    invoke-virtual {p0, v0}, La8/d;->setState(La8/g;)V

    sget-object p1, La8/e$d;->a:La8/e$d;

    invoke-virtual {p0, p1}, La8/d;->setPanelState(La8/e;)V

    return-void
.end method

.method public onDestroyed()V
    .registers 2

    iget-object v0, p0, La8/d;->n:La8/k;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, La8/k;->reset()V

    :cond_7
    return-void
.end method

.method public onPacketCreated(I)V
    .registers 12

    new-instance v9, Lj8/d;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    move-object v0, v9

    invoke-direct/range {v0 .. v8}, Lj8/d;-><init>(JJJILkotlin/jvm/internal/i;)V

    iget-object v0, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    if-eqz v0, :cond_1f

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->getUploadTimeMap()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, p1, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1f
    return-void
.end method

.method public onPacketUploadResult(IZ)V
    .registers 3

    iget-object p2, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    if-eqz p2, :cond_7

    invoke-virtual {p2, p1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->setIndividualPacketUploadDelay(I)V

    :cond_7
    return-void
.end method

.method public onPaused()V
    .registers 2

    invoke-virtual {p0}, La8/d;->stopTts()V

    iget-object v0, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {v0}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->cancelRecording()V

    sget-object v0, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, v0}, La8/d;->setState(La8/g;)V

    iget-object v0, p0, La8/d;->n:La8/k;

    if-eqz v0, :cond_14

    invoke-virtual {v0}, La8/k;->reset()V

    :cond_14
    return-void
.end method

.method public final onPermissionsResult(II)V
    .registers 4

    iget-object v0, p0, La8/d;->o:La8/f;

    if-eqz v0, :cond_7

    invoke-virtual {v0, p1, p2}, La8/f;->actionTaken(II)V

    :cond_7
    const/16 v0, 0x1f

    if-ne p2, v0, :cond_d

    const/4 p2, 0x1

    goto :goto_e

    :cond_d
    const/4 p2, 0x0

    :goto_e
    const/4 v0, 0x4

    if-ne p1, v0, :cond_22

    if-eqz p2, :cond_22

    iget-object p1, p0, La8/d;->o:La8/f;

    if-eqz p1, :cond_1d

    invoke-virtual {p1}, La8/f;->getMarketplace()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_1f

    :cond_1d
    const-string p1, "FLIPKART"

    :cond_1f
    invoke-virtual {p0, p2, p1}, La8/d;->startListening(ZLjava/lang/String;)V

    :cond_22
    return-void
.end method

.method public onRecordingEnd(La8/l;)V
    .registers 5

    const-string v0, "trackingValue"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, La8/g$c;

    sget-object v1, La8/g;->a:La8/g$a;

    iget-object v2, p0, La8/d;->f:Landroidx/lifecycle/I;

    invoke-virtual {v2}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La8/g;

    invoke-virtual {v1, v2}, La8/g$a;->getOldTranscription(La8/g;)Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, p1}, La8/g$c;-><init>(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ZLa8/l;)V

    invoke-virtual {p0, v0}, La8/d;->setState(La8/g;)V

    sget-object p1, La8/e$b;->a:La8/e$b;

    invoke-virtual {p0, p1}, La8/d;->setPanelState(La8/e;)V

    iget-object p1, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    if-eqz p1, :cond_28

    invoke-virtual {p1}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->startRecordingEndToFinalOutputTracker()V

    :cond_28
    return-void
.end method

.method public final playTts(Lmf/D;Ljava/lang/String;)V
    .registers 5

    const-string v0, "ttsValue"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "marketplace"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, La8/a;->a:La8/a;

    invoke-virtual {v0}, La8/a;->getConversationId()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1f

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "randomUUID().toString()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1f
    invoke-direct {p0, p1, v0, p2}, La8/d;->g(Lmf/D;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public final processFlippiResponse(LNf/b;)V
    .registers 7

    iget-object v0, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    if-eqz v0, :cond_11

    invoke-virtual {v0}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->getMapiResponseTracker()Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    move-result-object v0

    if-eqz v0, :cond_11

    invoke-direct {p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->stopTraceAndTrackEventWithNC(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_11
    iget-object v0, p0, La8/d;->g:Landroidx/lifecycle/I;

    const/4 v1, 0x2

    iget-object v2, p0, La8/d;->m:Landroid/os/Handler;

    if-nez p1, :cond_31

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->hasActiveObservers()Z

    move-result v3

    if-eqz v3, :cond_31

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object p1

    instance-of p1, p1, La8/e$e;

    if-eqz p1, :cond_30

    sget-object p1, Lcom/flipkart/android/voice/flippi/FlippiEvent;->CLOSE_PANEL:Lcom/flipkart/android/voice/flippi/FlippiEvent;

    new-instance v0, Lh0/e;

    invoke-direct {v0, p0, p1, v1}, Lh0/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_30
    return-void

    :cond_31
    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->hasActiveObservers()Z

    move-result v0

    iget-object v3, p0, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    if-eqz v0, :cond_77

    sget-object v0, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, v0}, La8/d;->setState(La8/g;)V

    sget-object v0, La8/e$c;->a:La8/e$c;

    invoke-virtual {p0, v0}, La8/d;->setPanelState(La8/e;)V

    const/4 v0, 0x0

    if-eqz p1, :cond_52

    iget-object p1, p1, LNf/b;->a:Ljava/util/List;

    if-eqz p1, :cond_52

    const/4 v4, 0x0

    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljg/K;

    goto :goto_53

    :cond_52
    move-object p1, v0

    :goto_53
    if-eqz p1, :cond_6c

    invoke-virtual {v3, p1}, Lcom/flipkart/android/gson/Serializer;->serializeSlotData(Ljg/K;)Lxk/p;

    move-result-object p1

    new-instance v1, Lxk/m;

    invoke-direct {v1}, Lxk/m;-><init>()V

    invoke-virtual {v1, p1}, Lxk/m;->t(Lxk/p;)V

    iget-object p1, p0, La8/d;->i:LR7/a;

    new-instance v2, La8/i;

    invoke-direct {v2, v1, v0, v0}, La8/i;-><init>(Lxk/m;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1, v2}, Landroidx/lifecycle/I;->postValue(Ljava/lang/Object;)V

    goto :goto_76

    :cond_6c
    sget-object p1, Lcom/flipkart/android/voice/flippi/FlippiEvent;->CLOSE_PANEL:Lcom/flipkart/android/voice/flippi/FlippiEvent;

    new-instance v0, Lh0/e;

    invoke-direct {v0, p0, p1, v1}, Lh0/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_76
    return-void

    :cond_77
    invoke-static {p1, v3}, La8/h;->getFlippiWidgetData(LNf/b;Lcom/flipkart/android/gson/Serializer;)LWg/d;

    move-result-object p1

    if-nez p1, :cond_7e

    return-void

    :cond_7e
    iget-object v0, p1, LWg/d;->a:LLe/f;

    if-eqz v0, :cond_90

    iget-object v0, v0, LGe/B0;->a:Ljava/util/Map;

    if-eqz v0, :cond_90

    const-string v1, "marketplace"

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_92

    :cond_90
    const-string v0, "FLIPKART"

    :cond_92
    iget-object p1, p1, LWg/d;->b:Lmf/D;

    if-eqz p1, :cond_99

    invoke-virtual {p0, p1, v0}, La8/d;->playTts(Lmf/D;Ljava/lang/String;)V

    :cond_99
    return-void
.end method

.method public final resetStates()V
    .registers 2

    sget-object v0, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, v0}, La8/d;->setState(La8/g;)V

    sget-object v0, La8/e$c;->a:La8/e$c;

    invoke-virtual {p0, v0}, La8/d;->setPanelState(La8/e;)V

    return-void
.end method

.method public final setAltInputCall(Lta/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "Lmf/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    iput-object p1, p0, La8/d;->q:Lta/a;

    return-void
.end method

.method public final setCurrentSessionID(Ljava/lang/String;)V
    .registers 3

    const-string v0, "assistantSessionID"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object p1, La8/d;->v:Ljava/lang/String;

    return-void
.end method

.method public final setHintText(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, La8/d;->s:Ljava/lang/String;

    return-void
.end method

.method public final setInitTimeStamp()V
    .registers 2

    iget-object v0, p0, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->startWidgetResponseTracker()V

    :cond_7
    return-void
.end method

.method public final setPanelInstanceId(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, La8/d;->r:Ljava/lang/String;

    return-void
.end method

.method public final setPanelState(La8/e;)V
    .registers 5

    const-string v0, "state"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->m:Landroid/os/Handler;

    new-instance v1, La0/t;

    const/4 v2, 0x4

    invoke-direct {v1, p0, p1, v2}, La0/t;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final setQuesAsked(Z)V
    .registers 2

    iput-boolean p1, p0, La8/d;->u:Z

    return-void
.end method

.method public final setState(La8/g;)V
    .registers 5

    const-string v0, "state"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->m:Landroid/os/Handler;

    new-instance v1, LW5/a;

    const/4 v2, 0x2

    invoke-direct {v1, p0, p1, v2}, LW5/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final setTtsText(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, La8/d;->t:Ljava/lang/String;

    return-void
.end method

.method public final startListening(ZLjava/lang/String;)V
    .registers 22

    move-object/from16 v9, p0

    move-object/from16 v10, p2

    const-string v0, "marketplace"

    invoke-static {v10, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, La8/d;->isFlippiSpeaking()Z

    move-result v11

    iput-boolean v11, v9, La8/d;->b:Z

    iget-object v7, v9, La8/d;->p:Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;

    if-eqz v7, :cond_16

    invoke-virtual {v7}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->clearPreviousQueryData()V

    :cond_16
    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    sget-object v12, La8/b;->a:La8/b;

    const/4 v8, 0x0

    iget-object v13, v9, La8/d;->a:Landroid/content/Context;

    if-eqz v0, :cond_61

    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.content.Context"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Lcom/flipkart/android/utils/A0;->checkNetworkConnectivity(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_61

    const-string v0, "No internet!"

    const/16 v10, 0x65

    invoke-virtual {v12, v10, v0, v13}, La8/b;->logError(ILjava/lang/String;Landroid/content/Context;)V

    new-instance v11, La8/g$b;

    new-instance v12, La8/l;

    invoke-virtual/range {p0 .. p0}, La8/d;->isFlippiSpeaking()Z

    move-result v5

    const-string v1, ""

    const/4 v4, 0x0

    const-string v2, ""

    const-string v3, ""

    move-object v0, v12

    move/from16 v6, p1

    invoke-direct/range {v0 .. v6}, La8/l;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    invoke-direct {v11, v10, v12}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {v9, v11}, La8/d;->setState(La8/g;)V

    new-instance v0, La8/e$a;

    invoke-direct {v0, v10}, La8/e$a;-><init>(I)V

    invoke-virtual {v9, v0}, La8/d;->setPanelState(La8/e;)V

    goto :goto_86

    :cond_61
    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La8/c;

    if-nez v0, :cond_6c

    goto :goto_86

    :cond_6c
    if-eqz p1, :cond_71

    const/16 v1, 0x1f

    goto :goto_73

    :cond_71
    const/16 v1, 0x1e

    :goto_73
    sget-object v2, La8/h;->a:La8/h;

    invoke-virtual {v2, v10}, La8/h;->getWidgetKeyInfo(Ljava/lang/String;)Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;

    move-result-object v2

    invoke-interface {v0, v1, v2}, La8/c;->checkAndAskPermission(ILcom/flipkart/android/permissions/RationaleWidgetKeyInfo;)Z

    move-result v0

    if-nez v0, :cond_8d

    new-instance v0, La8/f;

    invoke-direct {v0, v10, v13}, La8/f;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    iput-object v0, v9, La8/d;->o:La8/f;

    :goto_86
    if-nez v7, :cond_89

    goto :goto_8c

    :cond_89
    invoke-virtual {v7, v8}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->setAutolistenTracker(Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;)V

    :goto_8c
    return-void

    :cond_8d
    if-eqz p1, :cond_a6

    iget-object v0, v9, La8/d;->t:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_a6

    if-eqz v7, :cond_a6

    invoke-virtual {v7}, Lcom/flipkart/android/voice/util/FlippiLatencyTrackingHandler;->getAutolistenTracker()Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    move-result-object v0

    if-eqz v0, :cond_a6

    invoke-direct/range {p0 .. p0}, La8/d;->f()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->stopTraceAndTrackEventWithNC(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_a6
    iget-object v14, v9, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {v14}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_b1

    invoke-interface {v14}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->cancelRecording()V

    :cond_b1
    invoke-virtual/range {p0 .. p0}, La8/d;->stopTts()V

    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La8/c;

    if-nez v0, :cond_bf

    goto :goto_ca

    :cond_bf
    instance-of v1, v0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    if-nez v1, :cond_c4

    goto :goto_ca

    :cond_c4
    check-cast v0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    invoke-virtual {v0}, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->getCurrentScreenUri()Ljava/lang/String;

    move-result-object v8

    :goto_ca
    sget-object v0, Lcom/flipkart/android/voice/FlippiRequestInfo;->Companion:Lcom/flipkart/android/voice/FlippiRequestInfo$a;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v1

    invoke-virtual {v1, v8}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getPageRequestString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v0}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v0

    invoke-virtual {v0, v8}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getConversationId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, La8/a;->a:La8/a;

    invoke-virtual {v1}, La8/a;->getConversationId()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_e7

    move-object/from16 v16, v0

    goto :goto_e9

    :cond_e7
    move-object/from16 v16, v1

    :goto_e9
    const-wide/16 v0, 0x0

    iget-object v2, v9, La8/d;->l:Lw4/b;

    if-eqz v2, :cond_f2

    iget-wide v2, v2, Lw4/b;->a:J

    goto :goto_f3

    :cond_f2
    move-wide v2, v0

    :goto_f3
    if-nez v16, :cond_121

    cmp-long v4, v2, v0

    if-nez v4, :cond_121

    const/16 v7, 0x68

    const-string v0, "Null conversation id!"

    invoke-virtual {v12, v7, v0, v13}, La8/b;->logError(ILjava/lang/String;Landroid/content/Context;)V

    new-instance v8, La8/g$b;

    new-instance v10, La8/l;

    const-string v1, ""

    const-string v2, ""

    const-string v3, ""

    const/4 v4, 0x0

    move-object v0, v10

    move v5, v11

    move/from16 v6, p1

    invoke-direct/range {v0 .. v6}, La8/l;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    invoke-direct {v8, v7, v10}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {v9, v8}, La8/d;->setState(La8/g;)V

    new-instance v0, La8/e$a;

    invoke-direct {v0, v7}, La8/e$a;-><init>(I)V

    invoke-virtual {v9, v0}, La8/d;->setPanelState(La8/e;)V

    return-void

    :cond_121
    iget-object v0, v9, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La8/c;

    const-string v1, "EN"

    if-eqz v0, :cond_13b

    invoke-interface {v0}, La8/c;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_13b

    invoke-static {v0}, Lcom/flipkart/android/utils/n0;->getSelectedLanguage(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_13a

    goto :goto_13b

    :cond_13a
    move-object v1, v0

    :cond_13b
    :goto_13b
    move-object/from16 v17, v1

    iget-object v0, v9, La8/d;->n:La8/k;

    if-eqz v0, :cond_144

    invoke-virtual {v0}, La8/k;->reset()V

    :cond_144
    new-instance v8, La8/k;

    iget-object v1, v9, La8/d;->m:Landroid/os/Handler;

    sget-object v4, La8/d;->v:Ljava/lang/String;

    const/4 v7, 0x0

    iget-object v2, v9, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    move-object v0, v8

    move-object/from16 v3, p0

    move-object/from16 v5, p2

    move/from16 v6, p1

    move-object/from16 v18, v8

    move v8, v11

    invoke-direct/range {v0 .. v8}, La8/k;-><init>(Landroid/os/Handler;Lcom/flipkart/android/gson/Serializer;La8/k$a;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    invoke-virtual/range {v18 .. v18}, La8/k;->getInstanceId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v9, La8/d;->r:Ljava/lang/String;

    move-object/from16 v8, v18

    iput-object v8, v9, La8/d;->n:La8/k;

    sget-object v18, Lj8/c;->a:Lj8/c;

    invoke-virtual {v8}, La8/k;->getInstanceId()Ljava/lang/String;

    move-result-object v7

    iget-object v1, v9, La8/d;->e:Lcom/flipkart/android/gson/Serializer;

    const/4 v2, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, v18

    move-object/from16 v3, v17

    move-object v4, v15

    move-object/from16 v5, v16

    move-object v15, v8

    move-object/from16 v8, p2

    invoke-virtual/range {v0 .. v8}, Lj8/c;->getHttpParamsForFlippi(Lcom/flipkart/android/gson/Serializer;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    invoke-virtual/range {v18 .. v18}, Lj8/c;->getDefaultWebsocketParams()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v14, v0, v1, v15}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->startRecording(Ljava/util/Map;Ljava/util/Map;Lcom/flipkart/android/voice/s2tlibrary/SpeechToText$a;)I

    move-result v7

    if-eqz v7, :cond_1ad

    const-string v0, "Error while initializing sdk!"

    invoke-virtual {v12, v7, v0, v13}, La8/b;->logError(ILjava/lang/String;Landroid/content/Context;)V

    new-instance v8, La8/g$b;

    new-instance v10, La8/l;

    invoke-virtual {v15}, La8/k;->getInstanceId()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const-string v2, ""

    const-string v3, ""

    move-object v0, v10

    move v5, v11

    move/from16 v6, p1

    invoke-direct/range {v0 .. v6}, La8/l;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    invoke-direct {v8, v7, v10}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {v9, v8}, La8/d;->setState(La8/g;)V

    new-instance v0, La8/e$a;

    invoke-direct {v0, v7}, La8/e$a;-><init>(I)V

    invoke-virtual {v9, v0}, La8/d;->setPanelState(La8/e;)V

    :cond_1ad
    return-void
.end method

.method public final stopListening()V
    .registers 2

    iget-object v0, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {v0}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->isRunning()Z

    move-result v0

    if-nez v0, :cond_17

    const-string v0, "Stop listening is called when sdk is not running!"

    invoke-static {v0}, LDi/q;->d(Ljava/lang/String;)V

    sget-object v0, La8/g$d;->b:La8/g$d;

    invoke-virtual {p0, v0}, La8/d;->setState(La8/g;)V

    sget-object v0, La8/e$c;->a:La8/e$c;

    invoke-virtual {p0, v0}, La8/d;->setPanelState(La8/e;)V

    :cond_17
    const/4 v0, 0x1

    invoke-virtual {p0, v0, v0}, La8/d;->stopListening(ZZ)V

    return-void
.end method

.method public final stopListening(ZZ)V
    .registers 4

    if-eqz p2, :cond_5

    invoke-virtual {p0}, La8/d;->stopTts()V

    :cond_5
    iget-object p2, p0, La8/d;->c:Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani;

    invoke-interface {p2}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_16

    if-eqz p1, :cond_13

    invoke-interface {p2}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->stopRecording()V

    goto :goto_16

    :cond_13
    invoke-interface {p2}, Lcom/flipkart/android/voice/s2tlibrary/SpeechToText;->cancelRecording()V

    :cond_16
    :goto_16
    return-void
.end method

.method public final stopTts()V
    .registers 2

    iget-object v0, p0, La8/d;->d:Lb8/c;

    invoke-virtual {v0}, Lb8/c;->stop()V

    return-void
.end method

.method public final updateAssistantCallback(La8/c;)V
    .registers 3

    const-string v0, "flippiCallback"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eq v0, p1, :cond_14

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, La8/d;->j:Ljava/lang/ref/WeakReference;

    :cond_14
    return-void
.end method
