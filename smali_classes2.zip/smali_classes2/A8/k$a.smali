.class public interface abstract La8/k$a;
.super Ljava/lang/Object;
.source "SpeechToTextCallback.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V
.end method

.method public abstract onAmplitudeChanged(D)V
.end method

.method public abstract onPacketCreated(I)V
.end method

.method public abstract onPacketUploadResult(IZ)V
.end method

.method public abstract onRecordingEnd(La8/l;)V
.end method
