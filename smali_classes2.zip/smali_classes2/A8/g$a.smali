.class public final La8/g$a;
.super Ljava/lang/Object;
.source "FlippiState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getOldRms(La8/g;)D
    .registers 4

    if-eqz p1, :cond_d

    instance-of v0, p1, La8/g$e;

    if-eqz v0, :cond_d

    check-cast p1, La8/g$e;

    invoke-virtual {p1}, La8/g$e;->getRMS()D

    move-result-wide v0

    return-wide v0

    :cond_d
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public final getOldTranscription(La8/g;)Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;
    .registers 3

    if-eqz p1, :cond_d

    instance-of v0, p1, La8/g$e;

    if-eqz v0, :cond_d

    check-cast p1, La8/g$e;

    invoke-virtual {p1}, La8/g$e;->getTranscription()Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    move-result-object p1

    return-object p1

    :cond_d
    const/4 p1, 0x0

    return-object p1
.end method
