.class public final La8/e$b;
.super La8/e;
.source "FlippiPanelState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final a:La8/e$b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/e$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/e;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, La8/e$b;->a:La8/e$b;

    return-void
.end method
