.class public final La8/e$a;
.super La8/e;
.source "FlippiPanelState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:I


# direct methods
.method public constructor <init>(I)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La8/e;-><init>(Lkotlin/jvm/internal/i;)V

    iput p1, p0, La8/e$a;->a:I

    return-void
.end method

.method public static synthetic copy$default(La8/e$a;IILjava/lang/Object;)La8/e$a;
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    iget p1, p0, La8/e$a;->a:I

    :cond_6
    invoke-virtual {p0, p1}, La8/e$a;->copy(I)La8/e$a;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 2

    iget v0, p0, La8/e$a;->a:I

    return v0
.end method

.method public final copy(I)La8/e$a;
    .registers 3

    new-instance v0, La8/e$a;

    invoke-direct {v0, p1}, La8/e$a;-><init>(I)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 5

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La8/e$a;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La8/e$a;

    iget v1, p0, La8/e$a;->a:I

    iget p1, p1, La8/e$a;->a:I

    if-eq v1, p1, :cond_13

    return v2

    :cond_13
    return v0
.end method

.method public final getErrorType()I
    .registers 2

    iget v0, p0, La8/e$a;->a:I

    return v0
.end method

.method public hashCode()I
    .registers 2

    iget v0, p0, La8/e$a;->a:I

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error(errorType="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, La8/e$a;->a:I

    const/16 v2, 0x29

    invoke-static {v0, v1, v2}, LU9/c;->c(Ljava/lang/StringBuilder;IC)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
