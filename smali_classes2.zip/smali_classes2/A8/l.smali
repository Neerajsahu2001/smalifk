.class public final La8/l;
.super Ljava/lang/Object;
.source "TrackingValue.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La8/l$a;
    }
.end annotation


# static fields
.field public static final g:La8/l$a;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Z

.field private final e:Z

.field private final f:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/l$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/l$a;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, La8/l;->g:La8/l$a;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V
    .registers 8

    const-string v0, "instanceId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "audioId"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "transcriptionText"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/l;->a:Ljava/lang/String;

    iput-object p2, p0, La8/l;->b:Ljava/lang/String;

    iput-object p3, p0, La8/l;->c:Ljava/lang/String;

    iput-boolean p4, p0, La8/l;->d:Z

    iput-boolean p5, p0, La8/l;->e:Z

    iput-boolean p6, p0, La8/l;->f:Z

    return-void
.end method

.method public static synthetic copy$default(La8/l;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZILjava/lang/Object;)La8/l;
    .registers 13

    and-int/lit8 p8, p7, 0x1

    if-eqz p8, :cond_6

    iget-object p1, p0, La8/l;->a:Ljava/lang/String;

    :cond_6
    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_c

    iget-object p2, p0, La8/l;->b:Ljava/lang/String;

    :cond_c
    move-object p8, p2

    and-int/lit8 p2, p7, 0x4

    if-eqz p2, :cond_13

    iget-object p3, p0, La8/l;->c:Ljava/lang/String;

    :cond_13
    move-object v0, p3

    and-int/lit8 p2, p7, 0x8

    if-eqz p2, :cond_1a

    iget-boolean p4, p0, La8/l;->d:Z

    :cond_1a
    move v1, p4

    and-int/lit8 p2, p7, 0x10

    if-eqz p2, :cond_21

    iget-boolean p5, p0, La8/l;->e:Z

    :cond_21
    move v2, p5

    and-int/lit8 p2, p7, 0x20

    if-eqz p2, :cond_28

    iget-boolean p6, p0, La8/l;->f:Z

    :cond_28
    move v3, p6

    move-object p2, p0

    move-object p3, p1

    move-object p4, p8

    move-object p5, v0

    move p6, v1

    move p7, v2

    move p8, v3

    invoke-virtual/range {p2 .. p8}, La8/l;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)La8/l;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/l;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final component2()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/l;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final component3()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/l;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final component4()Z
    .registers 2

    iget-boolean v0, p0, La8/l;->d:Z

    return v0
.end method

.method public final component5()Z
    .registers 2

    iget-boolean v0, p0, La8/l;->e:Z

    return v0
.end method

.method public final component6()Z
    .registers 2

    iget-boolean v0, p0, La8/l;->f:Z

    return v0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)La8/l;
    .registers 15

    const-string v0, "instanceId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "audioId"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "transcriptionText"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, La8/l;

    move-object v1, v0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v5, p4

    move v6, p5

    move v7, p6

    invoke-direct/range {v1 .. v7}, La8/l;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La8/l;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La8/l;

    iget-object v1, p1, La8/l;->a:Ljava/lang/String;

    iget-object v3, p0, La8/l;->a:Ljava/lang/String;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, La8/l;->b:Ljava/lang/String;

    iget-object v3, p1, La8/l;->b:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-object v1, p0, La8/l;->c:Ljava/lang/String;

    iget-object v3, p1, La8/l;->c:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2d

    return v2

    :cond_2d
    iget-boolean v1, p0, La8/l;->d:Z

    iget-boolean v3, p1, La8/l;->d:Z

    if-eq v1, v3, :cond_34

    return v2

    :cond_34
    iget-boolean v1, p0, La8/l;->e:Z

    iget-boolean v3, p1, La8/l;->e:Z

    if-eq v1, v3, :cond_3b

    return v2

    :cond_3b
    iget-boolean v1, p0, La8/l;->f:Z

    iget-boolean p1, p1, La8/l;->f:Z

    if-eq v1, p1, :cond_42

    return v2

    :cond_42
    return v0
.end method

.method public final getAudioId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/l;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final getFlippiSpeaking()Z
    .registers 2

    iget-boolean v0, p0, La8/l;->e:Z

    return v0
.end method

.method public final getFlippiState()Ljava/lang/String;
    .registers 2

    iget-boolean v0, p0, La8/l;->e:Z

    if-eqz v0, :cond_7

    const-string v0, "1"

    goto :goto_9

    :cond_7
    const-string v0, "2"

    :goto_9
    return-object v0
.end method

.method public final getInstanceId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/l;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final getPanelOpenInstanceId()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "PanelOpen"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La8/l;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getTranscriptionText()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/l;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final getVoiceInputInstanceId()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "VoiceInput"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La8/l;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public hashCode()I
    .registers 5

    iget-object v0, p0, La8/l;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, La8/l;->b:Ljava/lang/String;

    invoke-static {v2, v0, v1}, LD/a;->a(Ljava/lang/String;II)I

    move-result v0

    iget-object v2, p0, La8/l;->c:Ljava/lang/String;

    invoke-static {v2, v0, v1}, LD/a;->a(Ljava/lang/String;II)I

    move-result v0

    const/4 v2, 0x1

    iget-boolean v3, p0, La8/l;->d:Z

    if-eqz v3, :cond_1c

    const/4 v3, 0x1

    :cond_1c
    add-int/2addr v0, v3

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v3, p0, La8/l;->e:Z

    if-eqz v3, :cond_24

    const/4 v3, 0x1

    :cond_24
    add-int/2addr v0, v3

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, La8/l;->f:Z

    if-eqz v1, :cond_2c

    goto :goto_2d

    :cond_2c
    move v2, v1

    :goto_2d
    add-int/2addr v0, v2

    return v0
.end method

.method public final isAutoListen()Z
    .registers 2

    iget-boolean v0, p0, La8/l;->f:Z

    return v0
.end method

.method public final isFirstHandshake()Z
    .registers 2

    iget-boolean v0, p0, La8/l;->d:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "TrackingValue(instanceId="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La8/l;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", audioId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La8/l;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", transcriptionText="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La8/l;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", isFirstHandshake="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, La8/l;->d:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", flippiSpeaking="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, La8/l;->e:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", isAutoListen="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, La8/l;->f:Z

    const/16 v2, 0x29

    invoke-static {v0, v1, v2}, Landroidx/coordinatorlayout/widget/a;->b(Ljava/lang/StringBuilder;ZC)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
