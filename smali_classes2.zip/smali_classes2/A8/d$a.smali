.class public final La8/d$a;
.super Ljava/lang/Object;
.source "FlippiController.kt"

# interfaces
.implements Lcom/flipkart/android/voice/s2tlibrary/v2/Vaani$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La8/d;-><init>(Landroid/content/Context;La8/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# virtual methods
.method public initSoLoader(Landroid/content/Context;)V
    .registers 3

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method
