.class public final synthetic La8/d$c;
.super Ljava/lang/Object;
.source "FlippiController.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1001
    name = "c"
.end annotation


# static fields
.field public static final synthetic a:[I

.field public static final synthetic b:[I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    invoke-static {}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->values()[Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    const/4 v1, 0x1

    :try_start_8
    sget-object v2, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->TRANSCRIPTION:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aput v1, v0, v2
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_10} :catch_10

    :catch_10
    const/4 v2, 0x2

    :try_start_11
    sget-object v3, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->ERROR:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aput v2, v0, v3
    :try_end_19
    .catch Ljava/lang/NoSuchFieldError; {:try_start_11 .. :try_end_19} :catch_19

    :catch_19
    const/4 v3, 0x3

    :try_start_1a
    sget-object v4, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->RENDER:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v3, v0, v4
    :try_end_22
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1a .. :try_end_22} :catch_22

    :catch_22
    :try_start_22
    sget-object v4, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->EXECUTE:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    const/4 v5, 0x4

    aput v5, v0, v4
    :try_end_2b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_22 .. :try_end_2b} :catch_2b

    :catch_2b
    :try_start_2b
    sget-object v4, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->INTERMEDIATE:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    const/4 v5, 0x5

    aput v5, v0, v4
    :try_end_34
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2b .. :try_end_34} :catch_34

    :catch_34
    sput-object v0, La8/d$c;->a:[I

    invoke-static {}, Lcom/flipkart/android/voice/flippi/tts/TTSValidity;->values()[Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_3d
    sget-object v4, Lcom/flipkart/android/voice/flippi/tts/TTSValidity;->VALID:Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v1, v0, v4
    :try_end_45
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3d .. :try_end_45} :catch_45

    :catch_45
    :try_start_45
    sget-object v1, Lcom/flipkart/android/voice/flippi/tts/TTSValidity;->AUTOLISTEN:Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aput v2, v0, v1
    :try_end_4d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_45 .. :try_end_4d} :catch_4d

    :catch_4d
    :try_start_4d
    sget-object v1, Lcom/flipkart/android/voice/flippi/tts/TTSValidity;->INVALID:Lcom/flipkart/android/voice/flippi/tts/TTSValidity;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aput v3, v0, v1
    :try_end_55
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4d .. :try_end_55} :catch_55

    :catch_55
    sput-object v0, La8/d$c;->b:[I

    return-void
.end method
