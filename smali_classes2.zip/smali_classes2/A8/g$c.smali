.class public final La8/g$c;
.super La8/g;
.source "FlippiState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field private b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

.field private final c:Z

.field private final d:La8/l;


# direct methods
.method public constructor <init>(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ZLa8/l;)V
    .registers 5

    const-string v0, "trackingValue"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La8/g;-><init>(Lkotlin/jvm/internal/i;)V

    iput-object p1, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    iput-boolean p2, p0, La8/g$c;->c:Z

    iput-object p3, p0, La8/g$c;->d:La8/l;

    return-void
.end method

.method public static synthetic copy$default(La8/g$c;Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ZLa8/l;ILjava/lang/Object;)La8/g$c;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget-object p1, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget-boolean p2, p0, La8/g$c;->c:Z

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget-object p3, p0, La8/g$c;->d:La8/l;

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, La8/g$c;->copy(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ZLa8/l;)La8/g$c;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;
    .registers 2

    iget-object v0, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    return-object v0
.end method

.method public final component2()Z
    .registers 2

    iget-boolean v0, p0, La8/g$c;->c:Z

    return v0
.end method

.method public final component3()La8/l;
    .registers 2

    iget-object v0, p0, La8/g$c;->d:La8/l;

    return-object v0
.end method

.method public final copy(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ZLa8/l;)La8/g$c;
    .registers 5

    const-string v0, "trackingValue"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, La8/g$c;

    invoke-direct {v0, p1, p2, p3}, La8/g$c;-><init>(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ZLa8/l;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La8/g$c;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La8/g$c;

    iget-object v1, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    iget-object v3, p1, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-boolean v1, p0, La8/g$c;->c:Z

    iget-boolean v3, p1, La8/g$c;->c:Z

    if-eq v1, v3, :cond_1e

    return v2

    :cond_1e
    iget-object v1, p0, La8/g$c;->d:La8/l;

    iget-object p1, p1, La8/g$c;->d:La8/l;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_29

    return v2

    :cond_29
    return v0
.end method

.method public final getTrackingValue()La8/l;
    .registers 2

    iget-object v0, p0, La8/g$c;->d:La8/l;

    return-object v0
.end method

.method public final getTranscription()Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;
    .registers 2

    iget-object v0, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    return-object v0
.end method

.method public hashCode()I
    .registers 3

    iget-object v0, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_a

    :cond_6
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_a
    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, La8/g$c;->c:Z

    if-eqz v1, :cond_11

    const/4 v1, 0x1

    :cond_11
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, La8/g$c;->d:La8/l;

    invoke-virtual {v1}, La8/l;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public final isLast()Z
    .registers 2

    iget-boolean v0, p0, La8/g$c;->c:Z

    return v0
.end method

.method public final setTranscription(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)V
    .registers 2

    iput-object p1, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Fetching(transcription="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La8/g$c;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", isLast="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, La8/g$c;->c:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", trackingValue="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La8/g$c;->d:La8/l;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
