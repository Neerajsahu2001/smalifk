.class public final La8/h;
.super Ljava/lang/Object;
.source "FlippiUtil.kt"


# static fields
.field public static final a:La8/h;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, La8/h;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La8/h;->a:La8/h;

    return-void
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    sget-object v0, Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent;->Companion:Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent$Companion;

    const/4 v1, 0x4

    new-array v1, v1, [LUn/j;

    new-instance v2, LUn/j;

    const-string v3, "ua"

    const-string v4, "Voice_assistant_initiation"

    invoke-direct {v2, v3, v4}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x0

    aput-object v2, v1, v3

    new-instance v2, LUn/j;

    const-string v3, "asid"

    invoke-direct {v2, v3, p1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x1

    aput-object v2, v1, p1

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->generateImpressionId()Ljava/lang/String;

    move-result-object p1

    new-instance v2, LUn/j;

    const-string v3, "iid"

    invoke-direct {v2, v3, p1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x2

    aput-object v2, v1, p1

    const-string p1, "GROCERY"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_34

    const-string p1, "GroceryAssistantV2"

    goto :goto_36

    :cond_34
    const-string p1, "DiscoveryAssistant"

    :goto_36
    new-instance p2, LUn/j;

    const-string v2, "at"

    invoke-direct {p2, v2, p1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x3

    aput-object p2, v1, p1

    invoke-static {v1}, Lkotlin/collections/J;->i([LUn/j;)Ljava/util/Map;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent$Companion;->construct(Ljava/util/Map;)Lcom/flipkart/android/datagovernance/events/voice/VoiceAssistantUsedEvent;

    move-result-object p1

    if-eqz p1, :cond_4d

    invoke-static {p0, p1}, La8/h;->ingestFdpEvent(Landroid/content/Context;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    :cond_4d
    return-void
.end method

.method public static final getController(Landroid/content/Context;La8/c;)La8/d;
    .registers 4

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "flippiCallback"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.init.FlipkartApplication"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {v0, p0, p1}, Lcom/flipkart/android/init/FlipkartApplication;->getFlippiController(Landroid/content/Context;La8/c;)La8/d;

    move-result-object p0

    const-string p1, "context.applicationConte\u2026(context, flippiCallback)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static final getFlippiWidgetData(LNf/b;Lcom/flipkart/android/gson/Serializer;)LWg/d;
    .registers 4

    const/4 v0, 0x0

    if-eqz p0, :cond_6

    iget-object p0, p0, LNf/b;->a:Ljava/util/List;

    goto :goto_7

    :cond_6
    move-object p0, v0

    :goto_7
    if-eqz p0, :cond_1e

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-nez v1, :cond_10

    goto :goto_1e

    :cond_10
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljg/K;

    sget-object v0, La8/h;->a:La8/h;

    invoke-virtual {v0, p0, p1}, La8/h;->getFlippiWidgetDataFromSlotData(Ljg/K;Lcom/flipkart/android/gson/Serializer;)LWg/d;

    move-result-object p0

    return-object p0

    :cond_1e
    :goto_1e
    return-object v0
.end method

.method public static final getFlippiWidgetData(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;Lcom/flipkart/android/gson/Serializer;)LWg/d;
    .registers 4

    const-string v0, "assistPayload"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getConversationId()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2e

    invoke-virtual {p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getSlots()Lxk/m;

    move-result-object v0

    if-nez v0, :cond_13

    goto :goto_2e

    :cond_13
    invoke-virtual {p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getSlots()Lxk/m;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lxk/m;->v(I)Lxk/p;

    move-result-object p0

    const-string v0, "assistPayload.getSlots()[0]"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p1, :cond_27

    invoke-virtual {p1, p0}, Lcom/flipkart/android/gson/Serializer;->deserializeSlotData(Lxk/p;)Ljg/K;

    move-result-object v1

    :cond_27
    sget-object p0, La8/h;->a:La8/h;

    invoke-virtual {p0, v1, p1}, La8/h;->getFlippiWidgetDataFromSlotData(Ljg/K;Lcom/flipkart/android/gson/Serializer;)LWg/d;

    move-result-object p0

    return-object p0

    :cond_2e
    :goto_2e
    return-object v1
.end method

.method public static final getPanelWidgetKey(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    const-string v0, "marketplace"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "GROCERY"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_10

    const-string p0, "GroceryAssistantPanel"

    goto :goto_12

    :cond_10
    const-string p0, "VoiceSearchAssistantPanel"

    :goto_12
    return-object p0
.end method

.method public static final handlePageLoaded(Landroid/content/Context;Landroid/app/Activity;)V
    .registers 3

    if-eqz p0, :cond_15

    invoke-static {p0}, La8/h;->isControllerActive(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_15

    instance-of v0, p1, La8/c;

    if-eqz v0, :cond_15

    check-cast p1, La8/c;

    invoke-static {p0, p1}, La8/h;->getController(Landroid/content/Context;La8/c;)La8/d;

    move-result-object p0

    invoke-virtual {p0}, La8/d;->handlePageLoadedEvent()V

    :cond_15
    return-void
.end method

.method public static final ingestFdpEvent(Landroid/content/Context;Lcom/flipkart/android/datagovernance/events/DGEvent;)V
    .registers 3

    const-string v0, "event"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p0, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    if-eqz v0, :cond_1c

    check-cast p0, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    invoke-interface {p0}, Lcom/flipkart/android/datagovernance/NavigationStateHolder;->getNavigationState()Lcom/flipkart/android/datagovernance/GlobalContextInfo;

    move-result-object p0

    if-eqz p0, :cond_1c

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v0

    invoke-virtual {p0}, Lcom/flipkart/android/datagovernance/GlobalContextInfo;->getCurrentNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object p0

    invoke-virtual {v0, p0, p1}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEvent(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    :cond_1c
    return-void
.end method

.method public static final ingestOmnitureEvents(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    const-string v0, "assistantSessionId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "marketplace"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p0, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    if-eqz v0, :cond_4e

    instance-of v0, p0, La8/c;

    if-eqz v0, :cond_4e

    move-object v0, p0

    check-cast v0, La8/c;

    invoke-static {p0, v0}, La8/h;->getController(Landroid/content/Context;La8/c;)La8/d;

    move-result-object v0

    invoke-virtual {v0}, La8/d;->getCurrentSessionID()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, p1, v2}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_4e

    const-string v1, "GROCERY"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_33

    invoke-static {p1}, LS3/x;->sendGrocerySessionCreated(Ljava/lang/String;)V

    invoke-static {p0, p1, p2}, La8/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_4b

    :cond_33
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v1

    if-eqz v1, :cond_48

    iget-boolean v1, v1, Lcom/flipkart/android/configmodel/t2;->B:Z

    if-ne v1, v2, :cond_48

    invoke-static {p1}, LS3/x;->sendIntegratedAssistantSessionCreated(Ljava/lang/String;)V

    invoke-static {p0, p1, p2}, La8/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_4b

    :cond_48
    invoke-static {p1}, LS3/x;->sendAssistantSessionCreated(Ljava/lang/String;)V

    :goto_4b
    invoke-virtual {v0, p1}, La8/d;->setCurrentSessionID(Ljava/lang/String;)V

    :cond_4e
    return-void
.end method

.method public static final isControllerActive(Landroid/content/Context;)Z
    .registers 2

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    instance-of v0, v0, Lcom/flipkart/android/init/FlipkartApplication;

    if-eqz v0, :cond_20

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v0, "null cannot be cast to non-null type com.flipkart.android.init.FlipkartApplication"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {p0}, Lcom/flipkart/android/init/FlipkartApplication;->isFlippiControllerActive()Z

    move-result p0

    if-eqz p0, :cond_20

    const/4 p0, 0x1

    goto :goto_21

    :cond_20
    const/4 p0, 0x0

    :goto_21
    return p0
.end method

.method public static final observeFlippiState(Landroid/content/Context;La8/c;Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "La8/c;",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "La8/g;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "flippiCallback"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "lifeCycleOwner"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "stateObserver"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, La8/h;->getController(Landroid/content/Context;La8/c;)La8/d;

    move-result-object p0

    invoke-virtual {p0, p2, p3}, La8/d;->attachFlippiStateObserver(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public static final observeFlippiTts(Landroid/content/Context;La8/c;Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "La8/c;",
            "Landroidx/lifecycle/A;",
            "Landroidx/lifecycle/J<",
            "Lcom/flipkart/android/voice/flippi/tts/TtsEvent;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "flippiCallback"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "lifeCycleOwner"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ttsObserver"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, La8/h;->getController(Landroid/content/Context;La8/c;)La8/d;

    move-result-object p0

    invoke-virtual {p0, p2, p3}, La8/d;->attachTtsEventListener(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public static final processFlippiResponse(Landroid/content/Context;LNf/b;)V
    .registers 4

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    instance-of v0, v0, Lcom/flipkart/android/init/FlipkartApplication;

    if-eqz v0, :cond_3e

    invoke-static {p0}, La8/h;->isControllerActive(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_14

    goto :goto_3e

    :cond_14
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.init.FlipkartApplication"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {v0}, Lcom/flipkart/android/init/FlipkartApplication;->getActivity()Landroid/app/Activity;

    move-result-object v1

    instance-of v1, v1, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    if-eqz v1, :cond_33

    invoke-virtual {v0}, Lcom/flipkart/android/init/FlipkartApplication;->getActivity()Landroid/app/Activity;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.voice.flippi.FlippiCallback"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, La8/c;

    goto :goto_34

    :cond_33
    const/4 v0, 0x0

    :goto_34
    if-nez v0, :cond_37

    return-void

    :cond_37
    invoke-static {p0, v0}, La8/h;->getController(Landroid/content/Context;La8/c;)La8/d;

    move-result-object p0

    invoke-virtual {p0, p1}, La8/d;->processFlippiResponse(LNf/b;)V

    :cond_3e
    :goto_3e
    return-void
.end method


# virtual methods
.method public final getAutoListenDelay()J
    .registers 3

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v0

    if-eqz v0, :cond_f

    iget-object v0, v0, Lcom/flipkart/android/configmodel/t2;->J:Ljava/lang/Long;

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    if-nez v0, :cond_15

    const-wide/16 v0, 0x190

    goto :goto_19

    :cond_15
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    :goto_19
    return-wide v0
.end method

.method public final getFlippiWidgetDataFromSlotData(Ljg/K;Lcom/flipkart/android/gson/Serializer;)LWg/d;
    .registers 6

    const/4 v0, 0x0

    if-eqz p1, :cond_36

    instance-of v1, p1, Ljg/h0;

    if-nez v1, :cond_8

    goto :goto_36

    :cond_8
    check-cast p1, Ljg/h0;

    iget-object p1, p1, Ljg/h0;->f:Ljg/e0;

    if-eqz p1, :cond_11

    iget-object v1, p1, Ljg/e0;->i:Ljg/g0;

    goto :goto_12

    :cond_11
    move-object v1, v0

    :goto_12
    if-nez v1, :cond_15

    return-object v0

    :cond_15
    instance-of v2, v1, LJa/i;

    if-eqz v2, :cond_2f

    if-eqz p1, :cond_1e

    iget-object p1, p1, Ljg/e0;->i:Ljg/g0;

    goto :goto_1f

    :cond_1e
    move-object p1, v0

    :goto_1f
    const-string v1, "null cannot be cast to non-null type com.flipkart.mapi.model.DefaultWidgetData"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, LJa/i;

    if-eqz p2, :cond_2e

    iget-object p1, p1, LJa/i;->a:Lxk/p;

    invoke-virtual {p2, p1}, Lcom/flipkart/android/gson/Serializer;->deserializeFlippiWidgetData(Lxk/p;)LWg/d;

    move-result-object v0

    :cond_2e
    return-object v0

    :cond_2f
    instance-of p1, v1, LWg/d;

    if-eqz p1, :cond_36

    check-cast v1, LWg/d;

    return-object v1

    :cond_36
    :goto_36
    return-object v0
.end method

.method public final getWidgetKeyInfo(Ljava/lang/String;)Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;
    .registers 4

    const-string v0, "marketplace"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v0

    if-eqz v0, :cond_14

    iget-boolean v0, v0, Lcom/flipkart/android/configmodel/t2;->B:Z

    goto :goto_15

    :cond_14
    const/4 v0, 0x0

    :goto_15
    const-string v1, "GROCERY"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x0

    if-eqz p1, :cond_26

    new-instance p1, Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;

    const-string v0, "GroceryAssistant_Permission_popup"

    invoke-direct {p1, v0, v1, v1}, Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_37

    :cond_26
    if-eqz v0, :cond_30

    new-instance p1, Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;

    const-string v0, "VoiceSearchAssistant_Permission_popup"

    invoke-direct {p1, v0, v1, v1}, Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_37

    :cond_30
    new-instance p1, Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;

    const-string v0, "VoiceAssistant_Permission_popup"

    invoke-direct {p1, v0, v1, v1}, Lcom/flipkart/android/permissions/RationaleWidgetKeyInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_37
    return-object p1
.end method

.method public final isDormant(LLe/f;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LLe/f<",
            "Lmf/r;",
            ">;)Z"
        }
    .end annotation

    if-eqz p1, :cond_b

    iget-object p1, p1, LLe/f;->c:LMe/R3;

    check-cast p1, Lmf/r;

    if-eqz p1, :cond_b

    iget-object p1, p1, Lmf/r;->g:Ljava/lang/String;

    goto :goto_c

    :cond_b
    const/4 p1, 0x0

    :goto_c
    const-string v0, "DORMANT"

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method
