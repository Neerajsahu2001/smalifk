.class public final La8/e$d;
.super La8/e;
.source "FlippiPanelState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# static fields
.field public static final a:La8/e$d;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/e$d;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/e;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, La8/e$d;->a:La8/e$d;

    return-void
.end method
