.class public interface abstract La8/c;
.super Ljava/lang/Object;
.source "FlippiCallback.java"


# virtual methods
.method public abstract checkAndAskPermission(ILcom/flipkart/android/permissions/RationaleWidgetKeyInfo;)Z
.end method

.method public abstract executeDmAction(Lcom/flipkart/mapi/model/component/data/renderables/b;Lcom/flipkart/android/newmultiwidget/a;Z)V
.end method

.method public abstract getContext()Landroid/content/Context;
.end method

.method public abstract getCurrentScreenUri()Ljava/lang/String;
.end method
