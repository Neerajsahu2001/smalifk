.class public final La8/k;
.super Ljava/lang/Object;
.source "SpeechToTextCallback.kt"

# interfaces
.implements Lcom/flipkart/android/voice/s2tlibrary/SpeechToText$a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La8/k$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/os/Handler;

.field private final b:Lcom/flipkart/android/gson/Serializer;

.field private c:La8/k$a;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private final f:Z

.field private final g:Z

.field private final h:Z

.field private final i:Ljava/lang/String;

.field private j:Ljava/lang/String;

.field private k:Ljava/lang/String;

.field private l:Landroidx/media3/ui/h;

.field private m:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

.field private n:J


# direct methods
.method public constructor <init>(Landroid/os/Handler;Lcom/flipkart/android/gson/Serializer;La8/k$a;Ljava/lang/String;Ljava/lang/String;ZZZ)V
    .registers 10

    const-string v0, "handler"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "serializer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "marketplace"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/k;->a:Landroid/os/Handler;

    iput-object p2, p0, La8/k;->b:Lcom/flipkart/android/gson/Serializer;

    iput-object p3, p0, La8/k;->c:La8/k$a;

    iput-object p4, p0, La8/k;->d:Ljava/lang/String;

    iput-object p5, p0, La8/k;->e:Ljava/lang/String;

    iput-boolean p6, p0, La8/k;->f:Z

    iput-boolean p7, p0, La8/k;->g:Z

    iput-boolean p8, p0, La8/k;->h:Z

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "randomUUID().toString()"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, La8/k;->i:Ljava/lang/String;

    const-string p1, ""

    iput-object p1, p0, La8/k;->j:Ljava/lang/String;

    iput-object p1, p0, La8/k;->k:Ljava/lang/String;

    return-void
.end method

.method public static a(La8/k;)V
    .registers 2

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/k;->m:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    invoke-direct {p0, v0}, La8/k;->b(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;)V

    return-void
.end method

.method private final b(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;)V
    .registers 5

    if-eqz p1, :cond_18

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    instance-of v0, v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    if-nez v0, :cond_b

    goto :goto_18

    :cond_b
    iget-object v0, p0, La8/k;->c:La8/k$a;

    if-eqz v0, :cond_18

    invoke-direct {p0}, La8/k;->c()La8/l;

    move-result-object v1

    iget-object v2, p0, La8/k;->e:Ljava/lang/String;

    invoke-interface {v0, p1, v2, v1}, La8/k$a;->onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V

    :cond_18
    :goto_18
    return-void
.end method

.method private final c()La8/l;
    .registers 9

    new-instance v7, La8/l;

    iget-object v2, p0, La8/k;->k:Ljava/lang/String;

    iget-object v3, p0, La8/k;->j:Ljava/lang/String;

    iget-boolean v5, p0, La8/k;->h:Z

    iget-boolean v6, p0, La8/k;->f:Z

    iget-object v1, p0, La8/k;->i:Ljava/lang/String;

    iget-boolean v4, p0, La8/k;->g:Z

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, La8/l;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V

    return-object v7
.end method


# virtual methods
.method public final emitStaticPanelResponse(Ljava/lang/String;)V
    .registers 9

    const-string v0, "staticPanelKey"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v3, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    invoke-direct {v3}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;-><init>()V

    sget-object v1, Lj8/e;->a:Lj8/e;

    iget-object v5, p0, La8/k;->i:Ljava/lang/String;

    iget-object v6, p0, La8/k;->d:Ljava/lang/String;

    iget-object v2, p0, La8/k;->b:Lcom/flipkart/android/gson/Serializer;

    move-object v4, p1

    invoke-virtual/range {v1 .. v6}, Lj8/e;->getStaticPanelContent(Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    move-result-object p1

    if-eqz p1, :cond_1c

    invoke-virtual {p0, p1}, La8/k;->onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;)V

    :cond_1c
    return-void
.end method

.method public final getAssistantSessionId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/k;->d:Ljava/lang/String;

    return-object v0
.end method

.method public final getHandler()Landroid/os/Handler;
    .registers 2

    iget-object v0, p0, La8/k;->a:Landroid/os/Handler;

    return-object v0
.end method

.method public final getInstanceId()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/k;->i:Ljava/lang/String;

    return-object v0
.end method

.method public final getListener()La8/k$a;
    .registers 2

    iget-object v0, p0, La8/k;->c:La8/k$a;

    return-object v0
.end method

.method public final getMarketplace()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/k;->e:Ljava/lang/String;

    return-object v0
.end method

.method public final getSerializer()Lcom/flipkart/android/gson/Serializer;
    .registers 2

    iget-object v0, p0, La8/k;->b:Lcom/flipkart/android/gson/Serializer;

    return-object v0
.end method

.method public final isAutoListen()Z
    .registers 2

    iget-boolean v0, p0, La8/k;->f:Z

    return v0
.end method

.method public final isFirstHandshake()Z
    .registers 2

    iget-boolean v0, p0, La8/k;->g:Z

    return v0
.end method

.method public final isFlippiSpeaking()Z
    .registers 2

    iget-boolean v0, p0, La8/k;->h:Z

    return v0
.end method

.method public onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;)V
    .registers 13

    const-string v0, "response"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getAction()Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    move-result-object v0

    if-eqz v0, :cond_155

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    if-nez v0, :cond_13

    goto/16 :goto_155

    :cond_13
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getAppSessionId()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1b

    iput-object v0, p0, La8/k;->k:Ljava/lang/String;

    :cond_1b
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getAction()Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    move-result-object v0

    sget-object v1, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->ERROR:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    iget-object v2, p0, La8/k;->a:Landroid/os/Handler;

    iget-object v3, p0, La8/k;->e:Ljava/lang/String;

    if-ne v0, v1, :cond_75

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    instance-of v0, v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;

    if-eqz v0, :cond_75

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.voice.s2tlibrary.common.model.params.ErrorPayload"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getErrNum()I

    move-result v1

    const/16 v4, 0x23

    if-ne v1, v4, :cond_5c

    sget-object v5, Lj8/e;->a:Lj8/e;

    iget-object v6, p0, La8/k;->b:Lcom/flipkart/android/gson/Serializer;

    iget-object v8, p0, La8/k;->e:Ljava/lang/String;

    iget-object v9, p0, La8/k;->i:Ljava/lang/String;

    iget-object v10, p0, La8/k;->d:Ljava/lang/String;

    move-object v7, p1

    invoke-virtual/range {v5 .. v10}, Lj8/e;->getStaticPanelContent(Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    move-result-object v0

    if-eqz v0, :cond_75

    sget-object p1, La8/b;->a:La8/b;

    invoke-virtual {p1, v3}, La8/b;->logStaticPanelShownEvent(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, La8/k;->onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;)V

    return-void

    :cond_5c
    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/ErrorPayload;->getErrNum()I

    move-result v0

    const/16 v1, 0x1f

    if-ne v0, v1, :cond_75

    iget-object v0, p0, La8/k;->m:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    if-eqz v0, :cond_75

    iget-object v0, p0, La8/k;->l:Landroidx/media3/ui/h;

    if-eqz v0, :cond_75

    invoke-virtual {v2, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, La8/k;->m:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    invoke-direct {p0, p1}, La8/k;->b(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;)V

    return-void

    :cond_75
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getAction()Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    move-result-object v0

    sget-object v1, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->TRANSCRIPTION:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    if-ne v0, v1, :cond_b1

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    instance-of v0, v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;

    if-eqz v0, :cond_b1

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.voice.s2tlibrary.common.model.params.TranscriptionPayload"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/TranscriptionPayload;->getTranscriptions()[Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    move-result-object v0

    const-string v1, "transcriptions"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v1, v0

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v1, :cond_a0

    const/4 v1, 0x1

    goto :goto_a1

    :cond_a0
    const/4 v1, 0x0

    :goto_a1
    xor-int/2addr v1, v5

    if-eqz v1, :cond_b1

    aget-object v0, v0, v4

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;->getText()Ljava/lang/String;

    move-result-object v0

    const-string v1, "transcriptions[0].text"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, La8/k;->j:Ljava/lang/String;

    :cond_b1
    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getAction()Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    move-result-object v0

    sget-object v1, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->INTERMEDIATE:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    if-ne v0, v1, :cond_13e

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    instance-of v0, v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    if-eqz v0, :cond_13e

    iget-object v0, p0, La8/k;->l:Landroidx/media3/ui/h;

    if-eqz v0, :cond_c8

    invoke-virtual {v2, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_c8
    iput-object p1, p0, La8/k;->m:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.voice.s2tlibrary.common.model.params.AssistPayload"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getThresholdInfo()Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;

    move-result-object v1

    if-eqz v1, :cond_13d

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iget-wide v6, p0, La8/k;->n:J

    sub-long/2addr v4, v6

    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;->getThreshold()J

    move-result-wide v6

    sub-long/2addr v6, v4

    invoke-virtual {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/ThresholdInfo;->getThreshold()J

    move-result-wide v8

    cmp-long v1, v4, v8

    if-gez v1, :cond_13a

    iget-object v0, v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->slots:Lxk/m;

    if-eqz v0, :cond_12e

    invoke-virtual {v0}, Lxk/m;->size()I

    move-result v0

    if-nez v0, :cond_fa

    goto :goto_12e

    :cond_fa
    new-instance v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    invoke-direct {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;-><init>()V

    sget-object v1, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->RENDER:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    invoke-virtual {v0, v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getAppSessionId()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setAppSessionId(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getParam()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setParam(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getUserId()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setUserId(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->getIndex()I

    move-result p1

    invoke-virtual {v0, p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setIndex(I)V

    invoke-virtual {v0, v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;)V

    iget-object p1, p0, La8/k;->c:La8/k$a;

    if-eqz p1, :cond_12e

    invoke-direct {p0}, La8/k;->c()La8/l;

    move-result-object v1

    invoke-interface {p1, v0, v3, v1}, La8/k$a;->onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V

    :cond_12e
    :goto_12e
    new-instance p1, Landroidx/media3/ui/h;

    const/4 v0, 0x4

    invoke-direct {p1, v0, p0}, Landroidx/media3/ui/h;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, La8/k;->l:Landroidx/media3/ui/h;

    invoke-virtual {v2, p1, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_13d

    :cond_13a
    invoke-direct {p0, p1}, La8/k;->b(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;)V

    :cond_13d
    :goto_13d
    return-void

    :cond_13e
    iget-object v0, p0, La8/k;->l:Landroidx/media3/ui/h;

    if-eqz v0, :cond_14a

    invoke-virtual {v2, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    iput-object v0, p0, La8/k;->m:Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    iput-object v0, p0, La8/k;->l:Landroidx/media3/ui/h;

    :cond_14a
    iget-object v0, p0, La8/k;->c:La8/k$a;

    if-eqz v0, :cond_155

    invoke-direct {p0}, La8/k;->c()La8/l;

    move-result-object v1

    invoke-interface {v0, p1, v3, v1}, La8/k$a;->onAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V

    :cond_155
    :goto_155
    return-void
.end method

.method public onAmplitudeChanged(D)V
    .registers 4

    iget-object v0, p0, La8/k;->c:La8/k$a;

    if-eqz v0, :cond_7

    invoke-interface {v0, p1, p2}, La8/k$a;->onAmplitudeChanged(D)V

    :cond_7
    return-void
.end method

.method public onPacketCreated(I)V
    .registers 3

    iget-object v0, p0, La8/k;->c:La8/k$a;

    if-eqz v0, :cond_7

    invoke-interface {v0, p1}, La8/k$a;->onPacketCreated(I)V

    :cond_7
    return-void
.end method

.method public onPacketUploadResult(IZ)V
    .registers 4

    iget-object v0, p0, La8/k;->c:La8/k$a;

    if-eqz v0, :cond_7

    invoke-interface {v0, p1, p2}, La8/k$a;->onPacketUploadResult(IZ)V

    :cond_7
    return-void
.end method

.method public onRecordingEnd(Lcom/flipkart/android/voice/s2tlibrary/common/model/RecordingStopper;)V
    .registers 4

    const-string v0, "stoppedBy"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, La8/k;->n:J

    iget-object p1, p0, La8/k;->c:La8/k$a;

    if-eqz p1, :cond_16

    invoke-direct {p0}, La8/k;->c()La8/l;

    move-result-object v0

    invoke-interface {p1, v0}, La8/k$a;->onRecordingEnd(La8/l;)V

    :cond_16
    return-void
.end method

.method public onTransactionEnd()V
    .registers 1

    return-void
.end method

.method public final reset()V
    .registers 2

    const/4 v0, 0x0

    iput-object v0, p0, La8/k;->c:La8/k$a;

    return-void
.end method

.method public final setListener(La8/k$a;)V
    .registers 2

    iput-object p1, p0, La8/k;->c:La8/k$a;

    return-void
.end method
