.class final La8/d$e;
.super Lkotlin/jvm/internal/p;
.source "FlippiController.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La8/d;->g(Lmf/D;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:La8/d;

.field final synthetic b:Lmf/D;


# direct methods
.method constructor <init>(La8/d;Lmf/D;)V
    .registers 3

    iput-object p1, p0, La8/d$e;->a:La8/d;

    iput-object p2, p0, La8/d$e;->b:Lmf/D;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, La8/d$e;->invoke()V

    sget-object v0, LUn/r;->a:LUn/r;

    return-object v0
.end method

.method public final invoke()V
    .registers 4

    iget-object v0, p0, La8/d$e;->b:Lmf/D;

    iget-object v0, v0, Lmf/D;->c:Ljava/lang/String;

    iget-object v1, p0, La8/d$e;->a:La8/d;

    const/4 v2, 0x1

    invoke-static {v1, v2, v0}, La8/d;->access$setFlippiStateAutolisten(La8/d;ZLjava/lang/String;)V

    return-void
.end method
