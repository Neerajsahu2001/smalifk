.class public abstract La8/e;
.super Ljava/lang/Object;
.source "FlippiPanelState.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La8/e$c;,
        La8/e$d;,
        La8/e$b;,
        La8/e$e;,
        La8/e$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, La8/e;-><init>()V

    return-void
.end method
