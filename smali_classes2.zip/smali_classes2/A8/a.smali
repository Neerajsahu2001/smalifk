.class public final La8/a;
.super Ljava/lang/Object;
.source "AssistPayloadManagerV2.kt"


# static fields
.field public static final a:La8/a;

.field private static b:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

.field private static c:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, La8/a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La8/a;->a:La8/a;

    return-void
.end method


# virtual methods
.method public final clear()V
    .registers 2

    const/4 v0, 0x0

    sput-object v0, La8/a;->c:Ljava/lang/String;

    sput-object v0, La8/a;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    return-void
.end method

.method public final getAssistPayload()Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;
    .registers 3

    sget-object v0, La8/a;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    const/4 v1, 0x0

    sput-object v1, La8/a;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    return-object v0
.end method

.method public final getConversationId()Ljava/lang/String;
    .registers 2

    sget-object v0, La8/a;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final setAssistPayload(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;)V
    .registers 3

    const-string v0, "assistPayload"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object p1, La8/a;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getConversationId()Ljava/lang/String;

    move-result-object p1

    sput-object p1, La8/a;->c:Ljava/lang/String;

    return-void
.end method

.method public final setConversationId(Ljava/lang/String;)V
    .registers 2

    if-eqz p1, :cond_4

    sput-object p1, La8/a;->c:Ljava/lang/String;

    :cond_4
    return-void
.end method
