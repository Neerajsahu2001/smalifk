.class public final La8/d$b;
.super Ljava/lang/Object;
.source "FlippiController.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getCurrentAssistantSessionId()Ljava/lang/String;
    .registers 2

    invoke-static {}, La8/d;->access$getCurrentAssistantSessionId$cp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final setCurrentAssistantSessionId(Ljava/lang/String;)V
    .registers 2

    invoke-static {p1}, La8/d;->access$setCurrentAssistantSessionId$cp(Ljava/lang/String;)V

    return-void
.end method
