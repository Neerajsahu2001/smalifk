.class public final La8/g$d;
.super La8/g;
.source "FlippiState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# static fields
.field public static final b:La8/g$d;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/g$d;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/g;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, La8/g$d;->b:La8/g$d;

    return-void
.end method
