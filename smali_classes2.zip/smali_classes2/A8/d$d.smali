.class final La8/d$d;
.super Lkotlin/jvm/internal/p;
.source "FlippiController.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La8/d;->handleDialogResponse(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:La8/d;

.field final synthetic b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;

.field final synthetic c:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

.field final synthetic d:Ljava/lang/String;


# direct methods
.method constructor <init>(La8/d;Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;Ljava/lang/String;)V
    .registers 5

    iput-object p1, p0, La8/d$d;->a:La8/d;

    iput-object p2, p0, La8/d$d;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;

    iput-object p3, p0, La8/d$d;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    iput-object p4, p0, La8/d$d;->d:Ljava/lang/String;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, La8/d$d;->invoke()V

    sget-object v0, LUn/r;->a:LUn/r;

    return-object v0
.end method

.method public final invoke()V
    .registers 5

    const-string v0, "tts"

    iget-object v1, p0, La8/d$d;->b:Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La8/d$d;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;

    check-cast v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->getConversationId()Ljava/lang/String;

    move-result-object v0

    const-string v2, "payload.conversationId"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, La8/d$d;->d:Ljava/lang/String;

    iget-object v3, p0, La8/d$d;->a:La8/d;

    invoke-static {v3, v1, v0, v2}, La8/d;->access$sayTts(La8/d;Lcom/flipkart/android/voice/s2tlibrary/common/model/Tts;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
