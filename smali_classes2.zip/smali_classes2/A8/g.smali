.class public abstract La8/g;
.super Ljava/lang/Object;
.source "FlippiState.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La8/g$a;,
        La8/g$d;,
        La8/g$e;,
        La8/g$c;,
        La8/g$b;,
        La8/g$f;
    }
.end annotation


# static fields
.field public static final a:La8/g$a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/g$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/g$a;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, La8/g;->a:La8/g$a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, La8/g;-><init>()V

    return-void
.end method
