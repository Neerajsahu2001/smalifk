.class public final La8/f;
.super Ljava/lang/Object;
.source "FlippiPermissionTrackingHandler.kt"

# interfaces
.implements Lcom/flipkart/android/permissions/d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La8/f$a;
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Landroid/content/Context;

.field private final c:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/f$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/f$a;-><init>(Lkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Landroid/content/Context;)V
    .registers 4

    const-string v0, "marketplace"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "context"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/f;->a:Ljava/lang/String;

    iput-object p2, p0, La8/f;->b:Landroid/content/Context;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object p1

    if-eqz p1, :cond_1e

    iget-boolean p1, p1, Lcom/flipkart/android/configmodel/t2;->B:Z

    goto :goto_1f

    :cond_1e
    const/4 p1, 0x0

    :goto_1f
    iput-boolean p1, p0, La8/f;->c:Z

    return-void
.end method


# virtual methods
.method public actionTaken(II)V
    .registers 7

    iget-object p2, p0, La8/f;->a:Ljava/lang/String;

    const-string v0, "GROCERY"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p2, :cond_26

    if-eq p1, v2, :cond_20

    if-eq p1, v1, :cond_1a

    if-eq p1, v0, :cond_14

    goto :goto_56

    :cond_14
    const-string p1, "grocery_assistant_always_permission_denied"

    invoke-static {p1}, LS3/x;->sendGroceryPermissionEvent(Ljava/lang/String;)V

    goto :goto_56

    :cond_1a
    const-string p1, "grocery_assistant_permission_granted"

    invoke-static {p1}, LS3/x;->sendGroceryPermissionEvent(Ljava/lang/String;)V

    goto :goto_56

    :cond_20
    const-string p1, "grocery_assistant_oneTime_permission_denied"

    invoke-static {p1}, LS3/x;->sendGroceryPermissionEvent(Ljava/lang/String;)V

    goto :goto_56

    :cond_26
    const-string p2, "voice_assistant_permission_denied"

    iget-boolean v3, p0, La8/f;->c:Z

    if-eq p1, v2, :cond_4b

    if-eq p1, v1, :cond_3d

    if-eq p1, v0, :cond_31

    goto :goto_56

    :cond_31
    if-eqz v3, :cond_39

    const-string p1, "voiceSearchAssistant_always_permission_denied"

    invoke-static {p1}, LS3/x;->sendVoicePermissionDenied(Ljava/lang/String;)V

    goto :goto_56

    :cond_39
    invoke-static {p2}, LS3/x;->sendVoicePermissionDenied(Ljava/lang/String;)V

    goto :goto_56

    :cond_3d
    if-eqz v3, :cond_45

    const-string p1, "voiceSearchAssistant_permission_granted"

    invoke-static {p1}, LS3/x;->sendVoicePermissionGranted(Ljava/lang/String;)V

    goto :goto_56

    :cond_45
    const-string p1, "voice_assistant_permission_granted"

    invoke-static {p1}, LS3/x;->sendVoicePermissionGranted(Ljava/lang/String;)V

    goto :goto_56

    :cond_4b
    if-eqz v3, :cond_53

    const-string p1, "voiceSearchAssistant_oneTime_permission_denied"

    invoke-static {p1}, LS3/x;->sendVoicePermissionDenied(Ljava/lang/String;)V

    goto :goto_56

    :cond_53
    invoke-static {p2}, LS3/x;->sendVoicePermissionDenied(Ljava/lang/String;)V

    :goto_56
    return-void
.end method

.method public final getContext()Landroid/content/Context;
    .registers 2

    iget-object v0, p0, La8/f;->b:Landroid/content/Context;

    return-object v0
.end method

.method public final getMarketplace()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La8/f;->a:Ljava/lang/String;

    return-object v0
.end method

.method public trackPermissionStatus(Lcom/flipkart/android/datagovernance/events/DGEvent;)V
    .registers 2

    return-void
.end method
