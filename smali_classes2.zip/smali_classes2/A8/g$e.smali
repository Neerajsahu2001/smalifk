.class public final La8/g$e;
.super La8/g;
.source "FlippiState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# instance fields
.field private b:D

.field private c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;


# direct methods
.method public constructor <init>(DLcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)V
    .registers 5

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La8/g;-><init>(Lkotlin/jvm/internal/i;)V

    iput-wide p1, p0, La8/g$e;->b:D

    iput-object p3, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    return-void
.end method

.method public static synthetic copy$default(La8/g$e;DLcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;ILjava/lang/Object;)La8/g$e;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget-wide p1, p0, La8/g$e;->b:D

    :cond_6
    and-int/lit8 p4, p4, 0x2

    if-eqz p4, :cond_c

    iget-object p3, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    :cond_c
    invoke-virtual {p0, p1, p2, p3}, La8/g$e;->copy(DLcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)La8/g$e;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()D
    .registers 3

    iget-wide v0, p0, La8/g$e;->b:D

    return-wide v0
.end method

.method public final component2()Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;
    .registers 2

    iget-object v0, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    return-object v0
.end method

.method public final copy(DLcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)La8/g$e;
    .registers 5

    new-instance v0, La8/g$e;

    invoke-direct {v0, p1, p2, p3}, La8/g$e;-><init>(DLcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La8/g$e;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La8/g$e;

    iget-wide v3, p0, La8/g$e;->b:D

    iget-wide v5, p1, La8/g$e;->b:D

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    move-result v1

    if-eqz v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    iget-object p1, p1, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_22

    return v2

    :cond_22
    return v0
.end method

.method public final getRMS()D
    .registers 3

    iget-wide v0, p0, La8/g$e;->b:D

    return-wide v0
.end method

.method public final getTranscription()Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;
    .registers 2

    iget-object v0, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    return-object v0
.end method

.method public hashCode()I
    .registers 5

    iget-wide v0, p0, La8/g$e;->b:D

    invoke-static {v0, v1}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v0

    const/16 v2, 0x20

    ushr-long v2, v0, v2

    xor-long/2addr v0, v2

    long-to-int v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    if-nez v0, :cond_14

    const/4 v0, 0x0

    goto :goto_18

    :cond_14
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_18
    add-int/2addr v1, v0

    return v1
.end method

.method public final setRMS(D)V
    .registers 3

    iput-wide p1, p0, La8/g$e;->b:D

    return-void
.end method

.method public final setTranscription(Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;)V
    .registers 2

    iput-object p1, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Listening(rMS="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, La8/g$e;->b:D

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string v1, ", transcription="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La8/g$e;->c:Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
