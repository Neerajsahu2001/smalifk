.class public final La8/j$a;
.super LFa/e;
.source "IntegratedAssistantUtil.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La8/j;->searchWithAltInput(Lcom/flipkart/android/activity/HomeFragmentHolderActivity;LGe/b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LFa/e<",
        "Lmf/f;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:La8/d;

.field final synthetic b:Ljava/lang/String;


# direct methods
.method constructor <init>(La8/d;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, La8/j$a;->a:La8/d;

    iput-object p2, p0, La8/j$a;->b:Ljava/lang/String;

    invoke-direct {p0}, LFa/e;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "Lmf/f;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    const-string v0, "errorInfo"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/Throwable;

    const-string v1, "INTEGRATED_ASSISTANT : Alt input call failed"

    invoke-direct {v0, v1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, LO7/c;->logException(Ljava/lang/Throwable;)V

    iget v0, p2, Lwa/a;->a:I

    const/16 v1, 0x10

    iget-object v2, p0, La8/j$a;->a:La8/d;

    sget-object v3, La8/j;->a:La8/j;

    if-ne v0, v1, :cond_1f

    const/16 v0, 0x65

    invoke-static {v3, v2, v0}, La8/j;->access$setErrorState(La8/j;La8/d;I)V

    goto :goto_24

    :cond_1f
    const/16 v0, 0x20

    invoke-static {v3, v2, v0}, La8/j;->access$setErrorState(La8/j;La8/d;I)V

    :goto_24
    invoke-super {p0, p1, p2}, LFa/e;->onFailure(Lta/a;Lwa/a;)V

    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lmf/f;

    invoke-virtual {p0, p1}, La8/j$a;->onSuccess(Lmf/f;)V

    return-void
.end method

.method public onSuccess(Lmf/f;)V
    .registers 5

    if-eqz p1, :cond_5

    iget-object v0, p1, Lmf/f;->a:Ljava/lang/String;

    goto :goto_6

    :cond_5
    const/4 v0, 0x0

    :goto_6
    iget-object v1, p0, La8/j$a;->a:La8/d;

    sget-object v2, La8/j;->a:La8/j;

    if-eqz v0, :cond_1c

    invoke-static {v2, p1}, La8/j;->access$getVoiceDialogResponse(La8/j;Lmf/f;)Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    move-result-object p1

    sget-object v0, La8/l;->g:La8/l$a;

    invoke-virtual {v0}, La8/l$a;->default()La8/l;

    move-result-object v0

    iget-object v2, p0, La8/j$a;->b:Ljava/lang/String;

    invoke-virtual {v1, p1, v2, v0}, La8/d;->handleDialogResponse(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;Ljava/lang/String;La8/l;)V

    goto :goto_21

    :cond_1c
    const/16 p1, 0x6a

    invoke-static {v2, v1, p1}, La8/j;->access$setErrorState(La8/j;La8/d;I)V

    :goto_21
    return-void
.end method
