.class public final La8/g$b;
.super La8/g;
.source "FlippiState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private b:I

.field private final c:La8/l;


# direct methods
.method public constructor <init>(ILa8/l;)V
    .registers 4

    const-string v0, "trackingValue"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La8/g;-><init>(Lkotlin/jvm/internal/i;)V

    iput p1, p0, La8/g$b;->b:I

    iput-object p2, p0, La8/g$b;->c:La8/l;

    return-void
.end method

.method public static synthetic copy$default(La8/g$b;ILa8/l;ILjava/lang/Object;)La8/g$b;
    .registers 5

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_6

    iget p1, p0, La8/g$b;->b:I

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    iget-object p2, p0, La8/g$b;->c:La8/l;

    :cond_c
    invoke-virtual {p0, p1, p2}, La8/g$b;->copy(ILa8/l;)La8/g$b;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 2

    iget v0, p0, La8/g$b;->b:I

    return v0
.end method

.method public final component2()La8/l;
    .registers 2

    iget-object v0, p0, La8/g$b;->c:La8/l;

    return-object v0
.end method

.method public final copy(ILa8/l;)La8/g$b;
    .registers 4

    const-string v0, "trackingValue"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, La8/g$b;

    invoke-direct {v0, p1, p2}, La8/g$b;-><init>(ILa8/l;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La8/g$b;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La8/g$b;

    iget v1, p0, La8/g$b;->b:I

    iget v3, p1, La8/g$b;->b:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget-object v1, p0, La8/g$b;->c:La8/l;

    iget-object p1, p1, La8/g$b;->c:La8/l;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1e

    return v2

    :cond_1e
    return v0
.end method

.method public final getErrorType()I
    .registers 2

    iget v0, p0, La8/g$b;->b:I

    return v0
.end method

.method public final getTrackingValue()La8/l;
    .registers 2

    iget-object v0, p0, La8/g$b;->c:La8/l;

    return-object v0
.end method

.method public hashCode()I
    .registers 3

    iget v0, p0, La8/g$b;->b:I

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, La8/g$b;->c:La8/l;

    invoke-virtual {v1}, La8/l;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public final setErrorType(I)V
    .registers 2

    iput p1, p0, La8/g$b;->b:I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error(errorType="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, La8/g$b;->b:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", trackingValue="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La8/g$b;->c:La8/l;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
