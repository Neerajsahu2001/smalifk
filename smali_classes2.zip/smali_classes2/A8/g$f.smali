.class public final La8/g$f;
.super La8/g;
.source "FlippiState.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# static fields
.field public static final b:La8/g$f;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La8/g$f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La8/g;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, La8/g$f;->b:La8/g$f;

    return-void
.end method
