.class public final La8/j;
.super Ljava/lang/Object;
.source "IntegratedAssistantUtil.kt"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# static fields
.field public static final a:La8/j;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, La8/j;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La8/j;->a:La8/j;

    return-void
.end method

.method public static final access$getVoiceDialogResponse(La8/j;Lmf/f;)Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;
    .registers 6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p1, Lmf/f;->a:Ljava/lang/String;

    invoke-static {p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;->getValue(Ljava/lang/String;)Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;

    move-result-object p0

    new-instance v0, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;

    invoke-direct {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;-><init>()V

    iget-object v1, p1, Lmf/f;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setAppSessionId(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setAction(Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse$ActionTypes;)V

    iget-object p0, p1, Lmf/f;->d:Ljava/lang/String;

    invoke-virtual {v0, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setTts(Ljava/lang/String;)V

    iget-object p0, p1, Lmf/f;->e:Ljava/util/List;

    invoke-virtual {v0, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setTtsUrls(Ljava/util/List;)V

    iget-object p0, p1, Lmf/f;->f:Ljava/lang/String;

    invoke-virtual {v0, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setUserId(Ljava/lang/String;)V

    iget-object p0, p1, Lmf/f;->h:Ljava/lang/String;

    invoke-virtual {v0, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setMicState(Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object p0

    invoke-virtual {p0}, Lcom/flipkart/android/gson/Serializer;->getGson()Lxk/j;

    move-result-object p0

    const-string v1, "getSerializer(FlipkartAp\u2026ion.getAppContext()).gson"

    invoke-static {p0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;

    invoke-direct {v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;-><init>()V

    iget-object v2, p1, Lmf/f;->c:Lmf/b;

    if-eqz v2, :cond_93

    iget-object v3, v2, Lmf/b;->i:LGe/b;

    if-eqz v3, :cond_53

    invoke-virtual {p0, v3}, Lxk/j;->p(Ljava/lang/Object;)Lxk/p;

    move-result-object v3

    invoke-virtual {v3}, Lxk/p;->j()Lxk/s;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setAction(Lxk/s;)V

    :cond_53
    iget-object v3, v2, Lmf/b;->j:Ljava/util/Map;

    if-eqz v3, :cond_62

    invoke-virtual {p0, v3}, Lxk/j;->p(Ljava/lang/Object;)Lxk/p;

    move-result-object p0

    invoke-virtual {p0}, Lxk/p;->j()Lxk/s;

    move-result-object p0

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setHeaders(Lxk/s;)V

    :cond_62
    iget-object p0, v2, Lmf/b;->h:Ljava/lang/String;

    if-eqz p0, :cond_70

    invoke-static {p0}, Lxk/u;->b(Ljava/lang/String;)Lxk/p;

    move-result-object p0

    invoke-virtual {p0}, Lxk/p;->i()Lxk/m;

    move-result-object p0

    iput-object p0, v1, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->slots:Lxk/m;

    :cond_70
    iget-object p0, v2, Lmf/b;->a:Ljava/lang/String;

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;->setStateID(Ljava/lang/String;)V

    iget-object p0, v2, Lmf/b;->e:Ljava/lang/String;

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setConversationId(Ljava/lang/String;)V

    iget-object p0, v2, Lmf/b;->d:Ljava/lang/String;

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setOrigin(Ljava/lang/String;)V

    iget-object p0, v2, Lmf/b;->f:Ljava/lang/String;

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setChatSession(Ljava/lang/String;)V

    iget-object p0, v2, Lmf/b;->g:Ljava/lang/String;

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setFlippiPanelState(Ljava/lang/String;)V

    iget-object p0, v2, Lmf/b;->b:Ljava/lang/String;

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setDomain(Ljava/lang/String;)V

    iget-object p0, v2, Lmf/b;->c:Ljava/lang/String;

    invoke-virtual {v1, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/params/AssistPayload;->setVersion(Ljava/lang/String;)V

    :cond_93
    invoke-virtual {v0, v1}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setParam(Lcom/flipkart/android/voice/s2tlibrary/common/model/params/DialogPayload;)V

    iget-object p0, p1, Lmf/f;->g:Ljava/lang/Integer;

    if-nez p0, :cond_9c

    const/4 p0, 0x0

    goto :goto_a0

    :cond_9c
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    :goto_a0
    invoke-virtual {v0, p0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/DialogResponse;->setIndex(I)V

    return-object v0
.end method

.method public static final access$setErrorState(La8/j;La8/d;I)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La8/g$b;

    sget-object v0, La8/l;->g:La8/l$a;

    invoke-virtual {v0}, La8/l$a;->default()La8/l;

    move-result-object v0

    invoke-direct {p0, p2, v0}, La8/g$b;-><init>(ILa8/l;)V

    invoke-virtual {p1, p0}, La8/d;->setState(La8/g;)V

    new-instance p0, La8/e$a;

    invoke-direct {p0, p2}, La8/e$a;-><init>(I)V

    invoke-virtual {p1, p0}, La8/d;->setPanelState(La8/e;)V

    return-void
.end method


# virtual methods
.method public final searchWithAltInput(Lcom/flipkart/android/activity/HomeFragmentHolderActivity;LGe/b;)V
    .registers 10

    const-string v0, "activity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "action"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1, p1}, La8/h;->getController(Landroid/content/Context;La8/c;)La8/d;

    move-result-object v0

    sget-object v1, La8/g$f;->b:La8/g$f;

    invoke-virtual {v0, v1}, La8/d;->setState(La8/g;)V

    invoke-virtual {p1}, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->getCurrentScreenUri()Ljava/lang/String;

    move-result-object v1

    const-string v2, ""

    if-nez v1, :cond_1c

    move-object v1, v2

    :cond_1c
    invoke-virtual {p1}, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->getMarketplaceFromFragmentContext()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_24

    const-string p1, "FLIPKART"

    :cond_24
    invoke-virtual {v0}, La8/d;->getPanelInstanceId()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    if-nez v3, :cond_30

    move-object v3, v2

    :cond_30
    const-string v5, "instance_id"

    invoke-virtual {v4, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lq4/g;->getAppVersionName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x2d

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {}, Lq4/g;->getAppVersionNumber()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v5, "app_version"

    invoke-virtual {v4, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "source"

    const-string v5, "PILL_CLICK"

    invoke-virtual {v4, v3, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "domain"

    const-string v5, "v1"

    invoke-virtual {v4, v3, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, Lmf/n;

    invoke-direct {v3}, Lmf/n;-><init>()V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Lcom/flipkart/android/utils/n0;->getSelectedLanguage(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "EN"

    if-nez v5, :cond_76

    move-object v5, v6

    :cond_76
    iput-object v5, v3, Lmf/n;->a:Ljava/lang/String;

    invoke-virtual {v0}, La8/d;->getCurrentSessionID()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v3, Lmf/n;->b:Ljava/lang/String;

    iget-object p2, p2, LGe/b;->f:Ljava/util/Map;

    const-string v5, "pillsValue"

    invoke-interface {p2, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v3, Lmf/n;->c:Ljava/lang/String;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getSessionManager()Lcom/flipkart/android/config/f;

    move-result-object p2

    invoke-virtual {p2}, Lcom/flipkart/android/config/f;->getUserAccountId()Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_97

    move-object p2, v2

    :cond_97
    iput-object p2, v3, Lmf/n;->d:Ljava/lang/String;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getSessionStorage()Lcom/flipkart/android/config/g;

    move-result-object p2

    invoke-virtual {p2}, Lcom/flipkart/android/config/g;->getSn()Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_a4

    move-object p2, v2

    :cond_a4
    iput-object p2, v3, Lmf/n;->e:Ljava/lang/String;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2}, Lcom/flipkart/android/utils/n0;->getSelectedLanguage(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_b1

    goto :goto_b2

    :cond_b1
    move-object v6, p2

    :goto_b2
    iput-object v6, v3, Lmf/n;->f:Ljava/lang/String;

    invoke-static {}, Lq4/g;->getDeviceId()Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_bb

    move-object p2, v2

    :cond_bb
    iput-object p2, v3, Lmf/n;->g:Ljava/lang/String;

    sget-object p2, Lcom/flipkart/android/voice/FlippiRequestInfo;->Companion:Lcom/flipkart/android/voice/FlippiRequestInfo$a;

    invoke-virtual {p2}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v5

    invoke-virtual {v5}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getEndpoint()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v3, Lmf/n;->h:Ljava/lang/String;

    invoke-virtual {p2}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object v5

    invoke-virtual {v5, v1}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getPageRequestString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v3, Lmf/n;->i:Ljava/lang/String;

    invoke-virtual {v0}, La8/d;->getCurrentSessionID()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v3, Lmf/n;->j:Ljava/lang/String;

    iput-object v2, v3, Lmf/n;->k:Ljava/lang/String;

    invoke-virtual {p2}, Lcom/flipkart/android/voice/FlippiRequestInfo$a;->getInstance()Lcom/flipkart/android/voice/FlippiRequestInfo;

    move-result-object p2

    invoke-virtual {p2}, Lcom/flipkart/android/voice/FlippiRequestInfo;->getHeaders()Ljava/lang/String;

    move-result-object p2

    iput-object p2, v3, Lmf/n;->l:Ljava/lang/String;

    new-instance p2, Lxk/j;

    invoke-direct {p2}, Lxk/j;-><init>()V

    invoke-static {p2, v4}, Lcom/newrelic/agent/android/instrumentation/GsonInstrumentation;->toJson(Lxk/j;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v3, Lmf/n;->m:Ljava/lang/String;

    sget-object p2, Lj8/c;->a:Lj8/c;

    invoke-virtual {p2, p1}, Lj8/c;->getDomainName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v3, Lmf/n;->n:Ljava/lang/String;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getMAPIHttpService()LDa/b;

    move-result-object p2

    invoke-interface {p2, v3}, LDa/b;->searchWithAltInput(Lmf/n;)Lta/a;

    move-result-object p2

    invoke-virtual {v0, p2}, La8/d;->setAltInputCall(Lta/a;)V

    new-instance v1, La8/j$a;

    invoke-direct {v1, v0, p1}, La8/j$a;-><init>(La8/d;Ljava/lang/String;)V

    invoke-interface {p2, v1}, Lta/a;->enqueue(Lva/b;)V

    return-void
.end method
