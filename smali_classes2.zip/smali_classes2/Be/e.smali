.class public final LBe/e;
.super Lxk/z;
.source "CartSummaryTrackingData$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LBe/f;",
        ">;"
    }
.end annotation


# static fields
.field public static final d:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "LBe/f;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:LJn/a$t;

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "LBe/j;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LBe/f;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, LBe/e;->d:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 7

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v1, Ljava/lang/String;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-class v1, Ljava/util/Set;

    invoke-static {v1, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    new-instance v1, LJn/a$t;

    sget-object v2, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    sget-object v3, LJn/a;->a:Lxk/z;

    new-instance v4, LJn/a$s;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    invoke-direct {v1, v2, v3, v4}, LJn/a$t;-><init>(Lxk/z;Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v1, p0, LBe/e;->a:LJn/a$t;

    sget-object v1, LBe/i;->a:Lcom/google/gson/reflect/a;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v1

    iput-object v1, p0, LBe/e;->b:Lxk/z;

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LBe/e;->c:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LBe/f;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LBe/f;

    invoke-direct {v0}, LBe/f;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1b7

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_1d4

    goto/16 :goto_fb

    :sswitch_34
    const-string v2, "coinPriceListingCount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_fb

    :cond_3e
    const/16 v3, 0xf

    goto/16 :goto_fb

    :sswitch_42
    const-string v2, "itemsWithD2rCount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_fb

    :cond_4c
    const/16 v3, 0xe

    goto/16 :goto_fb

    :sswitch_50
    const-string v2, "checkoutType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_fb

    :cond_5a
    const/16 v3, 0xd

    goto/16 :goto_fb

    :sswitch_5e
    const-string v2, "nepVisibleForAtleastOneProduct"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_fb

    :cond_68
    const/16 v3, 0xc

    goto/16 :goto_fb

    :sswitch_6c
    const-string v2, "moreOffersInfo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    goto/16 :goto_fb

    :cond_76
    const/16 v3, 0xb

    goto/16 :goto_fb

    :sswitch_7a
    const-string v2, "coinBalance"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_84

    goto/16 :goto_fb

    :cond_84
    const/16 v3, 0xa

    goto/16 :goto_fb

    :sswitch_88
    const-string v2, "totalAmountSaved"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_92

    goto/16 :goto_fb

    :cond_92
    const/16 v3, 0x9

    goto/16 :goto_fb

    :sswitch_96
    const-string v2, "totalShippingCost"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a0

    goto/16 :goto_fb

    :cond_a0
    const/16 v3, 0x8

    goto/16 :goto_fb

    :sswitch_a4
    const-string v2, "addressId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ad

    goto :goto_fb

    :cond_ad
    const/4 v3, 0x7

    goto :goto_fb

    :sswitch_af
    const-string v2, "recommendationMap"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b8

    goto :goto_fb

    :cond_b8
    const/4 v3, 0x6

    goto :goto_fb

    :sswitch_ba
    const-string v2, "bottomBarSubPriceDescription"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c3

    goto :goto_fb

    :cond_c3
    const/4 v3, 0x5

    goto :goto_fb

    :sswitch_c5
    const-string v2, "eventList"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ce

    goto :goto_fb

    :cond_ce
    const/4 v3, 0x4

    goto :goto_fb

    :sswitch_d0
    const-string v2, "pincode"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d9

    goto :goto_fb

    :cond_d9
    const/4 v3, 0x3

    goto :goto_fb

    :sswitch_db
    const-string v2, "totalCost"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e4

    goto :goto_fb

    :cond_e4
    const/4 v3, 0x2

    goto :goto_fb

    :sswitch_e6
    const-string v2, "sflItemCount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ef

    goto :goto_fb

    :cond_ef
    const/4 v3, 0x1

    goto :goto_fb

    :sswitch_f1
    const-string v2, "itemsWithOffersAvailableCount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_fa

    goto :goto_fb

    :cond_fa
    const/4 v3, 0x0

    :goto_fb
    packed-switch v3, :pswitch_data_216

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_103
    iget v1, v0, LBh/x;->g:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBh/x;->g:I

    goto/16 :goto_1d

    :pswitch_10d
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, LBe/f;->k:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_119
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/f;->o:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_125
    iget-boolean v1, v0, LBe/f;->p:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LBe/f;->p:Z

    goto/16 :goto_1d

    :pswitch_12f
    iget-object v1, p0, LBe/e;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LBe/j;

    iput-object v1, v0, LBe/f;->i:LBe/j;

    goto/16 :goto_1d

    :pswitch_13b
    iget v1, v0, LBh/x;->f:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBh/x;->f:I

    goto/16 :goto_1d

    :pswitch_145
    iget v1, v0, LBh/x;->d:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBh/x;->d:I

    goto/16 :goto_1d

    :pswitch_14f
    iget v1, v0, LBh/x;->e:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBh/x;->e:I

    goto/16 :goto_1d

    :pswitch_159
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBh/x;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_165
    iget-object v1, p0, LBe/e;->a:LJn/a$t;

    invoke-virtual {v1, p1}, LJn/a$t;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iput-object v1, v0, LBe/f;->h:Ljava/util/Map;

    goto/16 :goto_1d

    :pswitch_171
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/f;->m:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_17d
    iget-object v1, p0, LBe/e;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Set;

    iput-object v1, v0, LBe/f;->j:Ljava/util/Set;

    goto/16 :goto_1d

    :pswitch_189
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBh/x;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_195
    iget v1, v0, LBh/x;->c:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBh/x;->c:I

    goto/16 :goto_1d

    :pswitch_19f
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, LBe/f;->n:Ljava/lang/Integer;

    goto/16 :goto_1d

    :pswitch_1ab
    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, v0, LBe/f;->l:Ljava/lang/Integer;

    goto/16 :goto_1d

    :cond_1b7
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LBe/f;->h:Ljava/util/Map;

    if-eqz p1, :cond_1cb

    iget-object p1, v0, LBe/f;->j:Ljava/util/Set;

    if-eqz p1, :cond_1c3

    return-object v0

    :cond_1c3
    new-instance p1, Ljava/io/IOException;

    const-string v0, "eventList cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1cb
    new-instance p1, Ljava/io/IOException;

    const-string v0, "recommendationMap cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_1d4
    .sparse-switch
        -0x56e558fd -> :sswitch_f1
        -0x32d1cabd -> :sswitch_e6
        -0x227042cf -> :sswitch_db
        -0x21dc72fe -> :sswitch_d0
        0x1dbba58 -> :sswitch_c5
        0xa67be4b -> :sswitch_ba
        0x1c48a6e3 -> :sswitch_af
        0x3420782f -> :sswitch_a4
        0x38f7e3ff -> :sswitch_96
        0x3ddd7f2b -> :sswitch_88
        0x421d030b -> :sswitch_7a
        0x4310181a -> :sswitch_6c
        0x46c4b6cf -> :sswitch_5e
        0x572f3da0 -> :sswitch_50
        0x5f157c51 -> :sswitch_42
        0x65de5e43 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_216
    .packed-switch 0x0
        :pswitch_1ab
        :pswitch_19f
        :pswitch_195
        :pswitch_189
        :pswitch_17d
        :pswitch_171
        :pswitch_165
        :pswitch_159
        :pswitch_14f
        :pswitch_145
        :pswitch_13b
        :pswitch_12f
        :pswitch_125
        :pswitch_119
        :pswitch_10d
        :pswitch_103
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LBe/e;->read(LBk/a;)LBe/f;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LBe/f;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "pincode"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBh/x;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "addressId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBh/x;->b:Ljava/lang/String;

    if-eqz v0, :cond_2a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "totalCost"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBh/x;->c:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "totalAmountSaved"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBh/x;->d:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "totalShippingCost"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBh/x;->e:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "coinBalance"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBh/x;->f:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "coinPriceListingCount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBh/x;->g:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "recommendationMap"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->h:Ljava/util/Map;

    if-eqz v0, :cond_102

    iget-object v1, p0, LBe/e;->a:LJn/a$t;

    invoke-virtual {v1, p1, v0}, LJn/a$t;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "moreOffersInfo"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->i:LBe/j;

    if-eqz v0, :cond_81

    iget-object v1, p0, LBe/e;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_84

    :cond_81
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_84
    const-string v0, "eventList"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->j:Ljava/util/Set;

    if-eqz v0, :cond_fa

    iget-object v1, p0, LBe/e;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "itemsWithD2rCount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->k:Ljava/lang/Integer;

    if-eqz v0, :cond_a1

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a4

    :cond_a1
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a4
    const-string v0, "itemsWithOffersAvailableCount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->l:Ljava/lang/Integer;

    if-eqz v0, :cond_b3

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_b6

    :cond_b3
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_b6
    const-string v0, "bottomBarSubPriceDescription"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->m:Ljava/lang/String;

    if-eqz v0, :cond_c5

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_c8

    :cond_c5
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_c8
    const-string v0, "sflItemCount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->n:Ljava/lang/Integer;

    if-eqz v0, :cond_d7

    sget-object v1, LJn/a;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_da

    :cond_d7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_da
    const-string v0, "checkoutType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/f;->o:Ljava/lang/String;

    if-eqz v0, :cond_e9

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ec

    :cond_e9
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ec
    const-string v0, "nepVisibleForAtleastOneProduct"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, LBe/f;->p:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_fa
    new-instance p1, Ljava/io/IOException;

    const-string p2, "eventList cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_102
    new-instance p1, Ljava/io/IOException;

    const-string p2, "recommendationMap cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LBe/f;

    invoke-virtual {p0, p1, p2}, LBe/e;->write(LBk/c;LBe/f;)V

    return-void
.end method
