.class public final LBe/o;
.super Lxk/z;
.source "ReservedItemInfo$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LBe/p;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "LBe/p;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:LJn/a$r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LBe/p;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, LBe/o;->b:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 5

    invoke-direct {p0}, Lxk/z;-><init>()V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/reflect/Type;

    const-class v1, LQg/d;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-class v1, LLe/f;

    invoke-static {v1, v0}, Lcom/google/gson/reflect/a;->getParameterized(Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Lcom/google/gson/reflect/a;

    move-result-object v0

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    new-instance v0, LJn/a$r;

    new-instance v1, LJn/a$q;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, p1, v1}, LJn/a$r;-><init>(Lxk/z;Lcom/google/gson/internal/r;)V

    iput-object v0, p0, LBe/o;->a:LJn/a$r;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LBe/p;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LBe/p;

    invoke-direct {v0}, LBe/p;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_d4

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_f0

    goto :goto_7f

    :sswitch_33
    const-string v2, "asmDisplayState"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    goto :goto_7f

    :cond_3c
    const/4 v3, 0x6

    goto :goto_7f

    :sswitch_3e
    const-string v2, "reservationStatus"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    goto :goto_7f

    :cond_47
    const/4 v3, 0x5

    goto :goto_7f

    :sswitch_49
    const-string v2, "message"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_52

    goto :goto_7f

    :cond_52
    const/4 v3, 0x4

    goto :goto_7f

    :sswitch_54
    const-string v2, "ttl"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    goto :goto_7f

    :cond_5d
    const/4 v3, 0x3

    goto :goto_7f

    :sswitch_5f
    const-string v2, "saleId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto :goto_7f

    :cond_68
    const/4 v3, 0x2

    goto :goto_7f

    :sswitch_6a
    const-string v2, "presentTs"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_73

    goto :goto_7f

    :cond_73
    const/4 v3, 0x1

    goto :goto_7f

    :sswitch_75
    const-string v2, "actions"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7e

    goto :goto_7f

    :cond_7e
    const/4 v3, 0x0

    :goto_7f
    packed-switch v3, :pswitch_data_10e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1d

    :pswitch_86
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/p;->e:Ljava/lang/String;

    goto :goto_1d

    :pswitch_91
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/p;->d:Ljava/lang/String;

    goto :goto_1d

    :pswitch_9c
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/p;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_a8
    iget-wide v1, v0, LBe/p;->c:J

    invoke-static {p1, v1, v2}, LJn/a$B;->a(LBk/a;J)J

    move-result-wide v1

    iput-wide v1, v0, LBe/p;->c:J

    goto/16 :goto_1d

    :pswitch_b2
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/p;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_be
    iget-wide v1, v0, LBe/p;->a:J

    invoke-static {p1, v1, v2}, LJn/a$B;->a(LBk/a;J)J

    move-result-wide v1

    iput-wide v1, v0, LBe/p;->a:J

    goto/16 :goto_1d

    :pswitch_c8
    iget-object v1, p0, LBe/o;->a:LJn/a$r;

    invoke-virtual {v1, p1}, LJn/a$r;->read(LBk/a;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, LBe/p;->g:Ljava/util/List;

    goto/16 :goto_1d

    :cond_d4
    invoke-virtual {p1}, LBk/a;->endObject()V

    iget-object p1, v0, LBe/p;->d:Ljava/lang/String;

    if-eqz p1, :cond_e8

    iget-object p1, v0, LBe/p;->e:Ljava/lang/String;

    if-eqz p1, :cond_e0

    return-object v0

    :cond_e0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "asmDisplayState cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e8
    new-instance p1, Ljava/io/IOException;

    const-string v0, "reservationStatus cannot be null"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :sswitch_data_f0
    .sparse-switch
        -0x453fb703 -> :sswitch_75
        -0x36f3bf66 -> :sswitch_6a
        -0x36392c3e -> :sswitch_5f
        0x1c1ec -> :sswitch_54
        0x38eb0007 -> :sswitch_49
        0x6c40f6de -> :sswitch_3e
        0x79f7d30a -> :sswitch_33
    .end sparse-switch

    :pswitch_data_10e
    .packed-switch 0x0
        :pswitch_c8
        :pswitch_be
        :pswitch_b2
        :pswitch_a8
        :pswitch_9c
        :pswitch_91
        :pswitch_86
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LBe/o;->read(LBk/a;)LBe/p;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LBe/p;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "presentTs"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, LBe/p;->a:J

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "message"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/p;->b:Ljava/lang/String;

    if-eqz v0, :cond_22

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_25

    :cond_22
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_25
    const-string v0, "ttl"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-wide v0, p2, LBe/p;->c:J

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "reservationStatus"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/p;->d:Ljava/lang/String;

    if-eqz v0, :cond_7c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "asmDisplayState"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/p;->e:Ljava/lang/String;

    if-eqz v0, :cond_74

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string v0, "saleId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/p;->f:Ljava/lang/String;

    if-eqz v0, :cond_56

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_59

    :cond_56
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_59
    const-string v0, "actions"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LBe/p;->g:Ljava/util/List;

    if-eqz p2, :cond_6d

    iget-object v0, p0, LBe/o;->a:LJn/a$r;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/util/Collection;

    invoke-virtual {v0, p1, p2}, LJn/a$r;->write(LBk/c;Ljava/util/Collection;)V

    goto :goto_70

    :cond_6d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_70
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void

    :cond_74
    new-instance p1, Ljava/io/IOException;

    const-string p2, "asmDisplayState cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7c
    new-instance p1, Ljava/io/IOException;

    const-string p2, "reservationStatus cannot be null"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LBe/p;

    invoke-virtual {p0, p1, p2}, LBe/o;->write(LBk/c;LBe/p;)V

    return-void
.end method
