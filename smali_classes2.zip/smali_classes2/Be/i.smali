.class public final LBe/i;
.super Lxk/z;
.source "MoreOffersInfo$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LBe/j;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "LBe/j;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LBe/j;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, LBe/i;->a:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LBe/j;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LBe/j;

    invoke-direct {v0}, LBe/j;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_13b

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_140

    goto/16 :goto_b5

    :sswitch_34
    const-string v2, "isShown"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_b5

    :cond_3e
    const/16 v3, 0xa

    goto/16 :goto_b5

    :sswitch_42
    const-string v2, "offerType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_b5

    :cond_4c
    const/16 v3, 0x9

    goto/16 :goto_b5

    :sswitch_50
    const-string v2, "progressTier"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_b5

    :cond_5a
    const/16 v3, 0x8

    goto/16 :goto_b5

    :sswitch_5e
    const-string v2, "title"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_67

    goto :goto_b5

    :cond_67
    const/4 v3, 0x7

    goto :goto_b5

    :sswitch_69
    const-string v2, "offerTotalTier"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_72

    goto :goto_b5

    :cond_72
    const/4 v3, 0x6

    goto :goto_b5

    :sswitch_74
    const-string v2, "offersShownCount"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7d

    goto :goto_b5

    :cond_7d
    const/4 v3, 0x5

    goto :goto_b5

    :sswitch_7f
    const-string v2, "totalOffers"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_88

    goto :goto_b5

    :cond_88
    const/4 v3, 0x4

    goto :goto_b5

    :sswitch_8a
    const-string v2, "d2rValue"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_93

    goto :goto_b5

    :cond_93
    const/4 v3, 0x3

    goto :goto_b5

    :sswitch_95
    const-string v2, "d2rTitle"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9e

    goto :goto_b5

    :cond_9e
    const/4 v3, 0x2

    goto :goto_b5

    :sswitch_a0
    const-string v2, "offerId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a9

    goto :goto_b5

    :cond_a9
    const/4 v3, 0x1

    goto :goto_b5

    :sswitch_ab
    const-string v2, "progressTierType"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b4

    goto :goto_b5

    :cond_b4
    const/4 v3, 0x0

    :goto_b5
    packed-switch v3, :pswitch_data_16e

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_bd
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->k:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_c9
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->i:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_d5
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->f:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_e1
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->a:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_ed
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_f9
    iget v1, v0, LBe/j;->c:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBe/j;->c:I

    goto/16 :goto_1d

    :pswitch_103
    iget v1, v0, LBe/j;->b:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBe/j;->b:I

    goto/16 :goto_1d

    :pswitch_10d
    iget v1, v0, LBe/j;->e:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LBe/j;->e:I

    goto/16 :goto_1d

    :pswitch_117
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_123
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->j:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_12f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LBe/j;->g:Ljava/lang/String;

    goto/16 :goto_1d

    :cond_13b
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_140
    .sparse-switch
        -0x686cc277 -> :sswitch_ab
        -0x5c510369 -> :sswitch_a0
        -0x4fb93d2c -> :sswitch_95
        -0x4fa0ce13 -> :sswitch_8a
        -0x33758a05 -> :sswitch_7f
        -0x2b8e648b -> :sswitch_74
        -0x1be0b3b6 -> :sswitch_69
        0x6942258 -> :sswitch_5e
        0x2ac5a9af -> :sswitch_50
        0x73e78fb6 -> :sswitch_42
        0x7b6e3207 -> :sswitch_34
    .end sparse-switch

    :pswitch_data_16e
    .packed-switch 0x0
        :pswitch_12f
        :pswitch_123
        :pswitch_117
        :pswitch_10d
        :pswitch_103
        :pswitch_f9
        :pswitch_ed
        :pswitch_e1
        :pswitch_d5
        :pswitch_c9
        :pswitch_bd
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LBe/i;->read(LBk/a;)LBe/j;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LBe/j;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "title"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/j;->a:Ljava/lang/String;

    if-eqz v0, :cond_18

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "totalOffers"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBe/j;->b:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "offersShownCount"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBe/j;->c:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "d2rTitle"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/j;->d:Ljava/lang/String;

    if-eqz v0, :cond_40

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_43

    :cond_40
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_43
    const-string v0, "d2rValue"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LBe/j;->e:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "progressTier"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/j;->f:Ljava/lang/String;

    if-eqz v0, :cond_5d

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_60

    :cond_5d
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_60
    const-string v0, "progressTierType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/j;->g:Ljava/lang/String;

    if-eqz v0, :cond_6f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_72

    :cond_6f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_72
    const-string v0, "offerTotalTier"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/j;->h:Ljava/lang/String;

    if-eqz v0, :cond_81

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_84

    :cond_81
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_84
    const-string v0, "offerType"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/j;->i:Ljava/lang/String;

    if-eqz v0, :cond_93

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_96

    :cond_93
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_96
    const-string v0, "offerId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LBe/j;->j:Ljava/lang/String;

    if-eqz v0, :cond_a5

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a8

    :cond_a5
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a8
    const-string v0, "isShown"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object p2, p2, LBe/j;->k:Ljava/lang/String;

    if-eqz p2, :cond_b7

    sget-object v0, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v0, p1, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_ba

    :cond_b7
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_ba
    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LBe/j;

    invoke-virtual {p0, p1, p2}, LBe/i;->write(LBk/c;LBe/j;)V

    return-void
.end method
