.class public final LCj/i;
.super Ljava/lang/Object;


# static fields
.field public static final abc_action_bar_home_description:I = 0x7f130019

.field public static final abc_action_bar_up_description:I = 0x7f13001a

.field public static final abc_action_menu_overflow_description:I = 0x7f13001b

.field public static final abc_action_mode_done:I = 0x7f13001c

.field public static final abc_activity_chooser_view_see_all:I = 0x7f13001d

.field public static final abc_activitychooserview_choose_application:I = 0x7f13001e

.field public static final abc_capital_off:I = 0x7f13001f

.field public static final abc_capital_on:I = 0x7f130020

.field public static final abc_menu_alt_shortcut_label:I = 0x7f130021

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f130022

.field public static final abc_menu_delete_shortcut_label:I = 0x7f130023

.field public static final abc_menu_enter_shortcut_label:I = 0x7f130024

.field public static final abc_menu_function_shortcut_label:I = 0x7f130025

.field public static final abc_menu_meta_shortcut_label:I = 0x7f130026

.field public static final abc_menu_shift_shortcut_label:I = 0x7f130027

.field public static final abc_menu_space_shortcut_label:I = 0x7f130028

.field public static final abc_menu_sym_shortcut_label:I = 0x7f130029

.field public static final abc_prepend_shortcut_label:I = 0x7f13002a

.field public static final abc_search_hint:I = 0x7f13002b

.field public static final abc_searchview_description_clear:I = 0x7f13002c

.field public static final abc_searchview_description_query:I = 0x7f13002d

.field public static final abc_searchview_description_search:I = 0x7f13002e

.field public static final abc_searchview_description_submit:I = 0x7f13002f

.field public static final abc_searchview_description_voice:I = 0x7f130030

.field public static final abc_shareactionprovider_share_with:I = 0x7f130031

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f130032

.field public static final abc_toolbar_collapse_description:I = 0x7f130033

.field public static final appbar_scrolling_view_behavior:I = 0x7f13007e

.field public static final bottom_sheet_behavior:I = 0x7f1300b5

.field public static final character_counter_content_description:I = 0x7f130110

.field public static final character_counter_pattern:I = 0x7f130111

.field public static final fab_transformation_scrim_behavior:I = 0x7f130231

.field public static final fab_transformation_sheet_behavior:I = 0x7f130232

.field public static final hide_bottom_view_on_scroll_behavior:I = 0x7f130274

.field public static final mtrl_chip_close_icon_content_description:I = 0x7f130309

.field public static final password_toggle_content_description:I = 0x7f13036b

.field public static final path_password_eye:I = 0x7f13036e

.field public static final path_password_eye_mask_strike_through:I = 0x7f13036f

.field public static final path_password_eye_mask_visible:I = 0x7f130370

.field public static final path_password_strike_through:I = 0x7f130371

.field public static final search_menu_title:I = 0x7f1303fb

.field public static final status_bar_notification_info_overflow:I = 0x7f13044c
