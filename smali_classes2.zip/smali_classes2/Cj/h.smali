.class public final LCj/h;
.super Ljava/lang/Object;


# static fields
.field public static final abc_action_bar_title_item:I = 0x7f0e0001

.field public static final abc_action_bar_up_container:I = 0x7f0e0002

.field public static final abc_action_menu_item_layout:I = 0x7f0e0003

.field public static final abc_action_menu_layout:I = 0x7f0e0004

.field public static final abc_action_mode_bar:I = 0x7f0e0005

.field public static final abc_action_mode_close_item_material:I = 0x7f0e0006

.field public static final abc_activity_chooser_view:I = 0x7f0e0007

.field public static final abc_activity_chooser_view_list_item:I = 0x7f0e0008

.field public static final abc_alert_dialog_button_bar_material:I = 0x7f0e0009

.field public static final abc_alert_dialog_material:I = 0x7f0e000a

.field public static final abc_alert_dialog_title_material:I = 0x7f0e000b

.field public static final abc_cascading_menu_item_layout:I = 0x7f0e000c

.field public static final abc_dialog_title_material:I = 0x7f0e000d

.field public static final abc_expanded_menu_layout:I = 0x7f0e000e

.field public static final abc_list_menu_item_checkbox:I = 0x7f0e000f

.field public static final abc_list_menu_item_icon:I = 0x7f0e0010

.field public static final abc_list_menu_item_layout:I = 0x7f0e0011

.field public static final abc_list_menu_item_radio:I = 0x7f0e0012

.field public static final abc_popup_menu_header_item_layout:I = 0x7f0e0013

.field public static final abc_popup_menu_item_layout:I = 0x7f0e0014

.field public static final abc_screen_content_include:I = 0x7f0e0015

.field public static final abc_screen_simple:I = 0x7f0e0016

.field public static final abc_screen_simple_overlay_action_mode:I = 0x7f0e0017

.field public static final abc_screen_toolbar:I = 0x7f0e0018

.field public static final abc_search_dropdown_item_icons_2line:I = 0x7f0e0019

.field public static final abc_search_view:I = 0x7f0e001a

.field public static final abc_select_dialog_material:I = 0x7f0e001b

.field public static final abc_tooltip:I = 0x7f0e001c

.field public static final design_bottom_navigation_item:I = 0x7f0e00bc

.field public static final design_bottom_sheet_dialog:I = 0x7f0e00bd

.field public static final design_layout_snackbar:I = 0x7f0e00be

.field public static final design_layout_snackbar_include:I = 0x7f0e00bf

.field public static final design_layout_tab_icon:I = 0x7f0e00c0

.field public static final design_layout_tab_text:I = 0x7f0e00c1

.field public static final design_menu_item_action_area:I = 0x7f0e00c2

.field public static final design_navigation_item:I = 0x7f0e00c3

.field public static final design_navigation_item_header:I = 0x7f0e00c4

.field public static final design_navigation_item_separator:I = 0x7f0e00c5

.field public static final design_navigation_item_subheader:I = 0x7f0e00c6

.field public static final design_navigation_menu:I = 0x7f0e00c7

.field public static final design_navigation_menu_item:I = 0x7f0e00c8

.field public static final design_text_input_password_icon:I = 0x7f0e00c9

.field public static final mtrl_layout_snackbar:I = 0x7f0e0181

.field public static final mtrl_layout_snackbar_include:I = 0x7f0e0182

.field public static final notification_action:I = 0x7f0e018f

.field public static final notification_action_tombstone:I = 0x7f0e0190

.field public static final notification_template_custom_big:I = 0x7f0e0199

.field public static final notification_template_icon_group:I = 0x7f0e019a

.field public static final notification_template_part_chronometer:I = 0x7f0e019e

.field public static final notification_template_part_time:I = 0x7f0e019f

.field public static final select_dialog_item_material:I = 0x7f0e024e

.field public static final select_dialog_multichoice_material:I = 0x7f0e024f

.field public static final select_dialog_singlechoice_material:I = 0x7f0e0250

.field public static final support_simple_spinner_dropdown_item:I = 0x7f0e026b
