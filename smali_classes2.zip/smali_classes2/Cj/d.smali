.class public final Lcj/d;
.super Ljava/lang/Object;


# static fields
.field public static final LoadingImageView:[I

.field public static final LoadingImageView_circleCrop:I = 0x0

.field public static final LoadingImageView_imageAspectRatio:I = 0x1

.field public static final LoadingImageView_imageAspectRatioAdjust:I = 0x2

.field public static final SignInButton:[I

.field public static final SignInButton_buttonSize:I = 0x0

.field public static final SignInButton_colorScheme:I = 0x1

.field public static final SignInButton_scopeUris:I = 0x2


# direct methods
.method public static constructor <clinit>()V
    .registers 3

    const v0, 0x7f0401a3

    const v1, 0x7f0401a4

    const v2, 0x7f0400b2

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcj/d;->LoadingImageView:[I

    const v0, 0x7f0400cb

    const v1, 0x7f0402d9

    const v2, 0x7f040087

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcj/d;->SignInButton:[I

    return-void
.end method
