.class public final LCj/f;
.super Ljava/lang/Object;


# static fields
.field public static final action_bar:I = 0x7f0b003a

.field public static final action_bar_activity_content:I = 0x7f0b003b

.field public static final action_bar_container:I = 0x7f0b003d

.field public static final action_bar_root:I = 0x7f0b003e

.field public static final action_bar_spinner:I = 0x7f0b003f

.field public static final action_bar_subtitle:I = 0x7f0b0040

.field public static final action_bar_title:I = 0x7f0b0041

.field public static final action_container:I = 0x7f0b0045

.field public static final action_context_bar:I = 0x7f0b0046

.field public static final action_divider:I = 0x7f0b0049

.field public static final action_image:I = 0x7f0b004b

.field public static final action_menu_divider:I = 0x7f0b004c

.field public static final action_menu_presenter:I = 0x7f0b004d

.field public static final action_mode_bar:I = 0x7f0b004e

.field public static final action_mode_bar_stub:I = 0x7f0b004f

.field public static final action_mode_close_button:I = 0x7f0b0050

.field public static final action_text:I = 0x7f0b0055

.field public static final actions:I = 0x7f0b0057

.field public static final activity_chooser_view_content:I = 0x7f0b0058

.field public static final add:I = 0x7f0b005a

.field public static final alertTitle:I = 0x7f0b0063

.field public static final async:I = 0x7f0b0089

.field public static final auto:I = 0x7f0b008b

.field public static final blocking:I = 0x7f0b00a9

.field public static final bottom:I = 0x7f0b00ae

.field public static final buttonPanel:I = 0x7f0b00e2

.field public static final center:I = 0x7f0b017f

.field public static final checkbox:I = 0x7f0b018c

.field public static final chronometer:I = 0x7f0b019c

.field public static final container:I = 0x7f0b01c2

.field public static final content:I = 0x7f0b01c5

.field public static final contentPanel:I = 0x7f0b01c7

.field public static final coordinator:I = 0x7f0b01d2

.field public static final custom:I = 0x7f0b01e6

.field public static final customPanel:I = 0x7f0b01e7

.field public static final decor_content_parent:I = 0x7f0b01f5

.field public static final default_activity_button:I = 0x7f0b01f6

.field public static final design_bottom_sheet:I = 0x7f0b0205

.field public static final design_menu_item_action_area:I = 0x7f0b0206

.field public static final design_menu_item_action_area_stub:I = 0x7f0b0207

.field public static final design_menu_item_text:I = 0x7f0b0208

.field public static final design_navigation_view:I = 0x7f0b0209

.field public static final edit_query:I = 0x7f0b022d

.field public static final end:I = 0x7f0b0241

.field public static final expand_activities_button:I = 0x7f0b028d

.field public static final expanded_menu:I = 0x7f0b0295

.field public static final fill:I = 0x7f0b02a1

.field public static final filled:I = 0x7f0b02a4

.field public static final fixed:I = 0x7f0b02d2

.field public static final forever:I = 0x7f0b02f0

.field public static final group_divider:I = 0x7f0b032a

.field public static final home:I = 0x7f0b0342

.field public static final icon:I = 0x7f0b034d

.field public static final icon_group:I = 0x7f0b0350

.field public static final image:I = 0x7f0b0356

.field public static final info:I = 0x7f0b0397

.field public static final italic:I = 0x7f0b03aa

.field public static final item_touch_helper_previous_elevation:I = 0x7f0b03b1

.field public static final labeled:I = 0x7f0b03d8

.field public static final largeLabel:I = 0x7f0b03db

.field public static final left:I = 0x7f0b03e7

.field public static final line1:I = 0x7f0b03ef

.field public static final line3:I = 0x7f0b03f0

.field public static final listMode:I = 0x7f0b03f7

.field public static final list_item:I = 0x7f0b03f8

.field public static final masked:I = 0x7f0b0429

.field public static final message:I = 0x7f0b043b

.field public static final mini:I = 0x7f0b0445

.field public static final mtrl_child_content_container:I = 0x7f0b0452

.field public static final mtrl_internal_children_alpha_tag:I = 0x7f0b0453

.field public static final multiply:I = 0x7f0b0454

.field public static final navigation_header_container:I = 0x7f0b0461

.field public static final none:I = 0x7f0b046f

.field public static final normal:I = 0x7f0b0470

.field public static final notification_background:I = 0x7f0b0474

.field public static final notification_main_column:I = 0x7f0b0476

.field public static final notification_main_column_container:I = 0x7f0b0477

.field public static final outline:I = 0x7f0b04b1

.field public static final parallax:I = 0x7f0b04bc

.field public static final parentPanel:I = 0x7f0b04be

.field public static final pin:I = 0x7f0b04de

.field public static final progress_circular:I = 0x7f0b0582

.field public static final progress_horizontal:I = 0x7f0b0583

.field public static final radio:I = 0x7f0b059a

.field public static final right:I = 0x7f0b05f1

.field public static final right_icon:I = 0x7f0b05f5

.field public static final right_side:I = 0x7f0b05f8

.field public static final screen:I = 0x7f0b0626

.field public static final scrollIndicatorDown:I = 0x7f0b0628

.field public static final scrollIndicatorUp:I = 0x7f0b0629

.field public static final scrollView:I = 0x7f0b062a

.field public static final scrollable:I = 0x7f0b062b

.field public static final search_badge:I = 0x7f0b0630

.field public static final search_bar:I = 0x7f0b0631

.field public static final search_button:I = 0x7f0b0632

.field public static final search_close_btn:I = 0x7f0b0634

.field public static final search_edit_frame:I = 0x7f0b063b

.field public static final search_go_btn:I = 0x7f0b063d

.field public static final search_mag_icon:I = 0x7f0b0640

.field public static final search_plate:I = 0x7f0b0641

.field public static final search_src_text:I = 0x7f0b0642

.field public static final search_voice_btn:I = 0x7f0b0644

.field public static final select_dialog_listview:I = 0x7f0b065a

.field public static final selected:I = 0x7f0b065b

.field public static final shortcut:I = 0x7f0b066c

.field public static final smallLabel:I = 0x7f0b067c

.field public static final snackbar_action:I = 0x7f0b0685

.field public static final snackbar_text:I = 0x7f0b0687

.field public static final spacer:I = 0x7f0b0695

.field public static final split_action_bar:I = 0x7f0b069d

.field public static final src_atop:I = 0x7f0b06a0

.field public static final src_in:I = 0x7f0b06a1

.field public static final src_over:I = 0x7f0b06a2

.field public static final start:I = 0x7f0b06a5

.field public static final stretch:I = 0x7f0b06b4

.field public static final submenuarrow:I = 0x7f0b06bf

.field public static final submit_area:I = 0x7f0b06c1

.field public static final tabMode:I = 0x7f0b06db

.field public static final tag_transition_group:I = 0x7f0b06ec

.field public static final tag_unhandled_key_event_manager:I = 0x7f0b06ed

.field public static final tag_unhandled_key_listeners:I = 0x7f0b06ee

.field public static final text:I = 0x7f0b06f5

.field public static final text2:I = 0x7f0b06f7

.field public static final textSpacerNoButtons:I = 0x7f0b06fc

.field public static final textSpacerNoTitle:I = 0x7f0b06fd

.field public static final text_input_password_toggle:I = 0x7f0b0706

.field public static final textinput_counter:I = 0x7f0b0712

.field public static final textinput_error:I = 0x7f0b0713

.field public static final textinput_helper_text:I = 0x7f0b0714

.field public static final time:I = 0x7f0b0727

.field public static final title:I = 0x7f0b0733

.field public static final titleDividerNoCustom:I = 0x7f0b0734

.field public static final title_template:I = 0x7f0b073e

.field public static final top:I = 0x7f0b075c

.field public static final topPanel:I = 0x7f0b075e

.field public static final touch_outside:I = 0x7f0b0763

.field public static final uniform:I = 0x7f0b07e2

.field public static final unlabeled:I = 0x7f0b07e3

.field public static final up:I = 0x7f0b07e4

.field public static final view_offset_helper:I = 0x7f0b0826

.field public static final visible:I = 0x7f0b0832

.field public static final wrap_content:I = 0x7f0b0856
