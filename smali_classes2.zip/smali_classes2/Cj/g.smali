.class public final LCj/g;
.super Ljava/lang/Object;


# static fields
.field public static final abc_config_activityDefaultDur:I = 0x7f0c0000

.field public static final abc_config_activityShortDur:I = 0x7f0c0001

.field public static final app_bar_elevation_anim_duration:I = 0x7f0c0002

.field public static final bottom_sheet_slide_duration:I = 0x7f0c0003

.field public static final cancel_button_image_alpha:I = 0x7f0c0004

.field public static final config_tooltipAnimTime:I = 0x7f0c0005

.field public static final design_snackbar_text_max_lines:I = 0x7f0c0007

.field public static final design_tab_indicator_anim_duration_ms:I = 0x7f0c0008

.field public static final hide_password_duration:I = 0x7f0c000d

.field public static final mtrl_btn_anim_delay_ms:I = 0x7f0c000e

.field public static final mtrl_btn_anim_duration_ms:I = 0x7f0c000f

.field public static final mtrl_chip_anim_duration:I = 0x7f0c0010

.field public static final mtrl_tab_indicator_anim_duration_ms:I = 0x7f0c0011

.field public static final show_password_duration:I = 0x7f0c0015

.field public static final status_bar_notification_info_maxnum:I = 0x7f0c0016
