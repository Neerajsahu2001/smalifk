.class public final LC6/b$b$a$a$a;
.super Ljava/lang/Object;
.source "ReactMultiWidgetUtils.kt"

# interfaces
.implements LDc/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC6/b$b$a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lkotlin/jvm/internal/D;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/D<",
            "LXn/d<",
            "Ljava/lang/Boolean;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/D;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/D<",
            "LXn/d<",
            "Ljava/lang/Boolean;",
            ">;>;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC6/b$b$a$a$a;->a:Lkotlin/jvm/internal/D;

    return-void
.end method


# virtual methods
.method public allChunksLoadedInVM()V
    .registers 4

    iget-object v0, p0, LC6/b$b$a$a$a;->a:Lkotlin/jvm/internal/D;

    iget-object v1, v0, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    check-cast v1, LXn/d;

    if-eqz v1, :cond_d

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {v1, v2}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    :cond_d
    const/4 v1, 0x0

    iput-object v1, v0, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    return-void
.end method

.method public chunkLoadError(Ljava/lang/Exception;)V
    .registers 4

    const-string v0, "e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LC6/b$b$a$a$a;->a:Lkotlin/jvm/internal/D;

    iget-object v0, p1, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    check-cast v0, LXn/d;

    if-eqz v0, :cond_12

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v0, v1}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    :cond_12
    const/4 v0, 0x0

    iput-object v0, p1, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    return-void
.end method
