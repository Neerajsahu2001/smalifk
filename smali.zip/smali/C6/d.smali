.class public final Lc6/d;
.super Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;
.source "VoiceInputBarWidget.kt"

# interfaces
.implements Lcom/flipkart/android/voice/view/l;


# instance fields
.field private Q:Lcom/flipkart/android/voice/h;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;-><init>()V

    return-void
.end method


# virtual methods
.method public bindData(LG5/M;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/newmultiwidget/ui/widgets/q;)V
    .registers 10

    const-string v0, "widget"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "widgetPageInfo"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "parentCallback"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1, p2, p3}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->bindData(LG5/M;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/newmultiwidget/ui/widgets/q;)V

    iget-object p2, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    const-string v0, "null cannot be cast to non-null type com.flipkart.android.voice.view.VoiceInputBarView"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Lcom/flipkart/android/voice/view/k;

    check-cast p3, Landroidx/fragment/app/Fragment;

    iget-object v0, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-nez v0, :cond_6b

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.init.FlipkartApplication"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {p3}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v1

    instance-of v1, v1, Lcom/flipkart/android/voice/j;

    if-eqz v1, :cond_6b

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p3}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v2

    const-string v3, "null cannot be cast to non-null type com.flipkart.android.voice.VoiceInteractionInterface"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Lcom/flipkart/android/voice/j;

    invoke-virtual {v0, v1, v2}, Lcom/flipkart/android/init/FlipkartApplication;->getVoiceController(Landroid/content/Context;Lcom/flipkart/android/voice/j;)Lcom/flipkart/android/voice/h;

    move-result-object v0

    iput-object v0, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz v0, :cond_5b

    invoke-virtual {p2}, Lcom/flipkart/android/voice/view/k;->getObserver()Landroidx/lifecycle/J;

    move-result-object v1

    const-string v2, "view.observer"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, p3, v1}, Lcom/flipkart/android/voice/h;->attachObserver(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    :cond_5b
    iget-object v0, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz v0, :cond_6b

    invoke-virtual {p2}, Lcom/flipkart/android/voice/view/k;->getChitChatObserver()Landroidx/lifecycle/J;

    move-result-object v1

    const-string v2, "view.chitChatObserver"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, p3, v1}, Lcom/flipkart/android/voice/h;->attachChitChatObserver(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    :cond_6b
    invoke-virtual {p1}, LG5/M;->getData_()LK5/h;

    move-result-object p1

    if-eqz p1, :cond_74

    iget-object p3, p1, LK5/h;->b:Ljg/g0;

    goto :goto_75

    :cond_74
    const/4 p3, 0x0

    :goto_75
    if-nez p3, :cond_78

    return-void

    :cond_78
    iget-object p1, p1, LK5/h;->b:Ljg/g0;

    const-string p3, "null cannot be cast to non-null type com.flipkart.rome.datatypes.response.page.v4.mapiWidgetData.VoiceInputBarWidgetData"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lxg/D;

    iget-object p3, p1, Lxg/D;->a:Ljava/util/List;

    const/4 v0, 0x0

    if-eqz p3, :cond_a1

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_91
    if-ge v3, v2, :cond_9e

    invoke-interface {p3, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    aput-object v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_91

    :cond_9e
    invoke-virtual {p2, v1}, Lcom/flipkart/android/voice/view/k;->setAffordances([Ljava/lang/String;)V

    :cond_a1
    iget-object p3, p1, Lxg/D;->g:Ljava/lang/String;

    invoke-virtual {p2, p3}, Lcom/flipkart/android/voice/view/k;->setBoldText(Ljava/lang/String;)V

    iget-object p3, p1, Lxg/D;->c:Ljava/lang/String;

    if-eqz p3, :cond_b1

    iget-object v1, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz v1, :cond_b1

    invoke-virtual {v1, p3}, Lcom/flipkart/android/voice/h;->setStateId(Ljava/lang/String;)V

    :cond_b1
    iget-object p3, p1, Lxg/D;->i:LLe/f;

    if-eqz p3, :cond_c4

    iget-object p3, p3, LLe/f;->d:LGe/b;

    if-eqz p3, :cond_c4

    iget-object p3, p3, LGe/b;->h:Ljava/util/Map;

    if-eqz p3, :cond_c4

    iget-object v1, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz v1, :cond_c4

    invoke-virtual {v1, p3}, Lcom/flipkart/android/voice/h;->setTracking(Ljava/util/Map;)V

    :cond_c4
    iget-object p3, p1, Lxg/D;->i:LLe/f;

    if-eqz p3, :cond_da

    iget-object p3, p3, LLe/f;->d:LGe/b;

    if-eqz p3, :cond_da

    iget-object v1, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz v1, :cond_da

    iget-object p3, p3, LGe/b;->b:Ljava/lang/String;

    const-string v2, "it.type"

    invoke-static {p3, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, p3}, Lcom/flipkart/android/voice/h;->setEventName(Ljava/lang/String;)V

    :cond_da
    iget-object p3, p1, Lxg/D;->i:LLe/f;

    if-eqz p3, :cond_f4

    iget-object p3, p3, LLe/f;->c:LMe/R3;

    check-cast p3, Lmf/F;

    if-eqz p3, :cond_f4

    iget-object v1, p3, Lmf/F;->a:LMe/r1;

    if-eqz v1, :cond_f4

    iget-object v2, p3, Lmf/F;->b:Ljava/lang/String;

    if-eqz v2, :cond_f4

    invoke-virtual {p2, v1}, Lcom/flipkart/android/voice/view/k;->setMicIcon(LMe/r1;)V

    iget-object p3, p3, Lmf/F;->b:Ljava/lang/String;

    invoke-virtual {p2, p3}, Lcom/flipkart/android/voice/view/k;->setAnimationColor(Ljava/lang/String;)V

    :cond_f4
    iget-object p3, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz p3, :cond_fd

    iget-object v1, p1, Lxg/D;->d:Ljava/lang/String;

    invoke-virtual {p3, v1}, Lcom/flipkart/android/voice/h;->setAssistantSessionId(Ljava/lang/String;)V

    :cond_fd
    iget-object p3, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz p3, :cond_112

    iget-object v1, p1, Lxg/D;->e:Ljava/lang/String;

    iget-object v2, p1, Lxg/D;->b:Ljava/util/List;

    iget-object v3, p1, Lxg/D;->c:Ljava/lang/String;

    sget-object v4, Lj8/f;->a:Lj8/f;

    iget-object v5, p1, Lxg/D;->f:Ljava/lang/String;

    invoke-virtual {v4, v5}, Lj8/f;->shouldAutoListen(Ljava/lang/String;)Z

    move-result v4

    invoke-virtual {p3, v1, v2, v3, v4}, Lcom/flipkart/android/voice/h;->sayTts(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Z)V

    :cond_112
    iget-object p3, p1, Lxg/D;->j:LMe/T2;

    iget-object v1, p1, Lxg/D;->l:LMe/T2;

    iget-object v2, p1, Lxg/D;->k:LMe/T2;

    invoke-virtual {p2, p3, v1, v2}, Lcom/flipkart/android/voice/view/k;->setHintSubtext(LMe/T2;LMe/T2;LMe/T2;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p3

    invoke-virtual {p3}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object p3

    if-eqz p3, :cond_134

    iget-boolean p3, p3, Lcom/flipkart/android/configmodel/t2;->p:Z

    if-eqz p3, :cond_134

    invoke-static {}, Lcom/flipkart/android/config/d;->instance()Lcom/flipkart/android/config/d;

    move-result-object p3

    invoke-virtual {p3}, Lcom/flipkart/android/config/d;->isVoiceOnboardComplete()Z

    move-result p3

    if-nez p3, :cond_134

    const/4 v0, 0x1

    :cond_134
    invoke-virtual {p2, v0}, Lcom/flipkart/android/voice/view/k;->setShowOnboarding(Z)V

    iget-object p1, p1, Lxg/D;->h:Ljava/lang/String;

    invoke-virtual {p2, p1}, Lcom/flipkart/android/voice/view/k;->setLocale(Ljava/lang/String;)V

    return-void
.end method

.method public createView(Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 3

    const-string v0, "parent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    new-instance v0, Lcom/flipkart/android/voice/view/k;

    invoke-direct {v0, p1, p0}, Lcom/flipkart/android/voice/view/k;-><init>(Landroid/content/Context;Lcom/flipkart/android/voice/view/l;)V

    iput-object v0, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    return-object v0
.end method

.method public emitAction(LGe/b;)V
    .registers 2

    return-void
.end method

.method public onButtonClicked()V
    .registers 5

    iget-object v0, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz v0, :cond_a

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1, v3, v2, v3}, Lcom/flipkart/android/voice/h;->startListening$default(Lcom/flipkart/android/voice/h;ZLb6/d$a;ILjava/lang/Object;)V

    :cond_a
    return-void
.end method

.method public onSpeechRecognitionViewClicked()V
    .registers 2

    iget-object v0, p0, Lc6/d;->Q:Lcom/flipkart/android/voice/h;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/flipkart/android/voice/h;->stopListening()V

    :cond_7
    return-void
.end method
