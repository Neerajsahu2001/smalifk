.class public final LC6/b$b$a;
.super Ljava/lang/Object;
.source "ReactMultiWidgetUtils.kt"

# interfaces
.implements Lcom/flipkart/navigation/uri/resolvers/c$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC6/b$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field private a:LXn/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LXn/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:LXn/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LXn/d<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic c:Landroid/content/Context;

.field final synthetic d:Lcom/flipkart/crossplatform/t;

.field final synthetic e:Lcom/flipkart/crossplatform/b;


# direct methods
.method constructor <init>(LXn/i;Landroid/content/Context;Lcom/flipkart/crossplatform/t;Lcom/flipkart/crossplatform/b;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC6/b$b$a;->b:LXn/d;

    iput-object p2, p0, LC6/b$b$a;->c:Landroid/content/Context;

    iput-object p3, p0, LC6/b$b$a;->d:Lcom/flipkart/crossplatform/t;

    iput-object p4, p0, LC6/b$b$a;->e:Lcom/flipkart/crossplatform/b;

    iput-object p1, p0, LC6/b$b$a;->a:LXn/d;

    return-void
.end method


# virtual methods
.method public final getPuc()LXn/d;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LXn/d<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LC6/b$b$a;->a:LXn/d;

    return-object v0
.end method

.method public onRouteNotRecognized(Ljava/lang/String;)V
    .registers 3

    iget-object p1, p0, LC6/b$b$a;->a:LXn/d;

    if-eqz p1, :cond_9

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p1, v0}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    :cond_9
    const/4 p1, 0x0

    iput-object p1, p0, LC6/b$b$a;->a:LXn/d;

    return-void
.end method

.method public onRouteResolved(Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;)V
    .registers 11

    const-string v0, "activatedRoute"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lkotlinx/coroutines/S;->a()Lkotlinx/coroutines/scheduling/c;

    move-result-object v0

    invoke-static {v0}, LHj/a;->a(LXn/f;)Lkotlinx/coroutines/internal/d;

    move-result-object v0

    new-instance v8, LC6/b$b$a$a;

    iget-object v4, p0, LC6/b$b$a;->c:Landroid/content/Context;

    iget-object v5, p0, LC6/b$b$a;->d:Lcom/flipkart/crossplatform/t;

    iget-object v3, p0, LC6/b$b$a;->b:LXn/d;

    iget-object v6, p0, LC6/b$b$a;->e:Lcom/flipkart/crossplatform/b;

    const/4 v7, 0x0

    move-object v1, v8

    move-object v2, p1

    invoke-direct/range {v1 .. v7}, LC6/b$b$a$a;-><init>(Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;LXn/d;Landroid/content/Context;Lcom/flipkart/crossplatform/t;Lcom/flipkart/crossplatform/b;LXn/d;)V

    const/4 p1, 0x3

    const/4 v1, 0x0

    invoke-static {v0, v1, v8, p1}, Lkotlinx/coroutines/h;->b(Lkotlinx/coroutines/G;LXn/f$a;Leo/p;I)Lkotlinx/coroutines/j0;

    return-void
.end method

.method public final setPuc(LXn/d;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LXn/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LC6/b$b$a;->a:LXn/d;

    return-void
.end method
