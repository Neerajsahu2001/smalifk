.class public final Lc6/a;
.super Lcom/flipkart/android/newmultiwidget/ui/widgets/generators/F;
.source "FlippiFabGenerator.kt"


# direct methods
.method public constructor <init>()V
    .registers 3

    const/16 v0, 0xbf

    const-string v1, "FLIPPI_FAB"

    invoke-direct {p0, v0, v1}, Lcom/flipkart/android/newmultiwidget/ui/widgets/generators/F;-><init>(ILjava/lang/String;)V

    return-void
.end method


# virtual methods
.method public createWidget(I)Lcom/flipkart/android/newmultiwidget/ui/widgets/s;
    .registers 2

    new-instance p1, Lc6/b;

    invoke-direct {p1}, Lc6/b;-><init>()V

    return-object p1
.end method

.method public validateData(Ljava/lang/String;Ljg/g0;LLe/f;LGe/J0;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljg/g0;",
            "LLe/f<",
            "LMe/n1;",
            ">;",
            "LGe/J0;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    new-instance p1, Lc6/b;

    invoke-direct {p1}, Lc6/b;-><init>()V

    invoke-virtual {p1, p2, p3, p4}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->validateData(Ljg/g0;LLe/f;LGe/J0;)Z

    move-result p1

    return p1
.end method
