.class final LC6/b$b$a$a;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactMultiWidgetUtils.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC6/b$b$a;->onRouteResolved(Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.utils.ReactMultiWidgetUtils$changeUriWithChunkLoad$1$1$1$1$onRouteResolved$1"
    f = "ReactMultiWidgetUtils.kt"
    l = {
        0x2f
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:Ljava/lang/Object;

.field b:I

.field final synthetic c:Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;

.field final synthetic d:LXn/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LXn/d<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Lcom/flipkart/crossplatform/t;

.field final synthetic g:Lcom/flipkart/crossplatform/b;


# direct methods
.method constructor <init>(Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;LXn/d;Landroid/content/Context;Lcom/flipkart/crossplatform/t;Lcom/flipkart/crossplatform/b;LXn/d;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;",
            "LXn/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroid/content/Context;",
            "Lcom/flipkart/crossplatform/t;",
            "Lcom/flipkart/crossplatform/b;",
            "LXn/d<",
            "-",
            "LC6/b$b$a$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LC6/b$b$a$a;->c:Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;

    iput-object p2, p0, LC6/b$b$a$a;->d:LXn/d;

    iput-object p3, p0, LC6/b$b$a$a;->e:Landroid/content/Context;

    iput-object p4, p0, LC6/b$b$a$a;->f:Lcom/flipkart/crossplatform/t;

    iput-object p5, p0, LC6/b$b$a$a;->g:Lcom/flipkart/crossplatform/b;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LC6/b$b$a$a;

    iget-object v4, p0, LC6/b$b$a$a;->f:Lcom/flipkart/crossplatform/t;

    iget-object v5, p0, LC6/b$b$a$a;->g:Lcom/flipkart/crossplatform/b;

    iget-object v1, p0, LC6/b$b$a$a;->c:Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;

    iget-object v2, p0, LC6/b$b$a$a;->d:LXn/d;

    iget-object v3, p0, LC6/b$b$a$a;->e:Landroid/content/Context;

    move-object v0, p1

    move-object v6, p2

    invoke-direct/range {v0 .. v6}, LC6/b$b$a$a;-><init>(Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;LXn/d;Landroid/content/Context;Lcom/flipkart/crossplatform/t;Lcom/flipkart/crossplatform/b;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LC6/b$b$a$a;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LC6/b$b$a$a;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LC6/b$b$a$a;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LC6/b$b$a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    const/4 v0, 0x1

    sget-object v1, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v2, p0, LC6/b$b$a$a;->b:I

    if-eqz v2, :cond_15

    if-ne v2, v0, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_66

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LC6/b$b$a$a;->c:Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;

    invoke-virtual {p1}, Lcom/flipkart/navigation/models/uri/route/ActivatedRoute;->getUrlMeta()Lcom/flipkart/navigation/models/uri/URLMeta;

    move-result-object p1

    if-eqz p1, :cond_6b

    invoke-virtual {p1}, Lcom/flipkart/navigation/models/uri/URLMeta;->getPathMeta()Ljava/util/Map;

    move-result-object p1

    const-string v2, "dependentOnChunks"

    invoke-interface {p1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    new-instance v2, Ll4/a;

    iget-object v3, p0, LC6/b$b$a$a;->e:Landroid/content/Context;

    invoke-direct {v2, v3, p1}, Ll4/a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iget-object p1, p0, LC6/b$b$a$a;->f:Lcom/flipkart/crossplatform/t;

    iget-object v3, p0, LC6/b$b$a$a;->g:Lcom/flipkart/crossplatform/b;

    iput v0, p0, LC6/b$b$a$a;->b:I

    new-instance v4, LXn/i;

    invoke-static {p0}, LYn/b;->b(LXn/d;)LXn/d;

    move-result-object v5

    invoke-direct {v4, v5}, LXn/i;-><init>(LXn/d;)V

    new-instance v5, Lkotlin/jvm/internal/D;

    invoke-direct {v5}, Lkotlin/jvm/internal/D;-><init>()V

    iput-object v4, v5, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    new-instance v6, LC6/b$b$a$a$a;

    invoke-direct {v6, v5}, LC6/b$b$a$a$a;-><init>(Lkotlin/jvm/internal/D;)V

    new-instance v5, LCc/e;

    new-array v0, v0, [LDc/c;

    const/4 v7, 0x0

    aput-object v2, v0, v7

    invoke-static {v0}, Lkotlin/collections/q;->H([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-direct {v5, v0}, LCc/e;-><init>(Ljava/util/List;)V

    invoke-virtual {p1, v3, v6, v5}, Lcom/flipkart/crossplatform/t;->loadChunks(Lcom/flipkart/crossplatform/b;LDc/d;LCc/e;)V

    invoke-virtual {v4}, LXn/i;->a()Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_66

    return-object v1

    :cond_66
    :goto_66
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_6b
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iget-object v0, p0, LC6/b$b$a$a;->d:LXn/d;

    invoke-interface {v0, p1}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
