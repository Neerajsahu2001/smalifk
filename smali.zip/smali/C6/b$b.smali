.class final LC6/b$b;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactMultiWidgetUtils.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC6/b;->changeUriWithChunkLoad(Landroid/content/Context;Ljava/lang/String;Lcom/flipkart/crossplatform/b;Lcom/flipkart/crossplatform/t;LC6/b$a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.utils.ReactMultiWidgetUtils$changeUriWithChunkLoad$1$1"
    f = "ReactMultiWidgetUtils.kt"
    l = {
        0x22
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field final synthetic b:LC6/b$a;

.field final synthetic c:LPb/c;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Lcom/flipkart/crossplatform/t;

.field final synthetic g:Lcom/flipkart/crossplatform/b;


# direct methods
.method constructor <init>(LC6/b$a;LPb/c;Ljava/lang/String;Landroid/content/Context;Lcom/flipkart/crossplatform/t;Lcom/flipkart/crossplatform/b;LXn/d;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LC6/b$a;",
            "LPb/c;",
            "Ljava/lang/String;",
            "Landroid/content/Context;",
            "Lcom/flipkart/crossplatform/t;",
            "Lcom/flipkart/crossplatform/b;",
            "LXn/d<",
            "-",
            "LC6/b$b;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LC6/b$b;->b:LC6/b$a;

    iput-object p2, p0, LC6/b$b;->c:LPb/c;

    iput-object p3, p0, LC6/b$b;->d:Ljava/lang/String;

    iput-object p4, p0, LC6/b$b;->e:Landroid/content/Context;

    iput-object p5, p0, LC6/b$b;->f:Lcom/flipkart/crossplatform/t;

    iput-object p6, p0, LC6/b$b;->g:Lcom/flipkart/crossplatform/b;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p7}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LC6/b$b;

    iget-object v5, p0, LC6/b$b;->f:Lcom/flipkart/crossplatform/t;

    iget-object v6, p0, LC6/b$b;->g:Lcom/flipkart/crossplatform/b;

    iget-object v1, p0, LC6/b$b;->b:LC6/b$a;

    iget-object v2, p0, LC6/b$b;->c:LPb/c;

    iget-object v3, p0, LC6/b$b;->d:Ljava/lang/String;

    iget-object v4, p0, LC6/b$b;->e:Landroid/content/Context;

    move-object v0, p1

    move-object v7, p2

    invoke-direct/range {v0 .. v7}, LC6/b$b;-><init>(LC6/b$a;LPb/c;Ljava/lang/String;Landroid/content/Context;Lcom/flipkart/crossplatform/t;Lcom/flipkart/crossplatform/b;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LC6/b$b;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LC6/b$b;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LC6/b$b;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LC6/b$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LC6/b$b;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_3c

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LC6/b$b;->c:LPb/c;

    iget-object v1, p0, LC6/b$b;->d:Ljava/lang/String;

    iget-object v3, p0, LC6/b$b;->e:Landroid/content/Context;

    iget-object v4, p0, LC6/b$b;->f:Lcom/flipkart/crossplatform/t;

    iget-object v5, p0, LC6/b$b;->g:Lcom/flipkart/crossplatform/b;

    iput v2, p0, LC6/b$b;->a:I

    new-instance v2, LXn/i;

    invoke-static {p0}, LYn/b;->b(LXn/d;)LXn/d;

    move-result-object v6

    invoke-direct {v2, v6}, LXn/i;-><init>(LXn/d;)V

    new-instance v6, LC6/b$b$a;

    invoke-direct {v6, v2, v3, v4, v5}, LC6/b$b$a;-><init>(LXn/i;Landroid/content/Context;Lcom/flipkart/crossplatform/t;Lcom/flipkart/crossplatform/b;)V

    invoke-static {p1, v1, v6}, Lcom/flipkart/android/redux/middleware/routing/h;->parseURL(LPb/c;Ljava/lang/String;Lcom/flipkart/navigation/uri/resolvers/c$a;)V

    invoke-virtual {v2}, LXn/i;->a()Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3c

    return-object v0

    :cond_3c
    :goto_3c
    iget-object p1, p0, LC6/b$b;->b:LC6/b$a;

    invoke-interface {p1}, LC6/b$a;->changeUriProceed()V

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
