.class public final Lc6/b;
.super Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;
.source "FlippiFabWidget.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc6/b$a;
    }
.end annotation


# instance fields
.field private Q:Landroid/widget/ImageView;

.field private R:Landroid/widget/ImageView;

.field private S:Lcom/flipkart/android/voice/view/InflateDeflateRippleView;

.field private T:Ljava/util/LinkedHashMap;

.field private W:J

.field private final X:Lcom/flipkart/android/fragments/E;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lc6/b;->T:Ljava/util/LinkedHashMap;

    new-instance v0, Lcom/flipkart/android/fragments/E;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0}, Lcom/flipkart/android/fragments/E;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, Lc6/b;->X:Lcom/flipkart/android/fragments/E;

    return-void
.end method

.method public static g(Lc6/b;Lcom/flipkart/android/voice/flippi/tts/TtsEvent;)V
    .registers 3

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lc6/b$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_2d

    const/4 v0, 0x2

    if-eq p1, v0, :cond_1c

    const/4 v0, 0x3

    if-eq p1, v0, :cond_1c

    goto :goto_3d

    :cond_1c
    iget-object p1, p0, Lc6/b;->S:Lcom/flipkart/android/voice/view/InflateDeflateRippleView;

    if-eqz p1, :cond_23

    invoke-virtual {p1}, Lcom/flipkart/android/voice/view/InflateDeflateRippleView;->stopAnimation()V

    :cond_23
    iget-object p0, p0, Lc6/b;->R:Landroid/widget/ImageView;

    if-nez p0, :cond_28

    goto :goto_3d

    :cond_28
    const/4 p1, 0x4

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_3d

    :cond_2d
    iget-object p1, p0, Lc6/b;->S:Lcom/flipkart/android/voice/view/InflateDeflateRippleView;

    if-eqz p1, :cond_34

    invoke-virtual {p1}, Lcom/flipkart/android/voice/view/InflateDeflateRippleView;->startAnimation()V

    :cond_34
    iget-object p0, p0, Lc6/b;->R:Landroid/widget/ImageView;

    if-nez p0, :cond_39

    goto :goto_3d

    :cond_39
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    :goto_3d
    return-void
.end method

.method private final h(LG5/M;)V
    .registers 6

    iget-object v0, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    if-eqz v0, :cond_8

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_8
    invoke-virtual {p1}, LG5/M;->get_id()J

    move-result-wide v0

    invoke-virtual {p1}, LG5/M;->getScreen_id()J

    move-result-wide v2

    invoke-virtual {p0, v0, v1, v2, v3}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->removeWidget(JJ)V

    return-void
.end method


# virtual methods
.method public bindData(LG5/M;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/newmultiwidget/ui/widgets/q;)V
    .registers 11

    const-string v0, "widget"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "widgetPageInfo"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "parentCallback"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1, p2, p3}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->bindData(LG5/M;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/newmultiwidget/ui/widgets/q;)V

    invoke-virtual {p1}, LG5/M;->getData_()LK5/h;

    move-result-object p2

    const/4 v0, 0x0

    if-eqz p2, :cond_1c

    iget-object p2, p2, LK5/h;->b:Ljg/g0;

    goto :goto_1d

    :cond_1c
    move-object p2, v0

    :goto_1d
    instance-of p2, p2, LWg/b;

    if-nez p2, :cond_25

    invoke-direct {p0, p1}, Lc6/b;->h(LG5/M;)V

    return-void

    :cond_25
    invoke-virtual {p1}, LG5/M;->getData_()LK5/h;

    move-result-object p2

    if-eqz p2, :cond_2e

    iget-object p2, p2, LK5/h;->b:Ljg/g0;

    goto :goto_2f

    :cond_2e
    move-object p2, v0

    :goto_2f
    const-string v1, "null cannot be cast to non-null type com.flipkart.rome.datatypes.response.page.v4.voiceWidgetData.FlippiFabWidgetData"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, LWg/b;

    invoke-virtual {p1}, LG5/M;->getLayout_details()Ltg/f;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->applyLayoutDetailsToWidget(Ltg/f;)V

    iget-object v1, p2, LWg/b;->a:LLe/f;

    if-eqz v1, :cond_46

    iget-object v2, v1, LLe/f;->c:LMe/R3;

    check-cast v2, LMe/r1;

    goto :goto_47

    :cond_46
    move-object v2, v0

    :goto_47
    if-eqz v2, :cond_16b

    iget-object v2, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    if-eqz v2, :cond_16b

    iget-object v2, v1, LLe/f;->c:LMe/R3;

    invoke-static {v2}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    check-cast v2, LMe/r1;

    iget v3, v2, LMe/r1;->i:I

    if-lez v3, :cond_63

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v3

    iget v2, v2, LMe/r1;->i:I

    invoke-static {v3, v2}, Lcom/flipkart/android/utils/Y0;->dpToPx(Landroid/content/Context;I)I

    move-result v2

    goto :goto_6c

    :cond_63
    iget-object v2, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    invoke-static {v2}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    :goto_6c
    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v3

    iget-object v4, v1, LLe/f;->c:LMe/R3;

    check-cast v4, LMe/r1;

    int-to-float v2, v2

    const/4 v5, 0x0

    invoke-static {v3, v4, v5, v5, v2}, Lcom/flipkart/android/utils/h0;->getSatyaUrl(Landroid/content/Context;LMe/r1;FFF)Lcom/flipkart/android/satyabhama/FkRukminiRequest;

    move-result-object v2

    if-eqz v2, :cond_165

    iget-object v3, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    invoke-static {v2, v3}, Lcom/flipkart/android/utils/u1;->adjustImageViewBounds(Lcom/flipkart/android/satyabhama/FkRukminiRequest;Landroid/widget/ImageView;)V

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v3

    iget-object v4, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    invoke-static {v3, v2, v4}, Lcom/flipkart/android/utils/h0;->loadImage(Landroid/content/Context;Lcom/flipkart/android/satyabhama/FkRukminiRequest;Landroid/widget/ImageView;)V

    iget-object v3, v1, LLe/f;->d:LGe/b;

    if-eqz v3, :cond_9d

    iget-object v4, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    if-nez v4, :cond_93

    goto :goto_96

    :cond_93
    invoke-virtual {v4, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    :goto_96
    iget-object v3, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    if-eqz v3, :cond_9d

    invoke-virtual {v3, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_9d
    invoke-virtual {p1}, LG5/M;->getWidget_position()Ljava/lang/Long;

    move-result-object v3

    iget-object v4, v1, LLe/f;->d:LGe/b;

    if-eqz v4, :cond_a8

    iget-object v4, v4, LGe/b;->h:Ljava/util/Map;

    goto :goto_a9

    :cond_a8
    move-object v4, v0

    :goto_a9
    if-eqz v3, :cond_b1

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    iput-wide v5, p0, Lc6/b;->W:J

    :cond_b1
    if-eqz v4, :cond_b8

    iget-object v3, p0, Lc6/b;->T:Ljava/util/LinkedHashMap;

    invoke-interface {v3, v4}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    :cond_b8
    iget-object v3, v1, LGe/B0;->a:Ljava/util/Map;

    if-eqz v3, :cond_d7

    new-instance v3, Lcom/flipkart/android/datagovernance/utils/WidgetInfo;

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getWidgetImpressionId()Lcom/flipkart/android/datagovernance/ImpressionInfo;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Lcom/flipkart/android/datagovernance/utils/WidgetInfo;-><init>(ILcom/flipkart/android/datagovernance/ImpressionInfo;)V

    iget-object v4, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    if-eqz v4, :cond_d0

    const v5, 0x7f1304a6

    invoke-virtual {v4, v5, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_d0
    iget-object v1, v1, LGe/B0;->a:Ljava/util/Map;

    iget-object v3, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    invoke-virtual {p0, v1, v3}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->setTrackingInfo(Ljava/util/Map;Landroid/view/View;)V

    :cond_d7
    iget-object p2, p2, LWg/b;->b:LIe/g;

    if-eqz p2, :cond_165

    invoke-virtual {v2}, Lcom/flipkart/android/satyabhama/FkRukminiRequest;->getHeight()I

    move-result v0

    const v1, 0x7f0701b9

    if-lez v0, :cond_f9

    invoke-virtual {v2}, Lcom/flipkart/android/satyabhama/FkRukminiRequest;->getHeight()I

    move-result v0

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v3

    float-to-int v3, v3

    mul-int/lit8 v3, v3, 0x2

    add-int/2addr v3, v0

    goto :goto_109

    :cond_f9
    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v3, 0x7f0701b7

    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v0

    float-to-int v3, v0

    :goto_109
    invoke-virtual {v2}, Lcom/flipkart/android/satyabhama/FkRukminiRequest;->getWidth()I

    move-result v0

    if-lez v0, :cond_124

    invoke-virtual {v2}, Lcom/flipkart/android/satyabhama/FkRukminiRequest;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v1

    float-to-int v1, v1

    mul-int/lit8 v1, v1, 0x2

    add-int/2addr v1, v0

    goto :goto_134

    :cond_124
    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f0701b8

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v0

    float-to-int v1, v0

    :goto_134
    iget-object v0, p0, Lc6/b;->S:Lcom/flipkart/android/voice/view/InflateDeflateRippleView;

    if-eqz v0, :cond_13b

    invoke-virtual {v0, p2, v3, v1}, Lcom/flipkart/android/voice/view/InflateDeflateRippleView;->setupView(LIe/e;II)V

    :cond_13b
    instance-of p2, p3, Landroidx/fragment/app/Fragment;

    if-eqz p2, :cond_163

    move-object p2, p3

    check-cast p2, Landroidx/fragment/app/Fragment;

    invoke-virtual {p2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v0

    instance-of v0, v0, La8/c;

    if-eqz v0, :cond_163

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "context"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object p2

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.voice.flippi.FlippiCallback"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, La8/c;

    iget-object v1, p0, Lc6/b;->X:Lcom/flipkart/android/fragments/E;

    invoke-static {v0, p2, p3, v1}, La8/h;->observeFlippiTts(Landroid/content/Context;La8/c;Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    :cond_163
    sget-object v0, LUn/r;->a:LUn/r;

    :cond_165
    if-nez v0, :cond_16e

    invoke-direct {p0, p1}, Lc6/b;->h(LG5/M;)V

    goto :goto_16e

    :cond_16b
    invoke-direct {p0, p1}, Lc6/b;->h(LG5/M;)V

    :cond_16e
    :goto_16e
    return-void
.end method

.method public createView(Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 5

    const-string v0, "parent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f0e02b9

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const-string v0, "from(parent.context).inf\u2026v4_flippi, parent, false)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const v0, 0x7f0b035f

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lc6/b;->Q:Landroid/widget/ImageView;

    const v0, 0x7f0b05fb

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/flipkart/android/voice/view/InflateDeflateRippleView;

    iput-object v0, p0, Lc6/b;->S:Lcom/flipkart/android/voice/view/InflateDeflateRippleView;

    const v0, 0x7f0b00ad

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lc6/b;->R:Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    return-object p1
.end method

.method public onClick(Landroid/view/View;)V
    .registers 9

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->onClick(Landroid/view/View;)V

    new-instance p1, Lcom/flipkart/android/utils/i1;

    iget-object v0, p0, Lc6/b;->T:Ljava/util/LinkedHashMap;

    invoke-direct {p1, v0}, Lcom/flipkart/android/utils/i1;-><init>(Ljava/util/Map;)V

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/flipkart/android/datagovernance/ImpressionInfo;->instantiate(Lcom/flipkart/android/utils/i1;Ljava/lang/String;)Lcom/flipkart/android/datagovernance/ImpressionInfo;

    move-result-object v3

    const-string v0, "instantiate(helper, null)"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/flipkart/android/datagovernance/events/discovery/DiscoveryContentClick;

    iget-wide v1, p0, Lc6/b;->W:J

    long-to-int v2, v1

    invoke-virtual {p1}, Lcom/flipkart/android/utils/i1;->getContentType()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v6}, Lcom/flipkart/android/datagovernance/events/discovery/DiscoveryContentClick;-><init>(ILcom/flipkart/android/datagovernance/ImpressionInfo;Ljava/lang/String;Lcom/flipkart/android/datagovernance/ImpressionInfo;Lcom/flipkart/android/datagovernance/ImpressionInfo;)V

    invoke-virtual {p0, v0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->ingestEvent(Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    return-void
.end method
