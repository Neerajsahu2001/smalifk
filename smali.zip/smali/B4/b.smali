.class public final LB4/b;
.super Ljava/lang/Object;
.source "TrackingConfig.java"


# instance fields
.field public a:I
    .annotation runtime Lyk/b;
        value = "minViewVisibleTime"
    .end annotation
.end field

.field public b:I
    .annotation runtime Lyk/b;
        value = "minViewVisiblePercentage"
    .end annotation
.end field

.field public c:Lcom/flipkart/android/configmodel/t0;
    .annotation runtime Lyk/b;
        value = "installedAppSizeConfig"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xa

    iput v0, p0, LB4/b;->a:I

    const/4 v0, 0x1

    iput v0, p0, LB4/b;->b:I

    return-void
.end method


# virtual methods
.method public getMinViewVisiblePercentage()I
    .registers 2

    iget v0, p0, LB4/b;->b:I

    return v0
.end method

.method public getMinViewVisibleTime()I
    .registers 2

    iget v0, p0, LB4/b;->a:I

    return v0
.end method
