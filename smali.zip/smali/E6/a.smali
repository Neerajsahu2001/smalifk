.class public final Le6/a;
.super Ljava/lang/Object;
.source "ActionUtils.java"


# direct methods
.method public static getAsString(Ljava/lang/Object;)Ljava/lang/String;
    .registers 2

    instance-of v0, p0, Ljava/lang/String;

    if-eqz v0, :cond_7

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_7
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getBundleName(Lq4/i;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    invoke-virtual {p0, p1}, Lq4/i;->getPageInfo(Ljava/lang/String;)Lxk/s;

    move-result-object p0

    const-string p1, "bundleName"

    invoke-static {p0, p1}, Lcom/flipkart/android/wike/utils/JsonUtils;->getPropertyAsString(Lxk/s;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static getMapiFromRomeAction(LGe/b;)Lcom/flipkart/mapi/model/component/data/renderables/b;
    .registers 4

    new-instance v0, Lcom/flipkart/mapi/model/component/data/renderables/b;

    invoke-direct {v0}, Lcom/flipkart/mapi/model/component/data/renderables/b;-><init>()V

    iget-object v1, p0, LGe/b;->e:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->e:Ljava/lang/String;

    iget-object v1, p0, LGe/b;->a:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->a:Ljava/lang/String;

    iget-object v1, p0, LGe/b;->k:Ljava/util/List;

    iput-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->m:Ljava/util/List;

    iget-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    iget-object v2, p0, LGe/b;->f:Ljava/util/Map;

    invoke-interface {v1, v2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    iget-object v1, p0, LGe/b;->d:Ljava/lang/String;

    iput-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->d:Ljava/lang/String;

    iget-object p0, p0, LGe/b;->b:Ljava/lang/String;

    iput-object p0, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->b:Ljava/lang/String;

    return-object v0
.end method

.method public static getProjectName(Lq4/i;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    invoke-virtual {p0, p1}, Lq4/i;->getPageInfo(Ljava/lang/String;)Lxk/s;

    move-result-object p0

    const-string p1, "projectName"

    invoke-static {p0, p1}, Lcom/flipkart/android/wike/utils/JsonUtils;->getPropertyAsString(Lxk/s;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static getResultAction(Lcom/flipkart/android/newmultiwidget/w;)Lcom/flipkart/mapi/model/component/data/renderables/b;
    .registers 4

    new-instance v0, Lcom/flipkart/mapi/model/component/data/renderables/b;

    invoke-direct {v0}, Lcom/flipkart/mapi/model/component/data/renderables/b;-><init>()V

    const-string v1, "RESULT"

    iput-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->b:Ljava/lang/String;

    iget-object v1, p0, Lcom/flipkart/android/newmultiwidget/w;->b:Ljava/io/Serializable;

    if-eqz v1, :cond_14

    iget-object v2, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    iget-object p0, p0, Lcom/flipkart/android/newmultiwidget/w;->a:Ljava/lang/String;

    invoke-interface {v2, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_14
    return-object v0
.end method

.method public static getResultKey(Lcom/flipkart/mapi/model/component/data/renderables/b;)Ljava/lang/String;
    .registers 3

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    :cond_4
    iget-object p0, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v1, "resultKey"

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    instance-of v1, p0, Ljava/lang/String;

    if-eqz v1, :cond_13

    move-object v0, p0

    check-cast v0, Ljava/lang/String;

    :cond_13
    return-object v0
.end method

.method public static getRomeFromMapiAction(Lcom/flipkart/mapi/model/component/data/renderables/b;)LGe/b;
    .registers 4

    new-instance v0, LGe/b;

    invoke-direct {v0}, LGe/b;-><init>()V

    iget-object v1, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->k:Lcom/flipkart/mapi/model/mlogin/MLoginType;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, LGe/b;->j:Ljava/lang/String;

    iget-object v1, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->e:Ljava/lang/String;

    iput-object v1, v0, LGe/b;->e:Ljava/lang/String;

    iget-object v1, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->a:Ljava/lang/String;

    iput-object v1, v0, LGe/b;->a:Ljava/lang/String;

    iget-object v1, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->m:Ljava/util/List;

    iput-object v1, v0, LGe/b;->k:Ljava/util/List;

    iget-object v1, v0, LGe/b;->f:Ljava/util/Map;

    iget-object v2, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    invoke-interface {v1, v2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    iget-object p0, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->b:Ljava/lang/String;

    if-eqz p0, :cond_26

    iput-object p0, v0, LGe/b;->b:Ljava/lang/String;

    :cond_26
    return-object v0
.end method

.method public static updateAction(Lcom/flipkart/mapi/model/component/data/renderables/b;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    iget-object v0, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v1, "bundleName"

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p0, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string p1, "screenName"

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
