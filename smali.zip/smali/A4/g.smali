.class public final La4/g;
.super Landroid/app/Service;
.source "BNPLUploadService.java"


# instance fields
.field a:Ljava/lang/String;

.field private b:Z

.field private c:Ljava/util/concurrent/ExecutorService;

.field private d:Landroid/os/Handler;

.field private e:Landroidx/collection/b;

.field private f:Landroidx/collection/b;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, La4/g;->b:Z

    return-void
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;)Landroidx/core/app/NotificationCompat$Builder;
    .registers 5

    new-instance v0, Landroidx/core/app/NotificationCompat$Builder;

    const-string v1, "fk_channel_alerts_subs"

    invoke-direct {v0, p0, v1}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x7f0801d6

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->z(I)V

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->k(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p2}, Landroidx/core/app/NotificationCompat$Builder;->j(Ljava/lang/CharSequence;)V

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->u(Z)V

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->v(I)V

    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->w()V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->e(Z)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/c;->isPNColorEnabled()Z

    move-result p1

    if-eqz p1, :cond_35

    const p1, 0x7f06013e

    invoke-static {p0, p1}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->g(I)V

    :cond_35
    return-object v0
.end method

.method private c()V
    .registers 2

    iget-object v0, p0, La4/g;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_d

    iget-object v0, p0, La4/g;->a:Ljava/lang/String;

    invoke-static {p0, v0}, Lc4/a;->showErrorNotification(Landroid/content/Context;Ljava/lang/String;)V

    :cond_d
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void
.end method

.method public static generateIntent(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;
    .registers 5

    new-instance v0, Landroid/content/Intent;

    const-class v1, La4/g;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string p0, "action"

    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string p0, "type"

    invoke-virtual {v0, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    return-object v0
.end method

.method public static start(Landroid/content/Context;ILjava/lang/String;)V
    .registers 3

    return-void
.end method


# virtual methods
.method final b(La4/g;)V
    .registers 29

    move-object/from16 v13, p0

    move-object/from16 v0, p1

    invoke-static/range {p1 .. p1}, Lcom/flipkart/android/utils/A0;->isNetworkAvailable(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_d

    invoke-direct/range {p0 .. p0}, La4/g;->c()V

    :cond_d
    invoke-static {}, LFa/d;->newFuture()LFa/d;

    move-result-object v1

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getRequestQueueHelper()Lcom/flipkart/android/init/p;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/flipkart/android/init/p;->getNetworkSpeed(Landroid/content/Context;)Lcom/flipkart/android/configmodel/image/NetworkSpeed;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getRequestQueueHelper()Lcom/flipkart/android/init/p;

    move-result-object v3

    invoke-virtual {v3}, Lcom/flipkart/android/init/p;->getAverageNetworkSpeed()D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getVarysHttpService()LDa/c;

    move-result-object v4

    const-string v5, "CONSUMER_APP"

    invoke-interface {v4, v5, v2, v3}, LDa/c;->handshake(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lta/a;

    move-result-object v2

    invoke-virtual {v1, v2}, LFa/d;->enqueue(Lta/a;)V

    :try_start_36
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x3c

    invoke-virtual {v1, v3, v4, v2}, LFa/d;->get(JLjava/util/concurrent/TimeUnit;)Lretrofit2/F;

    move-result-object v1
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_36 .. :try_end_3e} :catch_368

    if-eqz v1, :cond_366

    invoke-virtual {v1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_366

    invoke-virtual {v1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LGe/e0;

    iget-object v2, v2, LGe/e0;->a:Ljava/lang/Object;

    if-eqz v2, :cond_366

    invoke-virtual {v1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LGe/e0;

    iget-object v2, v2, LGe/e0;->a:Ljava/lang/Object;

    move-object v14, v2

    check-cast v14, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;

    invoke-virtual {v1}, Lretrofit2/F;->e()Lokhttp3/Headers;

    move-result-object v1

    const-string v2, "X-Access-Token"

    invoke-virtual {v1, v2}, Lokhttp3/Headers;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getKey()Ljava/lang/String;

    move-result-object v16

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getKeyid()Ljava/lang/String;

    move-result-object v17

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->getCheckEligibilityConfig()Lcom/flipkart/android/configmodel/J;

    move-result-object v1

    const/16 v18, 0x0

    if-eqz v1, :cond_8b

    iget-boolean v2, v1, Lcom/flipkart/android/configmodel/J;->h:Z

    if-eqz v2, :cond_8b

    const/4 v2, 0x1

    const/16 v19, 0x1

    goto :goto_8d

    :cond_8b
    const/16 v19, 0x0

    :goto_8d
    if-eqz v1, :cond_93

    iget v1, v1, Lcom/flipkart/android/configmodel/J;->i:I

    move v10, v1

    goto :goto_94

    :cond_93
    const/4 v10, 0x0

    :goto_94
    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    if-eqz v1, :cond_16c

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getCompleted()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_16c

    const-string v1, "android.permission.READ_SMS"

    invoke-static {v0, v1}, Landroidx/core/content/c;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    const-string v9, "SMS"

    if-nez v1, :cond_147

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getSenderBlacklist()Ljava/util/List;

    move-result-object v1

    if-nez v1, :cond_c1

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :cond_c1
    move-object v8, v1

    sget-object v1, Landroid/util/Patterns;->PHONE:Ljava/util/regex/Pattern;

    invoke-virtual {v1}, Ljava/util/regex/Pattern;->pattern()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v8, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v7, Lcom/flipkart/android/bnpl/jobs/EligibilitySmsBatchJob;

    new-instance v6, Lqi/a;

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getFromTime()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-direct {v6, v1, v2, v10}, Lqi/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getSenderWhitelist()Ljava/util/List;

    move-result-object v20

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getBodyWhitelist()Ljava/util/List;

    move-result-object v21

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getBodyBlacklist()Ljava/util/List;

    move-result-object v22

    iget-boolean v5, v13, La4/g;->b:Z

    move-object v1, v7

    move-object/from16 v2, p0

    move-object/from16 v3, v16

    move-object/from16 v4, v17

    move/from16 v23, v5

    move-object v5, v15

    move-object/from16 v24, v15

    move-object v15, v7

    move-object/from16 v7, v20

    move-object v0, v9

    move-object/from16 v9, v21

    move/from16 v25, v10

    move-object/from16 v10, v22

    move-object v13, v11

    move/from16 v11, v23

    move-object/from16 v26, v12

    move/from16 v12, v19

    invoke-direct/range {v1 .. v12}, Lcom/flipkart/android/bnpl/jobs/EligibilitySmsBatchJob;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lqi/a;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;ZZ)V

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_137

    invoke-virtual {v13, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v9, p0

    move-object v10, v13

    move-object/from16 v8, v26

    goto :goto_13f

    :cond_137
    move-object/from16 v8, v26

    invoke-virtual {v8, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v9, p0

    move-object v10, v13

    :goto_13f
    iget-object v1, v9, La4/g;->e:Landroidx/collection/b;

    if-eqz v1, :cond_173

    invoke-virtual {v1, v0}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    goto :goto_173

    :cond_147
    move-object v0, v9

    move/from16 v25, v10

    move-object v10, v11

    move-object v8, v12

    move-object v9, v13

    move-object/from16 v24, v15

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getSmsUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/SmsUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_173

    iget-boolean v1, v9, La4/g;->b:Z

    if-nez v1, :cond_173

    iget-object v1, v9, La4/g;->f:Landroidx/collection/b;

    if-eqz v1, :cond_168

    invoke-virtual {v1, v0}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    :cond_168
    invoke-direct/range {p0 .. p0}, La4/g;->c()V

    return-void

    :cond_16c
    move/from16 v25, v10

    move-object v10, v11

    move-object v8, v12

    move-object v9, v13

    move-object/from16 v24, v15

    :cond_173
    :goto_173
    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getContactUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;

    move-result-object v0

    if-eqz v0, :cond_1ed

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getContactUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;->getCompleted()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_1ed

    const-string v0, "android.permission.READ_CONTACTS"

    move-object/from16 v11, p1

    invoke-static {v11, v0}, Landroidx/core/content/c;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const-string v12, "CONTACT"

    if-nez v0, :cond_1d0

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getContactUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;->getFromIdString()Ljava/lang/String;

    move-result-object v0

    new-instance v13, Lcom/flipkart/android/bnpl/jobs/EligibilityContactsBatchJob;

    new-instance v3, Lqi/a;

    const/4 v1, 0x0

    move/from16 v2, v25

    invoke-direct {v3, v0, v1, v2}, Lqi/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-boolean v7, v9, La4/g;->b:Z

    move-object v1, v13

    move-object/from16 v2, p0

    move-object/from16 v4, v16

    move-object/from16 v5, v17

    move-object/from16 v6, v24

    invoke-direct/range {v1 .. v7}, Lcom/flipkart/android/bnpl/jobs/EligibilityContactsBatchJob;-><init>(Landroid/content/Context;Lqi/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getContactUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1c5

    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1c8

    :cond_1c5
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1c8
    iget-object v0, v9, La4/g;->e:Landroidx/collection/b;

    if-eqz v0, :cond_1ef

    invoke-virtual {v0, v12}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    goto :goto_1ef

    :cond_1d0
    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getContactUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/ContactUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1ef

    iget-boolean v0, v9, La4/g;->b:Z

    if-nez v0, :cond_1ef

    iget-object v0, v9, La4/g;->f:Landroidx/collection/b;

    if-eqz v0, :cond_1e9

    invoke-virtual {v0, v12}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    :cond_1e9
    invoke-direct/range {p0 .. p0}, La4/g;->c()V

    return-void

    :cond_1ed
    move-object/from16 v11, p1

    :cond_1ef
    :goto_1ef
    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getLocationUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/LocationUploadRules;

    move-result-object v0

    if-eqz v0, :cond_25f

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getLocationUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/LocationUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/LocationUploadRules;->getCompleted()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_25f

    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-static {v11, v0}, Landroidx/core/content/c;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const-string v7, "LOCATION"

    if-eqz v0, :cond_233

    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-static {v11, v0}, Landroidx/core/content/c;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_216

    goto :goto_233

    :cond_216
    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getLocationUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/LocationUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/LocationUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_25f

    iget-boolean v0, v9, La4/g;->b:Z

    if-nez v0, :cond_25f

    iget-object v0, v9, La4/g;->f:Landroidx/collection/b;

    if-eqz v0, :cond_22f

    invoke-virtual {v0, v7}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    :cond_22f
    invoke-direct/range {p0 .. p0}, La4/g;->c()V

    return-void

    :cond_233
    :goto_233
    new-instance v0, Lcom/flipkart/android/bnpl/jobs/EligibilityLocationJob;

    iget-boolean v6, v9, La4/g;->b:Z

    move-object v1, v0

    move-object/from16 v2, p0

    move-object/from16 v3, v16

    move-object/from16 v4, v17

    move-object/from16 v5, v24

    invoke-direct/range {v1 .. v6}, Lcom/flipkart/android/bnpl/jobs/EligibilityLocationJob;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getLocationUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/LocationUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/LocationUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_255

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_258

    :cond_255
    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_258
    iget-object v0, v9, La4/g;->e:Landroidx/collection/b;

    if-eqz v0, :cond_25f

    invoke-virtual {v0, v7}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    :cond_25f
    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getDeviceUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/DeviceUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/DeviceUploadRules;->getCompleted()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_2c1

    const-string v0, "android.permission.READ_PHONE_STATE"

    invoke-static {v11, v0}, Landroidx/core/content/c;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const-string v7, "DEVICE"

    if-nez v0, :cond_2a4

    new-instance v0, Lcom/flipkart/android/bnpl/jobs/EligibilityDeviceJob;

    iget-boolean v6, v9, La4/g;->b:Z

    move-object v1, v0

    move-object/from16 v2, p0

    move-object/from16 v3, v16

    move-object/from16 v4, v17

    move-object/from16 v5, v24

    invoke-direct/range {v1 .. v6}, Lcom/flipkart/android/bnpl/jobs/EligibilityDeviceJob;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getDeviceUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/DeviceUploadRules;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/varys/interfaces/web/handshake/DeviceUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_299

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_29c

    :cond_299
    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_29c
    iget-object v0, v9, La4/g;->e:Landroidx/collection/b;

    if-eqz v0, :cond_2c1

    invoke-virtual {v0, v7}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    goto :goto_2c1

    :cond_2a4
    invoke-virtual {v14}, Lcom/flipkart/varys/interfaces/web/HandshakeResponseV3;->getDeviceUploadRules()Lcom/flipkart/varys/interfaces/web/handshake/DeviceUploadRules;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/varys/interfaces/web/handshake/DeviceUploadRules;->getMandatory()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_2c1

    iget-boolean v0, v9, La4/g;->b:Z

    if-nez v0, :cond_2c1

    iget-object v0, v9, La4/g;->f:Landroidx/collection/b;

    if-eqz v0, :cond_2bd

    invoke-virtual {v0, v7}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    :cond_2bd
    invoke-direct/range {p0 .. p0}, La4/g;->c()V

    return-void

    :cond_2c1
    :goto_2c1
    invoke-virtual {v10}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2cf

    invoke-virtual {v8}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2cf

    goto/16 :goto_367

    :cond_2cf
    const/4 v1, 0x0

    :goto_2d0
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_319

    :try_start_2d6
    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Callable;

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;
    :try_end_2df
    .catch Ljava/lang/Exception; {:try_start_2d6 .. :try_end_2df} :catch_2e2

    add-int/lit8 v1, v1, 0x1

    goto :goto_2d0

    :catch_2e2
    move-exception v0

    instance-of v2, v0, Ljava/lang/SecurityException;

    if-eqz v2, :cond_2e8

    goto :goto_2ea

    :cond_2e8
    instance-of v0, v0, Ljava/io/IOException;

    :goto_2ea
    iget-object v0, v9, La4/g;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2f7

    iget-object v0, v9, La4/g;->a:Ljava/lang/String;

    invoke-static {v9, v0}, Lc4/a;->showErrorNotification(Landroid/content/Context;Ljava/lang/String;)V

    :cond_2f7
    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Callable;

    invoke-static {v0}, La4/h;->getFeature(Ljava/util/concurrent/Callable;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, v9, La4/g;->e:Landroidx/collection/b;

    if-eqz v1, :cond_308

    invoke-virtual {v1, v0}, Landroidx/collection/b;->remove(Ljava/lang/Object;)Z

    :cond_308
    iget-object v1, v9, La4/g;->f:Landroidx/collection/b;

    if-eqz v1, :cond_30f

    invoke-virtual {v1, v0}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    :cond_30f
    iget-object v0, v9, La4/g;->e:Landroidx/collection/b;

    iget-object v1, v9, La4/g;->f:Landroidx/collection/b;

    iget-object v2, v9, La4/g;->a:Ljava/lang/String;

    invoke-static {v0, v1, v9, v2}, La4/b;->a(Landroidx/collection/b;Landroidx/collection/b;Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_367

    :cond_319
    const/4 v1, 0x0

    :goto_31a
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_356

    :try_start_320
    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Callable;

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;
    :try_end_329
    .catch Ljava/lang/Exception; {:try_start_320 .. :try_end_329} :catch_32a

    goto :goto_353

    :catch_32a
    move-exception v0

    instance-of v2, v0, Ljava/lang/SecurityException;

    if-eqz v2, :cond_330

    goto :goto_332

    :cond_330
    instance-of v0, v0, Ljava/io/IOException;

    :goto_332
    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Callable;

    invoke-static {v0}, La4/h;->getFeature(Ljava/util/concurrent/Callable;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, v9, La4/g;->e:Landroidx/collection/b;

    if-eqz v2, :cond_343

    invoke-virtual {v2, v0}, Landroidx/collection/b;->remove(Ljava/lang/Object;)Z

    :cond_343
    iget-object v2, v9, La4/g;->f:Landroidx/collection/b;

    if-eqz v2, :cond_34a

    invoke-virtual {v2, v0}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    :cond_34a
    iget-object v0, v9, La4/g;->e:Landroidx/collection/b;

    iget-object v2, v9, La4/g;->f:Landroidx/collection/b;

    iget-object v3, v9, La4/g;->a:Ljava/lang/String;

    invoke-static {v0, v2, v9, v3}, La4/b;->a(Landroidx/collection/b;Landroidx/collection/b;Landroid/content/Context;Ljava/lang/String;)V

    :goto_353
    add-int/lit8 v1, v1, 0x1

    goto :goto_31a

    :cond_356
    iget-object v0, v9, La4/g;->d:Landroid/os/Handler;

    if-eqz v0, :cond_367

    new-instance v1, La4/f;

    invoke-direct {v1, v9}, La4/f;-><init>(La4/g;)V

    const-wide/32 v2, 0x493e0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_367

    :cond_366
    move-object v9, v13

    :cond_367
    :goto_367
    return-void

    :catch_368
    move-object v9, v13

    return-void
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 2

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .registers 3

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    new-instance v0, Landroidx/collection/b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/collection/b;-><init>(I)V

    iput-object v0, p0, La4/g;->e:Landroidx/collection/b;

    new-instance v0, Landroidx/collection/b;

    invoke-direct {v0, v1}, Landroidx/collection/b;-><init>(I)V

    iput-object v0, p0, La4/g;->f:Landroidx/collection/b;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_29

    const-string v0, "notification"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    if-eqz v0, :cond_29

    invoke-static {}, La4/d;->a()Landroid/app/NotificationChannel;

    move-result-object v1

    invoke-static {v0, v1}, La4/c;->f(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    :cond_29
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, La4/g;->d:Landroid/os/Handler;

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, La4/g;->c:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method public onDestroy()V
    .registers 3

    const/4 v0, 0x0

    iput-object v0, p0, La4/g;->e:Landroidx/collection/b;

    iput-object v0, p0, La4/g;->f:Landroidx/collection/b;

    iget-object v1, p0, La4/g;->c:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iget-object v1, p0, La4/g;->d:Landroid/os/Handler;

    if-eqz v1, :cond_13

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iput-object v0, p0, La4/g;->d:Landroid/os/Handler;

    :cond_13
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 10

    const/4 v0, 0x2

    if-eqz p1, :cond_d5

    const-string v1, "action"

    invoke-virtual {p1, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_d

    goto/16 :goto_d5

    :cond_d
    const/4 v2, -0x1

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const-string v2, "type"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, La4/g;->a:Ljava/lang/String;

    const/16 v2, 0x2db

    const-string v3, "notification"

    const/4 v4, 0x1

    if-ne v1, v4, :cond_66

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getCheckEligibilityConfig()Lcom/flipkart/android/configmodel/J;

    move-result-object v0

    if-eqz v0, :cond_4e

    iget-object v1, v0, Lcom/flipkart/android/configmodel/J;->c:Ljava/lang/String;

    iget-object v0, v0, Lcom/flipkart/android/configmodel/J;->d:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_3b

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_4e

    :cond_3b
    invoke-virtual {p0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/NotificationManager;

    if-eqz v3, :cond_4e

    invoke-direct {p0, v1, v0}, La4/g;->a(Ljava/lang/String;Ljava/lang/String;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->a()Landroid/app/Notification;

    move-result-object v0

    invoke-virtual {v3, v2, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    :cond_4e
    iget-object v0, p0, La4/g;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_5b

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    goto/16 :goto_d0

    :cond_5b
    iget-object v0, p0, La4/g;->c:Ljava/util/concurrent/ExecutorService;

    new-instance v1, La4/e;

    invoke-direct {v1, p0}, La4/e;-><init>(La4/g;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    goto :goto_d0

    :cond_66
    const/4 v5, 0x4

    if-ne v1, v5, :cond_af

    iput-boolean v4, p0, La4/g;->b:Z

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getCheckEligibilityConfig()Lcom/flipkart/android/configmodel/J;

    move-result-object v0

    if-eqz v0, :cond_98

    iget-object v1, v0, Lcom/flipkart/android/configmodel/J;->a:Ljava/lang/String;

    iget-object v0, v0, Lcom/flipkart/android/configmodel/J;->b:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_85

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_98

    :cond_85
    invoke-virtual {p0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/NotificationManager;

    if-eqz v3, :cond_98

    invoke-direct {p0, v1, v0}, La4/g;->a(Ljava/lang/String;Ljava/lang/String;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->a()Landroid/app/Notification;

    move-result-object v0

    invoke-virtual {v3, v2, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    :cond_98
    iget-object v0, p0, La4/g;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_a4

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    goto :goto_d0

    :cond_a4
    iget-object v0, p0, La4/g;->c:Ljava/util/concurrent/ExecutorService;

    new-instance v1, La4/e;

    invoke-direct {v1, p0}, La4/e;-><init>(La4/g;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    goto :goto_d0

    :cond_af
    if-ne v1, v0, :cond_ca

    iget-object v0, p0, La4/g;->d:Landroid/os/Handler;

    if-eqz v0, :cond_b9

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    :cond_b9
    iget-object v0, p0, La4/g;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_c6

    iget-object v0, p0, La4/g;->a:Ljava/lang/String;

    invoke-static {p0, v0}, Lc4/a;->showCompletedNotification(Landroid/content/Context;Ljava/lang/String;)V

    :cond_c6
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    goto :goto_d0

    :cond_ca
    const/4 v0, 0x3

    if-ne v1, v0, :cond_d0

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    :cond_d0
    :goto_d0
    invoke-super {p0, p1, p2, p3}, Landroid/app/Service;->onStartCommand(Landroid/content/Intent;II)I

    move-result p1

    return p1

    :cond_d5
    :goto_d5
    return v0
.end method
