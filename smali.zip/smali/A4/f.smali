.class final La4/f;
.super Ljava/lang/Object;
.source "BNPLUploadService.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:La4/g;


# direct methods
.method constructor <init>(La4/g;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La4/f;->a:La4/g;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, La4/f;->a:La4/g;

    iget-object v1, v0, La4/g;->a:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_f

    iget-object v1, v0, La4/g;->a:Ljava/lang/String;

    invoke-static {v0, v1}, Lc4/a;->showCheckBackLaterNotification(Landroid/content/Context;Ljava/lang/String;)V

    :cond_f
    invoke-virtual {v0}, Landroid/app/Service;->stopSelf()V

    return-void
.end method
