.class public final synthetic La4/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static synthetic a()Landroid/app/NotificationChannel;
    .registers 4

    new-instance v0, Landroid/app/NotificationChannel;

    const-string v1, "fk_channel_alerts_subs"

    const-string v2, "Alerts and Subscriptions"

    const/4 v3, 0x3

    invoke-direct {v0, v1, v2, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    return-object v0
.end method

.method public static bridge synthetic b()Landroid/graphics/ColorSpace$Named;
    .registers 1

    sget-object v0, Landroid/graphics/ColorSpace$Named;->SRGB:Landroid/graphics/ColorSpace$Named;

    return-object v0
.end method

.method public static bridge synthetic c()Ljava/util/Base64$Decoder;
    .registers 1

    invoke-static {}, Ljava/util/Base64;->getDecoder()Ljava/util/Base64$Decoder;

    move-result-object v0

    return-object v0
.end method

.method public static bridge synthetic d(Landroid/app/NotificationChannel;Ljava/lang/String;)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    return-void
.end method

.method public static bridge synthetic e(Lcom/facebook/react/views/text/ReactTextView;)V
    .registers 2

    const/16 v0, 0x10

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setFocusable(I)V

    return-void
.end method
