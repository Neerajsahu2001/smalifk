.class public final La4/h;
.super Ljava/lang/Object;
.source "UploadFeature.java"


# direct methods
.method public static getDisplayNamesForPermission(Ljava/lang/String;)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, -0x1

    sparse-switch v1, :sswitch_data_5a

    goto :goto_3d

    :sswitch_12
    const-string v1, "android.permission.READ_CONTACTS"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1b

    goto :goto_3d

    :cond_1b
    const/4 v2, 0x3

    goto :goto_3d

    :sswitch_1d
    const-string v1, "android.permission.READ_PHONE_STATE"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_26

    goto :goto_3d

    :cond_26
    const/4 v2, 0x2

    goto :goto_3d

    :sswitch_28
    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_31

    goto :goto_3d

    :cond_31
    const/4 v2, 0x1

    goto :goto_3d

    :sswitch_33
    const-string v1, "android.permission.READ_SMS"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3c

    goto :goto_3d

    :cond_3c
    const/4 v2, 0x0

    :goto_3d
    packed-switch v2, :pswitch_data_6c

    goto :goto_58

    :pswitch_41
    const-string p0, "Contacts"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_58

    :pswitch_47
    const-string p0, "Device Information"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_58

    :pswitch_4d
    const-string p0, "Location"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_58

    :pswitch_53
    const-string p0, "SMS"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_58
    return-object v0

    nop

    :sswitch_data_5a
    .sparse-switch
        -0x7aed85b0 -> :sswitch_33
        -0x70918bc1 -> :sswitch_28
        -0x550ba9 -> :sswitch_1d
        0x75dd2d9c -> :sswitch_12
    .end sparse-switch

    :pswitch_data_6c
    .packed-switch 0x0
        :pswitch_53
        :pswitch_4d
        :pswitch_47
        :pswitch_41
    .end packed-switch
.end method

.method public static getFeature(Ljava/util/concurrent/Callable;)Ljava/lang/String;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    instance-of v0, p0, Lcom/flipkart/android/bnpl/jobs/EligibilitySmsBatchJob;

    if-eqz v0, :cond_7

    const-string p0, "SMS"

    return-object p0

    :cond_7
    instance-of v0, p0, Lcom/flipkart/android/bnpl/jobs/EligibilityDeviceJob;

    if-eqz v0, :cond_e

    const-string p0, "DEVICE"

    return-object p0

    :cond_e
    instance-of v0, p0, Lcom/flipkart/android/bnpl/jobs/EligibilityLocationJob;

    if-eqz v0, :cond_15

    const-string p0, "LOCATION"

    return-object p0

    :cond_15
    instance-of p0, p0, Lcom/flipkart/android/bnpl/jobs/EligibilityContactsBatchJob;

    if-eqz p0, :cond_1c

    const-string p0, "CONTACT"

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getPermissions(Ljava/lang/String;)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, -0x1

    sparse-switch v1, :sswitch_data_58

    goto :goto_3c

    :sswitch_11
    const-string v1, "DEVICE"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1a

    goto :goto_3c

    :cond_1a
    const/4 v2, 0x3

    goto :goto_3c

    :sswitch_1c
    const-string v1, "CONTACT"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_25

    goto :goto_3c

    :cond_25
    const/4 v2, 0x2

    goto :goto_3c

    :sswitch_27
    const-string v1, "SMS"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_30

    goto :goto_3c

    :cond_30
    const/4 v2, 0x1

    goto :goto_3c

    :sswitch_32
    const-string v1, "LOCATION"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3b

    goto :goto_3c

    :cond_3b
    const/4 v2, 0x0

    :goto_3c
    packed-switch v2, :pswitch_data_6a

    goto :goto_57

    :pswitch_40
    const-string p0, "android.permission.READ_PHONE_STATE"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_57

    :pswitch_46
    const-string p0, "android.permission.READ_CONTACTS"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_57

    :pswitch_4c
    const-string p0, "android.permission.READ_SMS"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_57

    :pswitch_52
    const-string p0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_57
    return-object v0

    :sswitch_data_58
    .sparse-switch
        -0x600a704b -> :sswitch_32
        0x14139 -> :sswitch_27
        0x6382b000 -> :sswitch_1c
        0x77fe1256 -> :sswitch_11
    .end sparse-switch

    :pswitch_data_6a
    .packed-switch 0x0
        :pswitch_52
        :pswitch_4c
        :pswitch_46
        :pswitch_40
    .end packed-switch
.end method
