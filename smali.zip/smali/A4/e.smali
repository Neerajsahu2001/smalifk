.class final La4/e;
.super Ljava/lang/Object;
.source "BNPLUploadService.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:La4/g;


# direct methods
.method constructor <init>(La4/g;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La4/e;->a:La4/g;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    iget-object v0, p0, La4/e;->a:La4/g;

    invoke-virtual {v0, v0}, La4/g;->b(La4/g;)V

    return-void
.end method
