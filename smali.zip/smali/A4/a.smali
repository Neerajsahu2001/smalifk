.class final La4/a;
.super LFa/e;
.source "BNPLApplicationUpdateUtil.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LFa/e<",
        "LKf/h;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;)V
    .registers 3

    iput-object p1, p0, La4/a;->a:Ljava/lang/String;

    iput-object p2, p0, La4/a;->b:Landroid/content/Context;

    invoke-direct {p0}, LFa/e;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "LKf/h;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    invoke-super {p0, p1, p2}, LFa/e;->onFailure(Lta/a;Lwa/a;)V

    iget-object p1, p0, La4/a;->a:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_10

    iget-object p2, p0, La4/a;->b:Landroid/content/Context;

    invoke-static {p2, p1}, Lc4/a;->showErrorNotification(Landroid/content/Context;Ljava/lang/String;)V

    :cond_10
    return-void
.end method

.method public onSuccess(LKf/h;)V
    .registers 2

    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, LKf/h;

    invoke-virtual {p0, p1}, La4/a;->onSuccess(LKf/h;)V

    return-void
.end method
