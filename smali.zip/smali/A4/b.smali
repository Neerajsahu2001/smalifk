.class final La4/b;
.super Ljava/lang/Object;
.source "BNPLApplicationUpdateUtil.java"


# direct methods
.method static a(Landroidx/collection/b;Landroidx/collection/b;Landroid/content/Context;Ljava/lang/String;)V
    .registers 7

    new-instance v0, Ljd/e;

    invoke-direct {v0}, Ljd/e;-><init>()V

    new-instance v1, Landroidx/collection/b;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Landroidx/collection/b;-><init>(I)V

    iput-object v1, v0, Ljd/e;->b:Ljava/util/Set;

    new-instance v1, Landroidx/collection/b;

    invoke-direct {v1, v2}, Landroidx/collection/b;-><init>(I)V

    iput-object v1, v0, Ljd/e;->c:Ljava/util/Set;

    if-eqz p0, :cond_1b

    iget-object v1, v0, Ljd/e;->b:Ljava/util/Set;

    invoke-interface {v1, p0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    :cond_1b
    if-eqz p1, :cond_22

    iget-object p0, v0, Ljd/e;->c:Ljava/util/Set;

    invoke-interface {p0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    :cond_22
    iget-object p0, v0, Ljd/e;->c:Ljava/util/Set;

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result p0

    if-nez p0, :cond_33

    iget-object p0, v0, Ljd/e;->b:Ljava/util/Set;

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result p0

    if-nez p0, :cond_33

    return-void

    :cond_33
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getMAPIHttpService()LDa/b;

    move-result-object p0

    invoke-interface {p0, v0, p3}, LDa/b;->updateEligibilityApplication(Ljd/e;Ljava/lang/String;)Lta/a;

    move-result-object p0

    new-instance p1, La4/a;

    invoke-direct {p1, p3, p2}, La4/a;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    invoke-interface {p0, p1}, Lta/a;->enqueue(Lva/b;)V

    return-void
.end method
