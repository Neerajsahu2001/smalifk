.class public final Ld4/g;
.super Ljava/lang/Object;
.source "BottomNavigationUtils.java"


# direct methods
.method public static getBottomBarAction()Lcom/flipkart/mapi/model/component/data/renderables/b;
    .registers 4

    new-instance v0, Lcom/flipkart/mapi/model/component/data/renderables/b;

    invoke-direct {v0}, Lcom/flipkart/mapi/model/component/data/renderables/b;-><init>()V

    const-string v1, "NAVIGATION"

    iput-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->b:Ljava/lang/String;

    iget-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const-string v3, "SHOW_DUMMY_TOOLBAR"

    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v2, "pageColor"

    const-string v3, "#00FFFFFF"

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0
.end method

.method public static isBottomNavAction(Landroidx/fragment/app/Fragment;)Z
    .registers 3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p0

    if-eqz p0, :cond_13

    const-string v0, "isBottomNavAction"

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_13

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    goto :goto_14

    :cond_13
    const/4 p0, 0x0

    :goto_14
    return p0
.end method
