.class public final Ld4/f$a;
.super Ljava/lang/Object;
.source "BottomNavigationInterface.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static getCurrentVisibleFragment(Ld4/f;)Landroidx/fragment/app/Fragment;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method

.method public static onBottomBarResponseSuccess(Ld4/f;)V
    .registers 1

    return-void
.end method

.method public static onPagePainted(Ld4/f;Lcom/flipkart/android/navigation/k;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/flipkart/android/navigation/l$a;->onPagePainted(Lcom/flipkart/android/navigation/l;Lcom/flipkart/android/navigation/k;)V

    return-void
.end method
