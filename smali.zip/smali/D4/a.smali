.class public interface abstract Ld4/a;
.super Ljava/lang/Object;
.source "BottomBarUIUpdater.kt"


# virtual methods
.method public abstract findBottomBarEligibleUrl(Ljava/util/Set;)Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation
.end method

.method public abstract hideBottomBar()V
.end method

.method public abstract reInitializeVM(Ljava/lang/String;Ld4/h;)V
.end method

.method public abstract selectItemAtIndex(Ljava/lang/Integer;ZLjava/lang/String;)V
.end method
