.class public final Ld4/e;
.super Ljava/lang/Object;
.source "BottomBarVisibilityControllerImpl.kt"

# interfaces
.implements Ld4/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld4/e$a;
    }
.end annotation


# static fields
.field public static final i:Ld4/e$a;

.field private static final j:Ljava/lang/String;

.field private static final k:Ljava/lang/String;

.field private static final l:Ljava/lang/String;


# instance fields
.field private a:Ld4/a;

.field private b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

.field private c:Ljava/lang/Integer;

.field private d:Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

.field private e:Ljava/lang/Integer;

.field private f:Ld4/c;

.field private final g:Ljava/lang/String;

.field private h:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ld4/e$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld4/e$a;-><init>(Lkotlin/jvm/internal/i;)V

    sput-object v0, Ld4/e;->i:Ld4/e$a;

    const-string v0, "back_stack_map"

    sput-object v0, Ld4/e;->j:Ljava/lang/String;

    const-string v0, "bottom_nav_item_order"

    sput-object v0, Ld4/e;->k:Ljava/lang/String;

    const-string v0, "last_back_stack_count"

    sput-object v0, Ld4/e;->l:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ld4/a;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "/(hi|te|ta|kn)/.*"

    iput-object v0, p0, Ld4/e;->g:Ljava/lang/String;

    iput-object p1, p0, Ld4/e;->a:Ld4/a;

    iput p2, p0, Ld4/e;->h:I

    return-void
.end method

.method public static a(Landroid/content/Context;Ld4/e;)V
    .registers 12

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "$context"

    invoke-static {p0, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "this$0"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Ld4/e;->i:Ld4/e$a;

    invoke-static {v2, p0}, Ld4/e$a;->access$getParentsFragmentManager(Ld4/e$a;Landroid/content/Context;)Landroidx/fragment/app/o;

    move-result-object p0

    if-eqz p0, :cond_21d

    invoke-virtual {p0}, Landroidx/fragment/app/o;->W()I

    move-result v2

    if-lez v2, :cond_31

    add-int/lit8 v3, v2, -0x1

    invoke-virtual {p0, v3}, Landroidx/fragment/app/o;->V(I)Landroidx/fragment/app/o$e;

    move-result-object v3

    const-string v4, "fm.getBackStackEntryAt(newBackStackCount - 1)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v3}, Landroidx/fragment/app/o$e;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroidx/fragment/app/o;->T(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object p0

    goto :goto_42

    :cond_31
    const v3, 0x7f0b01c6

    invoke-virtual {p0, v3}, Landroidx/fragment/app/o;->S(I)Landroidx/fragment/app/Fragment;

    move-result-object p0

    instance-of v3, p0, Lcom/flipkart/android/multiverse/fragments/b;

    if-eqz v3, :cond_42

    check-cast p0, Lcom/flipkart/android/multiverse/fragments/b;

    invoke-virtual {p0}, Lcom/flipkart/android/multiverse/fragments/b;->getCurrentFragment()Lcom/flipkart/android/reactnative/nativeuimodules/d;

    move-result-object p0

    :cond_42
    :goto_42
    iget-object v3, p1, Ld4/e;->e:Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_52

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-ge v2, v3, :cond_52

    iput-object v5, p1, Ld4/e;->c:Ljava/lang/Integer;

    const/4 v3, 0x1

    goto :goto_64

    :cond_52
    iget-object v3, p1, Ld4/e;->c:Ljava/lang/Integer;

    if-eqz v3, :cond_63

    iget-object v6, p1, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    if-eqz v6, :cond_61

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v6, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    :cond_61
    iput-object v5, p1, Ld4/e;->c:Ljava/lang/Integer;

    :cond_63
    const/4 v3, 0x0

    :goto_64
    iget-object v6, p1, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    if-eqz v6, :cond_89

    const/4 v6, 0x0

    :goto_69
    iget-object v7, p1, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    invoke-static {v7}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v7}, Landroid/util/SparseIntArray;->size()I

    move-result v7

    if-ge v6, v7, :cond_89

    iget-object v7, p1, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    invoke-static {v7}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v7, v6}, Landroid/util/SparseIntArray;->keyAt(I)I

    move-result v7

    if-le v7, v2, :cond_86

    iget-object v7, p1, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    if-eqz v7, :cond_86

    invoke-virtual {v7, v6}, Landroid/util/SparseIntArray;->removeAt(I)V

    :cond_86
    add-int/lit8 v6, v6, 0x1

    goto :goto_69

    :cond_89
    if-eqz p0, :cond_9a

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v6

    if-eqz v6, :cond_9a

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/o;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/fragment/app/o;->a0()Ljava/util/List;

    move-result-object v6

    goto :goto_9b

    :cond_9a
    move-object v6, v5

    :goto_9b
    if-eqz v6, :cond_c8

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_a1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_c8

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/fragment/app/Fragment;

    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v8

    if-eqz v8, :cond_be

    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->isHidden()Z

    move-result v8

    if-nez v8, :cond_be

    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v7

    goto :goto_bf

    :cond_be
    move-object v7, v5

    :goto_bf
    if-eqz v7, :cond_a1

    invoke-virtual {v7}, Landroid/view/View;->getVisibility()I

    move-result v7

    if-nez v7, :cond_a1

    const/4 v0, 0x1

    :cond_c8
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v6

    invoke-virtual {v6}, Lcom/flipkart/android/config/c;->isReactBottomBarEnabled()Z

    move-result v6

    if-eqz v6, :cond_14e

    if-eqz p0, :cond_10d

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v7

    if-eqz v7, :cond_fd

    const-string v8, "page_url"

    invoke-virtual {v7, v8}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    if-eqz v8, :cond_ee

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_ee
    const-string v8, "pageUrl"

    invoke-virtual {v7, v8}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_fd

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_fd
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getTag()Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_10e

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_10e

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_10e

    :cond_10d
    move-object v6, v5

    :cond_10e
    :goto_10e
    if-eqz v6, :cond_14e

    new-instance v7, Ljava/util/LinkedHashSet;

    invoke-direct {v7}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_119
    :goto_119
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_14f

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    invoke-static {v8}, Lcom/flipkart/android/utils/r1;->startsWithHttp(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_134

    invoke-static {v8}, Lcom/flipkart/android/utils/r1;->isValidFlipkartHostNameInUrl(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_13d

    :cond_134
    invoke-static {v8}, Lcom/flipkart/android/utils/r1;->getFlipkartUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "getFlipkartUrl(url)"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_13d
    invoke-static {v8}, Lcom/flipkart/android/utils/r1;->getUrlPath(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    invoke-static {v8}, Lcom/flipkart/android/utils/r1;->getLanguageInsensitiveUrlPath(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-eqz v8, :cond_119

    invoke-virtual {v7, v8}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_119

    :cond_14e
    move-object v7, v5

    :cond_14f
    if-eqz v7, :cond_15a

    iget-object v6, p1, Ld4/e;->a:Ld4/a;

    if-eqz v6, :cond_15a

    invoke-interface {v6, v7}, Ld4/a;->findBottomBarEligibleUrl(Ljava/util/Set;)Ljava/lang/String;

    move-result-object v6

    goto :goto_15b

    :cond_15a
    move-object v6, v5

    :goto_15b
    iget v8, p1, Ld4/e;->h:I

    if-nez v0, :cond_195

    if-nez v2, :cond_17c

    if-eqz v7, :cond_196

    invoke-interface {v7}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_16a

    goto :goto_196

    :cond_16a
    if-nez v6, :cond_196

    iget-object p0, p1, Ld4/e;->a:Ld4/a;

    if-eqz p0, :cond_173

    invoke-interface {p0}, Ld4/a;->hideBottomBar()V

    :cond_173
    iget-object p0, p1, Ld4/e;->d:Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    if-eqz p0, :cond_21d

    invoke-virtual {p0, v8}, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;->hideBottomNav(I)V

    goto/16 :goto_21d

    :cond_17c
    iget-object v0, p1, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    if-eqz v0, :cond_195

    invoke-virtual {v0, v2}, Landroid/util/SparseIntArray;->indexOfKey(I)I

    move-result v0

    if-ltz v0, :cond_195

    iget-object v0, p1, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    invoke-static {v0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v0, v2}, Landroid/util/SparseIntArray;->get(I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object v1, v0

    goto :goto_196

    :cond_195
    move-object v1, v5

    :cond_196
    :goto_196
    if-eqz v1, :cond_1b4

    iget-object v0, p1, Ld4/e;->a:Ld4/a;

    if-eqz v0, :cond_19f

    invoke-interface {v0, v1, v3, v5}, Ld4/a;->selectItemAtIndex(Ljava/lang/Integer;ZLjava/lang/String;)V

    :cond_19f
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v0

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/flipkart/android/config/c;->setBottomNavBarPosition(I)V

    iget-object v0, p1, Ld4/e;->d:Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    if-eqz v0, :cond_1d5

    iget v2, p1, Ld4/e;->h:I

    invoke-virtual {v0, v2}, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;->showBottomNav(I)V

    goto :goto_1d5

    :cond_1b4
    if-eqz v6, :cond_1c7

    iget-object v0, p1, Ld4/e;->a:Ld4/a;

    if-eqz v0, :cond_1bd

    invoke-interface {v0, v5, v3, v6}, Ld4/a;->selectItemAtIndex(Ljava/lang/Integer;ZLjava/lang/String;)V

    :cond_1bd
    iget-object v0, p1, Ld4/e;->d:Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    if-eqz v0, :cond_1d5

    iget v2, p1, Ld4/e;->h:I

    invoke-virtual {v0, v2}, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;->showBottomNav(I)V

    goto :goto_1d5

    :cond_1c7
    iget-object v0, p1, Ld4/e;->a:Ld4/a;

    if-eqz v0, :cond_1ce

    invoke-interface {v0}, Ld4/a;->hideBottomBar()V

    :cond_1ce
    iget-object v0, p1, Ld4/e;->d:Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    if-eqz v0, :cond_1d5

    invoke-virtual {v0, v8}, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;->hideBottomNav(I)V

    :cond_1d5
    :goto_1d5
    new-instance v0, Ld4/h;

    invoke-direct {v0, v1, v3, v6}, Ld4/h;-><init>(Ljava/lang/Integer;ZLjava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    if-eqz v1, :cond_21d

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->isBottomBarReInitEnabled()Z

    move-result v1

    if-ne v1, v4, :cond_21d

    if-eqz p0, :cond_21d

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p0

    if-eqz p0, :cond_21d

    const-string v1, "bundleName"

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_21d

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const v2, -0x94d7323

    if-eq v1, v2, :cond_20e

    const v2, 0xee38a89

    if-eq v1, v2, :cond_205

    goto :goto_21d

    :cond_205
    const-string v1, "multiWidget_dls"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_216

    goto :goto_21d

    :cond_20e
    const-string v1, "multiWidget"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_21d

    :cond_216
    iget-object p1, p1, Ld4/e;->a:Ld4/a;

    if-eqz p1, :cond_21d

    invoke-interface {p1, p0, v0}, Ld4/a;->reInitializeVM(Ljava/lang/String;Ld4/h;)V

    :cond_21d
    :goto_21d
    return-void
.end method

.method public static b(Ld4/e;Landroid/content/Context;Landroidx/fragment/app/o;)V
    .registers 4

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ld4/e;->update(Landroid/content/Context;)V

    invoke-virtual {p2}, Landroidx/fragment/app/o;->W()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Ld4/e;->e:Ljava/lang/Integer;

    return-void
.end method


# virtual methods
.method public final checkForLanguageInsensitivePath(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    const-string v0, "urlPath"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lvp/h;

    iget-object v1, p0, Ld4/e;->g:Ljava/lang/String;

    invoke-direct {v0, v1}, Lvp/h;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Lvp/h;->d(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1d

    const/4 v0, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "this as java.lang.String).substring(startIndex)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1

    :cond_1d
    const/4 p1, 0x0

    return-object p1
.end method

.method public detach(Landroid/content/Context;)V
    .registers 3

    iget-object v0, p0, Ld4/e;->f:Ld4/c;

    if-eqz v0, :cond_1a

    instance-of v0, p1, Landroidx/fragment/app/d;

    if-eqz v0, :cond_1a

    check-cast p1, Landroidx/fragment/app/d;

    invoke-virtual {p1}, Landroidx/fragment/app/d;->getSupportFragmentManager()Landroidx/fragment/app/o;

    move-result-object p1

    const-string v0, "context.supportFragmentManager"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/e;->f:Ld4/c;

    if-eqz v0, :cond_1a

    invoke-virtual {p1, v0}, Landroidx/fragment/app/o;->C0(Landroidx/fragment/app/o$g;)V

    :cond_1a
    const/4 p1, 0x0

    iput-object p1, p0, Ld4/e;->f:Ld4/c;

    iput-object p1, p0, Ld4/e;->a:Ld4/a;

    return-void
.end method

.method public initialize(Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    .registers 5

    const/4 v0, 0x0

    if-eqz p1, :cond_8

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    goto :goto_9

    :cond_8
    move-object p1, v0

    :goto_9
    instance-of v1, p1, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    if-eqz v1, :cond_f

    move-object v0, p1

    goto :goto_15

    :cond_f
    if-eqz p1, :cond_15

    invoke-interface {p1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    :cond_15
    :goto_15
    instance-of p1, v0, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    if-eqz p1, :cond_1d

    check-cast v0, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    iput-object v0, p0, Ld4/e;->d:Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    :cond_1d
    if-eqz p2, :cond_60

    iget-object p1, p0, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    if-nez p1, :cond_33

    sget-object p1, Ld4/e;->j:Ljava/lang/String;

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_33

    invoke-virtual {p2, p1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    iput-object p1, p0, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    :cond_33
    iget-object p1, p0, Ld4/e;->c:Ljava/lang/Integer;

    if-nez p1, :cond_49

    sget-object p1, Ld4/e;->k:Ljava/lang/String;

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_49

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Ld4/e;->c:Ljava/lang/Integer;

    :cond_49
    iget-object p1, p0, Ld4/e;->e:Ljava/lang/Integer;

    if-nez p1, :cond_6f

    sget-object p1, Ld4/e;->l:Ljava/lang/String;

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6f

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Ld4/e;->e:Ljava/lang/Integer;

    goto :goto_6f

    :cond_60
    iget-object p1, p0, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    if-nez p1, :cond_6f

    new-instance p1, Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    invoke-direct {p1}, Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;-><init>()V

    iput-object p1, p0, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    const/4 p2, 0x0

    invoke-virtual {p1, p2, p2}, Landroid/util/SparseIntArray;->put(II)V

    :cond_6f
    :goto_6f
    return-void
.end method

.method public itemNavigation(I)V
    .registers 2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Ld4/e;->c:Ljava/lang/Integer;

    return-void
.end method

.method public onAttach(Landroid/content/Context;)V
    .registers 4

    sget-object v0, Ld4/e;->i:Ld4/e$a;

    invoke-static {v0, p1}, Ld4/e$a;->access$getParentsFragmentManager(Ld4/e$a;Landroid/content/Context;)Landroidx/fragment/app/o;

    move-result-object v0

    if-eqz v0, :cond_22

    if-eqz p1, :cond_22

    iget-object v1, p0, Ld4/e;->e:Ljava/lang/Integer;

    if-nez v1, :cond_18

    invoke-virtual {v0}, Landroidx/fragment/app/o;->W()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, p0, Ld4/e;->e:Ljava/lang/Integer;

    :cond_18
    new-instance v1, Ld4/c;

    invoke-direct {v1, p0, p1, v0}, Ld4/c;-><init>(Ld4/e;Landroid/content/Context;Landroidx/fragment/app/o;)V

    iput-object v1, p0, Ld4/e;->f:Ld4/c;

    invoke-virtual {v0, v1}, Landroidx/fragment/app/o;->d(Landroidx/fragment/app/o$g;)V

    :cond_22
    return-void
.end method

.method public onBottomViewCreated()V
    .registers 3

    iget-object v0, p0, Ld4/e;->d:Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;

    if-eqz v0, :cond_9

    iget v1, p0, Ld4/e;->h:I

    invoke-virtual {v0, v1}, Lcom/flipkart/android/customviews/VariablePaddingCoordinatorLayout;->onBottomViewCreated(I)V

    :cond_9
    return-void
.end method

.method public saveToInstanceState(Landroid/os/Bundle;)V
    .registers 4

    const-string v0, "outState"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/e;->b:Lcom/flipkart/android/bottomnavigation/SparseIntArrayParcelable;

    if-eqz v0, :cond_e

    sget-object v1, Ld4/e;->j:Ljava/lang/String;

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_e
    iget-object v0, p0, Ld4/e;->c:Ljava/lang/Integer;

    if-eqz v0, :cond_1b

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    sget-object v1, Ld4/e;->k:Ljava/lang/String;

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_1b
    iget-object v0, p0, Ld4/e;->e:Ljava/lang/Integer;

    if-eqz v0, :cond_28

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    sget-object v1, Ld4/e;->l:Ljava/lang/String;

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_28
    return-void
.end method

.method public update(Landroid/content/Context;)V
    .registers 5

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Ld4/d;

    const/4 v2, 0x0

    invoke-direct {v1, p1, p0, v2}, Ld4/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
