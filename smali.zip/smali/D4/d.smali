.class public final synthetic Ld4/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p3, p0, Ld4/d;->a:I

    iput-object p1, p0, Ld4/d;->b:Ljava/lang/Object;

    iput-object p2, p0, Ld4/d;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget v0, p0, Ld4/d;->a:I

    iget-object v1, p0, Ld4/d;->c:Ljava/lang/Object;

    iget-object v2, p0, Ld4/d;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_1a

    check-cast v2, Lcom/flipkart/android/webview/WebAppInterface;

    check-cast v1, Ljava/lang/String;

    invoke-static {v2, v1}, Lcom/flipkart/android/webview/WebAppInterface;->a(Lcom/flipkart/android/webview/WebAppInterface;Ljava/lang/String;)V

    return-void

    :pswitch_11
    check-cast v2, Landroid/content/Context;

    check-cast v1, Ld4/e;

    invoke-static {v2, v1}, Ld4/e;->a(Landroid/content/Context;Ld4/e;)V

    return-void

    nop

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method
