.class public final Ld4/h;
.super Ljava/lang/Object;
.source "BottombarIndexData.kt"


# instance fields
.field private final a:Ljava/lang/Integer;

.field private final b:Z

.field private final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/Integer;ZLjava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld4/h;->a:Ljava/lang/Integer;

    iput-boolean p2, p0, Ld4/h;->b:Z

    iput-object p3, p0, Ld4/h;->c:Ljava/lang/String;

    return-void
.end method

.method public static synthetic copy$default(Ld4/h;Ljava/lang/Integer;ZLjava/lang/String;ILjava/lang/Object;)Ld4/h;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget-object p1, p0, Ld4/h;->a:Ljava/lang/Integer;

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget-boolean p2, p0, Ld4/h;->b:Z

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget-object p3, p0, Ld4/h;->c:Ljava/lang/String;

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Ld4/h;->copy(Ljava/lang/Integer;ZLjava/lang/String;)Ld4/h;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Ljava/lang/Integer;
    .registers 2

    iget-object v0, p0, Ld4/h;->a:Ljava/lang/Integer;

    return-object v0
.end method

.method public final component2()Z
    .registers 2

    iget-boolean v0, p0, Ld4/h;->b:Z

    return v0
.end method

.method public final component3()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ld4/h;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final copy(Ljava/lang/Integer;ZLjava/lang/String;)Ld4/h;
    .registers 5

    new-instance v0, Ld4/h;

    invoke-direct {v0, p1, p2, p3}, Ld4/h;-><init>(Ljava/lang/Integer;ZLjava/lang/String;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Ld4/h;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Ld4/h;

    iget-object v1, p1, Ld4/h;->a:Ljava/lang/Integer;

    iget-object v3, p0, Ld4/h;->a:Ljava/lang/Integer;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-boolean v1, p0, Ld4/h;->b:Z

    iget-boolean v3, p1, Ld4/h;->b:Z

    if-eq v1, v3, :cond_1e

    return v2

    :cond_1e
    iget-object v1, p0, Ld4/h;->c:Ljava/lang/String;

    iget-object p1, p1, Ld4/h;->c:Ljava/lang/String;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_29

    return v2

    :cond_29
    return v0
.end method

.method public final getFragmentUrl()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ld4/h;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final getIndex()Ljava/lang/Integer;
    .registers 2

    iget-object v0, p0, Ld4/h;->a:Ljava/lang/Integer;

    return-object v0
.end method

.method public hashCode()I
    .registers 4

    const/4 v0, 0x0

    iget-object v1, p0, Ld4/h;->a:Ljava/lang/Integer;

    if-nez v1, :cond_7

    const/4 v1, 0x0

    goto :goto_b

    :cond_7
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_b
    mul-int/lit8 v1, v1, 0x1f

    iget-boolean v2, p0, Ld4/h;->b:Z

    if-eqz v2, :cond_12

    const/4 v2, 0x1

    :cond_12
    add-int/2addr v1, v2

    mul-int/lit8 v1, v1, 0x1f

    iget-object v2, p0, Ld4/h;->c:Ljava/lang/String;

    if-nez v2, :cond_1a

    goto :goto_1e

    :cond_1a
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_1e
    add-int/2addr v1, v0

    return v1
.end method

.method public final isBackFlow()Z
    .registers 2

    iget-boolean v0, p0, Ld4/h;->b:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "BottombarIndexData(index="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Ld4/h;->a:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", isBackFlow="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Ld4/h;->b:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", fragmentUrl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Ld4/h;->c:Ljava/lang/String;

    const/16 v2, 0x29

    invoke-static {v0, v1, v2}, Landroidx/lifecycle/Z;->d(Ljava/lang/StringBuilder;Ljava/lang/String;C)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
