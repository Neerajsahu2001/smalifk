.class public interface abstract Ld4/b;
.super Ljava/lang/Object;
.source "BottomBarVisibilityController.kt"


# virtual methods
.method public abstract detach(Landroid/content/Context;)V
.end method

.method public abstract initialize(Landroid/view/ViewGroup;Landroid/os/Bundle;)V
.end method

.method public abstract itemNavigation(I)V
.end method

.method public abstract onAttach(Landroid/content/Context;)V
.end method

.method public abstract onBottomViewCreated()V
.end method

.method public abstract saveToInstanceState(Landroid/os/Bundle;)V
.end method

.method public abstract update(Landroid/content/Context;)V
.end method
