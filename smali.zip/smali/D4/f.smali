.class public interface abstract Ld4/f;
.super Ljava/lang/Object;
.source "BottomNavigationInterface.kt"

# interfaces
.implements Lcom/flipkart/android/navigation/l;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld4/f$a;
    }
.end annotation


# virtual methods
.method public abstract getCurrentVisibleFragment()Landroidx/fragment/app/Fragment;
.end method

.method public abstract hideBottomBar()V
.end method

.method public abstract onBottomBarResponseSuccess()V
.end method

.method public abstract synthetic onPagePainted(Lcom/flipkart/android/navigation/k;)V
.end method

.method public abstract reloadBottomBar()V
.end method

.method public abstract showBottomBar()V
.end method

.method public abstract update()V
.end method

.method public abstract updateNavigationContext()V
.end method

.method public abstract updateSelectedTab(Ljava/lang/String;)V
.end method
