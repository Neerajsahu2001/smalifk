.class public interface abstract Ld4/i;
.super Ljava/lang/Object;
.source "UpdateBottomBarInterface.kt"


# virtual methods
.method public abstract hideBottomBar()V
.end method

.method public abstract onBottomBarV2ViewCreated()V
.end method

.method public abstract reloadBottomBar()V
.end method

.method public abstract showBottomBar()V
.end method

.method public abstract updateBottomBarVisibility()V
.end method
