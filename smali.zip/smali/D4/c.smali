.class public final synthetic Ld4/c;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/fragment/app/o$g;


# instance fields
.field public final synthetic a:Ld4/e;

.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:Landroidx/fragment/app/o;


# direct methods
.method public synthetic constructor <init>(Ld4/e;Landroid/content/Context;Landroidx/fragment/app/o;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld4/c;->a:Ld4/e;

    iput-object p2, p0, Ld4/c;->b:Landroid/content/Context;

    iput-object p3, p0, Ld4/c;->c:Landroidx/fragment/app/o;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    iget-object v0, p0, Ld4/c;->b:Landroid/content/Context;

    iget-object v1, p0, Ld4/c;->c:Landroidx/fragment/app/o;

    iget-object v2, p0, Ld4/c;->a:Ld4/e;

    invoke-static {v2, v0, v1}, Ld4/e;->b(Ld4/e;Landroid/content/Context;Landroidx/fragment/app/o;)V

    return-void
.end method
