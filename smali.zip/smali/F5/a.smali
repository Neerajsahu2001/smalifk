.class public final synthetic Lf5/a;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lzj/e;


# instance fields
.field public final synthetic a:Lcom/google/android/play/core/review/b;

.field public final synthetic b:Landroid/app/Activity;

.field public final synthetic c:Leo/a;

.field public final synthetic d:Leo/a;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/play/core/review/e;Landroid/app/Activity;Leo/a;Leo/a;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lf5/a;->a:Lcom/google/android/play/core/review/b;

    iput-object p2, p0, Lf5/a;->b:Landroid/app/Activity;

    iput-object p3, p0, Lf5/a;->c:Leo/a;

    iput-object p4, p0, Lf5/a;->d:Leo/a;

    return-void
.end method


# virtual methods
.method public final onComplete(Lzj/k;)V
    .registers 6

    iget-object v0, p0, Lf5/a;->a:Lcom/google/android/play/core/review/b;

    const-string v1, "$reviewManager"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, Lf5/a;->b:Landroid/app/Activity;

    const-string v2, "$activity"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "it"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lzj/k;->p()Z

    move-result v2

    iget-object v3, p0, Lf5/a;->c:Leo/a;

    if-eqz v2, :cond_3d

    invoke-virtual {p1}, Lzj/k;->l()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/google/android/play/core/review/ReviewInfo;

    invoke-interface {v0, v1, p1}, Lcom/google/android/play/core/review/b;->a(Landroid/app/Activity;Lcom/google/android/play/core/review/ReviewInfo;)Lzj/k;

    move-result-object p1

    const-string v0, "reviewManager.launchRevi\u2026low(activity, reviewInfo)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lf5/b;

    iget-object v1, p0, Lf5/a;->d:Leo/a;

    invoke-direct {v0, v1}, Lf5/b;-><init>(Leo/a;)V

    invoke-virtual {p1, v0}, Lzj/k;->c(Lzj/e;)V

    new-instance v0, Lg0/T;

    invoke-direct {v0, v3}, Lg0/T;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p1, v0}, Lzj/k;->e(Lzj/f;)Lzj/k;

    goto :goto_42

    :cond_3d
    if-eqz v3, :cond_42

    invoke-interface {v3}, Leo/a;->invoke()Ljava/lang/Object;

    :cond_42
    :goto_42
    return-void
.end method
