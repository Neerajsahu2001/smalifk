.class public final synthetic Lf5/b;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lzj/e;


# instance fields
.field public final synthetic a:Leo/a;


# direct methods
.method public synthetic constructor <init>(Leo/a;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lf5/b;->a:Leo/a;

    return-void
.end method


# virtual methods
.method public final onComplete(Lzj/k;)V
    .registers 3

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Lf5/b;->a:Leo/a;

    if-eqz p1, :cond_c

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    :cond_c
    return-void
.end method
