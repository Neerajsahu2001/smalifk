.class final LE0/c;
.super LE0/d;
.source "ScriptTagPayloadReader.java"


# instance fields
.field private b:J

.field private c:[J

.field private d:[J


# direct methods
.method public constructor <init>()V
    .registers 3

    new-instance v0, Ly0/k;

    invoke-direct {v0}, Ly0/k;-><init>()V

    invoke-direct {p0, v0}, LE0/d;-><init>(Ly0/J;)V

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v0, p0, LE0/c;->b:J

    const/4 v0, 0x0

    new-array v1, v0, [J

    iput-object v1, p0, LE0/c;->c:[J

    new-array v0, v0, [J

    iput-object v0, p0, LE0/c;->d:[J

    return-void
.end method

.method private static e(ILa0/C;)Ljava/io/Serializable;
    .registers 5

    if-eqz p0, :cond_7b

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eq p0, v0, :cond_6e

    const/4 v0, 0x2

    if-eq p0, v0, :cond_69

    const/4 v2, 0x3

    if-eq p0, v2, :cond_4d

    const/16 v2, 0x8

    if-eq p0, v2, :cond_48

    const/16 v2, 0xa

    if-eq p0, v2, :cond_2c

    const/16 v1, 0xb

    if-eq p0, v1, :cond_1a

    const/4 p0, 0x0

    return-object p0

    :cond_1a
    new-instance p0, Ljava/util/Date;

    invoke-virtual {p1}, La0/C;->u()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v1

    double-to-long v1, v1

    invoke-direct {p0, v1, v2}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {p1, v0}, La0/C;->N(I)V

    return-object p0

    :cond_2c
    invoke-virtual {p1}, La0/C;->E()I

    move-result p0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(I)V

    :goto_35
    if-ge v1, p0, :cond_47

    invoke-virtual {p1}, La0/C;->A()I

    move-result v2

    invoke-static {v2, p1}, LE0/c;->e(ILa0/C;)Ljava/io/Serializable;

    move-result-object v2

    if-eqz v2, :cond_44

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_44
    add-int/lit8 v1, v1, 0x1

    goto :goto_35

    :cond_47
    return-object v0

    :cond_48
    invoke-static {p1}, LE0/c;->f(La0/C;)Ljava/util/HashMap;

    move-result-object p0

    return-object p0

    :cond_4d
    new-instance p0, Ljava/util/HashMap;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    :cond_52
    :goto_52
    invoke-static {p1}, LE0/c;->g(La0/C;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, La0/C;->A()I

    move-result v1

    const/16 v2, 0x9

    if-ne v1, v2, :cond_5f

    return-object p0

    :cond_5f
    invoke-static {v1, p1}, LE0/c;->e(ILa0/C;)Ljava/io/Serializable;

    move-result-object v1

    if-eqz v1, :cond_52

    invoke-virtual {p0, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_52

    :cond_69
    invoke-static {p1}, LE0/c;->g(La0/C;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_6e
    invoke-virtual {p1}, La0/C;->A()I

    move-result p0

    if-ne p0, v0, :cond_75

    goto :goto_76

    :cond_75
    const/4 v0, 0x0

    :goto_76
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :cond_7b
    invoke-virtual {p1}, La0/C;->u()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    return-object p0
.end method

.method private static f(La0/C;)Ljava/util/HashMap;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/C;",
            ")",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, La0/C;->E()I

    move-result v0

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1, v0}, Ljava/util/HashMap;-><init>(I)V

    const/4 v2, 0x0

    :goto_a
    if-ge v2, v0, :cond_20

    invoke-static {p0}, LE0/c;->g(La0/C;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, La0/C;->A()I

    move-result v4

    invoke-static {v4, p0}, LE0/c;->e(ILa0/C;)Ljava/io/Serializable;

    move-result-object v4

    if-eqz v4, :cond_1d

    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1d
    add-int/lit8 v2, v2, 0x1

    goto :goto_a

    :cond_20
    return-object v1
.end method

.method private static g(La0/C;)Ljava/lang/String;
    .registers 4

    invoke-virtual {p0}, La0/C;->G()I

    move-result v0

    invoke-virtual {p0}, La0/C;->e()I

    move-result v1

    invoke-virtual {p0, v0}, La0/C;->N(I)V

    new-instance v2, Ljava/lang/String;

    invoke-virtual {p0}, La0/C;->d()[B

    move-result-object p0

    invoke-direct {v2, p0, v1, v0}, Ljava/lang/String;-><init>([BII)V

    return-object v2
.end method


# virtual methods
.method public final a()J
    .registers 3

    iget-wide v0, p0, LE0/c;->b:J

    return-wide v0
.end method

.method public final b()[J
    .registers 2

    iget-object v0, p0, LE0/c;->d:[J

    return-object v0
.end method

.method public final c()[J
    .registers 2

    iget-object v0, p0, LE0/c;->c:[J

    return-object v0
.end method

.method protected final d(La0/C;J)Z
    .registers 13

    invoke-virtual {p1}, La0/C;->A()I

    move-result p2

    const/4 p3, 0x2

    const/4 v0, 0x0

    if-eq p2, p3, :cond_9

    return v0

    :cond_9
    invoke-static {p1}, LE0/c;->g(La0/C;)Ljava/lang/String;

    move-result-object p2

    const-string p3, "onMetaData"

    invoke-virtual {p3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_16

    return v0

    :cond_16
    invoke-virtual {p1}, La0/C;->a()I

    move-result p2

    if-nez p2, :cond_1d

    return v0

    :cond_1d
    invoke-virtual {p1}, La0/C;->A()I

    move-result p2

    const/16 p3, 0x8

    if-eq p2, p3, :cond_26

    return v0

    :cond_26
    invoke-static {p1}, LE0/c;->f(La0/C;)Ljava/util/HashMap;

    move-result-object p1

    const-string p2, "duration"

    invoke-virtual {p1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    instance-of p3, p2, Ljava/lang/Double;

    const-wide v1, 0x412e848000000000L    # 1000000.0

    if-eqz p3, :cond_4a

    check-cast p2, Ljava/lang/Double;

    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide p2

    const-wide/16 v3, 0x0

    cmpl-double v5, p2, v3

    if-lez v5, :cond_4a

    mul-double p2, p2, v1

    double-to-long p2, p2

    iput-wide p2, p0, LE0/c;->b:J

    :cond_4a
    const-string p2, "keyframes"

    invoke-virtual {p1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    instance-of p2, p1, Ljava/util/Map;

    if-eqz p2, :cond_af

    check-cast p1, Ljava/util/Map;

    const-string p2, "filepositions"

    invoke-interface {p1, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const-string p3, "times"

    invoke-interface {p1, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    instance-of p3, p2, Ljava/util/List;

    if-eqz p3, :cond_af

    instance-of p3, p1, Ljava/util/List;

    if-eqz p3, :cond_af

    check-cast p2, Ljava/util/List;

    check-cast p1, Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    new-array v3, p3, [J

    iput-object v3, p0, LE0/c;->c:[J

    new-array v3, p3, [J

    iput-object v3, p0, LE0/c;->d:[J

    const/4 v3, 0x0

    :goto_7b
    if-ge v3, p3, :cond_af

    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/Double;

    if-eqz v6, :cond_a7

    instance-of v6, v4, Ljava/lang/Double;

    if-eqz v6, :cond_a7

    iget-object v6, p0, LE0/c;->c:[J

    check-cast v5, Ljava/lang/Double;

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v7

    mul-double v7, v7, v1

    double-to-long v7, v7

    aput-wide v7, v6, v3

    iget-object v5, p0, LE0/c;->d:[J

    check-cast v4, Ljava/lang/Double;

    invoke-virtual {v4}, Ljava/lang/Double;->longValue()J

    move-result-wide v6

    aput-wide v6, v5, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_7b

    :cond_a7
    new-array p1, v0, [J

    iput-object p1, p0, LE0/c;->c:[J

    new-array p1, v0, [J

    iput-object p1, p0, LE0/c;->d:[J

    :cond_af
    return v0
.end method
