.class final Le0/a;
.super Ljava/lang/Object;
.source "OkHttpDataSource.java"

# interfaces
.implements Lokhttp3/Callback;


# instance fields
.field final synthetic a:Lcom/google/common/util/concurrent/r;


# direct methods
.method constructor <init>(Lcom/google/common/util/concurrent/r;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le0/a;->a:Lcom/google/common/util/concurrent/r;

    return-void
.end method


# virtual methods
.method public final onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    .registers 3

    iget-object p1, p0, Le0/a;->a:Lcom/google/common/util/concurrent/r;

    invoke-virtual {p1, p2}, Lcom/google/common/util/concurrent/r;->t(Ljava/lang/Throwable;)Z

    return-void
.end method

.method public final onResponse(Lokhttp3/Call;Lokhttp3/Response;)V
    .registers 3

    iget-object p1, p0, Le0/a;->a:Lcom/google/common/util/concurrent/r;

    invoke-virtual {p1, p2}, Lcom/google/common/util/concurrent/r;->s(Ljava/lang/Object;)Z

    return-void
.end method
