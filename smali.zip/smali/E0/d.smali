.class abstract LE0/d;
.super Ljava/lang/Object;
.source "TagPayloadReader.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LE0/d$a;
    }
.end annotation


# instance fields
.field protected final a:Ly0/J;


# direct methods
.method protected constructor <init>(Ly0/J;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE0/d;->a:Ly0/J;

    return-void
.end method
