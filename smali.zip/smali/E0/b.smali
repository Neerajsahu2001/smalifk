.class public final Le0/b;
.super Landroidx/media3/datasource/a;
.source "OkHttpDataSource.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le0/b$a;
    }
.end annotation


# instance fields
.field private final e:Lokhttp3/Call$Factory;

.field private final f:Lc0/n;

.field private final g:Ljava/lang/String;

.field private final h:Lokhttp3/CacheControl;

.field private final i:Lc0/n;

.field private final j:Lfk/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lfk/g<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private k:Lokhttp3/Response;

.field private l:Ljava/io/InputStream;

.field private m:Z

.field private n:J

.field private o:J


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "media3.datasource.okhttp"

    invoke-static {v0}, Landroidx/media3/common/r;->a(Ljava/lang/String;)V

    return-void
.end method

.method constructor <init>(Lokhttp3/Call$Factory;Ljava/lang/String;Lc0/n;)V
    .registers 5

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroidx/media3/datasource/a;-><init>(Z)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Le0/b;->e:Lokhttp3/Call$Factory;

    iput-object p2, p0, Le0/b;->g:Ljava/lang/String;

    const/4 p1, 0x0

    iput-object p1, p0, Le0/b;->h:Lokhttp3/CacheControl;

    iput-object p3, p0, Le0/b;->i:Lc0/n;

    iput-object p1, p0, Le0/b;->j:Lfk/g;

    new-instance p1, Lc0/n;

    invoke-direct {p1}, Lc0/n;-><init>()V

    iput-object p1, p0, Le0/b;->f:Lc0/n;

    return-void
.end method

.method private o()V
    .registers 3

    iget-object v0, p0, Le0/b;->k:Lokhttp3/Response;

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->close()V

    iput-object v1, p0, Le0/b;->k:Lokhttp3/Response;

    :cond_11
    iput-object v1, p0, Le0/b;->l:Ljava/io/InputStream;

    return-void
.end method

.method private p(J)V
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lc0/k;
        }
    .end annotation

    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-nez v2, :cond_7

    return-void

    :cond_7
    const/16 v2, 0x1000

    new-array v3, v2, [B

    :goto_b
    cmp-long v4, p1, v0

    if-lez v4, :cond_50

    int-to-long v4, v2

    :try_start_10
    invoke-static {p1, p2, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v4

    long-to-int v5, v4

    iget-object v4, p0, Le0/b;->l:Ljava/io/InputStream;

    sget v6, La0/T;->a:I

    const/4 v6, 0x0

    invoke-virtual {v4, v3, v6, v5}, Ljava/io/InputStream;->read([BII)I

    move-result v4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v5

    if-nez v5, :cond_3b

    const/4 v5, -0x1

    if-eq v4, v5, :cond_33

    int-to-long v5, v4

    sub-long/2addr p1, v5

    invoke-virtual {p0, v4}, Landroidx/media3/datasource/a;->k(I)V

    goto :goto_b

    :catch_31
    move-exception p1

    goto :goto_41

    :cond_33
    new-instance p1, Lc0/k;

    const/16 p2, 0x7d8

    invoke-direct {p1, p2}, Lc0/k;-><init>(I)V

    throw p1

    :cond_3b
    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1
    :try_end_41
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_41} :catch_31

    :goto_41
    instance-of p2, p1, Lc0/k;

    if-eqz p2, :cond_48

    check-cast p1, Lc0/k;

    throw p1

    :cond_48
    new-instance p1, Lc0/k;

    const/16 p2, 0x7d0

    invoke-direct {p1, p2}, Lc0/k;-><init>(I)V

    throw p1

    :cond_50
    return-void
.end method


# virtual methods
.method public final a(Lc0/g;)J
    .registers 20
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lc0/k;
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const-wide/16 v2, 0x0

    iput-wide v2, v1, Le0/b;->o:J

    iput-wide v2, v1, Le0/b;->n:J

    invoke-virtual/range {p0 .. p1}, Landroidx/media3/datasource/a;->m(Lc0/g;)V

    iget-wide v4, v0, Lc0/g;->f:J

    iget-object v6, v0, Lc0/g;->a:Landroid/net/Uri;

    invoke-virtual {v6}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lokhttp3/HttpUrl;->parse(Ljava/lang/String;)Lokhttp3/HttpUrl;

    move-result-object v6

    if-eqz v6, :cond_197

    new-instance v7, Lokhttp3/Request$Builder;

    invoke-direct {v7}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v7, v6}, Lokhttp3/Request$Builder;->url(Lokhttp3/HttpUrl;)Lokhttp3/Request$Builder;

    move-result-object v6

    iget-object v7, v1, Le0/b;->h:Lokhttp3/CacheControl;

    if-eqz v7, :cond_2b

    invoke-virtual {v6, v7}, Lokhttp3/Request$Builder;->cacheControl(Lokhttp3/CacheControl;)Lokhttp3/Request$Builder;

    :cond_2b
    new-instance v7, Ljava/util/HashMap;

    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    iget-object v8, v1, Le0/b;->i:Lc0/n;

    if-eqz v8, :cond_3b

    invoke-virtual {v8}, Lc0/n;->b()Ljava/util/Map;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_3b
    iget-object v8, v1, Le0/b;->f:Lc0/n;

    invoke-virtual {v8}, Lc0/n;->b()Ljava/util/Map;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    iget-object v8, v0, Lc0/g;->e:Ljava/util/Map;

    invoke-virtual {v7, v8}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    invoke-virtual {v7}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_51
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_6d

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/Map$Entry;

    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v6, v9, v8}, Lokhttp3/Request$Builder;->header(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    goto :goto_51

    :cond_6d
    iget-wide v7, v0, Lc0/g;->g:J

    invoke-static {v4, v5, v7, v8}, Lc0/o;->a(JJ)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_7a

    const-string v5, "Range"

    invoke-virtual {v6, v5, v4}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    :cond_7a
    iget-object v4, v1, Le0/b;->g:Ljava/lang/String;

    if-eqz v4, :cond_83

    const-string v5, "User-Agent"

    invoke-virtual {v6, v5, v4}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    :cond_83
    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Lc0/g;->c(I)Z

    move-result v5

    if-nez v5, :cond_91

    const-string v5, "Accept-Encoding"

    const-string v9, "identity"

    invoke-virtual {v6, v5, v9}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    :cond_91
    iget v9, v0, Lc0/g;->c:I

    iget-object v10, v0, Lc0/g;->d:[B

    if-eqz v10, :cond_9c

    invoke-static {v10}, Lokhttp3/RequestBody;->create([B)Lokhttp3/RequestBody;

    move-result-object v10

    goto :goto_a7

    :cond_9c
    const/4 v10, 0x2

    if-ne v9, v10, :cond_a6

    sget-object v10, La0/T;->f:[B

    invoke-static {v10}, Lokhttp3/RequestBody;->create([B)Lokhttp3/RequestBody;

    move-result-object v10

    goto :goto_a7

    :cond_a6
    const/4 v10, 0x0

    :goto_a7
    invoke-static {v9}, Lc0/g;->b(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9, v10}, Lokhttp3/Request$Builder;->method(Ljava/lang/String;Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    invoke-virtual {v6}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v6

    iget-object v9, v1, Le0/b;->e:Lokhttp3/Call$Factory;

    invoke-interface {v9, v6}, Lokhttp3/Call$Factory;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v6

    :try_start_b8
    invoke-static {}, Lcom/google/common/util/concurrent/r;->v()Lcom/google/common/util/concurrent/r;

    move-result-object v9

    new-instance v10, Le0/a;

    invoke-direct {v10, v9}, Le0/a;-><init>(Lcom/google/common/util/concurrent/r;)V

    invoke-interface {v6, v10}, Lokhttp3/Call;->enqueue(Lokhttp3/Callback;)V
    :try_end_c4
    .catch Ljava/io/IOException; {:try_start_b8 .. :try_end_c4} :catch_180

    :try_start_c4
    invoke-virtual {v9}, Lcom/google/common/util/concurrent/r;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lokhttp3/Response;
    :try_end_ca
    .catch Ljava/lang/InterruptedException; {:try_start_c4 .. :try_end_ca} :catch_189
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_c4 .. :try_end_ca} :catch_182
    .catch Ljava/io/IOException; {:try_start_c4 .. :try_end_ca} :catch_180

    :try_start_ca
    iput-object v9, v1, Le0/b;->k:Lokhttp3/Response;

    invoke-virtual {v9}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Lokhttp3/ResponseBody;->byteStream()Ljava/io/InputStream;

    move-result-object v10

    iput-object v10, v1, Le0/b;->l:Ljava/io/InputStream;
    :try_end_d9
    .catch Ljava/io/IOException; {:try_start_ca .. :try_end_d9} :catch_180

    invoke-virtual {v9}, Lokhttp3/Response;->code()I

    move-result v10

    invoke-virtual {v9}, Lokhttp3/Response;->isSuccessful()Z

    move-result v11

    const-wide/16 v12, -0x1

    iget-wide v14, v0, Lc0/g;->f:J

    if-nez v11, :cond_132

    const/16 v6, 0x1a0

    if-ne v10, v6, :cond_108

    invoke-virtual {v9}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v11

    const-string v5, "Content-Range"

    invoke-virtual {v11, v5}, Lokhttp3/Headers;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lc0/o;->c(Ljava/lang/String;)J

    move-result-wide v16

    cmp-long v5, v14, v16

    if-nez v5, :cond_108

    iput-boolean v4, v1, Le0/b;->m:Z

    invoke-virtual/range {p0 .. p1}, Landroidx/media3/datasource/a;->n(Lc0/g;)V

    cmp-long v0, v7, v12

    if-eqz v0, :cond_107

    move-wide v2, v7

    :cond_107
    return-wide v2

    :cond_108
    :try_start_108
    iget-object v0, v1, Le0/b;->l:Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Lhk/a;->b(Ljava/io/InputStream;)[B
    :try_end_110
    .catch Ljava/io/IOException; {:try_start_108 .. :try_end_110} :catch_111

    goto :goto_113

    :catch_111
    sget v0, La0/T;->a:I

    :goto_113
    invoke-virtual {v9}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Headers;->toMultimap()Ljava/util/Map;

    move-result-object v0

    invoke-direct/range {p0 .. p0}, Le0/b;->o()V

    if-ne v10, v6, :cond_128

    new-instance v5, Lc0/e;

    const/16 v2, 0x7d8

    invoke-direct {v5, v2}, Lc0/e;-><init>(I)V

    goto :goto_129

    :cond_128
    const/4 v5, 0x0

    :goto_129
    new-instance v2, Lc0/m;

    invoke-virtual {v9}, Lokhttp3/Response;->message()Ljava/lang/String;

    invoke-direct {v2, v10, v5, v0}, Lc0/m;-><init>(ILc0/e;Ljava/util/Map;)V

    throw v2

    :cond_132
    invoke-virtual {v6}, Lokhttp3/ResponseBody;->contentType()Lokhttp3/MediaType;

    move-result-object v5

    if-eqz v5, :cond_13d

    invoke-virtual {v5}, Lokhttp3/MediaType;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_13f

    :cond_13d
    const-string v5, ""

    :goto_13f
    iget-object v9, v1, Le0/b;->j:Lfk/g;

    if-eqz v9, :cond_153

    invoke-interface {v9, v5}, Lfk/g;->apply(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_14a

    goto :goto_153

    :cond_14a
    invoke-direct/range {p0 .. p0}, Le0/b;->o()V

    new-instance v0, Lc0/l;

    invoke-direct {v0, v5}, Lc0/l;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_153
    :goto_153
    const/16 v5, 0xc8

    if-ne v10, v5, :cond_15c

    cmp-long v5, v14, v2

    if-eqz v5, :cond_15c

    move-wide v2, v14

    :cond_15c
    cmp-long v5, v7, v12

    if-eqz v5, :cond_163

    iput-wide v7, v1, Le0/b;->n:J

    goto :goto_16f

    :cond_163
    invoke-virtual {v6}, Lokhttp3/ResponseBody;->contentLength()J

    move-result-wide v5

    cmp-long v7, v5, v12

    if-eqz v7, :cond_16d

    sub-long v12, v5, v2

    :cond_16d
    iput-wide v12, v1, Le0/b;->n:J

    :goto_16f
    iput-boolean v4, v1, Le0/b;->m:Z

    invoke-virtual/range {p0 .. p1}, Landroidx/media3/datasource/a;->n(Lc0/g;)V

    :try_start_174
    invoke-direct {v1, v2, v3}, Le0/b;->p(J)V
    :try_end_177
    .catch Lc0/k; {:try_start_174 .. :try_end_177} :catch_17a

    iget-wide v2, v1, Le0/b;->n:J

    return-wide v2

    :catch_17a
    move-exception v0

    move-object v2, v0

    invoke-direct/range {p0 .. p0}, Le0/b;->o()V

    throw v2

    :catch_180
    move-exception v0

    goto :goto_192

    :catch_182
    move-exception v0

    :try_start_183
    new-instance v2, Ljava/io/IOException;

    invoke-direct {v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :catch_189
    invoke-interface {v6}, Lokhttp3/Call;->cancel()V

    new-instance v0, Ljava/io/InterruptedIOException;

    invoke-direct {v0}, Ljava/io/InterruptedIOException;-><init>()V

    throw v0
    :try_end_192
    .catch Ljava/io/IOException; {:try_start_183 .. :try_end_192} :catch_180

    :goto_192
    invoke-static {v0, v4}, Lc0/k;->b(Ljava/io/IOException;I)Lc0/k;

    move-result-object v0

    throw v0

    :cond_197
    new-instance v0, Lc0/k;

    const-string v2, "Malformed URL"

    const/16 v3, 0x3ec

    invoke-direct {v0, v2, v3}, Lc0/k;-><init>(Ljava/lang/String;I)V

    throw v0
.end method

.method public final c()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Le0/b;->k:Lokhttp3/Response;

    if-nez v0, :cond_9

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    goto :goto_11

    :cond_9
    invoke-virtual {v0}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Headers;->toMultimap()Ljava/util/Map;

    move-result-object v0

    :goto_11
    return-object v0
.end method

.method public final close()V
    .registers 2

    iget-boolean v0, p0, Le0/b;->m:Z

    if-eqz v0, :cond_d

    const/4 v0, 0x0

    iput-boolean v0, p0, Le0/b;->m:Z

    invoke-virtual {p0}, Landroidx/media3/datasource/a;->l()V

    invoke-direct {p0}, Le0/b;->o()V

    :cond_d
    return-void
.end method

.method public final getUri()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Le0/b;->k:Lokhttp3/Response;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_16

    :cond_6
    invoke-virtual {v0}, Lokhttp3/Response;->request()Lokhttp3/Request;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/HttpUrl;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    :goto_16
    return-object v0
.end method

.method public final read([BII)I
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lc0/k;
        }
    .end annotation

    if-nez p3, :cond_4

    const/4 p1, 0x0

    goto :goto_32

    :cond_4
    :try_start_4
    iget-wide v0, p0, Le0/b;->n:J

    const-wide/16 v2, -0x1

    const/4 v4, -0x1

    cmp-long v5, v0, v2

    if-eqz v5, :cond_1e

    iget-wide v2, p0, Le0/b;->o:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long v5, v0, v2

    if-nez v5, :cond_18

    :goto_16
    const/4 p1, -0x1

    goto :goto_32

    :cond_18
    int-to-long v2, p3

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int p3, v0

    :cond_1e
    iget-object v0, p0, Le0/b;->l:Ljava/io/InputStream;

    sget v1, La0/T;->a:I

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/InputStream;->read([BII)I

    move-result p1

    if-ne p1, v4, :cond_29

    goto :goto_16

    :cond_29
    iget-wide p2, p0, Le0/b;->o:J

    int-to-long v0, p1

    add-long/2addr p2, v0

    iput-wide p2, p0, Le0/b;->o:J

    invoke-virtual {p0, p1}, Landroidx/media3/datasource/a;->k(I)V
    :try_end_32
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_32} :catch_33

    :goto_32
    return p1

    :catch_33
    move-exception p1

    sget p2, La0/T;->a:I

    const/4 p2, 0x2

    invoke-static {p1, p2}, Lc0/k;->b(Ljava/io/IOException;I)Lc0/k;

    move-result-object p1

    throw p1
.end method
