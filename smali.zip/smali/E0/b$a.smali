.class public final Le0/b$a;
.super Ljava/lang/Object;
.source "OkHttpDataSource.java"

# interfaces
.implements Landroidx/media3/datasource/b$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le0/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Lc0/n;

.field private final b:Lokhttp3/Call$Factory;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lokhttp3/OkHttpClient;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le0/b$a;->b:Lokhttp3/Call$Factory;

    new-instance p1, Lc0/n;

    invoke-direct {p1}, Lc0/n;-><init>()V

    iput-object p1, p0, Le0/b$a;->a:Lc0/n;

    return-void
.end method


# virtual methods
.method public final a()Landroidx/media3/datasource/b;
    .registers 5

    new-instance v0, Le0/b;

    iget-object v1, p0, Le0/b$a;->c:Ljava/lang/String;

    iget-object v2, p0, Le0/b$a;->a:Lc0/n;

    iget-object v3, p0, Le0/b$a;->b:Lokhttp3/Call$Factory;

    invoke-direct {v0, v3, v1, v2}, Le0/b;-><init>(Lokhttp3/Call$Factory;Ljava/lang/String;Lc0/n;)V

    return-object v0
.end method

.method public final b(Ljava/util/Map;)V
    .registers 3

    iget-object v0, p0, Le0/b$a;->a:Lc0/n;

    invoke-virtual {v0, p1}, Lc0/n;->a(Ljava/util/Map;)V

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Le0/b$a;->c:Ljava/lang/String;

    return-void
.end method
