.class final LE0/e;
.super LE0/d;
.source "VideoTagPayloadReader.java"


# instance fields
.field private final b:La0/C;

.field private final c:La0/C;

.field private d:I

.field private e:Z

.field private f:Z

.field private g:I


# direct methods
.method public constructor <init>(Ly0/J;)V
    .registers 3

    invoke-direct {p0, p1}, LE0/d;-><init>(Ly0/J;)V

    new-instance p1, La0/C;

    sget-object v0, Landroidx/media3/container/b;->a:[B

    invoke-direct {p1, v0}, La0/C;-><init>([B)V

    iput-object p1, p0, LE0/e;->b:La0/C;

    new-instance p1, La0/C;

    const/4 v0, 0x4

    invoke-direct {p1, v0}, La0/C;-><init>(I)V

    iput-object p1, p0, LE0/e;->c:La0/C;

    return-void
.end method


# virtual methods
.method protected final a(La0/C;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            LE0/d$a;
        }
    .end annotation

    invoke-virtual {p1}, La0/C;->A()I

    move-result p1

    shr-int/lit8 v0, p1, 0x4

    and-int/lit8 v0, v0, 0xf

    and-int/lit8 p1, p1, 0xf

    const/4 v1, 0x7

    if-ne p1, v1, :cond_16

    iput v0, p0, LE0/e;->g:I

    const/4 p1, 0x5

    if-eq v0, p1, :cond_14

    const/4 p1, 0x1

    goto :goto_15

    :cond_14
    const/4 p1, 0x0

    :goto_15
    return p1

    :cond_16
    new-instance v0, LE0/d$a;

    const-string v1, "Video format not supported: "

    invoke-static {v1, p1}, Landroidx/core/content/b;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, LE0/d$a;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method protected final b(La0/C;J)Z
    .registers 14
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/media3/common/v;
        }
    .end annotation

    invoke-virtual {p1}, La0/C;->A()I

    move-result v0

    invoke-virtual {p1}, La0/C;->m()I

    move-result v1

    int-to-long v1, v1

    const-wide/16 v3, 0x3e8

    mul-long v1, v1, v3

    add-long v4, v1, p2

    iget-object p2, p0, LE0/d;->a:Ly0/J;

    const/4 p3, 0x1

    const/4 v1, 0x0

    if-nez v0, :cond_64

    iget-boolean v2, p0, LE0/e;->e:Z

    if-nez v2, :cond_64

    new-instance v0, La0/C;

    invoke-virtual {p1}, La0/C;->a()I

    move-result v2

    new-array v2, v2, [B

    invoke-direct {v0, v2}, La0/C;-><init>([B)V

    invoke-virtual {v0}, La0/C;->d()[B

    move-result-object v2

    invoke-virtual {p1}, La0/C;->a()I

    move-result v3

    invoke-virtual {p1, v2, v1, v3}, La0/C;->j([BII)V

    invoke-static {v0}, Ly0/d;->a(La0/C;)Ly0/d;

    move-result-object p1

    iget v0, p1, Ly0/d;->b:I

    iput v0, p0, LE0/e;->d:I

    new-instance v0, Landroidx/media3/common/m$a;

    invoke-direct {v0}, Landroidx/media3/common/m$a;-><init>()V

    const-string v2, "video/avc"

    invoke-virtual {v0, v2}, Landroidx/media3/common/m$a;->o0(Ljava/lang/String;)V

    iget-object v2, p1, Ly0/d;->l:Ljava/lang/String;

    invoke-virtual {v0, v2}, Landroidx/media3/common/m$a;->O(Ljava/lang/String;)V

    iget v2, p1, Ly0/d;->c:I

    invoke-virtual {v0, v2}, Landroidx/media3/common/m$a;->v0(I)V

    iget v2, p1, Ly0/d;->d:I

    invoke-virtual {v0, v2}, Landroidx/media3/common/m$a;->Y(I)V

    iget v2, p1, Ly0/d;->k:F

    invoke-virtual {v0, v2}, Landroidx/media3/common/m$a;->k0(F)V

    iget-object p1, p1, Ly0/d;->a:Ljava/util/List;

    invoke-virtual {v0, p1}, Landroidx/media3/common/m$a;->b0(Ljava/util/List;)V

    invoke-virtual {v0}, Landroidx/media3/common/m$a;->K()Landroidx/media3/common/m;

    move-result-object p1

    invoke-interface {p2, p1}, Ly0/J;->a(Landroidx/media3/common/m;)V

    iput-boolean p3, p0, LE0/e;->e:Z

    return v1

    :cond_64
    if-ne v0, p3, :cond_ba

    iget-boolean v0, p0, LE0/e;->e:Z

    if-eqz v0, :cond_ba

    iget v0, p0, LE0/e;->g:I

    if-ne v0, p3, :cond_70

    const/4 v6, 0x1

    goto :goto_71

    :cond_70
    const/4 v6, 0x0

    :goto_71
    iget-boolean v0, p0, LE0/e;->f:Z

    if-nez v0, :cond_78

    if-nez v6, :cond_78

    return v1

    :cond_78
    iget-object v0, p0, LE0/e;->c:La0/C;

    invoke-virtual {v0}, La0/C;->d()[B

    move-result-object v2

    aput-byte v1, v2, v1

    aput-byte v1, v2, p3

    const/4 v3, 0x2

    aput-byte v1, v2, v3

    iget v2, p0, LE0/e;->d:I

    const/4 v3, 0x4

    rsub-int/lit8 v2, v2, 0x4

    const/4 v7, 0x0

    :goto_8b
    invoke-virtual {p1}, La0/C;->a()I

    move-result v8

    if-lez v8, :cond_b0

    invoke-virtual {v0}, La0/C;->d()[B

    move-result-object v8

    iget v9, p0, LE0/e;->d:I

    invoke-virtual {p1, v8, v2, v9}, La0/C;->j([BII)V

    invoke-virtual {v0, v1}, La0/C;->M(I)V

    invoke-virtual {v0}, La0/C;->E()I

    move-result v8

    iget-object v9, p0, LE0/e;->b:La0/C;

    invoke-virtual {v9, v1}, La0/C;->M(I)V

    invoke-interface {p2, v3, v9}, Ly0/J;->c(ILa0/C;)V

    add-int/lit8 v7, v7, 0x4

    invoke-interface {p2, v8, p1}, Ly0/J;->c(ILa0/C;)V

    add-int/2addr v7, v8

    goto :goto_8b

    :cond_b0
    const/4 v9, 0x0

    iget-object v3, p0, LE0/d;->a:Ly0/J;

    const/4 v8, 0x0

    invoke-interface/range {v3 .. v9}, Ly0/J;->b(JIIILy0/J$a;)V

    iput-boolean p3, p0, LE0/e;->f:Z

    return p3

    :cond_ba
    return v1
.end method
