.class public final LD5/b;
.super Ljava/lang/Object;
.source "AttachedProductTracking.java"


# instance fields
.field public a:Ljava/lang/Integer;

.field public b:Lab/b;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:LD5/d;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
