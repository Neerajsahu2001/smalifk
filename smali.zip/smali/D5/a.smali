.class public final Ld5/a;
.super Lxk/z;
.source "CheckoutTypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LJa/b;",
        ">;"
    }
.end annotation


# instance fields
.field private a:Lxk/j;


# direct methods
.method public constructor <init>(Lxk/j;)V
    .registers 2

    invoke-direct {p0}, Lxk/z;-><init>()V

    iput-object p1, p0, Ld5/a;->a:Lxk/j;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LJa/b;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v0, v1, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v0, v1, :cond_19

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_19
    invoke-virtual {p1}, LBk/a;->beginObject()V

    :goto_1c
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_51

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v1

    sget-object v3, LBk/b;->NULL:LBk/b;

    if-ne v1, v3, :cond_32

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1c

    :cond_32
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "asmData"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto :goto_1c

    :cond_41
    iget-object v0, p0, Ld5/a;->a:Lxk/j;

    sget-object v1, LJa/a;->c:Lcom/google/gson/reflect/a;

    invoke-virtual {v0, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    invoke-virtual {v0, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LJa/b;

    move-object v2, v0

    goto :goto_1c

    :cond_51
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v2
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Ld5/a;->read(LBk/a;)LJa/b;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LJa/b;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LJa/b;

    invoke-virtual {p0, p1, p2}, Ld5/a;->write(LBk/c;LJa/b;)V

    return-void
.end method
