.class public final LD5/j;
.super Ljava/lang/Object;
.source "CheckoutExecutionStateRome.java"


# instance fields
.field public a:Ljava/lang/String;

.field public b:LD5/f;

.field public c:LQa/b;

.field public d:LGe/b;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
