.class public final LD5/l;
.super Lxk/z;
.source "ParentProductTracking$TypeAdapter.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lxk/z<",
        "LD5/m;",
        ">;"
    }
.end annotation


# static fields
.field public static final f:Lcom/google/gson/reflect/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/gson/reflect/a<",
            "LD5/m;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/TrackingDataV2;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;",
            ">;"
        }
    .end annotation
.end field

.field private final e:Lxk/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxk/z<",
            "Lcom/flipkart/android/analytics/AddCartLocation;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, LD5/m;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    sput-object v0, LD5/l;->f:Lcom/google/gson/reflect/a;

    return-void
.end method

.method public constructor <init>(Lxk/j;)V
    .registers 7

    invoke-direct {p0}, Lxk/z;-><init>()V

    const-class v0, Lcom/flipkart/rome/datatypes/response/product/TrackingDataV2;

    invoke-static {v0}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v0

    const-class v1, Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    invoke-static {v1}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v1

    const-class v2, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    invoke-static {v2}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v2

    const-class v3, Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    invoke-static {v3}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v3

    const-class v4, Lcom/flipkart/android/analytics/AddCartLocation;

    invoke-static {v4}, Lcom/google/gson/reflect/a;->get(Ljava/lang/Class;)Lcom/google/gson/reflect/a;

    move-result-object v4

    invoke-virtual {p1, v0}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, LD5/l;->a:Lxk/z;

    invoke-virtual {p1, v1}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, LD5/l;->b:Lxk/z;

    invoke-virtual {p1, v2}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, LD5/l;->c:Lxk/z;

    invoke-virtual {p1, v3}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object v0

    iput-object v0, p0, LD5/l;->d:Lxk/z;

    invoke-virtual {p1, v4}, Lxk/j;->g(Lcom/google/gson/reflect/a;)Lxk/z;

    move-result-object p1

    iput-object p1, p0, LD5/l;->e:Lxk/z;

    return-void
.end method


# virtual methods
.method public read(LBk/a;)LD5/m;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, LBk/a;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NULL:LBk/b;

    const/4 v2, 0x0

    if-ne v1, v0, :cond_d

    invoke-virtual {p1}, LBk/a;->nextNull()V

    return-object v2

    :cond_d
    sget-object v1, LBk/b;->BEGIN_OBJECT:LBk/b;

    if-eq v1, v0, :cond_15

    invoke-virtual {p1}, LBk/a;->skipValue()V

    return-object v2

    :cond_15
    invoke-virtual {p1}, LBk/a;->beginObject()V

    new-instance v0, LD5/m;

    invoke-direct {v0}, LD5/m;-><init>()V

    :goto_1d
    invoke-virtual {p1}, LBk/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_155

    invoke-virtual {p1}, LBk/a;->nextName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_15a

    goto/16 :goto_c3

    :sswitch_34
    const-string v2, "trackingDataV2"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3e

    goto/16 :goto_c3

    :cond_3e
    const/16 v3, 0xb

    goto/16 :goto_c3

    :sswitch_42
    const-string v2, "trackPostCheckout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto/16 :goto_c3

    :cond_4c
    const/16 v3, 0xa

    goto/16 :goto_c3

    :sswitch_50
    const-string v2, "addCartLocation"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    goto/16 :goto_c3

    :cond_5a
    const/16 v3, 0x9

    goto/16 :goto_c3

    :sswitch_5e
    const-string v2, "numberItemsDeselected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_68

    goto/16 :goto_c3

    :cond_68
    const/16 v3, 0x8

    goto/16 :goto_c3

    :sswitch_6c
    const-string v2, "marketplace"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_75

    goto :goto_c3

    :cond_75
    const/4 v3, 0x7

    goto :goto_c3

    :sswitch_77
    const-string v2, "parentProductId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_80

    goto :goto_c3

    :cond_80
    const/4 v3, 0x6

    goto :goto_c3

    :sswitch_82
    const-string v2, "parentListingId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8b

    goto :goto_c3

    :cond_8b
    const/4 v3, 0x5

    goto :goto_c3

    :sswitch_8d
    const-string v2, "pricing"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_96

    goto :goto_c3

    :cond_96
    const/4 v3, 0x4

    goto :goto_c3

    :sswitch_98
    const-string v2, "isCollectionCheckout"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a1

    goto :goto_c3

    :cond_a1
    const/4 v3, 0x3

    goto :goto_c3

    :sswitch_a3
    const-string v2, "rating"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ac

    goto :goto_c3

    :cond_ac
    const/4 v3, 0x2

    goto :goto_c3

    :sswitch_ae
    const-string v2, "fetchId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b7

    goto :goto_c3

    :cond_b7
    const/4 v3, 0x1

    goto :goto_c3

    :sswitch_b9
    const-string v2, "analyticsData"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c2

    goto :goto_c3

    :cond_c2
    const/4 v3, 0x0

    :goto_c3
    packed-switch v3, :pswitch_data_18c

    invoke-virtual {p1}, LBk/a;->skipValue()V

    goto/16 :goto_1d

    :pswitch_cb
    iget-object v1, p0, LD5/l;->a:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/TrackingDataV2;

    iput-object v1, v0, LD5/m;->a:Lcom/flipkart/rome/datatypes/response/product/TrackingDataV2;

    goto/16 :goto_1d

    :pswitch_d7
    iget-boolean v1, v0, LD5/m;->k:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LD5/m;->k:Z

    goto/16 :goto_1d

    :pswitch_e1
    iget-object v1, p0, LD5/l;->e:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/android/analytics/AddCartLocation;

    iput-object v1, v0, LD5/m;->j:Lcom/flipkart/android/analytics/AddCartLocation;

    goto/16 :goto_1d

    :pswitch_ed
    iget v1, v0, LD5/m;->g:I

    invoke-static {p1, v1}, LJn/a$z;->a(LBk/a;I)I

    move-result v1

    iput v1, v0, LD5/m;->g:I

    goto/16 :goto_1d

    :pswitch_f7
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LD5/m;->h:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_103
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LD5/m;->b:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_10f
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LD5/m;->c:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_11b
    iget-object v1, p0, LD5/l;->c:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    iput-object v1, v0, LD5/m;->f:Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    goto/16 :goto_1d

    :pswitch_127
    iget-boolean v1, v0, LD5/m;->l:Z

    invoke-static {p1, v1}, LJn/a$v;->a(LBk/a;Z)Z

    move-result v1

    iput-boolean v1, v0, LD5/m;->l:Z

    goto/16 :goto_1d

    :pswitch_131
    iget-object v1, p0, LD5/l;->b:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    iput-object v1, v0, LD5/m;->e:Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    goto/16 :goto_1d

    :pswitch_13d
    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, LD5/m;->d:Ljava/lang/String;

    goto/16 :goto_1d

    :pswitch_149
    iget-object v1, p0, LD5/l;->d:Lxk/z;

    invoke-virtual {v1, p1}, Lxk/z;->read(LBk/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    iput-object v1, v0, LD5/m;->i:Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    goto/16 :goto_1d

    :cond_155
    invoke-virtual {p1}, LBk/a;->endObject()V

    return-object v0

    nop

    :sswitch_data_15a
    .sparse-switch
        -0x502e33b0 -> :sswitch_b9
        -0x3959b68b -> :sswitch_ae
        -0x37ea4e63 -> :sswitch_a3
        -0x34f78b32 -> :sswitch_98
        -0x12c7603a -> :sswitch_8d
        -0xf696cb -> :sswitch_82
        0x8c38ce0 -> :sswitch_77
        0x11ef8a4b -> :sswitch_6c
        0x42b7c373 -> :sswitch_5e
        0x4cfb4236 -> :sswitch_50
        0x57bc56f1 -> :sswitch_42
        0x5d569d5d -> :sswitch_34
    .end sparse-switch

    :pswitch_data_18c
    .packed-switch 0x0
        :pswitch_149
        :pswitch_13d
        :pswitch_131
        :pswitch_127
        :pswitch_11b
        :pswitch_10f
        :pswitch_103
        :pswitch_f7
        :pswitch_ed
        :pswitch_e1
        :pswitch_d7
        :pswitch_cb
    .end packed-switch
.end method

.method public bridge synthetic read(LBk/a;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, LD5/l;->read(LBk/a;)LD5/m;

    move-result-object p1

    return-object p1
.end method

.method public write(LBk/c;LD5/m;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_6

    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    return-void

    :cond_6
    invoke-virtual {p1}, LBk/c;->beginObject()LBk/c;

    const-string v0, "trackingDataV2"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->a:Lcom/flipkart/rome/datatypes/response/product/TrackingDataV2;

    if-eqz v0, :cond_18

    iget-object v1, p0, LD5/l;->a:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_1b

    :cond_18
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_1b
    const-string v0, "parentProductId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->b:Ljava/lang/String;

    if-eqz v0, :cond_2a

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_2d
    const-string v0, "parentListingId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->c:Ljava/lang/String;

    if-eqz v0, :cond_3c

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_3c
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_3f
    const-string v0, "fetchId"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->d:Ljava/lang/String;

    if-eqz v0, :cond_4e

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_51

    :cond_4e
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_51
    const-string v0, "rating"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->e:Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

    if-eqz v0, :cond_60

    iget-object v1, p0, LD5/l;->b:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_63

    :cond_60
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_63
    const-string v0, "pricing"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->f:Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

    if-eqz v0, :cond_72

    iget-object v1, p0, LD5/l;->c:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_75

    :cond_72
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_75
    const-string v0, "numberItemsDeselected"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget v0, p2, LD5/m;->g:I

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, LBk/c;->value(J)LBk/c;

    const-string v0, "marketplace"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->h:Ljava/lang/String;

    if-eqz v0, :cond_8f

    sget-object v1, Lcom/google/gson/internal/bind/TypeAdapters;->p:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_92

    :cond_8f
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_92
    const-string v0, "analyticsData"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->i:Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

    if-eqz v0, :cond_a1

    iget-object v1, p0, LD5/l;->d:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_a4

    :cond_a1
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_a4
    const-string v0, "addCartLocation"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-object v0, p2, LD5/m;->j:Lcom/flipkart/android/analytics/AddCartLocation;

    if-eqz v0, :cond_b3

    iget-object v1, p0, LD5/l;->e:Lxk/z;

    invoke-virtual {v1, p1, v0}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    goto :goto_b6

    :cond_b3
    invoke-virtual {p1}, LBk/c;->nullValue()LBk/c;

    :goto_b6
    const-string v0, "trackPostCheckout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean v0, p2, LD5/m;->k:Z

    invoke-virtual {p1, v0}, LBk/c;->value(Z)LBk/c;

    const-string v0, "isCollectionCheckout"

    invoke-virtual {p1, v0}, LBk/c;->name(Ljava/lang/String;)LBk/c;

    iget-boolean p2, p2, LD5/m;->l:Z

    invoke-virtual {p1, p2}, LBk/c;->value(Z)LBk/c;

    invoke-virtual {p1}, LBk/c;->endObject()LBk/c;

    return-void
.end method

.method public bridge synthetic write(LBk/c;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p2, LD5/m;

    invoke-virtual {p0, p1, p2}, LD5/l;->write(LBk/c;LD5/m;)V

    return-void
.end method
