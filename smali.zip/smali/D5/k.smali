.class public final LD5/k;
.super Ljava/lang/Object;
.source "CheckoutUIImpl.java"

# interfaces
.implements LC5/a;


# instance fields
.field private a:Landroid/content/Context;

.field private b:Lb7/b;

.field private c:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Lb7/b;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD5/k;->a:Landroid/content/Context;

    iput-object p2, p0, LD5/k;->b:Lb7/b;

    return-void
.end method


# virtual methods
.method public handleASM(Lcom/flipkart/mapi/model/component/data/renderables/b;LJa/b;Ljg/e0;Ljava/util/Map;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/flipkart/mapi/model/component/data/renderables/b;",
            "LJa/b;",
            "Ljg/e0;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    return-void
.end method

.method public handleLoginDismissState()V
    .registers 3

    iget-boolean v0, p0, LD5/k;->c:Z

    if-eqz v0, :cond_a

    const-string v0, "Login failed"

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1}, LD5/k;->onFailure(Ljava/lang/String;I)V

    :cond_a
    return-void
.end method

.method public handlePartialFailure(Ljg/e0;)V
    .registers 4

    iget-object v0, p0, LD5/k;->a:Landroid/content/Context;

    instance-of v1, v0, Landroidx/appcompat/app/j;

    if-eqz v1, :cond_15

    check-cast v0, Landroidx/appcompat/app/j;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_15

    invoke-virtual {v0}, Landroidx/fragment/app/d;->getSupportFragmentManager()Landroidx/fragment/app/o;

    move-result-object v0

    invoke-static {v0, p1}, Lcom/flipkart/android/wike/utils/TransactController;->handlePartialFailure(Landroidx/fragment/app/o;Ljg/e0;)V

    :cond_15
    return-void
.end method

.method public onFailure(Ljava/lang/String;I)V
    .registers 6

    iget-object v0, p0, LD5/k;->a:Landroid/content/Context;

    if-eqz v0, :cond_4a

    iget-object v1, p0, LD5/k;->b:Lb7/b;

    invoke-interface {v1}, Lb7/b;->isReadyToEmit()Z

    move-result v2

    if-eqz v2, :cond_45

    new-instance v2, LD5/f;

    invoke-direct {v2}, LD5/f;-><init>()V

    iput p2, v2, LD5/f;->c:I

    iput-object p1, v2, LD5/f;->e:Ljava/lang/String;

    new-instance p1, LD5/h;

    invoke-direct {p1}, LD5/h;-><init>()V

    const-string p2, "CHECKOUT_FAILURE"

    iput-object p2, p1, LD5/h;->a:Ljava/lang/String;

    iput-object v2, p1, LD5/h;->b:LD5/f;

    new-instance p2, Lc5/f;

    invoke-direct {p2}, Lc5/f;-><init>()V

    :try_start_25
    invoke-static {v0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/gson/Serializer;->getGson()Lxk/j;

    move-result-object v0

    const-class v2, LD5/h;

    invoke-virtual {v0, v2}, Lxk/j;->h(Ljava/lang/Class;)Lxk/z;

    move-result-object v0

    invoke-virtual {v0, p2, p1}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string p1, "checkoutStateEvent"

    invoke-virtual {p2}, Lc5/f;->get()Lcom/facebook/react/bridge/WritableNativeMap;

    move-result-object p2

    invoke-interface {v1, p1, p2}, Lb7/b;->emitReactEvent(Ljava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V
    :try_end_3f
    .catch Ljava/io/IOException; {:try_start_25 .. :try_end_3f} :catch_40

    goto :goto_4a

    :catch_40
    move-exception p1

    invoke-static {p1}, Lpa/a;->printStackTrace(Ljava/lang/Throwable;)V

    goto :goto_4a

    :cond_45
    const-string p1, "React not started yet on failure of checkout call "

    invoke-static {p1}, LDi/q;->d(Ljava/lang/String;)V

    :cond_4a
    :goto_4a
    return-void
.end method

.method public onSavedInstanceState(Landroid/os/Bundle;)V
    .registers 4

    const-string v0, "CHECKOUT_STARTED"

    iget-boolean v1, p0, LD5/k;->c:Z

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    return-void
.end method

.method public onStart(Lcom/flipkart/mapi/model/component/data/renderables/b;)V
    .registers 5

    iget-object p1, p0, LD5/k;->b:Lb7/b;

    invoke-interface {p1}, Lb7/b;->isReadyToEmit()Z

    move-result v0

    if-eqz v0, :cond_1a

    new-instance v0, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-direct {v0}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    const-string v1, "checkoutState"

    const-string v2, "CHECKOUT_STARTED"

    invoke-virtual {v0, v1, v2}, Lcom/facebook/react/bridge/WritableNativeMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "checkoutStateEvent"

    invoke-interface {p1, v1, v0}, Lb7/b;->emitReactEvent(Ljava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V

    goto :goto_1f

    :cond_1a
    const-string p1, "React not started yet on start of checkout call"

    invoke-static {p1}, LDi/q;->d(Ljava/lang/String;)V

    :goto_1f
    return-void
.end method

.method public onSuccess(LQa/b;Lcom/flipkart/mapi/model/component/data/renderables/b;)V
    .registers 7

    if-eqz p1, :cond_48

    iget-object v0, p0, LD5/k;->a:Landroid/content/Context;

    if-eqz v0, :cond_48

    iget-object v1, p0, LD5/k;->b:Lb7/b;

    invoke-interface {v1}, Lb7/b;->isReadyToEmit()Z

    move-result v2

    if-eqz v2, :cond_43

    const/4 v2, 0x0

    iput-boolean v2, p0, LD5/k;->c:Z

    new-instance v2, LD5/h;

    invoke-direct {v2}, LD5/h;-><init>()V

    const-string v3, "CHECKOUT_SUCCESS"

    iput-object v3, v2, LD5/h;->a:Ljava/lang/String;

    iput-object p2, v2, LD5/h;->d:Lcom/flipkart/mapi/model/component/data/renderables/b;

    iput-object p1, v2, LD5/h;->c:LQa/b;

    new-instance p1, Lc5/f;

    invoke-direct {p1}, Lc5/f;-><init>()V

    :try_start_23
    invoke-static {v0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object p2

    invoke-virtual {p2}, Lcom/flipkart/android/gson/Serializer;->getGson()Lxk/j;

    move-result-object p2

    const-class v0, LD5/h;

    invoke-virtual {p2, v0}, Lxk/j;->h(Ljava/lang/Class;)Lxk/z;

    move-result-object p2

    invoke-virtual {p2, p1, v2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    const-string p2, "checkoutStateEvent"

    invoke-virtual {p1}, Lc5/f;->get()Lcom/facebook/react/bridge/WritableNativeMap;

    move-result-object p1

    invoke-interface {v1, p2, p1}, Lb7/b;->emitReactEvent(Ljava/lang/String;Lcom/facebook/react/bridge/WritableNativeMap;)V
    :try_end_3d
    .catch Ljava/io/IOException; {:try_start_23 .. :try_end_3d} :catch_3e

    goto :goto_48

    :catch_3e
    move-exception p1

    invoke-static {p1}, Lpa/a;->printStackTrace(Ljava/lang/Throwable;)V

    goto :goto_48

    :cond_43
    const-string p1, "React not started yet on success of checkout call"

    invoke-static {p1}, LDi/q;->d(Ljava/lang/String;)V

    :cond_48
    :goto_48
    return-void
.end method

.method public restoreState(Landroid/os/Bundle;)V
    .registers 4

    if-eqz p1, :cond_b

    const-string v0, "CHECKOUT_STARTED"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    iput-boolean p1, p0, LD5/k;->c:Z

    :cond_b
    return-void
.end method

.method public setReactCheckoutStarted(Z)V
    .registers 2

    iput-boolean p1, p0, LD5/k;->c:Z

    return-void
.end method
