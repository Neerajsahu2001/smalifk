.class public final LD5/d;
.super Ljava/lang/Object;
.source "BuyNowTracking.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getDfm()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LD5/d;->a:Ljava/lang/String;

    return-object v0
.end method

.method public setDfm(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, LD5/d;->a:Ljava/lang/String;

    return-void
.end method
