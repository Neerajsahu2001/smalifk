.class public final LD5/m;
.super Ljava/lang/Object;
.source "ParentProductTracking.java"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:Lcom/flipkart/rome/datatypes/response/product/TrackingDataV2;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Lcom/flipkart/rome/datatypes/response/common/leaf/value/ugc/RatingValue;

.field public f:Lcom/flipkart/rome/datatypes/response/product/ProductPricingSummary;

.field public g:I

.field public h:Ljava/lang/String;

.field public i:Lcom/flipkart/rome/datatypes/response/product/AnalyticsData;

.field public j:Lcom/flipkart/android/analytics/AddCartLocation;

.field public k:Z

.field public l:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
