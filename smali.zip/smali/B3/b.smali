.class public interface abstract Lb3/b;
.super Ljava/lang/Object;
.source "DraweeHierarchy.java"


# virtual methods
.method public abstract b()La3/d;
.end method

.method public abstract getBounds()Landroid/graphics/Rect;
.end method
