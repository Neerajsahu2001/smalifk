.class public interface abstract Lb3/c;
.super Ljava/lang/Object;
.source "SettableDraweeHierarchy.java"

# interfaces
.implements Lb3/b;


# virtual methods
.method public abstract a(FZ)V
.end method

.method public abstract c(Landroid/graphics/drawable/Drawable;FZ)V
.end method

.method public abstract d()V
.end method

.method public abstract e(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract reset()V
.end method
