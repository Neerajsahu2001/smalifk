.class public interface abstract Lb3/a;
.super Ljava/lang/Object;
.source "DraweeController.java"


# virtual methods
.method public abstract a(Lb3/b;)V
.end method
