.class public final synthetic Le4/b;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Le4/b;->a:I

    iput-object p2, p0, Le4/b;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget p1, p0, Le4/b;->a:I

    iget-object v0, p0, Le4/b;->b:Ljava/lang/Object;

    packed-switch p1, :pswitch_data_14

    check-cast v0, Lcom/flipkart/android/customviews/d;

    invoke-virtual {v0}, Lcom/google/android/material/snackbar/BaseTransientBottomBar;->dismiss()V

    return-void

    :pswitch_d
    check-cast v0, Le4/c;

    invoke-static {v0}, Le4/c;->a(Le4/c;)V

    return-void

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_d
    .end packed-switch
.end method
