.class final Le4/d;
.super LFa/e;
.source "PinCodeDialogFragment.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LFa/e<",
        "LBb/b;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Le4/c;


# direct methods
.method constructor <init>(Le4/c;)V
    .registers 2

    iput-object p1, p0, Le4/d;->a:Le4/c;

    invoke-direct {p0}, LFa/e;-><init>()V

    return-void
.end method


# virtual methods
.method public errorReceived(Lwa/a;)V
    .registers 2

    iget-object p1, p0, Le4/d;->a:Le4/c;

    invoke-virtual {p1}, Le4/c;->j()V

    return-void
.end method

.method public onSuccess(LBb/b;)V
    .registers 7

    iget-object v0, p0, Le4/d;->a:Le4/c;

    const/4 v1, 0x0

    iput-boolean v1, v0, Le4/c;->W:Z

    const-string v2, "PincodeCheck"

    if-eqz p1, :cond_6d

    invoke-virtual {v0}, Landroidx/fragment/app/b;->getDialog()Landroid/app/Dialog;

    move-result-object v3

    if-eqz v3, :cond_6d

    invoke-virtual {v0}, Landroidx/fragment/app/b;->getDialog()Landroid/app/Dialog;

    move-result-object v3

    invoke-virtual {v3}, Landroid/app/Dialog;->isShowing()Z

    move-result v3

    if-eqz v3, :cond_6d

    iget v3, p1, LBb/b;->b:I

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    iget-boolean v4, p1, LBb/b;->a:Z

    invoke-static {v4, v2}, LS3/x;->sendPinCodeDialogTracking(ZLjava/lang/String;)V

    iget-boolean p1, p1, LBb/b;->a:Z

    const/4 v2, 0x1

    if-eqz p1, :cond_4e

    invoke-virtual {v0, v1}, Le4/c;->l(Z)V

    iget-object p1, v0, Le4/c;->S:Le4/c$g;

    if-eqz p1, :cond_70

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v1

    invoke-interface {p1, v3, v2, v1}, Le4/c$g;->pinCode(Ljava/lang/String;ZLandroid/os/Bundle;)V

    invoke-virtual {v0}, Le4/c;->j()V

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object p1

    instance-of v0, p1, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    if-eqz v0, :cond_70

    invoke-virtual {p1}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_70

    check-cast p1, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    invoke-virtual {p1}, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->reloadFragment()V

    goto :goto_70

    :cond_4e
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_56

    iput-object v3, v0, Le4/c;->T:Ljava/lang/String;

    :cond_56
    iget-object p1, v0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const v3, 0x7f1301ec

    invoke-virtual {p1, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Le4/c;->n(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Le4/c;->o(Z)V

    invoke-virtual {v0, v2}, Le4/c;->l(Z)V

    goto :goto_70

    :cond_6d
    invoke-static {v1, v2}, LS3/x;->sendPinCodeDialogTracking(ZLjava/lang/String;)V

    :cond_70
    :goto_70
    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, LBb/b;

    invoke-virtual {p0, p1}, Le4/d;->onSuccess(LBb/b;)V

    return-void
.end method
