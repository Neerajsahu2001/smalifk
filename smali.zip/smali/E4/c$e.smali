.class final Le4/c$e;
.super LFa/e;
.source "PinCodeDialogFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le4/c;->m()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LFa/e<",
        "Ldb/d;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Le4/c;


# direct methods
.method constructor <init>(Le4/c;)V
    .registers 2

    iput-object p1, p0, Le4/c$e;->a:Le4/c;

    invoke-direct {p0}, LFa/e;-><init>()V

    return-void
.end method


# virtual methods
.method public errorReceived(Lwa/a;)V
    .registers 4

    iget-object p1, p0, Le4/c$e;->a:Le4/c;

    iget-object v0, p1, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f1301f0

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Le4/c;->n(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Le4/c;->k(Z)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Le4/c;->l(Z)V

    return-void
.end method

.method public onSuccess(Ldb/d;)V
    .registers 5

    iget-object v0, p0, Le4/c$e;->a:Le4/c;

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_41

    if-eqz p1, :cond_41

    invoke-virtual {p1}, Ldb/d;->getParameterizedAddress()Ldb/b;

    move-result-object v1

    if-eqz v1, :cond_41

    invoke-virtual {p1}, Ldb/d;->getParameterizedAddress()Ldb/b;

    move-result-object v1

    invoke-virtual {v1}, Ldb/b;->getPincode()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_20

    goto :goto_41

    :cond_20
    invoke-virtual {v0, v2}, Le4/c;->k(Z)V

    invoke-virtual {p1}, Ldb/d;->getParameterizedAddress()Ldb/b;

    move-result-object p1

    invoke-virtual {p1}, Ldb/b;->getPincode()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v2}, Le4/c;->l(Z)V

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_36

    iput-object p1, v0, Le4/c;->T:Ljava/lang/String;

    :cond_36
    iget-object v1, v0, Le4/c;->P:Landroid/widget/EditText;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, v0, Le4/c;->X:Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/view/View;->performClick()Z

    return-void

    :cond_41
    :goto_41
    iget-object p1, v0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f1301f0

    invoke-virtual {p1, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Le4/c;->n(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Le4/c;->k(Z)V

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Le4/c;->l(Z)V

    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ldb/d;

    invoke-virtual {p0, p1}, Le4/c$e;->onSuccess(Ldb/d;)V

    return-void
.end method
