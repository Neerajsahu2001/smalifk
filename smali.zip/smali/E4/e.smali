.class final Le4/e;
.super LFa/e;
.source "PinCodeDialogFragment.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LFa/e<",
        "Lvb/a;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Le4/c;


# direct methods
.method constructor <init>(Le4/c;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    iput-object p1, p0, Le4/e;->b:Le4/c;

    iput-object p3, p0, Le4/e;->a:Ljava/lang/String;

    invoke-direct {p0}, LFa/e;-><init>()V

    return-void
.end method


# virtual methods
.method public errorReceived(Lwa/a;)V
    .registers 2

    iget-object p1, p0, Le4/e;->b:Le4/c;

    invoke-virtual {p1}, Le4/c;->j()V

    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lvb/a;

    invoke-virtual {p0, p1}, Le4/e;->onSuccess(Lvb/a;)V

    return-void
.end method

.method public onSuccess(Lvb/a;)V
    .registers 6

    iget-object v0, p0, Le4/e;->b:Le4/c;

    iget-object v1, v0, Le4/c;->S:Le4/c$g;

    if-eqz v1, :cond_3d

    const/4 v1, 0x0

    iput-boolean v1, v0, Le4/c;->W:Z

    if-eqz p1, :cond_17

    const/4 p1, 0x0

    invoke-static {p1}, Lcom/flipkart/android/utils/d1;->isNullOrEmpty(Ljava/util/Map;)Z

    move-result v2

    if-eqz v2, :cond_13

    goto :goto_17

    :cond_13
    invoke-virtual {v0, v1}, Le4/c;->l(Z)V

    throw p1

    :cond_17
    :goto_17
    const-string p1, "PincodeCheck"

    invoke-static {v1, p1}, LS3/x;->sendPinCodeDialogTracking(ZLjava/lang/String;)V

    iget-object p1, v0, Le4/c;->S:Le4/c$g;

    iget-object v2, p0, Le4/e;->a:Ljava/lang/String;

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v3

    invoke-interface {p1, v2, v1, v3}, Le4/c$g;->pinCode(Ljava/lang/String;ZLandroid/os/Bundle;)V

    invoke-virtual {v0}, Le4/c;->j()V

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object p1

    instance-of v0, p1, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    if-eqz v0, :cond_3d

    invoke-virtual {p1}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_3d

    check-cast p1, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    invoke-virtual {p1}, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->reloadFragment()V

    :cond_3d
    return-void
.end method
