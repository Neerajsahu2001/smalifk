.class public interface abstract Le4/c$g;
.super Ljava/lang/Object;
.source "PinCodeDialogFragment.java"

# interfaces
.implements Le4/c$f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract dispatch(LGe/b;Lcom/flipkart/android/newmultiwidget/a;)V
.end method

.method public abstract synthetic pinCode(Ljava/lang/String;ZLandroid/os/Bundle;)V
.end method

.method public abstract synthetic sendPermissionEvent(Lcom/flipkart/android/datagovernance/events/DGEvent;)V
.end method
