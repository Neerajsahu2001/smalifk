.class public final Le4/c;
.super Landroidx/fragment/app/b;
.source "PinCodeDialogFragment.java"

# interfaces
.implements Lcom/flipkart/android/permissions/d;
.implements Lcom/flipkart/android/newmultiwidget/u;
.implements Lcom/newrelic/agent/android/api/v2/TraceFieldInterface;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le4/c$g;,
        Le4/c$f;
    }
.end annotation


# static fields
.field private static H0:Z

.field private static I0:Z


# instance fields
.field A0:Z

.field B0:Ljava/lang/String;

.field C0:Ljava/lang/String;

.field D0:Z

.field private E0:Landroid/widget/RelativeLayout;

.field private F0:Landroid/widget/RelativeLayout;

.field private G0:Ljava/lang/String;

.field P:Landroid/widget/EditText;

.field Q:Lcom/google/android/material/textfield/TextInputLayout;

.field R:Landroid/widget/ImageButton;

.field S:Le4/c$g;

.field T:Ljava/lang/String;

.field W:Z

.field X:Landroid/widget/TextView;

.field Y:Landroid/widget/TextView;

.field Z:Landroid/widget/TextView;

.field z0:Landroid/widget/ImageView;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroidx/fragment/app/b;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Le4/c;->T:Ljava/lang/String;

    const/4 v0, 0x0

    iput-boolean v0, p0, Le4/c;->W:Z

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->isMultiCityEnabled()Z

    move-result v0

    iput-boolean v0, p0, Le4/c;->D0:Z

    return-void
.end method

.method public static a(Le4/c;)V
    .registers 11

    iget-object v0, p0, Le4/c;->P:Landroid/widget/EditText;

    if-eqz v0, :cond_ee

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/flipkart/android/utils/d1;->isValidIndianPin(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_d6

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, ";"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Le4/c;->C0:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ";;;;eVar93="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Le4/c;->B0:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const-string v3, "FLIPKART"

    if-eqz v2, :cond_2f

    move-object v2, v3

    goto :goto_31

    :cond_2f
    iget-object v2, p0, Le4/c;->B0:Ljava/lang/String;

    :goto_31
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, LS3/x;->sendPinCodeDialogCheck(Ljava/lang/String;Ljava/lang/String;)V

    iget-boolean v1, p0, Le4/c;->A0:Z

    if-eqz v1, :cond_92

    iget-boolean v1, p0, Le4/c;->D0:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_59

    iget-object v1, p0, Le4/c;->S:Le4/c$g;

    if-eqz v1, :cond_a2

    iget-object v3, p0, Le4/c;->B0:Ljava/lang/String;

    invoke-static {v0, v2, v3}, Le4/c;->getMapiPincodeServiceabilityAction(Ljava/lang/String;Landroid/location/Location;Ljava/lang/String;)LGe/b;

    move-result-object v3

    new-instance v4, Lcom/flipkart/android/newmultiwidget/a;

    sget-object v5, Lcom/flipkart/android/analytics/PageTypeUtils;->None:Lcom/flipkart/android/analytics/PageTypeUtils;

    invoke-direct {v4, v5, v2, v2, v2}, Lcom/flipkart/android/newmultiwidget/a;-><init>(Lcom/flipkart/android/analytics/PageTypeUtils;Lcom/flipkart/android/datagovernance/utils/WidgetInfo;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/datagovernance/ContextManager;)V

    invoke-interface {v1, v3, v4}, Le4/c$g;->dispatch(LGe/b;Lcom/flipkart/android/newmultiwidget/a;)V

    goto :goto_a2

    :cond_59
    iget-object v1, p0, Le4/c;->B0:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_62

    goto :goto_64

    :cond_62
    iget-object v3, p0, Le4/c;->B0:Ljava/lang/String;

    :goto_64
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getMAPIHttpService()LDa/b;

    move-result-object v1

    sget-boolean v4, Le4/c;->H0:Z

    if-eqz v4, :cond_7b

    new-instance v2, Lvb/g;

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6

    sget-boolean v9, Le4/c;->I0:Z

    const/4 v5, 0x0

    move-object v4, v2

    move-object v8, v3

    invoke-direct/range {v4 .. v9}, Lvb/g;-><init>(Ljava/lang/String;JLjava/lang/String;Z)V

    goto :goto_85

    :cond_7b
    new-instance v4, Lvb/g;

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    invoke-direct {v4, v2, v5, v6, v3}, Lvb/g;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    move-object v2, v4

    :goto_85
    invoke-interface {v1, v2}, LDa/b;->getMarketplaceServicabilityInfo(Lvb/g;)Lta/a;

    move-result-object v1

    new-instance v2, Le4/e;

    invoke-direct {v2, p0, v3, v0}, Le4/e;-><init>(Le4/c;Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v1, v2}, Lta/a;->enqueue(Lva/b;)V

    goto :goto_a2

    :cond_92
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getMAPIHttpService()LDa/b;

    move-result-object v1

    invoke-interface {v1, v0}, LDa/b;->validatePincode(Ljava/lang/String;)Lta/a;

    move-result-object v1

    new-instance v2, Le4/d;

    invoke-direct {v2, p0}, Le4/d;-><init>(Le4/c;)V

    invoke-interface {v1, v2}, Lta/a;->enqueue(Lva/b;)V

    :cond_a2
    :goto_a2
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/flipkart/android/config/d;->instance()Lcom/flipkart/android/config/d;

    move-result-object v2

    invoke-virtual {v2}, Lcom/flipkart/android/config/d;->getUserPinCode()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lcom/flipkart/android/datagovernance/events/productpage/PinCodeSet;

    const/4 v4, 0x1

    invoke-direct {v3, v1, v0, v2, v4}, Lcom/flipkart/android/datagovernance/events/productpage/PinCodeSet;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    instance-of v1, v0, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    if-eqz v1, :cond_d3

    check-cast v0, Lcom/flipkart/android/datagovernance/NavigationStateHolder;

    invoke-interface {v0}, Lcom/flipkart/android/datagovernance/NavigationStateHolder;->getNavigationState()Lcom/flipkart/android/datagovernance/GlobalContextInfo;

    move-result-object v0

    if-eqz v0, :cond_d3

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v1

    invoke-virtual {v0}, Lcom/flipkart/android/datagovernance/GlobalContextInfo;->getCurrentNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v0

    invoke-virtual {v1, v0, v3}, Lcom/flipkart/android/datagovernance/DGEventsController;->ingestEvent(Lcom/flipkart/android/datagovernance/NavigationContext;Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    :cond_d3
    iput-boolean v4, p0, Le4/c;->W:Z

    goto :goto_ee

    :cond_d6
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_de

    iput-object v0, p0, Le4/c;->T:Ljava/lang/String;

    :cond_de
    iget-object v0, p0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f1301ec

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Le4/c;->n(Ljava/lang/String;)V

    :cond_ee
    :goto_ee
    return-void
.end method

.method public static getMPServiceabilityAction(Ljava/lang/String;Landroid/location/Location;Ljava/lang/String;)Lcom/flipkart/mapi/model/component/data/renderables/b;
    .registers 10

    new-instance v0, Lcom/flipkart/mapi/model/component/data/renderables/b;

    invoke-direct {v0}, Lcom/flipkart/mapi/model/component/data/renderables/b;-><init>()V

    const-string v1, "MP_SERVICEABILITY"

    iput-object v1, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->b:Ljava/lang/String;

    if-eqz p1, :cond_22

    invoke-static {}, Lcom/flipkart/android/config/d;->instance()Lcom/flipkart/android/config/d;

    move-result-object v2

    invoke-virtual {v2}, Lcom/flipkart/android/config/d;->edit()Lcom/flipkart/android/config/d$b;

    move-result-object v2

    invoke-virtual {p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v3

    invoke-virtual {p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v5

    invoke-virtual {v2, v3, v4, v5, v6}, Lcom/flipkart/android/config/d$b;->saveUserLatLong(DD)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_22
    new-instance v2, Lrd/d;

    invoke-direct {v2}, Lrd/d;-><init>()V

    new-instance v3, Lmd/d;

    invoke-direct {v3}, Lmd/d;-><init>()V

    iput-object v1, v2, Lpd/d;->a:Ljava/lang/String;

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_37

    iput-object p0, v3, Lmd/d;->a:Ljava/lang/String;

    goto :goto_4c

    :cond_37
    if-eqz p1, :cond_4c

    new-instance p0, LPc/d;

    invoke-direct {p0}, LPc/d;-><init>()V

    invoke-virtual {p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v4

    iput-wide v4, p0, LPc/d;->a:D

    invoke-virtual {p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v4

    iput-wide v4, p0, LPc/d;->b:D

    iput-object p0, v3, Lmd/d;->c:LPc/d;

    :cond_4c
    :goto_4c
    iput-object v3, v2, Lrd/d;->c:Lmd/d;

    new-instance p0, Lgd/d;

    invoke-direct {p0}, Lgd/d;-><init>()V

    iput-object p0, v2, Lrd/d;->b:Lgd/d;

    iput-object p2, p0, Lgd/d;->a:Ljava/lang/String;

    sget-boolean p0, Le4/c;->H0:Z

    if-eqz p0, :cond_66

    new-instance p0, Lgd/b;

    invoke-direct {p0}, Lgd/b;-><init>()V

    iput-object p0, v2, Lrd/d;->d:Lgd/b;

    sget-boolean p1, Le4/c;->I0:Z

    iput-boolean p1, p0, Lgd/b;->a:Z

    :cond_66
    iget-object p0, v0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string p1, "actionRequestContext"

    invoke-interface {p0, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0
.end method

.method public static getMapiPincodeServiceabilityAction(Ljava/lang/String;Landroid/location/Location;Ljava/lang/String;)LGe/b;
    .registers 5

    invoke-static {p0, p1, p2}, Le4/c;->getMPServiceabilityAction(Ljava/lang/String;Landroid/location/Location;Ljava/lang/String;)Lcom/flipkart/mapi/model/component/data/renderables/b;

    move-result-object p0

    new-instance p1, LGe/b;

    invoke-direct {p1}, LGe/b;-><init>()V

    iget-object p2, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const-string v1, "killCurrentPage"

    invoke-interface {p2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    iput-object p2, p1, LGe/b;->f:Ljava/util/Map;

    iget-object p0, p0, Lcom/flipkart/mapi/model/component/data/renderables/b;->b:Ljava/lang/String;

    iput-object p0, p1, LGe/b;->b:Ljava/lang/String;

    const-string p0, "LOGIN_NOT_REQUIRED"

    iput-object p0, p1, LGe/b;->j:Ljava/lang/String;

    return-object p1
.end method

.method public static getMpServiceabilityActionContext(Ljava/util/Map;)Lrd/d;
    .registers 7

    new-instance v0, Lrd/d;

    invoke-direct {v0}, Lrd/d;-><init>()V

    new-instance v1, Lmd/d;

    invoke-direct {v1}, Lmd/d;-><init>()V

    const-string v2, "type"

    invoke-interface {p0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1c

    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lpd/d;->a:Ljava/lang/String;

    :cond_1c
    const-string v2, "locationContext"

    invoke-interface {p0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_82

    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    if-eqz v2, :cond_82

    const-string v3, "pincode"

    invoke-interface {v2, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3f

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lmd/d;->a:Ljava/lang/String;

    goto :goto_82

    :cond_3f
    const-string v3, "geoLocation"

    invoke-interface {v2, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_82

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    new-instance v3, LPc/d;

    invoke-direct {v3}, LPc/d;-><init>()V

    if-eqz v2, :cond_80

    const-string v4, "latitude"

    invoke-interface {v2, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6a

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v4

    iput-wide v4, v3, LPc/d;->a:D

    :cond_6a
    const-string v4, "longitude"

    invoke-interface {v2, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_80

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v4

    iput-wide v4, v3, LPc/d;->b:D

    :cond_80
    iput-object v3, v1, Lmd/d;->c:LPc/d;

    :cond_82
    :goto_82
    iput-object v1, v0, Lrd/d;->c:Lmd/d;

    new-instance v1, Lgd/d;

    invoke-direct {v1}, Lgd/d;-><init>()V

    iput-object v1, v0, Lrd/d;->b:Lgd/d;

    const-string v1, "marketplaceContext"

    invoke-interface {p0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_a7

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    iget-object v2, v0, Lrd/d;->b:Lgd/d;

    const-string v3, "marketplace"

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v2, Lgd/d;->a:Ljava/lang/String;

    :cond_a7
    sget-boolean v1, Le4/c;->H0:Z

    if-eqz v1, :cond_d0

    new-instance v1, Lgd/b;

    invoke-direct {v1}, Lgd/b;-><init>()V

    iput-object v1, v0, Lrd/d;->d:Lgd/b;

    const-string v1, "groupBuyRequestContext"

    invoke-interface {p0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d0

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    iget-object v1, v0, Lrd/d;->d:Lgd/b;

    const-string v2, "gbFlow"

    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    iput-boolean p0, v1, Lgd/b;->a:Z

    :cond_d0
    return-object v0
.end method

.method public static newInstance()Le4/c;
    .registers 1

    const/4 v0, 0x0

    invoke-static {v0}, Le4/c;->newInstance(Ljava/util/Map;)Le4/c;

    move-result-object v0

    return-object v0
.end method

.method public static newInstance(Ljava/util/Map;)Le4/c;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)",
            "Le4/c;"
        }
    .end annotation

    new-instance v0, Le4/c;

    invoke-direct {v0}, Le4/c;-><init>()V

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const-string v2, "TAG"

    const-string v3, "PinCodeDialogFragment"

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    if-eqz p0, :cond_7a

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1e
    :goto_1e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_7a

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Ljava/lang/String;

    if-eqz v4, :cond_3e

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1e

    :cond_3e
    instance-of v4, v3, Ljava/lang/Long;

    if-eqz v4, :cond_52

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    goto :goto_1e

    :cond_52
    instance-of v4, v3, Ljava/lang/Double;

    if-eqz v4, :cond_66

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    check-cast v3, Ljava/lang/Double;

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V

    goto :goto_1e

    :cond_66
    instance-of v4, v3, Ljava/lang/Boolean;

    if-eqz v4, :cond_1e

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    goto :goto_1e

    :cond_7a
    return-object v0
.end method


# virtual methods
.method public actionTaken(II)V
    .registers 4

    const/4 v0, 0x1

    if-ne p2, v0, :cond_a

    const/4 p2, 0x4

    if-eq p1, p2, :cond_7

    goto :goto_a

    :cond_7
    invoke-virtual {p0}, Le4/c;->m()V

    :cond_a
    :goto_a
    return-void
.end method

.method public dismissDialog()V
    .registers 1

    invoke-virtual {p0}, Le4/c;->j()V

    return-void
.end method

.method public getDefaultViewModelCreationExtras()LW/a;
    .registers 2

    sget-object v0, LW/a$a;->b:LW/a$a;

    return-object v0
.end method

.method public isPermissionAskedCountExceeded(I)Z
    .registers 3

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getFineOverCoarsePermissionCount()I

    move-result v0

    if-lt p1, v0, :cond_c

    const/4 p1, 0x1

    goto :goto_d

    :cond_c
    const/4 p1, 0x0

    :goto_d
    return p1
.end method

.method final j()V
    .registers 5

    invoke-virtual {p0}, Landroidx/fragment/app/b;->getDialog()Landroid/app/Dialog;

    move-result-object v0

    if-eqz v0, :cond_39

    invoke-virtual {v0}, Landroid/app/Dialog;->getCurrentFocus()Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_36

    iget-boolean v2, p0, Le4/c;->W:Z

    if-nez v2, :cond_36

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v2, "input_method"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    if-eqz v0, :cond_26

    invoke-virtual {v1}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    :cond_26
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Le4/c$d;

    invoke-direct {v1, p0}, Le4/c$d;-><init>(Le4/c;)V

    const-wide/16 v2, 0x1f4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_39

    :cond_36
    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_39
    :goto_39
    return-void
.end method

.method final k(Z)V
    .registers 6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Le4/c;->Y:Landroid/widget/TextView;

    if-eqz v1, :cond_2d

    if-eqz v0, :cond_2d

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setEnabled(Z)V

    iget-object v1, p0, Le4/c;->Y:Landroid/widget/TextView;

    if-eqz p1, :cond_15

    const v2, 0x7f06016c

    goto :goto_18

    :cond_15
    const v2, 0x7f06016b

    :goto_18
    invoke-static {v0, v2}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Le4/c;->z0:Landroid/widget/ImageView;

    if-eqz p1, :cond_27

    const v1, 0x7f0802a1

    goto :goto_2a

    :cond_27
    const v1, 0x7f0802a0

    :goto_2a
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_2d
    iget-object v0, p0, Le4/c;->E0:Landroid/widget/RelativeLayout;

    const/4 v1, 0x0

    const/16 v2, 0x8

    if-eqz p1, :cond_37

    const/16 v3, 0x8

    goto :goto_38

    :cond_37
    const/4 v3, 0x0

    :goto_38
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Le4/c;->F0:Landroid/widget/RelativeLayout;

    if-eqz p1, :cond_40

    goto :goto_42

    :cond_40
    const/16 v1, 0x8

    :goto_42
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method final l(Z)V
    .registers 3

    iget-object v0, p0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    if-eqz v0, :cond_7

    invoke-virtual {v0, p1}, Lcom/google/android/material/textfield/TextInputLayout;->p(Z)V

    :cond_7
    return-void
.end method

.method final m()V
    .registers 6

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Le4/c;->k(Z)V

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v1

    new-instance v2, Landroid/content/Intent;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lcom/flipkart/android/services/LocationService;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v1, v2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/flipkart/android/utils/o0;->getBestLastKnownLocation(Landroid/content/Context;Z)Landroid/location/Location;

    move-result-object v0

    if-eqz v0, :cond_64

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "location : getLatitude : "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/location/Location;->getLatitude()D

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string v2, "  longitude : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroid/location/Location;->getLongitude()D

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "PinCodeDialogFragment"

    invoke-static {v2, v1}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getMAPIHttpService()LDa/b;

    move-result-object v1

    invoke-virtual {v0}, Landroid/location/Location;->getLatitude()D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    invoke-virtual {v0}, Landroid/location/Location;->getLongitude()D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    invoke-interface {v1, v2, v0}, LDa/b;->getPincodeUsingLocation(Ljava/lang/Double;Ljava/lang/Double;)Lta/a;

    move-result-object v0

    new-instance v1, Le4/c$e;

    invoke-direct {v1, p0}, Le4/c$e;-><init>(Le4/c;)V

    invoke-interface {v0, v1}, Lta/a;->enqueue(Lva/b;)V

    goto :goto_86

    :cond_64
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/flipkart/android/utils/o0;->isGPSEnabled(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_72

    const v0, 0x7f1301f0

    goto :goto_75

    :cond_72
    const v0, 0x7f1301dd

    :goto_75
    iget-object v1, p0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Le4/c;->n(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Le4/c;->k(Z)V

    :goto_86
    return-void
.end method

.method final n(Ljava/lang/String;)V
    .registers 3

    iget-object v0, p0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    if-eqz v0, :cond_20

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1a

    iget-object v0, p0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {v0, p1}, Lcom/google/android/material/textfield/TextInputLayout;->o(Ljava/lang/CharSequence;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Le4/c;->l(Z)V

    goto :goto_20

    :cond_1a
    iget-object p1, p0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/TextInputLayout;->p(Z)V

    :cond_20
    :goto_20
    return-void
.end method

.method final o(Z)V
    .registers 4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Le4/c;->X:Landroid/widget/TextView;

    if-eqz v1, :cond_1f

    if-eqz v0, :cond_1f

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setEnabled(Z)V

    iget-object v1, p0, Le4/c;->X:Landroid/widget/TextView;

    if-eqz p1, :cond_15

    const p1, 0x7f06016c

    goto :goto_18

    :cond_15
    const p1, 0x7f06016b

    :goto_18
    invoke-static {v0, p1}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_1f
    return-void
.end method

.method public onAttach(Landroid/content/Context;)V
    .registers 4

    invoke-super {p0, p1}, Landroidx/fragment/app/b;->onAttach(Landroid/content/Context;)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "onAttach :   PinCodeDialogCallback "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Le4/c;->S:Le4/c$g;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "PinCodeDialogFragment"

    invoke-static {v1, v0}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object v0

    instance-of v0, v0, Le4/c$g;

    if-eqz v0, :cond_29

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object p1

    check-cast p1, Le4/c$g;

    iput-object p1, p0, Le4/c;->S:Le4/c$g;

    goto :goto_31

    :cond_29
    instance-of v0, p1, Le4/c$g;

    if-eqz v0, :cond_31

    check-cast p1, Le4/c$g;

    iput-object p1, p0, Le4/c;->S:Le4/c$g;

    :cond_31
    :goto_31
    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 7

    const-string p2, "PinCodeDialogFragment#onCreateView"

    const/4 p3, 0x0

    :catch_3
    :try_start_3
    invoke-static {p3, p2, p3}, Lcom/newrelic/agent/android/tracing/TraceMachine;->enterMethod(Lcom/newrelic/agent/android/tracing/Trace;Ljava/lang/String;Ljava/util/ArrayList;)V
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_6} :catch_3

    invoke-virtual {p0}, Landroidx/fragment/app/b;->getDialog()Landroid/app/Dialog;

    move-result-object p2

    const/4 v0, 0x1

    if-eqz p2, :cond_18

    invoke-virtual {p2, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    invoke-virtual {p2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p2

    const/4 v1, 0x5

    invoke-virtual {p2, v1}, Landroid/view/Window;->setSoftInputMode(I)V

    :cond_18
    const p2, 0x7f0e01c9

    const/4 v1, 0x0

    invoke-virtual {p1, p2, p3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p2

    if-eqz p2, :cond_65

    const-string p3, "CALL_MARKETPLACE_API"

    invoke-virtual {p2, p3}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v2

    iput-boolean v2, p0, Le4/c;->A0:Z

    invoke-virtual {p2, p3}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const-string p3, "SUB_TEXT"

    invoke-virtual {p2, p3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Le4/c;->G0:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const-string p3, "MARKETPLACE_ID"

    invoke-virtual {p2, p3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Le4/c;->B0:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const-string p3, "PAGE_NAME"

    invoke-virtual {p2, p3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    iput-object p3, p0, Le4/c;->C0:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const-string p3, "gbFlow"

    invoke-virtual {p2, p3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_63

    sput-boolean v0, Le4/c;->H0:Z

    invoke-virtual {p2, p3}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p2

    sput-boolean p2, Le4/c;->I0:Z

    goto :goto_65

    :cond_63
    sput-boolean v1, Le4/c;->H0:Z

    :cond_65
    :goto_65
    const p2, 0x7f0b04e0

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/RelativeLayout;

    iput-object p2, p0, Le4/c;->E0:Landroid/widget/RelativeLayout;

    const p2, 0x7f0b0414

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/RelativeLayout;

    iput-object p2, p0, Le4/c;->F0:Landroid/widget/RelativeLayout;

    const p2, 0x7f0b04e3

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/EditText;

    iput-object p2, p0, Le4/c;->P:Landroid/widget/EditText;

    const p2, 0x7f0b04e2

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageButton;

    iput-object p2, p0, Le4/c;->R:Landroid/widget/ImageButton;

    const p2, 0x7f0b04e8

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iput-object p2, p0, Le4/c;->X:Landroid/widget/TextView;

    const p2, 0x7f0b04e1

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iput-object p2, p0, Le4/c;->Z:Landroid/widget/TextView;

    const p2, 0x7f0b07f0

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iput-object p2, p0, Le4/c;->Y:Landroid/widget/TextView;

    const p2, 0x7f0b0325

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    iput-object p2, p0, Le4/c;->z0:Landroid/widget/ImageView;

    const p3, 0x7f0802a1

    invoke-virtual {p2, p3}, Landroid/widget/ImageView;->setImageResource(I)V

    const p2, 0x7f0b0705

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/google/android/material/textfield/TextInputLayout;

    iput-object p2, p0, Le4/c;->Q:Lcom/google/android/material/textfield/TextInputLayout;

    const p2, 0x7f0b04e9

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iget-object p3, p0, Le4/c;->G0:Ljava/lang/String;

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    if-nez p3, :cond_e8

    iget-object p3, p0, Le4/c;->G0:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p2, v1}, Landroid/view/View;->setVisibility(I)V

    goto :goto_ed

    :cond_e8
    const/16 p3, 0x8

    invoke-virtual {p2, p3}, Landroid/view/View;->setVisibility(I)V

    :goto_ed
    iget-object p2, p0, Le4/c;->P:Landroid/widget/EditText;

    new-instance p3, Le4/c$a;

    invoke-direct {p3, p0}, Le4/c$a;-><init>(Le4/c;)V

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p2

    if-eqz p2, :cond_10a

    iget-object p3, p0, Le4/c;->P:Landroid/widget/EditText;

    const-string v0, "PINCODE"

    const-string v2, ""

    invoke-virtual {p2, v0, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, p2}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    :cond_10a
    iget-object p2, p0, Le4/c;->Z:Landroid/widget/TextView;

    new-instance p3, Le4/a;

    invoke-direct {p3, p0, v1}, Le4/a;-><init>(Landroidx/fragment/app/b;I)V

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p2, p0, Le4/c;->X:Landroid/widget/TextView;

    new-instance p3, Le4/b;

    invoke-direct {p3, v1, p0}, Le4/b;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p2, p0, Le4/c;->R:Landroid/widget/ImageButton;

    new-instance p3, Le4/c$b;

    invoke-direct {p3, p0}, Le4/c$b;-><init>(Le4/c;)V

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p2, p0, Le4/c;->Y:Landroid/widget/TextView;

    new-instance p3, Le4/c$c;

    invoke-direct {p3, p0}, Le4/c$c;-><init>(Le4/c;)V

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0, v1}, Le4/c;->l(Z)V

    invoke-static {}, Lcom/newrelic/agent/android/tracing/TraceMachine;->exitMethod()V

    return-object p1
.end method

.method public showErrorMessage(Ljava/lang/String;)V
    .registers 2

    invoke-virtual {p0, p1}, Le4/c;->n(Ljava/lang/String;)V

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Le4/c;->o(Z)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Le4/c;->l(Z)V

    return-void
.end method

.method public trackPermissionStatus(Lcom/flipkart/android/datagovernance/events/DGEvent;)V
    .registers 3

    iget-object v0, p0, Le4/c;->S:Le4/c$g;

    if-eqz v0, :cond_7

    invoke-interface {v0, p1}, Le4/c$g;->sendPermissionEvent(Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    :cond_7
    return-void
.end method
