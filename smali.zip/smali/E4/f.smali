.class public interface abstract Le4/f;
.super Ljava/lang/Object;
.source "ProductErrorListener.java"


# virtual methods
.method public abstract onErrorOccurred(Ljava/lang/Exception;Lwa/a;)V
.end method
