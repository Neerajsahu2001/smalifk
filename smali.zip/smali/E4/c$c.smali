.class final Le4/c$c;
.super Ljava/lang/Object;
.source "PinCodeDialogFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le4/c;->onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Le4/c;


# direct methods
.method constructor <init>(Le4/c;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le4/c$c;->a:Le4/c;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 8

    iget-object p1, p0, Le4/c$c;->a:Le4/c;

    iget-object v0, p1, Le4/c;->P:Landroid/widget/EditText;

    if-eqz v0, :cond_f

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Le4/c;->l(Z)V

    :cond_f
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v0

    sget-object v1, Lcom/flipkart/android/permissions/PermissionType;->ACCESS_COARSE_LOCATION:Lcom/flipkart/android/permissions/PermissionType;

    invoke-static {v0, v1}, Lcom/flipkart/android/permissions/e;->hasPermission(Landroid/content/Context;Lcom/flipkart/android/permissions/PermissionType;)Z

    move-result v0

    if-eqz v0, :cond_37

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getInstance()Lcom/flipkart/android/init/FlipkartApplication;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/init/FlipkartApplication;->isLocationPermissionAskedOnce()Z

    move-result v0

    if-nez v0, :cond_33

    invoke-static {}, Lcom/flipkart/android/config/d;->instance()Lcom/flipkart/android/config/d;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/d;->getFineOverCoarsePermissionAskedCount()I

    move-result v0

    invoke-virtual {p1, v0}, Le4/c;->isPermissionAskedCountExceeded(I)Z

    move-result v0

    if-eqz v0, :cond_37

    :cond_33
    invoke-virtual {p1}, Le4/c;->m()V

    return-void

    :cond_37
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v0

    sget-object v1, Lcom/flipkart/android/permissions/PermissionGroupType;->ACCESS_LOCATION:Lcom/flipkart/android/permissions/PermissionGroupType;

    invoke-static {v0, v1}, Lcom/flipkart/android/permissions/e;->hasPermissionGroup(Landroid/content/Context;Lcom/flipkart/android/permissions/PermissionGroupType;)Z

    move-result v0

    if-nez v0, :cond_a3

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v0

    if-eqz v0, :cond_a6

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v0

    invoke-static {v0, v1}, Lcom/flipkart/android/permissions/e;->hasPermissionGroup(Landroid/content/Context;Lcom/flipkart/android/permissions/PermissionGroupType;)Z

    move-result v0

    if-nez v0, :cond_a6

    new-instance v0, Lcom/flipkart/android/permissions/g$b;

    const-string v2, "location"

    const/4 v3, 0x1

    invoke-direct {v0, v1, v2, v3}, Lcom/flipkart/android/permissions/g$b;-><init>(Lcom/flipkart/android/permissions/PermissionGroupType;Ljava/lang/String;I)V

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v1

    const v2, 0x7f130064

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/flipkart/android/permissions/g$b;->setTitle(Ljava/lang/String;)Lcom/flipkart/android/permissions/g$b;

    move-result-object v1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v4

    const v5, 0x7f130062

    invoke-virtual {v4, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Lcom/flipkart/android/permissions/g$b;->setDescription(Ljava/lang/String;)Lcom/flipkart/android/permissions/g$b;

    move-result-object v1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/flipkart/android/permissions/g$b;->setGoToSettingsTitle(Ljava/lang/String;)Lcom/flipkart/android/permissions/g$b;

    move-result-object v1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object v2

    const v4, 0x7f130063

    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/flipkart/android/permissions/g$b;->setGoToSettingsDescription(Ljava/lang/String;)Lcom/flipkart/android/permissions/g$b;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/flipkart/android/permissions/g$b;->setPermissionDialogType(I)Lcom/flipkart/android/permissions/g$b;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/flipkart/android/permissions/g$b;->setLocationPermissionFromRN(Z)Lcom/flipkart/android/permissions/g$b;

    invoke-virtual {v0, p1}, Lcom/flipkart/android/permissions/g$b;->setFragment(Landroidx/fragment/app/Fragment;)Lcom/flipkart/android/permissions/g$b;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/permissions/g$b;->show()V

    goto :goto_a6

    :cond_a3
    invoke-virtual {p1}, Le4/c;->m()V

    :cond_a6
    :goto_a6
    return-void
.end method
