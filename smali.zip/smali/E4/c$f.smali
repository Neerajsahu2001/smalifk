.class public interface abstract Le4/c$f;
.super Ljava/lang/Object;
.source "PinCodeDialogFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "f"
.end annotation


# virtual methods
.method public abstract pinCode(Ljava/lang/String;ZLandroid/os/Bundle;)V
.end method

.method public abstract sendPermissionEvent(Lcom/flipkart/android/datagovernance/events/DGEvent;)V
.end method
