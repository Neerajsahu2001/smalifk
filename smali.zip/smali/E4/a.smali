.class public final synthetic Le4/a;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroidx/fragment/app/b;


# direct methods
.method public synthetic constructor <init>(Landroidx/fragment/app/b;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Le4/a;->a:I

    iput-object p1, p0, Le4/a;->b:Landroidx/fragment/app/b;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget p1, p0, Le4/a;->a:I

    iget-object v0, p0, Le4/a;->b:Landroidx/fragment/app/b;

    packed-switch p1, :pswitch_data_14

    check-cast v0, Lcom/flipkart/android/fragments/n0;

    invoke-static {v0}, Lcom/flipkart/android/fragments/n0;->d(Lcom/flipkart/android/fragments/n0;)V

    return-void

    :pswitch_d
    check-cast v0, Le4/c;

    invoke-virtual {v0}, Landroidx/fragment/app/b;->dismiss()V

    return-void

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_d
    .end packed-switch
.end method
