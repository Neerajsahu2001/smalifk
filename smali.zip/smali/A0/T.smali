.class public final synthetic La0/t;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p3, p0, La0/t;->a:I

    iput-object p1, p0, La0/t;->b:Ljava/lang/Object;

    iput-object p2, p0, La0/t;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget v0, p0, La0/t;->a:I

    iget-object v1, p0, La0/t;->c:Ljava/lang/Object;

    iget-object v2, p0, La0/t;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_50

    check-cast v2, La8/d;

    check-cast v1, La8/e;

    invoke-static {v2, v1}, La8/d;->c(La8/d;La8/e;)V

    return-void

    :pswitch_11
    check-cast v2, Lcom/flipkart/android/reactnative/nativemodules/MultiVerseModule;

    check-cast v1, Ljava/lang/String;

    invoke-static {v2, v1}, Lcom/flipkart/android/reactnative/nativemodules/MultiVerseModule;->e(Lcom/flipkart/android/reactnative/nativemodules/MultiVerseModule;Ljava/lang/String;)V

    return-void

    :pswitch_19
    check-cast v2, Lcom/flipkart/android/navigation/multistack/f;

    check-cast v1, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    sget-object v0, Lcom/flipkart/android/navigation/f;->a:Lcom/flipkart/android/navigation/f;

    const-string v0, "$activity"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "null cannot be cast to non-null type androidx.fragment.app.Fragment"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Landroidx/fragment/app/d;->getSupportFragmentManager()Landroidx/fragment/app/o;

    move-result-object v0

    invoke-static {v2, v1, v0}, Lcom/flipkart/android/utils/j;->canFragmentNavigate(Landroidx/fragment/app/Fragment;Landroid/app/Activity;Landroidx/fragment/app/o;)Z

    move-result v0

    if-eqz v0, :cond_36

    invoke-virtual {v2}, Lcom/flipkart/android/navigation/multistack/f;->clearBackStack()V

    :cond_36
    return-void

    :pswitch_37
    check-cast v2, Lk0/n$a;

    check-cast v1, Lk0/n;

    iget v0, v2, Lk0/n$a;->a:I

    iget-object v2, v2, Lk0/n$a;->b:Landroidx/media3/exoplayer/source/o$b;

    invoke-interface {v1, v0, v2}, Lk0/n;->J(ILandroidx/media3/exoplayer/source/o$b;)V

    return-void

    :pswitch_43
    check-cast v2, La0/z;

    check-cast v1, La0/z$a;

    invoke-virtual {v2}, La0/z;->c()I

    move-result v0

    invoke-interface {v1, v0}, La0/z$a;->a(I)V

    return-void

    nop

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_43
        :pswitch_37
        :pswitch_19
        :pswitch_11
    .end packed-switch
.end method
