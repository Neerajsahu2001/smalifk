.class public final La0/r;
.super Ljava/lang/Object;
.source "LongArrayQueue.java"


# instance fields
.field private a:I

.field private b:I

.field private c:[J

.field private d:I


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x10

    invoke-static {v0}, Ljava/lang/Integer;->bitCount(I)I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_13

    const/16 v0, 0xf

    invoke-static {v0}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v0

    shl-int/2addr v0, v2

    :cond_13
    const/4 v1, 0x0

    iput v1, p0, La0/r;->a:I

    iput v1, p0, La0/r;->b:I

    new-array v1, v0, [J

    iput-object v1, p0, La0/r;->c:[J

    sub-int/2addr v0, v2

    iput v0, p0, La0/r;->d:I

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, La0/r;->a:I

    iput v0, p0, La0/r;->b:I

    return-void
.end method

.method public final b()J
    .registers 4

    iget v0, p0, La0/r;->b:I

    if-eqz v0, :cond_b

    iget-object v0, p0, La0/r;->c:[J

    iget v1, p0, La0/r;->a:I

    aget-wide v1, v0, v1

    return-wide v1

    :cond_b
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final c()Z
    .registers 2

    iget v0, p0, La0/r;->b:I

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public final d()J
    .registers 6

    iget v0, p0, La0/r;->b:I

    if-eqz v0, :cond_16

    iget v1, p0, La0/r;->a:I

    iget-object v2, p0, La0/r;->c:[J

    aget-wide v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    iget v2, p0, La0/r;->d:I

    and-int/2addr v1, v2

    iput v1, p0, La0/r;->a:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La0/r;->b:I

    return-wide v3

    :cond_16
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method
