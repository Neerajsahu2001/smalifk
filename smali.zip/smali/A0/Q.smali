.class public final La0/q;
.super Ljava/lang/Object;
.source "LongArray.java"


# instance fields
.field private a:I

.field private b:[J


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x20

    new-array v0, v0, [J

    iput-object v0, p0, La0/q;->b:[J

    return-void
.end method


# virtual methods
.method public final a(J)V
    .registers 6

    iget v0, p0, La0/q;->a:I

    iget-object v1, p0, La0/q;->b:[J

    array-length v2, v1

    if-ne v0, v2, :cond_f

    mul-int/lit8 v0, v0, 0x2

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    iput-object v0, p0, La0/q;->b:[J

    :cond_f
    iget-object v0, p0, La0/q;->b:[J

    iget v1, p0, La0/q;->a:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, La0/q;->a:I

    aput-wide p1, v0, v1

    return-void
.end method

.method public final b(I)J
    .registers 5

    if-ltz p1, :cond_b

    iget v0, p0, La0/q;->a:I

    if-ge p1, v0, :cond_b

    iget-object v0, p0, La0/q;->b:[J

    aget-wide v1, v0, p1

    return-wide v1

    :cond_b
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const-string v1, "Invalid index "

    const-string v2, ", size is "

    invoke-static {v1, p1, v2}, Landroidx/exifinterface/media/a;->c(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget v1, p0, La0/q;->a:I

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c()I
    .registers 2

    iget v0, p0, La0/q;->a:I

    return v0
.end method
