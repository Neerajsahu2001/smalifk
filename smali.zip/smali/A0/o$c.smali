.class final La0/o$c;
.super Ljava/lang/Object;
.source "ListenerSet.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field private b:Landroidx/media3/common/l$a;

.field private c:Z

.field private d:Z


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/o$c;->a:Ljava/lang/Object;

    new-instance p1, Landroidx/media3/common/l$a;

    invoke-direct {p1}, Landroidx/media3/common/l$a;-><init>()V

    iput-object p1, p0, La0/o$c;->b:Landroidx/media3/common/l$a;

    return-void
.end method


# virtual methods
.method public final a(ILa0/o$a;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "La0/o$a<",
            "TT;>;)V"
        }
    .end annotation

    iget-boolean v0, p0, La0/o$c;->d:Z

    if-nez v0, :cond_14

    const/4 v0, -0x1

    if-eq p1, v0, :cond_c

    iget-object v0, p0, La0/o$c;->b:Landroidx/media3/common/l$a;

    invoke-virtual {v0, p1}, Landroidx/media3/common/l$a;->a(I)V

    :cond_c
    const/4 p1, 0x1

    iput-boolean p1, p0, La0/o$c;->c:Z

    iget-object p1, p0, La0/o$c;->a:Ljava/lang/Object;

    invoke-interface {p2, p1}, La0/o$a;->invoke(Ljava/lang/Object;)V

    :cond_14
    return-void
.end method

.method public final b(La0/o$b;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/o$b<",
            "TT;>;)V"
        }
    .end annotation

    iget-boolean v0, p0, La0/o$c;->d:Z

    if-nez v0, :cond_1d

    iget-boolean v0, p0, La0/o$c;->c:Z

    if-eqz v0, :cond_1d

    iget-object v0, p0, La0/o$c;->b:Landroidx/media3/common/l$a;

    invoke-virtual {v0}, Landroidx/media3/common/l$a;->b()Landroidx/media3/common/l;

    move-result-object v0

    new-instance v1, Landroidx/media3/common/l$a;

    invoke-direct {v1}, Landroidx/media3/common/l$a;-><init>()V

    iput-object v1, p0, La0/o$c;->b:Landroidx/media3/common/l$a;

    const/4 v1, 0x0

    iput-boolean v1, p0, La0/o$c;->c:Z

    iget-object v1, p0, La0/o$c;->a:Ljava/lang/Object;

    invoke-interface {p1, v1, v0}, La0/o$b;->b(Ljava/lang/Object;Landroidx/media3/common/l;)V

    :cond_1d
    return-void
.end method

.method public final c(La0/o$b;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/o$b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x1

    iput-boolean v0, p0, La0/o$c;->d:Z

    iget-boolean v0, p0, La0/o$c;->c:Z

    if-eqz v0, :cond_15

    const/4 v0, 0x0

    iput-boolean v0, p0, La0/o$c;->c:Z

    iget-object v0, p0, La0/o$c;->b:Landroidx/media3/common/l$a;

    invoke-virtual {v0}, Landroidx/media3/common/l$a;->b()Landroidx/media3/common/l;

    move-result-object v0

    iget-object v1, p0, La0/o$c;->a:Ljava/lang/Object;

    invoke-interface {p1, v1, v0}, La0/o$b;->b(Ljava/lang/Object;Landroidx/media3/common/l;)V

    :cond_15
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    if-eqz p1, :cond_1a

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-class v1, La0/o$c;

    if-eq v1, v0, :cond_f

    goto :goto_1a

    :cond_f
    check-cast p1, La0/o$c;

    iget-object p1, p1, La0/o$c;->a:Ljava/lang/Object;

    iget-object v0, p0, La0/o$c;->a:Ljava/lang/Object;

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_1a
    :goto_1a
    const/4 p1, 0x0

    return p1
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, La0/o$c;->a:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
