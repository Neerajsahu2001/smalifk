.class final La0/z$b;
.super Landroid/content/BroadcastReceiver;
.source "NetworkTypeObserver.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "b"
.end annotation


# instance fields
.field final synthetic a:La0/z;


# direct methods
.method constructor <init>(La0/z;)V
    .registers 2

    iput-object p1, p0, La0/z$b;->a:La0/z;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 11

    const-string p2, "connectivity"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/net/ConnectivityManager;

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-nez p2, :cond_d

    goto :goto_53

    :cond_d
    :try_start_d
    invoke-virtual {p2}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p2
    :try_end_11
    .catch Ljava/lang/SecurityException; {:try_start_d .. :try_end_11} :catch_52

    const/4 v2, 0x1

    if-eqz p2, :cond_50

    invoke-virtual {p2}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v3

    if-nez v3, :cond_1b

    goto :goto_50

    :cond_1b
    invoke-virtual {p2}, Landroid/net/NetworkInfo;->getType()I

    move-result v3

    const/4 v4, 0x2

    const/16 v5, 0x9

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v3, :cond_39

    if-eq v3, v2, :cond_37

    if-eq v3, v7, :cond_39

    if-eq v3, v0, :cond_39

    if-eq v3, v6, :cond_35

    if-eq v3, v5, :cond_33

    const/16 v1, 0x8

    goto :goto_53

    :cond_33
    const/4 v1, 0x7

    goto :goto_53

    :cond_35
    :pswitch_35
    const/4 v1, 0x5

    goto :goto_53

    :cond_37
    :pswitch_37
    const/4 v1, 0x2

    goto :goto_53

    :cond_39
    invoke-virtual {p2}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result p2

    packed-switch p2, :pswitch_data_80

    :pswitch_40
    const/4 v1, 0x6

    goto :goto_53

    :pswitch_42
    sget p2, La0/T;->a:I

    const/16 v2, 0x1d

    if-lt p2, v2, :cond_53

    const/16 v1, 0x9

    goto :goto_53

    :pswitch_4b
    const/4 v1, 0x4

    goto :goto_53

    :pswitch_4d
    const/4 p2, 0x3

    const/4 v1, 0x3

    goto :goto_53

    :cond_50
    :goto_50
    const/4 v1, 0x1

    goto :goto_53

    :catch_52
    nop

    :cond_53
    :goto_53
    sget p2, La0/T;->a:I

    const/16 v2, 0x1f

    iget-object v3, p0, La0/z$b;->a:La0/z;

    if-lt p2, v2, :cond_7c

    if-ne v1, v0, :cond_7c

    :try_start_5d
    const-string p2, "phone"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/telephony/TelephonyManager;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, La0/y;

    invoke-direct {v1, v3}, La0/y;-><init>(La0/z;)V

    invoke-static {p1}, La0/u;->a(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object p1

    invoke-static {p2, p1, v1}, La0/v;->d(Landroid/telephony/TelephonyManager;Ljava/util/concurrent/Executor;Landroid/telephony/TelephonyCallback;)V

    invoke-static {p2, v1}, La0/w;->c(Landroid/telephony/TelephonyManager;Landroid/telephony/TelephonyCallback;)V
    :try_end_77
    .catch Ljava/lang/RuntimeException; {:try_start_5d .. :try_end_77} :catch_78

    goto :goto_7f

    :catch_78
    invoke-static {v3, v0}, La0/z;->a(La0/z;I)V

    goto :goto_7f

    :cond_7c
    invoke-static {v3, v1}, La0/z;->a(La0/z;I)V

    :goto_7f
    return-void

    :pswitch_data_80
    .packed-switch 0x1
        :pswitch_4d
        :pswitch_4d
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_4b
        :pswitch_35
        :pswitch_4b
        :pswitch_4b
        :pswitch_40
        :pswitch_4b
        :pswitch_37
        :pswitch_40
        :pswitch_42
    .end packed-switch
.end method
