.class public final La0/o;
.super Ljava/lang/Object;
.source "ListenerSet.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La0/o$b;,
        La0/o$c;,
        La0/o$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private final a:La0/b;

.field private final b:La0/l;

.field private final c:La0/o$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/o$b<",
            "TT;>;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/concurrent/CopyOnWriteArraySet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArraySet<",
            "La0/o$c<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field private final e:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Ljava/lang/Runnable;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Ljava/lang/Runnable;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Ljava/lang/Object;

.field private h:Z

.field private i:Z


# direct methods
.method public constructor <init>(Landroid/os/Looper;La0/b;La0/o$b;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Looper;",
            "La0/b;",
            "La0/o$b<",
            "TT;>;)V"
        }
    .end annotation

    new-instance v1, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    const/4 v5, 0x1

    move-object v0, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    invoke-direct/range {v0 .. v5}, La0/o;-><init>(Ljava/util/concurrent/CopyOnWriteArraySet;Landroid/os/Looper;La0/b;La0/o$b;Z)V

    return-void
.end method

.method private constructor <init>(Ljava/util/concurrent/CopyOnWriteArraySet;Landroid/os/Looper;La0/b;La0/o$b;Z)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/CopyOnWriteArraySet<",
            "La0/o$c<",
            "TT;>;>;",
            "Landroid/os/Looper;",
            "La0/b;",
            "La0/o$b<",
            "TT;>;Z)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, La0/o;->a:La0/b;

    iput-object p1, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    iput-object p4, p0, La0/o;->c:La0/o$b;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/o;->g:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, La0/o;->e:Ljava/util/ArrayDeque;

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, La0/o;->f:Ljava/util/ArrayDeque;

    new-instance p1, La0/m;

    invoke-direct {p1, p0}, La0/m;-><init>(La0/o;)V

    invoke-interface {p3, p2, p1}, La0/b;->b(Landroid/os/Looper;Landroid/os/Handler$Callback;)La0/l;

    move-result-object p1

    iput-object p1, p0, La0/o;->b:La0/l;

    iput-boolean p5, p0, La0/o;->i:Z

    return-void
.end method

.method public static a(La0/o;)V
    .registers 4

    iget-object v0, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1f

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/o$c;

    iget-object v2, p0, La0/o;->c:La0/o$b;

    invoke-virtual {v1, v2}, La0/o$c;->b(La0/o$b;)V

    iget-object v1, p0, La0/o;->b:La0/l;

    invoke-interface {v1}, La0/l;->a()Z

    move-result v1

    if-eqz v1, :cond_6

    :cond_1f
    return-void
.end method

.method private i()V
    .registers 3

    iget-boolean v0, p0, La0/o;->i:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    iget-object v1, p0, La0/o;->b:La0/l;

    invoke-interface {v1}, La0/l;->e()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-ne v0, v1, :cond_17

    const/4 v0, 0x1

    goto :goto_18

    :cond_17
    const/4 v0, 0x0

    :goto_18
    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, La0/o;->g:Ljava/lang/Object;

    monitor-enter v0

    :try_start_6
    iget-boolean v1, p0, La0/o;->h:Z

    if-eqz v1, :cond_e

    monitor-exit v0

    return-void

    :catchall_c
    move-exception p1

    goto :goto_1a

    :cond_e
    iget-object v1, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    new-instance v2, La0/o$c;

    invoke-direct {v2, p1}, La0/o$c;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :goto_1a
    monitor-exit v0
    :try_end_1b
    .catchall {:try_start_6 .. :try_end_1b} :catchall_c

    throw p1
.end method

.method public final c(Landroid/os/Looper;Lg0/h;)La0/o;
    .registers 10

    new-instance v6, La0/o;

    iget-boolean v5, p0, La0/o;->i:Z

    iget-object v3, p0, La0/o;->a:La0/b;

    iget-object v1, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    move-object v0, v6

    move-object v2, p1

    move-object v4, p2

    invoke-direct/range {v0 .. v5}, La0/o;-><init>(Ljava/util/concurrent/CopyOnWriteArraySet;Landroid/os/Looper;La0/b;La0/o$b;Z)V

    return-object v6
.end method

.method public final d()V
    .registers 5

    invoke-direct {p0}, La0/o;->i()V

    iget-object v0, p0, La0/o;->f:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_c

    return-void

    :cond_c
    iget-object v1, p0, La0/o;->b:La0/l;

    invoke-interface {v1}, La0/l;->a()Z

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_1c

    invoke-interface {v1, v3}, La0/l;->b(I)La0/l$a;

    move-result-object v2

    invoke-interface {v1, v2}, La0/l;->g(La0/l$a;)Z

    :cond_1c
    iget-object v1, p0, La0/o;->e:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v2

    xor-int/2addr v2, v3

    invoke-virtual {v1, v0}, Ljava/util/ArrayDeque;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    if-eqz v2, :cond_2c

    return-void

    :cond_2c
    :goto_2c
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3f

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->peekFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    goto :goto_2c

    :cond_3f
    return-void
.end method

.method public final e(ILa0/o$a;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "La0/o$a<",
            "TT;>;)V"
        }
    .end annotation

    invoke-direct {p0}, La0/o;->i()V

    new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    iget-object v1, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {v0, v1}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>(Ljava/util/Collection;)V

    iget-object v1, p0, La0/o;->f:Ljava/util/ArrayDeque;

    new-instance v2, La0/n;

    invoke-direct {v2, v0, p1, p2}, La0/n;-><init>(Ljava/util/concurrent/CopyOnWriteArraySet;ILa0/o$a;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final f()V
    .registers 4

    invoke-direct {p0}, La0/o;->i()V

    iget-object v0, p0, La0/o;->g:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x1

    :try_start_7
    iput-boolean v1, p0, La0/o;->h:Z

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_7 .. :try_end_a} :catchall_28

    iget-object v0, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_22

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/o$c;

    iget-object v2, p0, La0/o;->c:La0/o$b;

    invoke-virtual {v1, v2}, La0/o$c;->c(La0/o$b;)V

    goto :goto_10

    :cond_22
    iget-object v0, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->clear()V

    return-void

    :catchall_28
    move-exception v1

    :try_start_29
    monitor-exit v0
    :try_end_2a
    .catchall {:try_start_29 .. :try_end_2a} :catchall_28

    throw v1
.end method

.method public final g(Ljava/lang/Object;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    invoke-direct {p0}, La0/o;->i()V

    iget-object v0, p0, La0/o;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_9
    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_26

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La0/o$c;

    iget-object v3, v2, La0/o$c;->a:Ljava/lang/Object;

    invoke-virtual {v3, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9

    iget-object v3, p0, La0/o;->c:La0/o$b;

    invoke-virtual {v2, v3}, La0/o$c;->c(La0/o$b;)V

    invoke-virtual {v0, v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->remove(Ljava/lang/Object;)Z

    goto :goto_9

    :cond_26
    return-void
.end method

.method public final h(ILa0/o$a;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "La0/o$a<",
            "TT;>;)V"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, La0/o;->e(ILa0/o$a;)V

    invoke-virtual {p0}, La0/o;->d()V

    return-void
.end method
