.class final LA0/b$a;
.super Ljava/lang/Object;
.source "AviExtractor.java"

# interfaces
.implements Ly0/E;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LA0/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field private final a:J

.field final synthetic b:LA0/b;


# direct methods
.method public constructor <init>(LA0/b;J)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA0/b$a;->b:LA0/b;

    iput-wide p2, p0, LA0/b$a;->a:J

    return-void
.end method


# virtual methods
.method public final d(J)Ly0/E$a;
    .registers 12

    iget-object v0, p0, LA0/b$a;->b:LA0/b;

    invoke-static {v0}, LA0/b;->a(LA0/b;)[LA0/e;

    move-result-object v1

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-virtual {v1, p1, p2}, LA0/e;->d(J)Ly0/E$a;

    move-result-object v1

    const/4 v2, 0x1

    :goto_e
    invoke-static {v0}, LA0/b;->a(LA0/b;)[LA0/e;

    move-result-object v3

    array-length v3, v3

    if-ge v2, v3, :cond_2f

    invoke-static {v0}, LA0/b;->a(LA0/b;)[LA0/e;

    move-result-object v3

    aget-object v3, v3, v2

    invoke-virtual {v3, p1, p2}, LA0/e;->d(J)Ly0/E$a;

    move-result-object v3

    iget-object v4, v3, Ly0/E$a;->a:Ly0/F;

    iget-wide v4, v4, Ly0/F;->b:J

    iget-object v6, v1, Ly0/E$a;->a:Ly0/F;

    iget-wide v6, v6, Ly0/F;->b:J

    cmp-long v8, v4, v6

    if-gez v8, :cond_2c

    move-object v1, v3

    :cond_2c
    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    :cond_2f
    return-object v1
.end method

.method public final h()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public final l()J
    .registers 3

    iget-wide v0, p0, LA0/b$a;->a:J

    return-wide v0
.end method
