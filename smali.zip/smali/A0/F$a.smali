.class final La0/F$a;
.super Ljava/lang/Object;
.source "SystemHandlerWrapper.java"

# interfaces
.implements La0/l$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private a:Landroid/os/Message;


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, La0/F$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 2

    iget-object v0, p0, La0/F$a;->a:Landroid/os/Message;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    const/4 v0, 0x0

    iput-object v0, p0, La0/F$a;->a:Landroid/os/Message;

    invoke-static {p0}, La0/F;->l(La0/F$a;)V

    return-void
.end method

.method public final b(Landroid/os/Handler;)Z
    .registers 3

    iget-object v0, p0, La0/F$a;->a:Landroid/os/Message;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendMessageAtFrontOfQueue(Landroid/os/Message;)Z

    move-result p1

    const/4 v0, 0x0

    iput-object v0, p0, La0/F$a;->a:Landroid/os/Message;

    invoke-static {p0}, La0/F;->l(La0/F$a;)V

    return p1
.end method

.method public final c(Landroid/os/Message;)V
    .registers 2

    iput-object p1, p0, La0/F$a;->a:Landroid/os/Message;

    return-void
.end method
