.class public final La0/i;
.super Ljava/lang/Object;
.source "EGLSurfaceTexture.java"

# interfaces
.implements Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;
.implements Ljava/lang/Runnable;


# static fields
.field private static final g:[I


# instance fields
.field private final a:Landroid/os/Handler;

.field private final b:[I

.field private c:Landroid/opengl/EGLDisplay;

.field private d:Landroid/opengl/EGLContext;

.field private e:Landroid/opengl/EGLSurface;

.field private f:Landroid/graphics/SurfaceTexture;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x11

    new-array v0, v0, [I

    fill-array-data v0, :array_a

    sput-object v0, La0/i;->g:[I

    return-void

    :array_a
    .array-data 4
        0x3040
        0x4
        0x3024
        0x8
        0x3023
        0x8
        0x3022
        0x8
        0x3021
        0x8
        0x3025
        0x0
        0x3027
        0x3038
        0x3033
        0x4
        0x3038
    .end array-data
.end method

.method public constructor <init>(Landroid/os/Handler;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/i;->a:Landroid/os/Handler;

    const/4 p1, 0x1

    new-array p1, p1, [I

    iput-object p1, p0, La0/i;->b:[I

    return-void
.end method


# virtual methods
.method public final a()Landroid/graphics/SurfaceTexture;
    .registers 2

    iget-object v0, p0, La0/i;->f:Landroid/graphics/SurfaceTexture;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0
.end method

.method public final b(I)V
    .registers 22
    .annotation system Ldalvik/annotation/Throws;
        value = {
            La0/k$a;
        }
    .end annotation

    move-object/from16 v0, p0

    move/from16 v1, p1

    const/16 v2, 0x3056

    const/16 v3, 0x3057

    const/16 v4, 0x32c0

    const/16 v5, 0x3038

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v7}, Landroid/opengl/EGL14;->eglGetDisplay(I)Landroid/opengl/EGLDisplay;

    move-result-object v9

    if-eqz v9, :cond_17

    const/4 v10, 0x1

    goto :goto_18

    :cond_17
    const/4 v10, 0x0

    :goto_18
    const-string v11, "eglGetDisplay failed"

    invoke-static {v11, v10}, La0/k;->c(Ljava/lang/String;Z)V

    new-array v10, v6, [I

    invoke-static {v9, v10, v7, v10, v8}, Landroid/opengl/EGL14;->eglInitialize(Landroid/opengl/EGLDisplay;[II[II)Z

    move-result v10

    const-string v11, "eglInitialize failed"

    invoke-static {v11, v10}, La0/k;->c(Ljava/lang/String;Z)V

    iput-object v9, v0, La0/i;->c:Landroid/opengl/EGLDisplay;

    new-array v15, v8, [Landroid/opengl/EGLConfig;

    new-array v14, v8, [I

    sget-object v10, La0/i;->g:[I

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/16 v16, 0x1

    const/16 v17, 0x0

    move-object v12, v15

    move-object/from16 v18, v14

    move/from16 v14, v16

    move-object/from16 v19, v15

    move-object/from16 v15, v18

    move/from16 v16, v17

    invoke-static/range {v9 .. v16}, Landroid/opengl/EGL14;->eglChooseConfig(Landroid/opengl/EGLDisplay;[II[Landroid/opengl/EGLConfig;II[II)Z

    move-result v9

    if-eqz v9, :cond_51

    aget v10, v18, v7

    if-lez v10, :cond_51

    aget-object v10, v19, v7

    if-eqz v10, :cond_51

    const/4 v10, 0x1

    goto :goto_52

    :cond_51
    const/4 v10, 0x0

    :goto_52
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    aget v11, v18, v7

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aget-object v12, v19, v7

    const/4 v13, 0x3

    new-array v13, v13, [Ljava/lang/Object;

    aput-object v9, v13, v7

    aput-object v11, v13, v8

    aput-object v12, v13, v6

    sget v9, La0/T;->a:I

    sget-object v9, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v11, "eglChooseConfig failed: success=%b, numConfigs[0]=%d, configs[0]=%s"

    invoke-static {v9, v11, v13}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v10}, La0/k;->c(Ljava/lang/String;Z)V

    aget-object v9, v19, v7

    iget-object v10, v0, La0/i;->c:Landroid/opengl/EGLDisplay;

    const/16 v11, 0x3098

    if-nez v1, :cond_81

    filled-new-array {v11, v6, v5}, [I

    move-result-object v4

    goto :goto_85

    :cond_81
    filled-new-array {v11, v6, v4, v8, v5}, [I

    move-result-object v4

    :goto_85
    sget-object v11, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    invoke-static {v10, v9, v11, v4, v7}, Landroid/opengl/EGL14;->eglCreateContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;Landroid/opengl/EGLContext;[II)Landroid/opengl/EGLContext;

    move-result-object v4

    if-eqz v4, :cond_8f

    const/4 v10, 0x1

    goto :goto_90

    :cond_8f
    const/4 v10, 0x0

    :goto_90
    const-string v11, "eglCreateContext failed"

    invoke-static {v11, v10}, La0/k;->c(Ljava/lang/String;Z)V

    iput-object v4, v0, La0/i;->d:Landroid/opengl/EGLContext;

    iget-object v10, v0, La0/i;->c:Landroid/opengl/EGLDisplay;

    if-ne v1, v8, :cond_9e

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    goto :goto_b9

    :cond_9e
    if-ne v1, v6, :cond_a7

    const/4 v1, 0x7

    new-array v1, v1, [I

    fill-array-data v1, :array_da

    goto :goto_ab

    :cond_a7
    filled-new-array {v3, v8, v2, v8, v5}, [I

    move-result-object v1

    :goto_ab
    invoke-static {v10, v9, v1, v7}, Landroid/opengl/EGL14;->eglCreatePbufferSurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;[II)Landroid/opengl/EGLSurface;

    move-result-object v1

    if-eqz v1, :cond_b3

    const/4 v2, 0x1

    goto :goto_b4

    :cond_b3
    const/4 v2, 0x0

    :goto_b4
    const-string v3, "eglCreatePbufferSurface failed"

    invoke-static {v3, v2}, La0/k;->c(Ljava/lang/String;Z)V

    :goto_b9
    invoke-static {v10, v1, v1, v4}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    move-result v2

    const-string v3, "eglMakeCurrent failed"

    invoke-static {v3, v2}, La0/k;->c(Ljava/lang/String;Z)V

    iput-object v1, v0, La0/i;->e:Landroid/opengl/EGLSurface;

    iget-object v1, v0, La0/i;->b:[I

    invoke-static {v8, v1, v7}, Landroid/opengl/GLES20;->glGenTextures(I[II)V

    invoke-static {}, La0/k;->b()V

    new-instance v2, Landroid/graphics/SurfaceTexture;

    aget v1, v1, v7

    invoke-direct {v2, v1}, Landroid/graphics/SurfaceTexture;-><init>(I)V

    iput-object v2, v0, La0/i;->f:Landroid/graphics/SurfaceTexture;

    invoke-virtual {v2, v0}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    return-void

    nop

    :array_da
    .array-data 4
        0x3057
        0x1
        0x3056
        0x1
        0x32c0
        0x1
        0x3038
    .end array-data
.end method

.method public final c()V
    .registers 6

    iget-object v0, p0, La0/i;->a:Landroid/os/Handler;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    :try_start_6
    iget-object v1, p0, La0/i;->f:Landroid/graphics/SurfaceTexture;

    if-eqz v1, :cond_17

    invoke-virtual {v1}, Landroid/graphics/SurfaceTexture;->release()V

    iget-object v1, p0, La0/i;->b:[I

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v3, v1, v2}, Landroid/opengl/GLES20;->glDeleteTextures(I[II)V
    :try_end_14
    .catchall {:try_start_6 .. :try_end_14} :catchall_15

    goto :goto_17

    :catchall_15
    move-exception v1

    goto :goto_65

    :cond_17
    :goto_17
    iget-object v1, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    if-eqz v1, :cond_2c

    sget-object v2, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v1, v2}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c

    iget-object v1, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    sget-object v2, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    invoke-static {v1, v2, v2, v3}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    :cond_2c
    iget-object v1, p0, La0/i;->e:Landroid/opengl/EGLSurface;

    if-eqz v1, :cond_3f

    sget-object v2, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    invoke-virtual {v1, v2}, Landroid/opengl/EGLSurface;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3f

    iget-object v1, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    iget-object v2, p0, La0/i;->e:Landroid/opengl/EGLSurface;

    invoke-static {v1, v2}, Landroid/opengl/EGL14;->eglDestroySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    :cond_3f
    iget-object v1, p0, La0/i;->d:Landroid/opengl/EGLContext;

    if-eqz v1, :cond_48

    iget-object v2, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v2, v1}, Landroid/opengl/EGL14;->eglDestroyContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLContext;)Z

    :cond_48
    invoke-static {}, Landroid/opengl/EGL14;->eglReleaseThread()Z

    iget-object v1, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    if-eqz v1, :cond_5c

    sget-object v2, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v1, v2}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5c

    iget-object v1, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v1}, Landroid/opengl/EGL14;->eglTerminate(Landroid/opengl/EGLDisplay;)Z

    :cond_5c
    iput-object v0, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    iput-object v0, p0, La0/i;->d:Landroid/opengl/EGLContext;

    iput-object v0, p0, La0/i;->e:Landroid/opengl/EGLSurface;

    iput-object v0, p0, La0/i;->f:Landroid/graphics/SurfaceTexture;

    return-void

    :goto_65
    iget-object v2, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    if-eqz v2, :cond_7a

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v2, v3}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_7a

    iget-object v2, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    invoke-static {v2, v3, v3, v4}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    :cond_7a
    iget-object v2, p0, La0/i;->e:Landroid/opengl/EGLSurface;

    if-eqz v2, :cond_8d

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    invoke-virtual {v2, v3}, Landroid/opengl/EGLSurface;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_8d

    iget-object v2, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    iget-object v3, p0, La0/i;->e:Landroid/opengl/EGLSurface;

    invoke-static {v2, v3}, Landroid/opengl/EGL14;->eglDestroySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    :cond_8d
    iget-object v2, p0, La0/i;->d:Landroid/opengl/EGLContext;

    if-eqz v2, :cond_96

    iget-object v3, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v3, v2}, Landroid/opengl/EGL14;->eglDestroyContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLContext;)Z

    :cond_96
    invoke-static {}, Landroid/opengl/EGL14;->eglReleaseThread()Z

    iget-object v2, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    if-eqz v2, :cond_aa

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v2, v3}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_aa

    iget-object v2, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v2}, Landroid/opengl/EGL14;->eglTerminate(Landroid/opengl/EGLDisplay;)Z

    :cond_aa
    iput-object v0, p0, La0/i;->c:Landroid/opengl/EGLDisplay;

    iput-object v0, p0, La0/i;->d:Landroid/opengl/EGLContext;

    iput-object v0, p0, La0/i;->e:Landroid/opengl/EGLSurface;

    iput-object v0, p0, La0/i;->f:Landroid/graphics/SurfaceTexture;

    throw v1
.end method

.method public final onFrameAvailable(Landroid/graphics/SurfaceTexture;)V
    .registers 2

    iget-object p1, p0, La0/i;->a:Landroid/os/Handler;

    invoke-virtual {p1, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final run()V
    .registers 2

    iget-object v0, p0, La0/i;->f:Landroid/graphics/SurfaceTexture;

    if-eqz v0, :cond_7

    :try_start_4
    invoke-virtual {v0}, Landroid/graphics/SurfaceTexture;->updateTexImage()V
    :try_end_7
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_7} :catch_7

    :catch_7
    :cond_7
    return-void
.end method
