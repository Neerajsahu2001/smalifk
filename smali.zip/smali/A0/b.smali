.class public interface abstract La0/b;
.super Ljava/lang/Object;
.source "Clock.java"


# static fields
.field public static final a:La0/E;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/E;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La0/b;->a:La0/E;

    return-void
.end method


# virtual methods
.method public abstract a()J
.end method

.method public abstract b(Landroid/os/Looper;Landroid/os/Handler$Callback;)La0/l;
.end method

.method public abstract currentTimeMillis()J
.end method

.method public abstract elapsedRealtime()J
.end method

.method public abstract nanoTime()J
.end method
