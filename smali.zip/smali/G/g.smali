.class public final LG/g;
.super Ljava/lang/Object;


# static fields
.field public static final custom_dialog:I = 0x7f0e009b

.field public static final notification_action:I = 0x7f0e018f

.field public static final notification_action_tombstone:I = 0x7f0e0190

.field public static final notification_template_custom_big:I = 0x7f0e0199

.field public static final notification_template_icon_group:I = 0x7f0e019a

.field public static final notification_template_part_chronometer:I = 0x7f0e019e

.field public static final notification_template_part_time:I = 0x7f0e019f
