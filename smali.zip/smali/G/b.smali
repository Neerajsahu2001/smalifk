.class Lg/b;
.super Landroid/graphics/drawable/Drawable;
.source "DrawableContainer.java"

# interfaces
.implements Landroid/graphics/drawable/Drawable$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lg/b$b;,
        Lg/b$c;
    }
.end annotation


# static fields
.field public static final synthetic m:I


# instance fields
.field private a:Lg/b$c;

.field private b:Landroid/graphics/Rect;

.field private c:Landroid/graphics/drawable/Drawable;

.field private d:Landroid/graphics/drawable/Drawable;

.field private e:I

.field private f:Z

.field private g:I

.field private h:Z

.field private i:Ljava/lang/Runnable;

.field private j:J

.field private k:J

.field private l:Lg/b$b;


# direct methods
.method constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/16 v0, 0xff

    iput v0, p0, Lg/b;->e:I

    const/4 v0, -0x1

    iput v0, p0, Lg/b;->g:I

    return-void
.end method

.method private d(Landroid/graphics/drawable/Drawable;)V
    .registers 6

    iget-object v0, p0, Lg/b;->l:Lg/b$b;

    if-nez v0, :cond_b

    new-instance v0, Lg/b$b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lg/b;->l:Lg/b$b;

    :cond_b
    iget-object v0, p0, Lg/b;->l:Lg/b$b;

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v1

    invoke-virtual {v0, v1}, Lg/b$b;->b(Landroid/graphics/drawable/Drawable$Callback;)V

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :try_start_17
    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget v0, v0, Lg/b$c;->y:I

    if-gtz v0, :cond_29

    iget-boolean v0, p0, Lg/b;->f:Z

    if-eqz v0, :cond_29

    iget v0, p0, Lg/b;->e:I

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    goto :goto_29

    :catchall_27
    move-exception v0

    goto :goto_9a

    :cond_29
    :goto_29
    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->C:Z

    if-eqz v1, :cond_35

    iget-object v0, v0, Lg/b$c;->B:Landroid/graphics/ColorFilter;

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    goto :goto_49

    :cond_35
    iget-boolean v1, v0, Lg/b$c;->F:Z

    if-eqz v1, :cond_3e

    iget-object v0, v0, Lg/b$c;->D:Landroid/content/res/ColorStateList;

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/a;->n(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_3e
    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->G:Z

    if-eqz v1, :cond_49

    iget-object v0, v0, Lg/b$c;->E:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/a;->o(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_49
    :goto_49
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v0, v0, Lg/b$c;->w:Z

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setDither(Z)V

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getLevel()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_7a

    invoke-static {p0}, Landroidx/core/graphics/drawable/a;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v0

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/a;->l(Landroid/graphics/drawable/Drawable;I)Z

    :cond_7a
    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v0, v0, Lg/b$c;->A:Z

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/a;->i(Landroid/graphics/drawable/Drawable;Z)V

    iget-object v0, p0, Lg/b;->b:Landroid/graphics/Rect;

    if-eqz v0, :cond_90

    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v2, v0, Landroid/graphics/Rect;->top:I

    iget v3, v0, Landroid/graphics/Rect;->right:I

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    invoke-static {p1, v1, v2, v3, v0}, Landroidx/core/graphics/drawable/a;->k(Landroid/graphics/drawable/Drawable;IIII)V
    :try_end_90
    .catchall {:try_start_17 .. :try_end_90} :catchall_27

    :cond_90
    iget-object v0, p0, Lg/b;->l:Lg/b$b;

    invoke-virtual {v0}, Lg/b$b;->a()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-void

    :goto_9a
    iget-object v1, p0, Lg/b;->l:Lg/b$b;

    invoke-virtual {v1}, Lg/b$b;->a()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    throw v0
.end method


# virtual methods
.method final a(Z)V
    .registers 15

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/b;->f:Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iget-object v3, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    const-wide/16 v4, 0xff

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    if-eqz v3, :cond_38

    iget-wide v9, p0, Lg/b;->j:J

    cmp-long v11, v9, v6

    if-eqz v11, :cond_3a

    cmp-long v11, v9, v1

    if-gtz v11, :cond_22

    iget v9, p0, Lg/b;->e:I

    invoke-virtual {v3, v9}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    iput-wide v6, p0, Lg/b;->j:J

    goto :goto_3a

    :cond_22
    sub-long/2addr v9, v1

    mul-long v9, v9, v4

    long-to-int v10, v9

    iget-object v9, p0, Lg/b;->a:Lg/b$c;

    iget v9, v9, Lg/b$c;->y:I

    div-int/2addr v10, v9

    rsub-int v9, v10, 0xff

    iget v10, p0, Lg/b;->e:I

    mul-int v9, v9, v10

    div-int/lit16 v9, v9, 0xff

    invoke-virtual {v3, v9}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    const/4 v3, 0x1

    goto :goto_3b

    :cond_38
    iput-wide v6, p0, Lg/b;->j:J

    :cond_3a
    :goto_3a
    const/4 v3, 0x0

    :goto_3b
    iget-object v9, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v9, :cond_65

    iget-wide v10, p0, Lg/b;->k:J

    cmp-long v12, v10, v6

    if-eqz v12, :cond_67

    cmp-long v12, v10, v1

    if-gtz v12, :cond_52

    invoke-virtual {v9, v8, v8}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v0, 0x0

    iput-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    iput-wide v6, p0, Lg/b;->k:J

    goto :goto_67

    :cond_52
    sub-long/2addr v10, v1

    mul-long v10, v10, v4

    long-to-int v3, v10

    iget-object v4, p0, Lg/b;->a:Lg/b$c;

    iget v4, v4, Lg/b$c;->z:I

    div-int/2addr v3, v4

    iget v4, p0, Lg/b;->e:I

    mul-int v3, v3, v4

    div-int/lit16 v3, v3, 0xff

    invoke-virtual {v9, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    goto :goto_68

    :cond_65
    iput-wide v6, p0, Lg/b;->k:J

    :cond_67
    :goto_67
    move v0, v3

    :goto_68
    if-eqz p1, :cond_74

    if-eqz v0, :cond_74

    iget-object p1, p0, Lg/b;->i:Ljava/lang/Runnable;

    const-wide/16 v3, 0x10

    add-long/2addr v1, v3

    invoke-virtual {p0, p1, v1, v2}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    :cond_74
    return-void
.end method

.method public applyTheme(Landroid/content/res/Resources$Theme;)V
    .registers 3

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    invoke-virtual {v0, p1}, Lg/b$c;->b(Landroid/content/res/Resources$Theme;)V

    return-void
.end method

.method b()Lg/b$c;
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method final c()I
    .registers 2

    iget v0, p0, Lg/b;->g:I

    return v0
.end method

.method public canApplyTheme()Z
    .registers 2

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    invoke-virtual {v0}, Lg/b$c;->canApplyTheme()Z

    move-result v0

    return v0
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .registers 3

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_7
    iget-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_e

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_e
    return-void
.end method

.method final e(I)Z
    .registers 11

    iget v0, p0, Lg/b;->g:I

    const/4 v1, 0x0

    if-ne p1, v0, :cond_6

    return v1

    :cond_6
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget v0, v0, Lg/b$c;->z:I

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    if-lez v0, :cond_2e

    iget-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_1a

    invoke-virtual {v0, v1, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_1a
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_29

    iput-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget v0, v0, Lg/b$c;->z:I

    int-to-long v0, v0

    add-long/2addr v0, v2

    iput-wide v0, p0, Lg/b;->k:J

    goto :goto_35

    :cond_29
    iput-object v4, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    iput-wide v5, p0, Lg/b;->k:J

    goto :goto_35

    :cond_2e
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_35

    invoke-virtual {v0, v1, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_35
    :goto_35
    if-ltz p1, :cond_55

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget v1, v0, Lg/b$c;->h:I

    if-ge p1, v1, :cond_55

    invoke-virtual {v0, p1}, Lg/b$c;->f(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    iput p1, p0, Lg/b;->g:I

    if-eqz v0, :cond_5a

    iget-object p1, p0, Lg/b;->a:Lg/b$c;

    iget p1, p1, Lg/b$c;->y:I

    if-lez p1, :cond_51

    int-to-long v7, p1

    add-long/2addr v2, v7

    iput-wide v2, p0, Lg/b;->j:J

    :cond_51
    invoke-direct {p0, v0}, Lg/b;->d(Landroid/graphics/drawable/Drawable;)V

    goto :goto_5a

    :cond_55
    iput-object v4, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 p1, -0x1

    iput p1, p0, Lg/b;->g:I

    :cond_5a
    :goto_5a
    iget-wide v0, p0, Lg/b;->j:J

    const/4 p1, 0x1

    cmp-long v2, v0, v5

    if-nez v2, :cond_67

    iget-wide v0, p0, Lg/b;->k:J

    cmp-long v2, v0, v5

    if-eqz v2, :cond_7c

    :cond_67
    iget-object v0, p0, Lg/b;->i:Ljava/lang/Runnable;

    if-nez v0, :cond_76

    new-instance v0, Lg/b$a;

    move-object v1, p0

    check-cast v1, Lg/d;

    invoke-direct {v0, v1}, Lg/b$a;-><init>(Lg/d;)V

    iput-object v0, p0, Lg/b;->i:Ljava/lang/Runnable;

    goto :goto_79

    :cond_76
    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    :goto_79
    invoke-virtual {p0, p1}, Lg/b;->a(Z)V

    :cond_7c
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return p1
.end method

.method f(Lg/b$c;)V
    .registers 3

    iput-object p1, p0, Lg/b;->a:Lg/b$c;

    iget v0, p0, Lg/b;->g:I

    if-ltz v0, :cond_11

    invoke-virtual {p1, v0}, Lg/b$c;->f(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    iput-object p1, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz p1, :cond_11

    invoke-direct {p0, p1}, Lg/b;->d(Landroid/graphics/drawable/Drawable;)V

    :cond_11
    const/4 p1, 0x0

    iput-object p1, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method final g(Landroid/content/res/Resources;)V
    .registers 4

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    if-eqz p1, :cond_1c

    iput-object p1, v0, Lg/b$c;->b:Landroid/content/res/Resources;

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    if-nez p1, :cond_10

    const/16 p1, 0xa0

    :cond_10
    iget v1, v0, Lg/b$c;->c:I

    iput p1, v0, Lg/b$c;->c:I

    if-eq v1, p1, :cond_1f

    const/4 p1, 0x0

    iput-boolean p1, v0, Lg/b$c;->m:Z

    iput-boolean p1, v0, Lg/b$c;->j:Z

    goto :goto_1f

    :cond_1c
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_1f
    :goto_1f
    return-void
.end method

.method public getAlpha()I
    .registers 2

    iget v0, p0, Lg/b;->e:I

    return v0
.end method

.method public getChangingConfigurations()I
    .registers 3

    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result v0

    iget-object v1, p0, Lg/b;->a:Lg/b$c;

    invoke-virtual {v1}, Lg/b$c;->getChangingConfigurations()I

    move-result v1

    or-int/2addr v0, v1

    return v0
.end method

.method public final getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;
    .registers 3

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    invoke-virtual {v0}, Lg/b$c;->c()Z

    move-result v0

    if-eqz v0, :cond_13

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    invoke-virtual {p0}, Lg/b;->getChangingConfigurations()I

    move-result v1

    iput v1, v0, Lg/b$c;->d:I

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    return-object v0

    :cond_13
    const/4 v0, 0x0

    return-object v0
.end method

.method public getCurrent()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public getHotspotBounds(Landroid/graphics/Rect;)V
    .registers 3

    iget-object v0, p0, Lg/b;->b:Landroid/graphics/Rect;

    if-eqz v0, :cond_8

    invoke-virtual {p1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    goto :goto_b

    :cond_8
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->getHotspotBounds(Landroid/graphics/Rect;)V

    :goto_b
    return-void
.end method

.method public getIntrinsicHeight()I
    .registers 3

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->l:Z

    if-eqz v1, :cond_10

    iget-boolean v1, v0, Lg/b$c;->m:Z

    if-nez v1, :cond_d

    invoke-virtual {v0}, Lg/b$c;->d()V

    :cond_d
    iget v0, v0, Lg/b$c;->o:I

    return v0

    :cond_10
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    goto :goto_1a

    :cond_19
    const/4 v0, -0x1

    :goto_1a
    return v0
.end method

.method public getIntrinsicWidth()I
    .registers 3

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->l:Z

    if-eqz v1, :cond_10

    iget-boolean v1, v0, Lg/b$c;->m:Z

    if-nez v1, :cond_d

    invoke-virtual {v0}, Lg/b$c;->d()V

    :cond_d
    iget v0, v0, Lg/b$c;->n:I

    return v0

    :cond_10
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    goto :goto_1a

    :cond_19
    const/4 v0, -0x1

    :goto_1a
    return v0
.end method

.method public getMinimumHeight()I
    .registers 3

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->l:Z

    if-eqz v1, :cond_10

    iget-boolean v1, v0, Lg/b$c;->m:Z

    if-nez v1, :cond_d

    invoke-virtual {v0}, Lg/b$c;->d()V

    :cond_d
    iget v0, v0, Lg/b$c;->q:I

    return v0

    :cond_10
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    move-result v0

    goto :goto_1a

    :cond_19
    const/4 v0, 0x0

    :goto_1a
    return v0
.end method

.method public getMinimumWidth()I
    .registers 3

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->l:Z

    if-eqz v1, :cond_10

    iget-boolean v1, v0, Lg/b$c;->m:Z

    if-nez v1, :cond_d

    invoke-virtual {v0}, Lg/b$c;->d()V

    :cond_d
    iget v0, v0, Lg/b$c;->p:I

    return v0

    :cond_10
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumWidth()I

    move-result v0

    goto :goto_1a

    :cond_19
    const/4 v0, 0x0

    :goto_1a
    return v0
.end method

.method public getOpacity()I
    .registers 2

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    if-nez v0, :cond_b

    goto :goto_12

    :cond_b
    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    invoke-virtual {v0}, Lg/b$c;->h()I

    move-result v0

    goto :goto_13

    :cond_12
    :goto_12
    const/4 v0, -0x2

    :goto_13
    return v0
.end method

.method public getOutline(Landroid/graphics/Outline;)V
    .registers 3

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->getOutline(Landroid/graphics/Outline;)V

    :cond_7
    return-void
.end method

.method public getPadding(Landroid/graphics/Rect;)Z
    .registers 6

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    invoke-virtual {v0}, Lg/b$c;->g()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_1d

    invoke-virtual {p1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    iget v2, v0, Landroid/graphics/Rect;->left:I

    iget v3, v0, Landroid/graphics/Rect;->top:I

    or-int/2addr v2, v3

    iget v3, v0, Landroid/graphics/Rect;->bottom:I

    or-int/2addr v2, v3

    iget v0, v0, Landroid/graphics/Rect;->right:I

    or-int/2addr v0, v2

    if-eqz v0, :cond_1b

    const/4 v0, 0x1

    goto :goto_2a

    :cond_1b
    const/4 v0, 0x0

    goto :goto_2a

    :cond_1d
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_26

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    move-result v0

    goto :goto_2a

    :cond_26
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    move-result v0

    :goto_2a
    invoke-virtual {p0}, Lg/b;->isAutoMirrored()Z

    move-result v2

    if-eqz v2, :cond_3e

    invoke-static {p0}, Landroidx/core/graphics/drawable/a;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v2

    if-ne v2, v1, :cond_3e

    iget v1, p1, Landroid/graphics/Rect;->left:I

    iget v2, p1, Landroid/graphics/Rect;->right:I

    iput v2, p1, Landroid/graphics/Rect;->left:I

    iput v1, p1, Landroid/graphics/Rect;->right:I

    :cond_3e
    return v0
.end method

.method public invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .registers 4

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    if-eqz v0, :cond_9

    const/4 v1, 0x0

    iput-boolean v1, v0, Lg/b$c;->r:Z

    iput-boolean v1, v0, Lg/b$c;->t:Z

    :cond_9
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-ne p1, v0, :cond_1a

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    if-eqz p1, :cond_1a

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    invoke-interface {p1, p0}, Landroid/graphics/drawable/Drawable$Callback;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_1a
    return-void
.end method

.method public isAutoMirrored()Z
    .registers 2

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v0, v0, Lg/b$c;->A:Z

    return v0
.end method

.method public jumpToCurrentState()V
    .registers 8

    iget-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x1

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    const/4 v0, 0x0

    iput-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v0, 0x1

    goto :goto_e

    :cond_d
    const/4 v0, 0x0

    :goto_e
    iget-object v2, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v2, :cond_20

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    iget-boolean v2, p0, Lg/b;->f:Z

    if-eqz v2, :cond_20

    iget-object v2, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    iget v3, p0, Lg/b;->e:I

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_20
    iget-wide v2, p0, Lg/b;->k:J

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-eqz v6, :cond_2b

    iput-wide v4, p0, Lg/b;->k:J

    goto :goto_2c

    :cond_2b
    move v1, v0

    :goto_2c
    iget-wide v2, p0, Lg/b;->j:J

    cmp-long v0, v2, v4

    if-eqz v0, :cond_35

    iput-wide v4, p0, Lg/b;->j:J

    goto :goto_37

    :cond_35
    if-eqz v1, :cond_3a

    :goto_37
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_3a
    return-void
.end method

.method public mutate()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-boolean v0, p0, Lg/b;->h:Z

    if-nez v0, :cond_17

    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-ne v0, p0, :cond_17

    invoke-virtual {p0}, Lg/b;->b()Lg/b$c;

    move-result-object v0

    invoke-virtual {v0}, Lg/b$c;->i()V

    invoke-virtual {p0, v0}, Lg/b;->f(Lg/b$c;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/b;->h:Z

    :cond_17
    return-object p0
.end method

.method protected final onBoundsChange(Landroid/graphics/Rect;)V
    .registers 3

    iget-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    :cond_7
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_e

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    :cond_e
    return-void
.end method

.method public onLayoutDirectionChanged(I)Z
    .registers 12

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget v1, p0, Lg/b;->g:I

    iget v2, v0, Lg/b$c;->h:I

    iget-object v3, v0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_b
    if-ge v5, v2, :cond_23

    aget-object v7, v3, v5

    if-eqz v7, :cond_20

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x17

    if-lt v8, v9, :cond_1c

    invoke-static {v7, p1}, Landroidx/core/graphics/drawable/a;->l(Landroid/graphics/drawable/Drawable;I)Z

    move-result v7

    goto :goto_1d

    :cond_1c
    const/4 v7, 0x0

    :goto_1d
    if-ne v5, v1, :cond_20

    move v6, v7

    :cond_20
    add-int/lit8 v5, v5, 0x1

    goto :goto_b

    :cond_23
    iput p1, v0, Lg/b$c;->x:I

    return v6
.end method

.method protected final onLevelChange(I)Z
    .registers 3

    iget-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_9

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result p1

    return p1

    :cond_9
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_12

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result p1

    return p1

    :cond_12
    const/4 p1, 0x0

    return p1
.end method

.method protected onStateChange([I)Z
    .registers 3

    iget-object v0, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_9

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    return p1

    :cond_9
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_12

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    return p1

    :cond_12
    const/4 p1, 0x0

    return p1
.end method

.method public scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .registers 6

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-ne p1, v0, :cond_11

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    if-eqz p1, :cond_11

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    invoke-interface {p1, p0, p2, p3, p4}, Landroid/graphics/drawable/Drawable$Callback;->scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V

    :cond_11
    return-void
.end method

.method public setAlpha(I)V
    .registers 8

    iget-boolean v0, p0, Lg/b;->f:Z

    if-eqz v0, :cond_8

    iget v0, p0, Lg/b;->e:I

    if-eq v0, p1, :cond_21

    :cond_8
    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/b;->f:Z

    iput p1, p0, Lg/b;->e:I

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_21

    iget-wide v1, p0, Lg/b;->j:J

    const-wide/16 v3, 0x0

    cmp-long v5, v1, v3

    if-nez v5, :cond_1d

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    goto :goto_21

    :cond_1d
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lg/b;->a(Z)V

    :cond_21
    :goto_21
    return-void
.end method

.method public setAutoMirrored(Z)V
    .registers 4

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->A:Z

    if-eq v1, p1, :cond_f

    iput-boolean p1, v0, Lg/b$c;->A:Z

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_f

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/a;->i(Landroid/graphics/drawable/Drawable;Z)V

    :cond_f
    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 4

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lg/b$c;->C:Z

    iget-object v1, v0, Lg/b$c;->B:Landroid/graphics/ColorFilter;

    if-eq v1, p1, :cond_12

    iput-object p1, v0, Lg/b$c;->B:Landroid/graphics/ColorFilter;

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_12

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    :cond_12
    return-void
.end method

.method public setDither(Z)V
    .registers 4

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    iget-boolean v1, v0, Lg/b$c;->w:Z

    if-eq v1, p1, :cond_f

    iput-boolean p1, v0, Lg/b$c;->w:Z

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_f

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setDither(Z)V

    :cond_f
    return-void
.end method

.method public setHotspot(FF)V
    .registers 4

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_7

    invoke-static {v0, p1, p2}, Landroidx/core/graphics/drawable/a;->j(Landroid/graphics/drawable/Drawable;FF)V

    :cond_7
    return-void
.end method

.method public setHotspotBounds(IIII)V
    .registers 6

    iget-object v0, p0, Lg/b;->b:Landroid/graphics/Rect;

    if-nez v0, :cond_c

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0, p1, p2, p3, p4}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object v0, p0, Lg/b;->b:Landroid/graphics/Rect;

    goto :goto_f

    :cond_c
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/Rect;->set(IIII)V

    :goto_f
    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_16

    invoke-static {v0, p1, p2, p3, p4}, Landroidx/core/graphics/drawable/a;->k(Landroid/graphics/drawable/Drawable;IIII)V

    :cond_16
    return-void
.end method

.method public setTintList(Landroid/content/res/ColorStateList;)V
    .registers 4

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lg/b$c;->F:Z

    iget-object v1, v0, Lg/b$c;->D:Landroid/content/res/ColorStateList;

    if-eq v1, p1, :cond_10

    iput-object p1, v0, Lg/b$c;->D:Landroid/content/res/ColorStateList;

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/a;->n(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_10
    return-void
.end method

.method public setTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .registers 4

    iget-object v0, p0, Lg/b;->a:Lg/b$c;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lg/b$c;->G:Z

    iget-object v1, v0, Lg/b$c;->E:Landroid/graphics/PorterDuff$Mode;

    if-eq v1, p1, :cond_10

    iput-object p1, v0, Lg/b$c;->E:Landroid/graphics/PorterDuff$Mode;

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/a;->o(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_10
    return-void
.end method

.method public setVisible(ZZ)Z
    .registers 5

    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result v0

    iget-object v1, p0, Lg/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_b

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_b
    iget-object v1, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_12

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_12
    return v0
.end method

.method public unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .registers 4

    iget-object v0, p0, Lg/b;->c:Landroid/graphics/drawable/Drawable;

    if-ne p1, v0, :cond_11

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    if-eqz p1, :cond_11

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    invoke-interface {p1, p0, p2}, Landroid/graphics/drawable/Drawable$Callback;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V

    :cond_11
    return-void
.end method
