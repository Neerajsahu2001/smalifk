.class final Lg/a$b;
.super Lg/d$a;
.source "AnimatedStateListDrawableCompat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# instance fields
.field I:Landroidx/collection/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/f<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field J:Landroidx/collection/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/i<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lg/a$b;Lg/a;Landroid/content/res/Resources;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lg/d$a;-><init>(Lg/d$a;Lg/d;Landroid/content/res/Resources;)V

    if-eqz p1, :cond_e

    iget-object p2, p1, Lg/a$b;->I:Landroidx/collection/f;

    iput-object p2, p0, Lg/a$b;->I:Landroidx/collection/f;

    iget-object p1, p1, Lg/a$b;->J:Landroidx/collection/i;

    iput-object p1, p0, Lg/a$b;->J:Landroidx/collection/i;

    goto :goto_1c

    :cond_e
    new-instance p1, Landroidx/collection/f;

    invoke-direct {p1}, Landroidx/collection/f;-><init>()V

    iput-object p1, p0, Lg/a$b;->I:Landroidx/collection/f;

    new-instance p1, Landroidx/collection/i;

    invoke-direct {p1}, Landroidx/collection/i;-><init>()V

    iput-object p1, p0, Lg/a$b;->J:Landroidx/collection/i;

    :goto_1c
    return-void
.end method


# virtual methods
.method final i()V
    .registers 2

    iget-object v0, p0, Lg/a$b;->I:Landroidx/collection/f;

    invoke-virtual {v0}, Landroidx/collection/f;->c()Landroidx/collection/f;

    move-result-object v0

    iput-object v0, p0, Lg/a$b;->I:Landroidx/collection/f;

    iget-object v0, p0, Lg/a$b;->J:Landroidx/collection/i;

    invoke-virtual {v0}, Landroidx/collection/i;->c()Landroidx/collection/i;

    move-result-object v0

    iput-object v0, p0, Lg/a$b;->J:Landroidx/collection/i;

    return-void
.end method

.method final k(IILandroid/graphics/drawable/Drawable;Z)I
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Lg/b$c;->a(Landroid/graphics/drawable/Drawable;)I

    move-result v1

    move/from16 v2, p1

    int-to-long v2, v2

    const/16 v4, 0x20

    shl-long v5, v2, v4

    move/from16 v7, p2

    int-to-long v7, v7

    or-long/2addr v5, v7

    if-eqz p4, :cond_1b

    const-wide v9, 0x200000000L

    goto :goto_1d

    :cond_1b
    const-wide/16 v9, 0x0

    :goto_1d
    iget-object v11, v0, Lg/a$b;->I:Landroidx/collection/f;

    int-to-long v12, v1

    or-long v14, v12, v9

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    invoke-virtual {v11, v5, v6, v14}, Landroidx/collection/f;->a(JLjava/lang/Long;)V

    if-eqz p4, :cond_3e

    shl-long v4, v7, v4

    or-long/2addr v2, v4

    iget-object v4, v0, Lg/a$b;->I:Landroidx/collection/f;

    const-wide v5, 0x100000000L

    or-long/2addr v5, v12

    or-long/2addr v5, v9

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v4, v2, v3, v5}, Landroidx/collection/f;->a(JLjava/lang/Long;)V

    :cond_3e
    return v1
.end method

.method final l(II)I
    .registers 6

    int-to-long v0, p1

    const/16 p1, 0x20

    shl-long/2addr v0, p1

    int-to-long p1, p2

    or-long/2addr p1, v0

    iget-object v0, p0, Lg/a$b;->I:Landroidx/collection/f;

    const-wide/16 v1, -0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, p1, p2, v1}, Landroidx/collection/f;->f(JLjava/lang/Long;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    long-to-int p2, p1

    return p2
.end method

.method final m(II)Z
    .registers 6

    int-to-long v0, p1

    const/16 p1, 0x20

    shl-long/2addr v0, p1

    int-to-long p1, p2

    or-long/2addr p1, v0

    iget-object v0, p0, Lg/a$b;->I:Landroidx/collection/f;

    const-wide/16 v1, -0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, p1, p2, v1}, Landroidx/collection/f;->f(JLjava/lang/Long;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const-wide v0, 0x100000000L

    and-long/2addr p1, v0

    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-eqz v2, :cond_26

    const/4 p1, 0x1

    goto :goto_27

    :cond_26
    const/4 p1, 0x0

    :goto_27
    return p1
.end method

.method final n(II)Z
    .registers 6

    int-to-long v0, p1

    const/16 p1, 0x20

    shl-long/2addr v0, p1

    int-to-long p1, p2

    or-long/2addr p1, v0

    iget-object v0, p0, Lg/a$b;->I:Landroidx/collection/f;

    const-wide/16 v1, -0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, p1, p2, v1}, Landroidx/collection/f;->f(JLjava/lang/Long;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const-wide v0, 0x200000000L

    and-long/2addr p1, v0

    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-eqz v2, :cond_26

    const/4 p1, 0x1

    goto :goto_27

    :cond_26
    const/4 p1, 0x0

    :goto_27
    return p1
.end method

.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .registers 3

    new-instance v0, Lg/a;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lg/a;-><init>(Lg/a$b;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method public final newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .registers 3

    new-instance v0, Lg/a;

    invoke-direct {v0, p0, p1}, Lg/a;-><init>(Lg/a$b;Landroid/content/res/Resources;)V

    return-object v0
.end method
