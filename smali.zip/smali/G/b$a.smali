.class final Lg/b$a;
.super Ljava/lang/Object;
.source "DrawableContainer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lg/b;->e(I)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lg/b;


# direct methods
.method constructor <init>(Lg/d;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg/b$a;->a:Lg/b;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    const/4 v0, 0x1

    iget-object v1, p0, Lg/b$a;->a:Lg/b;

    invoke-virtual {v1, v0}, Lg/b;->a(Z)V

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method
