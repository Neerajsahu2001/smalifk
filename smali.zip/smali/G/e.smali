.class public final LG/e;
.super Ljava/lang/Object;


# static fields
.field public static final accessibility_action_clickable_span:I = 0x7f0b000b

.field public static final accessibility_custom_action_0:I = 0x7f0b000f

.field public static final accessibility_custom_action_1:I = 0x7f0b0010

.field public static final accessibility_custom_action_10:I = 0x7f0b0011

.field public static final accessibility_custom_action_11:I = 0x7f0b0012

.field public static final accessibility_custom_action_12:I = 0x7f0b0013

.field public static final accessibility_custom_action_13:I = 0x7f0b0014

.field public static final accessibility_custom_action_14:I = 0x7f0b0015

.field public static final accessibility_custom_action_15:I = 0x7f0b0016

.field public static final accessibility_custom_action_16:I = 0x7f0b0017

.field public static final accessibility_custom_action_17:I = 0x7f0b0018

.field public static final accessibility_custom_action_18:I = 0x7f0b0019

.field public static final accessibility_custom_action_19:I = 0x7f0b001a

.field public static final accessibility_custom_action_2:I = 0x7f0b001b

.field public static final accessibility_custom_action_20:I = 0x7f0b001c

.field public static final accessibility_custom_action_21:I = 0x7f0b001d

.field public static final accessibility_custom_action_22:I = 0x7f0b001e

.field public static final accessibility_custom_action_23:I = 0x7f0b001f

.field public static final accessibility_custom_action_24:I = 0x7f0b0020

.field public static final accessibility_custom_action_25:I = 0x7f0b0021

.field public static final accessibility_custom_action_26:I = 0x7f0b0022

.field public static final accessibility_custom_action_27:I = 0x7f0b0023

.field public static final accessibility_custom_action_28:I = 0x7f0b0024

.field public static final accessibility_custom_action_29:I = 0x7f0b0025

.field public static final accessibility_custom_action_3:I = 0x7f0b0026

.field public static final accessibility_custom_action_30:I = 0x7f0b0027

.field public static final accessibility_custom_action_31:I = 0x7f0b0028

.field public static final accessibility_custom_action_4:I = 0x7f0b0029

.field public static final accessibility_custom_action_5:I = 0x7f0b002a

.field public static final accessibility_custom_action_6:I = 0x7f0b002b

.field public static final accessibility_custom_action_7:I = 0x7f0b002c

.field public static final accessibility_custom_action_8:I = 0x7f0b002d

.field public static final accessibility_custom_action_9:I = 0x7f0b002e

.field public static final action_container:I = 0x7f0b0045

.field public static final action_divider:I = 0x7f0b0049

.field public static final action_image:I = 0x7f0b004b

.field public static final action_text:I = 0x7f0b0055

.field public static final actions:I = 0x7f0b0057

.field public static final async:I = 0x7f0b0089

.field public static final blocking:I = 0x7f0b00a9

.field public static final chronometer:I = 0x7f0b019c

.field public static final dialog_button:I = 0x7f0b020d

.field public static final forever:I = 0x7f0b02f0

.field public static final icon:I = 0x7f0b034d

.field public static final icon_group:I = 0x7f0b0350

.field public static final info:I = 0x7f0b0397

.field public static final italic:I = 0x7f0b03aa

.field public static final line1:I = 0x7f0b03ef

.field public static final line3:I = 0x7f0b03f0

.field public static final normal:I = 0x7f0b0470

.field public static final notification_background:I = 0x7f0b0474

.field public static final notification_main_column:I = 0x7f0b0476

.field public static final notification_main_column_container:I = 0x7f0b0477

.field public static final right_icon:I = 0x7f0b05f5

.field public static final right_side:I = 0x7f0b05f8

.field public static final tag_accessibility_actions:I = 0x7f0b06e0

.field public static final tag_accessibility_clickable_spans:I = 0x7f0b06e1

.field public static final tag_accessibility_heading:I = 0x7f0b06e2

.field public static final tag_accessibility_pane_title:I = 0x7f0b06e3

.field public static final tag_on_apply_window_listener:I = 0x7f0b06e7

.field public static final tag_on_receive_content_listener:I = 0x7f0b06e8

.field public static final tag_on_receive_content_mime_types:I = 0x7f0b06e9

.field public static final tag_screen_reader_focusable:I = 0x7f0b06ea

.field public static final tag_state_description:I = 0x7f0b06eb

.field public static final tag_transition_group:I = 0x7f0b06ec

.field public static final tag_unhandled_key_event_manager:I = 0x7f0b06ed

.field public static final tag_unhandled_key_listeners:I = 0x7f0b06ee

.field public static final tag_window_insets_animation_callback:I = 0x7f0b06ef

.field public static final text:I = 0x7f0b06f5

.field public static final text2:I = 0x7f0b06f7

.field public static final time:I = 0x7f0b0727

.field public static final title:I = 0x7f0b0733
