.class Lg/d;
.super Lg/b;
.source "StateListDrawable.java"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "RestrictedAPI"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lg/d$a;
    }
.end annotation


# instance fields
.field private n:Lg/d$a;

.field private o:Z


# direct methods
.method constructor <init>(Lg/d$a;Landroid/content/res/Resources;)V
    .registers 4

    invoke-direct {p0}, Lg/b;-><init>()V

    new-instance v0, Lg/d$a;

    invoke-direct {v0, p1, p0, p2}, Lg/d$a;-><init>(Lg/d$a;Lg/d;Landroid/content/res/Resources;)V

    invoke-virtual {p0, v0}, Lg/d;->f(Lg/b$c;)V

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    invoke-virtual {p0, p1}, Lg/d;->onStateChange([I)Z

    return-void
.end method


# virtual methods
.method public applyTheme(Landroid/content/res/Resources$Theme;)V
    .registers 2

    invoke-super {p0, p1}, Lg/b;->applyTheme(Landroid/content/res/Resources$Theme;)V

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    invoke-virtual {p0, p1}, Lg/d;->onStateChange([I)Z

    return-void
.end method

.method bridge synthetic b()Lg/b$c;
    .registers 2

    invoke-virtual {p0}, Lg/d;->h()Lg/d$a;

    move-result-object v0

    return-object v0
.end method

.method f(Lg/b$c;)V
    .registers 3

    invoke-super {p0, p1}, Lg/b;->f(Lg/b$c;)V

    instance-of v0, p1, Lg/d$a;

    if-eqz v0, :cond_b

    check-cast p1, Lg/d$a;

    iput-object p1, p0, Lg/d;->n:Lg/d$a;

    :cond_b
    return-void
.end method

.method h()Lg/d$a;
    .registers 4

    new-instance v0, Lg/d$a;

    iget-object v1, p0, Lg/d;->n:Lg/d$a;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lg/d$a;-><init>(Lg/d$a;Lg/d;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method public isStateful()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public mutate()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-boolean v0, p0, Lg/d;->o:Z

    if-nez v0, :cond_f

    invoke-super {p0}, Lg/b;->mutate()Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, Lg/d;->n:Lg/d$a;

    invoke-virtual {v0}, Lg/d$a;->i()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/d;->o:Z

    :cond_f
    return-object p0
.end method

.method protected onStateChange([I)Z
    .registers 4

    invoke-super {p0, p1}, Lg/b;->onStateChange([I)Z

    move-result v0

    iget-object v1, p0, Lg/d;->n:Lg/d$a;

    invoke-virtual {v1, p1}, Lg/d$a;->j([I)I

    move-result p1

    if-gez p1, :cond_14

    iget-object p1, p0, Lg/d;->n:Lg/d$a;

    sget-object v1, Landroid/util/StateSet;->WILD_CARD:[I

    invoke-virtual {p1, v1}, Lg/d$a;->j([I)I

    move-result p1

    :cond_14
    invoke-virtual {p0, p1}, Lg/b;->e(I)Z

    move-result p1

    if-nez p1, :cond_1f

    if-eqz v0, :cond_1d

    goto :goto_1f

    :cond_1d
    const/4 p1, 0x0

    goto :goto_20

    :cond_1f
    :goto_1f
    const/4 p1, 0x1

    :goto_20
    return p1
.end method
