.class abstract Lg/b$c;
.super Landroid/graphics/drawable/Drawable$ConstantState;
.source "DrawableContainer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "c"
.end annotation


# instance fields
.field A:Z

.field B:Landroid/graphics/ColorFilter;

.field C:Z

.field D:Landroid/content/res/ColorStateList;

.field E:Landroid/graphics/PorterDuff$Mode;

.field F:Z

.field G:Z

.field final a:Lg/b;

.field b:Landroid/content/res/Resources;

.field c:I

.field d:I

.field e:I

.field f:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Landroid/graphics/drawable/Drawable$ConstantState;",
            ">;"
        }
    .end annotation
.end field

.field g:[Landroid/graphics/drawable/Drawable;

.field h:I

.field i:Z

.field j:Z

.field k:Landroid/graphics/Rect;

.field l:Z

.field m:Z

.field n:I

.field o:I

.field p:I

.field q:I

.field r:Z

.field s:I

.field t:Z

.field u:Z

.field v:Z

.field w:Z

.field x:I

.field y:I

.field z:I


# direct methods
.method constructor <init>(Lg/b$c;Lg/b;Landroid/content/res/Resources;)V
    .registers 8

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lg/b$c;->i:Z

    iput-boolean v0, p0, Lg/b$c;->l:Z

    const/4 v1, 0x1

    iput-boolean v1, p0, Lg/b$c;->w:Z

    iput v0, p0, Lg/b$c;->y:I

    iput v0, p0, Lg/b$c;->z:I

    iput-object p2, p0, Lg/b$c;->a:Lg/b;

    const/4 p2, 0x0

    if-eqz p3, :cond_16

    move-object v2, p3

    goto :goto_1c

    :cond_16
    if-eqz p1, :cond_1b

    iget-object v2, p1, Lg/b$c;->b:Landroid/content/res/Resources;

    goto :goto_1c

    :cond_1b
    move-object v2, p2

    :goto_1c
    iput-object v2, p0, Lg/b$c;->b:Landroid/content/res/Resources;

    if-eqz p1, :cond_23

    iget v2, p1, Lg/b$c;->c:I

    goto :goto_24

    :cond_23
    const/4 v2, 0x0

    :goto_24
    sget v3, Lg/b;->m:I

    if-nez p3, :cond_29

    goto :goto_2f

    :cond_29
    invoke-virtual {p3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p3

    iget v2, p3, Landroid/util/DisplayMetrics;->densityDpi:I

    :goto_2f
    if-nez v2, :cond_33

    const/16 v2, 0xa0

    :cond_33
    iput v2, p0, Lg/b$c;->c:I

    if-eqz p1, :cond_f0

    iget p3, p1, Lg/b$c;->d:I

    iput p3, p0, Lg/b$c;->d:I

    iget p3, p1, Lg/b$c;->e:I

    iput p3, p0, Lg/b$c;->e:I

    iput-boolean v1, p0, Lg/b$c;->u:Z

    iput-boolean v1, p0, Lg/b$c;->v:Z

    iget-boolean p3, p1, Lg/b$c;->i:Z

    iput-boolean p3, p0, Lg/b$c;->i:Z

    iget-boolean p3, p1, Lg/b$c;->l:Z

    iput-boolean p3, p0, Lg/b$c;->l:Z

    iget-boolean p3, p1, Lg/b$c;->w:Z

    iput-boolean p3, p0, Lg/b$c;->w:Z

    iget p3, p1, Lg/b$c;->x:I

    iput p3, p0, Lg/b$c;->x:I

    iget p3, p1, Lg/b$c;->y:I

    iput p3, p0, Lg/b$c;->y:I

    iget p3, p1, Lg/b$c;->z:I

    iput p3, p0, Lg/b$c;->z:I

    iget-boolean p3, p1, Lg/b$c;->A:Z

    iput-boolean p3, p0, Lg/b$c;->A:Z

    iget-object p3, p1, Lg/b$c;->B:Landroid/graphics/ColorFilter;

    iput-object p3, p0, Lg/b$c;->B:Landroid/graphics/ColorFilter;

    iget-boolean p3, p1, Lg/b$c;->C:Z

    iput-boolean p3, p0, Lg/b$c;->C:Z

    iget-object p3, p1, Lg/b$c;->D:Landroid/content/res/ColorStateList;

    iput-object p3, p0, Lg/b$c;->D:Landroid/content/res/ColorStateList;

    iget-object p3, p1, Lg/b$c;->E:Landroid/graphics/PorterDuff$Mode;

    iput-object p3, p0, Lg/b$c;->E:Landroid/graphics/PorterDuff$Mode;

    iget-boolean p3, p1, Lg/b$c;->F:Z

    iput-boolean p3, p0, Lg/b$c;->F:Z

    iget-boolean p3, p1, Lg/b$c;->G:Z

    iput-boolean p3, p0, Lg/b$c;->G:Z

    iget p3, p1, Lg/b$c;->c:I

    if-ne p3, v2, :cond_a4

    iget-boolean p3, p1, Lg/b$c;->j:Z

    if-eqz p3, :cond_8e

    iget-object p3, p1, Lg/b$c;->k:Landroid/graphics/Rect;

    if-eqz p3, :cond_8a

    new-instance p2, Landroid/graphics/Rect;

    iget-object p3, p1, Lg/b$c;->k:Landroid/graphics/Rect;

    invoke-direct {p2, p3}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    :cond_8a
    iput-object p2, p0, Lg/b$c;->k:Landroid/graphics/Rect;

    iput-boolean v1, p0, Lg/b$c;->j:Z

    :cond_8e
    iget-boolean p2, p1, Lg/b$c;->m:Z

    if-eqz p2, :cond_a4

    iget p2, p1, Lg/b$c;->n:I

    iput p2, p0, Lg/b$c;->n:I

    iget p2, p1, Lg/b$c;->o:I

    iput p2, p0, Lg/b$c;->o:I

    iget p2, p1, Lg/b$c;->p:I

    iput p2, p0, Lg/b$c;->p:I

    iget p2, p1, Lg/b$c;->q:I

    iput p2, p0, Lg/b$c;->q:I

    iput-boolean v1, p0, Lg/b$c;->m:Z

    :cond_a4
    iget-boolean p2, p1, Lg/b$c;->r:Z

    if-eqz p2, :cond_ae

    iget p2, p1, Lg/b$c;->s:I

    iput p2, p0, Lg/b$c;->s:I

    iput-boolean v1, p0, Lg/b$c;->r:Z

    :cond_ae
    iget-boolean p2, p1, Lg/b$c;->t:Z

    if-eqz p2, :cond_b4

    iput-boolean v1, p0, Lg/b$c;->t:Z

    :cond_b4
    iget-object p2, p1, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    array-length p3, p2

    new-array p3, p3, [Landroid/graphics/drawable/Drawable;

    iput-object p3, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    iget p3, p1, Lg/b$c;->h:I

    iput p3, p0, Lg/b$c;->h:I

    iget-object p1, p1, Lg/b$c;->f:Landroid/util/SparseArray;

    if-eqz p1, :cond_ca

    invoke-virtual {p1}, Landroid/util/SparseArray;->clone()Landroid/util/SparseArray;

    move-result-object p1

    iput-object p1, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    goto :goto_d3

    :cond_ca
    new-instance p1, Landroid/util/SparseArray;

    iget p3, p0, Lg/b$c;->h:I

    invoke-direct {p1, p3}, Landroid/util/SparseArray;-><init>(I)V

    iput-object p1, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    :goto_d3
    iget p1, p0, Lg/b$c;->h:I

    :goto_d5
    if-ge v0, p1, :cond_f8

    aget-object p3, p2, v0

    if-eqz p3, :cond_ed

    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object p3

    if-eqz p3, :cond_e7

    iget-object v1, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    invoke-virtual {v1, v0, p3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto :goto_ed

    :cond_e7
    iget-object p3, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    aget-object v1, p2, v0

    aput-object v1, p3, v0

    :cond_ed
    :goto_ed
    add-int/lit8 v0, v0, 0x1

    goto :goto_d5

    :cond_f0
    const/16 p1, 0xa

    new-array p1, p1, [Landroid/graphics/drawable/Drawable;

    iput-object p1, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    iput v0, p0, Lg/b$c;->h:I

    :cond_f8
    return-void
.end method

.method private e()V
    .registers 8

    iget-object v0, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    if-eqz v0, :cond_3d

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_9
    if-ge v1, v0, :cond_3a

    iget-object v2, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    iget-object v3, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/drawable/Drawable$ConstantState;

    iget-object v4, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    iget-object v5, p0, Lg/b$c;->b:Landroid/content/res/Resources;

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0x17

    if-lt v5, v6, :cond_2c

    iget v5, p0, Lg/b$c;->x:I

    invoke-static {v3, v5}, Landroidx/core/graphics/drawable/a;->l(Landroid/graphics/drawable/Drawable;I)Z

    :cond_2c
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    iget-object v5, p0, Lg/b$c;->a:Lg/b;

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    aput-object v3, v4, v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_3a
    const/4 v0, 0x0

    iput-object v0, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    :cond_3d
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;)I
    .registers 8

    iget v0, p0, Lg/b$c;->h:I

    iget-object v1, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    array-length v1, v1

    const/4 v2, 0x0

    if-lt v0, v1, :cond_21

    add-int/lit8 v1, v0, 0xa

    move-object v3, p0

    check-cast v3, Lg/d$a;

    new-array v4, v1, [Landroid/graphics/drawable/Drawable;

    iget-object v5, v3, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    if-eqz v5, :cond_16

    invoke-static {v5, v2, v4, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_16
    iput-object v4, v3, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    new-array v1, v1, [[I

    iget-object v4, v3, Lg/d$a;->H:[[I

    invoke-static {v4, v2, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v1, v3, Lg/d$a;->H:[[I

    :cond_21
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x1

    invoke-virtual {p1, v2, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    iget-object v3, p0, Lg/b$c;->a:Lg/b;

    invoke-virtual {p1, v3}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    iget-object v3, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    aput-object p1, v3, v0

    iget v3, p0, Lg/b$c;->h:I

    add-int/2addr v3, v1

    iput v3, p0, Lg/b$c;->h:I

    iget v1, p0, Lg/b$c;->e:I

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result p1

    or-int/2addr p1, v1

    iput p1, p0, Lg/b$c;->e:I

    iput-boolean v2, p0, Lg/b$c;->r:Z

    iput-boolean v2, p0, Lg/b$c;->t:Z

    const/4 p1, 0x0

    iput-object p1, p0, Lg/b$c;->k:Landroid/graphics/Rect;

    iput-boolean v2, p0, Lg/b$c;->j:Z

    iput-boolean v2, p0, Lg/b$c;->m:Z

    iput-boolean v2, p0, Lg/b$c;->u:Z

    return v0
.end method

.method final b(Landroid/content/res/Resources$Theme;)V
    .registers 8

    if-eqz p1, :cond_48

    invoke-direct {p0}, Lg/b$c;->e()V

    iget v0, p0, Lg/b$c;->h:I

    iget-object v1, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v0, :cond_2a

    aget-object v4, v1, v3

    if-eqz v4, :cond_27

    invoke-static {v4}, Landroidx/core/graphics/drawable/a;->b(Landroid/graphics/drawable/Drawable;)Z

    move-result v4

    if-eqz v4, :cond_27

    aget-object v4, v1, v3

    invoke-static {v4, p1}, Landroidx/core/graphics/drawable/a;->a(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources$Theme;)V

    iget v4, p0, Lg/b$c;->e:I

    aget-object v5, v1, v3

    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result v5

    or-int/2addr v4, v5

    iput v4, p0, Lg/b$c;->e:I

    :cond_27
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_2a
    invoke-virtual {p1}, Landroid/content/res/Resources$Theme;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    if-eqz p1, :cond_48

    iput-object p1, p0, Lg/b$c;->b:Landroid/content/res/Resources;

    sget v0, Lg/b;->m:I

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    if-nez p1, :cond_3e

    const/16 p1, 0xa0

    :cond_3e
    iget v0, p0, Lg/b$c;->c:I

    iput p1, p0, Lg/b$c;->c:I

    if-eq v0, p1, :cond_48

    iput-boolean v2, p0, Lg/b$c;->m:Z

    iput-boolean v2, p0, Lg/b$c;->j:Z

    :cond_48
    return-void
.end method

.method public final c()Z
    .registers 7

    iget-boolean v0, p0, Lg/b$c;->u:Z

    if-eqz v0, :cond_7

    iget-boolean v0, p0, Lg/b$c;->v:Z

    return v0

    :cond_7
    invoke-direct {p0}, Lg/b$c;->e()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/b$c;->u:Z

    iget v1, p0, Lg/b$c;->h:I

    iget-object v2, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_13
    if-ge v4, v1, :cond_23

    aget-object v5, v2, v4

    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v5

    if-nez v5, :cond_20

    iput-boolean v3, p0, Lg/b$c;->v:Z

    return v3

    :cond_20
    add-int/lit8 v4, v4, 0x1

    goto :goto_13

    :cond_23
    iput-boolean v0, p0, Lg/b$c;->v:Z

    return v0
.end method

.method public final canApplyTheme()Z
    .registers 7

    iget v0, p0, Lg/b$c;->h:I

    iget-object v1, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_6
    if-ge v3, v0, :cond_28

    aget-object v4, v1, v3

    const/4 v5, 0x1

    if-eqz v4, :cond_14

    invoke-static {v4}, Landroidx/core/graphics/drawable/a;->b(Landroid/graphics/drawable/Drawable;)Z

    move-result v4

    if-eqz v4, :cond_25

    return v5

    :cond_14
    iget-object v4, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    invoke-virtual {v4, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/drawable/Drawable$ConstantState;

    if-eqz v4, :cond_25

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable$ConstantState;->canApplyTheme()Z

    move-result v4

    if-eqz v4, :cond_25

    return v5

    :cond_25
    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    :cond_28
    return v2
.end method

.method protected final d()V
    .registers 7

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/b$c;->m:Z

    invoke-direct {p0}, Lg/b$c;->e()V

    iget v0, p0, Lg/b$c;->h:I

    iget-object v1, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v2, -0x1

    iput v2, p0, Lg/b$c;->o:I

    iput v2, p0, Lg/b$c;->n:I

    const/4 v2, 0x0

    iput v2, p0, Lg/b$c;->q:I

    iput v2, p0, Lg/b$c;->p:I

    :goto_14
    if-ge v2, v0, :cond_43

    aget-object v3, v1, v2

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v4

    iget v5, p0, Lg/b$c;->n:I

    if-le v4, v5, :cond_22

    iput v4, p0, Lg/b$c;->n:I

    :cond_22
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v4

    iget v5, p0, Lg/b$c;->o:I

    if-le v4, v5, :cond_2c

    iput v4, p0, Lg/b$c;->o:I

    :cond_2c
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getMinimumWidth()I

    move-result v4

    iget v5, p0, Lg/b$c;->p:I

    if-le v4, v5, :cond_36

    iput v4, p0, Lg/b$c;->p:I

    :cond_36
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    move-result v3

    iget v4, p0, Lg/b$c;->q:I

    if-le v3, v4, :cond_40

    iput v3, p0, Lg/b$c;->q:I

    :cond_40
    add-int/lit8 v2, v2, 0x1

    goto :goto_14

    :cond_43
    return-void
.end method

.method public final f(I)Landroid/graphics/drawable/Drawable;
    .registers 7

    iget-object v0, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    aget-object v0, v0, p1

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    iget-object v0, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    const/4 v1, 0x0

    if-eqz v0, :cond_48

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v0

    if-ltz v0, :cond_48

    iget-object v2, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable$ConstantState;

    iget-object v3, p0, Lg/b$c;->b:Landroid/content/res/Resources;

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x17

    if-lt v3, v4, :cond_2b

    iget v3, p0, Lg/b$c;->x:I

    invoke-static {v2, v3}, Landroidx/core/graphics/drawable/a;->l(Landroid/graphics/drawable/Drawable;I)Z

    :cond_2b
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    iget-object v3, p0, Lg/b$c;->a:Lg/b;

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    iget-object v3, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    aput-object v2, v3, p1

    iget-object p1, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    invoke-virtual {p1, v0}, Landroid/util/SparseArray;->removeAt(I)V

    iget-object p1, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result p1

    if-nez p1, :cond_47

    iput-object v1, p0, Lg/b$c;->f:Landroid/util/SparseArray;

    :cond_47
    return-object v2

    :cond_48
    return-object v1
.end method

.method public final g()Landroid/graphics/Rect;
    .registers 9

    iget-boolean v0, p0, Lg/b$c;->i:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    return-object v1

    :cond_6
    iget-object v0, p0, Lg/b$c;->k:Landroid/graphics/Rect;

    if-nez v0, :cond_57

    iget-boolean v2, p0, Lg/b$c;->j:Z

    if-eqz v2, :cond_f

    goto :goto_57

    :cond_f
    invoke-direct {p0}, Lg/b$c;->e()V

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iget v2, p0, Lg/b$c;->h:I

    iget-object v3, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_1d
    if-ge v5, v2, :cond_51

    aget-object v6, v3, v5

    invoke-virtual {v6, v0}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    move-result v6

    if-eqz v6, :cond_4e

    if-nez v1, :cond_2e

    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1, v4, v4, v4, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    :cond_2e
    iget v6, v0, Landroid/graphics/Rect;->left:I

    iget v7, v1, Landroid/graphics/Rect;->left:I

    if-le v6, v7, :cond_36

    iput v6, v1, Landroid/graphics/Rect;->left:I

    :cond_36
    iget v6, v0, Landroid/graphics/Rect;->top:I

    iget v7, v1, Landroid/graphics/Rect;->top:I

    if-le v6, v7, :cond_3e

    iput v6, v1, Landroid/graphics/Rect;->top:I

    :cond_3e
    iget v6, v0, Landroid/graphics/Rect;->right:I

    iget v7, v1, Landroid/graphics/Rect;->right:I

    if-le v6, v7, :cond_46

    iput v6, v1, Landroid/graphics/Rect;->right:I

    :cond_46
    iget v6, v0, Landroid/graphics/Rect;->bottom:I

    iget v7, v1, Landroid/graphics/Rect;->bottom:I

    if-le v6, v7, :cond_4e

    iput v6, v1, Landroid/graphics/Rect;->bottom:I

    :cond_4e
    add-int/lit8 v5, v5, 0x1

    goto :goto_1d

    :cond_51
    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/b$c;->j:Z

    iput-object v1, p0, Lg/b$c;->k:Landroid/graphics/Rect;

    return-object v1

    :cond_57
    :goto_57
    return-object v0
.end method

.method public final getChangingConfigurations()I
    .registers 3

    iget v0, p0, Lg/b$c;->d:I

    iget v1, p0, Lg/b$c;->e:I

    or-int/2addr v0, v1

    return v0
.end method

.method public final h()I
    .registers 7

    iget-boolean v0, p0, Lg/b$c;->r:Z

    if-eqz v0, :cond_7

    iget v0, p0, Lg/b$c;->s:I

    return v0

    :cond_7
    invoke-direct {p0}, Lg/b$c;->e()V

    iget v0, p0, Lg/b$c;->h:I

    iget-object v1, p0, Lg/b$c;->g:[Landroid/graphics/drawable/Drawable;

    if-lez v0, :cond_18

    const/4 v2, 0x0

    aget-object v2, v1, v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getOpacity()I

    move-result v2

    goto :goto_19

    :cond_18
    const/4 v2, -0x2

    :goto_19
    const/4 v3, 0x1

    const/4 v4, 0x1

    :goto_1b
    if-ge v4, v0, :cond_2a

    aget-object v5, v1, v4

    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getOpacity()I

    move-result v5

    invoke-static {v2, v5}, Landroid/graphics/drawable/Drawable;->resolveOpacity(II)I

    move-result v2

    add-int/lit8 v4, v4, 0x1

    goto :goto_1b

    :cond_2a
    iput v2, p0, Lg/b$c;->s:I

    iput-boolean v3, p0, Lg/b$c;->r:Z

    return v2
.end method

.method abstract i()V
.end method
