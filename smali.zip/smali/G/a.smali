.class public final Lg/a;
.super Lg/d;
.source "AnimatedStateListDrawableCompat.java"

# interfaces
.implements Landroidx/core/graphics/drawable/e;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "RestrictedAPI"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lg/a$e;,
        Lg/a$b;,
        Lg/a$c;,
        Lg/a$d;,
        Lg/a$a;,
        Lg/a$f;
    }
.end annotation


# instance fields
.field private p:Lg/a$b;

.field private q:Lg/a$f;

.field private r:I

.field private s:I

.field private t:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0, v0, v0}, Lg/a;-><init>(Lg/a$b;Landroid/content/res/Resources;)V

    return-void
.end method

.method constructor <init>(Lg/a$b;Landroid/content/res/Resources;)V
    .registers 4

    invoke-direct {p0}, Lg/b;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lg/a;->r:I

    iput v0, p0, Lg/a;->s:I

    new-instance v0, Lg/a$b;

    invoke-direct {v0, p1, p0, p2}, Lg/a$b;-><init>(Lg/a$b;Lg/a;Landroid/content/res/Resources;)V

    invoke-virtual {p0, v0}, Lg/a;->f(Lg/b$c;)V

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    invoke-virtual {p0, p1}, Lg/a;->onStateChange([I)Z

    invoke-virtual {p0}, Lg/a;->jumpToCurrentState()V

    return-void
.end method

.method public static i(Landroid/content/Context;Landroid/content/res/Resources$Theme;Landroid/content/res/Resources;Landroid/util/AttributeSet;Landroid/content/res/XmlResourceParser;)Lg/a;
    .registers 22
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lorg/xmlpull/v1/XmlPullParserException;
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v5

    const-string v6, "animated-selector"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_214

    new-instance v5, Lg/a;

    invoke-direct {v5}, Lg/a;-><init>()V

    sget-object v6, Lh/d;->AnimatedStateListDrawableCompat:[I

    invoke-static {v2, v1, v3, v6}, Landroidx/core/content/res/j;->e(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v6

    sget v7, Lh/d;->AnimatedStateListDrawableCompat_android_visible:I

    const/4 v8, 0x1

    invoke-virtual {v6, v7, v8}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v7

    invoke-virtual {v5, v7, v8}, Lg/a;->setVisible(ZZ)Z

    iget-object v7, v5, Lg/a;->p:Lg/a$b;

    iget v9, v7, Lg/b$c;->d:I

    invoke-static {v6}, Lh/b;->b(Landroid/content/res/TypedArray;)I

    move-result v10

    or-int/2addr v9, v10

    iput v9, v7, Lg/b$c;->d:I

    sget v9, Lh/d;->AnimatedStateListDrawableCompat_android_variablePadding:I

    iget-boolean v10, v7, Lg/b$c;->i:Z

    invoke-virtual {v6, v9, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v9

    iput-boolean v9, v7, Lg/b$c;->i:Z

    sget v9, Lh/d;->AnimatedStateListDrawableCompat_android_constantSize:I

    iget-boolean v10, v7, Lg/b$c;->l:Z

    invoke-virtual {v6, v9, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v9

    iput-boolean v9, v7, Lg/b$c;->l:Z

    sget v9, Lh/d;->AnimatedStateListDrawableCompat_android_enterFadeDuration:I

    iget v10, v7, Lg/b$c;->y:I

    invoke-virtual {v6, v9, v10}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v9

    iput v9, v7, Lg/b$c;->y:I

    sget v9, Lh/d;->AnimatedStateListDrawableCompat_android_exitFadeDuration:I

    iget v10, v7, Lg/b$c;->z:I

    invoke-virtual {v6, v9, v10}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v9

    iput v9, v7, Lg/b$c;->z:I

    sget v9, Lh/d;->AnimatedStateListDrawableCompat_android_dither:I

    iget-boolean v7, v7, Lg/b$c;->w:Z

    invoke-virtual {v6, v9, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v7

    invoke-super {v5, v7}, Lg/b;->setDither(Z)V

    invoke-virtual {v5, v2}, Lg/b;->g(Landroid/content/res/Resources;)V

    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v6

    add-int/2addr v6, v8

    :goto_74
    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v7

    if-eq v7, v8, :cond_20c

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v9

    if-ge v9, v6, :cond_83

    const/4 v10, 0x3

    if-eq v7, v10, :cond_20c

    :cond_83
    const/4 v10, 0x2

    if-eq v7, v10, :cond_87

    goto :goto_74

    :cond_87
    if-le v9, v6, :cond_8a

    goto :goto_74

    :cond_8a
    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v7

    const-string v9, "item"

    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v11, 0x0

    const/4 v12, -0x1

    const/4 v13, 0x0

    if-eqz v7, :cond_156

    sget-object v7, Lh/d;->AnimatedStateListDrawableItem:[I

    invoke-static {v2, v1, v3, v7}, Landroidx/core/content/res/j;->e(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v7

    sget v14, Lh/d;->AnimatedStateListDrawableItem_android_id:I

    invoke-virtual {v7, v14, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v14

    sget v15, Lh/d;->AnimatedStateListDrawableItem_android_drawable:I

    invoke-virtual {v7, v15, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v12

    if-lez v12, :cond_b5

    invoke-static {}, Landroidx/appcompat/widget/a0;->d()Landroidx/appcompat/widget/a0;

    move-result-object v11

    invoke-virtual {v11, v0, v12}, Landroidx/appcompat/widget/a0;->f(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    :cond_b5
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->recycle()V

    invoke-interface/range {p3 .. p3}, Landroid/util/AttributeSet;->getAttributeCount()I

    move-result v7

    new-array v12, v7, [I

    const/4 v8, 0x0

    const/4 v15, 0x0

    :goto_c0
    if-ge v15, v7, :cond_e3

    invoke-interface {v3, v15}, Landroid/util/AttributeSet;->getAttributeNameResource(I)I

    move-result v10

    if-eqz v10, :cond_df

    const v9, 0x10100d0

    if-eq v10, v9, :cond_df

    const v9, 0x1010199

    if-eq v10, v9, :cond_df

    add-int/lit8 v9, v8, 0x1

    invoke-interface {v3, v15, v13}, Landroid/util/AttributeSet;->getAttributeBooleanValue(IZ)Z

    move-result v16

    if-eqz v16, :cond_db

    goto :goto_dc

    :cond_db
    neg-int v10, v10

    :goto_dc
    aput v10, v12, v8

    move v8, v9

    :cond_df
    add-int/lit8 v15, v15, 0x1

    const/4 v10, 0x2

    goto :goto_c0

    :cond_e3
    invoke-static {v12, v8}, Landroid/util/StateSet;->trimStateSet([II)[I

    move-result-object v7

    const-string v8, ": <item> tag requires a \'drawable\' attribute or child tag defining a drawable"

    if-nez v11, :cond_125

    :goto_eb
    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v9

    const/4 v10, 0x4

    if-ne v9, v10, :cond_f3

    goto :goto_eb

    :cond_f3
    const/4 v10, 0x2

    if-ne v9, v10, :cond_10c

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v9

    const-string v10, "vector"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_107

    invoke-static {v2, v4, v3, v1}, Landroidx/vectordrawable/graphics/drawable/f;->a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/vectordrawable/graphics/drawable/f;

    move-result-object v11

    goto :goto_125

    :cond_107
    invoke-static {v2, v4, v3, v1}, Lh/b;->a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    goto :goto_125

    :cond_10c
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_125
    :goto_125
    if-eqz v11, :cond_13d

    iget-object v8, v5, Lg/a;->p:Lg/a$b;

    invoke-virtual {v8, v11}, Lg/b$c;->a(Landroid/graphics/drawable/Drawable;)I

    move-result v9

    iget-object v10, v8, Lg/d$a;->H:[[I

    aput-object v7, v10, v9

    iget-object v7, v8, Lg/a$b;->J:Landroidx/collection/i;

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v7, v9, v8}, Landroidx/collection/i;->i(ILjava/lang/Object;)V

    :cond_13a
    :goto_13a
    const/4 v8, 0x1

    goto/16 :goto_74

    :cond_13d
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_156
    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v7

    const-string v8, "transition"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_13a

    sget-object v7, Lh/d;->AnimatedStateListDrawableTransition:[I

    invoke-static {v2, v1, v3, v7}, Landroidx/core/content/res/j;->e(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v7

    sget v8, Lh/d;->AnimatedStateListDrawableTransition_android_fromId:I

    invoke-virtual {v7, v8, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    sget v9, Lh/d;->AnimatedStateListDrawableTransition_android_toId:I

    invoke-virtual {v7, v9, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v9

    sget v10, Lh/d;->AnimatedStateListDrawableTransition_android_drawable:I

    invoke-virtual {v7, v10, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v10

    if-lez v10, :cond_184

    invoke-static {}, Landroidx/appcompat/widget/a0;->d()Landroidx/appcompat/widget/a0;

    move-result-object v11

    invoke-virtual {v11, v0, v10}, Landroidx/appcompat/widget/a0;->f(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    :cond_184
    sget v10, Lh/d;->AnimatedStateListDrawableTransition_android_reversible:I

    invoke-virtual {v7, v10, v13}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v10

    invoke-virtual {v7}, Landroid/content/res/TypedArray;->recycle()V

    const-string v7, ": <transition> tag requires a \'drawable\' attribute or child tag defining a drawable"

    if-nez v11, :cond_1cb

    :goto_191
    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v11

    const/4 v13, 0x4

    if-ne v11, v13, :cond_199

    goto :goto_191

    :cond_199
    const/4 v14, 0x2

    if-ne v11, v14, :cond_1b2

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v11

    const-string v13, "animated-vector"

    invoke-virtual {v11, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_1ad

    invoke-static/range {p0 .. p4}, Landroidx/vectordrawable/graphics/drawable/b;->a(Landroid/content/Context;Landroid/content/res/Resources$Theme;Landroid/content/res/Resources;Landroid/util/AttributeSet;Landroid/content/res/XmlResourceParser;)Landroidx/vectordrawable/graphics/drawable/b;

    move-result-object v11

    goto :goto_1cb

    :cond_1ad
    invoke-static {v2, v4, v3, v1}, Lh/b;->a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    goto :goto_1cb

    :cond_1b2
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1cb
    :goto_1cb
    if-eqz v11, :cond_1f3

    if-eq v8, v12, :cond_1d8

    if-eq v9, v12, :cond_1d8

    iget-object v7, v5, Lg/a;->p:Lg/a$b;

    invoke-virtual {v7, v8, v9, v11, v10}, Lg/a$b;->k(IILandroid/graphics/drawable/Drawable;Z)I

    goto/16 :goto_13a

    :cond_1d8
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": <transition> tag requires \'fromId\' & \'toId\' attributes"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1f3
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_20c
    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    invoke-virtual {v5, v0}, Lg/a;->onStateChange([I)Z

    return-object v5

    :cond_214
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": invalid animated-selector tag "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method final b()Lg/b$c;
    .registers 4

    new-instance v0, Lg/a$b;

    iget-object v1, p0, Lg/a;->p:Lg/a$b;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lg/a$b;-><init>(Lg/a$b;Lg/a;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method final f(Lg/b$c;)V
    .registers 3

    invoke-super {p0, p1}, Lg/d;->f(Lg/b$c;)V

    instance-of v0, p1, Lg/a$b;

    if-eqz v0, :cond_b

    check-cast p1, Lg/a$b;

    iput-object p1, p0, Lg/a;->p:Lg/a$b;

    :cond_b
    return-void
.end method

.method final h()Lg/d$a;
    .registers 4

    new-instance v0, Lg/a$b;

    iget-object v1, p0, Lg/a;->p:Lg/a$b;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lg/a$b;-><init>(Lg/a$b;Lg/a;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method public final jumpToCurrentState()V
    .registers 2

    invoke-super {p0}, Lg/b;->jumpToCurrentState()V

    iget-object v0, p0, Lg/a;->q:Lg/a$f;

    if-eqz v0, :cond_17

    invoke-virtual {v0}, Lg/a$f;->d()V

    const/4 v0, 0x0

    iput-object v0, p0, Lg/a;->q:Lg/a$f;

    iget v0, p0, Lg/a;->r:I

    invoke-virtual {p0, v0}, Lg/b;->e(I)Z

    const/4 v0, -0x1

    iput v0, p0, Lg/a;->r:I

    iput v0, p0, Lg/a;->s:I

    :cond_17
    return-void
.end method

.method public final mutate()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-boolean v0, p0, Lg/a;->t:Z

    if-nez v0, :cond_f

    invoke-super {p0}, Lg/d;->mutate()Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, Lg/a;->p:Lg/a$b;

    invoke-virtual {v0}, Lg/a$b;->i()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg/a;->t:Z

    :cond_f
    return-object p0
.end method

.method protected final onStateChange([I)Z
    .registers 11

    iget-object v0, p0, Lg/a;->p:Lg/a$b;

    invoke-virtual {v0, p1}, Lg/d$a;->j([I)I

    move-result v1

    if-ltz v1, :cond_9

    goto :goto_f

    :cond_9
    sget-object v1, Landroid/util/StateSet;->WILD_CARD:[I

    invoke-virtual {v0, v1}, Lg/d$a;->j([I)I

    move-result v1

    :goto_f
    invoke-virtual {p0}, Lg/b;->c()I

    move-result v0

    const/4 v2, 0x0

    if-eq v1, v0, :cond_c3

    iget-object v0, p0, Lg/a;->q:Lg/a$f;

    if-eqz v0, :cond_3b

    iget v3, p0, Lg/a;->r:I

    if-ne v1, v3, :cond_20

    goto/16 :goto_c2

    :cond_20
    iget v3, p0, Lg/a;->s:I

    if-ne v1, v3, :cond_35

    invoke-virtual {v0}, Lg/a$f;->a()Z

    move-result v3

    if-eqz v3, :cond_35

    invoke-virtual {v0}, Lg/a$f;->b()V

    iget v0, p0, Lg/a;->s:I

    iput v0, p0, Lg/a;->r:I

    iput v1, p0, Lg/a;->s:I

    goto/16 :goto_c2

    :cond_35
    iget v3, p0, Lg/a;->r:I

    invoke-virtual {v0}, Lg/a$f;->d()V

    goto :goto_3f

    :cond_3b
    invoke-virtual {p0}, Lg/b;->c()I

    move-result v3

    :goto_3f
    const/4 v0, 0x0

    iput-object v0, p0, Lg/a;->q:Lg/a$f;

    const/4 v0, -0x1

    iput v0, p0, Lg/a;->s:I

    iput v0, p0, Lg/a;->r:I

    iget-object v0, p0, Lg/a;->p:Lg/a$b;

    if-gez v3, :cond_50

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x0

    goto :goto_60

    :cond_50
    iget-object v4, v0, Lg/a$b;->J:Landroidx/collection/i;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v3, v5}, Landroidx/collection/i;->e(ILjava/lang/Integer;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    :goto_60
    if-gez v1, :cond_64

    const/4 v5, 0x0

    goto :goto_74

    :cond_64
    iget-object v5, v0, Lg/a$b;->J:Landroidx/collection/i;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v5, v1, v6}, Landroidx/collection/i;->e(ILjava/lang/Integer;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    :goto_74
    if-eqz v5, :cond_bc

    if-nez v4, :cond_79

    goto :goto_bc

    :cond_79
    invoke-virtual {v0, v4, v5}, Lg/a$b;->l(II)I

    move-result v6

    if-gez v6, :cond_80

    goto :goto_bc

    :cond_80
    invoke-virtual {v0, v4, v5}, Lg/a$b;->n(II)Z

    move-result v7

    invoke-virtual {p0, v6}, Lg/b;->e(I)Z

    invoke-super {p0}, Lg/b;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    instance-of v8, v6, Landroid/graphics/drawable/AnimationDrawable;

    if-eqz v8, :cond_9b

    invoke-virtual {v0, v4, v5}, Lg/a$b;->m(II)Z

    move-result v0

    new-instance v2, Lg/a$d;

    check-cast v6, Landroid/graphics/drawable/AnimationDrawable;

    invoke-direct {v2, v6, v0, v7}, Lg/a$d;-><init>(Landroid/graphics/drawable/AnimationDrawable;ZZ)V

    goto :goto_b2

    :cond_9b
    instance-of v0, v6, Landroidx/vectordrawable/graphics/drawable/b;

    if-eqz v0, :cond_a7

    new-instance v2, Lg/a$c;

    check-cast v6, Landroidx/vectordrawable/graphics/drawable/b;

    invoke-direct {v2, v6}, Lg/a$c;-><init>(Landroidx/vectordrawable/graphics/drawable/b;)V

    goto :goto_b2

    :cond_a7
    instance-of v0, v6, Landroid/graphics/drawable/Animatable;

    if-eqz v0, :cond_bc

    new-instance v2, Lg/a$a;

    check-cast v6, Landroid/graphics/drawable/Animatable;

    invoke-direct {v2, v6}, Lg/a$a;-><init>(Landroid/graphics/drawable/Animatable;)V

    :goto_b2
    invoke-virtual {v2}, Lg/a$f;->c()V

    iput-object v2, p0, Lg/a;->q:Lg/a$f;

    iput v3, p0, Lg/a;->s:I

    iput v1, p0, Lg/a;->r:I

    goto :goto_c2

    :cond_bc
    :goto_bc
    invoke-virtual {p0, v1}, Lg/b;->e(I)Z

    move-result v0

    if-eqz v0, :cond_c3

    :goto_c2
    const/4 v2, 0x1

    :cond_c3
    invoke-super {p0}, Lg/b;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_ce

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    or-int/2addr v2, p1

    :cond_ce
    return v2
.end method

.method public final setVisible(ZZ)Z
    .registers 5

    invoke-super {p0, p1, p2}, Lg/b;->setVisible(ZZ)Z

    move-result v0

    iget-object v1, p0, Lg/a;->q:Lg/a$f;

    if-eqz v1, :cond_15

    if-nez v0, :cond_c

    if-eqz p2, :cond_15

    :cond_c
    if-eqz p1, :cond_12

    invoke-virtual {v1}, Lg/a$f;->c()V

    goto :goto_15

    :cond_12
    invoke-virtual {p0}, Lg/a;->jumpToCurrentState()V

    :cond_15
    :goto_15
    return v0
.end method
