.class public final Lc4/a;
.super Ljava/lang/Object;
.source "BNPLNotificationHelper.java"


# direct methods
.method private static a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .registers 8

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v1, Lcom/flipkart/mapi/model/component/data/renderables/b;

    sget-object v2, Lcom/flipkart/android/urlmanagement/AppAction;->checkEligibilityStatus:Lcom/flipkart/android/urlmanagement/AppAction;

    invoke-virtual {v2}, Lcom/flipkart/android/urlmanagement/AppAction;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    invoke-direct {v1, v2, v3}, Lcom/flipkart/mapi/model/component/data/renderables/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Ljava/util/HashMap;

    const/4 v4, 0x1

    invoke-direct {v2, v4}, Ljava/util/HashMap;-><init>(I)V

    iput-object v2, v1, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v5, "type"

    invoke-virtual {v2, v5, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "HOME_ACTIVITY_EXTRAS_FROM_SCREEN"

    const-string v2, "notification"

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {p0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object p0

    invoke-virtual {p0, v1}, Lcom/flipkart/android/gson/Serializer;->serialize(Lcom/flipkart/mapi/model/component/data/renderables/b;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "actionJson"

    invoke-virtual {v0, p1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p0, "omniture"

    invoke-virtual {v0, p0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 p0, 0x2c9

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    const-string p1, "extras_notification_id"

    invoke-virtual {v0, p1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p0, "doDismissOnClick"

    invoke-virtual {v0, p0, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const p0, 0x20008000

    invoke-virtual {v0, p0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    return-object v0
.end method

.method public static showCheckBackLaterNotification(Landroid/content/Context;Ljava/lang/String;)V
    .registers 6

    new-instance v0, Landroidx/core/app/NotificationCompat$Builder;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "fk_channel_alerts_subs"

    invoke-direct {v0, v1, v2}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x7f0801d6

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->z(I)V

    const v1, 0x7f1300a5

    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->k(Ljava/lang/CharSequence;)V

    const v1, 0x7f1300a2

    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->j(Ljava/lang/CharSequence;)V

    invoke-static {p0, p1}, Lc4/a;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x17

    const/4 v3, 0x0

    if-lt v1, v2, :cond_33

    const/high16 v1, 0x4000000

    goto :goto_34

    :cond_33
    const/4 v1, 0x0

    :goto_34
    const/16 v2, 0x22d

    invoke-static {p0, v2, p1, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->i(Landroid/app/PendingIntent;)V

    invoke-virtual {v0, v3}, Landroidx/core/app/NotificationCompat$Builder;->u(Z)V

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->e(Z)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/c;->isPNColorEnabled()Z

    move-result p1

    if-eqz p1, :cond_58

    const p1, 0x7f06013e

    invoke-static {p0, p1}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->g(I)V

    :cond_58
    const-string p1, "notification"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/NotificationManager;

    if-eqz p0, :cond_6b

    const/16 p1, 0x2c9

    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->a()Landroid/app/Notification;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    :cond_6b
    return-void
.end method

.method public static showCompletedNotification(Landroid/content/Context;Ljava/lang/String;)V
    .registers 5

    const-string v0, "CheckEligibilityPNstatuscompleted"

    invoke-static {v0}, LS3/x;->sendCheckEligibilityNotificationEvent(Ljava/lang/String;)V

    new-instance v0, Landroidx/core/app/NotificationCompat$Builder;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "fk_channel_alerts_subs"

    invoke-direct {v0, v1, v2}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x7f0801d6

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->z(I)V

    const v1, 0x7f1300a3

    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->k(Ljava/lang/CharSequence;)V

    const v1, 0x7f1300a8

    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->j(Ljava/lang/CharSequence;)V

    invoke-static {p0, p1}, Lc4/a;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x17

    if-lt v1, v2, :cond_37

    const/high16 v1, 0x4000000

    goto :goto_38

    :cond_37
    const/4 v1, 0x0

    :goto_38
    const/16 v2, 0x22d

    invoke-static {p0, v2, p1, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->i(Landroid/app/PendingIntent;)V

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->e(Z)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/c;->isPNColorEnabled()Z

    move-result p1

    if-eqz p1, :cond_59

    const p1, 0x7f06013e

    invoke-static {p0, p1}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroidx/core/app/NotificationCompat$Builder;->g(I)V

    :cond_59
    const-string p1, "notification"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/NotificationManager;

    if-eqz p0, :cond_6c

    const/16 p1, 0x2c9

    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->a()Landroid/app/Notification;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    :cond_6c
    return-void
.end method

.method public static showErrorNotification(Landroid/content/Context;Ljava/lang/String;)V
    .registers 9

    const-string v0, "CheckEligibilityPNstatusError"

    invoke-static {v0}, LS3/x;->sendCheckEligibilityNotificationEvent(Ljava/lang/String;)V

    new-instance v0, Landroidx/core/app/NotificationCompat$Builder;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "fk_channel_alerts_subs"

    invoke-direct {v0, v1, v2}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x7f0801d6

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->z(I)V

    const v1, 0x7f1300a4

    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->k(Ljava/lang/CharSequence;)V

    const v1, 0x7f1300a8

    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->j(Ljava/lang/CharSequence;)V

    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v2, Lcom/flipkart/mapi/model/component/data/renderables/b;

    sget-object v3, Lcom/flipkart/android/urlmanagement/AppAction;->checkEligibilityHome:Lcom/flipkart/android/urlmanagement/AppAction;

    invoke-virtual {v3}, Lcom/flipkart/android/urlmanagement/AppAction;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-direct {v2, v3, v4}, Lcom/flipkart/mapi/model/component/data/renderables/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v3, Ljava/util/HashMap;

    const/4 v5, 0x1

    invoke-direct {v3, v5}, Ljava/util/HashMap;-><init>(I)V

    iput-object v3, v2, Lcom/flipkart/mapi/model/component/data/renderables/b;->f:Ljava/util/Map;

    const-string v6, "type"

    invoke-virtual {v3, v6, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "HOME_ACTIVITY_EXTRAS_FROM_SCREEN"

    const-string v3, "notification"

    invoke-virtual {v1, p1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {p0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object p1

    invoke-virtual {p1, v2}, Lcom/flipkart/android/gson/Serializer;->serialize(Lcom/flipkart/mapi/model/component/data/renderables/b;)Ljava/lang/String;

    move-result-object p1

    const-string v2, "actionJson"

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "omniture"

    invoke-virtual {v1, p1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 p1, 0x2c9

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    const-string v4, "extras_notification_id"

    invoke-virtual {v1, v4, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v2, "doDismissOnClick"

    invoke-virtual {v1, v2, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const v2, 0x20008000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x17

    if-lt v2, v4, :cond_83

    const/high16 v2, 0x4000000

    goto :goto_84

    :cond_83
    const/4 v2, 0x0

    :goto_84
    const/16 v4, 0x22d

    invoke-static {p0, v4, v1, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->i(Landroid/app/PendingIntent;)V

    invoke-virtual {v0, v5}, Landroidx/core/app/NotificationCompat$Builder;->e(Z)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->isPNColorEnabled()Z

    move-result v1

    if-eqz v1, :cond_a4

    const v1, 0x7f06013e

    invoke-static {p0, v1}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->g(I)V

    :cond_a4
    invoke-virtual {p0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/NotificationManager;

    if-eqz p0, :cond_b3

    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->a()Landroid/app/Notification;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    :cond_b3
    return-void
.end method
