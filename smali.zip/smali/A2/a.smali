.class public final La2/a;
.super Lq2/g;
.source "LruResourceCache.java"

# interfaces
.implements La2/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lq2/g<",
        "LW1/f;",
        "Lcom/bumptech/glide/load/engine/w<",
        "*>;>;",
        "La2/b;"
    }
.end annotation


# instance fields
.field private d:La2/b$a;


# virtual methods
.method protected final d(Ljava/lang/Object;)I
    .registers 2

    check-cast p1, Lcom/bumptech/glide/load/engine/w;

    if-nez p1, :cond_6

    const/4 p1, 0x1

    goto :goto_a

    :cond_6
    invoke-interface {p1}, Lcom/bumptech/glide/load/engine/w;->c()I

    move-result p1

    :goto_a
    return p1
.end method

.method protected final e(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    check-cast p1, LW1/f;

    check-cast p2, Lcom/bumptech/glide/load/engine/w;

    iget-object p1, p0, La2/a;->d:La2/b$a;

    if-eqz p1, :cond_f

    if-eqz p2, :cond_f

    check-cast p1, Lcom/bumptech/glide/load/engine/m;

    invoke-virtual {p1, p2}, Lcom/bumptech/glide/load/engine/m;->g(Lcom/bumptech/glide/load/engine/w;)V

    :cond_f
    return-void
.end method

.method public final i(La2/b$a;)V
    .registers 2

    iput-object p1, p0, La2/a;->d:La2/b$a;

    return-void
.end method

.method public final j(I)V
    .registers 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "InlinedApi"
        }
    .end annotation

    const/16 v0, 0x28

    if-lt p1, v0, :cond_8

    invoke-virtual {p0}, Lq2/g;->a()V

    goto :goto_1a

    :cond_8
    const/16 v0, 0x14

    if-ge p1, v0, :cond_10

    const/16 v0, 0xf

    if-ne p1, v0, :cond_1a

    :cond_10
    invoke-virtual {p0}, Lq2/g;->c()J

    move-result-wide v0

    const-wide/16 v2, 0x2

    div-long/2addr v0, v2

    invoke-virtual {p0, v0, v1}, Lq2/g;->h(J)V

    :cond_1a
    :goto_1a
    return-void
.end method
