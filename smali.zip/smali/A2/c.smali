.class public final La2/c;
.super Ljava/lang/Object;
.source "SafeKeyGenerator.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La2/c$b;
    }
.end annotation


# instance fields
.field private final a:Lq2/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lq2/g<",
            "LW1/f;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Landroidx/core/util/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/core/util/e<",
            "La2/c$b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lq2/g;

    const-wide/16 v1, 0x3e8

    invoke-direct {v0, v1, v2}, Lq2/g;-><init>(J)V

    iput-object v0, p0, La2/c;->a:Lq2/g;

    new-instance v0, La2/c$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/16 v1, 0xa

    invoke-static {v1, v0}, Lr2/a;->a(ILr2/a$b;)Landroidx/core/util/e;

    move-result-object v0

    iput-object v0, p0, La2/c;->b:Landroidx/core/util/e;

    return-void
.end method


# virtual methods
.method public final a(LW1/f;)Ljava/lang/String;
    .registers 5

    iget-object v0, p0, La2/c;->a:Lq2/g;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, La2/c;->a:Lq2/g;

    invoke-virtual {v1, p1}, Lq2/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    monitor-exit v0
    :try_end_c
    .catchall {:try_start_3 .. :try_end_c} :catchall_3f

    if-nez v1, :cond_32

    iget-object v0, p0, La2/c;->b:Landroidx/core/util/e;

    invoke-interface {v0}, Landroidx/core/util/e;->acquire()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "Argument must not be null"

    invoke-static {v1, v2}, LHj/a;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, La2/c$b;

    iget-object v2, v1, La2/c$b;->a:Ljava/security/MessageDigest;

    :try_start_1d
    invoke-interface {p1, v2}, LW1/f;->updateDiskCacheKey(Ljava/security/MessageDigest;)V

    invoke-virtual {v2}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v2

    invoke-static {v2}, Lq2/j;->j([B)Ljava/lang/String;

    move-result-object v2
    :try_end_28
    .catchall {:try_start_1d .. :try_end_28} :catchall_2d

    invoke-interface {v0, v1}, Landroidx/core/util/e;->release(Ljava/lang/Object;)Z

    move-object v1, v2

    goto :goto_32

    :catchall_2d
    move-exception p1

    invoke-interface {v0, v1}, Landroidx/core/util/e;->release(Ljava/lang/Object;)Z

    throw p1

    :cond_32
    :goto_32
    iget-object v2, p0, La2/c;->a:Lq2/g;

    monitor-enter v2

    :try_start_35
    iget-object v0, p0, La2/c;->a:Lq2/g;

    invoke-virtual {v0, p1, v1}, Lq2/g;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v2

    return-object v1

    :catchall_3c
    move-exception p1

    monitor-exit v2
    :try_end_3e
    .catchall {:try_start_35 .. :try_end_3e} :catchall_3c

    throw p1

    :catchall_3f
    move-exception p1

    :try_start_40
    monitor-exit v0
    :try_end_41
    .catchall {:try_start_40 .. :try_end_41} :catchall_3f

    throw p1
.end method
