.class final La2/c$b;
.super Ljava/lang/Object;
.source "SafeKeyGenerator.java"

# interfaces
.implements Lr2/a$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La2/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation


# instance fields
.field final a:Ljava/security/MessageDigest;

.field private final b:Lr2/d;


# direct methods
.method constructor <init>(Ljava/security/MessageDigest;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lr2/d;->a()Lr2/d;

    move-result-object v0

    iput-object v0, p0, La2/c$b;->b:Lr2/d;

    iput-object p1, p0, La2/c$b;->a:Ljava/security/MessageDigest;

    return-void
.end method


# virtual methods
.method public final b()Lr2/d;
    .registers 2

    iget-object v0, p0, La2/c$b;->b:Lr2/d;

    return-object v0
.end method
