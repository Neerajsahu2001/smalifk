.class public final LE5/e;
.super Ljava/lang/Object;
.source "FacebookRequest.java"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# direct methods
.method public static makeAPICall(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 9

    new-instance v0, LE5/b$a;

    invoke-direct {v0}, LE5/b$a;-><init>()V

    invoke-virtual {v0, p0}, LE5/b$a;->withEventName(Ljava/lang/String;)LE5/b$a;

    move-result-object p0

    invoke-virtual {p0, p1}, LE5/b$a;->withContentIdAndFbContent(Ljava/lang/String;)LE5/b$a;

    move-result-object p0

    invoke-virtual {p0, p2}, LE5/b$a;->withContentCategory(Ljava/lang/String;)LE5/b$a;

    move-result-object p0

    invoke-virtual {p0, p3, p4}, LE5/b$a;->withSum(D)LE5/b$a;

    move-result-object p0

    invoke-virtual {p0, p6}, LE5/b$a;->withContentIds(Ljava/lang/String;)LE5/b$a;

    move-result-object p0

    invoke-virtual {p0, p7}, LE5/b$a;->withContentName(Ljava/lang/String;)LE5/b$a;

    move-result-object p0

    invoke-virtual {p0}, LE5/b$a;->build()LE5/b;

    move-result-object p0

    invoke-static {p5, p0}, LE5/d;->from(Ljava/lang/String;LE5/b;)LE5/d;

    move-result-object p0

    new-instance p1, Lokhttp3/Request$Builder;

    invoke-direct {p1}, Lokhttp3/Request$Builder;-><init>()V

    const-string p2, "https://graph.facebook.com/v5.0/383167535118598/activities"

    invoke-virtual {p1, p2}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p1

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object p2

    invoke-virtual {p2, p0}, Lcom/flipkart/android/gson/Serializer;->serialize(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p2, "application/json; charset=utf-8"

    invoke-static {p2}, Lokhttp3/MediaType;->parse(Ljava/lang/String;)Lokhttp3/MediaType;

    move-result-object p2

    invoke-static {p0, p2}, Lokhttp3/RequestBody;->create(Ljava/lang/String;Lokhttp3/MediaType;)Lokhttp3/RequestBody;

    move-result-object p0

    invoke-virtual {p1, p0}, Lokhttp3/Request$Builder;->post(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object p0

    instance-of p1, p0, Lokhttp3/Request$Builder;

    if-nez p1, :cond_53

    invoke-virtual {p0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p0

    goto :goto_57

    :cond_53
    invoke-static {p0}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object p0

    :goto_57
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getInstance()Lcom/flipkart/android/init/FlipkartApplication;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/init/FlipkartApplication;->getFacebookOKHttpClient()Lokhttp3/OkHttpClient;

    move-result-object p1

    instance-of p2, p1, Lokhttp3/OkHttpClient;

    if-nez p2, :cond_68

    invoke-virtual {p1, p0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p0

    goto :goto_6c

    :cond_68
    invoke-static {p1, p0}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->newCall(Lokhttp3/OkHttpClient;Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p0

    :goto_6c
    new-instance p1, LE5/e$a;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    invoke-interface {p0, p1}, Lokhttp3/Call;->enqueue(Lokhttp3/Callback;)V

    return-void
.end method
