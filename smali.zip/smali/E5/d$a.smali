.class public final LE5/d$a;
.super Ljava/lang/Object;
.source "FacebookEventModel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE5/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final from(Ljava/lang/String;LE5/b;)LE5/d;
    .registers 13

    const/4 v0, 0x1

    const-string v1, "eventType"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "facebookCustomEvent"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/config/d;->instance()Lcom/flipkart/android/config/d;

    move-result-object v1

    const-string v2, "instance()"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/flipkart/android/config/d;->getDoNotTrack()Z

    move-result v2

    new-instance v9, LE5/d;

    xor-int/lit8 v4, v2, 0x1

    xor-int/lit8 v5, v2, 0x1

    invoke-virtual {v1}, Lcom/flipkart/android/config/d;->getAdId()Ljava/lang/String;

    move-result-object v6

    new-array v0, v0, [LE5/b;

    const/4 v1, 0x0

    aput-object p2, v0, v1

    invoke-static {v0}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v7

    move-object v3, v9

    move-object v8, p1

    invoke-direct/range {v3 .. v8}, LE5/d;-><init>(IILjava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;)V

    return-object v9
.end method
