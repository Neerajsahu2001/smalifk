.class public final Le5/a;
.super Ljava/lang/Object;
.source "RichTextTooltipBuilder.kt"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createBuilder(Landroid/content/Context;Lpg/c;Lcom/flipkart/tooltip/TooltipBuilder;)Lcom/flipkart/tooltip/TooltipBuilder;
    .registers 20

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    const-string v3, "context"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "guidedNavigationTip"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "tooltipBuilder"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v1, Lpg/c;->k:Lpg/e;

    instance-of v3, v1, Lpg/s;

    const/4 v4, 0x0

    if-nez v3, :cond_1d

    return-object v4

    :cond_1d
    const-string v3, "null cannot be cast to non-null type com.flipkart.rome.datatypes.response.page.v4.guidedNav.RichTextTooltip"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lpg/s;

    iget-object v3, v1, Lpg/s;->e:Ljava/util/List;

    iget-object v1, v1, Lpg/s;->g:Lpg/i;

    if-eqz v3, :cond_17d

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_32

    goto/16 :goto_17d

    :cond_32
    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    const v8, 0x7f070130

    invoke-virtual {v7, v8}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v7

    float-to-int v7, v7

    invoke-virtual {v5, v7, v7, v7, v7}, Landroid/view/View;->setPadding(IIII)V

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_4e
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v9, 0x0

    if-eqz v7, :cond_13f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lpg/q;

    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    invoke-virtual {v11, v8}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v11

    float-to-int v11, v11

    iget-object v12, v7, Lpg/q;->h:Lpg/k;

    if-eqz v12, :cond_97

    iget-object v13, v12, Lpg/k;->a:Ljava/lang/Integer;

    if-nez v13, :cond_73

    move v13, v11

    goto :goto_77

    :cond_73
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    :goto_77
    iget-object v14, v12, Lpg/k;->b:Ljava/lang/Integer;

    if-nez v14, :cond_7d

    move v14, v11

    goto :goto_81

    :cond_7d
    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    move-result v14

    :goto_81
    iget-object v15, v12, Lpg/k;->c:Ljava/lang/Integer;

    if-nez v15, :cond_87

    move v15, v11

    goto :goto_8b

    :cond_87
    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    move-result v15

    :goto_8b
    iget-object v12, v12, Lpg/k;->d:Ljava/lang/Integer;

    if-nez v12, :cond_90

    goto :goto_94

    :cond_90
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v11

    :goto_94
    move v12, v11

    move v11, v13

    goto :goto_9a

    :cond_97
    move v12, v11

    move v14, v12

    move v15, v14

    :goto_9a
    invoke-virtual {v10, v11, v15, v14, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v11, v7, Lpg/q;->g:Ljava/lang/String;

    if-eqz v11, :cond_d1

    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    move-result v12

    const v13, 0x239807

    if-eq v12, v13, :cond_c6

    const v13, 0x4a5c9fc

    if-eq v12, v13, :cond_bb

    const v13, 0x7645c055

    if-eq v12, v13, :cond_b5

    goto :goto_d1

    :cond_b5
    const-string v12, "CENTER"

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    goto :goto_d1

    :cond_bb
    const-string v12, "RIGHT"

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_c4

    goto :goto_d1

    :cond_c4
    const/4 v11, 0x6

    goto :goto_d2

    :cond_c6
    const-string v12, "LEFT"

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_cf

    goto :goto_d1

    :cond_cf
    const/4 v11, 0x5

    goto :goto_d2

    :cond_d1
    :goto_d1
    const/4 v11, 0x4

    :goto_d2
    invoke-virtual {v10, v11}, Landroid/view/View;->setTextAlignment(I)V

    iget-object v11, v7, Lpg/q;->a:Ljava/lang/String;

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v11, v7, Lpg/q;->b:Ljava/lang/String;

    const/4 v12, -0x1

    invoke-static {v11, v12}, Lcom/flipkart/android/utils/w;->parseColor(Ljava/lang/String;I)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v11, v7, Lpg/q;->c:Ljava/lang/Integer;

    if-eqz v11, :cond_f6

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-lez v12, :cond_f6

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_f6
    iget-object v11, v7, Lpg/q;->d:Ljava/lang/String;

    invoke-static {v11}, LP7/a;->mapTypefaceStyle(Ljava/lang/String;)I

    move-result v11

    const/4 v12, 0x2

    if-ne v11, v12, :cond_101

    const/4 v11, 0x1

    goto :goto_102

    :cond_101
    const/4 v11, 0x0

    :goto_102
    iget-object v7, v7, Lpg/q;->e:Ljava/lang/String;

    if-eqz v7, :cond_110

    const-string v13, "bold"

    invoke-static {v7, v13}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_110

    const/4 v13, 0x1

    goto :goto_111

    :cond_110
    const/4 v13, 0x0

    :goto_111
    if-eqz v7, :cond_126

    const-string v14, "medium"

    invoke-static {v7, v14}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_126

    if-eqz v11, :cond_11e

    const/4 v9, 0x2

    :cond_11e
    invoke-static {v0, v9}, Lcom/flipkart/android/utils/U;->getMediumTypeface(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object v7

    invoke-virtual {v10, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    goto :goto_13a

    :cond_126
    if-eqz v11, :cond_12c

    if-eqz v13, :cond_12c

    const/4 v9, 0x3

    goto :goto_133

    :cond_12c
    if-eqz v13, :cond_130

    const/4 v9, 0x1

    goto :goto_133

    :cond_130
    if-eqz v11, :cond_133

    const/4 v9, 0x2

    :cond_133
    :goto_133
    invoke-static {v9}, Landroid/graphics/Typeface;->defaultFromStyle(I)Landroid/graphics/Typeface;

    move-result-object v7

    invoke-virtual {v10, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    :goto_13a
    invoke-virtual {v5, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto/16 :goto_4e

    :cond_13f
    if-eqz v1, :cond_143

    iget-object v4, v1, Lpg/i;->c:Ljava/lang/String;

    :cond_143
    const/high16 v3, -0x1000000

    if-nez v4, :cond_148

    goto :goto_14e

    :cond_148
    iget-object v4, v1, Lpg/i;->c:Ljava/lang/String;

    invoke-static {v4, v3}, Lcom/flipkart/android/utils/w;->parseColor(Ljava/lang/String;I)I

    move-result v3

    :goto_14e
    invoke-virtual {v2, v3}, Lcom/flipkart/tooltip/TooltipBuilder;->showBubble(I)Lcom/flipkart/tooltip/TooltipBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Lcom/flipkart/tooltip/TooltipBuilder;->customView(Landroid/view/View;)Lcom/flipkart/tooltip/TooltipBuilder;

    move-result-object v2

    if-eqz v1, :cond_177

    iget-object v3, v1, Lpg/i;->a:Ljava/lang/Integer;

    if-nez v3, :cond_15e

    const/4 v3, 0x0

    goto :goto_166

    :cond_15e
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v0, v3}, Lcom/flipkart/android/utils/Y0;->dpToPx(Landroid/content/Context;I)I

    move-result v3

    :goto_166
    iget-object v1, v1, Lpg/i;->b:Ljava/lang/Integer;

    if-nez v1, :cond_16b

    goto :goto_173

    :cond_16b
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v0, v1}, Lcom/flipkart/android/utils/Y0;->dpToPx(Landroid/content/Context;I)I

    move-result v9

    :goto_173
    invoke-virtual {v2, v3, v9}, Lcom/flipkart/tooltip/TooltipBuilder;->translation(II)Lcom/flipkart/tooltip/TooltipBuilder;

    move-result-object v2

    :cond_177
    const-string v0, "builder"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v2

    :cond_17d
    :goto_17d
    return-object v4
.end method
