.class public final LE5/b$a;
.super Ljava/lang/Object;
.source "FacebookCustomEvent.kt"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE5/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:LUn/e;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, LE5/b$a$a;->a:LE5/b$a$a;

    invoke-static {v0}, LUn/f;->b(Leo/a;)LUn/e;

    move-result-object v0

    iput-object v0, p0, LE5/b$a;->a:LUn/e;

    return-void
.end method

.method private final a()LE5/b;
    .registers 2

    iget-object v0, p0, LE5/b$a;->a:LUn/e;

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LE5/b;

    return-object v0
.end method


# virtual methods
.method public final build()LE5/b;
    .registers 4

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    const-string v1, "INR"

    invoke-virtual {v0, v1}, LE5/b;->setCurrency(Ljava/lang/String;)V

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    const-string v1, "product"

    invoke-virtual {v0, v1}, LE5/b;->setContentType(Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/config/d;->instance()Lcom/flipkart/android/config/d;

    move-result-object v0

    const-string v1, "instance()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v1

    invoke-virtual {v0}, Lcom/flipkart/android/config/d;->getAppVersionName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, LE5/b;->setAppVersion(Ljava/lang/String;)V

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, LE5/b;->setLogTime(Ljava/lang/String;)V

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    return-object v0
.end method

.method public final withContentCategory(Ljava/lang/String;)LE5/b$a;
    .registers 3

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    invoke-virtual {v0, p1}, LE5/b;->setContentCategory(Ljava/lang/String;)V

    return-object p0
.end method

.method public final withContentIdAndFbContent(Ljava/lang/String;)LE5/b$a;
    .registers 7

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    invoke-virtual {v0, p1}, LE5/b;->setContentId(Ljava/lang/String;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/gson/Serializer;->getGson()Lxk/j;

    move-result-object v0

    const-string v1, "getSerializer(FlipkartAp\u2026ion.getAppContext()).gson"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p1, :cond_5a

    invoke-static {p1}, Lvp/k;->B(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_21

    goto :goto_5a

    :cond_21
    const-string v1, "[\""

    const/4 v2, 0x0

    invoke-static {p1, v1, v2}, Lvp/k;->N(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    const-string v4, "\"]"

    if-eqz v3, :cond_33

    invoke-static {p1, v4}, Lvp/k;->w(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_33

    goto :goto_5c

    :cond_33
    const-string v3, "\""

    invoke-static {p1, v3, v2}, Lvp/k;->N(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_55

    invoke-static {p1, v3}, Lvp/k;->w(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_55

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "["

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x5d

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_5c

    :cond_55
    invoke-static {v1, p1, v4}, Landroidx/core/content/b;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_5c

    :cond_5a
    :goto_5a
    const-string p1, "[]"

    :goto_5c
    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc5/a;->getConfigSerializer(Landroid/content/Context;)Lp7/h;

    move-result-object v1

    invoke-virtual {v1, p1}, Lp7/h;->deserializeArrayListString(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    if-nez p1, :cond_6c

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_6c
    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v1

    sget-object v2, LE5/a;->c:LE5/a$a;

    invoke-virtual {v2, p1}, LE5/a$a;->from(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/newrelic/agent/android/instrumentation/GsonInstrumentation;->toJson(Lxk/j;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, LE5/b;->setFbContent(Ljava/lang/String;)V

    return-object p0
.end method

.method public final withContentIds(Ljava/lang/String;)LE5/b$a;
    .registers 3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_d

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    invoke-virtual {v0, p1}, LE5/b;->setContentIds(Ljava/lang/String;)V

    :cond_d
    return-object p0
.end method

.method public final withContentName(Ljava/lang/String;)LE5/b$a;
    .registers 3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_d

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    invoke-virtual {v0, p1}, LE5/b;->setContentName(Ljava/lang/String;)V

    :cond_d
    return-object p0
.end method

.method public final withEventName(Ljava/lang/String;)LE5/b$a;
    .registers 3

    const-string v0, "eventName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    invoke-virtual {v0, p1}, LE5/b;->setEventName(Ljava/lang/String;)V

    return-object p0
.end method

.method public final withSum(D)LE5/b$a;
    .registers 4

    invoke-direct {p0}, LE5/b$a;->a()LE5/b;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, LE5/b;->setSum(D)V

    return-object p0
.end method
