.class public interface abstract LE5/c;
.super Ljava/lang/Object;
.source "FacebookDependencyProvider.kt"


# virtual methods
.method public abstract getFacebookOKHttpClient()Lokhttp3/OkHttpClient;
.end method
