.class final Lf1/d$c;
.super Ljava/lang/Object;
.source "TableInfo.java"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf1/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lf1/d$c;",
        ">;"
    }
.end annotation


# instance fields
.field final a:I

.field final b:I

.field final c:Ljava/lang/String;

.field final d:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Lf1/d$c;->a:I

    iput p3, p0, Lf1/d$c;->b:I

    iput-object p1, p0, Lf1/d$c;->c:Ljava/lang/String;

    iput-object p4, p0, Lf1/d$c;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .registers 4

    check-cast p1, Lf1/d$c;

    iget v0, p1, Lf1/d$c;->a:I

    iget v1, p0, Lf1/d$c;->a:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_f

    iget v0, p0, Lf1/d$c;->b:I

    iget p1, p1, Lf1/d$c;->b:I

    sub-int v1, v0, p1

    :cond_f
    return v1
.end method
