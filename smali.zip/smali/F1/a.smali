.class public final Lf1/a;
.super Ljava/lang/Object;
.source "CopyLock.java"


# static fields
.field private static final e:Ljava/util/HashMap;


# instance fields
.field private final a:Ljava/io/File;

.field private final b:Ljava/util/concurrent/locks/Lock;

.field private final c:Z

.field private d:Ljava/nio/channels/FileChannel;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lf1/a;->e:Ljava/util/HashMap;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/io/File;Z)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/io/File;

    const-string v1, ".lck"

    invoke-static {p1, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p2, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lf1/a;->a:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    sget-object p2, Lf1/a;->e:Ljava/util/HashMap;

    monitor-enter p2

    :try_start_17
    invoke-virtual {p2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/locks/Lock;

    if-nez v0, :cond_2a

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    invoke-virtual {p2, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2a

    :catchall_28
    move-exception p1

    goto :goto_30

    :cond_2a
    :goto_2a
    monitor-exit p2
    :try_end_2b
    .catchall {:try_start_17 .. :try_end_2b} :catchall_28

    iput-object v0, p0, Lf1/a;->b:Ljava/util/concurrent/locks/Lock;

    iput-boolean p3, p0, Lf1/a;->c:Z

    return-void

    :goto_30
    :try_start_30
    monitor-exit p2
    :try_end_31
    .catchall {:try_start_30 .. :try_end_31} :catchall_28

    throw p1
.end method


# virtual methods
.method public final a()V
    .registers 4

    iget-object v0, p0, Lf1/a;->b:Ljava/util/concurrent/locks/Lock;

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    iget-boolean v0, p0, Lf1/a;->c:Z

    if-eqz v0, :cond_23

    :try_start_9
    new-instance v0, Ljava/io/FileOutputStream;

    iget-object v1, p0, Lf1/a;->a:Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v0

    iput-object v0, p0, Lf1/a;->d:Ljava/nio/channels/FileChannel;

    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->lock()Ljava/nio/channels/FileLock;
    :try_end_19
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_19} :catch_1a

    goto :goto_23

    :catch_1a
    move-exception v0

    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Unable to grab copy lock."

    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_23
    :goto_23
    return-void
.end method

.method public final b()V
    .registers 2

    iget-object v0, p0, Lf1/a;->d:Ljava/nio/channels/FileChannel;

    if-eqz v0, :cond_7

    :try_start_4
    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_7} :catch_7

    :catch_7
    :cond_7
    iget-object v0, p0, Lf1/a;->b:Ljava/util/concurrent/locks/Lock;

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    return-void
.end method
