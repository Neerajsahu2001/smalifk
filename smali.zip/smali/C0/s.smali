.class public final Lc0/s;
.super Landroidx/media3/datasource/a;
.source "UdpDataSource.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc0/s$a;
    }
.end annotation


# instance fields
.field private final e:I

.field private final f:[B

.field private final g:Ljava/net/DatagramPacket;

.field private h:Landroid/net/Uri;

.field private i:Ljava/net/DatagramSocket;

.field private j:Ljava/net/MulticastSocket;

.field private k:Ljava/net/InetAddress;

.field private l:Z

.field private m:I


# direct methods
.method public constructor <init>()V
    .registers 5

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroidx/media3/datasource/a;-><init>(Z)V

    const/16 v0, 0x1f40

    iput v0, p0, Lc0/s;->e:I

    const/16 v0, 0x7d0

    new-array v1, v0, [B

    iput-object v1, p0, Lc0/s;->f:[B

    new-instance v2, Ljava/net/DatagramPacket;

    const/4 v3, 0x0

    invoke-direct {v2, v1, v3, v0}, Ljava/net/DatagramPacket;-><init>([BII)V

    iput-object v2, p0, Lc0/s;->g:Ljava/net/DatagramPacket;

    return-void
.end method


# virtual methods
.method public final a(Lc0/g;)J
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lc0/s$a;
        }
    .end annotation

    iget-object v0, p1, Lc0/g;->a:Landroid/net/Uri;

    iput-object v0, p0, Lc0/s;->h:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc0/s;->h:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->getPort()I

    move-result v1

    invoke-virtual {p0, p1}, Landroidx/media3/datasource/a;->m(Lc0/g;)V

    :try_start_14
    invoke-static {v0}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v0

    iput-object v0, p0, Lc0/s;->k:Ljava/net/InetAddress;

    new-instance v0, Ljava/net/InetSocketAddress;

    iget-object v2, p0, Lc0/s;->k:Ljava/net/InetAddress;

    invoke-direct {v0, v2, v1}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    iget-object v1, p0, Lc0/s;->k:Ljava/net/InetAddress;

    invoke-virtual {v1}, Ljava/net/InetAddress;->isMulticastAddress()Z

    move-result v1

    if-eqz v1, :cond_3e

    new-instance v1, Ljava/net/MulticastSocket;

    invoke-direct {v1, v0}, Ljava/net/MulticastSocket;-><init>(Ljava/net/SocketAddress;)V

    iput-object v1, p0, Lc0/s;->j:Ljava/net/MulticastSocket;

    iget-object v0, p0, Lc0/s;->k:Ljava/net/InetAddress;

    invoke-virtual {v1, v0}, Ljava/net/MulticastSocket;->joinGroup(Ljava/net/InetAddress;)V

    iget-object v0, p0, Lc0/s;->j:Ljava/net/MulticastSocket;

    iput-object v0, p0, Lc0/s;->i:Ljava/net/DatagramSocket;

    goto :goto_45

    :catch_3a
    move-exception p1

    goto :goto_55

    :catch_3c
    move-exception p1

    goto :goto_5d

    :cond_3e
    new-instance v1, Ljava/net/DatagramSocket;

    invoke-direct {v1, v0}, Ljava/net/DatagramSocket;-><init>(Ljava/net/SocketAddress;)V

    iput-object v1, p0, Lc0/s;->i:Ljava/net/DatagramSocket;

    :goto_45
    iget-object v0, p0, Lc0/s;->i:Ljava/net/DatagramSocket;

    iget v1, p0, Lc0/s;->e:I

    invoke-virtual {v0, v1}, Ljava/net/DatagramSocket;->setSoTimeout(I)V
    :try_end_4c
    .catch Ljava/lang/SecurityException; {:try_start_14 .. :try_end_4c} :catch_3c
    .catch Ljava/io/IOException; {:try_start_14 .. :try_end_4c} :catch_3a

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc0/s;->l:Z

    invoke-virtual {p0, p1}, Landroidx/media3/datasource/a;->n(Lc0/g;)V

    const-wide/16 v0, -0x1

    return-wide v0

    :goto_55
    new-instance v0, Lc0/s$a;

    const/16 v1, 0x7d1

    invoke-direct {v0, p1, v1}, Lc0/e;-><init>(Ljava/lang/Throwable;I)V

    throw v0

    :goto_5d
    new-instance v0, Lc0/s$a;

    const/16 v1, 0x7d6

    invoke-direct {v0, p1, v1}, Lc0/e;-><init>(Ljava/lang/Throwable;I)V

    throw v0
.end method

.method public final close()V
    .registers 4

    const/4 v0, 0x0

    iput-object v0, p0, Lc0/s;->h:Landroid/net/Uri;

    iget-object v1, p0, Lc0/s;->j:Ljava/net/MulticastSocket;

    if-eqz v1, :cond_11

    :try_start_7
    iget-object v2, p0, Lc0/s;->k:Ljava/net/InetAddress;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v2}, Ljava/net/MulticastSocket;->leaveGroup(Ljava/net/InetAddress;)V
    :try_end_f
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_f} :catch_f

    :catch_f
    iput-object v0, p0, Lc0/s;->j:Ljava/net/MulticastSocket;

    :cond_11
    iget-object v1, p0, Lc0/s;->i:Ljava/net/DatagramSocket;

    if-eqz v1, :cond_1a

    invoke-virtual {v1}, Ljava/net/DatagramSocket;->close()V

    iput-object v0, p0, Lc0/s;->i:Ljava/net/DatagramSocket;

    :cond_1a
    iput-object v0, p0, Lc0/s;->k:Ljava/net/InetAddress;

    const/4 v0, 0x0

    iput v0, p0, Lc0/s;->m:I

    iget-boolean v1, p0, Lc0/s;->l:Z

    if-eqz v1, :cond_28

    iput-boolean v0, p0, Lc0/s;->l:Z

    invoke-virtual {p0}, Landroidx/media3/datasource/a;->l()V

    :cond_28
    return-void
.end method

.method public final getUri()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc0/s;->h:Landroid/net/Uri;

    return-object v0
.end method

.method public final read([BII)I
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lc0/s$a;
        }
    .end annotation

    if-nez p3, :cond_4

    const/4 p1, 0x0

    return p1

    :cond_4
    iget v0, p0, Lc0/s;->m:I

    iget-object v1, p0, Lc0/s;->g:Ljava/net/DatagramPacket;

    if-nez v0, :cond_30

    :try_start_a
    iget-object v0, p0, Lc0/s;->i:Ljava/net/DatagramSocket;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v1}, Ljava/net/DatagramSocket;->receive(Ljava/net/DatagramPacket;)V
    :try_end_12
    .catch Ljava/net/SocketTimeoutException; {:try_start_a .. :try_end_12} :catch_1e
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_12} :catch_1c

    invoke-virtual {v1}, Ljava/net/DatagramPacket;->getLength()I

    move-result v0

    iput v0, p0, Lc0/s;->m:I

    invoke-virtual {p0, v0}, Landroidx/media3/datasource/a;->k(I)V

    goto :goto_30

    :catch_1c
    move-exception p1

    goto :goto_20

    :catch_1e
    move-exception p1

    goto :goto_28

    :goto_20
    new-instance p2, Lc0/s$a;

    const/16 p3, 0x7d1

    invoke-direct {p2, p1, p3}, Lc0/e;-><init>(Ljava/lang/Throwable;I)V

    throw p2

    :goto_28
    new-instance p2, Lc0/s$a;

    const/16 p3, 0x7d2

    invoke-direct {p2, p1, p3}, Lc0/e;-><init>(Ljava/lang/Throwable;I)V

    throw p2

    :cond_30
    :goto_30
    invoke-virtual {v1}, Ljava/net/DatagramPacket;->getLength()I

    move-result v0

    iget v1, p0, Lc0/s;->m:I

    sub-int/2addr v0, v1

    invoke-static {v1, p3}, Ljava/lang/Math;->min(II)I

    move-result p3

    iget-object v1, p0, Lc0/s;->f:[B

    invoke-static {v1, v0, p1, p2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p1, p0, Lc0/s;->m:I

    sub-int/2addr p1, p3

    iput p1, p0, Lc0/s;->m:I

    return p3
.end method
