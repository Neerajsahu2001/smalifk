.class public final Lc0/f;
.super Ljava/io/InputStream;
.source "DataSourceInputStream.java"


# instance fields
.field private final a:Landroidx/media3/datasource/b;

.field private final b:Lc0/g;

.field private final c:[B

.field private d:Z

.field private e:Z


# direct methods
.method public constructor <init>(Landroidx/media3/datasource/b;Lc0/g;)V
    .registers 4

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc0/f;->d:Z

    iput-boolean v0, p0, Lc0/f;->e:Z

    iput-object p1, p0, Lc0/f;->a:Landroidx/media3/datasource/b;

    iput-object p2, p0, Lc0/f;->b:Lc0/g;

    const/4 p1, 0x1

    new-array p1, p1, [B

    iput-object p1, p0, Lc0/f;->c:[B

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-boolean v0, p0, Lc0/f;->d:Z

    if-nez v0, :cond_e

    iget-object v0, p0, Lc0/f;->a:Landroidx/media3/datasource/b;

    iget-object v1, p0, Lc0/f;->b:Lc0/g;

    invoke-interface {v0, v1}, Landroidx/media3/datasource/b;->a(Lc0/g;)J

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc0/f;->d:Z

    :cond_e
    return-void
.end method

.method public final close()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-boolean v0, p0, Lc0/f;->e:Z

    if-nez v0, :cond_c

    iget-object v0, p0, Lc0/f;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->close()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc0/f;->e:Z

    :cond_c
    return-void
.end method

.method public final read()I
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lc0/f;->c:[B

    array-length v1, v0

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v2, v1}, Lc0/f;->read([BII)I

    move-result v1

    const/4 v3, -0x1

    if-ne v1, v3, :cond_c

    goto :goto_10

    :cond_c
    aget-byte v0, v0, v2

    and-int/lit16 v3, v0, 0xff

    :goto_10
    return v3
.end method

.method public final read([B)I
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    array-length v0, p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0}, Lc0/f;->read([BII)I

    move-result p1

    return p1
.end method

.method public final read([BII)I
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-boolean v0, p0, Lc0/f;->e:Z

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    iget-boolean v0, p0, Lc0/f;->d:Z

    iget-object v2, p0, Lc0/f;->a:Landroidx/media3/datasource/b;

    if-nez v0, :cond_14

    iget-object v0, p0, Lc0/f;->b:Lc0/g;

    invoke-interface {v2, v0}, Landroidx/media3/datasource/b;->a(Lc0/g;)J

    iput-boolean v1, p0, Lc0/f;->d:Z

    :cond_14
    invoke-interface {v2, p1, p2, p3}, Landroidx/media3/common/i;->read([BII)I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_1c

    return p2

    :cond_1c
    return p1
.end method
