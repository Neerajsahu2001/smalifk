.class public final Lc0/b;
.super Landroidx/media3/datasource/a;
.source "DataSchemeDataSource.java"


# instance fields
.field private e:Lc0/g;

.field private f:[B

.field private g:I

.field private h:I


# virtual methods
.method public final a(Lc0/g;)J
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0, p1}, Landroidx/media3/datasource/a;->m(Lc0/g;)V

    iput-object p1, p0, Lc0/b;->e:Lc0/g;

    iget-object v0, p1, Lc0/g;->a:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->normalizeScheme()Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v1

    const-string v2, "data"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Unsupported scheme: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/facebook/soloader/m;->b(ZLjava/lang/String;)V

    invoke-virtual {v0}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v1

    sget v2, La0/T;->a:I

    const/4 v2, -0x1

    const-string v3, ","

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne v2, v3, :cond_a8

    const/4 v0, 0x1

    aget-object v0, v1, v0

    const/4 v2, 0x0

    aget-object v1, v1, v2

    const-string v3, ";base64"

    invoke-virtual {v1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_61

    :try_start_46
    invoke-static {v0, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    iput-object v1, p0, Lc0/b;->f:[B
    :try_end_4c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_46 .. :try_end_4c} :catch_4d

    goto :goto_73

    :catch_4d
    move-exception p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Error while parsing Base64 encoded string: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p1}, Landroidx/media3/common/v;->b(Ljava/lang/String;Ljava/lang/IllegalArgumentException;)Landroidx/media3/common/v;

    move-result-object p1

    throw p1

    :cond_61
    sget-object v1, Lfk/c;->a:Ljava/nio/charset/Charset;

    invoke-virtual {v1}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lfk/c;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    iput-object v0, p0, Lc0/b;->f:[B

    :goto_73
    iget-object v0, p0, Lc0/b;->f:[B

    array-length v1, v0

    int-to-long v1, v1

    iget-wide v5, p1, Lc0/g;->f:J

    cmp-long v3, v5, v1

    if-gtz v3, :cond_9e

    long-to-int v1, v5

    iput v1, p0, Lc0/b;->g:I

    array-length v0, v0

    sub-int/2addr v0, v1

    iput v0, p0, Lc0/b;->h:I

    const-wide/16 v1, -0x1

    iget-wide v3, p1, Lc0/g;->g:J

    cmp-long v5, v3, v1

    if-eqz v5, :cond_94

    int-to-long v0, v0

    invoke-static {v0, v1, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int v1, v0

    iput v1, p0, Lc0/b;->h:I

    :cond_94
    invoke-virtual {p0, p1}, Landroidx/media3/datasource/a;->n(Lc0/g;)V

    if-eqz v5, :cond_9a

    goto :goto_9d

    :cond_9a
    iget p1, p0, Lc0/b;->h:I

    int-to-long v3, p1

    :goto_9d
    return-wide v3

    :cond_9e
    iput-object v4, p0, Lc0/b;->f:[B

    new-instance p1, Lc0/e;

    const/16 v0, 0x7d8

    invoke-direct {p1, v0}, Lc0/e;-><init>(I)V

    throw p1

    :cond_a8
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "Unexpected URI format: "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v4}, Landroidx/media3/common/v;->b(Ljava/lang/String;Ljava/lang/IllegalArgumentException;)Landroidx/media3/common/v;

    move-result-object p1

    throw p1
.end method

.method public final close()V
    .registers 3

    iget-object v0, p0, Lc0/b;->f:[B

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    iput-object v1, p0, Lc0/b;->f:[B

    invoke-virtual {p0}, Landroidx/media3/datasource/a;->l()V

    :cond_a
    iput-object v1, p0, Lc0/b;->e:Lc0/g;

    return-void
.end method

.method public final getUri()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc0/b;->e:Lc0/g;

    if-eqz v0, :cond_7

    iget-object v0, v0, Lc0/g;->a:Landroid/net/Uri;

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    return-object v0
.end method

.method public final read([BII)I
    .registers 6

    if-nez p3, :cond_4

    const/4 p1, 0x0

    return p1

    :cond_4
    iget v0, p0, Lc0/b;->h:I

    if-nez v0, :cond_a

    const/4 p1, -0x1

    return p1

    :cond_a
    invoke-static {p3, v0}, Ljava/lang/Math;->min(II)I

    move-result p3

    iget-object v0, p0, Lc0/b;->f:[B

    sget v1, La0/T;->a:I

    iget v1, p0, Lc0/b;->g:I

    invoke-static {v0, v1, p1, p2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p1, p0, Lc0/b;->g:I

    add-int/2addr p1, p3

    iput p1, p0, Lc0/b;->g:I

    iget p1, p0, Lc0/b;->h:I

    sub-int/2addr p1, p3

    iput p1, p0, Lc0/b;->h:I

    invoke-virtual {p0, p3}, Landroidx/media3/datasource/a;->k(I)V

    return p3
.end method
