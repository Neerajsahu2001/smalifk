.class public final Lc0/m;
.super Lc0/k;
.source "HttpDataSource.java"


# instance fields
.field public final d:I

.field public final e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(ILc0/e;Ljava/util/Map;)V
    .registers 6

    const-string v0, "Response code: "

    invoke-static {v0, p1}, Landroidx/core/content/b;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x7d4

    invoke-direct {p0, v0, p2, v1}, Lc0/k;-><init>(Ljava/lang/String;Ljava/io/IOException;I)V

    iput p1, p0, Lc0/m;->d:I

    iput-object p3, p0, Lc0/m;->e:Ljava/util/Map;

    return-void
.end method
