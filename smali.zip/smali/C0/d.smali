.class public final synthetic Lc0/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lfk/n;


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 2

    sget-object v0, Landroidx/media3/datasource/DataSourceBitmapLoader;->b:Lfk/n;

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    invoke-static {v0}, Lcom/google/common/util/concurrent/q;->b(Ljava/util/concurrent/ExecutorService;)Lcom/google/common/util/concurrent/p;

    move-result-object v0

    return-object v0
.end method
