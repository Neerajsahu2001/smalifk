.class public final Lc0/g;
.super Ljava/lang/Object;
.source "DataSpec.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc0/g$a;
    }
.end annotation


# instance fields
.field public final a:Landroid/net/Uri;

.field public final b:J

.field public final c:I

.field public final d:[B

.field public final e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final f:J

.field public final g:J

.field public final h:Ljava/lang/String;

.field public final i:I

.field public final j:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "media3.datasource"

    invoke-static {v0}, Landroidx/media3/common/r;->a(Ljava/lang/String;)V

    return-void
.end method

.method private constructor <init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;)V
    .registers 29
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "JI[B",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;JJ",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    move-object v0, p0

    move-wide/from16 v1, p2

    move-object/from16 v3, p5

    move-wide/from16 v4, p7

    move-wide/from16 v6, p9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    add-long v8, v1, v4

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-wide/16 v12, 0x0

    cmp-long v14, v8, v12

    if-ltz v14, :cond_18

    const/4 v8, 0x1

    goto :goto_19

    :cond_18
    const/4 v8, 0x0

    :goto_19
    invoke-static {v8}, Lcom/facebook/soloader/m;->a(Z)V

    cmp-long v8, v4, v12

    if-ltz v8, :cond_22

    const/4 v8, 0x1

    goto :goto_23

    :cond_22
    const/4 v8, 0x0

    :goto_23
    invoke-static {v8}, Lcom/facebook/soloader/m;->a(Z)V

    cmp-long v8, v6, v12

    if-gtz v8, :cond_32

    const-wide/16 v8, -0x1

    cmp-long v12, v6, v8

    if-nez v12, :cond_31

    goto :goto_32

    :cond_31
    const/4 v10, 0x0

    :cond_32
    :goto_32
    invoke-static {v10}, Lcom/facebook/soloader/m;->a(Z)V

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v8, p1

    iput-object v8, v0, Lc0/g;->a:Landroid/net/Uri;

    iput-wide v1, v0, Lc0/g;->b:J

    move/from16 v1, p4

    iput v1, v0, Lc0/g;->c:I

    if-eqz v3, :cond_48

    array-length v1, v3

    if-eqz v1, :cond_48

    goto :goto_4a

    :cond_48
    const/4 v1, 0x0

    move-object v3, v1

    :goto_4a
    iput-object v3, v0, Lc0/g;->d:[B

    new-instance v1, Ljava/util/HashMap;

    move-object/from16 v2, p6

    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v1

    iput-object v1, v0, Lc0/g;->e:Ljava/util/Map;

    iput-wide v4, v0, Lc0/g;->f:J

    iput-wide v6, v0, Lc0/g;->g:J

    move-object/from16 v1, p11

    iput-object v1, v0, Lc0/g;->h:Ljava/lang/String;

    move/from16 v1, p12

    iput v1, v0, Lc0/g;->i:I

    move-object/from16 v1, p13

    iput-object v1, v0, Lc0/g;->j:Ljava/lang/Object;

    return-void
.end method

.method synthetic constructor <init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;I)V
    .registers 15

    invoke-direct/range {p0 .. p13}, Lc0/g;-><init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;)V

    return-void
.end method

.method public static b(I)Ljava/lang/String;
    .registers 2

    const/4 v0, 0x1

    if-eq p0, v0, :cond_15

    const/4 v0, 0x2

    if-eq p0, v0, :cond_12

    const/4 v0, 0x3

    if-ne p0, v0, :cond_c

    const-string p0, "HEAD"

    return-object p0

    :cond_c
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    throw p0

    :cond_12
    const-string p0, "POST"

    return-object p0

    :cond_15
    const-string p0, "GET"

    return-object p0
.end method


# virtual methods
.method public final a()Lc0/g$a;
    .registers 2

    new-instance v0, Lc0/g$a;

    invoke-direct {v0, p0}, Lc0/g$a;-><init>(Lc0/g;)V

    return-object v0
.end method

.method public final c(I)Z
    .registers 3

    iget v0, p0, Lc0/g;->i:I

    and-int/2addr v0, p1

    if-ne v0, p1, :cond_7

    const/4 p1, 0x1

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    return p1
.end method

.method public final d(J)Lc0/g;
    .registers 8

    iget-wide v0, p0, Lc0/g;->g:J

    const-wide/16 v2, -0x1

    cmp-long v4, v0, v2

    if-nez v4, :cond_9

    goto :goto_b

    :cond_9
    sub-long v2, v0, p1

    :goto_b
    invoke-virtual {p0, p1, p2, v2, v3}, Lc0/g;->e(JJ)Lc0/g;

    move-result-object p1

    return-object p1
.end method

.method public final e(JJ)Lc0/g;
    .registers 22

    move-object/from16 v0, p0

    const-wide/16 v1, 0x0

    cmp-long v3, p1, v1

    if-nez v3, :cond_f

    iget-wide v1, v0, Lc0/g;->g:J

    cmp-long v3, v1, p3

    if-nez v3, :cond_f

    return-object v0

    :cond_f
    new-instance v1, Lc0/g;

    iget-wide v2, v0, Lc0/g;->f:J

    add-long v10, v2, p1

    iget v15, v0, Lc0/g;->i:I

    iget-object v2, v0, Lc0/g;->j:Ljava/lang/Object;

    iget-object v4, v0, Lc0/g;->a:Landroid/net/Uri;

    iget-wide v5, v0, Lc0/g;->b:J

    iget v7, v0, Lc0/g;->c:I

    iget-object v8, v0, Lc0/g;->d:[B

    iget-object v9, v0, Lc0/g;->e:Ljava/util/Map;

    iget-object v14, v0, Lc0/g;->h:Ljava/lang/String;

    move-object v3, v1

    move-wide/from16 v12, p3

    move-object/from16 v16, v2

    invoke-direct/range {v3 .. v16}, Lc0/g;-><init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;)V

    return-object v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DataSpec["

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lc0/g;->c:I

    invoke-static {v1}, Lc0/g;->b(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lc0/g;->a:Landroid/net/Uri;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lc0/g;->f:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lc0/g;->g:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc0/g;->h:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lc0/g;->i:I

    const-string v2, "]"

    invoke-static {v0, v1, v2}, LE/f;->b(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
