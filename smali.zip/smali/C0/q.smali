.class public final Lc0/q;
.super Ljava/lang/Object;
.source "TeeDataSource.java"

# interfaces
.implements Landroidx/media3/datasource/b;


# instance fields
.field private final a:Landroidx/media3/datasource/b;

.field private final b:Lc0/c;

.field private c:Z

.field private d:J


# direct methods
.method public constructor <init>(Landroidx/media3/datasource/b;Lc0/c;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc0/q;->a:Landroidx/media3/datasource/b;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p0, Lc0/q;->b:Lc0/c;

    return-void
.end method


# virtual methods
.method public final a(Lc0/g;)J
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lc0/q;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1}, Landroidx/media3/datasource/b;->a(Lc0/g;)J

    move-result-wide v0

    iput-wide v0, p0, Lc0/q;->d:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-nez v4, :cond_f

    return-wide v2

    :cond_f
    iget-wide v4, p1, Lc0/g;->g:J

    const-wide/16 v6, -0x1

    cmp-long v8, v4, v6

    if-nez v8, :cond_1f

    cmp-long v4, v0, v6

    if-eqz v4, :cond_1f

    invoke-virtual {p1, v2, v3, v0, v1}, Lc0/g;->e(JJ)Lc0/g;

    move-result-object p1

    :cond_1f
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc0/q;->c:Z

    iget-object v0, p0, Lc0/q;->b:Lc0/c;

    invoke-interface {v0, p1}, Lc0/c;->a(Lc0/g;)V

    iget-wide v0, p0, Lc0/q;->d:J

    return-wide v0
.end method

.method public final c()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lc0/q;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->c()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public final close()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lc0/q;->b:Lc0/c;

    const/4 v1, 0x0

    :try_start_3
    iget-object v2, p0, Lc0/q;->a:Landroidx/media3/datasource/b;

    invoke-interface {v2}, Landroidx/media3/datasource/b;->close()V
    :try_end_8
    .catchall {:try_start_3 .. :try_end_8} :catchall_12

    iget-boolean v2, p0, Lc0/q;->c:Z

    if-eqz v2, :cond_11

    iput-boolean v1, p0, Lc0/q;->c:Z

    invoke-interface {v0}, Lc0/c;->close()V

    :cond_11
    return-void

    :catchall_12
    move-exception v2

    iget-boolean v3, p0, Lc0/q;->c:Z

    if-eqz v3, :cond_1c

    iput-boolean v1, p0, Lc0/q;->c:Z

    invoke-interface {v0}, Lc0/c;->close()V

    :cond_1c
    throw v2
.end method

.method public final e(Lc0/r;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc0/q;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1}, Landroidx/media3/datasource/b;->e(Lc0/r;)V

    return-void
.end method

.method public final getUri()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc0/q;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->getUri()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final read([BII)I
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-wide v0, p0, Lc0/q;->d:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-nez v4, :cond_a

    const/4 p1, -0x1

    return p1

    :cond_a
    iget-object v0, p0, Lc0/q;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1, p2, p3}, Landroidx/media3/common/i;->read([BII)I

    move-result p3

    if-lez p3, :cond_23

    iget-object v0, p0, Lc0/q;->b:Lc0/c;

    invoke-interface {v0, p1, p2, p3}, Lc0/c;->write([BII)V

    iget-wide p1, p0, Lc0/q;->d:J

    const-wide/16 v0, -0x1

    cmp-long v2, p1, v0

    if-eqz v2, :cond_23

    int-to-long v0, p3

    sub-long/2addr p1, v0

    iput-wide p1, p0, Lc0/q;->d:J

    :cond_23
    return p3
.end method
