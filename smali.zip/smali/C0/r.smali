.class public interface abstract Lc0/r;
.super Ljava/lang/Object;
.source "TransferListener.java"


# virtual methods
.method public abstract a(Lc0/g;Z)V
.end method

.method public abstract b(Lc0/g;ZI)V
.end method

.method public abstract c(Lc0/g;Z)V
.end method
