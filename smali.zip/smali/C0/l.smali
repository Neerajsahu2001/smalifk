.class public final Lc0/l;
.super Lc0/k;
.source "HttpDataSource.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    const-string v0, "Invalid content type: "

    invoke-static {v0, p1}, Landroidx/coordinatorlayout/widget/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x7d3

    invoke-direct {p0, p1, v0}, Lc0/k;-><init>(Ljava/lang/String;I)V

    return-void
.end method
