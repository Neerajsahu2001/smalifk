.class public final Lc0/p;
.super Ljava/lang/Object;
.source "StatsDataSource.java"

# interfaces
.implements Landroidx/media3/datasource/b;


# instance fields
.field private final a:Landroidx/media3/datasource/b;

.field private b:J

.field private c:Landroid/net/Uri;

.field private d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/media3/datasource/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lc0/p;->a:Landroidx/media3/datasource/b;

    sget-object p1, Landroid/net/Uri;->EMPTY:Landroid/net/Uri;

    iput-object p1, p0, Lc0/p;->c:Landroid/net/Uri;

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, Lc0/p;->d:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final a(Lc0/g;)J
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p1, Lc0/g;->a:Landroid/net/Uri;

    iput-object v0, p0, Lc0/p;->c:Landroid/net/Uri;

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lc0/p;->d:Ljava/util/Map;

    iget-object v0, p0, Lc0/p;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1}, Landroidx/media3/datasource/b;->a(Lc0/g;)J

    move-result-wide v1

    invoke-interface {v0}, Landroidx/media3/datasource/b;->getUri()Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lc0/p;->c:Landroid/net/Uri;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->c()Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, Lc0/p;->d:Ljava/util/Map;

    return-wide v1
.end method

.method public final c()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lc0/p;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->c()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public final close()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lc0/p;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->close()V

    return-void
.end method

.method public final e(Lc0/r;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc0/p;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1}, Landroidx/media3/datasource/b;->e(Lc0/r;)V

    return-void
.end method

.method public final getUri()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc0/p;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->getUri()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final k()J
    .registers 3

    iget-wide v0, p0, Lc0/p;->b:J

    return-wide v0
.end method

.method public final l()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc0/p;->c:Landroid/net/Uri;

    return-object v0
.end method

.method public final m()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lc0/p;->d:Ljava/util/Map;

    return-object v0
.end method

.method public final n()V
    .registers 3

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc0/p;->b:J

    return-void
.end method

.method public final read([BII)I
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lc0/p;->a:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1, p2, p3}, Landroidx/media3/common/i;->read([BII)I

    move-result p1

    const/4 p2, -0x1

    if-eq p1, p2, :cond_f

    iget-wide p2, p0, Lc0/p;->b:J

    int-to-long v0, p1

    add-long/2addr p2, v0

    iput-wide p2, p0, Lc0/p;->b:J

    :cond_f
    return p1
.end method
