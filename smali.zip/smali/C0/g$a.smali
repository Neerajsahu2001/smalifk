.class public final Lc0/g$a;
.super Ljava/lang/Object;
.source "DataSpec.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc0/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:Landroid/net/Uri;

.field private b:J

.field private c:I

.field private d:[B

.field private e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private f:J

.field private g:J

.field private h:Ljava/lang/String;

.field private i:I

.field private j:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lc0/g$a;->c:I

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lc0/g$a;->e:Ljava/util/Map;

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lc0/g$a;->g:J

    return-void
.end method

.method constructor <init>(Lc0/g;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p1, Lc0/g;->a:Landroid/net/Uri;

    iput-object v0, p0, Lc0/g$a;->a:Landroid/net/Uri;

    iget-wide v0, p1, Lc0/g;->b:J

    iput-wide v0, p0, Lc0/g$a;->b:J

    iget v0, p1, Lc0/g;->c:I

    iput v0, p0, Lc0/g$a;->c:I

    iget-object v0, p1, Lc0/g;->d:[B

    iput-object v0, p0, Lc0/g$a;->d:[B

    iget-object v0, p1, Lc0/g;->e:Ljava/util/Map;

    iput-object v0, p0, Lc0/g$a;->e:Ljava/util/Map;

    iget-wide v0, p1, Lc0/g;->f:J

    iput-wide v0, p0, Lc0/g$a;->f:J

    iget-wide v0, p1, Lc0/g;->g:J

    iput-wide v0, p0, Lc0/g$a;->g:J

    iget-object v0, p1, Lc0/g;->h:Ljava/lang/String;

    iput-object v0, p0, Lc0/g$a;->h:Ljava/lang/String;

    iget v0, p1, Lc0/g;->i:I

    iput v0, p0, Lc0/g$a;->i:I

    iget-object p1, p1, Lc0/g;->j:Ljava/lang/Object;

    iput-object p1, p0, Lc0/g$a;->j:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a()Lc0/g;
    .registers 18

    move-object/from16 v0, p0

    iget-object v1, v0, Lc0/g$a;->a:Landroid/net/Uri;

    if-eqz v1, :cond_23

    new-instance v1, Lc0/g;

    iget-object v3, v0, Lc0/g$a;->a:Landroid/net/Uri;

    iget-wide v4, v0, Lc0/g$a;->b:J

    iget v6, v0, Lc0/g$a;->c:I

    iget-object v7, v0, Lc0/g$a;->d:[B

    iget-object v8, v0, Lc0/g$a;->e:Ljava/util/Map;

    iget-wide v9, v0, Lc0/g$a;->f:J

    iget-wide v11, v0, Lc0/g$a;->g:J

    iget-object v13, v0, Lc0/g$a;->h:Ljava/lang/String;

    iget v14, v0, Lc0/g$a;->i:I

    iget-object v15, v0, Lc0/g$a;->j:Ljava/lang/Object;

    const/16 v16, 0x0

    move-object v2, v1

    invoke-direct/range {v2 .. v16}, Lc0/g;-><init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;I)V

    return-object v1

    :cond_23
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "The uri must be set."

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final b(I)V
    .registers 2

    iput p1, p0, Lc0/g$a;->i:I

    return-void
.end method

.method public final c([B)V
    .registers 2

    iput-object p1, p0, Lc0/g$a;->d:[B

    return-void
.end method

.method public final d()V
    .registers 2

    const/4 v0, 0x2

    iput v0, p0, Lc0/g$a;->c:I

    return-void
.end method

.method public final e(Ljava/util/Map;)V
    .registers 2

    iput-object p1, p0, Lc0/g$a;->e:Ljava/util/Map;

    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lc0/g$a;->h:Ljava/lang/String;

    return-void
.end method

.method public final g(J)V
    .registers 3

    iput-wide p1, p0, Lc0/g$a;->g:J

    return-void
.end method

.method public final h(J)V
    .registers 3

    iput-wide p1, p0, Lc0/g$a;->f:J

    return-void
.end method

.method public final i(Landroid/net/Uri;)V
    .registers 2

    iput-object p1, p0, Lc0/g$a;->a:Landroid/net/Uri;

    return-void
.end method

.method public final j(Ljava/lang/String;)V
    .registers 2

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    iput-object p1, p0, Lc0/g$a;->a:Landroid/net/Uri;

    return-void
.end method

.method public final k(J)V
    .registers 3

    iput-wide p1, p0, Lc0/g$a;->b:J

    return-void
.end method
