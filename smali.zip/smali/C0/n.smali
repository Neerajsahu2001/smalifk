.class public final Lc0/n;
.super Ljava/lang/Object;
.source "HttpDataSource.java"


# instance fields
.field private final a:Ljava/io/Serializable;

.field private b:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lc0/n;->a:Ljava/io/Serializable;

    return-void
.end method

.method public constructor <init>(LPi/b;Landroid/os/Bundle;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc0/n;->a:Ljava/io/Serializable;

    iput-object p2, p0, Lc0/n;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Ljava/util/Map;)V
    .registers 3

    monitor-enter p0

    const/4 v0, 0x0

    :try_start_2
    iput-object v0, p0, Lc0/n;->b:Ljava/lang/Object;

    iget-object v0, p0, Lc0/n;->a:Ljava/io/Serializable;

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    iget-object v0, p0, Lc0/n;->a:Ljava/io/Serializable;

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V
    :try_end_12
    .catchall {:try_start_2 .. :try_end_12} :catchall_14

    monitor-exit p0

    return-void

    :catchall_14
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized b()Ljava/util/Map;
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lc0/n;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Map;

    if-nez v0, :cond_19

    new-instance v0, Ljava/util/HashMap;

    iget-object v1, p0, Lc0/n;->a:Ljava/io/Serializable;

    check-cast v1, Ljava/util/Map;

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lc0/n;->b:Ljava/lang/Object;

    goto :goto_19

    :catchall_17
    move-exception v0

    goto :goto_1f

    :cond_19
    :goto_19
    iget-object v0, p0, Lc0/n;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Map;
    :try_end_1d
    .catchall {:try_start_1 .. :try_end_1d} :catchall_17

    monitor-exit p0

    return-object v0

    :goto_1f
    monitor-exit p0

    throw v0
.end method
