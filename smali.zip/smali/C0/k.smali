.class public Lc0/k;
.super Lc0/e;
.source "HttpDataSource.java"


# instance fields
.field public final c:I


# direct methods
.method public constructor <init>(I)V
    .registers 3

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lc0/k;->a(II)I

    move-result p1

    invoke-direct {p0, p1}, Lc0/e;-><init>(I)V

    iput v0, p0, Lc0/k;->c:I

    return-void
.end method

.method public constructor <init>(Ljava/io/IOException;II)V
    .registers 4

    invoke-static {p2, p3}, Lc0/k;->a(II)I

    move-result p2

    invoke-direct {p0, p1, p2}, Lc0/e;-><init>(Ljava/lang/Throwable;I)V

    iput p3, p0, Lc0/k;->c:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 4

    const/4 v0, 0x1

    invoke-static {p2, v0}, Lc0/k;->a(II)I

    move-result p2

    invoke-direct {p0, p1, p2}, Lc0/e;-><init>(Ljava/lang/String;I)V

    iput v0, p0, Lc0/k;->c:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/io/IOException;I)V
    .registers 5

    const/4 v0, 0x1

    invoke-static {p3, v0}, Lc0/k;->a(II)I

    move-result p3

    invoke-direct {p0, p3, p1, p2}, Lc0/e;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    iput v0, p0, Lc0/k;->c:I

    return-void
.end method

.method private static a(II)I
    .registers 3

    const/16 v0, 0x7d0

    if-ne p0, v0, :cond_9

    const/4 v0, 0x1

    if-ne p1, v0, :cond_9

    const/16 p0, 0x7d1

    :cond_9
    return p0
.end method

.method public static b(Ljava/io/IOException;I)Lc0/k;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    instance-of v1, p0, Ljava/net/SocketTimeoutException;

    const/16 v2, 0x7d7

    if-eqz v1, :cond_d

    const/16 v0, 0x7d2

    goto :goto_27

    :cond_d
    instance-of v1, p0, Ljava/io/InterruptedIOException;

    if-eqz v1, :cond_14

    const/16 v0, 0x3ec

    goto :goto_27

    :cond_14
    if-eqz v0, :cond_25

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/d0;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "cleartext.*not permitted.*"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_25

    const/16 v0, 0x7d7

    goto :goto_27

    :cond_25
    const/16 v0, 0x7d1

    :goto_27
    if-ne v0, v2, :cond_31

    new-instance p1, Lc0/j;

    const-string v0, "Cleartext HTTP traffic not permitted. See https://developer.android.com/guide/topics/media/issues/cleartext-not-permitted"

    invoke-direct {p1, v0, p0, v2}, Lc0/k;-><init>(Ljava/lang/String;Ljava/io/IOException;I)V

    goto :goto_37

    :cond_31
    new-instance v1, Lc0/k;

    invoke-direct {v1, p0, v0, p1}, Lc0/k;-><init>(Ljava/io/IOException;II)V

    move-object p1, v1

    :goto_37
    return-object p1
.end method
