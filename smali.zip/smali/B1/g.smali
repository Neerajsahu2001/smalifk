.class final LB1/g;
.super Ljava/lang/Object;
.source "Task.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:LB1/i;

.field final synthetic b:Ljava/util/concurrent/Callable;


# direct methods
.method constructor <init>(LB1/i;Ljava/util/concurrent/Callable;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB1/g;->a:LB1/i;

    iput-object p2, p0, LB1/g;->b:Ljava/util/concurrent/Callable;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, LB1/g;->a:LB1/i;

    :try_start_2
    iget-object v1, p0, LB1/g;->b:Ljava/util/concurrent/Callable;

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, LB1/i;->d(Ljava/lang/Object;)V
    :try_end_b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_b} :catch_11
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_b} :catch_c

    goto :goto_14

    :catch_c
    move-exception v1

    invoke-virtual {v0, v1}, LB1/i;->c(Ljava/lang/Exception;)V

    goto :goto_14

    :catch_11
    invoke-virtual {v0}, LB1/i;->b()V

    :goto_14
    return-void
.end method
