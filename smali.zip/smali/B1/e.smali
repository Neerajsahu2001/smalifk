.class final LB1/e;
.super Ljava/lang/Object;
.source "Task.java"

# interfaces
.implements LB1/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LB1/c<",
        "Ljava/lang/Object;",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LB1/i;

.field final synthetic b:LB1/c;

.field final synthetic c:Ljava/util/concurrent/Executor;


# direct methods
.method constructor <init>(LB1/c;LB1/i;Ljava/util/concurrent/Executor;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LB1/e;->a:LB1/i;

    iput-object p1, p0, LB1/e;->b:LB1/c;

    iput-object p3, p0, LB1/e;->c:Ljava/util/concurrent/Executor;

    return-void
.end method


# virtual methods
.method public final a(LB1/h;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    iget-object v0, p0, LB1/e;->c:Ljava/util/concurrent/Executor;

    iget-object v1, p0, LB1/e;->b:LB1/c;

    iget-object v2, p0, LB1/e;->a:LB1/i;

    invoke-static {v1, p1, v2, v0}, LB1/h;->a(LB1/c;LB1/h;LB1/i;Ljava/util/concurrent/Executor;)V

    return-void
.end method
