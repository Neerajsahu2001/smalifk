.class public final LB1/i;
.super Ljava/lang/Object;
.source "TaskCompletionSource.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<TResult:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private final a:LB1/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LB1/h<",
            "TTResult;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LB1/h;

    invoke-direct {v0}, LB1/h;-><init>()V

    iput-object v0, p0, LB1/i;->a:LB1/h;

    return-void
.end method


# virtual methods
.method public final a()LB1/h;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LB1/h<",
            "TTResult;>;"
        }
    .end annotation

    iget-object v0, p0, LB1/i;->a:LB1/h;

    return-object v0
.end method

.method public final b()V
    .registers 3

    iget-object v0, p0, LB1/i;->a:LB1/h;

    invoke-virtual {v0}, LB1/h;->l()Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    :cond_9
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot cancel a completed task."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c(Ljava/lang/Exception;)V
    .registers 3

    iget-object v0, p0, LB1/i;->a:LB1/h;

    invoke-virtual {v0, p1}, LB1/h;->m(Ljava/lang/Exception;)Z

    move-result p1

    if-eqz p1, :cond_9

    return-void

    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Cannot set the error on a completed task."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final d(Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTResult;)V"
        }
    .end annotation

    iget-object v0, p0, LB1/i;->a:LB1/h;

    invoke-virtual {v0, p1}, LB1/h;->n(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_9

    return-void

    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Cannot set the result of a completed task."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
