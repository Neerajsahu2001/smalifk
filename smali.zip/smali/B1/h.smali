.class public final LB1/h;
.super Ljava/lang/Object;
.source "Task.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<TResult:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field public static final g:Ljava/util/concurrent/ExecutorService;

.field private static final h:Ljava/util/concurrent/Executor;

.field public static final i:Ljava/util/concurrent/Executor;

.field private static j:LB1/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LB1/h<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private static k:LB1/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LB1/h<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Ljava/lang/Object;

.field private b:Z

.field private c:Z

.field private d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TTResult;"
        }
    .end annotation
.end field

.field private e:Ljava/lang/Exception;

.field private f:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    invoke-static {}, LB1/b;->a()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, LB1/h;->g:Ljava/util/concurrent/ExecutorService;

    invoke-static {}, LB1/b;->b()Ljava/util/concurrent/Executor;

    move-result-object v0

    sput-object v0, LB1/h;->h:Ljava/util/concurrent/Executor;

    invoke-static {}, LB1/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v0

    sput-object v0, LB1/h;->i:Ljava/util/concurrent/Executor;

    new-instance v0, LB1/h;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LB1/h;-><init>(Ljava/lang/Boolean;)V

    new-instance v0, LB1/h;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-direct {v0, v1}, LB1/h;-><init>(Ljava/lang/Boolean;)V

    sput-object v0, LB1/h;->j:LB1/h;

    new-instance v0, LB1/h;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {v0, v1}, LB1/h;-><init>(Ljava/lang/Boolean;)V

    sput-object v0, LB1/h;->k:LB1/h;

    new-instance v0, LB1/h;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LB1/h;-><init>(I)V

    return-void
.end method

.method constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LB1/h;->f:Ljava/util/ArrayList;

    return-void
.end method

.method private constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB1/h;->a:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LB1/h;->f:Ljava/util/ArrayList;

    invoke-virtual {p0}, LB1/h;->l()Z

    return-void
.end method

.method private constructor <init>(Ljava/lang/Boolean;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LB1/h;->f:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, LB1/h;->n(Ljava/lang/Object;)Z

    return-void
.end method

.method static a(LB1/c;LB1/h;LB1/i;Ljava/util/concurrent/Executor;)V
    .registers 5

    :try_start_0
    new-instance v0, LB1/f;

    invoke-direct {v0, p2, p0, p1}, LB1/f;-><init>(LB1/i;LB1/c;LB1/h;)V

    invoke-interface {p3, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_9

    goto :goto_12

    :catch_9
    move-exception p0

    new-instance p1, LB1/d;

    invoke-direct {p1, p0}, LB1/d;-><init>(Ljava/lang/Exception;)V

    invoke-virtual {p2, p1}, LB1/i;->c(Ljava/lang/Exception;)V

    :goto_12
    return-void
.end method

.method public static b(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)LB1/h;
    .registers 4

    new-instance v0, LB1/i;

    invoke-direct {v0}, LB1/i;-><init>()V

    :try_start_5
    new-instance v1, LB1/g;

    invoke-direct {v1, v0, p1}, LB1/g;-><init>(LB1/i;Ljava/util/concurrent/Callable;)V

    invoke-interface {p0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_d} :catch_e

    goto :goto_17

    :catch_e
    move-exception p0

    new-instance p1, LB1/d;

    invoke-direct {p1, p0}, LB1/d;-><init>(Ljava/lang/Exception;)V

    invoke-virtual {v0, p1}, LB1/i;->c(Ljava/lang/Exception;)V

    :goto_17
    invoke-virtual {v0}, LB1/i;->a()LB1/h;

    move-result-object p0

    return-object p0
.end method

.method private static c(LB1/c;LB1/h;LB1/i;Ljava/util/concurrent/Executor;)V
    .registers 5

    :try_start_0
    new-instance v0, LB1/f;

    invoke-direct {v0, p2, p0, p1}, LB1/f;-><init>(LB1/i;LB1/c;LB1/h;)V

    invoke-interface {p3, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_9

    goto :goto_12

    :catch_9
    move-exception p0

    new-instance p1, LB1/d;

    invoke-direct {p1, p0}, LB1/d;-><init>(Ljava/lang/Exception;)V

    invoke-virtual {p2, p1}, LB1/i;->c(Ljava/lang/Exception;)V

    :goto_12
    return-void
.end method

.method public static e(Lo3/d;)LB1/h;
    .registers 2

    instance-of v0, p0, Ljava/lang/Boolean;

    if-eqz v0, :cond_12

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_f

    sget-object p0, LB1/h;->j:LB1/h;

    goto :goto_11

    :cond_f
    sget-object p0, LB1/h;->k:LB1/h;

    :goto_11
    return-object p0

    :cond_12
    new-instance v0, LB1/i;

    invoke-direct {v0}, LB1/i;-><init>()V

    invoke-virtual {v0, p0}, LB1/i;->d(Ljava/lang/Object;)V

    invoke-virtual {v0}, LB1/i;->a()LB1/h;

    move-result-object p0

    return-object p0
.end method

.method private k()V
    .registers 4

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LB1/h;->f:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_24

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LB1/c;
    :try_end_15
    .catchall {:try_start_3 .. :try_end_15} :catchall_19

    :try_start_15
    invoke-interface {v2, p0}, LB1/c;->a(LB1/h;)V
    :try_end_18
    .catch Ljava/lang/RuntimeException; {:try_start_15 .. :try_end_18} :catch_22
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_18} :catch_1b
    .catchall {:try_start_15 .. :try_end_18} :catchall_19

    goto :goto_9

    :catchall_19
    move-exception v1

    goto :goto_29

    :catch_1b
    move-exception v1

    :try_start_1c
    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :catch_22
    move-exception v1

    throw v1

    :cond_24
    const/4 v1, 0x0

    iput-object v1, p0, LB1/h;->f:Ljava/util/ArrayList;

    monitor-exit v0

    return-void

    :goto_29
    monitor-exit v0
    :try_end_2a
    .catchall {:try_start_1c .. :try_end_2a} :catchall_19

    throw v1
.end method


# virtual methods
.method public final d(LB1/c;)V
    .registers 8

    sget-object v0, LB1/h;->h:Ljava/util/concurrent/Executor;

    new-instance v1, LB1/i;

    invoke-direct {v1}, LB1/i;-><init>()V

    iget-object v2, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v2

    :try_start_a
    invoke-virtual {p0}, LB1/h;->i()Z

    move-result v3

    if-nez v3, :cond_1d

    iget-object v4, p0, LB1/h;->f:Ljava/util/ArrayList;

    new-instance v5, LB1/e;

    invoke-direct {v5, p1, v1, v0}, LB1/e;-><init>(LB1/c;LB1/i;Ljava/util/concurrent/Executor;)V

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1d

    :catchall_1b
    move-exception p1

    goto :goto_24

    :cond_1d
    :goto_1d
    monitor-exit v2
    :try_end_1e
    .catchall {:try_start_a .. :try_end_1e} :catchall_1b

    if-eqz v3, :cond_23

    invoke-static {p1, p0, v1, v0}, LB1/h;->c(LB1/c;LB1/h;LB1/i;Ljava/util/concurrent/Executor;)V

    :cond_23
    return-void

    :goto_24
    :try_start_24
    monitor-exit v2
    :try_end_25
    .catchall {:try_start_24 .. :try_end_25} :catchall_1b

    throw p1
.end method

.method public final f()Ljava/lang/Exception;
    .registers 3

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LB1/h;->e:Ljava/lang/Exception;

    monitor-exit v0

    return-object v1

    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public final g()Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TTResult;"
        }
    .end annotation

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LB1/h;->d:Ljava/lang/Object;

    monitor-exit v0

    return-object v1

    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public final h()Z
    .registers 3

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LB1/h;->c:Z

    monitor-exit v0

    return v1

    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public final i()Z
    .registers 3

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LB1/h;->b:Z

    monitor-exit v0

    return v1

    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public final j()Z
    .registers 3

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p0}, LB1/h;->f()Ljava/lang/Exception;

    move-result-object v1

    if-eqz v1, :cond_b

    const/4 v1, 0x1

    goto :goto_c

    :cond_b
    const/4 v1, 0x0

    :goto_c
    monitor-exit v0

    return v1

    :catchall_e
    move-exception v1

    monitor-exit v0
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_e

    throw v1
.end method

.method final l()Z
    .registers 4

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LB1/h;->b:Z

    if-eqz v1, :cond_c

    monitor-exit v0

    const/4 v0, 0x0

    return v0

    :catchall_a
    move-exception v1

    goto :goto_1b

    :cond_c
    const/4 v1, 0x1

    iput-boolean v1, p0, LB1/h;->b:Z

    iput-boolean v1, p0, LB1/h;->c:Z

    iget-object v2, p0, LB1/h;->a:Ljava/lang/Object;

    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V

    invoke-direct {p0}, LB1/h;->k()V

    monitor-exit v0

    return v1

    :goto_1b
    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_a

    throw v1
.end method

.method final m(Ljava/lang/Exception;)Z
    .registers 4

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LB1/h;->b:Z

    if-eqz v1, :cond_c

    monitor-exit v0

    const/4 p1, 0x0

    return p1

    :catchall_a
    move-exception p1

    goto :goto_1b

    :cond_c
    const/4 v1, 0x1

    iput-boolean v1, p0, LB1/h;->b:Z

    iput-object p1, p0, LB1/h;->e:Ljava/lang/Exception;

    iget-object p1, p0, LB1/h;->a:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    invoke-direct {p0}, LB1/h;->k()V

    monitor-exit v0

    return v1

    :goto_1b
    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_a

    throw p1
.end method

.method final n(Ljava/lang/Object;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTResult;)Z"
        }
    .end annotation

    iget-object v0, p0, LB1/h;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LB1/h;->b:Z

    if-eqz v1, :cond_c

    monitor-exit v0

    const/4 p1, 0x0

    return p1

    :catchall_a
    move-exception p1

    goto :goto_1b

    :cond_c
    const/4 v1, 0x1

    iput-boolean v1, p0, LB1/h;->b:Z

    iput-object p1, p0, LB1/h;->d:Ljava/lang/Object;

    iget-object p1, p0, LB1/h;->a:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    invoke-direct {p0}, LB1/h;->k()V

    monitor-exit v0

    return v1

    :goto_1b
    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_a

    throw p1
.end method
