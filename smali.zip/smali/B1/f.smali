.class final LB1/f;
.super Ljava/lang/Object;
.source "Task.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:LB1/i;

.field final synthetic b:LB1/c;

.field final synthetic c:LB1/h;


# direct methods
.method constructor <init>(LB1/i;LB1/c;LB1/h;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB1/f;->a:LB1/i;

    iput-object p2, p0, LB1/f;->b:LB1/c;

    iput-object p3, p0, LB1/f;->c:LB1/h;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, LB1/f;->a:LB1/i;

    :try_start_2
    iget-object v1, p0, LB1/f;->b:LB1/c;

    iget-object v2, p0, LB1/f;->c:LB1/h;

    invoke-interface {v1, v2}, LB1/c;->a(LB1/h;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, LB1/i;->d(Ljava/lang/Object;)V
    :try_end_d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_d} :catch_13
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_d} :catch_e

    goto :goto_16

    :catch_e
    move-exception v1

    invoke-virtual {v0, v1}, LB1/i;->c(Ljava/lang/Exception;)V

    goto :goto_16

    :catch_13
    invoke-virtual {v0}, LB1/i;->b()V

    :goto_16
    return-void
.end method
