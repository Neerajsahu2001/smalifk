.class final LA5/b$b;
.super Lkotlin/jvm/internal/p;
.source "KevlarLogUtils.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LA5/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Lvp/h;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LA5/b$b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LA5/b$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LA5/b$b;->a:LA5/b$b;

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, LA5/b$b;->invoke()Lvp/h;

    move-result-object v0

    return-object v0
.end method

.method public final invoke()Lvp/h;
    .registers 3

    new-instance v0, Lvp/h;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->getKevlarRegex()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_e

    const-string v1, "^(?:[a-zA-Z\\d+=/]+\\.){2}[\\w+=/-]+$"

    :cond_e
    invoke-direct {v0, v1}, Lvp/h;-><init>(Ljava/lang/String;)V

    return-object v0
.end method
