.class final LA5/b$a;
.super Lkotlin/coroutines/jvm/internal/i;
.source "KevlarLogUtils.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LA5/b;->logToken(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.network.kevlar.KevlarLogUtils$logToken$1"
    f = "KevlarLogUtils.kt"
    l = {}
    m = "invokeSuspend"
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/Boolean;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;LXn/d;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            "LXn/d<",
            "-",
            "LA5/b$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LA5/b$a;->a:Ljava/lang/String;

    iput-object p2, p0, LA5/b$a;->b:Ljava/lang/String;

    iput-object p3, p0, LA5/b$a;->c:Ljava/lang/String;

    iput-object p4, p0, LA5/b$a;->d:Ljava/lang/Boolean;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LA5/b$a;

    iget-object v3, p0, LA5/b$a;->c:Ljava/lang/String;

    iget-object v4, p0, LA5/b$a;->d:Ljava/lang/Boolean;

    iget-object v1, p0, LA5/b$a;->a:Ljava/lang/String;

    iget-object v2, p0, LA5/b$a;->b:Ljava/lang/String;

    move-object v0, p1

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, LA5/b$a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LA5/b$a;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LA5/b$a;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LA5/b$a;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LA5/b$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    sget-object p1, LA5/b;->a:LA5/b;

    invoke-static {p1}, LA5/b;->access$getPattern(LA5/b;)Lvp/h;

    move-result-object v0

    iget-object v1, p0, LA5/b$a;->a:Ljava/lang/String;

    const-string v2, ""

    if-nez v1, :cond_11

    move-object v3, v2

    goto :goto_12

    :cond_11
    move-object v3, v1

    :goto_12
    invoke-virtual {v0, v3}, Lvp/h;->d(Ljava/lang/CharSequence;)Z

    move-result v0

    invoke-static {p1}, LA5/b;->access$getPattern(LA5/b;)Lvp/h;

    move-result-object p1

    iget-object v3, p0, LA5/b$a;->b:Ljava/lang/String;

    if-nez v3, :cond_20

    move-object v4, v2

    goto :goto_21

    :cond_20
    move-object v4, v3

    :goto_21
    invoke-virtual {p1, v4}, Lvp/h;->d(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez v0, :cond_c2

    const/4 v4, 0x7

    new-array v4, v4, [LUn/j;

    if-nez v0, :cond_2e

    if-nez v1, :cond_2f

    :cond_2e
    move-object v1, v2

    :cond_2f
    new-instance v5, LUn/j;

    const-string v6, "AT"

    invoke-direct {v5, v6, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x0

    aput-object v5, v4, v1

    if-nez p1, :cond_3d

    if-nez v3, :cond_3e

    :cond_3d
    move-object v3, v2

    :cond_3e
    new-instance v1, LUn/j;

    const-string v5, "RT"

    invoke-direct {v1, v5, v3}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x1

    aput-object v1, v4, v3

    new-instance v1, LUn/j;

    const-string v3, "Origin"

    iget-object v5, p0, LA5/b$a;->c:Ljava/lang/String;

    invoke-direct {v1, v3, v5}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x2

    aput-object v1, v4, v3

    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "this as java.lang.String).toUpperCase(Locale.ROOT)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v5, LUn/j;

    const-string v6, "ValidAT"

    invoke-direct {v5, v6, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v0, 0x3

    aput-object v5, v4, v0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LUn/j;

    const-string v5, "ValidRT"

    invoke-direct {v0, v5, p1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x4

    aput-object v0, v4, p1

    iget-object p1, p0, LA5/b$a;->d:Ljava/lang/Boolean;

    if-nez p1, :cond_8e

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getSessionManager()Lcom/flipkart/android/config/f;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/f;->isLoggedIn()Ljava/lang/Boolean;

    move-result-object p1

    :cond_8e
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LUn/j;

    const-string v1, "LoggedIn"

    invoke-direct {v0, v1, p1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x5

    aput-object v0, v4, p1

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getSessionManager()Lcom/flipkart/android/config/f;

    move-result-object p1

    invoke-virtual {p1}, Lcom/flipkart/android/config/f;->getUserAccountId()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_ae

    goto :goto_af

    :cond_ae
    move-object v2, p1

    :goto_af
    new-instance p1, LUn/j;

    const-string v0, "UserID"

    invoke-direct {p1, v0, v2}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v0, 0x6

    aput-object p1, v4, v0

    invoke-static {v4}, Lkotlin/collections/J;->j([LUn/j;)Ljava/util/LinkedHashMap;

    move-result-object p1

    const-string v0, "KEVLAR_LOG_TOKEN"

    invoke-static {v0, p1}, LO7/c;->logCustomEvents(Ljava/lang/String;Ljava/util/Map;)V

    :cond_c2
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
