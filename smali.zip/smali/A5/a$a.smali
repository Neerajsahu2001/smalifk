.class public final LA5/a$a;
.super LFa/e;
.source "KevlarClientImpl.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LA5/a;->performAcknowledgement(LAa/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LFa/e<",
        "Ltf/b;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Lta/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lta/a<",
            "LGe/e0<",
            "Ltf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/String;Lta/a;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lta/a<",
            "LGe/e0<",
            "Ltf/b;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    iput-object p1, p0, LA5/a$a;->a:Ljava/lang/String;

    iput-object p2, p0, LA5/a$a;->b:Lta/a;

    invoke-direct {p0}, LFa/e;-><init>()V

    return-void
.end method


# virtual methods
.method public errorReceived(Lwa/a;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    const-string v0, "errorInfo"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1}, LFa/e;->errorReceived(Lwa/a;)V

    sget-object v0, LA5/b;->a:LA5/b;

    iget-object v1, p1, Lwa/a;->d:Ljava/lang/String;

    if-nez v1, :cond_10

    const-string v1, "NO-SERVER-MESSAGE"

    :cond_10
    iget-object v2, p0, LA5/a$a;->b:Lta/a;

    invoke-interface {v2}, Lta/a;->request()Lokhttp3/Request;

    move-result-object v2

    const-string v3, "null cannot be cast to non-null type okhttp3.Request"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/HttpUrl;->toString()Ljava/lang/String;

    move-result-object v2

    iget p1, p1, Lwa/a;->b:I

    iget-object v3, p0, LA5/a$a;->a:Ljava/lang/String;

    invoke-virtual {v0, v3, v1, v2, p1}, LA5/b;->logError(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ltf/b;

    invoke-virtual {p0, p1}, LA5/a$a;->onSuccess(Ltf/b;)V

    return-void
.end method

.method public onSuccess(Ltf/b;)V
    .registers 5

    sget-object v0, LA5/b;->a:LA5/b;

    const-string v1, "KEVLAR_ACK_SUCCESS"

    iget-object v2, p0, LA5/a$a;->a:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, LA5/b;->logEvent(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p1, :cond_15

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iget-object p1, p1, Ltf/d;->a:Ljava/lang/Object;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1a

    :cond_15
    const-string p1, "KEVLAR_ACK_RESPONSE_ERROR"

    invoke-virtual {v0, p1, v2}, LA5/b;->logEvent(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1a
    return-void
.end method
