.class public final synthetic La5/a;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La5/a;->a:I

    iput-object p2, p0, La5/a;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, La5/a;->a:I

    iget-object v1, p0, La5/a;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_22

    check-cast v1, Lcom/flipkart/android/datagovernance/GlobalContextInfo;

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v0

    invoke-virtual {v1}, Lcom/flipkart/android/datagovernance/GlobalContextInfo;->getCurrentNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/flipkart/android/datagovernance/DGEventsController;->flushEvents(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    return-void

    :pswitch_15
    check-cast v1, Lcom/flipkart/android/permissions/g;

    invoke-static {v1}, Lcom/flipkart/android/permissions/g;->a(Lcom/flipkart/android/permissions/g;)V

    return-void

    :pswitch_1b
    check-cast v1, Lcom/flipkart/android/fragments/qrcodescanner/QRCodeScannerFragment;

    invoke-static {v1}, Lcom/flipkart/android/fragments/qrcodescanner/QRCodeScannerFragment;->b(Lcom/flipkart/android/fragments/qrcodescanner/QRCodeScannerFragment;)V

    return-void

    nop

    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_15
    .end packed-switch
.end method
