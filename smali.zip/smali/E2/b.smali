.class public final Le2/b;
.super Ljava/lang/Object;
.source "UnitTransformation.java"

# interfaces
.implements LW1/m;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LW1/m<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final a:Le2/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Le2/b;

    invoke-direct {v0}, Le2/b;-><init>()V

    sput-object v0, Le2/b;->a:Le2/b;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()Le2/b;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Le2/b<",
            "TT;>;"
        }
    .end annotation

    sget-object v0, Le2/b;->a:Le2/b;

    return-object v0
.end method


# virtual methods
.method public final transform(Landroid/content/Context;Lcom/bumptech/glide/load/engine/w;II)Lcom/bumptech/glide/load/engine/w;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/bumptech/glide/load/engine/w<",
            "TT;>;II)",
            "Lcom/bumptech/glide/load/engine/w<",
            "TT;>;"
        }
    .end annotation

    return-object p2
.end method

.method public final updateDiskCacheKey(Ljava/security/MessageDigest;)V
    .registers 2

    return-void
.end method
