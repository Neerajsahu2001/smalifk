.class public Lf0/e;
.super Ljava/lang/Exception;
.source "DecoderException.java"
