.class public interface abstract Lf0/g$a;
.super Ljava/lang/Object;
.source "DecoderOutputBuffer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf0/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Lf0/g;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
