.class public abstract Lf0/g;
.super Lf0/a;
.source "DecoderOutputBuffer.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lf0/g$a;
    }
.end annotation


# instance fields
.field public b:J

.field public c:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public h()V
    .registers 3

    invoke-super {p0}, Lf0/a;->h()V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lf0/g;->b:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Lf0/g;->c:Z

    return-void
.end method

.method public abstract q()V
.end method
