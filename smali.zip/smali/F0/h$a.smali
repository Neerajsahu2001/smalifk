.class final Lf0/h$a;
.super Ljava/lang/Thread;
.source "SimpleDecoder.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lf0/h;-><init>([Lf0/f;[Lf0/g;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lf0/h;


# direct methods
.method constructor <init>(Lf0/h;)V
    .registers 2

    iput-object p1, p0, Lf0/h$a;->a:Lf0/h;

    const-string p1, "ExoPlayer:SimpleDecoder"

    invoke-direct {p0, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lf0/h$a;->a:Lf0/h;

    invoke-static {v0}, Lf0/h;->f(Lf0/h;)V

    return-void
.end method
