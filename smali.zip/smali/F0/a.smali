.class public abstract Lf0/a;
.super Ljava/lang/Object;
.source "Buffer.java"


# instance fields
.field private a:I


# virtual methods
.method public final f(I)V
    .registers 3

    iget v0, p0, Lf0/a;->a:I

    or-int/2addr p1, v0

    iput p1, p0, Lf0/a;->a:I

    return-void
.end method

.method public h()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, Lf0/a;->a:I

    return-void
.end method

.method protected final i(I)Z
    .registers 3

    iget v0, p0, Lf0/a;->a:I

    and-int/2addr v0, p1

    if-ne v0, p1, :cond_7

    const/4 p1, 0x1

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    return p1
.end method

.method public final j()Z
    .registers 2

    const/high16 v0, 0x10000000

    invoke-virtual {p0, v0}, Lf0/a;->i(I)Z

    move-result v0

    return v0
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Lf0/a;->i(I)Z

    move-result v0

    return v0
.end method

.method public final l()Z
    .registers 2

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lf0/a;->i(I)Z

    move-result v0

    return v0
.end method

.method public final n()Z
    .registers 2

    const/high16 v0, 0x20000000

    invoke-virtual {p0, v0}, Lf0/a;->i(I)Z

    move-result v0

    return v0
.end method

.method public final o(I)V
    .registers 2

    iput p1, p0, Lf0/a;->a:I

    return-void
.end method
