.class public final Lf0/i;
.super Lf0/g;
.source "VideoDecoderOutputBuffer.java"


# virtual methods
.method public final q()V
    .registers 2

    const/4 v0, 0x0

    throw v0
.end method
