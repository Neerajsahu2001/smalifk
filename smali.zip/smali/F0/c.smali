.class public final Lf0/c;
.super Ljava/lang/Object;
.source "CryptoInfo.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lf0/c$a;
    }
.end annotation


# instance fields
.field public a:[B

.field public b:[B

.field public c:I

.field public d:[I

.field public e:[I

.field public f:I

.field public g:I

.field public h:I

.field private final i:Landroid/media/MediaCodec$CryptoInfo;

.field private final j:Lf0/c$a;


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/media/MediaCodec$CryptoInfo;

    invoke-direct {v0}, Landroid/media/MediaCodec$CryptoInfo;-><init>()V

    iput-object v0, p0, Lf0/c;->i:Landroid/media/MediaCodec$CryptoInfo;

    sget v1, La0/T;->a:I

    const/16 v2, 0x18

    if-lt v1, v2, :cond_16

    new-instance v1, Lf0/c$a;

    invoke-direct {v1, v0}, Lf0/c$a;-><init>(Landroid/media/MediaCodec$CryptoInfo;)V

    goto :goto_17

    :cond_16
    const/4 v1, 0x0

    :goto_17
    iput-object v1, p0, Lf0/c;->j:Lf0/c$a;

    return-void
.end method


# virtual methods
.method public final a()Landroid/media/MediaCodec$CryptoInfo;
    .registers 2

    iget-object v0, p0, Lf0/c;->i:Landroid/media/MediaCodec$CryptoInfo;

    return-object v0
.end method

.method public final b(I)V
    .registers 5

    if-nez p1, :cond_3

    return-void

    :cond_3
    iget-object v0, p0, Lf0/c;->d:[I

    if-nez v0, :cond_10

    const/4 v0, 0x1

    new-array v0, v0, [I

    iput-object v0, p0, Lf0/c;->d:[I

    iget-object v1, p0, Lf0/c;->i:Landroid/media/MediaCodec$CryptoInfo;

    iput-object v0, v1, Landroid/media/MediaCodec$CryptoInfo;->numBytesOfClearData:[I

    :cond_10
    iget-object v0, p0, Lf0/c;->d:[I

    const/4 v1, 0x0

    aget v2, v0, v1

    add-int/2addr v2, p1

    aput v2, v0, v1

    return-void
.end method

.method public final c(I[I[I[B[BIII)V
    .registers 10

    iput p1, p0, Lf0/c;->f:I

    iput-object p2, p0, Lf0/c;->d:[I

    iput-object p3, p0, Lf0/c;->e:[I

    iput-object p4, p0, Lf0/c;->b:[B

    iput-object p5, p0, Lf0/c;->a:[B

    iput p6, p0, Lf0/c;->c:I

    iput p7, p0, Lf0/c;->g:I

    iput p8, p0, Lf0/c;->h:I

    iget-object v0, p0, Lf0/c;->i:Landroid/media/MediaCodec$CryptoInfo;

    iput p1, v0, Landroid/media/MediaCodec$CryptoInfo;->numSubSamples:I

    iput-object p2, v0, Landroid/media/MediaCodec$CryptoInfo;->numBytesOfClearData:[I

    iput-object p3, v0, Landroid/media/MediaCodec$CryptoInfo;->numBytesOfEncryptedData:[I

    iput-object p4, v0, Landroid/media/MediaCodec$CryptoInfo;->key:[B

    iput-object p5, v0, Landroid/media/MediaCodec$CryptoInfo;->iv:[B

    iput p6, v0, Landroid/media/MediaCodec$CryptoInfo;->mode:I

    sget p1, La0/T;->a:I

    const/16 p2, 0x18

    if-lt p1, p2, :cond_2c

    iget-object p1, p0, Lf0/c;->j:Lf0/c$a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p7, p8}, Lf0/c$a;->a(Lf0/c$a;II)V

    :cond_2c
    return-void
.end method
