.class public abstract Lf0/h;
.super Ljava/lang/Object;
.source "SimpleDecoder.java"

# interfaces
.implements Lf0/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<I:",
        "Lf0/f;",
        "O:",
        "Lf0/g;",
        "E:",
        "Lf0/e;",
        ">",
        "Ljava/lang/Object;",
        "Lf0/d<",
        "TI;TO;TE;>;"
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/Thread;

.field private final b:Ljava/lang/Object;

.field private final c:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "TI;>;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "TO;>;"
        }
    .end annotation
.end field

.field private final e:[Lf0/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TI;"
        }
    .end annotation
.end field

.field private final f:[Lf0/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TO;"
        }
    .end annotation
.end field

.field private g:I

.field private h:I

.field private i:Lf0/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TI;"
        }
    .end annotation
.end field

.field private j:Lf0/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TE;"
        }
    .end annotation
.end field

.field private k:Z

.field private l:Z

.field private m:J


# direct methods
.method protected constructor <init>([Lf0/f;[Lf0/g;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([TI;[TO;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v0, p0, Lf0/h;->m:J

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lf0/h;->d:Ljava/util/ArrayDeque;

    iput-object p1, p0, Lf0/h;->e:[Lf0/f;

    array-length p1, p1

    iput p1, p0, Lf0/h;->g:I

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_26
    iget v1, p0, Lf0/h;->g:I

    if-ge v0, v1, :cond_35

    iget-object v1, p0, Lf0/h;->e:[Lf0/f;

    invoke-virtual {p0}, Lf0/h;->g()Lf0/f;

    move-result-object v2

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_26

    :cond_35
    iput-object p2, p0, Lf0/h;->f:[Lf0/g;

    array-length p2, p2

    iput p2, p0, Lf0/h;->h:I

    :goto_3a
    iget p2, p0, Lf0/h;->h:I

    if-ge p1, p2, :cond_49

    iget-object p2, p0, Lf0/h;->f:[Lf0/g;

    invoke-virtual {p0}, Lf0/h;->h()Lf0/g;

    move-result-object v0

    aput-object v0, p2, p1

    add-int/lit8 p1, p1, 0x1

    goto :goto_3a

    :cond_49
    new-instance p1, Lf0/h$a;

    invoke-direct {p1, p0}, Lf0/h$a;-><init>(Lf0/h;)V

    iput-object p1, p0, Lf0/h;->a:Ljava/lang/Thread;

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method static f(Lf0/h;)V
    .registers 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_3
    :try_start_3
    invoke-direct {p0}, Lf0/h;->k()Z

    move-result v0
    :try_end_7
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_7} :catch_b

    if-eqz v0, :cond_a

    goto :goto_3

    :cond_a
    return-void

    :catch_b
    move-exception p0

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method private k()Z
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;
        }
    .end annotation

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    :goto_3
    :try_start_3
    iget-boolean v1, p0, Lf0/h;->l:Z

    if-nez v1, :cond_1d

    iget-object v1, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_14

    iget v1, p0, Lf0/h;->h:I

    if-lez v1, :cond_14

    goto :goto_1d

    :cond_14
    iget-object v1, p0, Lf0/h;->b:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->wait()V

    goto :goto_3

    :catchall_1a
    move-exception v1

    goto/16 :goto_a6

    :cond_1d
    :goto_1d
    iget-boolean v1, p0, Lf0/h;->l:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_24

    monitor-exit v0

    return v2

    :cond_24
    iget-object v1, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lf0/f;

    iget-object v3, p0, Lf0/h;->f:[Lf0/g;

    iget v4, p0, Lf0/h;->h:I

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    iput v4, p0, Lf0/h;->h:I

    aget-object v3, v3, v4

    iget-boolean v4, p0, Lf0/h;->k:Z

    iput-boolean v2, p0, Lf0/h;->k:Z

    monitor-exit v0
    :try_end_3b
    .catchall {:try_start_3 .. :try_end_3b} :catchall_1a

    const/4 v0, 0x4

    invoke-virtual {v1, v0}, Lf0/a;->i(I)Z

    move-result v6

    if-eqz v6, :cond_46

    invoke-virtual {v3, v0}, Lf0/a;->f(I)V

    goto :goto_7b

    :cond_46
    iget-wide v6, v1, Lf0/f;->f:J

    iput-wide v6, v3, Lf0/g;->b:J

    const/high16 v0, 0x8000000

    invoke-virtual {v1, v0}, Lf0/a;->i(I)Z

    move-result v6

    if-eqz v6, :cond_55

    invoke-virtual {v3, v0}, Lf0/a;->f(I)V

    :cond_55
    iget-wide v6, v1, Lf0/f;->f:J

    invoke-virtual {p0, v6, v7}, Lf0/h;->m(J)Z

    move-result v0

    if-nez v0, :cond_5f

    iput-boolean v5, v3, Lf0/g;->c:Z

    :cond_5f
    :try_start_5f
    invoke-virtual {p0, v1, v3, v4}, Lf0/h;->j(Lf0/f;Lf0/g;Z)Lf0/e;

    move-result-object v0
    :try_end_63
    .catch Ljava/lang/RuntimeException; {:try_start_5f .. :try_end_63} :catch_6a
    .catch Ljava/lang/OutOfMemoryError; {:try_start_5f .. :try_end_63} :catch_64

    goto :goto_6f

    :catch_64
    move-exception v0

    invoke-virtual {p0, v0}, Lf0/h;->i(Ljava/lang/Throwable;)Lf0/e;

    move-result-object v0

    goto :goto_6f

    :catch_6a
    move-exception v0

    invoke-virtual {p0, v0}, Lf0/h;->i(Ljava/lang/Throwable;)Lf0/e;

    move-result-object v0

    :goto_6f
    if-eqz v0, :cond_7b

    iget-object v4, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v4

    :try_start_74
    iput-object v0, p0, Lf0/h;->j:Lf0/e;

    monitor-exit v4

    return v2

    :catchall_78
    move-exception v0

    monitor-exit v4
    :try_end_7a
    .catchall {:try_start_74 .. :try_end_7a} :catchall_78

    throw v0

    :cond_7b
    :goto_7b
    iget-object v2, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v2

    :try_start_7e
    iget-boolean v0, p0, Lf0/h;->k:Z

    if-eqz v0, :cond_88

    invoke-virtual {v3}, Lf0/g;->q()V

    goto :goto_95

    :catchall_86
    move-exception v0

    goto :goto_a4

    :cond_88
    iget-boolean v0, v3, Lf0/g;->c:Z

    if-eqz v0, :cond_90

    invoke-virtual {v3}, Lf0/g;->q()V

    goto :goto_95

    :cond_90
    iget-object v0, p0, Lf0/h;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v0, v3}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    :goto_95
    invoke-virtual {v1}, Lf0/f;->h()V

    iget v0, p0, Lf0/h;->g:I

    add-int/lit8 v3, v0, 0x1

    iput v3, p0, Lf0/h;->g:I

    iget-object v3, p0, Lf0/h;->e:[Lf0/f;

    aput-object v1, v3, v0

    monitor-exit v2

    return v5

    :goto_a4
    monitor-exit v2
    :try_end_a5
    .catchall {:try_start_7e .. :try_end_a5} :catchall_86

    throw v0

    :goto_a6
    :try_start_a6
    monitor-exit v0
    :try_end_a7
    .catchall {:try_start_a6 .. :try_end_a7} :catchall_1a

    throw v1
.end method


# virtual methods
.method public final bridge synthetic b()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lf0/e;
        }
    .end annotation

    invoke-virtual {p0}, Lf0/h;->l()Lf0/g;

    move-result-object v0

    return-object v0
.end method

.method public final c(J)V
    .registers 6

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget v1, p0, Lf0/h;->g:I

    iget-object v2, p0, Lf0/h;->e:[Lf0/f;

    array-length v2, v2

    if-eq v1, v2, :cond_13

    iget-boolean v1, p0, Lf0/h;->k:Z

    if-eqz v1, :cond_f

    goto :goto_13

    :cond_f
    const/4 v1, 0x0

    goto :goto_14

    :catchall_11
    move-exception p1

    goto :goto_1b

    :cond_13
    :goto_13
    const/4 v1, 0x1

    :goto_14
    invoke-static {v1}, Lcom/facebook/soloader/m;->e(Z)V

    iput-wide p1, p0, Lf0/h;->m:J

    monitor-exit v0

    return-void

    :goto_1b
    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_11

    throw p1
.end method

.method public final bridge synthetic d(LO0/o;)V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lf0/e;
        }
    .end annotation

    invoke-virtual {p0, p1}, Lf0/h;->n(Lf0/f;)V

    return-void
.end method

.method public final e()Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lf0/e;
        }
    .end annotation

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Lf0/h;->j:Lf0/e;

    if-nez v1, :cond_25

    iget-object v1, p0, Lf0/h;->i:Lf0/f;

    const/4 v2, 0x1

    if-nez v1, :cond_e

    const/4 v1, 0x1

    goto :goto_f

    :cond_e
    const/4 v1, 0x0

    :goto_f
    invoke-static {v1}, Lcom/facebook/soloader/m;->e(Z)V

    iget v1, p0, Lf0/h;->g:I

    if-nez v1, :cond_18

    const/4 v1, 0x0

    goto :goto_1f

    :cond_18
    iget-object v3, p0, Lf0/h;->e:[Lf0/f;

    sub-int/2addr v1, v2

    iput v1, p0, Lf0/h;->g:I

    aget-object v1, v3, v1

    :goto_1f
    iput-object v1, p0, Lf0/h;->i:Lf0/f;

    monitor-exit v0

    return-object v1

    :catchall_23
    move-exception v1

    goto :goto_26

    :cond_25
    throw v1

    :goto_26
    monitor-exit v0
    :try_end_27
    .catchall {:try_start_3 .. :try_end_27} :catchall_23

    throw v1
.end method

.method public final flush()V
    .registers 5

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x1

    :try_start_4
    iput-boolean v1, p0, Lf0/h;->k:Z

    iget-object v1, p0, Lf0/h;->i:Lf0/f;

    if-eqz v1, :cond_1d

    invoke-virtual {v1}, Lf0/f;->h()V

    iget v2, p0, Lf0/h;->g:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, Lf0/h;->g:I

    iget-object v3, p0, Lf0/h;->e:[Lf0/f;

    aput-object v1, v3, v2

    const/4 v1, 0x0

    iput-object v1, p0, Lf0/h;->i:Lf0/f;

    goto :goto_1d

    :catchall_1b
    move-exception v1

    goto :goto_51

    :cond_1d
    :goto_1d
    iget-object v1, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3b

    iget-object v1, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lf0/f;

    invoke-virtual {v1}, Lf0/f;->h()V

    iget v2, p0, Lf0/h;->g:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, Lf0/h;->g:I

    iget-object v3, p0, Lf0/h;->e:[Lf0/f;

    aput-object v1, v3, v2

    goto :goto_1d

    :cond_3b
    :goto_3b
    iget-object v1, p0, Lf0/h;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4f

    iget-object v1, p0, Lf0/h;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lf0/g;

    invoke-virtual {v1}, Lf0/g;->q()V

    goto :goto_3b

    :cond_4f
    monitor-exit v0

    return-void

    :goto_51
    monitor-exit v0
    :try_end_52
    .catchall {:try_start_4 .. :try_end_52} :catchall_1b

    throw v1
.end method

.method protected abstract g()Lf0/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TI;"
        }
    .end annotation
.end method

.method protected abstract h()Lf0/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TO;"
        }
    .end annotation
.end method

.method protected abstract i(Ljava/lang/Throwable;)Lf0/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Throwable;",
            ")TE;"
        }
    .end annotation
.end method

.method protected abstract j(Lf0/f;Lf0/g;Z)Lf0/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TI;TO;Z)TE;"
        }
    .end annotation
.end method

.method public final l()Lf0/g;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TO;^TE;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lf0/e;
        }
    .end annotation

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Lf0/h;->j:Lf0/e;

    if-nez v1, :cond_1e

    iget-object v1, p0, Lf0/h;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_14

    monitor-exit v0

    const/4 v0, 0x0

    return-object v0

    :catchall_12
    move-exception v1

    goto :goto_1f

    :cond_14
    iget-object v1, p0, Lf0/h;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lf0/g;

    monitor-exit v0

    return-object v1

    :cond_1e
    throw v1

    :goto_1f
    monitor-exit v0
    :try_end_20
    .catchall {:try_start_3 .. :try_end_20} :catchall_12

    throw v1
.end method

.method protected final m(J)Z
    .registers 9

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-wide v1, p0, Lf0/h;->m:J

    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v5, v1, v3

    if-eqz v5, :cond_15

    cmp-long v3, p1, v1

    if-ltz v3, :cond_13

    goto :goto_15

    :cond_13
    const/4 p1, 0x0

    goto :goto_16

    :cond_15
    :goto_15
    const/4 p1, 0x1

    :goto_16
    monitor-exit v0

    return p1

    :catchall_18
    move-exception p1

    monitor-exit v0
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_18

    throw p1
.end method

.method public final n(Lf0/f;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TI;)V^TE;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lf0/e;
        }
    .end annotation

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Lf0/h;->j:Lf0/e;

    if-nez v1, :cond_2e

    iget-object v1, p0, Lf0/h;->i:Lf0/f;

    if-ne p1, v1, :cond_d

    const/4 v1, 0x1

    goto :goto_e

    :cond_d
    const/4 v1, 0x0

    :goto_e
    invoke-static {v1}, Lcom/facebook/soloader/m;->a(Z)V

    iget-object v1, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1, p1}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    iget-object p1, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    invoke-virtual {p1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_27

    iget p1, p0, Lf0/h;->h:I

    if-lez p1, :cond_27

    iget-object p1, p0, Lf0/h;->b:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notify()V

    :cond_27
    const/4 p1, 0x0

    iput-object p1, p0, Lf0/h;->i:Lf0/f;

    monitor-exit v0

    return-void

    :catchall_2c
    move-exception p1

    goto :goto_2f

    :cond_2e
    throw v1

    :goto_2f
    monitor-exit v0
    :try_end_30
    .catchall {:try_start_3 .. :try_end_30} :catchall_2c

    throw p1
.end method

.method protected final o(Lf0/g;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TO;)V"
        }
    .end annotation

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p1}, Lf0/g;->h()V

    iget v1, p0, Lf0/h;->h:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lf0/h;->h:I

    iget-object v2, p0, Lf0/h;->f:[Lf0/g;

    aput-object p1, v2, v1

    iget-object p1, p0, Lf0/h;->c:Ljava/util/ArrayDeque;

    invoke-virtual {p1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_21

    iget p1, p0, Lf0/h;->h:I

    if-lez p1, :cond_21

    iget-object p1, p0, Lf0/h;->b:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notify()V

    :cond_21
    monitor-exit v0

    return-void

    :catchall_23
    move-exception p1

    monitor-exit v0
    :try_end_25
    .catchall {:try_start_3 .. :try_end_25} :catchall_23

    throw p1
.end method

.method protected final p()V
    .registers 6

    iget v0, p0, Lf0/h;->g:I

    iget-object v1, p0, Lf0/h;->e:[Lf0/f;

    array-length v2, v1

    const/4 v3, 0x0

    if-ne v0, v2, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    array-length v0, v1

    :goto_f
    if-ge v3, v0, :cond_1b

    aget-object v2, v1, v3

    const/16 v4, 0x400

    invoke-virtual {v2, v4}, Lf0/f;->s(I)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_f

    :cond_1b
    return-void
.end method

.method public final release()V
    .registers 3

    iget-object v0, p0, Lf0/h;->b:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x1

    :try_start_4
    iput-boolean v1, p0, Lf0/h;->l:Z

    iget-object v1, p0, Lf0/h;->b:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->notify()V

    monitor-exit v0
    :try_end_c
    .catchall {:try_start_4 .. :try_end_c} :catchall_1a

    :try_start_c
    iget-object v0, p0, Lf0/h;->a:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->join()V
    :try_end_11
    .catch Ljava/lang/InterruptedException; {:try_start_c .. :try_end_11} :catch_12

    goto :goto_19

    :catch_12
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    :goto_19
    return-void

    :catchall_1a
    move-exception v1

    :try_start_1b
    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_1b .. :try_end_1c} :catchall_1a

    throw v1
.end method
