.class final Lf0/c$a;
.super Ljava/lang/Object;
.source "CryptoInfo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf0/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Landroid/media/MediaCodec$CryptoInfo;

.field private final b:Landroid/media/MediaCodec$CryptoInfo$Pattern;


# direct methods
.method constructor <init>(Landroid/media/MediaCodec$CryptoInfo;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lf0/c$a;->a:Landroid/media/MediaCodec$CryptoInfo;

    invoke-static {}, Le3/k;->d()Landroid/media/MediaCodec$CryptoInfo$Pattern;

    move-result-object p1

    iput-object p1, p0, Lf0/c$a;->b:Landroid/media/MediaCodec$CryptoInfo$Pattern;

    return-void
.end method

.method static a(Lf0/c$a;II)V
    .registers 4

    iget-object v0, p0, Lf0/c$a;->b:Landroid/media/MediaCodec$CryptoInfo$Pattern;

    invoke-static {v0, p1, p2}, Landroidx/appcompat/widget/x;->e(Landroid/media/MediaCodec$CryptoInfo$Pattern;II)V

    iget-object p0, p0, Lf0/c$a;->a:Landroid/media/MediaCodec$CryptoInfo;

    invoke-static {p0, v0}, Landroidx/appcompat/widget/y;->d(Landroid/media/MediaCodec$CryptoInfo;Landroid/media/MediaCodec$CryptoInfo$Pattern;)V

    return-void
.end method
