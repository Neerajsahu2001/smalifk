.class public final LD2/n;
.super Ljava/lang/Object;
.source "Suppliers.java"


# static fields
.field public static final a:LD2/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LD2/l<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LD2/n$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LD2/n;->a:LD2/l;

    return-void
.end method

.method public static a()LD2/l;
    .registers 1

    new-instance v0, LD2/m;

    invoke-direct {v0}, LD2/m;-><init>()V

    return-object v0
.end method
