.class public final Ld2/c$a;
.super Ljava/lang/Object;
.source "UrlLoader.java"

# interfaces
.implements Lc2/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld2/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lc2/i<",
        "Ljava/net/URL;",
        "Ljava/io/InputStream;",
        ">;"
    }
.end annotation


# virtual methods
.method public final build(Lcom/bumptech/glide/load/model/i;)Lcom/bumptech/glide/load/model/f;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/bumptech/glide/load/model/i;",
            ")",
            "Lcom/bumptech/glide/load/model/f<",
            "Ljava/net/URL;",
            "Ljava/io/InputStream;",
            ">;"
        }
    .end annotation

    new-instance v0, Ld2/c;

    const-class v1, Lc2/b;

    const-class v2, Ljava/io/InputStream;

    invoke-virtual {p1, v1, v2}, Lcom/bumptech/glide/load/model/i;->c(Ljava/lang/Class;Ljava/lang/Class;)Lcom/bumptech/glide/load/model/f;

    move-result-object p1

    invoke-direct {v0, p1}, Ld2/c;-><init>(Lcom/bumptech/glide/load/model/f;)V

    return-object v0
.end method
