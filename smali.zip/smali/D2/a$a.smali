.class public final Ld2/a$a;
.super Ljava/lang/Object;
.source "HttpGlideUrlLoader.java"

# interfaces
.implements Lc2/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld2/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lc2/i<",
        "Lc2/b;",
        "Ljava/io/InputStream;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lc2/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lc2/h<",
            "Lc2/b;",
            "Lc2/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lc2/h;

    invoke-direct {v0}, Lc2/h;-><init>()V

    iput-object v0, p0, Ld2/a$a;->a:Lc2/h;

    return-void
.end method


# virtual methods
.method public final build(Lcom/bumptech/glide/load/model/i;)Lcom/bumptech/glide/load/model/f;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/bumptech/glide/load/model/i;",
            ")",
            "Lcom/bumptech/glide/load/model/f<",
            "Lc2/b;",
            "Ljava/io/InputStream;",
            ">;"
        }
    .end annotation

    new-instance p1, Ld2/a;

    iget-object v0, p0, Ld2/a$a;->a:Lc2/h;

    invoke-direct {p1, v0}, Ld2/a;-><init>(Lc2/h;)V

    return-object p1
.end method
