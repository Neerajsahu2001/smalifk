.class public final Ld2/c;
.super Ljava/lang/Object;
.source "UrlLoader.java"

# interfaces
.implements Lcom/bumptech/glide/load/model/f;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld2/c$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/bumptech/glide/load/model/f<",
        "Ljava/net/URL;",
        "Ljava/io/InputStream;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lcom/bumptech/glide/load/model/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/bumptech/glide/load/model/f<",
            "Lc2/b;",
            "Ljava/io/InputStream;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/bumptech/glide/load/model/f;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/bumptech/glide/load/model/f<",
            "Lc2/b;",
            "Ljava/io/InputStream;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld2/c;->a:Lcom/bumptech/glide/load/model/f;

    return-void
.end method


# virtual methods
.method public final buildLoadData(Ljava/lang/Object;IILW1/i;)Lcom/bumptech/glide/load/model/f$a;
    .registers 6

    check-cast p1, Ljava/net/URL;

    new-instance v0, Lc2/b;

    invoke-direct {v0, p1}, Lc2/b;-><init>(Ljava/net/URL;)V

    iget-object p1, p0, Ld2/c;->a:Lcom/bumptech/glide/load/model/f;

    invoke-interface {p1, v0, p2, p3, p4}, Lcom/bumptech/glide/load/model/f;->buildLoadData(Ljava/lang/Object;IILW1/i;)Lcom/bumptech/glide/load/model/f$a;

    move-result-object p1

    return-object p1
.end method

.method public final bridge synthetic handles(Ljava/lang/Object;)Z
    .registers 2

    check-cast p1, Ljava/net/URL;

    const/4 p1, 0x1

    return p1
.end method
