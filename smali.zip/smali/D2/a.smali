.class public final Ld2/a;
.super Ljava/lang/Object;
.source "HttpGlideUrlLoader.java"

# interfaces
.implements Lcom/bumptech/glide/load/model/f;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld2/a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/bumptech/glide/load/model/f<",
        "Lc2/b;",
        "Ljava/io/InputStream;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:LW1/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LW1/h<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lc2/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lc2/h<",
            "Lc2/b;",
            "Lc2/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v0, 0x9c4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const-string v1, "com.bumptech.glide.load.model.stream.HttpGlideUrlLoader.Timeout"

    invoke-static {v0, v1}, LW1/h;->d(Ljava/lang/Object;Ljava/lang/String;)LW1/h;

    move-result-object v0

    sput-object v0, Ld2/a;->b:LW1/h;

    return-void
.end method

.method public constructor <init>(Lc2/h;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lc2/h<",
            "Lc2/b;",
            "Lc2/b;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld2/a;->a:Lc2/h;

    return-void
.end method


# virtual methods
.method public final buildLoadData(Ljava/lang/Object;IILW1/i;)Lcom/bumptech/glide/load/model/f$a;
    .registers 5

    check-cast p1, Lc2/b;

    iget-object p2, p0, Ld2/a;->a:Lc2/h;

    if-eqz p2, :cond_13

    invoke-virtual {p2, p1}, Lc2/h;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lc2/b;

    if-nez p3, :cond_12

    invoke-virtual {p2, p1, p1}, Lc2/h;->b(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_13

    :cond_12
    move-object p1, p3

    :cond_13
    :goto_13
    sget-object p2, Ld2/a;->b:LW1/h;

    invoke-virtual {p4, p2}, LW1/i;->a(LW1/h;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    new-instance p3, Lcom/bumptech/glide/load/model/f$a;

    new-instance p4, LX1/j;

    invoke-direct {p4, p1, p2}, LX1/j;-><init>(Lc2/b;I)V

    invoke-direct {p3, p1, p4}, Lcom/bumptech/glide/load/model/f$a;-><init>(LW1/f;LX1/d;)V

    return-object p3
.end method

.method public final bridge synthetic handles(Ljava/lang/Object;)Z
    .registers 2

    check-cast p1, Lc2/b;

    const/4 p1, 0x1

    return p1
.end method
