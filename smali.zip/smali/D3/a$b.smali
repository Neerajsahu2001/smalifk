.class final LD3/a$b;
.super LD3/a$a;
.source "SystraceMessage.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# virtual methods
.method public final a(ILjava/lang/String;)LD3/a$a;
    .registers 3

    const/4 p0, 0x0

    throw p0
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/String;)LD3/a$a;
    .registers 3

    const/4 p0, 0x0

    throw p0
.end method

.method public final c()V
    .registers 1

    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void
.end method
