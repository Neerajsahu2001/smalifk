.class public final Ld3/c;
.super Ld3/a;
.source "ForwardingControllerListener2.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<I:",
        "Ljava/lang/Object;",
        ">",
        "Ld3/a<",
        "TI;>;"
    }
.end annotation


# instance fields
.field private final a:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    return-void
.end method

.method private declared-synchronized n(Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 4

    monitor-enter p0

    :try_start_1
    const-string v0, "FwdControllerListener2"

    invoke-static {v0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_8

    monitor-exit p0

    return-void

    :catchall_8
    move-exception p1

    monitor-exit p0

    throw p1
.end method


# virtual methods
.method public final c(Ljava/lang/String;Ljava/lang/Object;Ld3/b$a;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "TI;",
            "Ld3/b$a;",
            ")V"
        }
    .end annotation

    iget-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_1e

    :try_start_9
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld3/b;

    if-eqz v3, :cond_1b

    invoke-interface {v3, p1, p2, p3}, Ld3/b;->c(Ljava/lang/String;Ljava/lang/Object;Ld3/b$a;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_14} :catch_15

    goto :goto_1b

    :catch_15
    move-exception v3

    const-string v4, "ForwardingControllerListener2 exception in onFinalImageSet"

    invoke-direct {p0, v4, v3}, Ld3/c;->n(Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_1b
    :goto_1b
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_1e
    return-void
.end method

.method public final e(Ljava/lang/String;Ljava/lang/Throwable;Ld3/b$a;)V
    .registers 9

    iget-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_1e

    :try_start_9
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld3/b;

    if-eqz v3, :cond_1b

    invoke-interface {v3, p1, p2, p3}, Ld3/b;->e(Ljava/lang/String;Ljava/lang/Throwable;Ld3/b$a;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_14} :catch_15

    goto :goto_1b

    :catch_15
    move-exception v3

    const-string v4, "ForwardingControllerListener2 exception in onFailure"

    invoke-direct {p0, v4, v3}, Ld3/c;->n(Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_1b
    :goto_1b
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_1e
    return-void
.end method

.method public final f(Ljava/lang/String;Ljava/lang/Object;Ld3/b$a;)V
    .registers 9

    iget-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_1e

    :try_start_9
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld3/b;

    if-eqz v3, :cond_1b

    invoke-interface {v3, p1, p2, p3}, Ld3/b;->f(Ljava/lang/String;Ljava/lang/Object;Ld3/b$a;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_14} :catch_15

    goto :goto_1b

    :catch_15
    move-exception v3

    const-string v4, "ForwardingControllerListener2 exception in onSubmit"

    invoke-direct {p0, v4, v3}, Ld3/c;->n(Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_1b
    :goto_1b
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_1e
    return-void
.end method

.method public final g(Ljava/lang/String;Ld3/b$a;)V
    .registers 8

    iget-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_1e

    :try_start_9
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld3/b;

    if-eqz v3, :cond_1b

    invoke-interface {v3, p1, p2}, Ld3/b;->g(Ljava/lang/String;Ld3/b$a;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_14} :catch_15

    goto :goto_1b

    :catch_15
    move-exception v3

    const-string v4, "ForwardingControllerListener2 exception in onRelease"

    invoke-direct {p0, v4, v3}, Ld3/c;->n(Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_1b
    :goto_1b
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_1e
    return-void
.end method

.method public final declared-synchronized m(Ld3/b;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld3/b<",
            "TI;>;)V"
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_8

    monitor-exit p0

    return-void

    :catchall_8
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized o(LV2/a;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p1

    const/4 v0, -0x1

    if-eq p1, v0, :cond_12

    iget-object v0, p0, Ld3/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    :try_end_f
    .catchall {:try_start_1 .. :try_end_f} :catchall_10

    goto :goto_12

    :catchall_10
    move-exception p1

    goto :goto_14

    :cond_12
    :goto_12
    monitor-exit p0

    return-void

    :goto_14
    monitor-exit p0

    throw p1
.end method
