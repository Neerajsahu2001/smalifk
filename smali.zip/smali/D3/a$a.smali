.class public abstract LD3/a$a;
.super Ljava/lang/Object;
.source "SystraceMessage.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# virtual methods
.method public abstract a(ILjava/lang/String;)LD3/a$a;
.end method

.method public abstract b(Ljava/lang/Object;Ljava/lang/String;)LD3/a$a;
.end method

.method public abstract c()V
.end method
