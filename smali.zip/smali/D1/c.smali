.class public final Ld1/c;
.super Ljava/lang/Object;


# static fields
.field public static final item_touch_helper_previous_elevation:I = 0x7f0b03b1
