.class public final Ld1/b;
.super Ljava/lang/Object;


# static fields
.field public static final fastscroll_default_thickness:I = 0x7f0701a4

.field public static final fastscroll_margin:I = 0x7f0701a5

.field public static final fastscroll_minimum_range:I = 0x7f0701a6

.field public static final item_touch_helper_max_drag_scroll_per_frame:I = 0x7f0701ec

.field public static final item_touch_helper_swipe_escape_max_velocity:I = 0x7f0701ed

.field public static final item_touch_helper_swipe_escape_velocity:I = 0x7f0701ee
