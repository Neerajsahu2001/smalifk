.class public final Ld1/a;
.super Ljava/lang/Object;


# static fields
.field public static final fastScrollEnabled:I = 0x7f04015d

.field public static final fastScrollHorizontalThumbDrawable:I = 0x7f04015e

.field public static final fastScrollHorizontalTrackDrawable:I = 0x7f04015f

.field public static final fastScrollVerticalThumbDrawable:I = 0x7f040160

.field public static final fastScrollVerticalTrackDrawable:I = 0x7f040161

.field public static final layoutManager:I = 0x7f0401d2

.field public static final recyclerViewStyle:I = 0x7f0402b5

.field public static final reverseLayout:I = 0x7f0402bf

.field public static final spanCount:I = 0x7f040331

.field public static final stackFromEnd:I = 0x7f040339
