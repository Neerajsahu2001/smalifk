.class public final LB2/f;
.super LB2/b;
.source "UiThreadImmediateExecutorService.java"


# static fields
.field private static b:LB2/f;


# direct methods
.method public static b()LB2/f;
    .registers 3

    sget-object v0, LB2/f;->b:LB2/f;

    if-nez v0, :cond_14

    new-instance v0, LB2/f;

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-direct {v0, v1}, LB2/b;-><init>(Landroid/os/Handler;)V

    sput-object v0, LB2/f;->b:LB2/f;

    :cond_14
    sget-object v0, LB2/f;->b:LB2/f;

    return-object v0
.end method


# virtual methods
.method public final execute(Ljava/lang/Runnable;)V
    .registers 3

    invoke-virtual {p0}, LB2/b;->a()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    goto :goto_d

    :cond_a
    invoke-super {p0, p1}, LB2/b;->execute(Ljava/lang/Runnable;)V

    :goto_d
    return-void
.end method
