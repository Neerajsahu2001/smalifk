.class public interface abstract LB2/d;
.super Ljava/lang/Object;
.source "SerialExecutorService.java"

# interfaces
.implements Ljava/util/concurrent/ExecutorService;
