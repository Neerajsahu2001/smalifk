.class public final LD/e;
.super LD/c;
.source "GoalRow.java"


# virtual methods
.method public final g(LD/i;)V
    .registers 6

    iget v0, p1, LD/i;->c:I

    const/4 v1, 0x1

    const/high16 v2, 0x3f800000    # 1.0f

    if-ne v0, v1, :cond_8

    goto :goto_22

    :cond_8
    const/4 v3, 0x2

    if-ne v0, v3, :cond_e

    const/high16 v2, 0x447a0000    # 1000.0f

    goto :goto_22

    :cond_e
    const/4 v3, 0x3

    if-ne v0, v3, :cond_15

    const v2, 0x49742400    # 1000000.0f

    goto :goto_22

    :cond_15
    const/4 v3, 0x4

    if-ne v0, v3, :cond_1c

    const v2, 0x4e6e6b28    # 1.0E9f

    goto :goto_22

    :cond_1c
    const/4 v3, 0x5

    if-ne v0, v3, :cond_22

    const v2, 0x5368d4a5    # 1.0E12f

    :cond_22
    :goto_22
    iget-object v0, p0, LD/c;->c:LD/b;

    invoke-virtual {v0, p1, v2}, LD/b;->k(LD/i;F)V

    iget v0, p1, LD/i;->i:I

    sub-int/2addr v0, v1

    iput v0, p1, LD/i;->i:I

    return-void
.end method
