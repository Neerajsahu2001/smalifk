.class public final LD/g;
.super Ljava/lang/Object;
.source "Metrics.java"
