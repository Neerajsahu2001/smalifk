.class public LD/c;
.super Ljava/lang/Object;
.source "ArrayRow.java"


# instance fields
.field a:LD/i;

.field b:F

.field public final c:LD/b;

.field d:Z


# direct methods
.method public constructor <init>(LD/d;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, LD/c;->a:LD/i;

    const/4 v0, 0x0

    iput v0, p0, LD/c;->b:F

    const/4 v0, 0x0

    iput-boolean v0, p0, LD/c;->d:Z

    new-instance v0, LD/b;

    invoke-direct {v0, p0, p1}, LD/b;-><init>(LD/c;LD/d;)V

    iput-object v0, p0, LD/c;->c:LD/b;

    return-void
.end method


# virtual methods
.method public final a(LD/f;I)V
    .registers 6

    invoke-virtual {p1, p2}, LD/f;->k(I)LD/i;

    move-result-object v0

    iget-object v1, p0, LD/c;->c:LD/b;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v1, v0, v2}, LD/b;->k(LD/i;F)V

    invoke-virtual {p1, p2}, LD/f;->k(I)LD/i;

    move-result-object p1

    const/high16 p2, -0x40800000    # -1.0f

    invoke-virtual {v1, p1, p2}, LD/b;->k(LD/i;F)V

    return-void
.end method

.method public final b(FFFLD/i;LD/i;LD/i;LD/i;)V
    .registers 13

    const/4 v0, 0x0

    iput v0, p0, LD/c;->b:F

    const/high16 v1, -0x40800000    # -1.0f

    const/high16 v2, 0x3f800000    # 1.0f

    iget-object v3, p0, LD/c;->c:LD/b;

    cmpl-float v4, p2, v0

    if-eqz v4, :cond_39

    cmpl-float v4, p1, p3

    if-nez v4, :cond_12

    goto :goto_39

    :cond_12
    cmpl-float v4, p1, v0

    if-nez v4, :cond_1d

    invoke-virtual {v3, p4, v2}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p5, v1}, LD/b;->k(LD/i;F)V

    goto :goto_45

    :cond_1d
    cmpl-float v0, p3, v0

    if-nez v0, :cond_28

    invoke-virtual {v3, p6, v2}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p7, v1}, LD/b;->k(LD/i;F)V

    goto :goto_45

    :cond_28
    div-float/2addr p1, p2

    div-float/2addr p3, p2

    div-float/2addr p1, p3

    invoke-virtual {v3, p4, v2}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p5, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p7, p1}, LD/b;->k(LD/i;F)V

    neg-float p1, p1

    invoke-virtual {v3, p6, p1}, LD/b;->k(LD/i;F)V

    goto :goto_45

    :cond_39
    :goto_39
    invoke-virtual {v3, p4, v2}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p5, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p7, v2}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p6, v1}, LD/b;->k(LD/i;F)V

    :goto_45
    return-void
.end method

.method public final c(LD/i;LD/i;LD/i;I)V
    .registers 9

    const/high16 v0, 0x3f800000    # 1.0f

    const/high16 v1, -0x40800000    # -1.0f

    iget-object v2, p0, LD/c;->c:LD/b;

    if-eqz p4, :cond_1f

    if-gez p4, :cond_e

    mul-int/lit8 p4, p4, -0x1

    const/4 v3, 0x1

    goto :goto_f

    :cond_e
    const/4 v3, 0x0

    :goto_f
    int-to-float p4, p4

    iput p4, p0, LD/c;->b:F

    if-nez v3, :cond_15

    goto :goto_1f

    :cond_15
    invoke-virtual {v2, p1, v0}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p2, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p3, v1}, LD/b;->k(LD/i;F)V

    goto :goto_28

    :cond_1f
    :goto_1f
    invoke-virtual {v2, p1, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p2, v0}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p3, v0}, LD/b;->k(LD/i;F)V

    :goto_28
    return-void
.end method

.method public final d(LD/i;LD/i;LD/i;I)V
    .registers 9

    const/high16 v0, 0x3f800000    # 1.0f

    const/high16 v1, -0x40800000    # -1.0f

    iget-object v2, p0, LD/c;->c:LD/b;

    if-eqz p4, :cond_1f

    if-gez p4, :cond_e

    mul-int/lit8 p4, p4, -0x1

    const/4 v3, 0x1

    goto :goto_f

    :cond_e
    const/4 v3, 0x0

    :goto_f
    int-to-float p4, p4

    iput p4, p0, LD/c;->b:F

    if-nez v3, :cond_15

    goto :goto_1f

    :cond_15
    invoke-virtual {v2, p1, v0}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p2, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p3, v0}, LD/b;->k(LD/i;F)V

    goto :goto_28

    :cond_1f
    :goto_1f
    invoke-virtual {v2, p1, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p2, v0}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p3, v1}, LD/b;->k(LD/i;F)V

    :goto_28
    return-void
.end method

.method public final e(LD/i;LD/i;LD/i;LD/i;F)V
    .registers 8

    iget-object v0, p0, LD/c;->c:LD/b;

    const/high16 v1, 0x3f000000    # 0.5f

    invoke-virtual {v0, p3, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v0, p4, v1}, LD/b;->k(LD/i;F)V

    const/high16 p3, -0x41000000    # -0.5f

    invoke-virtual {v0, p1, p3}, LD/b;->k(LD/i;F)V

    invoke-virtual {v0, p2, p3}, LD/b;->k(LD/i;F)V

    neg-float p1, p5

    iput p1, p0, LD/c;->b:F

    return-void
.end method

.method final f(LD/i;)V
    .registers 5

    iget-object v0, p0, LD/c;->a:LD/i;

    const/high16 v1, -0x40800000    # -1.0f

    iget-object v2, p0, LD/c;->c:LD/b;

    if-eqz v0, :cond_e

    invoke-virtual {v2, v0, v1}, LD/b;->k(LD/i;F)V

    const/4 v0, 0x0

    iput-object v0, p0, LD/c;->a:LD/i;

    :cond_e
    const/4 v0, 0x1

    invoke-virtual {v2, p1, v0}, LD/b;->l(LD/i;Z)F

    move-result v0

    mul-float v0, v0, v1

    iput-object p1, p0, LD/c;->a:LD/i;

    const/high16 p1, 0x3f800000    # 1.0f

    cmpl-float p1, v0, p1

    if-nez p1, :cond_1e

    return-void

    :cond_1e
    iget p1, p0, LD/c;->b:F

    div-float/2addr p1, v0

    iput p1, p0, LD/c;->b:F

    invoke-virtual {v2, v0}, LD/b;->e(F)V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 11

    iget-object v0, p0, LD/c;->a:LD/i;

    if-nez v0, :cond_7

    const-string v0, "0"

    goto :goto_17

    :cond_7
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LD/c;->a:LD/i;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_17
    const-string v1, " = "

    invoke-static {v0, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget v1, p0, LD/c;->b:F

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    cmpl-float v1, v1, v4

    if-eqz v1, :cond_35

    invoke-static {v0}, LD/a;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, LD/c;->b:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    goto :goto_36

    :cond_35
    const/4 v1, 0x0

    :goto_36
    iget-object v5, p0, LD/c;->c:LD/b;

    iget v6, v5, LD/b;->a:I

    :goto_3a
    if-ge v3, v6, :cond_92

    invoke-virtual {v5, v3}, LD/b;->h(I)LD/i;

    move-result-object v7

    if-nez v7, :cond_43

    goto :goto_8f

    :cond_43
    invoke-virtual {v5, v3}, LD/b;->i(I)F

    move-result v7

    cmpl-float v8, v7, v4

    if-nez v8, :cond_4c

    goto :goto_8f

    :cond_4c
    const/high16 v9, -0x40800000    # -1.0f

    if-nez v1, :cond_5d

    cmpg-float v1, v7, v4

    if-gez v1, :cond_6d

    const-string v1, "- "

    invoke-static {v0, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_5a
    mul-float v7, v7, v9

    goto :goto_6d

    :cond_5d
    if-lez v8, :cond_66

    const-string v1, " + "

    invoke-static {v0, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_6d

    :cond_66
    const-string v1, " - "

    invoke-static {v0, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_5a

    :cond_6d
    :goto_6d
    const/high16 v1, 0x3f800000    # 1.0f

    cmpl-float v1, v7, v1

    if-nez v1, :cond_7a

    const-string v1, "null"

    invoke-static {v0, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_8e

    :cond_7a
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v0, " null"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_8e
    const/4 v1, 0x1

    :goto_8f
    add-int/lit8 v3, v3, 0x1

    goto :goto_3a

    :cond_92
    if-nez v1, :cond_9a

    const-string v1, "0.0"

    invoke-static {v0, v1}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_9a
    return-object v0
.end method
