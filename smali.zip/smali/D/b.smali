.class public final LD/b;
.super Ljava/lang/Object;
.source "ArrayLinkedVariables.java"


# instance fields
.field a:I

.field private final b:LD/c;

.field private final c:LD/d;

.field private d:I

.field private e:[I

.field private f:[I

.field private g:[F

.field private h:I

.field private i:I

.field private j:Z


# direct methods
.method constructor <init>(LD/c;LD/d;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, LD/b;->a:I

    const/16 v1, 0x8

    iput v1, p0, LD/b;->d:I

    new-array v2, v1, [I

    iput-object v2, p0, LD/b;->e:[I

    new-array v2, v1, [I

    iput-object v2, p0, LD/b;->f:[I

    new-array v1, v1, [F

    iput-object v1, p0, LD/b;->g:[F

    const/4 v1, -0x1

    iput v1, p0, LD/b;->h:I

    iput v1, p0, LD/b;->i:I

    iput-boolean v0, p0, LD/b;->j:Z

    iput-object p1, p0, LD/b;->b:LD/c;

    iput-object p2, p0, LD/b;->c:LD/d;

    return-void
.end method


# virtual methods
.method final a(LD/i;FZ)V
    .registers 14

    const/4 v0, 0x0

    cmpl-float v1, p2, v0

    if-nez v1, :cond_6

    return-void

    :cond_6
    iget v1, p0, LD/b;->h:I

    const/4 v2, 0x1

    iget-object v3, p0, LD/b;->b:LD/c;

    const/4 v4, 0x0

    const/4 v5, -0x1

    if-ne v1, v5, :cond_41

    iput v4, p0, LD/b;->h:I

    iget-object p3, p0, LD/b;->g:[F

    aput p2, p3, v4

    iget-object p2, p0, LD/b;->e:[I

    iget p3, p1, LD/i;->a:I

    aput p3, p2, v4

    iget-object p2, p0, LD/b;->f:[I

    aput v5, p2, v4

    iget p2, p1, LD/i;->i:I

    add-int/2addr p2, v2

    iput p2, p1, LD/i;->i:I

    invoke-virtual {p1, v3}, LD/i;->a(LD/c;)V

    iget p1, p0, LD/b;->a:I

    add-int/2addr p1, v2

    iput p1, p0, LD/b;->a:I

    iget-boolean p1, p0, LD/b;->j:Z

    if-nez p1, :cond_40

    iget p1, p0, LD/b;->i:I

    add-int/2addr p1, v2

    iput p1, p0, LD/b;->i:I

    iget-object p2, p0, LD/b;->e:[I

    array-length p3, p2

    if-lt p1, p3, :cond_40

    iput-boolean v2, p0, LD/b;->j:Z

    array-length p1, p2

    sub-int/2addr p1, v2

    iput p1, p0, LD/b;->i:I

    :cond_40
    return-void

    :cond_41
    const/4 v6, 0x0

    const/4 v7, -0x1

    :goto_43
    if-eq v1, v5, :cond_8d

    iget v8, p0, LD/b;->a:I

    if-ge v6, v8, :cond_8d

    iget-object v8, p0, LD/b;->e:[I

    aget v8, v8, v1

    iget v9, p1, LD/i;->a:I

    if-ne v8, v9, :cond_83

    iget-object v4, p0, LD/b;->g:[F

    aget v5, v4, v1

    add-float/2addr v5, p2

    aput v5, v4, v1

    cmpl-float p2, v5, v0

    if-nez p2, :cond_82

    iget p2, p0, LD/b;->h:I

    if-ne v1, p2, :cond_67

    iget-object p2, p0, LD/b;->f:[I

    aget p2, p2, v1

    iput p2, p0, LD/b;->h:I

    goto :goto_6d

    :cond_67
    iget-object p2, p0, LD/b;->f:[I

    aget v0, p2, v1

    aput v0, p2, v7

    :goto_6d
    if-eqz p3, :cond_72

    invoke-virtual {p1, v3}, LD/i;->c(LD/c;)V

    :cond_72
    iget-boolean p2, p0, LD/b;->j:Z

    if-eqz p2, :cond_78

    iput v1, p0, LD/b;->i:I

    :cond_78
    iget p2, p1, LD/i;->i:I

    sub-int/2addr p2, v2

    iput p2, p1, LD/i;->i:I

    iget p1, p0, LD/b;->a:I

    sub-int/2addr p1, v2

    iput p1, p0, LD/b;->a:I

    :cond_82
    return-void

    :cond_83
    if-ge v8, v9, :cond_86

    move v7, v1

    :cond_86
    iget-object v8, p0, LD/b;->f:[I

    aget v1, v8, v1

    add-int/lit8 v6, v6, 0x1

    goto :goto_43

    :cond_8d
    iget p3, p0, LD/b;->i:I

    add-int/lit8 v0, p3, 0x1

    iget-boolean v1, p0, LD/b;->j:Z

    if-eqz v1, :cond_9e

    iget-object v0, p0, LD/b;->e:[I

    aget v1, v0, p3

    if-ne v1, v5, :cond_9c

    goto :goto_9f

    :cond_9c
    array-length p3, v0

    goto :goto_9f

    :cond_9e
    move p3, v0

    :goto_9f
    iget-object v0, p0, LD/b;->e:[I

    array-length v1, v0

    if-lt p3, v1, :cond_b8

    iget v1, p0, LD/b;->a:I

    array-length v0, v0

    if-ge v1, v0, :cond_b8

    const/4 v0, 0x0

    :goto_aa
    iget-object v1, p0, LD/b;->e:[I

    array-length v6, v1

    if-ge v0, v6, :cond_b8

    aget v1, v1, v0

    if-ne v1, v5, :cond_b5

    move p3, v0

    goto :goto_b8

    :cond_b5
    add-int/lit8 v0, v0, 0x1

    goto :goto_aa

    :cond_b8
    :goto_b8
    iget-object v0, p0, LD/b;->e:[I

    array-length v1, v0

    if-lt p3, v1, :cond_e6

    array-length p3, v0

    iget v0, p0, LD/b;->d:I

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, LD/b;->d:I

    iput-boolean v4, p0, LD/b;->j:Z

    add-int/lit8 v1, p3, -0x1

    iput v1, p0, LD/b;->i:I

    iget-object v1, p0, LD/b;->g:[F

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([FI)[F

    move-result-object v0

    iput-object v0, p0, LD/b;->g:[F

    iget-object v0, p0, LD/b;->e:[I

    iget v1, p0, LD/b;->d:I

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    iput-object v0, p0, LD/b;->e:[I

    iget-object v0, p0, LD/b;->f:[I

    iget v1, p0, LD/b;->d:I

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    iput-object v0, p0, LD/b;->f:[I

    :cond_e6
    iget-object v0, p0, LD/b;->e:[I

    iget v1, p1, LD/i;->a:I

    aput v1, v0, p3

    iget-object v0, p0, LD/b;->g:[F

    aput p2, v0, p3

    if-eq v7, v5, :cond_fb

    iget-object p2, p0, LD/b;->f:[I

    aget v0, p2, v7

    aput v0, p2, p3

    aput p3, p2, v7

    goto :goto_103

    :cond_fb
    iget-object p2, p0, LD/b;->f:[I

    iget v0, p0, LD/b;->h:I

    aput v0, p2, p3

    iput p3, p0, LD/b;->h:I

    :goto_103
    iget p2, p1, LD/i;->i:I

    add-int/2addr p2, v2

    iput p2, p1, LD/i;->i:I

    invoke-virtual {p1, v3}, LD/i;->a(LD/c;)V

    iget p1, p0, LD/b;->a:I

    add-int/2addr p1, v2

    iput p1, p0, LD/b;->a:I

    iget-boolean p1, p0, LD/b;->j:Z

    if-nez p1, :cond_119

    iget p1, p0, LD/b;->i:I

    add-int/2addr p1, v2

    iput p1, p0, LD/b;->i:I

    :cond_119
    iget p1, p0, LD/b;->i:I

    iget-object p2, p0, LD/b;->e:[I

    array-length p3, p2

    if-lt p1, p3, :cond_126

    iput-boolean v2, p0, LD/b;->j:Z

    array-length p1, p2

    sub-int/2addr p1, v2

    iput p1, p0, LD/b;->i:I

    :cond_126
    return-void
.end method

.method final b()LD/i;
    .registers 16

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v4, v1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    :goto_b
    const/4 v10, -0x1

    if-eq v0, v10, :cond_97

    iget v10, p0, LD/b;->a:I

    if-ge v5, v10, :cond_97

    iget-object v10, p0, LD/b;->g:[F

    aget v11, v10, v0

    iget-object v12, p0, LD/b;->c:LD/d;

    iget-object v12, v12, LD/d;->c:[LD/i;

    iget-object v13, p0, LD/b;->e:[I

    aget v13, v13, v0

    aget-object v12, v12, v13

    iget-object v13, p0, LD/b;->b:LD/c;

    cmpg-float v14, v11, v2

    if-gez v14, :cond_34

    const v14, -0x457ced91    # -0.001f

    cmpl-float v14, v11, v14

    if-lez v14, :cond_41

    aput v2, v10, v0

    invoke-virtual {v12, v13}, LD/i;->c(LD/c;)V

    :goto_32
    const/4 v11, 0x0

    goto :goto_41

    :cond_34
    const v14, 0x3a83126f    # 0.001f

    cmpg-float v14, v11, v14

    if-gez v14, :cond_41

    aput v2, v10, v0

    invoke-virtual {v12, v13}, LD/i;->c(LD/c;)V

    goto :goto_32

    :cond_41
    :goto_41
    cmpl-float v10, v11, v2

    if-eqz v10, :cond_8f

    iget-object v10, v12, LD/i;->f:LD/i$a;

    sget-object v13, LD/i$a;->UNRESTRICTED:LD/i$a;

    const/4 v14, 0x1

    if-ne v10, v13, :cond_6b

    if-nez v4, :cond_58

    iget v4, v12, LD/i;->i:I

    if-gt v4, v14, :cond_54

    :goto_52
    const/4 v7, 0x1

    goto :goto_55

    :cond_54
    const/4 v7, 0x0

    :goto_55
    move v6, v11

    move-object v4, v12

    goto :goto_8f

    :cond_58
    cmpl-float v10, v6, v11

    if-lez v10, :cond_61

    iget v4, v12, LD/i;->i:I

    if-gt v4, v14, :cond_54

    goto :goto_52

    :cond_61
    if-nez v7, :cond_8f

    iget v10, v12, LD/i;->i:I

    if-gt v10, v14, :cond_8f

    move v6, v11

    move-object v4, v12

    const/4 v7, 0x1

    goto :goto_8f

    :cond_6b
    if-nez v4, :cond_8f

    cmpg-float v10, v11, v2

    if-gez v10, :cond_8f

    if-nez v1, :cond_7d

    iget v1, v12, LD/i;->i:I

    if-gt v1, v14, :cond_79

    :goto_77
    const/4 v9, 0x1

    goto :goto_7a

    :cond_79
    const/4 v9, 0x0

    :goto_7a
    move v8, v11

    move-object v1, v12

    goto :goto_8f

    :cond_7d
    cmpl-float v10, v8, v11

    if-lez v10, :cond_86

    iget v1, v12, LD/i;->i:I

    if-gt v1, v14, :cond_79

    goto :goto_77

    :cond_86
    if-nez v9, :cond_8f

    iget v10, v12, LD/i;->i:I

    if-gt v10, v14, :cond_8f

    move v8, v11

    move-object v1, v12

    const/4 v9, 0x1

    :cond_8f
    :goto_8f
    iget-object v10, p0, LD/b;->f:[I

    aget v0, v10, v0

    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_b

    :cond_97
    if-eqz v4, :cond_9a

    return-object v4

    :cond_9a
    return-object v1
.end method

.method public final c()V
    .registers 6

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_4
    const/4 v3, -0x1

    if-eq v0, v3, :cond_23

    iget v4, p0, LD/b;->a:I

    if-ge v2, v4, :cond_23

    iget-object v3, p0, LD/b;->c:LD/d;

    iget-object v3, v3, LD/d;->c:[LD/i;

    iget-object v4, p0, LD/b;->e:[I

    aget v4, v4, v0

    aget-object v3, v3, v4

    if-eqz v3, :cond_1c

    iget-object v4, p0, LD/b;->b:LD/c;

    invoke-virtual {v3, v4}, LD/i;->c(LD/c;)V

    :cond_1c
    iget-object v3, p0, LD/b;->f:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_23
    iput v3, p0, LD/b;->h:I

    iput v3, p0, LD/b;->i:I

    iput-boolean v1, p0, LD/b;->j:Z

    iput v1, p0, LD/b;->a:I

    return-void
.end method

.method final d(LD/i;)Z
    .registers 8

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    const/4 v2, -0x1

    if-ne v0, v2, :cond_7

    return v1

    :cond_7
    const/4 v3, 0x0

    :goto_8
    if-eq v0, v2, :cond_1f

    iget v4, p0, LD/b;->a:I

    if-ge v3, v4, :cond_1f

    iget-object v4, p0, LD/b;->e:[I

    aget v4, v4, v0

    iget v5, p1, LD/i;->a:I

    if-ne v4, v5, :cond_18

    const/4 p1, 0x1

    return p1

    :cond_18
    iget-object v4, p0, LD/b;->f:[I

    aget v0, v4, v0

    add-int/lit8 v3, v3, 0x1

    goto :goto_8

    :cond_1f
    return v1
.end method

.method final e(F)V
    .registers 6

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    :goto_3
    const/4 v2, -0x1

    if-eq v0, v2, :cond_18

    iget v2, p0, LD/b;->a:I

    if-ge v1, v2, :cond_18

    iget-object v2, p0, LD/b;->g:[F

    aget v3, v2, v0

    div-float/2addr v3, p1

    aput v3, v2, v0

    iget-object v2, p0, LD/b;->f:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_18
    return-void
.end method

.method public final f(LD/i;)F
    .registers 6

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    :goto_3
    const/4 v2, -0x1

    if-eq v0, v2, :cond_1e

    iget v2, p0, LD/b;->a:I

    if-ge v1, v2, :cond_1e

    iget-object v2, p0, LD/b;->e:[I

    aget v2, v2, v0

    iget v3, p1, LD/i;->a:I

    if-ne v2, v3, :cond_17

    iget-object p1, p0, LD/b;->g:[F

    aget p1, p1, v0

    return p1

    :cond_17
    iget-object v2, p0, LD/b;->f:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_1e
    const/4 p1, 0x0

    return p1
.end method

.method final g([ZLD/i;)LD/i;
    .registers 12

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_6
    const/4 v5, -0x1

    if-eq v0, v5, :cond_40

    iget v5, p0, LD/b;->a:I

    if-ge v1, v5, :cond_40

    iget-object v5, p0, LD/b;->g:[F

    aget v5, v5, v0

    cmpg-float v6, v5, v3

    if-gez v6, :cond_39

    iget-object v6, p0, LD/b;->c:LD/d;

    iget-object v6, v6, LD/d;->c:[LD/i;

    iget-object v7, p0, LD/b;->e:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    if-eqz p1, :cond_27

    iget v7, v6, LD/i;->a:I

    aget-boolean v7, p1, v7

    if-nez v7, :cond_39

    :cond_27
    if-eq v6, p2, :cond_39

    iget-object v7, v6, LD/i;->f:LD/i$a;

    sget-object v8, LD/i$a;->SLACK:LD/i$a;

    if-eq v7, v8, :cond_33

    sget-object v8, LD/i$a;->ERROR:LD/i$a;

    if-ne v7, v8, :cond_39

    :cond_33
    cmpg-float v7, v5, v4

    if-gez v7, :cond_39

    move v4, v5

    move-object v2, v6

    :cond_39
    iget-object v5, p0, LD/b;->f:[I

    aget v0, v5, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_40
    return-object v2
.end method

.method final h(I)LD/i;
    .registers 5

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    :goto_3
    const/4 v2, -0x1

    if-eq v0, v2, :cond_1e

    iget v2, p0, LD/b;->a:I

    if-ge v1, v2, :cond_1e

    if-ne v1, p1, :cond_17

    iget-object p1, p0, LD/b;->c:LD/d;

    iget-object p1, p1, LD/d;->c:[LD/i;

    iget-object v1, p0, LD/b;->e:[I

    aget v0, v1, v0

    aget-object p1, p1, v0

    return-object p1

    :cond_17
    iget-object v2, p0, LD/b;->f:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_1e
    const/4 p1, 0x0

    return-object p1
.end method

.method final i(I)F
    .registers 5

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    :goto_3
    const/4 v2, -0x1

    if-eq v0, v2, :cond_18

    iget v2, p0, LD/b;->a:I

    if-ge v1, v2, :cond_18

    if-ne v1, p1, :cond_11

    iget-object p1, p0, LD/b;->g:[F

    aget p1, p1, v0

    return p1

    :cond_11
    iget-object v2, p0, LD/b;->f:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_18
    const/4 p1, 0x0

    return p1
.end method

.method final j()V
    .registers 6

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    :goto_3
    const/4 v2, -0x1

    if-eq v0, v2, :cond_1b

    iget v2, p0, LD/b;->a:I

    if-ge v1, v2, :cond_1b

    iget-object v2, p0, LD/b;->g:[F

    aget v3, v2, v0

    const/high16 v4, -0x40800000    # -1.0f

    mul-float v3, v3, v4

    aput v3, v2, v0

    iget-object v2, p0, LD/b;->f:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_1b
    return-void
.end method

.method public final k(LD/i;F)V
    .registers 12

    const/4 v0, 0x0

    const/4 v1, 0x1

    cmpl-float v0, p2, v0

    if-nez v0, :cond_a

    invoke-virtual {p0, p1, v1}, LD/b;->l(LD/i;Z)F

    return-void

    :cond_a
    iget v0, p0, LD/b;->h:I

    iget-object v2, p0, LD/b;->b:LD/c;

    const/4 v3, 0x0

    const/4 v4, -0x1

    if-ne v0, v4, :cond_44

    iput v3, p0, LD/b;->h:I

    iget-object v0, p0, LD/b;->g:[F

    aput p2, v0, v3

    iget-object p2, p0, LD/b;->e:[I

    iget v0, p1, LD/i;->a:I

    aput v0, p2, v3

    iget-object p2, p0, LD/b;->f:[I

    aput v4, p2, v3

    iget p2, p1, LD/i;->i:I

    add-int/2addr p2, v1

    iput p2, p1, LD/i;->i:I

    invoke-virtual {p1, v2}, LD/i;->a(LD/c;)V

    iget p1, p0, LD/b;->a:I

    add-int/2addr p1, v1

    iput p1, p0, LD/b;->a:I

    iget-boolean p1, p0, LD/b;->j:Z

    if-nez p1, :cond_43

    iget p1, p0, LD/b;->i:I

    add-int/2addr p1, v1

    iput p1, p0, LD/b;->i:I

    iget-object p2, p0, LD/b;->e:[I

    array-length v0, p2

    if-lt p1, v0, :cond_43

    iput-boolean v1, p0, LD/b;->j:Z

    array-length p1, p2

    sub-int/2addr p1, v1

    iput p1, p0, LD/b;->i:I

    :cond_43
    return-void

    :cond_44
    const/4 v5, 0x0

    const/4 v6, -0x1

    :goto_46
    if-eq v0, v4, :cond_63

    iget v7, p0, LD/b;->a:I

    if-ge v5, v7, :cond_63

    iget-object v7, p0, LD/b;->e:[I

    aget v7, v7, v0

    iget v8, p1, LD/i;->a:I

    if-ne v7, v8, :cond_59

    iget-object p1, p0, LD/b;->g:[F

    aput p2, p1, v0

    return-void

    :cond_59
    if-ge v7, v8, :cond_5c

    move v6, v0

    :cond_5c
    iget-object v7, p0, LD/b;->f:[I

    aget v0, v7, v0

    add-int/lit8 v5, v5, 0x1

    goto :goto_46

    :cond_63
    iget v0, p0, LD/b;->i:I

    add-int/lit8 v5, v0, 0x1

    iget-boolean v7, p0, LD/b;->j:Z

    if-eqz v7, :cond_74

    iget-object v5, p0, LD/b;->e:[I

    aget v7, v5, v0

    if-ne v7, v4, :cond_72

    goto :goto_75

    :cond_72
    array-length v0, v5

    goto :goto_75

    :cond_74
    move v0, v5

    :goto_75
    iget-object v5, p0, LD/b;->e:[I

    array-length v7, v5

    if-lt v0, v7, :cond_8e

    iget v7, p0, LD/b;->a:I

    array-length v5, v5

    if-ge v7, v5, :cond_8e

    const/4 v5, 0x0

    :goto_80
    iget-object v7, p0, LD/b;->e:[I

    array-length v8, v7

    if-ge v5, v8, :cond_8e

    aget v7, v7, v5

    if-ne v7, v4, :cond_8b

    move v0, v5

    goto :goto_8e

    :cond_8b
    add-int/lit8 v5, v5, 0x1

    goto :goto_80

    :cond_8e
    :goto_8e
    iget-object v5, p0, LD/b;->e:[I

    array-length v7, v5

    if-lt v0, v7, :cond_bc

    array-length v0, v5

    iget v5, p0, LD/b;->d:I

    mul-int/lit8 v5, v5, 0x2

    iput v5, p0, LD/b;->d:I

    iput-boolean v3, p0, LD/b;->j:Z

    add-int/lit8 v3, v0, -0x1

    iput v3, p0, LD/b;->i:I

    iget-object v3, p0, LD/b;->g:[F

    invoke-static {v3, v5}, Ljava/util/Arrays;->copyOf([FI)[F

    move-result-object v3

    iput-object v3, p0, LD/b;->g:[F

    iget-object v3, p0, LD/b;->e:[I

    iget v5, p0, LD/b;->d:I

    invoke-static {v3, v5}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v3

    iput-object v3, p0, LD/b;->e:[I

    iget-object v3, p0, LD/b;->f:[I

    iget v5, p0, LD/b;->d:I

    invoke-static {v3, v5}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v3

    iput-object v3, p0, LD/b;->f:[I

    :cond_bc
    iget-object v3, p0, LD/b;->e:[I

    iget v5, p1, LD/i;->a:I

    aput v5, v3, v0

    iget-object v3, p0, LD/b;->g:[F

    aput p2, v3, v0

    if-eq v6, v4, :cond_d1

    iget-object p2, p0, LD/b;->f:[I

    aget v3, p2, v6

    aput v3, p2, v0

    aput v0, p2, v6

    goto :goto_d9

    :cond_d1
    iget-object p2, p0, LD/b;->f:[I

    iget v3, p0, LD/b;->h:I

    aput v3, p2, v0

    iput v0, p0, LD/b;->h:I

    :goto_d9
    iget p2, p1, LD/i;->i:I

    add-int/2addr p2, v1

    iput p2, p1, LD/i;->i:I

    invoke-virtual {p1, v2}, LD/i;->a(LD/c;)V

    iget p1, p0, LD/b;->a:I

    add-int/2addr p1, v1

    iput p1, p0, LD/b;->a:I

    iget-boolean p2, p0, LD/b;->j:Z

    if-nez p2, :cond_ef

    iget p2, p0, LD/b;->i:I

    add-int/2addr p2, v1

    iput p2, p0, LD/b;->i:I

    :cond_ef
    iget-object p2, p0, LD/b;->e:[I

    array-length v0, p2

    if-lt p1, v0, :cond_f6

    iput-boolean v1, p0, LD/b;->j:Z

    :cond_f6
    iget p1, p0, LD/b;->i:I

    array-length v0, p2

    if-lt p1, v0, :cond_101

    iput-boolean v1, p0, LD/b;->j:Z

    array-length p1, p2

    sub-int/2addr p1, v1

    iput p1, p0, LD/b;->i:I

    :cond_101
    return-void
.end method

.method public final l(LD/i;Z)F
    .registers 11

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    const/4 v2, -0x1

    if-ne v0, v2, :cond_7

    return v1

    :cond_7
    const/4 v3, 0x0

    const/4 v4, -0x1

    :goto_9
    if-eq v0, v2, :cond_54

    iget v5, p0, LD/b;->a:I

    if-ge v3, v5, :cond_54

    iget-object v5, p0, LD/b;->e:[I

    aget v5, v5, v0

    iget v6, p1, LD/i;->a:I

    if-ne v5, v6, :cond_4a

    iget v1, p0, LD/b;->h:I

    if-ne v0, v1, :cond_22

    iget-object v1, p0, LD/b;->f:[I

    aget v1, v1, v0

    iput v1, p0, LD/b;->h:I

    goto :goto_28

    :cond_22
    iget-object v1, p0, LD/b;->f:[I

    aget v3, v1, v0

    aput v3, v1, v4

    :goto_28
    if-eqz p2, :cond_2f

    iget-object p2, p0, LD/b;->b:LD/c;

    invoke-virtual {p1, p2}, LD/i;->c(LD/c;)V

    :cond_2f
    iget p2, p1, LD/i;->i:I

    add-int/lit8 p2, p2, -0x1

    iput p2, p1, LD/i;->i:I

    iget p1, p0, LD/b;->a:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, LD/b;->a:I

    iget-object p1, p0, LD/b;->e:[I

    aput v2, p1, v0

    iget-boolean p1, p0, LD/b;->j:Z

    if-eqz p1, :cond_45

    iput v0, p0, LD/b;->i:I

    :cond_45
    iget-object p1, p0, LD/b;->g:[F

    aget p1, p1, v0

    return p1

    :cond_4a
    iget-object v4, p0, LD/b;->f:[I

    aget v4, v4, v0

    add-int/lit8 v3, v3, 0x1

    move v7, v4

    move v4, v0

    move v0, v7

    goto :goto_9

    :cond_54
    return v1
.end method

.method final m(LD/c;LD/c;)V
    .registers 11

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    :goto_3
    const/4 v2, 0x0

    :goto_4
    const/4 v3, -0x1

    if-eq v0, v3, :cond_54

    iget v4, p0, LD/b;->a:I

    if-ge v2, v4, :cond_54

    iget-object v4, p0, LD/b;->e:[I

    aget v4, v4, v0

    iget-object v5, p2, LD/c;->a:LD/i;

    iget v6, v5, LD/i;->a:I

    if-ne v4, v6, :cond_4d

    iget-object v2, p0, LD/b;->g:[F

    aget v0, v2, v0

    invoke-virtual {p0, v5, v1}, LD/b;->l(LD/i;Z)F

    iget-object v2, p2, LD/c;->c:LD/b;

    iget v4, v2, LD/b;->h:I

    const/4 v5, 0x0

    :goto_21
    if-eq v4, v3, :cond_41

    iget v6, v2, LD/b;->a:I

    if-ge v5, v6, :cond_41

    iget-object v6, p0, LD/b;->c:LD/d;

    iget-object v6, v6, LD/d;->c:[LD/i;

    iget-object v7, v2, LD/b;->e:[I

    aget v7, v7, v4

    aget-object v6, v6, v7

    iget-object v7, v2, LD/b;->g:[F

    aget v7, v7, v4

    mul-float v7, v7, v0

    invoke-virtual {p0, v6, v7, v1}, LD/b;->a(LD/i;FZ)V

    iget-object v6, v2, LD/b;->f:[I

    aget v4, v6, v4

    add-int/lit8 v5, v5, 0x1

    goto :goto_21

    :cond_41
    iget v2, p1, LD/c;->b:F

    iget v3, p2, LD/c;->b:F

    mul-float v3, v3, v0

    add-float/2addr v3, v2

    iput v3, p1, LD/c;->b:F

    iget v0, p0, LD/b;->h:I

    goto :goto_3

    :cond_4d
    iget-object v3, p0, LD/b;->f:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_54
    return-void
.end method

.method final n(LD/c;[LD/c;)V
    .registers 14

    iget v0, p0, LD/b;->h:I

    const/4 v1, 0x0

    :goto_3
    const/4 v2, 0x0

    :goto_4
    const/4 v3, -0x1

    if-eq v0, v3, :cond_64

    iget v4, p0, LD/b;->a:I

    if-ge v2, v4, :cond_64

    iget-object v4, p0, LD/b;->c:LD/d;

    iget-object v5, v4, LD/d;->c:[LD/i;

    iget-object v6, p0, LD/b;->e:[I

    aget v6, v6, v0

    aget-object v5, v5, v6

    iget v6, v5, LD/i;->b:I

    if-eq v6, v3, :cond_5d

    iget-object v2, p0, LD/b;->g:[F

    aget v0, v2, v0

    const/4 v2, 0x1

    invoke-virtual {p0, v5, v2}, LD/b;->l(LD/i;Z)F

    iget v5, v5, LD/i;->b:I

    aget-object v5, p2, v5

    iget-boolean v6, v5, LD/c;->d:Z

    if-nez v6, :cond_4c

    iget-object v6, v5, LD/c;->c:LD/b;

    iget v7, v6, LD/b;->h:I

    const/4 v8, 0x0

    :goto_2e
    if-eq v7, v3, :cond_4c

    iget v9, v6, LD/b;->a:I

    if-ge v8, v9, :cond_4c

    iget-object v9, v4, LD/d;->c:[LD/i;

    iget-object v10, v6, LD/b;->e:[I

    aget v10, v10, v7

    aget-object v9, v9, v10

    iget-object v10, v6, LD/b;->g:[F

    aget v10, v10, v7

    mul-float v10, v10, v0

    invoke-virtual {p0, v9, v10, v2}, LD/b;->a(LD/i;FZ)V

    iget-object v9, v6, LD/b;->f:[I

    aget v7, v9, v7

    add-int/lit8 v8, v8, 0x1

    goto :goto_2e

    :cond_4c
    iget v2, p1, LD/c;->b:F

    iget v3, v5, LD/c;->b:F

    mul-float v3, v3, v0

    add-float/2addr v3, v2

    iput v3, p1, LD/c;->b:F

    iget-object v0, v5, LD/c;->a:LD/i;

    invoke-virtual {v0, p1}, LD/i;->c(LD/c;)V

    iget v0, p0, LD/b;->h:I

    goto :goto_3

    :cond_5d
    iget-object v3, p0, LD/b;->f:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_64
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    iget v0, p0, LD/b;->h:I

    const-string v1, ""

    const/4 v2, 0x0

    :goto_5
    const/4 v3, -0x1

    if-eq v0, v3, :cond_42

    iget v3, p0, LD/b;->a:I

    if-ge v2, v3, :cond_42

    const-string v3, " -> "

    invoke-static {v1, v3}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, LD/a;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v3, p0, LD/b;->g:[F

    aget v3, v3, v0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v3, " : "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, LD/a;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v3, p0, LD/b;->c:LD/d;

    iget-object v3, v3, LD/d;->c:[LD/i;

    iget-object v4, p0, LD/b;->e:[I

    aget v4, v4, v0

    aget-object v3, v3, v4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, LD/b;->f:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_42
    return-object v1
.end method
