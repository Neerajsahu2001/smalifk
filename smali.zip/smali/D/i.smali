.class public final LD/i;
.super Ljava/lang/Object;
.source "SolverVariable.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD/i$a;
    }
.end annotation


# instance fields
.field public a:I

.field b:I

.field public c:I

.field public d:F

.field e:[F

.field f:LD/i$a;

.field g:[LD/c;

.field h:I

.field public i:I


# direct methods
.method public constructor <init>(LD/i$a;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, LD/i;->a:I

    iput v0, p0, LD/i;->b:I

    const/4 v0, 0x0

    iput v0, p0, LD/i;->c:I

    const/4 v1, 0x7

    new-array v1, v1, [F

    iput-object v1, p0, LD/i;->e:[F

    const/16 v1, 0x8

    new-array v1, v1, [LD/c;

    iput-object v1, p0, LD/i;->g:[LD/c;

    iput v0, p0, LD/i;->h:I

    iput v0, p0, LD/i;->i:I

    iput-object p1, p0, LD/i;->f:LD/i$a;

    return-void
.end method

.method static b()V
    .registers 0

    return-void
.end method


# virtual methods
.method public final a(LD/c;)V
    .registers 5

    const/4 v0, 0x0

    :goto_1
    iget v1, p0, LD/i;->h:I

    if-ge v0, v1, :cond_f

    iget-object v1, p0, LD/i;->g:[LD/c;

    aget-object v1, v1, v0

    if-ne v1, p1, :cond_c

    return-void

    :cond_c
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_f
    iget-object v0, p0, LD/i;->g:[LD/c;

    array-length v2, v0

    if-lt v1, v2, :cond_1f

    array-length v1, v0

    mul-int/lit8 v1, v1, 0x2

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LD/c;

    iput-object v0, p0, LD/i;->g:[LD/c;

    :cond_1f
    iget-object v0, p0, LD/i;->g:[LD/c;

    iget v1, p0, LD/i;->h:I

    aput-object p1, v0, v1

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, LD/i;->h:I

    return-void
.end method

.method public final c(LD/c;)V
    .registers 7

    iget v0, p0, LD/i;->h:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_4
    if-ge v2, v0, :cond_29

    iget-object v3, p0, LD/i;->g:[LD/c;

    aget-object v3, v3, v2

    if-ne v3, p1, :cond_26

    :goto_c
    sub-int p1, v0, v2

    add-int/lit8 p1, p1, -0x1

    if-ge v1, p1, :cond_1f

    iget-object p1, p0, LD/i;->g:[LD/c;

    add-int v3, v2, v1

    add-int/lit8 v4, v3, 0x1

    aget-object v4, p1, v4

    aput-object v4, p1, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_c

    :cond_1f
    iget p1, p0, LD/i;->h:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, LD/i;->h:I

    return-void

    :cond_26
    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_29
    return-void
.end method

.method public final d()V
    .registers 3

    sget-object v0, LD/i$a;->UNKNOWN:LD/i$a;

    iput-object v0, p0, LD/i;->f:LD/i$a;

    const/4 v0, 0x0

    iput v0, p0, LD/i;->c:I

    const/4 v1, -0x1

    iput v1, p0, LD/i;->a:I

    iput v1, p0, LD/i;->b:I

    const/4 v1, 0x0

    iput v1, p0, LD/i;->d:F

    iput v0, p0, LD/i;->h:I

    iput v0, p0, LD/i;->i:I

    return-void
.end method

.method public final e(LD/c;)V
    .registers 7

    iget v0, p0, LD/i;->h:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_4
    if-ge v2, v0, :cond_12

    iget-object v3, p0, LD/i;->g:[LD/c;

    aget-object v3, v3, v2

    iget-object v4, v3, LD/c;->c:LD/b;

    invoke-virtual {v4, v3, p1}, LD/b;->m(LD/c;LD/c;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_12
    iput v1, p0, LD/i;->h:I

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    const-string v0, "null"

    return-object v0
.end method
