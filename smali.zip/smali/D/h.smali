.class final LD/h;
.super Ljava/lang/Object;
.source "Pools.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private final a:[Ljava/lang/Object;

.field private b:I


# direct methods
.method constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x100

    new-array v0, v0, [Ljava/lang/Object;

    iput-object v0, p0, LD/h;->a:[Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    iget v0, p0, LD/h;->b:I

    const/4 v1, 0x0

    if-lez v0, :cond_12

    add-int/lit8 v2, v0, -0x1

    iget-object v3, p0, LD/h;->a:[Ljava/lang/Object;

    aget-object v4, v3, v2

    aput-object v1, v3, v2

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, LD/h;->b:I

    return-object v4

    :cond_12
    return-object v1
.end method

.method public final b(LD/c;)V
    .registers 5

    iget v0, p0, LD/h;->b:I

    iget-object v1, p0, LD/h;->a:[Ljava/lang/Object;

    array-length v2, v1

    if-ge v0, v2, :cond_d

    aput-object p1, v1, v0

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, LD/h;->b:I

    :cond_d
    return-void
.end method

.method public final c(I[Ljava/lang/Object;)V
    .registers 8

    array-length v0, p2

    if-le p1, v0, :cond_4

    array-length p1, p2

    :cond_4
    const/4 v0, 0x0

    :goto_5
    if-ge v0, p1, :cond_19

    aget-object v1, p2, v0

    iget v2, p0, LD/h;->b:I

    iget-object v3, p0, LD/h;->a:[Ljava/lang/Object;

    array-length v4, v3

    if-ge v2, v4, :cond_16

    aput-object v1, v3, v2

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, LD/h;->b:I

    :cond_16
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_19
    return-void
.end method
