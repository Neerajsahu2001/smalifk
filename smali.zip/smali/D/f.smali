.class public final LD/f;
.super Ljava/lang/Object;
.source "LinearSystem.java"


# static fields
.field private static o:I = 0x3e8


# instance fields
.field a:I

.field private b:LD/e;

.field private c:I

.field private d:I

.field e:[LD/c;

.field public f:Z

.field private g:[Z

.field h:I

.field i:I

.field private j:I

.field final k:LD/d;

.field private l:[LD/i;

.field private m:I

.field private final n:LD/c;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, LD/f;->a:I

    const/16 v1, 0x20

    iput v1, p0, LD/f;->c:I

    iput v1, p0, LD/f;->d:I

    const/4 v2, 0x0

    iput-object v2, p0, LD/f;->e:[LD/c;

    iput-boolean v0, p0, LD/f;->f:Z

    new-array v3, v1, [Z

    iput-object v3, p0, LD/f;->g:[Z

    const/4 v3, 0x1

    iput v3, p0, LD/f;->h:I

    iput v0, p0, LD/f;->i:I

    iput v1, p0, LD/f;->j:I

    sget v3, LD/f;->o:I

    new-array v3, v3, [LD/i;

    iput-object v3, p0, LD/f;->l:[LD/i;

    iput v0, p0, LD/f;->m:I

    new-array v3, v1, [LD/c;

    iput-object v3, p0, LD/f;->e:[LD/c;

    :goto_28
    iget-object v3, p0, LD/f;->e:[LD/c;

    array-length v4, v3

    if-ge v0, v4, :cond_3f

    aget-object v3, v3, v0

    if-eqz v3, :cond_38

    iget-object v4, p0, LD/f;->k:LD/d;

    iget-object v4, v4, LD/d;->a:LD/h;

    invoke-virtual {v4, v3}, LD/h;->b(LD/c;)V

    :cond_38
    iget-object v3, p0, LD/f;->e:[LD/c;

    aput-object v2, v3, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_28

    :cond_3f
    new-instance v0, LD/d;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    new-instance v2, LD/h;

    invoke-direct {v2}, LD/h;-><init>()V

    iput-object v2, v0, LD/d;->a:LD/h;

    new-instance v2, LD/h;

    invoke-direct {v2}, LD/h;-><init>()V

    iput-object v2, v0, LD/d;->b:LD/h;

    new-array v1, v1, [LD/i;

    iput-object v1, v0, LD/d;->c:[LD/i;

    iput-object v0, p0, LD/f;->k:LD/d;

    new-instance v1, LD/e;

    invoke-direct {v1, v0}, LD/c;-><init>(LD/d;)V

    iput-object v1, p0, LD/f;->b:LD/e;

    new-instance v1, LD/c;

    invoke-direct {v1, v0}, LD/c;-><init>(LD/d;)V

    iput-object v1, p0, LD/f;->n:LD/c;

    return-void
.end method

.method private a(LD/i$a;)LD/i;
    .registers 5

    iget-object v0, p0, LD/f;->k:LD/d;

    iget-object v0, v0, LD/d;->b:LD/h;

    invoke-virtual {v0}, LD/h;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LD/i;

    if-nez v0, :cond_14

    new-instance v0, LD/i;

    invoke-direct {v0, p1}, LD/i;-><init>(LD/i$a;)V

    iput-object p1, v0, LD/i;->f:LD/i$a;

    goto :goto_19

    :cond_14
    invoke-virtual {v0}, LD/i;->d()V

    iput-object p1, v0, LD/i;->f:LD/i$a;

    :goto_19
    iget p1, p0, LD/f;->m:I

    sget v1, LD/f;->o:I

    if-lt p1, v1, :cond_2d

    mul-int/lit8 v1, v1, 0x2

    sput v1, LD/f;->o:I

    iget-object p1, p0, LD/f;->l:[LD/i;

    invoke-static {p1, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [LD/i;

    iput-object p1, p0, LD/f;->l:[LD/i;

    :cond_2d
    iget-object p1, p0, LD/f;->l:[LD/i;

    iget v1, p0, LD/f;->m:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, LD/f;->m:I

    aput-object v0, p1, v1

    return-object v0
.end method

.method private final j(LD/c;)V
    .registers 4

    iget-object v0, p0, LD/f;->e:[LD/c;

    iget v1, p0, LD/f;->i:I

    aget-object v0, v0, v1

    if-eqz v0, :cond_f

    iget-object v1, p0, LD/f;->k:LD/d;

    iget-object v1, v1, LD/d;->a:LD/h;

    invoke-virtual {v1, v0}, LD/h;->b(LD/c;)V

    :cond_f
    iget-object v0, p0, LD/f;->e:[LD/c;

    iget v1, p0, LD/f;->i:I

    aput-object p1, v0, v1

    iget-object v0, p1, LD/c;->a:LD/i;

    iput v1, v0, LD/i;->b:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, LD/f;->i:I

    invoke-virtual {v0, p1}, LD/i;->e(LD/c;)V

    return-void
.end method

.method public static p(LE/e;)I
    .registers 2

    invoke-virtual {p0}, LE/e;->e()LD/i;

    move-result-object p0

    if-eqz p0, :cond_d

    iget p0, p0, LD/i;->d:F

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p0, v0

    float-to-int p0, p0

    return p0

    :cond_d
    const/4 p0, 0x0

    return p0
.end method

.method private q()V
    .registers 4

    iget v0, p0, LD/f;->c:I

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, LD/f;->c:I

    iget-object v1, p0, LD/f;->e:[LD/c;

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LD/c;

    iput-object v0, p0, LD/f;->e:[LD/c;

    iget-object v0, p0, LD/f;->k:LD/d;

    iget-object v1, v0, LD/d;->c:[LD/i;

    iget v2, p0, LD/f;->c:I

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [LD/i;

    iput-object v1, v0, LD/d;->c:[LD/i;

    iget v0, p0, LD/f;->c:I

    new-array v1, v0, [Z

    iput-object v1, p0, LD/f;->g:[Z

    iput v0, p0, LD/f;->d:I

    iput v0, p0, LD/f;->j:I

    return-void
.end method

.method private final t(LD/c;)V
    .registers 14

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_2
    iget v2, p0, LD/f;->h:I

    if-ge v1, v2, :cond_d

    iget-object v2, p0, LD/f;->g:[Z

    aput-boolean v0, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_d
    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_f
    if-nez v1, :cond_8d

    const/4 v3, 0x1

    add-int/2addr v2, v3

    iget v4, p0, LD/f;->h:I

    mul-int/lit8 v4, v4, 0x2

    if-lt v2, v4, :cond_1a

    return-void

    :cond_1a
    iget-object v4, p1, LD/c;->a:LD/i;

    if-eqz v4, :cond_24

    iget-object v5, p0, LD/f;->g:[Z

    iget v4, v4, LD/i;->a:I

    aput-boolean v3, v5, v4

    :cond_24
    iget-object v4, p0, LD/f;->g:[Z

    iget-object v5, p1, LD/c;->c:LD/b;

    const/4 v6, 0x0

    invoke-virtual {v5, v4, v6}, LD/b;->g([ZLD/i;)LD/i;

    move-result-object v4

    if-eqz v4, :cond_3a

    iget-object v5, p0, LD/f;->g:[Z

    iget v6, v4, LD/i;->a:I

    aget-boolean v7, v5, v6

    if-eqz v7, :cond_38

    return-void

    :cond_38
    aput-boolean v3, v5, v6

    :cond_3a
    if-eqz v4, :cond_8b

    const/4 v5, -0x1

    const v6, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v7, 0x0

    const/4 v8, -0x1

    :goto_42
    iget v9, p0, LD/f;->i:I

    if-ge v7, v9, :cond_76

    iget-object v9, p0, LD/f;->e:[LD/c;

    aget-object v9, v9, v7

    iget-object v10, v9, LD/c;->a:LD/i;

    iget-object v10, v10, LD/i;->f:LD/i$a;

    sget-object v11, LD/i$a;->UNRESTRICTED:LD/i$a;

    if-ne v10, v11, :cond_53

    goto :goto_73

    :cond_53
    iget-boolean v10, v9, LD/c;->d:Z

    if-eqz v10, :cond_58

    goto :goto_73

    :cond_58
    iget-object v10, v9, LD/c;->c:LD/b;

    invoke-virtual {v10, v4}, LD/b;->d(LD/i;)Z

    move-result v11

    if-eqz v11, :cond_73

    invoke-virtual {v10, v4}, LD/b;->f(LD/i;)F

    move-result v10

    const/4 v11, 0x0

    cmpg-float v11, v10, v11

    if-gez v11, :cond_73

    iget v9, v9, LD/c;->b:F

    neg-float v9, v9

    div-float/2addr v9, v10

    cmpg-float v10, v9, v6

    if-gez v10, :cond_73

    move v8, v7

    move v6, v9

    :cond_73
    :goto_73
    add-int/lit8 v7, v7, 0x1

    goto :goto_42

    :cond_76
    if-le v8, v5, :cond_8b

    iget-object v3, p0, LD/f;->e:[LD/c;

    aget-object v3, v3, v8

    iget-object v6, v3, LD/c;->a:LD/i;

    iput v5, v6, LD/i;->b:I

    invoke-virtual {v3, v4}, LD/c;->f(LD/i;)V

    iget-object v4, v3, LD/c;->a:LD/i;

    iput v8, v4, LD/i;->b:I

    invoke-virtual {v4, v3}, LD/i;->e(LD/c;)V

    goto :goto_f

    :cond_8b
    const/4 v1, 0x1

    goto :goto_f

    :cond_8d
    return-void
.end method


# virtual methods
.method public final b(LD/i;LD/i;IFLD/i;LD/i;II)V
    .registers 15

    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    const/high16 v1, 0x3f800000    # 1.0f

    iget-object v2, v0, LD/c;->c:LD/b;

    if-ne p2, p5, :cond_16

    invoke-virtual {v2, p1, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p6, v1}, LD/b;->k(LD/i;F)V

    const/high16 p1, -0x40000000    # -2.0f

    invoke-virtual {v2, p2, p1}, LD/b;->k(LD/i;F)V

    goto :goto_75

    :cond_16
    const/high16 v3, 0x3f000000    # 0.5f

    const/high16 v4, -0x40800000    # -1.0f

    cmpl-float v3, p4, v3

    if-nez v3, :cond_34

    invoke-virtual {v2, p1, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p2, v4}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p5, v4}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p6, v1}, LD/b;->k(LD/i;F)V

    if-gtz p3, :cond_2e

    if-lez p7, :cond_75

    :cond_2e
    neg-int p1, p3

    add-int/2addr p1, p7

    int-to-float p1, p1

    iput p1, v0, LD/c;->b:F

    goto :goto_75

    :cond_34
    const/4 v3, 0x0

    cmpg-float v3, p4, v3

    if-gtz v3, :cond_43

    invoke-virtual {v2, p1, v4}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p2, v1}, LD/b;->k(LD/i;F)V

    int-to-float p1, p3

    iput p1, v0, LD/c;->b:F

    goto :goto_75

    :cond_43
    cmpl-float v3, p4, v1

    if-ltz v3, :cond_51

    invoke-virtual {v2, p5, v4}, LD/b;->k(LD/i;F)V

    invoke-virtual {v2, p6, v1}, LD/b;->k(LD/i;F)V

    int-to-float p1, p7

    iput p1, v0, LD/c;->b:F

    goto :goto_75

    :cond_51
    sub-float v3, v1, p4

    mul-float v5, v3, v1

    invoke-virtual {v2, p1, v5}, LD/b;->k(LD/i;F)V

    mul-float p1, v3, v4

    invoke-virtual {v2, p2, p1}, LD/b;->k(LD/i;F)V

    mul-float v4, v4, p4

    invoke-virtual {v2, p5, v4}, LD/b;->k(LD/i;F)V

    mul-float v1, v1, p4

    invoke-virtual {v2, p6, v1}, LD/b;->k(LD/i;F)V

    if-gtz p3, :cond_6b

    if-lez p7, :cond_75

    :cond_6b
    neg-int p1, p3

    int-to-float p1, p1

    mul-float p1, p1, v3

    int-to-float p2, p7

    mul-float p2, p2, p4

    add-float/2addr p2, p1

    iput p2, v0, LD/c;->b:F

    :cond_75
    :goto_75
    const/4 p1, 0x6

    if-eq p8, p1, :cond_7b

    invoke-virtual {v0, p0, p8}, LD/c;->a(LD/f;I)V

    :cond_7b
    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    return-void
.end method

.method public final c(LD/c;)V
    .registers 12

    iget v0, p0, LD/f;->i:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iget v2, p0, LD/f;->j:I

    if-ge v0, v2, :cond_f

    iget v0, p0, LD/f;->h:I

    add-int/2addr v0, v1

    iget v2, p0, LD/f;->d:I

    if-lt v0, v2, :cond_12

    :cond_f
    invoke-direct {p0}, LD/f;->q()V

    :cond_12
    iget-boolean v0, p1, LD/c;->d:Z

    if-nez v0, :cond_da

    iget v0, p0, LD/f;->i:I

    iget-object v2, p1, LD/c;->c:LD/b;

    if-lez v0, :cond_27

    iget-object v0, p0, LD/f;->e:[LD/c;

    invoke-virtual {v2, p1, v0}, LD/b;->n(LD/c;[LD/c;)V

    iget v0, v2, LD/b;->a:I

    if-nez v0, :cond_27

    iput-boolean v1, p1, LD/c;->d:Z

    :cond_27
    iget-object v0, p1, LD/c;->a:LD/i;

    const/4 v3, 0x0

    if-nez v0, :cond_37

    iget v0, p1, LD/c;->b:F

    cmpl-float v0, v0, v3

    if-nez v0, :cond_37

    iget v0, v2, LD/b;->a:I

    if-nez v0, :cond_37

    return-void

    :cond_37
    iget v0, p1, LD/c;->b:F

    cmpg-float v4, v0, v3

    if-gez v4, :cond_46

    const/high16 v4, -0x40800000    # -1.0f

    mul-float v0, v0, v4

    iput v0, p1, LD/c;->b:F

    invoke-virtual {v2}, LD/b;->j()V

    :cond_46
    invoke-virtual {v2}, LD/b;->b()LD/i;

    move-result-object v0

    const/4 v4, 0x0

    if-nez v0, :cond_4f

    const/4 v0, 0x1

    goto :goto_53

    :cond_4f
    invoke-virtual {p1, v0}, LD/c;->f(LD/i;)V

    const/4 v0, 0x0

    :goto_53
    iget v5, v2, LD/b;->a:I

    if-nez v5, :cond_59

    iput-boolean v1, p1, LD/c;->d:Z

    :cond_59
    if-eqz v0, :cond_c5

    iget v0, p0, LD/f;->h:I

    add-int/2addr v0, v1

    iget v5, p0, LD/f;->d:I

    if-lt v0, v5, :cond_65

    invoke-direct {p0}, LD/f;->q()V

    :cond_65
    sget-object v0, LD/i$a;->SLACK:LD/i$a;

    invoke-direct {p0, v0}, LD/f;->a(LD/i$a;)LD/i;

    move-result-object v0

    iget v5, p0, LD/f;->a:I

    add-int/2addr v5, v1

    iput v5, p0, LD/f;->a:I

    iget v6, p0, LD/f;->h:I

    add-int/2addr v6, v1

    iput v6, p0, LD/f;->h:I

    iput v5, v0, LD/i;->a:I

    iget-object v6, p0, LD/f;->k:LD/d;

    iget-object v6, v6, LD/d;->c:[LD/i;

    aput-object v0, v6, v5

    iput-object v0, p1, LD/c;->a:LD/i;

    invoke-direct {p0, p1}, LD/f;->j(LD/c;)V

    iget-object v5, p0, LD/f;->n:LD/c;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, 0x0

    iput-object v6, v5, LD/c;->a:LD/i;

    iget-object v7, v5, LD/c;->c:LD/b;

    invoke-virtual {v7}, LD/b;->c()V

    :goto_8f
    iget v8, v2, LD/b;->a:I

    if-ge v4, v8, :cond_a1

    invoke-virtual {v2, v4}, LD/b;->h(I)LD/i;

    move-result-object v8

    invoke-virtual {v2, v4}, LD/b;->i(I)F

    move-result v9

    invoke-virtual {v7, v8, v9, v1}, LD/b;->a(LD/i;FZ)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_8f

    :cond_a1
    invoke-direct {p0, v5}, LD/f;->t(LD/c;)V

    iget v4, v0, LD/i;->b:I

    const/4 v5, -0x1

    if-ne v4, v5, :cond_c6

    iget-object v4, p1, LD/c;->a:LD/i;

    if-ne v4, v0, :cond_b6

    invoke-virtual {v2, v6, v0}, LD/b;->g([ZLD/i;)LD/i;

    move-result-object v0

    if-eqz v0, :cond_b6

    invoke-virtual {p1, v0}, LD/c;->f(LD/i;)V

    :cond_b6
    iget-boolean v0, p1, LD/c;->d:Z

    if-nez v0, :cond_bf

    iget-object v0, p1, LD/c;->a:LD/i;

    invoke-virtual {v0, p1}, LD/i;->e(LD/c;)V

    :cond_bf
    iget v0, p0, LD/f;->i:I

    sub-int/2addr v0, v1

    iput v0, p0, LD/f;->i:I

    goto :goto_c6

    :cond_c5
    const/4 v1, 0x0

    :cond_c6
    :goto_c6
    iget-object v0, p1, LD/c;->a:LD/i;

    if-eqz v0, :cond_d9

    iget-object v0, v0, LD/i;->f:LD/i$a;

    sget-object v2, LD/i$a;->UNRESTRICTED:LD/i$a;

    if-eq v0, v2, :cond_d6

    iget v0, p1, LD/c;->b:F

    cmpg-float v0, v0, v3

    if-ltz v0, :cond_d9

    :cond_d6
    if-nez v1, :cond_dd

    goto :goto_da

    :cond_d9
    return-void

    :cond_da
    :goto_da
    invoke-direct {p0, p1}, LD/f;->j(LD/c;)V

    :cond_dd
    return-void
.end method

.method public final d(LD/i;I)V
    .registers 7

    iget v0, p1, LD/i;->b:I

    const/4 v1, 0x1

    const/4 v2, -0x1

    if-eq v0, v2, :cond_3d

    iget-object v3, p0, LD/f;->e:[LD/c;

    aget-object v0, v3, v0

    iget-boolean v3, v0, LD/c;->d:Z

    if-eqz v3, :cond_12

    int-to-float p1, p2

    iput p1, v0, LD/c;->b:F

    goto :goto_4d

    :cond_12
    iget-object v3, v0, LD/c;->c:LD/b;

    iget v3, v3, LD/b;->a:I

    if-nez v3, :cond_1e

    iput-boolean v1, v0, LD/c;->d:Z

    int-to-float p1, p2

    iput p1, v0, LD/c;->b:F

    goto :goto_4d

    :cond_1e
    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    iget-object v1, v0, LD/c;->c:LD/b;

    if-gez p2, :cond_31

    mul-int/lit8 p2, p2, -0x1

    int-to-float p2, p2

    iput p2, v0, LD/c;->b:F

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-virtual {v1, p1, p2}, LD/b;->k(LD/i;F)V

    goto :goto_39

    :cond_31
    int-to-float p2, p2

    iput p2, v0, LD/c;->b:F

    const/high16 p2, -0x40800000    # -1.0f

    invoke-virtual {v1, p1, p2}, LD/b;->k(LD/i;F)V

    :goto_39
    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    goto :goto_4d

    :cond_3d
    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    iput-object p1, v0, LD/c;->a:LD/i;

    int-to-float p2, p2

    iput p2, p1, LD/i;->d:F

    iput p2, v0, LD/c;->b:F

    iput-boolean v1, v0, LD/c;->d:Z

    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    :goto_4d
    return-void
.end method

.method public final e(LD/i;LD/i;II)V
    .registers 10

    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    const/high16 v1, 0x3f800000    # 1.0f

    const/high16 v2, -0x40800000    # -1.0f

    iget-object v3, v0, LD/c;->c:LD/b;

    if-eqz p3, :cond_20

    if-gez p3, :cond_12

    mul-int/lit8 p3, p3, -0x1

    const/4 v4, 0x1

    goto :goto_13

    :cond_12
    const/4 v4, 0x0

    :goto_13
    int-to-float p3, p3

    iput p3, v0, LD/c;->b:F

    if-nez v4, :cond_19

    goto :goto_20

    :cond_19
    invoke-virtual {v3, p1, v1}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p2, v2}, LD/b;->k(LD/i;F)V

    goto :goto_26

    :cond_20
    :goto_20
    invoke-virtual {v3, p1, v2}, LD/b;->k(LD/i;F)V

    invoke-virtual {v3, p2, v1}, LD/b;->k(LD/i;F)V

    :goto_26
    const/4 p1, 0x6

    if-eq p4, p1, :cond_2c

    invoke-virtual {v0, p0, p4}, LD/c;->a(LD/f;I)V

    :cond_2c
    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    return-void
.end method

.method public final f(LD/i;LD/i;Z)V
    .registers 7

    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    invoke-virtual {p0}, LD/f;->n()LD/i;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, LD/i;->c:I

    invoke-virtual {v0, p1, p2, v1, v2}, LD/c;->c(LD/i;LD/i;LD/i;I)V

    if-eqz p3, :cond_24

    iget-object p1, v0, LD/c;->c:LD/b;

    invoke-virtual {p1, v1}, LD/b;->f(LD/i;)F

    move-result p2

    const/high16 p3, -0x40800000    # -1.0f

    mul-float p2, p2, p3

    float-to-int p2, p2

    const/4 p3, 0x1

    invoke-virtual {p0, p3}, LD/f;->k(I)LD/i;

    move-result-object p3

    int-to-float p2, p2

    invoke-virtual {p1, p3, p2}, LD/b;->k(LD/i;F)V

    :cond_24
    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    return-void
.end method

.method public final g(LD/i;LD/i;II)V
    .registers 8

    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    invoke-virtual {p0}, LD/f;->n()LD/i;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, LD/i;->c:I

    invoke-virtual {v0, p1, p2, v1, p3}, LD/c;->c(LD/i;LD/i;LD/i;I)V

    const/4 p1, 0x6

    if-eq p4, p1, :cond_24

    iget-object p1, v0, LD/c;->c:LD/b;

    invoke-virtual {p1, v1}, LD/b;->f(LD/i;)F

    move-result p2

    const/high16 p3, -0x40800000    # -1.0f

    mul-float p2, p2, p3

    float-to-int p2, p2

    invoke-virtual {p0, p4}, LD/f;->k(I)LD/i;

    move-result-object p3

    int-to-float p2, p2

    invoke-virtual {p1, p3, p2}, LD/b;->k(LD/i;F)V

    :cond_24
    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    return-void
.end method

.method public final h(LD/i;LD/i;Z)V
    .registers 7

    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    invoke-virtual {p0}, LD/f;->n()LD/i;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, LD/i;->c:I

    invoke-virtual {v0, p1, p2, v1, v2}, LD/c;->d(LD/i;LD/i;LD/i;I)V

    if-eqz p3, :cond_24

    iget-object p1, v0, LD/c;->c:LD/b;

    invoke-virtual {p1, v1}, LD/b;->f(LD/i;)F

    move-result p2

    const/high16 p3, -0x40800000    # -1.0f

    mul-float p2, p2, p3

    float-to-int p2, p2

    const/4 p3, 0x1

    invoke-virtual {p0, p3}, LD/f;->k(I)LD/i;

    move-result-object p3

    int-to-float p2, p2

    invoke-virtual {p1, p3, p2}, LD/b;->k(LD/i;F)V

    :cond_24
    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    return-void
.end method

.method public final i(LD/i;LD/i;II)V
    .registers 8

    invoke-virtual {p0}, LD/f;->m()LD/c;

    move-result-object v0

    invoke-virtual {p0}, LD/f;->n()LD/i;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, LD/i;->c:I

    invoke-virtual {v0, p1, p2, v1, p3}, LD/c;->d(LD/i;LD/i;LD/i;I)V

    const/4 p1, 0x6

    if-eq p4, p1, :cond_24

    iget-object p1, v0, LD/c;->c:LD/b;

    invoke-virtual {p1, v1}, LD/b;->f(LD/i;)F

    move-result p2

    const/high16 p3, -0x40800000    # -1.0f

    mul-float p2, p2, p3

    float-to-int p2, p2

    invoke-virtual {p0, p4}, LD/f;->k(I)LD/i;

    move-result-object p3

    int-to-float p2, p2

    invoke-virtual {p1, p3, p2}, LD/b;->k(LD/i;F)V

    :cond_24
    invoke-virtual {p0, v0}, LD/f;->c(LD/c;)V

    return-void
.end method

.method public final k(I)LD/i;
    .registers 5

    iget v0, p0, LD/f;->h:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, LD/f;->d:I

    if-lt v0, v1, :cond_b

    invoke-direct {p0}, LD/f;->q()V

    :cond_b
    sget-object v0, LD/i$a;->ERROR:LD/i$a;

    invoke-direct {p0, v0}, LD/f;->a(LD/i$a;)LD/i;

    move-result-object v0

    iget v1, p0, LD/f;->a:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, LD/f;->a:I

    iget v2, p0, LD/f;->h:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, LD/f;->h:I

    iput v1, v0, LD/i;->a:I

    iput p1, v0, LD/i;->c:I

    iget-object p1, p0, LD/f;->k:LD/d;

    iget-object p1, p1, LD/d;->c:[LD/i;

    aput-object v0, p1, v1

    iget-object p1, p0, LD/f;->b:LD/e;

    invoke-virtual {p1, v0}, LD/e;->g(LD/i;)V

    return-object v0
.end method

.method public final l(Ljava/lang/Object;)LD/i;
    .registers 6

    const/4 v0, 0x0

    if-nez p1, :cond_4

    return-object v0

    :cond_4
    iget v1, p0, LD/f;->h:I

    add-int/lit8 v1, v1, 0x1

    iget v2, p0, LD/f;->d:I

    if-lt v1, v2, :cond_f

    invoke-direct {p0}, LD/f;->q()V

    :cond_f
    instance-of v1, p1, LE/e;

    if-eqz v1, :cond_4f

    check-cast p1, LE/e;

    invoke-virtual {p1}, LE/e;->e()LD/i;

    move-result-object v0

    if-nez v0, :cond_23

    invoke-virtual {p1}, LE/e;->j()V

    invoke-virtual {p1}, LE/e;->e()LD/i;

    move-result-object p1

    move-object v0, p1

    :cond_23
    iget p1, v0, LD/i;->a:I

    iget-object v1, p0, LD/f;->k:LD/d;

    const/4 v2, -0x1

    if-eq p1, v2, :cond_34

    iget v3, p0, LD/f;->a:I

    if-gt p1, v3, :cond_34

    iget-object v3, v1, LD/d;->c:[LD/i;

    aget-object v3, v3, p1

    if-nez v3, :cond_4f

    :cond_34
    if-eq p1, v2, :cond_39

    invoke-virtual {v0}, LD/i;->d()V

    :cond_39
    iget p1, p0, LD/f;->a:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, LD/f;->a:I

    iget v2, p0, LD/f;->h:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, LD/f;->h:I

    iput p1, v0, LD/i;->a:I

    sget-object v2, LD/i$a;->UNRESTRICTED:LD/i$a;

    iput-object v2, v0, LD/i;->f:LD/i$a;

    iget-object v1, v1, LD/d;->c:[LD/i;

    aput-object v0, v1, p1

    :cond_4f
    return-object v0
.end method

.method public final m()LD/c;
    .registers 3

    iget-object v0, p0, LD/f;->k:LD/d;

    iget-object v1, v0, LD/d;->a:LD/h;

    invoke-virtual {v1}, LD/h;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LD/c;

    if-nez v1, :cond_12

    new-instance v1, LD/c;

    invoke-direct {v1, v0}, LD/c;-><init>(LD/d;)V

    goto :goto_20

    :cond_12
    const/4 v0, 0x0

    iput-object v0, v1, LD/c;->a:LD/i;

    iget-object v0, v1, LD/c;->c:LD/b;

    invoke-virtual {v0}, LD/b;->c()V

    const/4 v0, 0x0

    iput v0, v1, LD/c;->b:F

    const/4 v0, 0x0

    iput-boolean v0, v1, LD/c;->d:Z

    :goto_20
    return-object v1
.end method

.method public final n()LD/i;
    .registers 4

    iget v0, p0, LD/f;->h:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, LD/f;->d:I

    if-lt v0, v1, :cond_b

    invoke-direct {p0}, LD/f;->q()V

    :cond_b
    sget-object v0, LD/i$a;->SLACK:LD/i$a;

    invoke-direct {p0, v0}, LD/f;->a(LD/i$a;)LD/i;

    move-result-object v0

    iget v1, p0, LD/f;->a:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, LD/f;->a:I

    iget v2, p0, LD/f;->h:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, LD/f;->h:I

    iput v1, v0, LD/i;->a:I

    iget-object v2, p0, LD/f;->k:LD/d;

    iget-object v2, v2, LD/d;->c:[LD/i;

    aput-object v0, v2, v1

    return-object v0
.end method

.method public final o()LD/d;
    .registers 2

    iget-object v0, p0, LD/f;->k:LD/d;

    return-object v0
.end method

.method public final r()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    iget-boolean v0, p0, LD/f;->f:Z

    iget-object v1, p0, LD/f;->b:LD/e;

    if-eqz v0, :cond_2c

    const/4 v0, 0x0

    const/4 v2, 0x0

    :goto_8
    iget v3, p0, LD/f;->i:I

    if-ge v2, v3, :cond_1b

    iget-object v3, p0, LD/f;->e:[LD/c;

    aget-object v3, v3, v2

    iget-boolean v3, v3, LD/c;->d:Z

    if-nez v3, :cond_18

    invoke-virtual {p0, v1}, LD/f;->s(LD/e;)V

    goto :goto_2f

    :cond_18
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    :cond_1b
    :goto_1b
    iget v1, p0, LD/f;->i:I

    if-ge v0, v1, :cond_2f

    iget-object v1, p0, LD/f;->e:[LD/c;

    aget-object v1, v1, v0

    iget-object v2, v1, LD/c;->a:LD/i;

    iget v1, v1, LD/c;->b:F

    iput v1, v2, LD/i;->d:F

    add-int/lit8 v0, v0, 0x1

    goto :goto_1b

    :cond_2c
    invoke-virtual {p0, v1}, LD/f;->s(LD/e;)V

    :cond_2f
    :goto_2f
    return-void
.end method

.method final s(LD/e;)V
    .registers 20
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget v2, v0, LD/f;->i:I

    const/4 v3, 0x1

    if-lez v2, :cond_18

    iget-object v2, v1, LD/c;->c:LD/b;

    iget-object v4, v0, LD/f;->e:[LD/c;

    invoke-virtual {v2, v1, v4}, LD/b;->n(LD/c;[LD/c;)V

    iget-object v2, v1, LD/c;->c:LD/b;

    iget v2, v2, LD/b;->a:I

    if-nez v2, :cond_18

    iput-boolean v3, v1, LD/c;->d:Z

    :cond_18
    const/4 v4, 0x0

    :goto_19
    iget v5, v0, LD/f;->i:I

    if-ge v4, v5, :cond_bd

    iget-object v5, v0, LD/f;->e:[LD/c;

    aget-object v5, v5, v4

    iget-object v6, v5, LD/c;->a:LD/i;

    iget-object v6, v6, LD/i;->f:LD/i$a;

    sget-object v7, LD/i$a;->UNRESTRICTED:LD/i$a;

    if-ne v6, v7, :cond_2b

    goto/16 :goto_b8

    :cond_2b
    iget v5, v5, LD/c;->b:F

    const/4 v6, 0x0

    cmpg-float v5, v5, v6

    if-gez v5, :cond_b8

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_34
    if-nez v4, :cond_bd

    add-int/2addr v5, v3

    const v8, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v9, 0x0

    const/4 v10, -0x1

    const/4 v11, -0x1

    const/4 v12, 0x0

    :goto_3e
    iget v13, v0, LD/f;->i:I

    iget-object v14, v0, LD/f;->k:LD/d;

    if-ge v9, v13, :cond_92

    iget-object v13, v0, LD/f;->e:[LD/c;

    aget-object v13, v13, v9

    iget-object v15, v13, LD/c;->a:LD/i;

    iget-object v15, v15, LD/i;->f:LD/i$a;

    sget-object v2, LD/i$a;->UNRESTRICTED:LD/i$a;

    if-ne v15, v2, :cond_51

    goto :goto_8d

    :cond_51
    iget-boolean v2, v13, LD/c;->d:Z

    if-eqz v2, :cond_56

    goto :goto_8d

    :cond_56
    iget v2, v13, LD/c;->b:F

    cmpg-float v2, v2, v6

    if-gez v2, :cond_8d

    const/4 v2, 0x1

    :goto_5d
    iget v15, v0, LD/f;->h:I

    if-ge v2, v15, :cond_8d

    iget-object v15, v14, LD/d;->c:[LD/i;

    aget-object v15, v15, v2

    iget-object v3, v13, LD/c;->c:LD/b;

    invoke-virtual {v3, v15}, LD/b;->f(LD/i;)F

    move-result v3

    cmpg-float v16, v3, v6

    if-gtz v16, :cond_70

    goto :goto_88

    :cond_70
    const/4 v6, 0x0

    :goto_71
    const/4 v7, 0x7

    if-ge v6, v7, :cond_88

    iget-object v7, v15, LD/i;->e:[F

    aget v7, v7, v6

    div-float/2addr v7, v3

    cmpg-float v17, v7, v8

    if-gez v17, :cond_7f

    if-eq v6, v12, :cond_81

    :cond_7f
    if-le v6, v12, :cond_85

    :cond_81
    move v11, v2

    move v12, v6

    move v8, v7

    move v10, v9

    :cond_85
    add-int/lit8 v6, v6, 0x1

    goto :goto_71

    :cond_88
    :goto_88
    add-int/lit8 v2, v2, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x0

    goto :goto_5d

    :cond_8d
    :goto_8d
    add-int/lit8 v9, v9, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x0

    goto :goto_3e

    :cond_92
    const/4 v2, -0x1

    if-eq v10, v2, :cond_ac

    iget-object v3, v0, LD/f;->e:[LD/c;

    aget-object v3, v3, v10

    iget-object v6, v3, LD/c;->a:LD/i;

    iput v2, v6, LD/i;->b:I

    iget-object v2, v14, LD/d;->c:[LD/i;

    aget-object v2, v2, v11

    invoke-virtual {v3, v2}, LD/c;->f(LD/i;)V

    iget-object v2, v3, LD/c;->a:LD/i;

    iput v10, v2, LD/i;->b:I

    invoke-virtual {v2, v3}, LD/i;->e(LD/c;)V

    goto :goto_ad

    :cond_ac
    const/4 v4, 0x1

    :goto_ad
    iget v2, v0, LD/f;->h:I

    div-int/lit8 v2, v2, 0x2

    if-le v5, v2, :cond_b4

    const/4 v4, 0x1

    :cond_b4
    const/4 v3, 0x1

    const/4 v6, 0x0

    goto/16 :goto_34

    :cond_b8
    :goto_b8
    add-int/lit8 v4, v4, 0x1

    const/4 v3, 0x1

    goto/16 :goto_19

    :cond_bd
    invoke-direct/range {p0 .. p1}, LD/f;->t(LD/c;)V

    const/4 v2, 0x0

    :goto_c1
    iget v1, v0, LD/f;->i:I

    if-ge v2, v1, :cond_d2

    iget-object v1, v0, LD/f;->e:[LD/c;

    aget-object v1, v1, v2

    iget-object v3, v1, LD/c;->a:LD/i;

    iget v1, v1, LD/c;->b:F

    iput v1, v3, LD/i;->d:F

    add-int/lit8 v2, v2, 0x1

    goto :goto_c1

    :cond_d2
    return-void
.end method

.method public final u()V
    .registers 7

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_2
    iget-object v2, p0, LD/f;->k:LD/d;

    iget-object v3, v2, LD/d;->c:[LD/i;

    array-length v4, v3

    if-ge v1, v4, :cond_13

    aget-object v2, v3, v1

    if-eqz v2, :cond_10

    invoke-virtual {v2}, LD/i;->d()V

    :cond_10
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_13
    iget-object v1, v2, LD/d;->b:LD/h;

    iget-object v3, p0, LD/f;->l:[LD/i;

    iget v4, p0, LD/f;->m:I

    invoke-virtual {v1, v4, v3}, LD/h;->c(I[Ljava/lang/Object;)V

    iput v0, p0, LD/f;->m:I

    iget-object v1, v2, LD/d;->c:[LD/i;

    const/4 v3, 0x0

    invoke-static {v1, v3}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    iput v0, p0, LD/f;->a:I

    iget-object v1, p0, LD/f;->b:LD/e;

    iget-object v4, v1, LD/c;->c:LD/b;

    invoke-virtual {v4}, LD/b;->c()V

    iput-object v3, v1, LD/c;->a:LD/i;

    const/4 v4, 0x0

    iput v4, v1, LD/c;->b:F

    const/4 v1, 0x1

    iput v1, p0, LD/f;->h:I

    const/4 v1, 0x0

    :goto_36
    iget v4, p0, LD/f;->i:I

    if-ge v1, v4, :cond_44

    iget-object v4, p0, LD/f;->e:[LD/c;

    aget-object v4, v4, v1

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v1, v1, 0x1

    goto :goto_36

    :cond_44
    const/4 v1, 0x0

    :goto_45
    iget-object v4, p0, LD/f;->e:[LD/c;

    array-length v5, v4

    if-ge v1, v5, :cond_5a

    aget-object v4, v4, v1

    if-eqz v4, :cond_53

    iget-object v5, v2, LD/d;->a:LD/h;

    invoke-virtual {v5, v4}, LD/h;->b(LD/c;)V

    :cond_53
    iget-object v4, p0, LD/f;->e:[LD/c;

    aput-object v3, v4, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_45

    :cond_5a
    iput v0, p0, LD/f;->i:I

    return-void
.end method
