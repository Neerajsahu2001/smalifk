.class public final enum LD/i$a;
.super Ljava/lang/Enum;
.source "SolverVariable.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LD/i$a;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LD/i$a;

.field public static final enum CONSTANT:LD/i$a;

.field public static final enum ERROR:LD/i$a;

.field public static final enum SLACK:LD/i$a;

.field public static final enum UNKNOWN:LD/i$a;

.field public static final enum UNRESTRICTED:LD/i$a;


# direct methods
.method static constructor <clinit>()V
    .registers 11

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v5, LD/i$a;

    const-string v6, "UNRESTRICTED"

    invoke-direct {v5, v6, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LD/i$a;->UNRESTRICTED:LD/i$a;

    new-instance v6, LD/i$a;

    const-string v7, "CONSTANT"

    invoke-direct {v6, v7, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, LD/i$a;->CONSTANT:LD/i$a;

    new-instance v7, LD/i$a;

    const-string v8, "SLACK"

    invoke-direct {v7, v8, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, LD/i$a;->SLACK:LD/i$a;

    new-instance v8, LD/i$a;

    const-string v9, "ERROR"

    invoke-direct {v8, v9, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, LD/i$a;->ERROR:LD/i$a;

    new-instance v9, LD/i$a;

    const-string v10, "UNKNOWN"

    invoke-direct {v9, v10, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, LD/i$a;->UNKNOWN:LD/i$a;

    const/4 v10, 0x5

    new-array v10, v10, [LD/i$a;

    aput-object v5, v10, v4

    aput-object v6, v10, v3

    aput-object v7, v10, v2

    aput-object v8, v10, v1

    aput-object v9, v10, v0

    sput-object v10, LD/i$a;->$VALUES:[LD/i$a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)LD/i$a;
    .registers 2

    const-class v0, LD/i$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LD/i$a;

    return-object p0
.end method

.method public static values()[LD/i$a;
    .registers 1

    sget-object v0, LD/i$a;->$VALUES:[LD/i$a;

    invoke-virtual {v0}, [LD/i$a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LD/i$a;

    return-object v0
.end method
