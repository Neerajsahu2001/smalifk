.class public final Le3/g;
.super Ljava/lang/Object;
.source "LocaleObjectAndroid.java"

# interfaces
.implements Le3/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Le3/b<",
        "Ljava/util/Locale;",
        ">;"
    }
.end annotation


# instance fields
.field private a:Ljava/util/Locale;

.field private b:Le3/m;

.field private c:Z


# direct methods
.method private constructor <init>(Ljava/util/Locale;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Le3/g;->b:Le3/m;

    const/4 v0, 0x0

    iput-boolean v0, p0, Le3/g;->c:Z

    iput-object p1, p0, Le3/g;->a:Ljava/util/Locale;

    return-void
.end method

.method public static h()Le3/g;
    .registers 2

    new-instance v0, Le3/g;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-direct {v0, v1}, Le3/g;-><init>(Ljava/util/Locale;)V

    return-object v0
.end method

.method public static i(Ljava/lang/String;)Le3/g;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    new-instance v0, Le3/g;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object v1, v0, Le3/g;->a:Ljava/util/Locale;

    iput-object v1, v0, Le3/g;->b:Le3/m;

    const/4 v1, 0x0

    iput-boolean v1, v0, Le3/g;->c:Z

    invoke-static {p0}, Le3/e;->d(Ljava/lang/String;)Le3/m;

    move-result-object p0

    iput-object p0, v0, Le3/g;->b:Le3/m;

    invoke-direct {v0}, Le3/g;->m()V

    return-object v0
.end method

.method private j()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    iget-boolean v0, p0, Le3/g;->c:Z

    if-eqz v0, :cond_16

    :try_start_4
    invoke-direct {p0}, Le3/g;->m()V
    :try_end_7
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_7} :catch_b

    const/4 v0, 0x0

    iput-boolean v0, p0, Le3/g;->c:Z

    goto :goto_16

    :catch_b
    move-exception v0

    new-instance v1, Le3/c;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_16
    :goto_16
    return-void
.end method

.method private m()V
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v3, Ljava/lang/StringBuffer;

    invoke-direct {v3}, Ljava/lang/StringBuffer;-><init>()V

    iget-object v4, p0, Le3/g;->b:Le3/m;

    iget-object v4, v4, Le3/m;->a:Le3/m$a;

    iget-object v4, v4, Le3/m$a;->a:Ljava/lang/String;

    if-eqz v4, :cond_2b

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_2b

    iget-object v4, p0, Le3/g;->b:Le3/m;

    iget-object v4, v4, Le3/m;->a:Le3/m$a;

    iget-object v4, v4, Le3/m$a;->a:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_2b
    iget-object v4, p0, Le3/g;->b:Le3/m;

    iget-object v4, v4, Le3/m;->a:Le3/m$a;

    iget-object v4, v4, Le3/m$a;->b:Ljava/lang/String;

    if-eqz v4, :cond_42

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_42

    iget-object v4, p0, Le3/g;->b:Le3/m;

    iget-object v4, v4, Le3/m;->a:Le3/m$a;

    iget-object v4, v4, Le3/m$a;->b:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_42
    iget-object v4, p0, Le3/g;->b:Le3/m;

    iget-object v4, v4, Le3/m;->a:Le3/m$a;

    iget-object v4, v4, Le3/m$a;->c:Ljava/lang/String;

    if-eqz v4, :cond_59

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_59

    iget-object v4, p0, Le3/g;->b:Le3/m;

    iget-object v4, v4, Le3/m;->a:Le3/m$a;

    iget-object v4, v4, Le3/m$a;->c:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_59
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->length()I

    move-result v4

    if-lez v4, :cond_66

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_66
    invoke-virtual {v2}, Ljava/lang/StringBuffer;->length()I

    move-result v1

    const-string v4, "-"

    if-lez v1, :cond_78

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_78
    invoke-virtual {v3}, Ljava/lang/StringBuffer;->length()I

    move-result v1

    if-lez v1, :cond_88

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_88
    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v1, v1, Le3/m;->a:Le3/m$a;

    iget-object v1, v1, Le3/m$a;->d:Ljava/util/ArrayList;

    if-eqz v1, :cond_a6

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_a6

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v1, v1, Le3/m;->a:Le3/m$a;

    iget-object v1, v1, Le3/m$a;->d:Ljava/util/ArrayList;

    invoke-static {v4, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_a6
    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v1, v1, Le3/m;->f:Ljava/util/TreeMap;

    if-eqz v1, :cond_db

    invoke-virtual {v1}, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_b4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_db

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v4, v2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_b4

    :cond_db
    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v2, v1, Le3/m;->d:Le3/m$a;

    const/16 v3, 0x2d

    const/4 v5, 0x0

    if-nez v2, :cond_e8

    iget-object v1, v1, Le3/m;->e:Ljava/util/TreeMap;

    if-eqz v1, :cond_1ae

    :cond_e8
    const-string v1, "-t-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->d:Le3/m$a;

    if-eqz v2, :cond_143

    iget-object v2, v2, Le3/m$a;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->d:Le3/m$a;

    iget-object v2, v2, Le3/m$a;->b:Ljava/lang/String;

    if-eqz v2, :cond_111

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->d:Le3/m$a;

    iget-object v2, v2, Le3/m$a;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_111
    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->d:Le3/m$a;

    iget-object v2, v2, Le3/m$a;->c:Ljava/lang/String;

    if-eqz v2, :cond_125

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->d:Le3/m$a;

    iget-object v2, v2, Le3/m$a;->c:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_125
    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->d:Le3/m$a;

    iget-object v2, v2, Le3/m$a;->d:Ljava/util/ArrayList;

    if-eqz v2, :cond_143

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_143

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->d:Le3/m$a;

    iget-object v2, v2, Le3/m$a;->d:Ljava/util/ArrayList;

    invoke-static {v4, v2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_143
    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->e:Ljava/util/TreeMap;

    if-eqz v2, :cond_1a7

    invoke-virtual {v2}, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_151
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_198

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map$Entry;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/ArrayList;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_17c
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_151

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_17c

    :cond_198
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->length()I

    move-result v2

    if-lez v2, :cond_1a7

    invoke-virtual {v1, v5}, Ljava/lang/StringBuffer;->charAt(I)C

    move-result v2

    if-ne v2, v3, :cond_1a7

    invoke-virtual {v1, v5}, Ljava/lang/StringBuffer;->deleteCharAt(I)Ljava/lang/StringBuffer;

    :cond_1a7
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_1ae
    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v2, v1, Le3/m;->b:Ljava/util/ArrayList;

    if-nez v2, :cond_1b8

    iget-object v1, v1, Le3/m;->c:Ljava/util/TreeMap;

    if-eqz v1, :cond_23a

    :cond_1b8
    const-string v1, "-u-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->b:Ljava/util/ArrayList;

    if-eqz v2, :cond_1cf

    invoke-static {v4, v2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_1cf
    iget-object v2, p0, Le3/g;->b:Le3/m;

    iget-object v2, v2, Le3/m;->c:Ljava/util/TreeMap;

    if-eqz v2, :cond_224

    invoke-virtual {v2}, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1dd
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_224

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map$Entry;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/ArrayList;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_208
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1dd

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_208

    :cond_224
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->length()I

    move-result v2

    if-lez v2, :cond_233

    invoke-virtual {v1, v5}, Ljava/lang/StringBuffer;->charAt(I)C

    move-result v2

    if-ne v2, v3, :cond_233

    invoke-virtual {v1, v5}, Ljava/lang/StringBuffer;->deleteCharAt(I)Ljava/lang/StringBuffer;

    :cond_233
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_23a
    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v1, v1, Le3/m;->g:Ljava/util/ArrayList;

    if-eqz v1, :cond_250

    const-string v1, "-x-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v1, v1, Le3/m;->g:Ljava/util/ArrayList;

    invoke-static {v4, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_250
    :try_start_250
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    iput-object v0, p0, Le3/g;->a:Ljava/util/Locale;
    :try_end_25a
    .catch Ljava/lang/RuntimeException; {:try_start_250 .. :try_end_25a} :catch_25d

    iput-boolean v5, p0, Le3/g;->c:Z

    return-void

    :catch_25d
    move-exception v0

    new-instance v1, Le3/c;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1
.end method


# virtual methods
.method public final a()Ljava/util/ArrayList;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/g;->j()V

    iget-object v0, p0, Le3/g;->b:Le3/m;

    if-nez v0, :cond_13

    iget-object v0, p0, Le3/g;->a:Ljava/util/Locale;

    invoke-virtual {v0}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le3/e;->d(Ljava/lang/String;)Le3/m;

    move-result-object v0

    iput-object v0, p0, Le3/g;->b:Le3/m;

    :cond_13
    iget-object v0, p0, Le3/g;->b:Le3/m;

    iget-object v0, v0, Le3/m;->c:Ljava/util/TreeMap;

    if-eqz v0, :cond_24

    const-string v1, "collation"

    invoke-virtual {v0, v1}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    if-eqz v0, :cond_24

    return-object v0

    :cond_24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method

.method public final a()Ljava/util/HashMap;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v1, v1, Le3/m;->c:Ljava/util/TreeMap;

    if-eqz v1, :cond_33

    invoke-virtual {v1}, Ljava/util/TreeMap;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_33

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v3, p0, Le3/g;->b:Le3/m;

    iget-object v3, v3, Le3/m;->c:Ljava/util/TreeMap;

    invoke-virtual {v3, v2}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/ArrayList;

    const-string v4, "-"

    invoke-static {v4, v3}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_13

    :cond_33
    return-object v0
.end method

.method public final bridge synthetic b()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-virtual {p0}, Le3/g;->l()Ljava/util/Locale;

    move-result-object v0

    return-object v0
.end method

.method public final c()Le3/b;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Le3/b<",
            "Ljava/util/Locale;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/g;->j()V

    new-instance v0, Le3/g;

    iget-object v1, p0, Le3/g;->a:Ljava/util/Locale;

    invoke-direct {v0, v1}, Le3/g;-><init>(Ljava/util/Locale;)V

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-virtual {p0}, Le3/g;->l()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final e(Ljava/lang/String;Ljava/util/ArrayList;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/g;->j()V

    iget-object v0, p0, Le3/g;->b:Le3/m;

    if-nez v0, :cond_13

    iget-object v0, p0, Le3/g;->a:Ljava/util/Locale;

    invoke-virtual {v0}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le3/e;->d(Ljava/lang/String;)Le3/m;

    move-result-object v0

    iput-object v0, p0, Le3/g;->b:Le3/m;

    :cond_13
    iget-object v0, p0, Le3/g;->b:Le3/m;

    iget-object v1, v0, Le3/m;->c:Ljava/util/TreeMap;

    if-nez v1, :cond_20

    new-instance v1, Ljava/util/TreeMap;

    invoke-direct {v1}, Ljava/util/TreeMap;-><init>()V

    iput-object v1, v0, Le3/m;->c:Ljava/util/TreeMap;

    :cond_20
    iget-object v0, p0, Le3/g;->b:Le3/m;

    iget-object v0, v0, Le3/m;->c:Ljava/util/TreeMap;

    invoke-virtual {v0, p1}, Ljava/util/TreeMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_36

    iget-object v0, p0, Le3/g;->b:Le3/m;

    iget-object v0, v0, Le3/m;->c:Ljava/util/TreeMap;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, p1, v1}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_36
    iget-object v0, p0, Le3/g;->b:Le3/m;

    iget-object v0, v0, Le3/m;->c:Ljava/util/TreeMap;

    invoke-virtual {v0, p1}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Le3/g;->b:Le3/m;

    iget-object v0, v0, Le3/m;->c:Ljava/util/TreeMap;

    invoke-virtual {v0, p1}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 p1, 0x1

    iput-boolean p1, p0, Le3/g;->c:Z

    return-void
.end method

.method public final f()Ljava/lang/String;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/g;->j()V

    iget-object v0, p0, Le3/g;->a:Ljava/util/Locale;

    invoke-virtual {v0}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final g()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/g;->j()V

    iget-object v0, p0, Le3/g;->a:Ljava/util/Locale;

    return-object v0
.end method

.method public final k()Ljava/util/Locale;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/g;->j()V

    iget-object v0, p0, Le3/g;->a:Ljava/util/Locale;

    return-object v0
.end method

.method public final l()Ljava/util/Locale;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/g;->j()V

    iget-object v0, p0, Le3/g;->b:Le3/m;

    if-nez v0, :cond_13

    iget-object v0, p0, Le3/g;->a:Ljava/util/Locale;

    invoke-virtual {v0}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le3/e;->d(Ljava/lang/String;)Le3/m;

    move-result-object v0

    iput-object v0, p0, Le3/g;->b:Le3/m;

    :cond_13
    new-instance v0, Le3/m;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iget-object v1, p0, Le3/g;->b:Le3/m;

    iget-object v1, v1, Le3/m;->a:Le3/m$a;

    iput-object v1, v0, Le3/m;->a:Le3/m$a;

    new-instance v1, Le3/g;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    iput-object v2, v1, Le3/g;->a:Ljava/util/Locale;

    const/4 v2, 0x0

    iput-boolean v2, v1, Le3/g;->c:Z

    iput-object v0, v1, Le3/g;->b:Le3/m;

    invoke-direct {v1}, Le3/g;->m()V

    invoke-direct {v1}, Le3/g;->j()V

    iget-object v0, v1, Le3/g;->a:Ljava/util/Locale;

    return-object v0
.end method
