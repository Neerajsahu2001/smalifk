.class public final synthetic Le3/h;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static bridge synthetic a()Landroid/icu/text/DateFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/DateFormat$Field;->ERA:Landroid/icu/text/DateFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic b()Landroid/icu/text/NumberFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/NumberFormat$Field;->EXPONENT_SIGN:Landroid/icu/text/NumberFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic c(Landroid/icu/util/ULocale$Category;)Landroid/icu/util/ULocale;
    .registers 1

    invoke-static {p0}, Landroid/icu/util/ULocale;->getDefault(Landroid/icu/util/ULocale$Category;)Landroid/icu/util/ULocale;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic d(Landroid/icu/text/NumberFormat;I)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/icu/text/NumberFormat;->setMaximumFractionDigits(I)V

    return-void
.end method
