.class public final Le3/d$a;
.super Ljava/lang/Object;
.source "LocaleIdentifier.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le3/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field private a:Ljava/lang/CharSequence;

.field private b:I

.field private c:I


# direct methods
.method constructor <init>(Ljava/lang/CharSequence;II)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    iput p2, p0, Le3/d$a;->b:I

    iput p3, p0, Le3/d$a;->c:I

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 5

    const/4 v0, 0x1

    iget v1, p0, Le3/d$a;->b:I

    iget v2, p0, Le3/d$a;->c:I

    iget-object v3, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-static {v1, v2, v3, v0, v0}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    return v0
.end method

.method public final b()Z
    .registers 6

    const/4 v0, 0x2

    const/16 v1, 0x8

    iget v2, p0, Le3/d$a;->b:I

    iget v3, p0, Le3/d$a;->c:I

    iget-object v4, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-static {v2, v3, v4, v0, v1}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    return v0
.end method

.method public final c()Z
    .registers 6

    const/4 v0, 0x1

    const/16 v1, 0x8

    iget v2, p0, Le3/d$a;->b:I

    iget v3, p0, Le3/d$a;->c:I

    iget-object v4, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-static {v2, v3, v4, v0, v1}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    return v0
.end method

.method public final d()Z
    .registers 5

    iget v0, p0, Le3/d$a;->b:I

    add-int/lit8 v1, v0, 0x1

    iget v2, p0, Le3/d$a;->c:I

    const/4 v3, 0x0

    if-eq v2, v1, :cond_a

    goto :goto_23

    :cond_a
    iget-object v1, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-interface {v1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    invoke-static {v0}, Lc2/a;->c(C)Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-interface {v1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/16 v1, 0x30

    if-lt v0, v1, :cond_23

    const/16 v1, 0x39

    if-gt v0, v1, :cond_23

    const/4 v3, 0x1

    :cond_23
    :goto_23
    return v3
.end method

.method public final e()Z
    .registers 6

    const/4 v0, 0x3

    const/16 v1, 0x8

    iget v2, p0, Le3/d$a;->b:I

    iget v3, p0, Le3/d$a;->c:I

    iget-object v4, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-static {v2, v3, v4, v0, v1}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    return v0
.end method

.method public final f()Z
    .registers 6

    const/4 v0, 0x3

    const/16 v1, 0x8

    iget v2, p0, Le3/d$a;->b:I

    iget v3, p0, Le3/d$a;->c:I

    iget-object v4, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-static {v2, v3, v4, v0, v1}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    return v0
.end method

.method public final g()Z
    .registers 6

    iget v0, p0, Le3/d$a;->b:I

    add-int/lit8 v1, v0, 0x1

    iget v2, p0, Le3/d$a;->c:I

    const/4 v3, 0x0

    if-eq v2, v1, :cond_a

    goto :goto_29

    :cond_a
    iget-object v1, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-interface {v1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    invoke-static {v0}, Lc2/a;->c(C)Z

    move-result v4

    if-nez v4, :cond_1e

    const/16 v4, 0x30

    if-lt v0, v4, :cond_29

    const/16 v4, 0x39

    if-gt v0, v4, :cond_29

    :cond_1e
    invoke-interface {v1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    invoke-static {v0}, Lc2/a;->c(C)Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v3, 0x1

    :cond_29
    :goto_29
    return v3
.end method

.method public final h()Z
    .registers 6

    iget v0, p0, Le3/d$a;->b:I

    iget v1, p0, Le3/d$a;->c:I

    iget-object v2, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/16 v4, 0x8

    invoke-static {v0, v1, v2, v3, v4}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    return v0
.end method

.method public final i()Z
    .registers 8

    iget v0, p0, Le3/d$a;->b:I

    iget v1, p0, Le3/d$a;->c:I

    iget-object v2, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1, v2, v3, v4}, Lc2/a;->d(IILjava/lang/CharSequence;II)Z

    move-result v3

    const/4 v5, 0x1

    if-nez v3, :cond_42

    const/4 v3, 0x5

    const/16 v6, 0x8

    invoke-static {v0, v1, v2, v3, v6}, Lc2/a;->d(IILjava/lang/CharSequence;II)Z

    move-result v3

    if-nez v3, :cond_42

    sub-int/2addr v1, v0

    add-int/2addr v1, v5

    const/4 v3, 0x4

    if-ne v1, v3, :cond_41

    invoke-interface {v2, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v1

    const/16 v3, 0x72

    if-ne v1, v3, :cond_41

    add-int/lit8 v1, v0, 0x1

    invoke-interface {v2, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v1

    const/16 v3, 0x6f

    if-ne v1, v3, :cond_41

    add-int/lit8 v1, v0, 0x2

    invoke-interface {v2, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v1

    if-ne v1, v3, :cond_41

    add-int/2addr v0, v4

    invoke-interface {v2, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/16 v1, 0x74

    if-ne v0, v1, :cond_41

    goto :goto_42

    :cond_41
    const/4 v5, 0x0

    :cond_42
    :goto_42
    return v5
.end method

.method public final j()Z
    .registers 7

    iget v0, p0, Le3/d$a;->b:I

    iget v1, p0, Le3/d$a;->c:I

    iget-object v2, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    const/4 v3, 0x2

    invoke-static {v0, v1, v2, v3, v3}, Lc2/a;->d(IILjava/lang/CharSequence;II)Z

    move-result v3

    const/4 v4, 0x1

    if-nez v3, :cond_30

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lt v1, v3, :cond_15

    goto :goto_2f

    :cond_15
    sub-int v3, v1, v0

    add-int/2addr v3, v4

    const/4 v5, 0x3

    if-lt v3, v5, :cond_2f

    if-le v3, v5, :cond_1e

    goto :goto_2f

    :cond_1e
    :goto_1e
    if-gt v0, v1, :cond_30

    invoke-interface {v2, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/16 v5, 0x30

    if-lt v3, v5, :cond_2f

    const/16 v5, 0x39

    if-gt v3, v5, :cond_2f

    add-int/lit8 v0, v0, 0x1

    goto :goto_1e

    :cond_2f
    :goto_2f
    const/4 v4, 0x0

    :cond_30
    return v4
.end method

.method public final k()Z
    .registers 5

    const/4 v0, 0x4

    iget v1, p0, Le3/d$a;->b:I

    iget v2, p0, Le3/d$a;->c:I

    iget-object v3, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-static {v1, v2, v3, v0, v0}, Lc2/a;->d(IILjava/lang/CharSequence;II)Z

    move-result v0

    return v0
.end method

.method public final l()Z
    .registers 7

    const/4 v0, 0x5

    const/16 v1, 0x8

    iget v2, p0, Le3/d$a;->b:I

    iget v3, p0, Le3/d$a;->c:I

    iget-object v4, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-static {v2, v3, v4, v0, v1}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_2a

    sub-int v0, v3, v2

    add-int/2addr v0, v1

    const/4 v5, 0x4

    if-ne v0, v5, :cond_29

    invoke-interface {v4, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    invoke-static {v0}, Lc2/a;->c(C)Z

    move-result v0

    if-eqz v0, :cond_29

    add-int/2addr v2, v1

    const/4 v0, 0x3

    invoke-static {v2, v3, v4, v0, v0}, Lc2/a;->e(IILjava/lang/CharSequence;II)Z

    move-result v0

    if-eqz v0, :cond_29

    goto :goto_2a

    :cond_29
    const/4 v1, 0x0

    :cond_2a
    :goto_2a
    return v1
.end method

.method public final m()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    iget v1, p0, Le3/d$a;->b:I

    :goto_7
    iget v2, p0, Le3/d$a;->c:I

    if-gt v1, v2, :cond_1b

    iget-object v2, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-interface {v2, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_1b
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final n()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    iget v1, p0, Le3/d$a;->b:I

    move v2, v1

    :goto_8
    iget v3, p0, Le3/d$a;->c:I

    if-gt v2, v3, :cond_2a

    iget-object v3, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    if-ne v2, v1, :cond_1c

    invoke-interface {v3, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->toUpperCase(C)C

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    goto :goto_27

    :cond_1c
    invoke-interface {v3, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :goto_27
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    :cond_2a
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final o()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    iget v1, p0, Le3/d$a;->b:I

    :goto_7
    iget v2, p0, Le3/d$a;->c:I

    if-gt v1, v2, :cond_1b

    iget-object v2, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    invoke-interface {v2, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->toUpperCase(C)C

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_1b
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    iget v0, p0, Le3/d$a;->c:I

    add-int/lit8 v0, v0, 0x1

    iget-object v1, p0, Le3/d$a;->a:Ljava/lang/CharSequence;

    iget v2, p0, Le3/d$a;->b:I

    invoke-interface {v1, v2, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
