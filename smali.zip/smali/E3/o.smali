.class public final synthetic Le3/o;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static bridge synthetic a()Landroid/icu/text/CompactDecimalFormat$CompactStyle;
    .registers 1

    sget-object v0, Landroid/icu/text/CompactDecimalFormat$CompactStyle;->SHORT:Landroid/icu/text/CompactDecimalFormat$CompactStyle;

    return-object v0
.end method

.method public static bridge synthetic b(Ljava/lang/Object;)Ljava/util/Optional;
    .registers 1

    invoke-static {p0}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic c(Landroid/icu/text/DecimalFormat;Ljava/lang/String;)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/icu/text/DecimalFormat;->setPositiveSuffix(Ljava/lang/String;)V

    return-void
.end method

.method public static bridge synthetic d(Landroid/icu/text/RuleBasedCollator;)V
    .registers 2

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/icu/text/RuleBasedCollator;->setCaseLevel(Z)V

    return-void
.end method

.method public static bridge synthetic e(Landroid/media/AudioTrack;Landroid/media/AudioRouting$OnRoutingChangedListener;)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/media/AudioTrack;->removeOnRoutingChangedListener(Landroid/media/AudioRouting$OnRoutingChangedListener;)V

    return-void
.end method
