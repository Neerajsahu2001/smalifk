.class public final synthetic Le3/j;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static bridge synthetic a()Landroid/icu/text/DateFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/DateFormat$Field;->DAY_OF_MONTH:Landroid/icu/text/DateFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic b()Landroid/icu/text/NumberFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/NumberFormat$Field;->GROUPING_SEPARATOR:Landroid/icu/text/NumberFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic c(Landroid/icu/util/ULocale;)Ljava/lang/String;
    .registers 1

    invoke-virtual {p0}, Landroid/icu/util/ULocale;->toLanguageTag()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic d(Landroid/icu/text/DecimalFormat;)V
    .registers 2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/icu/text/DecimalFormat;->setSignificantDigitsUsed(Z)V

    return-void
.end method

.method public static bridge synthetic e(Landroid/view/Window$Callback;Ljava/util/List;Landroid/view/Menu;I)V
    .registers 4

    invoke-interface {p0, p1, p2, p3}, Landroid/view/Window$Callback;->onProvideKeyboardShortcuts(Ljava/util/List;Landroid/view/Menu;I)V

    return-void
.end method

.method public static bridge synthetic f(Landroid/app/job/JobParameters;)[Landroid/net/Uri;
    .registers 1

    invoke-virtual {p0}, Landroid/app/job/JobParameters;->getTriggeredContentUris()[Landroid/net/Uri;

    move-result-object p0

    return-object p0
.end method
