.class public final Le3/f;
.super Ljava/lang/Object;
.source "LocaleObject.java"


# direct methods
.method public static a(Ljava/lang/String;)Le3/b;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-lt v0, v1, :cond_b

    invoke-static {p0}, Le3/l;->i(Ljava/lang/String;)Le3/l;

    move-result-object p0

    return-object p0

    :cond_b
    invoke-static {p0}, Le3/g;->i(Ljava/lang/String;)Le3/g;

    move-result-object p0

    return-object p0
.end method
