.class public final synthetic Le3/k;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static bridge synthetic a()Landroid/icu/text/DateFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/DateFormat$Field;->HOUR1:Landroid/icu/text/DateFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic b()Landroid/icu/text/NumberFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/NumberFormat$Field;->PERCENT:Landroid/icu/text/NumberFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic c(Landroid/icu/util/ULocale$Builder;Landroid/icu/util/ULocale;)Landroid/icu/util/ULocale$Builder;
    .registers 2

    invoke-virtual {p0, p1}, Landroid/icu/util/ULocale$Builder;->setLocale(Landroid/icu/util/ULocale;)Landroid/icu/util/ULocale$Builder;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic d()Landroid/media/MediaCodec$CryptoInfo$Pattern;
    .registers 2

    new-instance v0, Landroid/media/MediaCodec$CryptoInfo$Pattern;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1}, Landroid/media/MediaCodec$CryptoInfo$Pattern;-><init>(II)V

    return-object v0
.end method

.method public static bridge synthetic e(Ljava/util/stream/Stream;)Ljava/util/Optional;
    .registers 1

    invoke-interface {p0}, Ljava/util/stream/Stream;->findAny()Ljava/util/Optional;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic f(Landroid/icu/util/ULocale;)[Ljava/lang/String;
    .registers 3

    const-string v0, "ca"

    const/4 v1, 0x0

    invoke-static {v0, p0, v1}, Landroid/icu/util/Calendar;->getKeywordValuesForLocale(Ljava/lang/String;Landroid/icu/util/ULocale;Z)[Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
