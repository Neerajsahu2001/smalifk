.class public final Le3/c;
.super Ljava/lang/Exception;
.source "JSRangeErrorException.java"
