.class public final Le3/e;
.super Ljava/lang/Object;
.source "LocaleIdentifier.java"


# direct methods
.method static a(Ljava/lang/String;Le3/d;Le3/d$a;ZLe3/m;)Z
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;,
            Le3/d$b;
        }
    .end annotation

    const/4 v0, 0x1

    if-eqz p3, :cond_d

    invoke-virtual {p2}, Le3/d$a;->d()Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-static {p2, p1, p4, p0}, Le3/e;->e(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V

    return v0

    :cond_d
    invoke-virtual {p2}, Le3/d$a;->a()Z

    move-result v1

    if-eqz v1, :cond_25

    if-nez p3, :cond_19

    invoke-static {p2, p1, p4, p0}, Le3/e;->b(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V

    return v0

    :cond_19
    new-instance p1, Le3/c;

    const-string p2, "Extension singletons in transformed extension language tag: "

    invoke-static {p2, p0}, Landroidx/coordinatorlayout/widget/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_25
    const/4 p0, 0x0

    return p0
.end method

.method static b(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;,
            Le3/d$b;
        }
    .end annotation

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result v0

    const-string v1, "Extension sequence expected."

    if-eqz v0, :cond_192

    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const-string v0, "]"

    const/16 v2, 0x75

    const-string v3, "Malformed sequence expected."

    if-ne p0, v2, :cond_c0

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-eqz p0, :cond_ba

    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    iget-object v1, p2, Le3/m;->b:Ljava/util/ArrayList;

    if-nez v1, :cond_ae

    iget-object v1, p2, Le3/m;->c:Ljava/util/TreeMap;

    if-nez v1, :cond_ae

    :goto_2b
    invoke-virtual {p0}, Le3/d$a;->f()Z

    move-result v0

    if-eqz v0, :cond_52

    iget-object v0, p2, Le3/m;->b:Ljava/util/ArrayList;

    if-nez v0, :cond_3c

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p2, Le3/m;->b:Ljava/util/ArrayList;

    :cond_3c
    iget-object v0, p2, Le3/m;->b:Ljava/util/ArrayList;

    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-nez p0, :cond_4d

    goto/16 :goto_185

    :cond_4d
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    goto :goto_2b

    :cond_52
    invoke-virtual {p0}, Le3/d$a;->g()Z

    move-result v0

    if-eqz v0, :cond_9d

    iget-object v0, p2, Le3/m;->c:Ljava/util/TreeMap;

    if-nez v0, :cond_63

    new-instance v0, Ljava/util/TreeMap;

    invoke-direct {v0}, Ljava/util/TreeMap;-><init>()V

    iput-object v0, p2, Le3/m;->c:Ljava/util/TreeMap;

    :cond_63
    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p2, Le3/m;->c:Ljava/util/TreeMap;

    invoke-virtual {v1, p0, v0}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-nez p0, :cond_79

    goto/16 :goto_185

    :cond_79
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    :goto_7d
    invoke-virtual {p0}, Le3/d$a;->h()Z

    move-result v1

    if-eqz v1, :cond_97

    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-nez p0, :cond_92

    goto/16 :goto_185

    :cond_92
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    goto :goto_7d

    :cond_97
    invoke-virtual {p0}, Le3/d$a;->g()Z

    move-result v0

    if-nez v0, :cond_63

    :cond_9d
    invoke-virtual {p0}, Le3/d$a;->a()Z

    move-result v0

    if-eqz v0, :cond_a8

    invoke-static {p0, p1, p2, p3}, Le3/e;->b(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V

    goto/16 :goto_185

    :cond_a8
    new-instance p0, Le3/c;

    invoke-direct {p0, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_ae
    new-instance p0, Le3/c;

    const-string p1, "Duplicate unicode extension sequence in ["

    invoke-static {p1, p3, v0}, Landroidx/core/content/b;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_ba
    new-instance p0, Le3/c;

    invoke-direct {p0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_c0
    const/16 v2, 0x74

    if-ne p0, v2, :cond_fd

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-eqz p0, :cond_f7

    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    invoke-virtual {p0}, Le3/d$a;->i()Z

    move-result v1

    if-eqz v1, :cond_da

    const/4 v0, 0x1

    invoke-static {p3, p1, p0, v0, p2}, Le3/e;->c(Ljava/lang/String;Le3/d;Le3/d$a;ZLe3/m;)V

    goto/16 :goto_185

    :cond_da
    invoke-virtual {p0}, Le3/d$a;->d()Z

    move-result v1

    if-eqz v1, :cond_e5

    invoke-static {p0, p1, p2, p3}, Le3/e;->e(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V

    goto/16 :goto_185

    :cond_e5
    new-instance p1, Le3/c;

    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p2, "Unexpected token ["

    const-string v1, "] in transformed extension sequence ["

    invoke-static {p2, p0, v1, p3, v0}, LO0/d;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_f7
    new-instance p0, Le3/c;

    invoke-direct {p0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_fd
    const/16 v0, 0x78

    if-ne p0, v0, :cond_13f

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-eqz p0, :cond_139

    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    iget-object p3, p2, Le3/m;->g:Ljava/util/ArrayList;

    if-nez p3, :cond_116

    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    iput-object p3, p2, Le3/m;->g:Ljava/util/ArrayList;

    :cond_116
    :goto_116
    invoke-virtual {p0}, Le3/d$a;->c()Z

    move-result p3

    if-eqz p3, :cond_131

    iget-object p3, p2, Le3/m;->g:Ljava/util/ArrayList;

    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p3, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-nez p0, :cond_12c

    goto :goto_185

    :cond_12c
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    goto :goto_116

    :cond_131
    new-instance p0, Le3/c;

    const-string p1, "Tokens are not expected after pu extension."

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_139
    new-instance p0, Le3/c;

    invoke-direct {p0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_13f
    invoke-virtual {p1}, Le3/d;->a()Z

    move-result v0

    if-eqz v0, :cond_18c

    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object v0

    iget-object v1, p2, Le3/m;->f:Ljava/util/TreeMap;

    if-nez v1, :cond_154

    new-instance v1, Ljava/util/TreeMap;

    invoke-direct {v1}, Ljava/util/TreeMap;-><init>()V

    iput-object v1, p2, Le3/m;->f:Ljava/util/TreeMap;

    :cond_154
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iget-object v2, p2, Le3/m;->f:Ljava/util/TreeMap;

    new-instance v4, Ljava/lang/Character;

    invoke-direct {v4, p0}, Ljava/lang/Character;-><init>(C)V

    invoke-virtual {v2, v4, v1}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_163
    invoke-virtual {v0}, Le3/d$a;->b()Z

    move-result p0

    if-eqz p0, :cond_17c

    invoke-virtual {v0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-nez p0, :cond_177

    goto :goto_185

    :cond_177
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object v0

    goto :goto_163

    :cond_17c
    invoke-virtual {v0}, Le3/d$a;->a()Z

    move-result p0

    if-eqz p0, :cond_186

    invoke-static {v0, p1, p2, p3}, Le3/e;->b(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V

    :goto_185
    return-void

    :cond_186
    new-instance p0, Le3/c;

    invoke-direct {p0, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_18c
    new-instance p0, Le3/c;

    invoke-direct {p0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_192
    new-instance p0, Le3/c;

    invoke-direct {p0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static c(Ljava/lang/String;Le3/d;Le3/d$a;ZLe3/m;)V
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;,
            Le3/d$b;
        }
    .end annotation

    const-string v0, "Language subtag expected at "

    new-instance v1, Le3/m$a;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    if-eqz p3, :cond_c

    iput-object v1, p4, Le3/m;->d:Le3/m$a;

    goto :goto_e

    :cond_c
    iput-object v1, p4, Le3/m;->a:Le3/m$a;

    :goto_e
    :try_start_e
    invoke-virtual {p2}, Le3/d$a;->i()Z

    move-result v2

    if-eqz v2, :cond_c0

    invoke-virtual {p2}, Le3/d$a;->m()Ljava/lang/String;

    move-result-object p2

    iput-object p2, v1, Le3/m$a;->a:Ljava/lang/String;

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p2

    if-nez p2, :cond_21

    return-void

    :cond_21
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p2

    invoke-static {p0, p1, p2, p3, p4}, Le3/e;->a(Ljava/lang/String;Le3/d;Le3/d$a;ZLe3/m;)Z

    move-result v0

    if-eqz v0, :cond_2c

    return-void

    :cond_2c
    invoke-virtual {p2}, Le3/d$a;->k()Z

    move-result v0

    if-eqz v0, :cond_43

    invoke-virtual {p2}, Le3/d$a;->n()Ljava/lang/String;

    move-result-object p2

    iput-object p2, v1, Le3/m$a;->b:Ljava/lang/String;

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p2

    if-nez p2, :cond_3f

    return-void

    :cond_3f
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p2

    :cond_43
    invoke-virtual {p2}, Le3/d$a;->j()Z

    move-result v0

    if-eqz v0, :cond_5a

    invoke-virtual {p2}, Le3/d$a;->o()Ljava/lang/String;

    move-result-object p2

    iput-object p2, v1, Le3/m$a;->c:Ljava/lang/String;

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p2

    if-nez p2, :cond_56

    return-void

    :cond_56
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p2

    :cond_5a
    :goto_5a
    invoke-static {p0, p1, p2, p3, p4}, Le3/e;->a(Ljava/lang/String;Le3/d;Le3/d$a;ZLe3/m;)Z

    move-result v0

    if-eqz v0, :cond_61

    return-void

    :cond_61
    invoke-virtual {p2}, Le3/d$a;->l()Z

    move-result v0

    if-eqz v0, :cond_9d

    invoke-virtual {p2}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p2

    iget-object v0, v1, Le3/m$a;->d:Ljava/util/ArrayList;

    if-eqz v0, :cond_87

    invoke-static {v0, p2}, Ljava/util/Collections;->binarySearch(Ljava/util/List;Ljava/lang/Object;)I

    move-result v0

    if-gez v0, :cond_7f

    iget-object v2, v1, Le3/m$a;->d:Ljava/util/ArrayList;

    mul-int/lit8 v0, v0, -0x1

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v2, v0, p2}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    goto :goto_91

    :cond_7f
    new-instance p1, Le3/c;

    const-string p2, "Duplicate variant"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_87
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, v1, Le3/m$a;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_91
    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p2

    if-nez p2, :cond_98

    return-void

    :cond_98
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p2

    goto :goto_5a

    :cond_9d
    new-instance p1, Le3/c;

    invoke-virtual {p2}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p2

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string p4, "Unknown token ["

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "] found in locale id: "

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_c0
    new-instance p1, Le3/c;

    invoke-virtual {p2}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p2

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ": "

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_de
    .catch Le3/d$b; {:try_start_e .. :try_end_de} :catch_de

    :catch_de
    new-instance p1, Le3/c;

    const-string p2, "Locale Identifier subtag iteration failed: "

    invoke-static {p2, p0}, Landroidx/coordinatorlayout/widget/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method static d(Ljava/lang/String;)Le3/m;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Le3/d;

    invoke-direct {v0, p0}, Le3/d;-><init>(Ljava/lang/String;)V

    const-string v1, "Language subtag not found: "

    new-instance v2, Le3/m;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    :try_start_10
    invoke-virtual {v0}, Le3/d;->a()Z

    move-result v3

    if-eqz v3, :cond_1f

    invoke-virtual {v0}, Le3/d;->b()Le3/d$a;

    move-result-object v1

    const/4 v3, 0x0

    invoke-static {p0, v0, v1, v3, v2}, Le3/e;->c(Ljava/lang/String;Le3/d;Le3/d$a;ZLe3/m;)V

    return-object v2

    :cond_1f
    new-instance v0, Le3/c;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_31
    .catch Le3/d$b; {:try_start_10 .. :try_end_31} :catch_31

    :catch_31
    new-instance v0, Le3/c;

    const-string v1, "Locale Identifier subtag iteration failed: "

    invoke-static {v1, p0}, Landroidx/coordinatorlayout/widget/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static e(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;,
            Le3/d$b;
        }
    .end annotation

    invoke-virtual {p0}, Le3/d$a;->d()Z

    move-result v0

    if-eqz v0, :cond_65

    iget-object v0, p2, Le3/m;->e:Ljava/util/TreeMap;

    if-nez v0, :cond_57

    if-nez v0, :cond_13

    new-instance v0, Ljava/util/TreeMap;

    invoke-direct {v0}, Ljava/util/TreeMap;-><init>()V

    iput-object v0, p2, Le3/m;->e:Ljava/util/TreeMap;

    :cond_13
    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p2, Le3/m;->e:Ljava/util/TreeMap;

    invoke-virtual {v1, p0, v0}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-eqz p0, :cond_4b

    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    :goto_2b
    invoke-virtual {p0}, Le3/d$a;->e()Z

    move-result v1

    if-eqz v1, :cond_44

    invoke-virtual {p0}, Le3/d$a;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Le3/d;->a()Z

    move-result p0

    if-nez p0, :cond_3f

    return-void

    :cond_3f
    invoke-virtual {p1}, Le3/d;->b()Le3/d$a;

    move-result-object p0

    goto :goto_2b

    :cond_44
    invoke-virtual {p0}, Le3/d$a;->d()Z

    move-result v0

    if-nez v0, :cond_13

    goto :goto_65

    :cond_4b
    new-instance p0, Le3/c;

    const-string p1, "Malformated transformed key in : "

    invoke-static {p1, p3}, Landroidx/coordinatorlayout/widget/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_57
    new-instance p0, Le3/c;

    const-string p1, "Duplicate transformed extension sequence in ["

    const-string p2, "]"

    invoke-static {p1, p3, p2}, Landroidx/core/content/b;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_65
    :goto_65
    invoke-virtual {p0}, Le3/d$a;->a()Z

    move-result v0

    if-eqz v0, :cond_6f

    invoke-static {p0, p1, p2, p3}, Le3/e;->b(Le3/d$a;Le3/d;Le3/m;Ljava/lang/String;)V

    return-void

    :cond_6f
    new-instance p0, Le3/c;

    const-string p1, "Malformed extension sequence."

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
.end method
