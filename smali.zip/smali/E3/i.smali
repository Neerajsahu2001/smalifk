.class public final synthetic Le3/i;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static synthetic a(Landroid/net/Uri;I)Landroid/app/job/JobInfo$TriggerContentUri;
    .registers 3

    new-instance v0, Landroid/app/job/JobInfo$TriggerContentUri;

    invoke-direct {v0, p0, p1}, Landroid/app/job/JobInfo$TriggerContentUri;-><init>(Landroid/net/Uri;I)V

    return-object v0
.end method

.method public static bridge synthetic b()Landroid/icu/text/DateFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/DateFormat$Field;->YEAR:Landroid/icu/text/DateFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic c()Landroid/icu/text/NumberFormat$Field;
    .registers 1

    sget-object v0, Landroid/icu/text/NumberFormat$Field;->EXPONENT_SYMBOL:Landroid/icu/text/NumberFormat$Field;

    return-object v0
.end method

.method public static bridge synthetic d(Landroid/icu/util/ULocale;)Ljava/util/Iterator;
    .registers 1

    invoke-virtual {p0}, Landroid/icu/util/ULocale;->getKeywords()Ljava/util/Iterator;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic e(Ljava/lang/Object;)Z
    .registers 1

    instance-of p0, p0, Landroid/icu/text/DecimalFormat;

    return p0
.end method
