.class public final Le3/l;
.super Ljava/lang/Object;
.source "LocaleObjectICU.java"

# interfaces
.implements Le3/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Le3/b<",
        "Landroid/icu/util/ULocale;",
        ">;"
    }
.end annotation


# instance fields
.field private a:Landroid/icu/util/ULocale;

.field private b:Landroid/icu/util/ULocale$Builder;

.field private c:Z


# direct methods
.method private constructor <init>(Landroid/icu/util/ULocale;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Le3/l;->b:Landroid/icu/util/ULocale$Builder;

    const/4 v0, 0x0

    iput-boolean v0, p0, Le3/l;->c:Z

    iput-object p1, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    return-void
.end method

.method public static h()Le3/l;
    .registers 2

    new-instance v0, Le3/l;

    invoke-static {}, Lcom/flipkart/pushnotification/b;->c()Landroid/icu/util/ULocale$Category;

    move-result-object v1

    invoke-static {v1}, Le3/h;->c(Landroid/icu/util/ULocale$Category;)Landroid/icu/util/ULocale;

    move-result-object v1

    invoke-direct {v0, v1}, Le3/l;-><init>(Landroid/icu/util/ULocale;)V

    return-object v0
.end method

.method public static i(Ljava/lang/String;)Le3/l;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    new-instance v0, Le3/l;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object v1, v0, Le3/l;->a:Landroid/icu/util/ULocale;

    iput-object v1, v0, Le3/l;->b:Landroid/icu/util/ULocale$Builder;

    const/4 v1, 0x0

    iput-boolean v1, v0, Le3/l;->c:Z

    invoke-static {}, Lcom/flipkart/android/utils/c;->c()Landroid/icu/util/ULocale$Builder;

    move-result-object v1

    iput-object v1, v0, Le3/l;->b:Landroid/icu/util/ULocale$Builder;

    :try_start_13
    invoke-static {v1, p0}, Lcom/facebook/imageutils/b;->e(Landroid/icu/util/ULocale$Builder;Ljava/lang/String;)V
    :try_end_16
    .catch Ljava/lang/RuntimeException; {:try_start_13 .. :try_end_16} :catch_1a

    const/4 p0, 0x1

    iput-boolean p0, v0, Le3/l;->c:Z

    return-object v0

    :catch_1a
    move-exception p0

    new-instance v0, Le3/c;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static j(Landroid/icu/util/ULocale;)Le3/l;
    .registers 2

    new-instance v0, Le3/l;

    invoke-direct {v0, p0}, Le3/l;-><init>(Landroid/icu/util/ULocale;)V

    return-object v0
.end method

.method private k()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    iget-boolean v0, p0, Le3/l;->c:Z

    if-eqz v0, :cond_1b

    :try_start_4
    iget-object v0, p0, Le3/l;->b:Landroid/icu/util/ULocale$Builder;

    invoke-static {v0}, Lcom/flipkart/android/fragments/v0;->c(Landroid/icu/util/ULocale$Builder;)Landroid/icu/util/ULocale;

    move-result-object v0

    iput-object v0, p0, Le3/l;->a:Landroid/icu/util/ULocale;
    :try_end_c
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_c} :catch_10

    const/4 v0, 0x0

    iput-boolean v0, p0, Le3/l;->c:Z

    goto :goto_1b

    :catch_10
    move-exception v0

    new-instance v1, Le3/c;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1b
    :goto_1b
    return-void
.end method


# virtual methods
.method public final a()Ljava/util/ArrayList;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    invoke-static {}, Le3/p;->a()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iget-object v2, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-static {v2, v0}, Lcom/flipkart/ultra/container/v2/engine/views/a;->e(Landroid/icu/util/ULocale;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_23

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_23

    const-string v2, "-|_"

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    :cond_23
    return-object v1
.end method

.method public final a()Ljava/util/HashMap;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-static {v1}, Le3/i;->d(Landroid/icu/util/ULocale;)Ljava/util/Iterator;

    move-result-object v1

    if-eqz v1, :cond_2a

    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Le3/p;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-static {v4, v2}, Lcom/flipkart/ultra/container/v2/engine/views/a;->e(Landroid/icu/util/ULocale;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_10

    :cond_2a
    return-object v0
.end method

.method public final b()Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    invoke-static {}, Lcom/flipkart/android/utils/c;->c()Landroid/icu/util/ULocale$Builder;

    move-result-object v0

    iget-object v1, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-static {v0, v1}, Landroidx/appcompat/widget/y;->c(Landroid/icu/util/ULocale$Builder;Landroid/icu/util/ULocale;)V

    invoke-static {v0}, Lcom/facebook/imagepipeline/producers/K;->h(Landroid/icu/util/ULocale$Builder;)V

    invoke-static {v0}, Lcom/flipkart/android/fragments/w0;->d(Landroid/icu/util/ULocale$Builder;)Landroid/icu/util/ULocale;

    move-result-object v0

    return-object v0
.end method

.method public final c()Le3/b;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Le3/b<",
            "Landroid/icu/util/ULocale;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    new-instance v0, Le3/l;

    iget-object v1, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-direct {v0, v1}, Le3/l;-><init>(Landroid/icu/util/ULocale;)V

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    invoke-static {}, Lcom/flipkart/android/utils/c;->c()Landroid/icu/util/ULocale$Builder;

    move-result-object v0

    iget-object v1, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-static {v0, v1}, Landroidx/appcompat/widget/y;->c(Landroid/icu/util/ULocale$Builder;Landroid/icu/util/ULocale;)V

    invoke-static {v0}, Lcom/facebook/imagepipeline/producers/K;->h(Landroid/icu/util/ULocale$Builder;)V

    invoke-static {v0}, Lcom/flipkart/android/fragments/w0;->d(Landroid/icu/util/ULocale$Builder;)Landroid/icu/util/ULocale;

    move-result-object v0

    invoke-static {v0}, Le3/j;->c(Landroid/icu/util/ULocale;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final e(Ljava/lang/String;Ljava/util/ArrayList;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    iget-object v0, p0, Le3/l;->b:Landroid/icu/util/ULocale$Builder;

    if-nez v0, :cond_13

    invoke-static {}, Lcom/flipkart/android/utils/c;->c()Landroid/icu/util/ULocale$Builder;

    move-result-object v0

    iget-object v1, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-static {v0, v1}, Le3/k;->c(Landroid/icu/util/ULocale$Builder;Landroid/icu/util/ULocale;)Landroid/icu/util/ULocale$Builder;

    move-result-object v0

    iput-object v0, p0, Le3/l;->b:Landroid/icu/util/ULocale$Builder;

    :cond_13
    :try_start_13
    iget-object v0, p0, Le3/l;->b:Landroid/icu/util/ULocale$Builder;

    const-string v1, "-"

    invoke-static {v1, p2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p2

    invoke-static {v0, p1, p2}, Landroidx/appcompat/widget/x;->d(Landroid/icu/util/ULocale$Builder;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1e
    .catch Ljava/lang/RuntimeException; {:try_start_13 .. :try_end_1e} :catch_22

    const/4 p1, 0x1

    iput-boolean p1, p0, Le3/l;->c:Z

    return-void

    :catch_22
    move-exception p1

    new-instance p2, Le3/c;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public final f()Ljava/lang/String;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    iget-object v0, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    invoke-static {v0}, Le3/j;->c(Landroid/icu/util/ULocale;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final g()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    iget-object v0, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    return-object v0
.end method

.method public final l()Landroid/icu/util/ULocale;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    invoke-direct {p0}, Le3/l;->k()V

    iget-object v0, p0, Le3/l;->a:Landroid/icu/util/ULocale;

    return-object v0
.end method
