.class public final Le3/p;
.super Ljava/lang/Object;
.source "UnicodeExtensionKeys.java"


# static fields
.field private static a:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static b:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 74

    new-instance v0, Le3/p$a;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const-string v1, "ca"

    const-string v2, "calendar"

    invoke-virtual {v0, v1, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "nu"

    const-string v4, "numbers"

    invoke-virtual {v0, v3, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v5, "hc"

    const-string v6, "hours"

    invoke-virtual {v0, v5, v6}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v7, "co"

    const-string v8, "collation"

    invoke-virtual {v0, v7, v8}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v9, "kn"

    const-string v10, "colnumeric"

    invoke-virtual {v0, v9, v10}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v11, "kf"

    const-string v12, "colcasefirst"

    invoke-virtual {v0, v11, v12}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sput-object v0, Le3/p;->a:Ljava/util/HashMap;

    new-instance v0, Le3/p$b;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v0, v2, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, v6, v5}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, v8, v7}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, v10, v9}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, v12, v11}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sput-object v0, Le3/p;->b:Ljava/util/HashMap;

    new-instance v0, Le3/p$c;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const-string v2, "dictionary"

    const-string v4, "dict"

    invoke-virtual {v0, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "phonebook"

    const-string v4, "phonebk"

    invoke-virtual {v0, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "trad"

    const-string v4, "traditional"

    invoke-virtual {v0, v4, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "gb2312han"

    const-string v5, "gb2312"

    invoke-virtual {v0, v2, v5}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sput-object v0, Le3/p;->c:Ljava/util/Map;

    new-instance v0, Le3/p$d;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const-string v2, "gregorian"

    const-string v5, "gregory"

    invoke-virtual {v0, v2, v5}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sput-object v0, Le3/p;->d:Ljava/util/Map;

    new-instance v0, Le3/p$e;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const-string v2, "traditio"

    invoke-virtual {v0, v4, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sput-object v0, Le3/p;->e:Ljava/util/Map;

    new-instance v0, Le3/p$f;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const-string v70, "tirh"

    const-string v71, "vaii"

    const-string v8, "adlm"

    const-string v9, "ahom"

    const-string v10, "arab"

    const-string v11, "arabext"

    const-string v12, "bali"

    const-string v13, "beng"

    const-string v14, "bhks"

    const-string v15, "brah"

    const-string v16, "cakm"

    const-string v17, "cham"

    const-string v18, "deva"

    const-string v19, "diak"

    const-string v20, "fullwide"

    const-string v21, "gong"

    const-string v22, "gonm"

    const-string v23, "gujr"

    const-string v24, "guru"

    const-string v25, "hanidec"

    const-string v26, "hmng"

    const-string v27, "hmnp"

    const-string v28, "java"

    const-string v29, "kali"

    const-string v30, "khmr"

    const-string v31, "knda"

    const-string v32, "lana"

    const-string v33, "lanatham"

    const-string v34, "laoo"

    const-string v35, "latn"

    const-string v36, "lepc"

    const-string v37, "limb"

    const-string v38, "mathbold"

    const-string v39, "mathdbl"

    const-string v40, "mathmono"

    const-string v41, "mathsanb"

    const-string v42, "mathsans"

    const-string v43, "mlym"

    const-string v44, "modi"

    const-string v45, "mong"

    const-string v46, "mroo"

    const-string v47, "mtei"

    const-string v48, "mymr"

    const-string v49, "mymrshan"

    const-string v50, "mymrtlng"

    const-string v51, "newa"

    const-string v52, "nkoo"

    const-string v53, "olck"

    const-string v54, "orya"

    const-string v55, "osma"

    const-string v56, "rohg"

    const-string v57, "saur"

    const-string v58, "segment"

    const-string v59, "shrd"

    const-string v60, "sind"

    const-string v61, "sinh"

    const-string v62, "sora"

    const-string v63, "sund"

    const-string v64, "takr"

    const-string v65, "talu"

    const-string v66, "tamldec"

    const-string v67, "telu"

    const-string v68, "thai"

    const-string v69, "tibt"

    const-string v72, "wara"

    const-string v73, "wcho"

    filled-new-array/range {v8 .. v73}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v21, "stroke"

    const-string v22, "trad"

    const-string v8, "big5han"

    const-string v9, "compat"

    const-string v10, "dict"

    const-string v11, "direct"

    const-string v12, "ducet"

    const-string v13, "emoji"

    const-string v14, "eor"

    const-string v15, "gb2312"

    const-string v16, "phonebk"

    const-string v17, "phonetic"

    const-string v18, "pinyin"

    const-string v19, "reformed"

    const-string v20, "searchjl"

    const-string v23, "unihan"

    const-string v24, "zhuyin"

    filled-new-array/range {v8 .. v24}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v7, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v22, "iso8601"

    const-string v23, "japanese"

    const-string v8, "buddhist"

    const-string v9, "chinese"

    const-string v10, "coptic"

    const-string v11, "dangi"

    const-string v12, "ethioaa"

    const-string v13, "ethiopic"

    const-string v14, "gregory"

    const-string v15, "hebrew"

    const-string v16, "indian"

    const-string v17, "islamic"

    const-string v18, "islamic-umalqura"

    const-string v19, "islamic-tbla"

    const-string v20, "islamic-civil"

    const-string v21, "islamic-rgsa"

    const-string v24, "persian"

    const-string v25, "roc"

    filled-new-array/range {v8 .. v25}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sput-object v0, Le3/p;->f:Ljava/util/Map;

    return-void
.end method

.method public static a()Ljava/lang/String;
    .registers 3

    sget-object v0, Le3/p;->a:Ljava/util/HashMap;

    const-string v1, "collation"

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_11

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    :cond_11
    return-object v1
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    sget-object v0, Le3/p;->b:Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    :cond_e
    return-object p0
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;Le3/b;)Z
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/c;
        }
    .end annotation

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    const/4 v2, 0x1

    if-lt v0, v1, :cond_57

    invoke-interface {p2}, Le3/b;->g()Ljava/lang/Object;

    move-result-object p2

    invoke-static {p2}, LO6/g;->b(Ljava/lang/Object;)Landroid/icu/util/ULocale;

    move-result-object p2

    const/4 v0, 0x0

    new-array v1, v0, [Ljava/lang/String;

    const-string v3, "co"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_31

    const-string p0, "standard"

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_30

    const-string p0, "search"

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2b

    goto :goto_30

    :cond_2b
    invoke-static {p2}, Lcom/facebook/imageutils/b;->g(Landroid/icu/util/ULocale;)[Ljava/lang/String;

    move-result-object v1

    goto :goto_4a

    :cond_30
    :goto_30
    return v0

    :cond_31
    const-string v0, "ca"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3e

    invoke-static {p2}, Le3/k;->f(Landroid/icu/util/ULocale;)[Ljava/lang/String;

    move-result-object v1

    goto :goto_4a

    :cond_3e
    const-string p2, "nu"

    invoke-virtual {p0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_4a

    invoke-static {}, Landroidx/appcompat/widget/x;->f()[Ljava/lang/String;

    move-result-object v1

    :cond_4a
    :goto_4a
    array-length p0, v1

    if-nez p0, :cond_4e

    return v2

    :cond_4e
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_57
    sget-object p2, Le3/p;->f:Ljava/util/Map;

    check-cast p2, Ljava/util/HashMap;

    invoke-virtual {p2, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_70

    invoke-virtual {p2, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Ljava/lang/String;

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_70
    return v2
.end method

.method public static d(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    sget-object v0, Le3/p;->d:Ljava/util/Map;

    move-object v1, v0

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    return-object p0

    :cond_c
    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public static e(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    sget-object v0, Le3/p;->c:Ljava/util/Map;

    move-object v1, v0

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    return-object p0

    :cond_c
    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public static f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    const-string v0, "ca"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13

    instance-of v0, p0, Ljava/lang/String;

    if-eqz v0, :cond_13

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Le3/p;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_13
    const-string v0, "nu"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_33

    instance-of v0, p0, Ljava/lang/String;

    if-eqz v0, :cond_33

    check-cast p0, Ljava/lang/String;

    sget-object p1, Le3/p;->e:Ljava/util/Map;

    check-cast p1, Ljava/util/HashMap;

    invoke-virtual {p1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c

    goto :goto_32

    :cond_2c
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    :goto_32
    return-object p0

    :cond_33
    const-string v0, "co"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_46

    instance-of v0, p0, Ljava/lang/String;

    if-eqz v0, :cond_46

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Le3/p;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_46
    const-string v0, "kn"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    instance-of v1, p0, Ljava/lang/String;

    if-eqz v1, :cond_5d

    const-string v1, "yes"

    invoke-virtual {p0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    const-string p0, "true"

    return-object p0

    :cond_5d
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6b

    const-string v0, "kf"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_79

    :cond_6b
    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_79

    const-string p1, "no"

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_79

    const-string p0, "false"

    :cond_79
    return-object p0
.end method
