.class public final Le3/a;
.super Ljava/lang/Object;
.source "Constants.java"


# static fields
.field public static final a:[Ljava/lang/String;

.field public static final b:[Ljava/lang/String;

.field public static final c:[Ljava/lang/String;

.field public static final d:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const-string v0, "best fit"

    const-string v1, "lookup"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Le3/a;->a:[Ljava/lang/String;

    const-string v0, "case"

    const-string v1, "variant"

    const-string v2, "base"

    const-string v3, "accent"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Le3/a;->b:[Ljava/lang/String;

    const-string v0, "lower"

    const-string v1, "false"

    const-string v2, "upper"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Le3/a;->c:[Ljava/lang/String;

    const-string v0, "sort"

    const-string v1, "search"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Le3/a;->d:[Ljava/lang/String;

    return-void
.end method
