.class final Le3/d;
.super Ljava/lang/Object;
.source "LocaleIdentifier.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le3/d$b;,
        Le3/d$a;
    }
.end annotation


# instance fields
.field private a:Ljava/lang/CharSequence;

.field b:I

.field c:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Le3/d;->b:I

    const/4 v0, -0x1

    iput v0, p0, Le3/d;->c:I

    iput-object p1, p0, Le3/d;->a:Ljava/lang/CharSequence;

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 4

    iget-object v0, p0, Le3/d;->a:Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-lez v1, :cond_13

    iget v1, p0, Le3/d;->c:I

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v2, 0x1

    sub-int/2addr v0, v2

    if-ge v1, v0, :cond_13

    goto :goto_14

    :cond_13
    const/4 v2, 0x0

    :goto_14
    return v2
.end method

.method public final b()Le3/d$a;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Le3/d$b;
        }
    .end annotation

    invoke-virtual {p0}, Le3/d;->a()Z

    move-result v0

    if-eqz v0, :cond_67

    iget v0, p0, Le3/d;->c:I

    iget v1, p0, Le3/d;->b:I

    iget-object v2, p0, Le3/d;->a:Ljava/lang/CharSequence;

    const/16 v3, 0x2d

    if-lt v0, v1, :cond_35

    add-int/lit8 v0, v0, 0x1

    invoke-interface {v2, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    if-ne v0, v3, :cond_2f

    iget v0, p0, Le3/d;->c:I

    add-int/lit8 v0, v0, 0x2

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-eq v0, v1, :cond_29

    iget v0, p0, Le3/d;->c:I

    add-int/lit8 v0, v0, 0x2

    iput v0, p0, Le3/d;->b:I

    goto :goto_35

    :cond_29
    new-instance v0, Le3/d$b;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0

    :cond_2f
    new-instance v0, Le3/d$b;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0

    :cond_35
    :goto_35
    iget v0, p0, Le3/d;->b:I

    iput v0, p0, Le3/d;->c:I

    :goto_39
    iget v0, p0, Le3/d;->c:I

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-ge v0, v1, :cond_51

    iget v0, p0, Le3/d;->c:I

    invoke-interface {v2, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    if-ne v0, v3, :cond_4a

    goto :goto_51

    :cond_4a
    iget v0, p0, Le3/d;->c:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Le3/d;->c:I

    goto :goto_39

    :cond_51
    :goto_51
    iget v0, p0, Le3/d;->c:I

    iget v1, p0, Le3/d;->b:I

    if-le v0, v1, :cond_61

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Le3/d;->c:I

    new-instance v3, Le3/d$a;

    invoke-direct {v3, v2, v1, v0}, Le3/d$a;-><init>(Ljava/lang/CharSequence;II)V

    return-object v3

    :cond_61
    new-instance v0, Le3/d$b;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0

    :cond_67
    new-instance v0, Le3/d$b;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0
.end method
