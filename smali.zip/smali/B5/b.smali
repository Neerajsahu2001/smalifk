.class public final synthetic Lb5/b;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lzj/e;


# instance fields
.field public final synthetic a:Lb5/c$a;

.field public final synthetic b:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Lb5/c$a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lb5/b;->a:Lb5/c$a;

    iput-object p1, p0, Lb5/b;->b:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final onComplete(Lzj/k;)V
    .registers 7

    iget-object v0, p0, Lb5/b;->a:Lb5/c$a;

    iget-object v1, p0, Lb5/b;->b:Landroid/app/Activity;

    const-string v2, "GoogleApiHelper"

    :try_start_6
    const-class v3, Lcom/google/android/gms/common/api/ApiException;

    invoke-virtual {p1, v3}, Lzj/k;->m(Ljava/lang/Class;)Ljava/lang/Object;

    const-string p1, "All location settings are satisfied with status "

    invoke-static {v2, p1}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x1

    invoke-interface {v0, p1}, Lb5/c$a;->locationEnableStatusCallback(Z)V
    :try_end_14
    .catch Lcom/google/android/gms/common/api/ApiException; {:try_start_6 .. :try_end_14} :catch_15

    goto :goto_4a

    :catch_15
    move-exception p1

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/ApiException;->getStatusCode()I

    move-result v3

    const/4 v4, 0x6

    if-ne v3, v4, :cond_3d

    const-string v0, "Location settings are not satisfied. User prompted with dialog to upgrade location settings "

    invoke-static {v2, v0}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_22
    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_4a

    new-instance v0, Lcom/google/android/gms/common/api/ResolvableApiException;

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/ApiException;->getStatus()Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/ResolvableApiException;-><init>(Lcom/google/android/gms/common/api/Status;)V

    const/16 p1, 0x15

    invoke-virtual {v0, v1, p1}, Lcom/google/android/gms/common/api/ResolvableApiException;->startResolutionForResult(Landroid/app/Activity;I)V
    :try_end_36
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_22 .. :try_end_36} :catch_37

    goto :goto_4a

    :catch_37
    const-string p1, "PendingIntent unable to execute request."

    invoke-static {v2, p1}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_4a

    :cond_3d
    const/16 p1, 0x2136

    if-ne v3, p1, :cond_4a

    const-string p1, "Location settings are inadequate, and cannot be fixed here. Dialog not created."

    invoke-static {v2, p1}, Lpa/a;->debug(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    invoke-interface {v0, p1}, Lb5/c$a;->locationEnableStatusCallback(Z)V

    :cond_4a
    :goto_4a
    return-void
.end method
