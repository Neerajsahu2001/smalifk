.class public interface abstract Lb5/a;
.super Ljava/lang/Object;
.source "GoogleApiCallbacks.java"


# virtual methods
.method public abstract googleApiFailureCallback()V
.end method
