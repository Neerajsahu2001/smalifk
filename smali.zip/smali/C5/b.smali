.class public final Lc5/b;
.super LBk/a;
.source "JsonObjectTreeReader.java"

# interfaces
.implements LHa/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc5/b$b;
    }
.end annotation


# static fields
.field private static final u:Ljava/io/Reader;

.field private static final v:Ljava/lang/Object;


# instance fields
.field private q:[Ljava/lang/Object;

.field private r:I

.field private s:[Ljava/lang/String;

.field private t:[I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lc5/b$a;

    invoke-direct {v0}, Lc5/b$a;-><init>()V

    sput-object v0, Lc5/b;->u:Ljava/io/Reader;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lc5/b;->v:Ljava/lang/Object;

    new-instance v0, Lc5/b$b;

    sget-object v1, Lcom/google/gson/internal/p;->a:Lcom/google/gson/internal/p;

    invoke-direct {v0}, Lcom/google/gson/internal/p;-><init>()V

    iput-object v1, v0, Lc5/b$b;->b:Lcom/google/gson/internal/p;

    sput-object v0, Lcom/google/gson/internal/p;->a:Lcom/google/gson/internal/p;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .registers 4

    sget-object v0, Lc5/b;->u:Ljava/io/Reader;

    invoke-direct {p0, v0}, LBk/a;-><init>(Ljava/io/Reader;)V

    const/16 v0, 0x20

    new-array v1, v0, [Ljava/lang/Object;

    iput-object v1, p0, Lc5/b;->q:[Ljava/lang/Object;

    const/4 v1, 0x0

    iput v1, p0, Lc5/b;->r:I

    new-array v1, v0, [Ljava/lang/String;

    iput-object v1, p0, Lc5/b;->s:[Ljava/lang/String;

    new-array v0, v0, [I

    iput-object v0, p0, Lc5/b;->t:[I

    invoke-direct {p0, p1}, Lc5/b;->j0(Ljava/lang/Object;)V

    return-void
.end method

.method private c0(LBk/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    if-ne v0, p1, :cond_7

    return-void

    :cond_7
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " but was "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-direct {p0}, Lc5/b;->o()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private d0()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lc5/b;->q:[Ljava/lang/Object;

    iget v1, p0, Lc5/b;->r:I

    add-int/lit8 v1, v1, -0x1

    aget-object v0, v0, v1

    return-object v0
.end method

.method private f0()Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, Lc5/b;->q:[Ljava/lang/Object;

    iget v1, p0, Lc5/b;->r:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lc5/b;->r:I

    aget-object v2, v0, v1

    const/4 v3, 0x0

    aput-object v3, v0, v1

    return-object v2
.end method

.method private j0(Ljava/lang/Object;)V
    .registers 8

    iget v0, p0, Lc5/b;->r:I

    iget-object v1, p0, Lc5/b;->q:[Ljava/lang/Object;

    array-length v2, v1

    if-ne v0, v2, :cond_2b

    mul-int/lit8 v2, v0, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    mul-int/lit8 v3, v0, 0x2

    new-array v3, v3, [I

    mul-int/lit8 v4, v0, 0x2

    new-array v4, v4, [Ljava/lang/String;

    const/4 v5, 0x0

    invoke-static {v1, v5, v2, v5, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, Lc5/b;->t:[I

    iget v1, p0, Lc5/b;->r:I

    invoke-static {v0, v5, v3, v5, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, Lc5/b;->s:[Ljava/lang/String;

    iget v1, p0, Lc5/b;->r:I

    invoke-static {v0, v5, v4, v5, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v2, p0, Lc5/b;->q:[Ljava/lang/Object;

    iput-object v3, p0, Lc5/b;->t:[I

    iput-object v4, p0, Lc5/b;->s:[Ljava/lang/String;

    :cond_2b
    iget-object v0, p0, Lc5/b;->q:[Ljava/lang/Object;

    iget v1, p0, Lc5/b;->r:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lc5/b;->r:I

    aput-object p1, v0, v1

    return-void
.end method

.method private o()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, " at path "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lc5/b;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public beginArray()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->BEGIN_ARRAY:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-direct {p0, v0}, Lc5/b;->j0(Ljava/lang/Object;)V

    iget-object v0, p0, Lc5/b;->t:[I

    iget v1, p0, Lc5/b;->r:I

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x0

    aput v2, v0, v1

    return-void
.end method

.method public beginObject()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->BEGIN_OBJECT:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-direct {p0, v0}, Lc5/b;->j0(Ljava/lang/Object;)V

    return-void
.end method

.method public close()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    sget-object v2, Lc5/b;->v:Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    iput-object v1, p0, Lc5/b;->q:[Ljava/lang/Object;

    iput v0, p0, Lc5/b;->r:I

    return-void
.end method

.method public endArray()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->END_ARRAY:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    iget v0, p0, Lc5/b;->r:I

    if-lez v0, :cond_19

    iget-object v1, p0, Lc5/b;->t:[I

    add-int/lit8 v0, v0, -0x1

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    :cond_19
    return-void
.end method

.method public endObject()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->END_OBJECT:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    iget v0, p0, Lc5/b;->r:I

    if-lez v0, :cond_19

    iget-object v1, p0, Lc5/b;->t:[I

    add-int/lit8 v0, v0, -0x1

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    :cond_19
    return-void
.end method

.method public getPath()Ljava/lang/String;
    .registers 6

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "$"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    :goto_8
    iget v2, p0, Lc5/b;->r:I

    if-ge v1, v2, :cond_4b

    iget-object v2, p0, Lc5/b;->q:[Ljava/lang/Object;

    aget-object v3, v2, v1

    instance-of v4, v3, Ljava/util/List;

    if-eqz v4, :cond_2e

    add-int/lit8 v1, v1, 0x1

    aget-object v2, v2, v1

    instance-of v2, v2, Ljava/util/Iterator;

    if-eqz v2, :cond_48

    const/16 v2, 0x5b

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc5/b;->t:[I

    aget v2, v2, v1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v2, 0x5d

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_48

    :cond_2e
    instance-of v3, v3, Ljava/util/Map;

    if-eqz v3, :cond_48

    add-int/lit8 v1, v1, 0x1

    aget-object v2, v2, v1

    instance-of v2, v2, Ljava/util/Iterator;

    if-eqz v2, :cond_48

    const/16 v2, 0x2e

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc5/b;->s:[Ljava/lang/String;

    aget-object v2, v2, v1

    if-eqz v2, :cond_48

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_48
    :goto_48
    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    :cond_4b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public hasNext()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->END_OBJECT:LBk/b;

    if-eq v0, v1, :cond_e

    sget-object v1, LBk/b;->END_ARRAY:LBk/b;

    if-eq v0, v1, :cond_e

    const/4 v0, 0x1

    goto :goto_f

    :cond_e
    const/4 v0, 0x0

    :goto_f
    return v0
.end method

.method public nextBoolean()Z
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->BOOLEAN:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Boolean;

    if-eqz v1, :cond_14

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    goto :goto_20

    :cond_14
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    :goto_20
    iget v1, p0, Lc5/b;->r:I

    if-lez v1, :cond_2e

    iget-object v2, p0, Lc5/b;->t:[I

    add-int/lit8 v1, v1, -0x1

    aget v3, v2, v1

    add-int/lit8 v3, v3, 0x1

    aput v3, v2, v1

    :cond_2e
    return v0
.end method

.method public nextDouble()D
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NUMBER:LBk/b;

    if-eq v0, v1, :cond_30

    sget-object v2, LBk/b;->STRING:LBk/b;

    if-ne v0, v2, :cond_d

    goto :goto_30

    :cond_d
    new-instance v2, Ljava/lang/IllegalStateException;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Expected "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " but was "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-direct {p0}, Lc5/b;->o()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_30
    :goto_30
    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_3f

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    goto :goto_4b

    :cond_3f
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    :goto_4b
    invoke-virtual {p0}, LBk/a;->isLenient()Z

    move-result v2

    if-nez v2, :cond_72

    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    move-result v2

    if-nez v2, :cond_5e

    invoke-static {v0, v1}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v2

    if-nez v2, :cond_5e

    goto :goto_72

    :cond_5e
    new-instance v2, Ljava/lang/NumberFormatException;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "JSON forbids NaN and infinities: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_72
    :goto_72
    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    iget v2, p0, Lc5/b;->r:I

    if-lez v2, :cond_83

    iget-object v3, p0, Lc5/b;->t:[I

    add-int/lit8 v2, v2, -0x1

    aget v4, v3, v2

    add-int/lit8 v4, v4, 0x1

    aput v4, v3, v2

    :cond_83
    return-wide v0
.end method

.method public nextInt()I
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NUMBER:LBk/b;

    if-eq v0, v1, :cond_30

    sget-object v2, LBk/b;->STRING:LBk/b;

    if-ne v0, v2, :cond_d

    goto :goto_30

    :cond_d
    new-instance v2, Ljava/lang/IllegalStateException;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Expected "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " but was "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-direct {p0}, Lc5/b;->o()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_30
    :goto_30
    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_3f

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    goto :goto_47

    :cond_3f
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    :goto_47
    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    iget v1, p0, Lc5/b;->r:I

    if-lez v1, :cond_58

    iget-object v2, p0, Lc5/b;->t:[I

    add-int/lit8 v1, v1, -0x1

    aget v3, v2, v1

    add-int/lit8 v3, v3, 0x1

    aput v3, v2, v1

    :cond_58
    return v0
.end method

.method public nextLong()J
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NUMBER:LBk/b;

    if-eq v0, v1, :cond_30

    sget-object v2, LBk/b;->STRING:LBk/b;

    if-ne v0, v2, :cond_d

    goto :goto_30

    :cond_d
    new-instance v2, Ljava/lang/IllegalStateException;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Expected "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " but was "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-direct {p0}, Lc5/b;->o()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_30
    :goto_30
    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_3f

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    goto :goto_47

    :cond_3f
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    :goto_47
    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    iget v2, p0, Lc5/b;->r:I

    if-lez v2, :cond_58

    iget-object v3, p0, Lc5/b;->t:[I

    add-int/lit8 v2, v2, -0x1

    aget v4, v3, v2

    add-int/lit8 v4, v4, 0x1

    aput v4, v3, v2

    :cond_58
    return-wide v0
.end method

.method public nextName()Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->NAME:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Iterator;

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, Lc5/b;->s:[Ljava/lang/String;

    iget v3, p0, Lc5/b;->r:I

    add-int/lit8 v3, v3, -0x1

    aput-object v1, v2, v3

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-direct {p0, v0}, Lc5/b;->j0(Ljava/lang/Object;)V

    return-object v1
.end method

.method public nextNull()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->NULL:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    iget v0, p0, Lc5/b;->r:I

    if-lez v0, :cond_16

    iget-object v1, p0, Lc5/b;->t:[I

    add-int/lit8 v0, v0, -0x1

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    :cond_16
    return-void
.end method

.method public nextString()Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->STRING:LBk/b;

    if-eq v0, v1, :cond_30

    sget-object v2, LBk/b;->NUMBER:LBk/b;

    if-ne v0, v2, :cond_d

    goto :goto_30

    :cond_d
    new-instance v2, Ljava/lang/IllegalStateException;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Expected "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " but was "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-direct {p0}, Lc5/b;->o()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_30
    :goto_30
    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Lc5/b;->r:I

    if-lez v1, :cond_46

    iget-object v2, p0, Lc5/b;->t:[I

    add-int/lit8 v1, v1, -0x1

    aget v3, v2, v1

    add-int/lit8 v3, v3, 0x1

    aput v3, v2, v1

    :cond_46
    return-object v0
.end method

.method public peek()LBk/b;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, Lc5/b;->r:I

    if-nez v0, :cond_7

    sget-object v0, LBk/b;->END_DOCUMENT:LBk/b;

    return-object v0

    :cond_7
    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_10

    sget-object v0, LBk/b;->NULL:LBk/b;

    return-object v0

    :cond_10
    instance-of v1, v0, Ljava/util/Iterator;

    if-eqz v1, :cond_3f

    iget-object v1, p0, Lc5/b;->q:[Ljava/lang/Object;

    iget v2, p0, Lc5/b;->r:I

    add-int/lit8 v2, v2, -0x2

    aget-object v1, v1, v2

    instance-of v1, v1, Ljava/util/Map;

    check-cast v0, Ljava/util/Iterator;

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_37

    if-eqz v1, :cond_2b

    sget-object v0, LBk/b;->NAME:LBk/b;

    return-object v0

    :cond_2b
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-direct {p0, v0}, Lc5/b;->j0(Ljava/lang/Object;)V

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    return-object v0

    :cond_37
    if-eqz v1, :cond_3c

    sget-object v0, LBk/b;->END_OBJECT:LBk/b;

    goto :goto_3e

    :cond_3c
    sget-object v0, LBk/b;->END_ARRAY:LBk/b;

    :goto_3e
    return-object v0

    :cond_3f
    instance-of v1, v0, Ljava/util/Map;

    if-eqz v1, :cond_46

    sget-object v0, LBk/b;->BEGIN_OBJECT:LBk/b;

    return-object v0

    :cond_46
    instance-of v1, v0, Ljava/util/List;

    if-eqz v1, :cond_4d

    sget-object v0, LBk/b;->BEGIN_ARRAY:LBk/b;

    return-object v0

    :cond_4d
    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_54

    sget-object v0, LBk/b;->STRING:LBk/b;

    return-object v0

    :cond_54
    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_5b

    sget-object v0, LBk/b;->NUMBER:LBk/b;

    return-object v0

    :cond_5b
    instance-of v1, v0, Ljava/lang/Boolean;

    if-eqz v1, :cond_62

    sget-object v0, LBk/b;->BOOLEAN:LBk/b;

    return-object v0

    :cond_62
    sget-object v1, Lc5/b;->v:Ljava/lang/Object;

    if-ne v0, v1, :cond_6e

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "JsonReader is closed"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_6e
    new-instance v0, Ljava/lang/AssertionError;

    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    throw v0
.end method

.method public promoteName(Ljava/lang/String;)V
    .registers 6

    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/util/Iterator;

    if-eqz v1, :cond_3e

    check-cast v0, Ljava/util/Iterator;

    new-instance v1, Lcom/google/gson/internal/LinkedTreeMap;

    invoke-direct {v1}, Lcom/google/gson/internal/LinkedTreeMap;-><init>()V

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v2}, Lcom/google/gson/internal/LinkedTreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v3, v2}, Lcom/google/gson/internal/LinkedTreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_13

    :cond_2d
    invoke-virtual {v1, p1}, Lcom/google/gson/internal/LinkedTreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v1}, Lcom/google/gson/internal/LinkedTreeMap;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    invoke-direct {p0, p1}, Lc5/b;->j0(Ljava/lang/Object;)V

    :cond_3e
    return-void
.end method

.method public promoteNameToValue()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    sget-object v0, LBk/b;->NAME:LBk/b;

    invoke-direct {p0, v0}, Lc5/b;->c0(LBk/b;)V

    invoke-direct {p0}, Lc5/b;->d0()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Iterator;

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    invoke-direct {p0, v1}, Lc5/b;->j0(Ljava/lang/Object;)V

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    invoke-direct {p0, v0}, Lc5/b;->j0(Ljava/lang/Object;)V

    return-void
.end method

.method public skipValue()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lc5/b;->peek()LBk/b;

    move-result-object v0

    sget-object v1, LBk/b;->NAME:LBk/b;

    const-string v2, "null"

    if-ne v0, v1, :cond_16

    invoke-virtual {p0}, Lc5/b;->nextName()Ljava/lang/String;

    iget-object v0, p0, Lc5/b;->s:[Ljava/lang/String;

    iget v1, p0, Lc5/b;->r:I

    add-int/lit8 v1, v1, -0x2

    aput-object v2, v0, v1

    goto :goto_23

    :cond_16
    invoke-direct {p0}, Lc5/b;->f0()Ljava/lang/Object;

    iget v0, p0, Lc5/b;->r:I

    if-lez v0, :cond_23

    iget-object v1, p0, Lc5/b;->s:[Ljava/lang/String;

    add-int/lit8 v0, v0, -0x1

    aput-object v2, v1, v0

    :cond_23
    :goto_23
    iget v0, p0, Lc5/b;->r:I

    if-lez v0, :cond_31

    iget-object v1, p0, Lc5/b;->t:[I

    add-int/lit8 v0, v0, -0x1

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    :cond_31
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    const-class v0, Lc5/b;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
