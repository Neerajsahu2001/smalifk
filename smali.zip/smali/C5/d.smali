.class public final Lc5/d;
.super Ljava/lang/Object;
.source "ReadableMapIterator.java"

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc5/d$b;,
        Lc5/d$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "Ljava/util/Map$Entry<",
        "Ljava/lang/String;",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field private a:Lcom/facebook/react/bridge/ReadableMap;

.field private b:Lcom/facebook/react/bridge/ReadableMapKeySetIterator;


# direct methods
.method public constructor <init>(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc5/d;->a:Lcom/facebook/react/bridge/ReadableMap;

    if-eqz p1, :cond_c

    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableMap;->keySetIterator()Lcom/facebook/react/bridge/ReadableMapKeySetIterator;

    move-result-object p1

    goto :goto_d

    :cond_c
    const/4 p1, 0x0

    :goto_d
    iput-object p1, p0, Lc5/d;->b:Lcom/facebook/react/bridge/ReadableMapKeySetIterator;

    return-void
.end method


# virtual methods
.method final a(Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Lc5/d;->b:Lcom/facebook/react/bridge/ReadableMapKeySetIterator;

    if-eqz v0, :cond_b

    new-instance v1, Lc5/d$c;

    invoke-direct {v1, p1, v0}, Lc5/d$c;-><init>(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMapKeySetIterator;)V

    iput-object v1, p0, Lc5/d;->b:Lcom/facebook/react/bridge/ReadableMapKeySetIterator;

    :cond_b
    return-void
.end method

.method public hasNext()Z
    .registers 2

    iget-object v0, p0, Lc5/d;->b:Lcom/facebook/react/bridge/ReadableMapKeySetIterator;

    if-eqz v0, :cond_c

    invoke-interface {v0}, Lcom/facebook/react/bridge/ReadableMapKeySetIterator;->hasNextKey()Z

    move-result v0

    if-eqz v0, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, Lc5/d;->next()Ljava/util/Map$Entry;

    move-result-object v0

    return-object v0
.end method

.method public next()Ljava/util/Map$Entry;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lc5/d;->a:Lcom/facebook/react/bridge/ReadableMap;

    if-eqz v0, :cond_16

    iget-object v1, p0, Lc5/d;->b:Lcom/facebook/react/bridge/ReadableMapKeySetIterator;

    if-eqz v1, :cond_16

    new-instance v2, Lc5/d$b;

    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableMapKeySetIterator;->nextKey()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v1, v2, Lc5/d$b;->a:Ljava/lang/String;

    iput-object v0, v2, Lc5/d$b;->b:Lcom/facebook/react/bridge/ReadableMap;

    return-object v2

    :cond_16
    new-instance v0, Ljava/util/NoSuchElementException;

    const-string v1, "map null or no element"

    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
