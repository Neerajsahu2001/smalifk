.class public final Lc5/c;
.super Ljava/lang/Object;
.source "ReadableArrayIterator.java"

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field private a:Lcom/facebook/react/bridge/ReadableArray;

.field private b:I


# direct methods
.method public constructor <init>(Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lc5/c;->b:I

    iput-object p1, p0, Lc5/c;->a:Lcom/facebook/react/bridge/ReadableArray;

    return-void
.end method


# virtual methods
.method public hasNext()Z
    .registers 4

    iget v0, p0, Lc5/c;->b:I

    const/4 v1, 0x0

    iget-object v2, p0, Lc5/c;->a:Lcom/facebook/react/bridge/ReadableArray;

    if-eqz v2, :cond_c

    invoke-interface {v2}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    move-result v2

    goto :goto_d

    :cond_c
    const/4 v2, 0x0

    :goto_d
    if-ge v0, v2, :cond_10

    const/4 v1, 0x1

    :cond_10
    return v1
.end method

.method public next()Ljava/lang/Object;
    .registers 5

    const/4 v0, 0x0

    iget-object v1, p0, Lc5/c;->a:Lcom/facebook/react/bridge/ReadableArray;

    if-eqz v1, :cond_47

    sget-object v2, Lc5/c$a;->a:[I

    iget v3, p0, Lc5/c;->b:I

    invoke-interface {v1, v3}, Lcom/facebook/react/bridge/ReadableArray;->getType(I)Lcom/facebook/react/bridge/ReadableType;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v2, v2, v3

    packed-switch v2, :pswitch_data_48

    goto :goto_41

    :pswitch_17
    iget v0, p0, Lc5/c;->b:I

    invoke-interface {v1, v0}, Lcom/facebook/react/bridge/ReadableArray;->getArray(I)Lcom/facebook/react/bridge/ReadableArray;

    move-result-object v0

    goto :goto_41

    :pswitch_1e
    iget v0, p0, Lc5/c;->b:I

    invoke-interface {v1, v0}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    move-result-object v0

    goto :goto_41

    :pswitch_25
    iget v0, p0, Lc5/c;->b:I

    invoke-interface {v1, v0}, Lcom/facebook/react/bridge/ReadableArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_41

    :pswitch_2c
    iget v0, p0, Lc5/c;->b:I

    invoke-interface {v1, v0}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    goto :goto_41

    :pswitch_37
    iget v0, p0, Lc5/c;->b:I

    invoke-interface {v1, v0}, Lcom/facebook/react/bridge/ReadableArray;->getBoolean(I)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    :goto_41
    :pswitch_41
    iget v1, p0, Lc5/c;->b:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lc5/c;->b:I

    :cond_47
    return-object v0

    :pswitch_data_48
    .packed-switch 0x1
        :pswitch_41
        :pswitch_37
        :pswitch_2c
        :pswitch_25
        :pswitch_1e
        :pswitch_17
    .end packed-switch
.end method
