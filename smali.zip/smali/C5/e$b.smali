.class public final Lc5/e$b;
.super Lcom/google/gson/internal/p;
.source "ReadableMapReader.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc5/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field b:Lcom/google/gson/internal/p;


# virtual methods
.method public promoteNameToValue(LBk/a;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    instance-of v0, p1, Lc5/e;

    if-eqz v0, :cond_a

    check-cast p1, Lc5/e;

    invoke-virtual {p1}, Lc5/e;->promoteNameToValue()V

    goto :goto_f

    :cond_a
    iget-object v0, p0, Lc5/e$b;->b:Lcom/google/gson/internal/p;

    invoke-virtual {v0, p1}, Lcom/google/gson/internal/p;->promoteNameToValue(LBk/a;)V

    :goto_f
    return-void
.end method
