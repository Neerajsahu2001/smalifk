.class public final Lc5/f;
.super LBk/c;
.source "WritableMapJsonWriter.java"


# static fields
.field private static final p:Ljava/io/Writer;


# instance fields
.field private final l:Ljava/util/ArrayList;

.field private final m:Ljava/util/ArrayList;

.field private n:Ljava/lang/String;

.field private o:Lcom/facebook/react/bridge/WritableNativeMap;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lc5/f$a;

    invoke-direct {v0}, Lc5/f$a;-><init>()V

    sput-object v0, Lc5/f;->p:Ljava/io/Writer;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    sget-object v0, Lc5/f;->p:Ljava/io/Writer;

    invoke-direct {p0, v0}, LBk/c;-><init>(Ljava/io/Writer;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc5/f;->m:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lc5/f;->o:Lcom/facebook/react/bridge/WritableNativeMap;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, LBk/c;->setSerializeNulls(Z)V

    return-void
.end method

.method private N()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    const/4 v1, 0x1

    invoke-static {v0, v1}, LS/a;->b(Ljava/util/ArrayList;I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public beginArray()LBk/c;
    .registers 5

    new-instance v0, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-direct {v0}, Lcom/facebook/react/bridge/WritableNativeArray;-><init>()V

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    iget-object v2, p0, Lc5/f;->l:Ljava/util/ArrayList;

    if-eqz v1, :cond_14

    iget-object v3, p0, Lc5/f;->m:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    iput-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_1a

    :cond_14
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1e

    :goto_1a
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object p0

    :cond_1e
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Top level has to be an object"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public beginObject()LBk/c;
    .registers 5

    new-instance v0, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-direct {v0}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    iget-object v2, p0, Lc5/f;->l:Ljava/util/ArrayList;

    if-eqz v1, :cond_14

    iget-object v3, p0, Lc5/f;->m:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    iput-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_1c

    :cond_14
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1c

    iput-object v0, p0, Lc5/f;->o:Lcom/facebook/react/bridge/WritableNativeMap;

    :cond_1c
    :goto_1c
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object p0
.end method

.method public close()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_e

    const-string v1, "closed"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_e
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Incomplete document"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public endArray()LBk/c;
    .registers 5

    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5b

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    if-nez v1, :cond_5b

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Lcom/facebook/react/bridge/WritableNativeArray;

    if-eqz v2, :cond_55

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    instance-of v2, v0, Lcom/facebook/react/bridge/WritableNativeMap;

    if-eqz v2, :cond_49

    iget-object v2, p0, Lc5/f;->m:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_41

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    check-cast v1, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {v0, v2, v1}, Lcom/facebook/react/bridge/WritableNativeMap;->putArray(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V

    goto :goto_54

    :cond_41
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "pendingName is missing"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_49
    instance-of v2, v0, Lcom/facebook/react/bridge/WritableNativeArray;

    if-eqz v2, :cond_54

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    check-cast v1, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {v0, v1}, Lcom/facebook/react/bridge/WritableNativeArray;->pushArray(Lcom/facebook/react/bridge/ReadableArray;)V

    :cond_54
    :goto_54
    return-object p0

    :cond_55
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0

    :cond_5b
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0
.end method

.method public endObject()LBk/c;
    .registers 5

    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_59

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    if-nez v1, :cond_59

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Lcom/facebook/react/bridge/WritableNativeMap;

    if-eqz v2, :cond_53

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_52

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    instance-of v2, v0, Lcom/facebook/react/bridge/WritableNativeMap;

    if-eqz v2, :cond_47

    iget-object v2, p0, Lc5/f;->m:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_52

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    check-cast v1, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-virtual {v0, v2, v1}, Lcom/facebook/react/bridge/WritableNativeMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    goto :goto_52

    :cond_47
    instance-of v2, v0, Lcom/facebook/react/bridge/WritableNativeArray;

    if-eqz v2, :cond_52

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    check-cast v1, Lcom/facebook/react/bridge/WritableNativeMap;

    invoke-virtual {v0, v1}, Lcom/facebook/react/bridge/WritableNativeArray;->pushMap(Lcom/facebook/react/bridge/ReadableMap;)V

    :cond_52
    :goto_52
    return-object p0

    :cond_53
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0

    :cond_59
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0
.end method

.method public flush()V
    .registers 1

    return-void
.end method

.method public get()Lcom/facebook/react/bridge/WritableNativeMap;
    .registers 5

    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_b

    iget-object v0, p0, Lc5/f;->o:Lcom/facebook/react/bridge/WritableNativeMap;

    return-object v0

    :cond_b
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Expected one JSON element but was "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public name(Ljava/lang/String;)LBk/c;
    .registers 3

    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1d

    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    if-nez v0, :cond_1d

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Lcom/facebook/react/bridge/WritableNativeMap;

    if-eqz v0, :cond_17

    iput-object p1, p0, Lc5/f;->n:Ljava/lang/String;

    return-object p0

    :cond_17
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    throw p1

    :cond_1d
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    throw p1
.end method

.method public nullValue()LBk/c;
    .registers 4

    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    const/4 v1, 0x0

    if-eqz v0, :cond_13

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    iget-object v2, p0, Lc5/f;->n:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lcom/facebook/react/bridge/WritableNativeMap;->putNull(Ljava/lang/String;)V

    iput-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_27

    :cond_13
    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1e

    iput-object v1, p0, Lc5/f;->o:Lcom/facebook/react/bridge/WritableNativeMap;

    goto :goto_27

    :cond_1e
    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {v0}, Lcom/facebook/react/bridge/WritableNativeArray;->pushNull()V

    :goto_27
    return-object p0
.end method

.method public value(D)LBk/c;
    .registers 6

    invoke-virtual {p0}, LBk/c;->isLenient()Z

    move-result v0

    if-nez v0, :cond_27

    invoke-static {p1, p2}, Ljava/lang/Double;->isNaN(D)Z

    move-result v0

    if-nez v0, :cond_13

    invoke-static {p1, p2}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v0

    if-nez v0, :cond_13

    goto :goto_27

    :cond_13
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "JSON forbids NaN and infinities: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_27
    :goto_27
    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    if-eqz v0, :cond_3a

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    invoke-virtual {v0, v1, p1, p2}, Lcom/facebook/react/bridge/WritableNativeMap;->putDouble(Ljava/lang/String;D)V

    const/4 p1, 0x0

    iput-object p1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_4b

    :cond_3a
    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4c

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {v0, p1, p2}, Lcom/facebook/react/bridge/WritableNativeArray;->pushDouble(D)V

    :goto_4b
    return-object p0

    :cond_4c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public value(J)LBk/c;
    .registers 5

    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    if-eqz v0, :cond_14

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    long-to-double p1, p1

    invoke-virtual {v0, v1, p1, p2}, Lcom/facebook/react/bridge/WritableNativeMap;->putDouble(Ljava/lang/String;D)V

    const/4 p1, 0x0

    iput-object p1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_26

    :cond_14
    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_27

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    long-to-double p1, p1

    invoke-virtual {v0, p1, p2}, Lcom/facebook/react/bridge/WritableNativeArray;->pushDouble(D)V

    :goto_26
    return-object p0

    :cond_27
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public value(Ljava/lang/Boolean;)LBk/c;
    .registers 4

    if-nez p1, :cond_7

    invoke-virtual {p0}, Lc5/f;->nullValue()LBk/c;

    move-result-object p1

    return-object p1

    :cond_7
    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    if-eqz v0, :cond_1e

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    invoke-virtual {v0, v1, p1}, Lcom/facebook/react/bridge/WritableNativeMap;->putBoolean(Ljava/lang/String;Z)V

    const/4 p1, 0x0

    iput-object p1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_33

    :cond_1e
    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_34

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    invoke-virtual {v0, p1}, Lcom/facebook/react/bridge/WritableNativeArray;->pushBoolean(Z)V

    :goto_33
    return-object p0

    :cond_34
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public value(Ljava/lang/Number;)LBk/c;
    .registers 6

    if-nez p1, :cond_7

    invoke-virtual {p0}, Lc5/f;->nullValue()LBk/c;

    move-result-object p1

    return-object p1

    :cond_7
    invoke-virtual {p0}, LBk/c;->isLenient()Z

    move-result v0

    if-nez v0, :cond_32

    invoke-virtual {p1}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    move-result v2

    if-nez v2, :cond_1e

    invoke-static {v0, v1}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v0

    if-nez v0, :cond_1e

    goto :goto_32

    :cond_1e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "JSON forbids NaN and infinities: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_32
    :goto_32
    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    if-eqz v0, :cond_49

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lcom/facebook/react/bridge/WritableNativeMap;->putDouble(Ljava/lang/String;D)V

    const/4 p1, 0x0

    iput-object p1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_5e

    :cond_49
    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5f

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {p1}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lcom/facebook/react/bridge/WritableNativeArray;->pushDouble(D)V

    :goto_5e
    return-object p0

    :cond_5f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public value(Ljava/lang/String;)LBk/c;
    .registers 4

    if-nez p1, :cond_7

    invoke-virtual {p0}, Lc5/f;->nullValue()LBk/c;

    move-result-object p1

    return-object p1

    :cond_7
    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    if-eqz v0, :cond_1a

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Lcom/facebook/react/bridge/WritableNativeMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    iput-object p1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_2b

    :cond_1a
    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2c

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {v0, p1}, Lcom/facebook/react/bridge/WritableNativeArray;->pushString(Ljava/lang/String;)V

    :goto_2b
    return-object p0

    :cond_2c
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    throw p1
.end method

.method public value(Z)LBk/c;
    .registers 4

    iget-object v0, p0, Lc5/f;->n:Ljava/lang/String;

    if-eqz v0, :cond_13

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeMap;

    iget-object v1, p0, Lc5/f;->n:Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Lcom/facebook/react/bridge/WritableNativeMap;->putBoolean(Ljava/lang/String;Z)V

    const/4 p1, 0x0

    iput-object p1, p0, Lc5/f;->n:Ljava/lang/String;

    goto :goto_24

    :cond_13
    iget-object v0, p0, Lc5/f;->l:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_25

    invoke-direct {p0}, Lc5/f;->N()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/facebook/react/bridge/WritableNativeArray;

    invoke-virtual {v0, p1}, Lcom/facebook/react/bridge/WritableNativeArray;->pushBoolean(Z)V

    :goto_24
    return-object p0

    :cond_25
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method
