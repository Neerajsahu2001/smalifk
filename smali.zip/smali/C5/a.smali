.class public final Lc5/a;
.super Ljava/lang/Object;
.source "GsonHelper.java"


# direct methods
.method public static getConfigSerializer(Landroid/content/Context;)Lp7/h;
    .registers 1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    check-cast p0, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {p0}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigSerializer()Lp7/h;

    move-result-object p0

    return-object p0
.end method

.method public static getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;
    .registers 2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    instance-of v0, v0, Lcom/flipkart/android/init/FlipkartApplication;

    if-eqz v0, :cond_13

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    check-cast p0, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {p0}, Lcom/flipkart/android/init/FlipkartApplication;->getSerializer()Lcom/flipkart/android/gson/Serializer;

    move-result-object p0

    return-object p0

    :cond_13
    new-instance v0, Lcom/flipkart/android/gson/Serializer;

    invoke-direct {v0, p0}, Lcom/flipkart/android/gson/Serializer;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public static toJson(Lxk/j;Lxk/z;Ljava/lang/Object;)Ljava/lang/String;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lxk/j;",
            "Lxk/z<",
            "TT;>;TT;)",
            "Ljava/lang/String;"
        }
    .end annotation

    new-instance v0, Ljava/io/StringWriter;

    invoke-direct {v0}, Ljava/io/StringWriter;-><init>()V

    :try_start_5
    invoke-virtual {p0, v0}, Lxk/j;->k(Ljava/io/Writer;)LBk/c;

    move-result-object p0

    invoke-virtual {p1, p0, p2}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_c} :catch_d

    goto :goto_11

    :catch_d
    move-exception p0

    invoke-static {p0}, Lpa/a;->printStackTrace(Ljava/lang/Throwable;)V

    :goto_11
    invoke-virtual {v0}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static toJsonTree(Lxk/z;Ljava/lang/Object;)Lxk/p;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lxk/z<",
            "TT;>;TT;)",
            "Lxk/p;"
        }
    .end annotation

    :try_start_0
    new-instance v0, Lcom/google/gson/internal/bind/b;

    invoke-direct {v0}, Lcom/google/gson/internal/bind/b;-><init>()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, LBk/c;->setSerializeNulls(Z)V

    invoke-virtual {p0, v0, p1}, Lxk/z;->write(LBk/c;Ljava/lang/Object;)V

    invoke-virtual {v0}, Lcom/google/gson/internal/bind/b;->N()Lxk/p;

    move-result-object p0
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_10} :catch_11

    return-object p0

    :catch_11
    move-exception p0

    invoke-static {p0}, Lpa/a;->printStackTrace(Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return-object p0
.end method
