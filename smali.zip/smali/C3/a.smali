.class public final Lc3/a;
.super Ljava/lang/Object;
.source "DraweeHolder.java"

# interfaces
.implements Lcom/facebook/drawee/drawable/v;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<DH::",
        "Lb3/b;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/facebook/drawee/drawable/v;"
    }
.end annotation


# instance fields
.field private a:Z

.field private b:Z

.field private c:Z

.field private d:Lb3/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TDH;"
        }
    .end annotation
.end field

.field private e:Lb3/a;

.field private final f:LW2/c;


# direct methods
.method public constructor <init>(La3/a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc3/a;->a:Z

    iput-boolean v0, p0, Lc3/a;->b:Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc3/a;->c:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lc3/a;->e:Lb3/a;

    invoke-static {}, LW2/c;->a()LW2/c;

    move-result-object v0

    iput-object v0, p0, Lc3/a;->f:LW2/c;

    if-eqz p1, :cond_19

    invoke-virtual {p0, p1}, Lc3/a;->n(La3/a;)V

    :cond_19
    return-void
.end method

.method private a()V
    .registers 3

    iget-boolean v0, p0, Lc3/a;->a:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Lc3/a;->f:LW2/c;

    sget-object v1, LW2/c$a;->ON_ATTACH_CONTROLLER:LW2/c$a;

    invoke-virtual {v0, v1}, LW2/c;->b(LW2/c$a;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc3/a;->a:Z

    iget-object v0, p0, Lc3/a;->e:Lb3/a;

    if-eqz v0, :cond_22

    check-cast v0, LX2/a;

    invoke-virtual {v0}, LX2/a;->l()Lb3/c;

    move-result-object v0

    if-eqz v0, :cond_22

    iget-object v0, p0, Lc3/a;->e:Lb3/a;

    check-cast v0, LX2/a;

    invoke-virtual {v0}, LX2/a;->x()V

    :cond_22
    return-void
.end method

.method private b()V
    .registers 2

    iget-boolean v0, p0, Lc3/a;->b:Z

    if-eqz v0, :cond_c

    iget-boolean v0, p0, Lc3/a;->c:Z

    if-eqz v0, :cond_c

    invoke-direct {p0}, Lc3/a;->a()V

    goto :goto_f

    :cond_c
    invoke-direct {p0}, Lc3/a;->c()V

    :goto_f
    return-void
.end method

.method private c()V
    .registers 3

    iget-boolean v0, p0, Lc3/a;->a:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Lc3/a;->f:LW2/c;

    sget-object v1, LW2/c$a;->ON_DETACH_CONTROLLER:LW2/c$a;

    invoke-virtual {v0, v1}, LW2/c;->b(LW2/c$a;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc3/a;->a:Z

    invoke-virtual {p0}, Lc3/a;->g()Z

    move-result v0

    if-eqz v0, :cond_1c

    iget-object v0, p0, Lc3/a;->e:Lb3/a;

    check-cast v0, LX2/a;

    invoke-virtual {v0}, LX2/a;->z()V

    :cond_1c
    return-void
.end method


# virtual methods
.method public final d()Lb3/a;
    .registers 2

    iget-object v0, p0, Lc3/a;->e:Lb3/a;

    return-object v0
.end method

.method public final e()Lb3/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TDH;"
        }
    .end annotation

    iget-object v0, p0, Lc3/a;->d:Lb3/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0
.end method

.method public final f()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, Lc3/a;->d:Lb3/b;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_a

    :cond_6
    invoke-interface {v0}, Lb3/b;->b()La3/d;

    move-result-object v0

    :goto_a
    return-object v0
.end method

.method public final g()Z
    .registers 3

    iget-object v0, p0, Lc3/a;->e:Lb3/a;

    if-eqz v0, :cond_10

    check-cast v0, LX2/a;

    invoke-virtual {v0}, LX2/a;->l()Lb3/c;

    move-result-object v0

    iget-object v1, p0, Lc3/a;->d:Lb3/b;

    if-ne v0, v1, :cond_10

    const/4 v0, 0x1

    goto :goto_11

    :cond_10
    const/4 v0, 0x0

    :goto_11
    return v0
.end method

.method public final h()V
    .registers 3

    iget-object v0, p0, Lc3/a;->f:LW2/c;

    sget-object v1, LW2/c$a;->ON_HOLDER_ATTACH:LW2/c$a;

    invoke-virtual {v0, v1}, LW2/c;->b(LW2/c$a;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc3/a;->b:Z

    invoke-direct {p0}, Lc3/a;->b()V

    return-void
.end method

.method public final i()V
    .registers 3

    iget-object v0, p0, Lc3/a;->f:LW2/c;

    sget-object v1, LW2/c$a;->ON_HOLDER_DETACH:LW2/c$a;

    invoke-virtual {v0, v1}, LW2/c;->b(LW2/c$a;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc3/a;->b:Z

    invoke-direct {p0}, Lc3/a;->b()V

    return-void
.end method

.method public final j()V
    .registers 7

    const/4 v0, 0x1

    iget-boolean v1, p0, Lc3/a;->a:Z

    if-eqz v1, :cond_6

    return-void

    :cond_6
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Lc3/a;->e:Lb3/a;

    invoke-static {v2}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {p0}, Lc3/a;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x3

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v1, v4, v5

    aput-object v2, v4, v0

    const/4 v1, 0x2

    aput-object v3, v4, v1

    const-class v1, LW2/c;

    const-string v2, "%x: Draw requested for a non-attached controller %x. %s"

    invoke-static {v1, v2, v4}, LE2/a;->y(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V

    iput-boolean v0, p0, Lc3/a;->b:Z

    iput-boolean v0, p0, Lc3/a;->c:Z

    invoke-direct {p0}, Lc3/a;->b()V

    return-void
.end method

.method public final k(Landroid/view/MotionEvent;)Z
    .registers 3

    invoke-virtual {p0}, Lc3/a;->g()Z

    move-result v0

    if-nez v0, :cond_8

    const/4 p1, 0x0

    return p1

    :cond_8
    iget-object v0, p0, Lc3/a;->e:Lb3/a;

    check-cast v0, LX2/a;

    invoke-virtual {v0, p1}, LX2/a;->D(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public final l(Z)V
    .registers 4

    iget-boolean v0, p0, Lc3/a;->c:Z

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    if-eqz p1, :cond_a

    sget-object v0, LW2/c$a;->ON_DRAWABLE_SHOW:LW2/c$a;

    goto :goto_c

    :cond_a
    sget-object v0, LW2/c$a;->ON_DRAWABLE_HIDE:LW2/c$a;

    :goto_c
    iget-object v1, p0, Lc3/a;->f:LW2/c;

    invoke-virtual {v1, v0}, LW2/c;->b(LW2/c$a;)V

    iput-boolean p1, p0, Lc3/a;->c:Z

    invoke-direct {p0}, Lc3/a;->b()V

    return-void
.end method

.method public final m(LX2/a;)V
    .registers 6

    iget-boolean v0, p0, Lc3/a;->a:Z

    if-eqz v0, :cond_7

    invoke-direct {p0}, Lc3/a;->c()V

    :cond_7
    invoke-virtual {p0}, Lc3/a;->g()Z

    move-result v1

    iget-object v2, p0, Lc3/a;->f:LW2/c;

    if-eqz v1, :cond_1a

    sget-object v1, LW2/c$a;->ON_CLEAR_OLD_CONTROLLER:LW2/c$a;

    invoke-virtual {v2, v1}, LW2/c;->b(LW2/c$a;)V

    iget-object v1, p0, Lc3/a;->e:Lb3/a;

    const/4 v3, 0x0

    invoke-interface {v1, v3}, Lb3/a;->a(Lb3/b;)V

    :cond_1a
    iput-object p1, p0, Lc3/a;->e:Lb3/a;

    if-eqz p1, :cond_2b

    sget-object p1, LW2/c$a;->ON_SET_CONTROLLER:LW2/c$a;

    invoke-virtual {v2, p1}, LW2/c;->b(LW2/c$a;)V

    iget-object p1, p0, Lc3/a;->e:Lb3/a;

    iget-object v1, p0, Lc3/a;->d:Lb3/b;

    invoke-interface {p1, v1}, Lb3/a;->a(Lb3/b;)V

    goto :goto_30

    :cond_2b
    sget-object p1, LW2/c$a;->ON_CLEAR_CONTROLLER:LW2/c$a;

    invoke-virtual {v2, p1}, LW2/c;->b(LW2/c$a;)V

    :goto_30
    if-eqz v0, :cond_35

    invoke-direct {p0}, Lc3/a;->a()V

    :cond_35
    return-void
.end method

.method public final n(La3/a;)V
    .registers 5

    iget-object v0, p0, Lc3/a;->f:LW2/c;

    sget-object v1, LW2/c$a;->ON_SET_HIERARCHY:LW2/c$a;

    invoke-virtual {v0, v1}, LW2/c;->b(LW2/c$a;)V

    invoke-virtual {p0}, Lc3/a;->g()Z

    move-result v0

    invoke-virtual {p0}, Lc3/a;->f()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    instance-of v2, v1, Lcom/facebook/drawee/drawable/u;

    if-eqz v2, :cond_19

    check-cast v1, Lcom/facebook/drawee/drawable/u;

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Lcom/facebook/drawee/drawable/u;->f(Lcom/facebook/drawee/drawable/v;)V

    :cond_19
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lc3/a;->d:Lb3/b;

    invoke-virtual {p1}, La3/a;->b()La3/d;

    move-result-object v1

    if-eqz v1, :cond_2d

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v1

    if-eqz v1, :cond_2b

    goto :goto_2d

    :cond_2b
    const/4 v1, 0x0

    goto :goto_2e

    :cond_2d
    :goto_2d
    const/4 v1, 0x1

    :goto_2e
    invoke-virtual {p0, v1}, Lc3/a;->l(Z)V

    invoke-virtual {p0}, Lc3/a;->f()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    instance-of v2, v1, Lcom/facebook/drawee/drawable/u;

    if-eqz v2, :cond_3e

    check-cast v1, Lcom/facebook/drawee/drawable/u;

    invoke-interface {v1, p0}, Lcom/facebook/drawee/drawable/u;->f(Lcom/facebook/drawee/drawable/v;)V

    :cond_3e
    if-eqz v0, :cond_45

    iget-object v0, p0, Lc3/a;->e:Lb3/a;

    invoke-interface {v0, p1}, Lb3/a;->a(Lb3/b;)V

    :cond_45
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    invoke-static {p0}, LD2/i;->b(Ljava/lang/Object;)LD2/i$a;

    move-result-object v0

    const-string v1, "controllerAttached"

    iget-boolean v2, p0, Lc3/a;->a:Z

    invoke-virtual {v0, v1, v2}, LD2/i$a;->c(Ljava/lang/String;Z)V

    const-string v1, "holderAttached"

    iget-boolean v2, p0, Lc3/a;->b:Z

    invoke-virtual {v0, v1, v2}, LD2/i$a;->c(Ljava/lang/String;Z)V

    const-string v1, "drawableVisible"

    iget-boolean v2, p0, Lc3/a;->c:Z

    invoke-virtual {v0, v1, v2}, LD2/i$a;->c(Ljava/lang/String;Z)V

    iget-object v1, p0, Lc3/a;->f:LW2/c;

    invoke-virtual {v1}, LW2/c;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "events"

    invoke-virtual {v0, v1, v2}, LD2/i$a;->b(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, LD2/i$a;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
