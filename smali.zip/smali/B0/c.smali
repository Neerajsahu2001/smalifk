.class public final Lb0/c;
.super Ljava/lang/Object;
.source "VersionTable.java"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "media3.database"

    invoke-static {v0}, Landroidx/media3/common/r;->a(Ljava/lang/String;)V

    return-void
.end method

.method public static a(Landroid/database/sqlite/SQLiteDatabase;ILjava/lang/String;)I
    .registers 14
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lb0/a;
        }
    .end annotation

    :try_start_0
    sget v0, La0/T;->a:I

    const-string v0, "ExoPlayerVersions"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const-string v1, "sqlite_master"

    const-string v2, "tbl_name = ?"

    invoke-static {p0, v1, v2, v0}, Landroid/database/DatabaseUtils;->queryNumEntries(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v0

    const-wide/16 v4, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x1

    cmp-long v7, v0, v4

    if-lez v7, :cond_1a

    const/4 v0, 0x1

    goto :goto_1b

    :cond_1a
    const/4 v0, 0x0

    :goto_1b
    const/4 v1, -0x1

    if-nez v0, :cond_1f

    return v1

    :cond_1f
    const-string v4, "ExoPlayerVersions"

    new-array v5, v6, [Ljava/lang/String;

    const-string v0, "version"

    aput-object v0, v5, v2

    const-string v6, "feature = ? AND instance_uid = ?"

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0, p2}, [Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v3, p0

    invoke-virtual/range {v3 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3
    :try_end_39
    .catch Landroid/database/SQLException; {:try_start_0 .. :try_end_39} :catch_43

    :try_start_39
    invoke-interface {v3}, Landroid/database/Cursor;->getCount()I

    move-result v0
    :try_end_3d
    .catchall {:try_start_39 .. :try_end_3d} :catchall_50

    if-nez v0, :cond_45

    :try_start_3f
    invoke-interface {v3}, Landroid/database/Cursor;->close()V
    :try_end_42
    .catch Landroid/database/SQLException; {:try_start_3f .. :try_end_42} :catch_43

    return v1

    :catch_43
    move-exception v0

    goto :goto_5e

    :cond_45
    :try_start_45
    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    invoke-interface {v3, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result v0
    :try_end_4c
    .catchall {:try_start_45 .. :try_end_4c} :catchall_50

    :try_start_4c
    invoke-interface {v3}, Landroid/database/Cursor;->close()V
    :try_end_4f
    .catch Landroid/database/SQLException; {:try_start_4c .. :try_end_4f} :catch_43

    return v0

    :catchall_50
    move-exception v0

    move-object v1, v0

    if-eqz v3, :cond_5d

    :try_start_54
    invoke-interface {v3}, Landroid/database/Cursor;->close()V
    :try_end_57
    .catchall {:try_start_54 .. :try_end_57} :catchall_58

    goto :goto_5d

    :catchall_58
    move-exception v0

    move-object v2, v0

    :try_start_5a
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_5d
    :goto_5d
    throw v1
    :try_end_5e
    .catch Landroid/database/SQLException; {:try_start_5a .. :try_end_5e} :catch_43

    :goto_5e
    new-instance v1, Lb0/a;

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method

.method public static b(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lb0/a;
        }
    .end annotation

    const-string v0, "ExoPlayerVersions"

    :try_start_2
    sget v1, La0/T;->a:I

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v1

    const-string v2, "sqlite_master"

    const-string v3, "tbl_name = ?"

    invoke-static {p0, v2, v3, v1}, Landroid/database/DatabaseUtils;->queryNumEntries(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long v5, v1, v3

    if-lez v5, :cond_27

    const-string v1, "feature = ? AND instance_uid = ?"

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2, p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v0, v1, p1}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_24
    .catch Landroid/database/SQLException; {:try_start_2 .. :try_end_24} :catch_25

    return-void

    :catch_25
    move-exception p0

    goto :goto_28

    :cond_27
    return-void

    :goto_28
    new-instance p1, Lb0/a;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method

.method public static c(Landroid/database/sqlite/SQLiteDatabase;ILjava/lang/String;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lb0/a;
        }
    .end annotation

    :try_start_0
    const-string v0, "CREATE TABLE IF NOT EXISTS ExoPlayerVersions (feature INTEGER NOT NULL,instance_uid TEXT NOT NULL,version INTEGER NOT NULL,PRIMARY KEY (feature, instance_uid))"

    invoke-virtual {p0, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const-string v1, "feature"

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string p1, "instance_uid"

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "version"

    const/4 p2, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string p1, "ExoPlayerVersions"

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2, v0}, Landroid/database/sqlite/SQLiteDatabase;->replaceOrThrow(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    :try_end_28
    .catch Landroid/database/SQLException; {:try_start_0 .. :try_end_28} :catch_29

    return-void

    :catch_29
    move-exception p0

    new-instance p1, Lb0/a;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method
