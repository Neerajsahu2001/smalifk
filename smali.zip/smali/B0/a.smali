.class public final Lb0/a;
.super Ljava/io/IOException;
.source "DatabaseIOException.java"
