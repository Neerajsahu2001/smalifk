.class public final LE1/a$a;
.super Ljava/lang/Object;
.source "LottieLoadEventData.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE1/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private a:J

.field private b:J

.field private c:J

.field private d:J

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Z


# direct methods
.method public constructor <init>(JJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 13

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LE1/a$a;->a:J

    iput-wide p3, p0, LE1/a$a;->b:J

    iput-wide p5, p0, LE1/a$a;->c:J

    iput-wide p7, p0, LE1/a$a;->d:J

    iput-object p9, p0, LE1/a$a;->e:Ljava/lang/String;

    iput-object p10, p0, LE1/a$a;->f:Ljava/lang/String;

    iput-object p11, p0, LE1/a$a;->g:Ljava/lang/String;

    iput-boolean p12, p0, LE1/a$a;->h:Z

    return-void
.end method


# virtual methods
.method public final a()LE1/a;
    .registers 14

    new-instance v0, LE1/a;

    iget-wide v1, p0, LE1/a$a;->a:J

    iget-wide v3, p0, LE1/a$a;->b:J

    iget-wide v5, p0, LE1/a$a;->c:J

    iget-wide v7, p0, LE1/a$a;->d:J

    iget-object v9, p0, LE1/a$a;->f:Ljava/lang/String;

    iget-object v10, p0, LE1/a$a;->e:Ljava/lang/String;

    iget-object v11, p0, LE1/a$a;->g:Ljava/lang/String;

    iget-boolean v12, p0, LE1/a$a;->h:Z

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-wide v1, v0, LE1/a;->a:J

    iput-wide v3, v0, LE1/a;->b:J

    iput-wide v5, v0, LE1/a;->c:J

    iput-wide v7, v0, LE1/a;->d:J

    iput-object v9, v0, LE1/a;->e:Ljava/lang/String;

    iput-object v10, v0, LE1/a;->f:Ljava/lang/String;

    iput-object v11, v0, LE1/a;->g:Ljava/lang/String;

    iput-boolean v12, v0, LE1/a;->h:Z

    return-object v0
.end method

.method public final b(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, LE1/a$a;->g:Ljava/lang/String;

    return-void
.end method

.method public final c(Ljava/lang/Long;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    iput-wide v0, p0, LE1/a$a;->c:J

    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, LE1/a$a;->f:Ljava/lang/String;

    return-void
.end method

.method public final e(Ljava/lang/Boolean;)V
    .registers 3

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    if-nez p1, :cond_5

    move-object p1, v0

    :cond_5
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iput-boolean p1, p0, LE1/a$a;->h:Z

    return-void
.end method

.method public final f(Ljava/lang/Long;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    iput-wide v0, p0, LE1/a$a;->a:J

    return-void
.end method

.method public final g(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, LE1/a$a;->e:Ljava/lang/String;

    return-void
.end method

.method public final h(Ljava/lang/Long;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    iput-wide v0, p0, LE1/a$a;->d:J

    return-void
.end method

.method public final i(Ljava/lang/Long;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    iput-wide v0, p0, LE1/a$a;->b:J

    return-void
.end method
