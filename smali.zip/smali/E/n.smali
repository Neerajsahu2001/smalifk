.class public final LE/n;
.super LE/p;
.source "ResolutionAnchor.java"


# instance fields
.field c:LE/e;

.field d:LE/n;

.field e:F

.field f:LE/n;

.field g:F

.field h:I

.field private i:LE/n;

.field private j:LE/o;

.field private k:I

.field private l:LE/o;


# direct methods
.method public constructor <init>(LE/e;)V
    .registers 4

    invoke-direct {p0}, LE/p;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, LE/n;->h:I

    const/4 v0, 0x0

    iput-object v0, p0, LE/n;->j:LE/o;

    const/4 v1, 0x1

    iput v1, p0, LE/n;->k:I

    iput-object v0, p0, LE/n;->l:LE/o;

    iput-object p1, p0, LE/n;->c:LE/e;

    return-void
.end method

.method static m(I)Ljava/lang/String;
    .registers 2

    const/4 v0, 0x1

    if-ne p0, v0, :cond_6

    const-string p0, "DIRECT"

    return-object p0

    :cond_6
    const/4 v0, 0x2

    if-ne p0, v0, :cond_c

    const-string p0, "CENTER"

    return-object p0

    :cond_c
    const/4 v0, 0x3

    if-ne p0, v0, :cond_12

    const-string p0, "MATCH"

    return-object p0

    :cond_12
    const/4 v0, 0x4

    if-ne p0, v0, :cond_18

    const-string p0, "CHAIN"

    return-object p0

    :cond_18
    const/4 v0, 0x5

    if-ne p0, v0, :cond_1e

    const-string p0, "BARRIER"

    return-object p0

    :cond_1e
    const-string p0, "UNCONNECTED"

    return-object p0
.end method


# virtual methods
.method public final e()V
    .registers 10

    iget v0, p0, LE/p;->b:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_6

    return-void

    :cond_6
    iget v0, p0, LE/n;->h:I

    const/4 v2, 0x4

    if-ne v0, v2, :cond_c

    return-void

    :cond_c
    iget-object v2, p0, LE/n;->j:LE/o;

    if-eqz v2, :cond_1e

    iget v3, v2, LE/p;->b:I

    if-eq v3, v1, :cond_15

    return-void

    :cond_15
    iget v3, p0, LE/n;->k:I

    int-to-float v3, v3

    iget v2, v2, LE/o;->c:F

    mul-float v3, v3, v2

    iput v3, p0, LE/n;->e:F

    :cond_1e
    iget-object v2, p0, LE/n;->l:LE/o;

    if-eqz v2, :cond_27

    iget v2, v2, LE/p;->b:I

    if-eq v2, v1, :cond_27

    return-void

    :cond_27
    if-ne v0, v1, :cond_4a

    iget-object v2, p0, LE/n;->d:LE/n;

    if-eqz v2, :cond_31

    iget v3, v2, LE/p;->b:I

    if-ne v3, v1, :cond_4a

    :cond_31
    if-nez v2, :cond_3a

    iput-object p0, p0, LE/n;->f:LE/n;

    iget v0, p0, LE/n;->e:F

    iput v0, p0, LE/n;->g:F

    goto :goto_45

    :cond_3a
    iget-object v0, v2, LE/n;->f:LE/n;

    iput-object v0, p0, LE/n;->f:LE/n;

    iget v0, v2, LE/n;->g:F

    iget v1, p0, LE/n;->e:F

    add-float/2addr v0, v1

    iput v0, p0, LE/n;->g:F

    :goto_45
    invoke-virtual {p0}, LE/p;->b()V

    goto/16 :goto_135

    :cond_4a
    iget-object v2, p0, LE/n;->c:LE/e;

    const/4 v3, 0x2

    if-ne v0, v3, :cond_f7

    iget-object v3, p0, LE/n;->d:LE/n;

    if-eqz v3, :cond_f7

    iget v4, v3, LE/p;->b:I

    if-ne v4, v1, :cond_f7

    iget-object v4, p0, LE/n;->i:LE/n;

    if-eqz v4, :cond_f7

    iget-object v5, v4, LE/n;->d:LE/n;

    if-eqz v5, :cond_f7

    iget v6, v5, LE/p;->b:I

    if-ne v6, v1, :cond_f7

    iget-object v0, v3, LE/n;->f:LE/n;

    iput-object v0, p0, LE/n;->f:LE/n;

    iget-object v0, v5, LE/n;->f:LE/n;

    iput-object v0, v4, LE/n;->f:LE/n;

    iget-object v0, v2, LE/e;->c:LE/e$d;

    sget-object v4, LE/e$d;->RIGHT:LE/e$d;

    const/4 v6, 0x0

    if-eq v0, v4, :cond_78

    sget-object v7, LE/e$d;->BOTTOM:LE/e$d;

    if-ne v0, v7, :cond_77

    goto :goto_78

    :cond_77
    const/4 v1, 0x0

    :cond_78
    :goto_78
    if-eqz v1, :cond_80

    iget v3, v3, LE/n;->g:F

    iget v5, v5, LE/n;->g:F

    sub-float/2addr v3, v5

    goto :goto_86

    :cond_80
    iget v5, v5, LE/n;->g:F

    iget v3, v3, LE/n;->g:F

    sub-float v3, v5, v3

    :goto_86
    sget-object v5, LE/e$d;->LEFT:LE/e$d;

    iget-object v7, v2, LE/e;->b:LE/h;

    if-eq v0, v5, :cond_98

    if-ne v0, v4, :cond_8f

    goto :goto_98

    :cond_8f
    invoke-virtual {v7}, LE/h;->n()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr v3, v0

    iget v0, v7, LE/h;->W:F

    goto :goto_a0

    :cond_98
    :goto_98
    invoke-virtual {v7}, LE/h;->v()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr v3, v0

    iget v0, v7, LE/h;->V:F

    :goto_a0
    invoke-virtual {v2}, LE/e;->c()I

    move-result v4

    iget-object v5, p0, LE/n;->i:LE/n;

    iget-object v5, v5, LE/n;->c:LE/e;

    invoke-virtual {v5}, LE/e;->c()I

    move-result v5

    iget-object v2, v2, LE/e;->d:LE/e;

    iget-object v7, p0, LE/n;->i:LE/n;

    iget-object v8, v7, LE/n;->c:LE/e;

    iget-object v8, v8, LE/e;->d:LE/e;

    if-ne v2, v8, :cond_ba

    const/high16 v0, 0x3f000000    # 0.5f

    const/4 v5, 0x0

    goto :goto_bb

    :cond_ba
    move v6, v4

    :goto_bb
    int-to-float v2, v6

    sub-float/2addr v3, v2

    int-to-float v4, v5

    sub-float/2addr v3, v4

    const/high16 v5, 0x3f800000    # 1.0f

    if-eqz v1, :cond_d9

    iget-object v1, v7, LE/n;->d:LE/n;

    iget v1, v1, LE/n;->g:F

    add-float/2addr v1, v4

    mul-float v4, v3, v0

    add-float/2addr v4, v1

    iput v4, v7, LE/n;->g:F

    iget-object v1, p0, LE/n;->d:LE/n;

    iget v1, v1, LE/n;->g:F

    sub-float/2addr v1, v2

    sub-float/2addr v5, v0

    mul-float v5, v5, v3

    sub-float/2addr v1, v5

    iput v1, p0, LE/n;->g:F

    goto :goto_ee

    :cond_d9
    iget-object v1, p0, LE/n;->d:LE/n;

    iget v1, v1, LE/n;->g:F

    add-float/2addr v1, v2

    mul-float v2, v3, v0

    add-float/2addr v2, v1

    iput v2, p0, LE/n;->g:F

    iget-object v1, v7, LE/n;->d:LE/n;

    iget v1, v1, LE/n;->g:F

    sub-float/2addr v1, v4

    sub-float/2addr v5, v0

    mul-float v5, v5, v3

    sub-float/2addr v1, v5

    iput v1, v7, LE/n;->g:F

    :goto_ee
    invoke-virtual {p0}, LE/p;->b()V

    iget-object v0, p0, LE/n;->i:LE/n;

    invoke-virtual {v0}, LE/p;->b()V

    goto :goto_135

    :cond_f7
    const/4 v3, 0x3

    if-ne v0, v3, :cond_12d

    iget-object v3, p0, LE/n;->d:LE/n;

    if-eqz v3, :cond_12d

    iget v4, v3, LE/p;->b:I

    if-ne v4, v1, :cond_12d

    iget-object v4, p0, LE/n;->i:LE/n;

    if-eqz v4, :cond_12d

    iget-object v5, v4, LE/n;->d:LE/n;

    if-eqz v5, :cond_12d

    iget v6, v5, LE/p;->b:I

    if-ne v6, v1, :cond_12d

    iget-object v0, v3, LE/n;->f:LE/n;

    iput-object v0, p0, LE/n;->f:LE/n;

    iget-object v0, v5, LE/n;->f:LE/n;

    iput-object v0, v4, LE/n;->f:LE/n;

    iget v0, v3, LE/n;->g:F

    iget v1, p0, LE/n;->e:F

    add-float/2addr v0, v1

    iput v0, p0, LE/n;->g:F

    iget v0, v5, LE/n;->g:F

    iget v1, v4, LE/n;->e:F

    add-float/2addr v0, v1

    iput v0, v4, LE/n;->g:F

    invoke-virtual {p0}, LE/p;->b()V

    iget-object v0, p0, LE/n;->i:LE/n;

    invoke-virtual {v0}, LE/p;->b()V

    goto :goto_135

    :cond_12d
    const/4 v1, 0x5

    if-ne v0, v1, :cond_135

    iget-object v0, v2, LE/e;->b:LE/h;

    invoke-virtual {v0}, LE/h;->G()V

    :cond_135
    :goto_135
    return-void
.end method

.method final f(LD/f;)V
    .registers 6

    iget-object v0, p0, LE/n;->c:LE/e;

    iget-object v0, v0, LE/e;->i:LD/i;

    iget-object v1, p0, LE/n;->f:LE/n;

    const/high16 v2, 0x3f000000    # 0.5f

    if-nez v1, :cond_12

    iget v1, p0, LE/n;->g:F

    add-float/2addr v1, v2

    float-to-int v1, v1

    invoke-virtual {p1, v0, v1}, LD/f;->d(LD/i;I)V

    goto :goto_20

    :cond_12
    iget-object v1, v1, LE/n;->c:LE/e;

    invoke-virtual {p1, v1}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v1

    iget v3, p0, LE/n;->g:F

    add-float/2addr v3, v2

    float-to-int v2, v3

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1, v2, v3}, LD/f;->e(LD/i;LD/i;II)V

    :goto_20
    return-void
.end method

.method public final g(LE/n;I)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, LE/n;->h:I

    iput-object p1, p0, LE/n;->d:LE/n;

    int-to-float p2, p2

    iput p2, p0, LE/n;->e:F

    invoke-virtual {p1, p0}, LE/p;->a(LE/p;)V

    return-void
.end method

.method public final h(LE/n;ILE/o;)V
    .registers 4

    iput-object p1, p0, LE/n;->d:LE/n;

    invoke-virtual {p1, p0}, LE/p;->a(LE/p;)V

    iput-object p3, p0, LE/n;->j:LE/o;

    iput p2, p0, LE/n;->k:I

    invoke-virtual {p3, p0}, LE/p;->a(LE/p;)V

    return-void
.end method

.method public final i(LE/n;I)V
    .registers 3

    iput-object p1, p0, LE/n;->d:LE/n;

    int-to-float p2, p2

    iput p2, p0, LE/n;->e:F

    invoke-virtual {p1, p0}, LE/p;->a(LE/p;)V

    return-void
.end method

.method public final j()F
    .registers 2

    iget v0, p0, LE/n;->g:F

    return v0
.end method

.method public final k()V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, LE/p;->b:I

    iget-object v1, p0, LE/p;->a:Ljava/util/HashSet;

    invoke-virtual {v1}, Ljava/util/HashSet;->clear()V

    const/4 v1, 0x0

    iput-object v1, p0, LE/n;->d:LE/n;

    const/4 v2, 0x0

    iput v2, p0, LE/n;->e:F

    iput-object v1, p0, LE/n;->j:LE/o;

    const/4 v3, 0x1

    iput v3, p0, LE/n;->k:I

    iput-object v1, p0, LE/n;->l:LE/o;

    iput-object v1, p0, LE/n;->f:LE/n;

    iput v2, p0, LE/n;->g:F

    iput-object v1, p0, LE/n;->i:LE/n;

    iput v0, p0, LE/n;->h:I

    return-void
.end method

.method public final l(LE/n;F)V
    .registers 5

    iget v0, p0, LE/p;->b:I

    if-eqz v0, :cond_e

    iget-object v1, p0, LE/n;->f:LE/n;

    if-eq v1, p1, :cond_1b

    iget v1, p0, LE/n;->g:F

    cmpl-float v1, v1, p2

    if-eqz v1, :cond_1b

    :cond_e
    iput-object p1, p0, LE/n;->f:LE/n;

    iput p2, p0, LE/n;->g:F

    const/4 p1, 0x1

    if-ne v0, p1, :cond_18

    invoke-virtual {p0}, LE/p;->c()V

    :cond_18
    invoke-virtual {p0}, LE/p;->b()V

    :cond_1b
    return-void
.end method

.method public final n(LE/n;)V
    .registers 2

    iput-object p1, p0, LE/n;->i:LE/n;

    return-void
.end method

.method public final o(LE/n;ILE/o;)V
    .registers 4

    iput-object p1, p0, LE/n;->i:LE/n;

    iput-object p3, p0, LE/n;->l:LE/o;

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    iget v0, p0, LE/p;->b:I

    iget-object v1, p0, LE/n;->c:LE/e;

    const/4 v2, 0x1

    if-ne v0, v2, :cond_5f

    iget-object v0, p0, LE/n;->f:LE/n;

    const-string v2, ", RESOLVED: "

    const-string v3, "["

    if-ne v0, p0, :cond_32

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LE/n;->g:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, "]  type: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LE/n;->h:I

    invoke-static {v1}, LE/n;->m(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_32
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LE/n;->f:LE/n;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LE/n;->g:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, "] type: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LE/n;->h:I

    invoke-static {v1}, LE/n;->m(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_5f
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "{ "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " UNRESOLVED} type: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LE/n;->h:I

    invoke-static {v1}, LE/n;->m(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
