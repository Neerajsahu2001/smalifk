.class public LE/r;
.super LE/h;
.source "WidgetContainer.java"


# instance fields
.field protected i0:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "LE/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, LE/h;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public D()V
    .registers 2

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-super {p0}, LE/h;->D()V

    return-void
.end method

.method public final F(LD/d;)V
    .registers 5

    invoke-super {p0, p1}, LE/h;->F(LD/d;)V

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_a
    if-ge v1, v0, :cond_1a

    iget-object v2, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LE/h;

    invoke-virtual {v2, p1}, LE/h;->F(LD/d;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_a

    :cond_1a
    return-void
.end method

.method public final V(II)V
    .registers 7

    iput p1, p0, LE/h;->O:I

    iput p2, p0, LE/h;->P:I

    iget-object p1, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 p2, 0x0

    :goto_b
    if-ge p2, p1, :cond_25

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LE/h;

    iget v1, p0, LE/h;->I:I

    iget v2, p0, LE/h;->O:I

    add-int/2addr v1, v2

    iget v2, p0, LE/h;->J:I

    iget v3, p0, LE/h;->P:I

    add-int/2addr v2, v3

    invoke-virtual {v0, v1, v2}, LE/h;->V(II)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_b

    :cond_25
    return-void
.end method

.method public final j0()V
    .registers 6

    invoke-super {p0}, LE/h;->j0()V

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    if-nez v0, :cond_8

    return-void

    :cond_8
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_d
    if-ge v1, v0, :cond_2c

    iget-object v2, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LE/h;

    invoke-virtual {p0}, LE/h;->l()I

    move-result v3

    invoke-virtual {p0}, LE/h;->m()I

    move-result v4

    invoke-virtual {v2, v3, v4}, LE/h;->V(II)V

    instance-of v3, v2, LE/i;

    if-nez v3, :cond_29

    invoke-virtual {v2}, LE/h;->j0()V

    :cond_29
    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_2c
    return-void
.end method

.method public final l0(LE/h;)V
    .registers 3

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p1, LE/h;->D:LE/h;

    if-eqz v0, :cond_e

    check-cast v0, LE/r;

    invoke-virtual {v0, p1}, LE/r;->n0(LE/h;)V

    :cond_e
    iput-object p0, p1, LE/h;->D:LE/h;

    return-void
.end method

.method public m0()V
    .registers 5

    invoke-virtual {p0}, LE/r;->j0()V

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    if-nez v0, :cond_8

    return-void

    :cond_8
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_d
    if-ge v1, v0, :cond_23

    iget-object v2, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LE/h;

    instance-of v3, v2, LE/r;

    if-eqz v3, :cond_20

    check-cast v2, LE/r;

    invoke-virtual {v2}, LE/r;->m0()V

    :cond_20
    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_23
    return-void
.end method

.method public final n0(LE/h;)V
    .registers 3

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v0, 0x0

    iput-object v0, p1, LE/h;->D:LE/h;

    return-void
.end method

.method public final o0()V
    .registers 2

    iget-object v0, p0, LE/r;->i0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method
