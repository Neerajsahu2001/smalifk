.class public final enum LE/e$c;
.super Ljava/lang/Enum;
.source "ConstraintAnchor.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LE/e$c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LE/e$c;

.field public static final enum NONE:LE/e$c;

.field public static final enum STRONG:LE/e$c;

.field public static final enum WEAK:LE/e$c;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v3, LE/e$c;

    const-string v4, "NONE"

    invoke-direct {v3, v4, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LE/e$c;->NONE:LE/e$c;

    new-instance v4, LE/e$c;

    const-string v5, "STRONG"

    invoke-direct {v4, v5, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, LE/e$c;->STRONG:LE/e$c;

    new-instance v5, LE/e$c;

    const-string v6, "WEAK"

    invoke-direct {v5, v6, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LE/e$c;->WEAK:LE/e$c;

    const/4 v6, 0x3

    new-array v6, v6, [LE/e$c;

    aput-object v3, v6, v2

    aput-object v4, v6, v1

    aput-object v5, v6, v0

    sput-object v6, LE/e$c;->$VALUES:[LE/e$c;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)LE/e$c;
    .registers 2

    const-class v0, LE/e$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LE/e$c;

    return-object p0
.end method

.method public static values()[LE/e$c;
    .registers 1

    sget-object v0, LE/e$c;->$VALUES:[LE/e$c;

    invoke-virtual {v0}, [LE/e$c;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LE/e$c;

    return-object v0
.end method
