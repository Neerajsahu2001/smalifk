.class public final enum LE/e$b;
.super Ljava/lang/Enum;
.source "ConstraintAnchor.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LE/e$b;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LE/e$b;

.field public static final enum RELAXED:LE/e$b;

.field public static final enum STRICT:LE/e$b;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance v2, LE/e$b;

    const-string v3, "RELAXED"

    invoke-direct {v2, v3, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, LE/e$b;->RELAXED:LE/e$b;

    new-instance v3, LE/e$b;

    const-string v4, "STRICT"

    invoke-direct {v3, v4, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LE/e$b;->STRICT:LE/e$b;

    const/4 v4, 0x2

    new-array v4, v4, [LE/e$b;

    aput-object v2, v4, v1

    aput-object v3, v4, v0

    sput-object v4, LE/e$b;->$VALUES:[LE/e$b;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)LE/e$b;
    .registers 2

    const-class v0, LE/e$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LE/e$b;

    return-object p0
.end method

.method public static values()[LE/e$b;
    .registers 1

    sget-object v0, LE/e$b;->$VALUES:[LE/e$b;

    invoke-virtual {v0}, [LE/e$b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LE/e$b;

    return-object v0
.end method
