.class public final LE/q;
.super Ljava/lang/Object;
.source "Snapshot.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LE/q$a;
    }
.end annotation


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "LE/q$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LE/r;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LE/q;->e:Ljava/util/ArrayList;

    iget v0, p1, LE/h;->I:I

    iput v0, p0, LE/q;->a:I

    iget v0, p1, LE/h;->J:I

    iput v0, p0, LE/q;->b:I

    invoke-virtual {p1}, LE/h;->v()I

    move-result v0

    iput v0, p0, LE/q;->c:I

    invoke-virtual {p1}, LE/h;->n()I

    move-result v0

    iput v0, p0, LE/q;->d:I

    iget-object p1, p1, LE/h;->B:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_25
    if-ge v1, v0, :cond_3a

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LE/e;

    iget-object v3, p0, LE/q;->e:Ljava/util/ArrayList;

    new-instance v4, LE/q$a;

    invoke-direct {v4, v2}, LE/q$a;-><init>(LE/e;)V

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_25

    :cond_3a
    return-void
.end method


# virtual methods
.method public final a(LE/r;)V
    .registers 6

    iget v0, p0, LE/q;->a:I

    iput v0, p1, LE/h;->I:I

    iget v0, p0, LE/q;->b:I

    iput v0, p1, LE/h;->J:I

    iget v0, p0, LE/q;->c:I

    invoke-virtual {p1, v0}, LE/h;->e0(I)V

    iget v0, p0, LE/q;->d:I

    invoke-virtual {p1, v0}, LE/h;->L(I)V

    iget-object v0, p0, LE/q;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_19
    if-ge v2, v1, :cond_27

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LE/q$a;

    invoke-virtual {v3, p1}, LE/q$a;->a(LE/r;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_19

    :cond_27
    return-void
.end method

.method public final b(LE/r;)V
    .registers 6

    iget v0, p1, LE/h;->I:I

    iput v0, p0, LE/q;->a:I

    iget v0, p1, LE/h;->J:I

    iput v0, p0, LE/q;->b:I

    invoke-virtual {p1}, LE/h;->v()I

    move-result v0

    iput v0, p0, LE/q;->c:I

    invoke-virtual {p1}, LE/h;->n()I

    move-result v0

    iput v0, p0, LE/q;->d:I

    iget-object v0, p0, LE/q;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_1b
    if-ge v2, v1, :cond_29

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LE/q$a;

    invoke-virtual {v3, p1}, LE/q$a;->b(LE/r;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1b

    :cond_29
    return-void
.end method
