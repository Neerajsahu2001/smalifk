.class final LE/q$a;
.super Ljava/lang/Object;
.source "Snapshot.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private a:LE/e;

.field private b:LE/e;

.field private c:I

.field private d:LE/e$c;

.field private e:I


# direct methods
.method public constructor <init>(LE/e;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE/q$a;->a:LE/e;

    iget-object v0, p1, LE/e;->d:LE/e;

    iput-object v0, p0, LE/q$a;->b:LE/e;

    invoke-virtual {p1}, LE/e;->c()I

    move-result v0

    iput v0, p0, LE/q$a;->c:I

    invoke-virtual {p1}, LE/e;->f()LE/e$c;

    move-result-object v0

    iput-object v0, p0, LE/q$a;->d:LE/e$c;

    invoke-virtual {p1}, LE/e;->b()I

    move-result p1

    iput p1, p0, LE/q$a;->e:I

    return-void
.end method


# virtual methods
.method public final a(LE/r;)V
    .registers 10

    iget-object v0, p0, LE/q$a;->a:LE/e;

    iget-object v0, v0, LE/e;->c:LE/e$d;

    invoke-virtual {p1, v0}, LE/h;->g(LE/e$d;)LE/e;

    move-result-object v1

    iget-object v2, p0, LE/q$a;->b:LE/e;

    iget v3, p0, LE/q$a;->c:I

    iget-object v5, p0, LE/q$a;->d:LE/e$c;

    iget v6, p0, LE/q$a;->e:I

    const/4 v4, -0x1

    const/4 v7, 0x0

    invoke-virtual/range {v1 .. v7}, LE/e;->a(LE/e;IILE/e$c;IZ)Z

    return-void
.end method

.method public final b(LE/r;)V
    .registers 3

    iget-object v0, p0, LE/q$a;->a:LE/e;

    iget-object v0, v0, LE/e;->c:LE/e$d;

    invoke-virtual {p1, v0}, LE/h;->g(LE/e$d;)LE/e;

    move-result-object p1

    iput-object p1, p0, LE/q$a;->a:LE/e;

    if-eqz p1, :cond_27

    iget-object v0, p1, LE/e;->d:LE/e;

    iput-object v0, p0, LE/q$a;->b:LE/e;

    invoke-virtual {p1}, LE/e;->c()I

    move-result p1

    iput p1, p0, LE/q$a;->c:I

    iget-object p1, p0, LE/q$a;->a:LE/e;

    invoke-virtual {p1}, LE/e;->f()LE/e$c;

    move-result-object p1

    iput-object p1, p0, LE/q$a;->d:LE/e$c;

    iget-object p1, p0, LE/q$a;->a:LE/e;

    invoke-virtual {p1}, LE/e;->b()I

    move-result p1

    iput p1, p0, LE/q$a;->e:I

    goto :goto_33

    :cond_27
    const/4 p1, 0x0

    iput-object p1, p0, LE/q$a;->b:LE/e;

    const/4 p1, 0x0

    iput p1, p0, LE/q$a;->c:I

    sget-object v0, LE/e$c;->STRONG:LE/e$c;

    iput-object v0, p0, LE/q$a;->d:LE/e$c;

    iput p1, p0, LE/q$a;->e:I

    :goto_33
    return-void
.end method
