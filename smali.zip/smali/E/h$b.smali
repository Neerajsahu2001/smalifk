.class public final enum LE/h$b;
.super Ljava/lang/Enum;
.source "ConstraintWidget.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LE/h$b;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LE/h$b;

.field public static final enum FIXED:LE/h$b;

.field public static final enum MATCH_CONSTRAINT:LE/h$b;

.field public static final enum MATCH_PARENT:LE/h$b;

.field public static final enum WRAP_CONTENT:LE/h$b;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v4, LE/h$b;

    const-string v5, "FIXED"

    invoke-direct {v4, v5, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, LE/h$b;->FIXED:LE/h$b;

    new-instance v5, LE/h$b;

    const-string v6, "WRAP_CONTENT"

    invoke-direct {v5, v6, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LE/h$b;->WRAP_CONTENT:LE/h$b;

    new-instance v6, LE/h$b;

    const-string v7, "MATCH_CONSTRAINT"

    invoke-direct {v6, v7, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, LE/h$b;->MATCH_CONSTRAINT:LE/h$b;

    new-instance v7, LE/h$b;

    const-string v8, "MATCH_PARENT"

    invoke-direct {v7, v8, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, LE/h$b;->MATCH_PARENT:LE/h$b;

    const/4 v8, 0x4

    new-array v8, v8, [LE/h$b;

    aput-object v4, v8, v3

    aput-object v5, v8, v2

    aput-object v6, v8, v1

    aput-object v7, v8, v0

    sput-object v8, LE/h$b;->$VALUES:[LE/h$b;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)LE/h$b;
    .registers 2

    const-class v0, LE/h$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LE/h$b;

    return-object p0
.end method

.method public static values()[LE/h$b;
    .registers 1

    sget-object v0, LE/h$b;->$VALUES:[LE/h$b;

    invoke-virtual {v0}, [LE/h$b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LE/h$b;

    return-object v0
.end method
