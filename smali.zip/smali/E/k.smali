.class public final LE/k;
.super LE/h;
.source "Guideline.java"


# instance fields
.field protected i0:F

.field protected j0:I

.field protected k0:I

.field private l0:LE/e;

.field private m0:I


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, LE/h;-><init>()V

    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, LE/k;->i0:F

    const/4 v0, -0x1

    iput v0, p0, LE/k;->j0:I

    iput v0, p0, LE/k;->k0:I

    iget-object v0, p0, LE/h;->t:LE/e;

    iput-object v0, p0, LE/k;->l0:LE/e;

    const/4 v0, 0x0

    iput v0, p0, LE/k;->m0:I

    iget-object v1, p0, LE/h;->B:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, LE/h;->B:Ljava/util/ArrayList;

    iget-object v2, p0, LE/k;->l0:LE/e;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, LE/h;->A:[LE/e;

    array-length v1, v1

    :goto_22
    if-ge v0, v1, :cond_2d

    iget-object v2, p0, LE/h;->A:[LE/e;

    iget-object v3, p0, LE/k;->l0:LE/e;

    aput-object v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_22

    :cond_2d
    return-void
.end method


# virtual methods
.method public final a(LD/f;)V
    .registers 10

    iget-object v0, p0, LE/h;->D:LE/h;

    check-cast v0, LE/i;

    if-nez v0, :cond_7

    return-void

    :cond_7
    sget-object v1, LE/e$d;->LEFT:LE/e$d;

    invoke-virtual {v0, v1}, LE/h;->g(LE/e$d;)LE/e;

    move-result-object v1

    sget-object v2, LE/e$d;->RIGHT:LE/e$d;

    invoke-virtual {v0, v2}, LE/h;->g(LE/e$d;)LE/e;

    move-result-object v2

    iget-object v3, p0, LE/h;->D:LE/h;

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_23

    iget-object v3, v3, LE/h;->C:[LE/h$b;

    aget-object v3, v3, v5

    sget-object v6, LE/h$b;->WRAP_CONTENT:LE/h$b;

    if-ne v3, v6, :cond_23

    const/4 v3, 0x1

    goto :goto_24

    :cond_23
    const/4 v3, 0x0

    :goto_24
    iget v6, p0, LE/k;->m0:I

    if-nez v6, :cond_43

    sget-object v1, LE/e$d;->TOP:LE/e$d;

    invoke-virtual {v0, v1}, LE/h;->g(LE/e$d;)LE/e;

    move-result-object v1

    sget-object v2, LE/e$d;->BOTTOM:LE/e$d;

    invoke-virtual {v0, v2}, LE/h;->g(LE/e$d;)LE/e;

    move-result-object v2

    iget-object v0, p0, LE/h;->D:LE/h;

    if-eqz v0, :cond_41

    iget-object v0, v0, LE/h;->C:[LE/h$b;

    aget-object v0, v0, v4

    sget-object v3, LE/h$b;->WRAP_CONTENT:LE/h$b;

    if-ne v0, v3, :cond_41

    goto :goto_42

    :cond_41
    const/4 v4, 0x0

    :goto_42
    move v3, v4

    :cond_43
    iget v0, p0, LE/k;->j0:I

    const/4 v4, 0x6

    const/4 v6, -0x1

    const/4 v7, 0x5

    if-eq v0, v6, :cond_63

    iget-object v0, p0, LE/k;->l0:LE/e;

    invoke-virtual {p1, v0}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v0

    invoke-virtual {p1, v1}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v1

    iget v6, p0, LE/k;->j0:I

    invoke-virtual {p1, v0, v1, v6, v4}, LD/f;->e(LD/i;LD/i;II)V

    if-eqz v3, :cond_b1

    invoke-virtual {p1, v2}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v1

    invoke-virtual {p1, v1, v0, v5, v7}, LD/f;->g(LD/i;LD/i;II)V

    goto :goto_b1

    :cond_63
    iget v0, p0, LE/k;->k0:I

    if-eq v0, v6, :cond_84

    iget-object v0, p0, LE/k;->l0:LE/e;

    invoke-virtual {p1, v0}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v0

    invoke-virtual {p1, v2}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v2

    iget v6, p0, LE/k;->k0:I

    neg-int v6, v6

    invoke-virtual {p1, v0, v2, v6, v4}, LD/f;->e(LD/i;LD/i;II)V

    if-eqz v3, :cond_b1

    invoke-virtual {p1, v1}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v1

    invoke-virtual {p1, v0, v1, v5, v7}, LD/f;->g(LD/i;LD/i;II)V

    invoke-virtual {p1, v2, v0, v5, v7}, LD/f;->g(LD/i;LD/i;II)V

    goto :goto_b1

    :cond_84
    iget v0, p0, LE/k;->i0:F

    const/high16 v3, -0x40800000    # -1.0f

    cmpl-float v0, v0, v3

    if-eqz v0, :cond_b1

    iget-object v0, p0, LE/k;->l0:LE/e;

    invoke-virtual {p1, v0}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v0

    invoke-virtual {p1, v1}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v1

    invoke-virtual {p1, v2}, LD/f;->l(Ljava/lang/Object;)LD/i;

    move-result-object v2

    iget v4, p0, LE/k;->i0:F

    invoke-virtual {p1}, LD/f;->m()LD/c;

    move-result-object v5

    iget-object v6, v5, LD/c;->c:LD/b;

    invoke-virtual {v6, v0, v3}, LD/b;->k(LD/i;F)V

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float/2addr v0, v4

    invoke-virtual {v6, v1, v0}, LD/b;->k(LD/i;F)V

    invoke-virtual {v6, v2, v4}, LD/b;->k(LD/i;F)V

    invoke-virtual {p1, v5}, LD/f;->c(LD/c;)V

    :cond_b1
    :goto_b1
    return-void
.end method

.method public final b()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public final c(I)V
    .registers 14

    iget-object p1, p0, LE/h;->D:LE/h;

    if-nez p1, :cond_5

    return-void

    :cond_5
    iget v0, p0, LE/k;->m0:I

    iget-object v1, p0, LE/h;->u:LE/e;

    iget-object v2, p0, LE/h;->s:LE/e;

    iget-object v3, p0, LE/h;->v:LE/e;

    iget-object v4, p0, LE/h;->t:LE/e;

    iget-object v5, p1, LE/h;->C:[LE/h$b;

    iget-object v6, p1, LE/h;->s:LE/e;

    iget-object v7, p1, LE/h;->t:LE/e;

    const/high16 v8, -0x40800000    # -1.0f

    const/4 v9, -0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-ne v0, v11, :cond_a0

    invoke-virtual {v4}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v7}, LE/e;->d()LE/n;

    move-result-object v4

    invoke-virtual {v0, v4, v10}, LE/n;->g(LE/n;I)V

    invoke-virtual {v3}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v7}, LE/e;->d()LE/n;

    move-result-object v3

    invoke-virtual {v0, v3, v10}, LE/n;->g(LE/n;I)V

    iget v0, p0, LE/k;->j0:I

    if-eq v0, v9, :cond_52

    invoke-virtual {v2}, LE/e;->d()LE/n;

    move-result-object p1

    invoke-virtual {v6}, LE/e;->d()LE/n;

    move-result-object v0

    iget v2, p0, LE/k;->j0:I

    invoke-virtual {p1, v0, v2}, LE/n;->g(LE/n;I)V

    invoke-virtual {v1}, LE/e;->d()LE/n;

    move-result-object p1

    invoke-virtual {v6}, LE/e;->d()LE/n;

    move-result-object v0

    iget v1, p0, LE/k;->j0:I

    invoke-virtual {p1, v0, v1}, LE/n;->g(LE/n;I)V

    goto/16 :goto_120

    :cond_52
    iget v0, p0, LE/k;->k0:I

    if-eq v0, v9, :cond_76

    invoke-virtual {v2}, LE/e;->d()LE/n;

    move-result-object v0

    iget-object p1, p1, LE/h;->u:LE/e;

    invoke-virtual {p1}, LE/e;->d()LE/n;

    move-result-object v2

    iget v3, p0, LE/k;->k0:I

    neg-int v3, v3

    invoke-virtual {v0, v2, v3}, LE/n;->g(LE/n;I)V

    invoke-virtual {v1}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {p1}, LE/e;->d()LE/n;

    move-result-object p1

    iget v1, p0, LE/k;->k0:I

    neg-int v1, v1

    invoke-virtual {v0, p1, v1}, LE/n;->g(LE/n;I)V

    goto/16 :goto_120

    :cond_76
    iget v0, p0, LE/k;->i0:F

    cmpl-float v3, v0, v8

    if-eqz v3, :cond_120

    aget-object v3, v5, v10

    sget-object v4, LE/h$b;->FIXED:LE/h$b;

    if-ne v3, v4, :cond_120

    iget p1, p1, LE/h;->E:I

    int-to-float p1, p1

    mul-float p1, p1, v0

    float-to-int p1, p1

    invoke-virtual {v2}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v6}, LE/e;->d()LE/n;

    move-result-object v2

    invoke-virtual {v0, v2, p1}, LE/n;->g(LE/n;I)V

    invoke-virtual {v1}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v6}, LE/e;->d()LE/n;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, LE/n;->g(LE/n;I)V

    goto/16 :goto_120

    :cond_a0
    invoke-virtual {v2}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v6}, LE/e;->d()LE/n;

    move-result-object v2

    invoke-virtual {v0, v2, v10}, LE/n;->g(LE/n;I)V

    invoke-virtual {v1}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v6}, LE/e;->d()LE/n;

    move-result-object v1

    invoke-virtual {v0, v1, v10}, LE/n;->g(LE/n;I)V

    iget v0, p0, LE/k;->j0:I

    if-eq v0, v9, :cond_d5

    invoke-virtual {v4}, LE/e;->d()LE/n;

    move-result-object p1

    invoke-virtual {v7}, LE/e;->d()LE/n;

    move-result-object v0

    iget v1, p0, LE/k;->j0:I

    invoke-virtual {p1, v0, v1}, LE/n;->g(LE/n;I)V

    invoke-virtual {v3}, LE/e;->d()LE/n;

    move-result-object p1

    invoke-virtual {v7}, LE/e;->d()LE/n;

    move-result-object v0

    iget v1, p0, LE/k;->j0:I

    invoke-virtual {p1, v0, v1}, LE/n;->g(LE/n;I)V

    goto :goto_120

    :cond_d5
    iget v0, p0, LE/k;->k0:I

    if-eq v0, v9, :cond_f8

    invoke-virtual {v4}, LE/e;->d()LE/n;

    move-result-object v0

    iget-object p1, p1, LE/h;->v:LE/e;

    invoke-virtual {p1}, LE/e;->d()LE/n;

    move-result-object v1

    iget v2, p0, LE/k;->k0:I

    neg-int v2, v2

    invoke-virtual {v0, v1, v2}, LE/n;->g(LE/n;I)V

    invoke-virtual {v3}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {p1}, LE/e;->d()LE/n;

    move-result-object p1

    iget v1, p0, LE/k;->k0:I

    neg-int v1, v1

    invoke-virtual {v0, p1, v1}, LE/n;->g(LE/n;I)V

    goto :goto_120

    :cond_f8
    iget v0, p0, LE/k;->i0:F

    cmpl-float v1, v0, v8

    if-eqz v1, :cond_120

    aget-object v1, v5, v11

    sget-object v2, LE/h$b;->FIXED:LE/h$b;

    if-ne v1, v2, :cond_120

    iget p1, p1, LE/h;->F:I

    int-to-float p1, p1

    mul-float p1, p1, v0

    float-to-int p1, p1

    invoke-virtual {v4}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v7}, LE/e;->d()LE/n;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, LE/n;->g(LE/n;I)V

    invoke-virtual {v3}, LE/e;->d()LE/n;

    move-result-object v0

    invoke-virtual {v7}, LE/e;->d()LE/n;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, LE/n;->g(LE/n;I)V

    :cond_120
    :goto_120
    return-void
.end method

.method public final g(LE/e$d;)LE/e;
    .registers 4

    sget-object v0, LE/k$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_28

    goto :goto_1d

    :pswitch_c
    const/4 p1, 0x0

    return-object p1

    :pswitch_e
    iget v0, p0, LE/k;->m0:I

    if-nez v0, :cond_1d

    iget-object p1, p0, LE/k;->l0:LE/e;

    return-object p1

    :pswitch_15
    iget v0, p0, LE/k;->m0:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1d

    iget-object p1, p0, LE/k;->l0:LE/e;

    return-object p1

    :cond_1d
    :goto_1d
    new-instance v0, Ljava/lang/AssertionError;

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    nop

    :pswitch_data_28
    .packed-switch 0x1
        :pswitch_15
        :pswitch_15
        :pswitch_e
        :pswitch_e
        :pswitch_c
        :pswitch_c
        :pswitch_c
        :pswitch_c
        :pswitch_c
    .end packed-switch
.end method

.method public final k0(LD/f;)V
    .registers 5

    iget-object p1, p0, LE/h;->D:LE/h;

    if-nez p1, :cond_5

    return-void

    :cond_5
    iget-object p1, p0, LE/k;->l0:LE/e;

    invoke-static {p1}, LD/f;->p(LE/e;)I

    move-result p1

    iget v0, p0, LE/k;->m0:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_22

    iput p1, p0, LE/h;->I:I

    iput v2, p0, LE/h;->J:I

    iget-object p1, p0, LE/h;->D:LE/h;

    invoke-virtual {p1}, LE/h;->n()I

    move-result p1

    invoke-virtual {p0, p1}, LE/h;->L(I)V

    invoke-virtual {p0, v2}, LE/h;->e0(I)V

    goto :goto_32

    :cond_22
    iput v2, p0, LE/h;->I:I

    iput p1, p0, LE/h;->J:I

    iget-object p1, p0, LE/h;->D:LE/h;

    invoke-virtual {p1}, LE/h;->v()I

    move-result p1

    invoke-virtual {p0, p1}, LE/h;->e0(I)V

    invoke-virtual {p0, v2}, LE/h;->L(I)V

    :goto_32
    return-void
.end method

.method public final l0(I)V
    .registers 4

    const/4 v0, -0x1

    if-le p1, v0, :cond_b

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, LE/k;->i0:F

    iput p1, p0, LE/k;->j0:I

    iput v0, p0, LE/k;->k0:I

    :cond_b
    return-void
.end method

.method public final m0(I)V
    .registers 4

    const/4 v0, -0x1

    if-le p1, v0, :cond_b

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, LE/k;->i0:F

    iput v0, p0, LE/k;->j0:I

    iput p1, p0, LE/k;->k0:I

    :cond_b
    return-void
.end method

.method public final n0(F)V
    .registers 3

    const/high16 v0, -0x40800000    # -1.0f

    cmpl-float v0, p1, v0

    if-lez v0, :cond_d

    iput p1, p0, LE/k;->i0:F

    const/4 p1, -0x1

    iput p1, p0, LE/k;->j0:I

    iput p1, p0, LE/k;->k0:I

    :cond_d
    return-void
.end method

.method public final o0(I)V
    .registers 5

    iget v0, p0, LE/k;->m0:I

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput p1, p0, LE/k;->m0:I

    iget-object p1, p0, LE/h;->B:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget v0, p0, LE/k;->m0:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_16

    iget-object v0, p0, LE/h;->s:LE/e;

    iput-object v0, p0, LE/k;->l0:LE/e;

    goto :goto_1a

    :cond_16
    iget-object v0, p0, LE/h;->t:LE/e;

    iput-object v0, p0, LE/k;->l0:LE/e;

    :goto_1a
    iget-object v0, p0, LE/k;->l0:LE/e;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, LE/h;->A:[LE/e;

    array-length v0, p1

    const/4 v1, 0x0

    :goto_23
    if-ge v1, v0, :cond_2c

    iget-object v2, p0, LE/k;->l0:LE/e;

    aput-object v2, p1, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_23

    :cond_2c
    return-void
.end method
