.class public LE/l;
.super LE/h;
.source "Helper.java"


# instance fields
.field protected i0:[LE/h;

.field protected j0:I


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, LE/h;-><init>()V

    const/4 v0, 0x4

    new-array v0, v0, [LE/h;

    iput-object v0, p0, LE/l;->i0:[LE/h;

    const/4 v0, 0x0

    iput v0, p0, LE/l;->j0:I

    return-void
.end method


# virtual methods
.method public final l0(LE/h;)V
    .registers 5

    iget v0, p0, LE/l;->j0:I

    add-int/lit8 v0, v0, 0x1

    iget-object v1, p0, LE/l;->i0:[LE/h;

    array-length v2, v1

    if-le v0, v2, :cond_14

    array-length v0, v1

    mul-int/lit8 v0, v0, 0x2

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LE/h;

    iput-object v0, p0, LE/l;->i0:[LE/h;

    :cond_14
    iget-object v0, p0, LE/l;->i0:[LE/h;

    iget v1, p0, LE/l;->j0:I

    aput-object p1, v0, v1

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, LE/l;->j0:I

    return-void
.end method

.method public final m0()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, LE/l;->j0:I

    return-void
.end method
