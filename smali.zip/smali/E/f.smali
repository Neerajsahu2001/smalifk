.class public final Le/f;
.super Ljava/lang/Object;


# static fields
.field public static final action_bar:I = 0x7f0b003a

.field public static final action_bar_activity_content:I = 0x7f0b003b

.field public static final action_bar_container:I = 0x7f0b003d

.field public static final action_bar_root:I = 0x7f0b003e

.field public static final action_bar_spinner:I = 0x7f0b003f

.field public static final action_bar_subtitle:I = 0x7f0b0040

.field public static final action_bar_title:I = 0x7f0b0041

.field public static final action_context_bar:I = 0x7f0b0046

.field public static final action_menu_divider:I = 0x7f0b004c

.field public static final action_menu_presenter:I = 0x7f0b004d

.field public static final action_mode_bar:I = 0x7f0b004e

.field public static final action_mode_bar_stub:I = 0x7f0b004f

.field public static final action_mode_close_button:I = 0x7f0b0050

.field public static final activity_chooser_view_content:I = 0x7f0b0058

.field public static final add:I = 0x7f0b005a

.field public static final alertTitle:I = 0x7f0b0063

.field public static final buttonPanel:I = 0x7f0b00e2

.field public static final checkbox:I = 0x7f0b018c

.field public static final checked:I = 0x7f0b018f

.field public static final content:I = 0x7f0b01c5

.field public static final contentPanel:I = 0x7f0b01c7

.field public static final custom:I = 0x7f0b01e6

.field public static final customPanel:I = 0x7f0b01e7

.field public static final decor_content_parent:I = 0x7f0b01f5

.field public static final default_activity_button:I = 0x7f0b01f6

.field public static final edit_query:I = 0x7f0b022d

.field public static final expand_activities_button:I = 0x7f0b028d

.field public static final expanded_menu:I = 0x7f0b0295

.field public static final group_divider:I = 0x7f0b032a

.field public static final home:I = 0x7f0b0342

.field public static final icon:I = 0x7f0b034d

.field public static final image:I = 0x7f0b0356

.field public static final listMode:I = 0x7f0b03f7

.field public static final list_item:I = 0x7f0b03f8

.field public static final message:I = 0x7f0b043b

.field public static final multiply:I = 0x7f0b0454

.field public static final none:I = 0x7f0b046f

.field public static final normal:I = 0x7f0b0470

.field public static final off:I = 0x7f0b0482

.field public static final on:I = 0x7f0b04a0

.field public static final parentPanel:I = 0x7f0b04be

.field public static final progress_circular:I = 0x7f0b0582

.field public static final progress_horizontal:I = 0x7f0b0583

.field public static final radio:I = 0x7f0b059a

.field public static final screen:I = 0x7f0b0626

.field public static final scrollIndicatorDown:I = 0x7f0b0628

.field public static final scrollIndicatorUp:I = 0x7f0b0629

.field public static final scrollView:I = 0x7f0b062a

.field public static final search_badge:I = 0x7f0b0630

.field public static final search_bar:I = 0x7f0b0631

.field public static final search_button:I = 0x7f0b0632

.field public static final search_close_btn:I = 0x7f0b0634

.field public static final search_edit_frame:I = 0x7f0b063b

.field public static final search_go_btn:I = 0x7f0b063d

.field public static final search_mag_icon:I = 0x7f0b0640

.field public static final search_plate:I = 0x7f0b0641

.field public static final search_src_text:I = 0x7f0b0642

.field public static final search_voice_btn:I = 0x7f0b0644

.field public static final select_dialog_listview:I = 0x7f0b065a

.field public static final shortcut:I = 0x7f0b066c

.field public static final spacer:I = 0x7f0b0695

.field public static final split_action_bar:I = 0x7f0b069d

.field public static final src_atop:I = 0x7f0b06a0

.field public static final src_in:I = 0x7f0b06a1

.field public static final src_over:I = 0x7f0b06a2

.field public static final submenuarrow:I = 0x7f0b06bf

.field public static final submit_area:I = 0x7f0b06c1

.field public static final tabMode:I = 0x7f0b06db

.field public static final textSpacerNoButtons:I = 0x7f0b06fc

.field public static final textSpacerNoTitle:I = 0x7f0b06fd

.field public static final title:I = 0x7f0b0733

.field public static final titleDividerNoCustom:I = 0x7f0b0734

.field public static final title_template:I = 0x7f0b073e

.field public static final topPanel:I = 0x7f0b075e

.field public static final unchecked:I = 0x7f0b07e0

.field public static final uniform:I = 0x7f0b07e2

.field public static final up:I = 0x7f0b07e4

.field public static final wrap_content:I = 0x7f0b0856
