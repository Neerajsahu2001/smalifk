.class public final LE/o;
.super LE/p;
.source "ResolutionDimension.java"


# instance fields
.field c:F


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, LE/p;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, LE/o;->c:F

    return-void
.end method


# virtual methods
.method public final f()V
    .registers 2

    const/4 v0, 0x2

    iput v0, p0, LE/p;->b:I

    return-void
.end method

.method public final g()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, LE/p;->b:I

    iget-object v0, p0, LE/p;->a:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    const/4 v0, 0x0

    iput v0, p0, LE/o;->c:F

    return-void
.end method

.method public final h(I)V
    .registers 5

    iget v0, p0, LE/p;->b:I

    if-eqz v0, :cond_b

    iget v1, p0, LE/o;->c:F

    int-to-float v2, p1

    cmpl-float v1, v1, v2

    if-eqz v1, :cond_17

    :cond_b
    int-to-float p1, p1

    iput p1, p0, LE/o;->c:F

    const/4 p1, 0x1

    if-ne v0, p1, :cond_14

    invoke-virtual {p0}, LE/p;->c()V

    :cond_14
    invoke-virtual {p0}, LE/p;->b()V

    :cond_17
    return-void
.end method
