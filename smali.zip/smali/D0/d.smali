.class public interface abstract Ld0/d;
.super Ljava/lang/Object;
.source "CacheEvictor.java"

# interfaces
.implements Ld0/a$b;


# virtual methods
.method public abstract a()Z
.end method

.method public abstract c(Ld0/a;J)V
.end method
