.class final Ld0/p;
.super Ljava/io/BufferedOutputStream;
.source "ReusableBufferedOutputStream.java"


# instance fields
.field private a:Z


# virtual methods
.method public final c(Ljava/io/OutputStream;)V
    .registers 3

    iget-boolean v0, p0, Ld0/p;->a:Z

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    iput-object p1, p0, Ljava/io/BufferedOutputStream;->out:Ljava/io/OutputStream;

    const/4 p1, 0x0

    iput p1, p0, Ljava/io/BufferedOutputStream;->count:I

    iput-boolean p1, p0, Ld0/p;->a:Z

    return-void
.end method

.method public final close()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x1

    iput-boolean v0, p0, Ld0/p;->a:Z

    :try_start_3
    invoke-virtual {p0}, Ljava/io/OutputStream;->flush()V
    :try_end_6
    .catchall {:try_start_3 .. :try_end_6} :catchall_8

    const/4 v0, 0x0

    goto :goto_9

    :catchall_8
    move-exception v0

    :goto_9
    :try_start_9
    iget-object v1, p0, Ljava/io/BufferedOutputStream;->out:Ljava/io/OutputStream;

    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_e
    .catchall {:try_start_9 .. :try_end_e} :catchall_f

    goto :goto_13

    :catchall_f
    move-exception v1

    if-nez v0, :cond_13

    move-object v0, v1

    :cond_13
    :goto_13
    if-nez v0, :cond_16

    return-void

    :cond_16
    sget v1, La0/T;->a:I

    throw v0
.end method
