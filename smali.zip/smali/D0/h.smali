.class public Ld0/h;
.super Ljava/lang/Object;
.source "CacheSpan.java"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Ld0/h;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:J

.field public final c:J

.field public final d:Z

.field public final e:Ljava/io/File;

.field public final f:J


# direct methods
.method public constructor <init>(Ljava/lang/String;JJJLjava/io/File;)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld0/h;->a:Ljava/lang/String;

    iput-wide p2, p0, Ld0/h;->b:J

    iput-wide p4, p0, Ld0/h;->c:J

    if-eqz p8, :cond_d

    const/4 p1, 0x1

    goto :goto_e

    :cond_d
    const/4 p1, 0x0

    :goto_e
    iput-boolean p1, p0, Ld0/h;->d:Z

    iput-object p8, p0, Ld0/h;->e:Ljava/io/File;

    iput-wide p6, p0, Ld0/h;->f:J

    return-void
.end method


# virtual methods
.method public final a(Ld0/h;)I
    .registers 6

    iget-object v0, p1, Ld0/h;->a:Ljava/lang/String;

    iget-object v1, p0, Ld0/h;->a:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_11

    iget-object p1, p1, Ld0/h;->a:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    return p1

    :cond_11
    iget-wide v0, p0, Ld0/h;->b:J

    iget-wide v2, p1, Ld0/h;->b:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long p1, v0, v2

    if-nez p1, :cond_1e

    const/4 p1, 0x0

    goto :goto_23

    :cond_1e
    if-gez p1, :cond_22

    const/4 p1, -0x1

    goto :goto_23

    :cond_22
    const/4 p1, 0x1

    :goto_23
    return p1
.end method

.method public final bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    check-cast p1, Ld0/h;

    invoke-virtual {p0, p1}, Ld0/h;->a(Ld0/h;)I

    move-result p1

    return p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "["

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, Ld0/h;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Ld0/h;->c:J

    const-string v3, "]"

    invoke-static {v0, v1, v2, v3}, Landroid/support/v4/media/session/b;->b(Ljava/lang/StringBuilder;JLjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
