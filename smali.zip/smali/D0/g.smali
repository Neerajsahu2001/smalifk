.class public interface abstract Ld0/g;
.super Ljava/lang/Object;
.source "CacheKeyFactory.java"


# static fields
.field public static final u0:LO0/d;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LO0/d;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Ld0/g;->u0:LO0/d;

    return-void
.end method
