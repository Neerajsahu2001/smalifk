.class public final Ld0/b$b;
.super Ljava/lang/Object;
.source "CacheDataSink.java"

# interfaces
.implements Lc0/c$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private a:Ld0/a;


# virtual methods
.method public final a()Ld0/b;
    .registers 3

    new-instance v0, Ld0/b;

    iget-object v1, p0, Ld0/b$b;->a:Ld0/a;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0, v1}, Ld0/b;-><init>(Ld0/a;)V

    return-object v0
.end method

.method public final b(Ld0/a;)V
    .registers 2

    iput-object p1, p0, Ld0/b$b;->a:Ld0/a;

    return-void
.end method
