.class public interface abstract Ld0/a$b;
.super Ljava/lang/Object;
.source "Cache.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ld0/h;)V
.end method

.method public abstract d(Ld0/a;Ld0/h;Ld0/h;)V
.end method

.method public abstract e(Ld0/a;Ld0/h;)V
.end method
