.class final Ld0/j;
.super Ljava/lang/Object;
.source "CachedContentIndex.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld0/j$a;,
        Ld0/j$b;,
        Ld0/j$c;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ld0/i;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Landroid/util/SparseBooleanArray;

.field private final d:Landroid/util/SparseBooleanArray;

.field private e:Ld0/j$c;

.field private f:Ld0/j$c;


# direct methods
.method public constructor <init>(Landroidx/media3/database/StandaloneDatabaseProvider;Ljava/io/File;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Ld0/j;->a:Ljava/util/HashMap;

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Ld0/j;->b:Landroid/util/SparseArray;

    new-instance v0, Landroid/util/SparseBooleanArray;

    invoke-direct {v0}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object v0, p0, Ld0/j;->c:Landroid/util/SparseBooleanArray;

    new-instance v0, Landroid/util/SparseBooleanArray;

    invoke-direct {v0}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object v0, p0, Ld0/j;->d:Landroid/util/SparseBooleanArray;

    new-instance v0, Ld0/j$a;

    invoke-direct {v0, p1}, Ld0/j$a;-><init>(Landroidx/media3/database/StandaloneDatabaseProvider;)V

    new-instance p1, Ld0/j$b;

    new-instance v1, Ljava/io/File;

    const-string v2, "cached_content_index.exi"

    invoke-direct {v1, p2, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {p1, v1}, Ld0/j$b;-><init>(Ljava/io/File;)V

    iput-object v0, p0, Ld0/j;->e:Ld0/j$c;

    iput-object p1, p0, Ld0/j;->f:Ld0/j$c;

    return-void
.end method

.method static a(Ljava/io/DataInputStream;)Ld0/l;
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v0, :cond_45

    invoke-virtual {p0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0}, Ljava/io/DataInputStream;->readInt()I

    move-result v5

    if-ltz v5, :cond_39

    const/high16 v6, 0xa00000

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v7

    sget-object v8, La0/T;->f:[B

    const/4 v9, 0x0

    :goto_20
    if-eq v9, v5, :cond_33

    add-int v10, v9, v7

    invoke-static {v8, v10}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v8

    invoke-virtual {p0, v8, v9, v7}, Ljava/io/DataInputStream;->readFully([BII)V

    sub-int v7, v5, v10

    invoke-static {v7, v6}, Ljava/lang/Math;->min(II)I

    move-result v7

    move v9, v10

    goto :goto_20

    :cond_33
    invoke-virtual {v1, v4, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_39
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid value size: "

    invoke-static {v0, v5}, Landroidx/core/content/b;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_45
    new-instance p0, Ld0/l;

    invoke-direct {p0, v1}, Ld0/l;-><init>(Ljava/util/Map;)V

    return-object p0
.end method

.method static b(Ld0/l;Ljava/io/DataOutputStream;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Ld0/l;->b()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/io/DataOutputStream;->writeInt(I)V

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p1, v1}, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    array-length v1, v0

    invoke-virtual {p1, v1}, Ljava/io/DataOutputStream;->writeInt(I)V

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    goto :goto_f

    :cond_32
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/String;Ld0/k;)V
    .registers 3

    invoke-virtual {p0, p1}, Ld0/j;->g(Ljava/lang/String;)Ld0/i;

    move-result-object p1

    invoke-virtual {p1, p2}, Ld0/i;->b(Ld0/k;)Z

    move-result p2

    if-eqz p2, :cond_f

    iget-object p2, p0, Ld0/j;->e:Ld0/j$c;

    invoke-interface {p2, p1}, Ld0/j$c;->a(Ld0/i;)V

    :cond_f
    return-void
.end method

.method public final d(Ljava/lang/String;)Ld0/i;
    .registers 3

    iget-object v0, p0, Ld0/j;->a:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld0/i;

    return-object p1
.end method

.method public final e()Ljava/util/Collection;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "Ld0/i;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ld0/j;->a:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableCollection(Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v0

    return-object v0
.end method

.method public final f(I)Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Ld0/j;->b:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1
.end method

.method public final g(Ljava/lang/String;)Ld0/i;
    .registers 8

    iget-object v0, p0, Ld0/j;->a:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld0/i;

    if-nez v1, :cond_44

    iget-object v1, p0, Ld0/j;->b:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_16

    const/4 v5, 0x0

    goto :goto_1d

    :cond_16
    add-int/lit8 v5, v2, -0x1

    invoke-virtual {v1, v5}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v5

    add-int/2addr v5, v3

    :goto_1d
    if-gez v5, :cond_2c

    :goto_1f
    if-ge v4, v2, :cond_2b

    invoke-virtual {v1, v4}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v5

    if-eq v4, v5, :cond_28

    goto :goto_2b

    :cond_28
    add-int/lit8 v4, v4, 0x1

    goto :goto_1f

    :cond_2b
    :goto_2b
    move v5, v4

    :cond_2c
    new-instance v2, Ld0/i;

    sget-object v4, Ld0/l;->c:Ld0/l;

    invoke-direct {v2, v5, p1, v4}, Ld0/i;-><init>(ILjava/lang/String;Ld0/l;)V

    invoke-virtual {v0, p1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v1, v5, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iget-object p1, p0, Ld0/j;->d:Landroid/util/SparseBooleanArray;

    invoke-virtual {p1, v5, v3}, Landroid/util/SparseBooleanArray;->put(IZ)V

    iget-object p1, p0, Ld0/j;->e:Ld0/j$c;

    invoke-interface {p1, v2}, Ld0/j$c;->a(Ld0/i;)V

    move-object v1, v2

    :cond_44
    return-object v1
.end method

.method public final h(J)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Ld0/j;->e:Ld0/j$c;

    invoke-interface {v0, p1, p2}, Ld0/j$c;->d(J)V

    iget-object v1, p0, Ld0/j;->f:Ld0/j$c;

    if-eqz v1, :cond_c

    invoke-interface {v1, p1, p2}, Ld0/j$c;->d(J)V

    :cond_c
    invoke-interface {v0}, Ld0/j$c;->b()Z

    move-result p1

    iget-object p2, p0, Ld0/j;->b:Landroid/util/SparseArray;

    iget-object v1, p0, Ld0/j;->a:Ljava/util/HashMap;

    if-nez p1, :cond_29

    iget-object p1, p0, Ld0/j;->f:Ld0/j$c;

    if-eqz p1, :cond_29

    invoke-interface {p1}, Ld0/j$c;->b()Z

    move-result p1

    if-eqz p1, :cond_29

    iget-object p1, p0, Ld0/j;->f:Ld0/j$c;

    invoke-interface {p1, v1, p2}, Ld0/j$c;->g(Ljava/util/HashMap;Landroid/util/SparseArray;)V

    invoke-interface {v0, v1}, Ld0/j$c;->f(Ljava/util/HashMap;)V

    goto :goto_2c

    :cond_29
    invoke-interface {v0, v1, p2}, Ld0/j$c;->g(Ljava/util/HashMap;Landroid/util/SparseArray;)V

    :goto_2c
    iget-object p1, p0, Ld0/j;->f:Ld0/j$c;

    if-eqz p1, :cond_36

    invoke-interface {p1}, Ld0/j$c;->delete()V

    const/4 p1, 0x0

    iput-object p1, p0, Ld0/j;->f:Ld0/j$c;

    :cond_36
    return-void
.end method

.method public final i(Ljava/lang/String;)V
    .registers 6

    iget-object v0, p0, Ld0/j;->a:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld0/i;

    if-eqz v1, :cond_3b

    invoke-virtual {v1}, Ld0/i;->f()Z

    move-result v2

    if-eqz v2, :cond_3b

    invoke-virtual {v1}, Ld0/i;->h()Z

    move-result v2

    if-eqz v2, :cond_3b

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Ld0/j;->d:Landroid/util/SparseBooleanArray;

    iget v0, v1, Ld0/i;->a:I

    invoke-virtual {p1, v0}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v2

    iget-object v3, p0, Ld0/j;->e:Ld0/j$c;

    invoke-interface {v3, v1, v2}, Ld0/j$c;->e(Ld0/i;Z)V

    iget-object v1, p0, Ld0/j;->b:Landroid/util/SparseArray;

    if-eqz v2, :cond_31

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->remove(I)V

    invoke-virtual {p1, v0}, Landroid/util/SparseBooleanArray;->delete(I)V

    goto :goto_3b

    :cond_31
    const/4 p1, 0x0

    invoke-virtual {v1, v0, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iget-object p1, p0, Ld0/j;->c:Landroid/util/SparseBooleanArray;

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/util/SparseBooleanArray;->put(IZ)V

    :cond_3b
    :goto_3b
    return-void
.end method

.method public final j()V
    .registers 3

    iget-object v0, p0, Ld0/j;->a:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-static {v0}, Lgk/y;->s(Ljava/util/Collection;)Lgk/y;

    move-result-object v0

    invoke-virtual {v0}, Lgk/u;->l()Lgk/b0;

    move-result-object v0

    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p0, v1}, Ld0/j;->i(Ljava/lang/String;)V

    goto :goto_e

    :cond_1e
    return-void
.end method

.method public final k()V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Ld0/j;->a:Ljava/util/HashMap;

    iget-object v1, p0, Ld0/j;->e:Ld0/j$c;

    invoke-interface {v1, v0}, Ld0/j$c;->c(Ljava/util/HashMap;)V

    iget-object v0, p0, Ld0/j;->c:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_e
    if-ge v2, v1, :cond_1c

    iget-object v3, p0, Ld0/j;->b:Landroid/util/SparseArray;

    invoke-virtual {v0, v2}, Landroid/util/SparseBooleanArray;->keyAt(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->remove(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    :cond_1c
    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clear()V

    iget-object v0, p0, Ld0/j;->d:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clear()V

    return-void
.end method
