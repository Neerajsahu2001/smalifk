.class public final Ld0/c;
.super Ljava/lang/Object;
.source "CacheDataSource.java"

# interfaces
.implements Landroidx/media3/datasource/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld0/c$a;
    }
.end annotation


# instance fields
.field private final a:Ld0/a;

.field private final b:Landroidx/media3/datasource/b;

.field private final c:Lc0/q;

.field private final d:Landroidx/media3/datasource/b;

.field private final e:Ld0/g;

.field private final f:Z

.field private final g:Z

.field private final h:Z

.field private i:Landroid/net/Uri;

.field private j:Lc0/g;

.field private k:Lc0/g;

.field private l:Landroidx/media3/datasource/b;

.field private m:J

.field private n:J

.field private o:J

.field private p:Ld0/h;

.field private q:Z

.field private r:Z

.field private s:J


# direct methods
.method constructor <init>(Ld0/a;Landroidx/media3/datasource/b;Landroidx/media3/datasource/b;Lc0/c;I)V
    .registers 7

    sget-object v0, Ld0/g;->u0:LO0/d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld0/c;->a:Ld0/a;

    iput-object p3, p0, Ld0/c;->b:Landroidx/media3/datasource/b;

    iput-object v0, p0, Ld0/c;->e:Ld0/g;

    and-int/lit8 p1, p5, 0x1

    const/4 p3, 0x1

    const/4 v0, 0x0

    if-eqz p1, :cond_13

    const/4 p1, 0x1

    goto :goto_14

    :cond_13
    const/4 p1, 0x0

    :goto_14
    iput-boolean p1, p0, Ld0/c;->f:Z

    and-int/lit8 p1, p5, 0x2

    if-eqz p1, :cond_1c

    const/4 p1, 0x1

    goto :goto_1d

    :cond_1c
    const/4 p1, 0x0

    :goto_1d
    iput-boolean p1, p0, Ld0/c;->g:Z

    and-int/lit8 p1, p5, 0x4

    if-eqz p1, :cond_24

    goto :goto_25

    :cond_24
    const/4 p3, 0x0

    :goto_25
    iput-boolean p3, p0, Ld0/c;->h:Z

    const/4 p1, 0x0

    if-eqz p2, :cond_36

    iput-object p2, p0, Ld0/c;->d:Landroidx/media3/datasource/b;

    if-eqz p4, :cond_33

    new-instance p1, Lc0/q;

    invoke-direct {p1, p2, p4}, Lc0/q;-><init>(Landroidx/media3/datasource/b;Lc0/c;)V

    :cond_33
    iput-object p1, p0, Ld0/c;->c:Lc0/q;

    goto :goto_3c

    :cond_36
    sget-object p2, Landroidx/media3/datasource/e;->a:Landroidx/media3/datasource/e;

    iput-object p2, p0, Ld0/c;->d:Landroidx/media3/datasource/b;

    iput-object p1, p0, Ld0/c;->c:Lc0/q;

    :goto_3c
    return-void
.end method

.method private k()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Ld0/c;->a:Ld0/a;

    iget-object v1, p0, Ld0/c;->l:Landroidx/media3/datasource/b;

    if-nez v1, :cond_7

    return-void

    :cond_7
    const/4 v2, 0x0

    :try_start_8
    invoke-interface {v1}, Landroidx/media3/datasource/b;->close()V
    :try_end_b
    .catchall {:try_start_8 .. :try_end_b} :catchall_19

    iput-object v2, p0, Ld0/c;->k:Lc0/g;

    iput-object v2, p0, Ld0/c;->l:Landroidx/media3/datasource/b;

    iget-object v1, p0, Ld0/c;->p:Ld0/h;

    if-eqz v1, :cond_18

    invoke-interface {v0, v1}, Ld0/a;->c(Ld0/h;)V

    iput-object v2, p0, Ld0/c;->p:Ld0/h;

    :cond_18
    return-void

    :catchall_19
    move-exception v1

    iput-object v2, p0, Ld0/c;->k:Lc0/g;

    iput-object v2, p0, Ld0/c;->l:Landroidx/media3/datasource/b;

    iget-object v3, p0, Ld0/c;->p:Ld0/h;

    if-eqz v3, :cond_27

    invoke-interface {v0, v3}, Ld0/a;->c(Ld0/h;)V

    iput-object v2, p0, Ld0/c;->p:Ld0/h;

    :cond_27
    throw v1
.end method

.method private l(Lc0/g;Z)V
    .registers 23
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    sget v2, La0/T;->a:I

    iget-boolean v2, v1, Ld0/c;->r:Z

    iget-object v9, v0, Lc0/g;->h:Ljava/lang/String;

    if-eqz v2, :cond_e

    const/4 v2, 0x0

    goto :goto_36

    :cond_e
    iget-boolean v2, v1, Ld0/c;->f:Z

    if-eqz v2, :cond_2b

    :try_start_12
    iget-object v3, v1, Ld0/c;->a:Ld0/a;

    iget-wide v4, v1, Ld0/c;->n:J

    iget-wide v6, v1, Ld0/c;->o:J

    move-object v8, v9

    invoke-interface/range {v3 .. v8}, Ld0/a;->d(JJLjava/lang/String;)Ld0/h;

    move-result-object v2
    :try_end_1d
    .catch Ljava/lang/InterruptedException; {:try_start_12 .. :try_end_1d} :catch_1e

    goto :goto_36

    :catch_1e
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    new-instance v0, Ljava/io/InterruptedIOException;

    invoke-direct {v0}, Ljava/io/InterruptedIOException;-><init>()V

    throw v0

    :cond_2b
    iget-wide v4, v1, Ld0/c;->n:J

    iget-wide v6, v1, Ld0/c;->o:J

    iget-object v3, v1, Ld0/c;->a:Ld0/a;

    move-object v8, v9

    invoke-interface/range {v3 .. v8}, Ld0/a;->e(JJLjava/lang/String;)Ld0/h;

    move-result-object v2

    :goto_36
    iget-object v3, v1, Ld0/c;->c:Lc0/q;

    iget-object v4, v1, Ld0/c;->b:Landroidx/media3/datasource/b;

    iget-object v5, v1, Ld0/c;->a:Ld0/a;

    const-wide/16 v6, -0x1

    iget-object v8, v1, Ld0/c;->d:Landroidx/media3/datasource/b;

    if-nez v2, :cond_5a

    invoke-virtual/range {p1 .. p1}, Lc0/g;->a()Lc0/g$a;

    move-result-object v11

    iget-wide v12, v1, Ld0/c;->n:J

    invoke-virtual {v11, v12, v13}, Lc0/g$a;->h(J)V

    iget-wide v12, v1, Ld0/c;->o:J

    invoke-virtual {v11, v12, v13}, Lc0/g$a;->g(J)V

    invoke-virtual {v11}, Lc0/g$a;->a()Lc0/g;

    move-result-object v11

    move-object/from16 v18, v8

    move-object/from16 v17, v9

    goto/16 :goto_c3

    :cond_5a
    iget-boolean v11, v2, Ld0/h;->d:Z

    iget-wide v12, v2, Ld0/h;->c:J

    if-eqz v11, :cond_94

    iget-object v11, v2, Ld0/h;->e:Ljava/io/File;

    invoke-static {v11}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v11

    iget-wide v14, v1, Ld0/c;->n:J

    move-object/from16 v16, v11

    iget-wide v10, v2, Ld0/h;->b:J

    sub-long/2addr v14, v10

    sub-long/2addr v12, v14

    move-object/from16 v18, v8

    move-object/from16 v17, v9

    iget-wide v8, v1, Ld0/c;->o:J

    cmp-long v19, v8, v6

    if-eqz v19, :cond_7c

    invoke-static {v12, v13, v8, v9}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v12

    :cond_7c
    invoke-virtual/range {p1 .. p1}, Lc0/g;->a()Lc0/g$a;

    move-result-object v8

    move-object/from16 v9, v16

    invoke-virtual {v8, v9}, Lc0/g$a;->i(Landroid/net/Uri;)V

    invoke-virtual {v8, v10, v11}, Lc0/g$a;->k(J)V

    invoke-virtual {v8, v14, v15}, Lc0/g$a;->h(J)V

    invoke-virtual {v8, v12, v13}, Lc0/g$a;->g(J)V

    invoke-virtual {v8}, Lc0/g$a;->a()Lc0/g;

    move-result-object v11

    move-object v8, v4

    goto :goto_c3

    :cond_94
    move-object/from16 v18, v8

    move-object/from16 v17, v9

    cmp-long v8, v12, v6

    if-nez v8, :cond_9f

    iget-wide v12, v1, Ld0/c;->o:J

    goto :goto_a9

    :cond_9f
    iget-wide v8, v1, Ld0/c;->o:J

    cmp-long v10, v8, v6

    if-eqz v10, :cond_a9

    invoke-static {v12, v13, v8, v9}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v12

    :cond_a9
    :goto_a9
    invoke-virtual/range {p1 .. p1}, Lc0/g;->a()Lc0/g$a;

    move-result-object v8

    iget-wide v9, v1, Ld0/c;->n:J

    invoke-virtual {v8, v9, v10}, Lc0/g$a;->h(J)V

    invoke-virtual {v8, v12, v13}, Lc0/g$a;->g(J)V

    invoke-virtual {v8}, Lc0/g$a;->a()Lc0/g;

    move-result-object v11

    if-eqz v3, :cond_bd

    move-object v8, v3

    goto :goto_c3

    :cond_bd
    invoke-interface {v5, v2}, Ld0/a;->c(Ld0/h;)V

    move-object/from16 v8, v18

    const/4 v2, 0x0

    :goto_c3
    iget-boolean v9, v1, Ld0/c;->r:Z

    if-nez v9, :cond_d2

    move-object/from16 v9, v18

    if-ne v8, v9, :cond_d4

    iget-wide v12, v1, Ld0/c;->n:J

    const-wide/32 v14, 0x19000

    add-long/2addr v12, v14

    goto :goto_d9

    :cond_d2
    move-object/from16 v9, v18

    :cond_d4
    const-wide v12, 0x7fffffffffffffffL

    :goto_d9
    iput-wide v12, v1, Ld0/c;->s:J

    const/4 v12, 0x1

    if-eqz p2, :cond_fa

    iget-object v13, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    if-ne v13, v9, :cond_e4

    const/4 v13, 0x1

    goto :goto_e5

    :cond_e4
    const/4 v13, 0x0

    :goto_e5
    invoke-static {v13}, Lcom/facebook/soloader/m;->e(Z)V

    if-ne v8, v9, :cond_eb

    return-void

    :cond_eb
    :try_start_eb
    invoke-direct/range {p0 .. p0}, Ld0/c;->k()V
    :try_end_ee
    .catchall {:try_start_eb .. :try_end_ee} :catchall_ef

    goto :goto_fa

    :catchall_ef
    move-exception v0

    move-object v3, v0

    iget-boolean v0, v2, Ld0/h;->d:Z

    xor-int/2addr v0, v12

    if-eqz v0, :cond_f9

    invoke-interface {v5, v2}, Ld0/a;->c(Ld0/h;)V

    :cond_f9
    throw v3

    :cond_fa
    :goto_fa
    if-eqz v2, :cond_103

    iget-boolean v9, v2, Ld0/h;->d:Z

    xor-int/2addr v9, v12

    if-eqz v9, :cond_103

    iput-object v2, v1, Ld0/c;->p:Ld0/h;

    :cond_103
    iput-object v8, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    iput-object v11, v1, Ld0/c;->k:Lc0/g;

    const-wide/16 v13, 0x0

    iput-wide v13, v1, Ld0/c;->m:J

    invoke-interface {v8, v11}, Landroidx/media3/datasource/b;->a(Lc0/g;)J

    move-result-wide v13

    new-instance v2, Ld0/k;

    invoke-direct {v2}, Ld0/k;-><init>()V

    iget-wide v10, v11, Lc0/g;->g:J

    cmp-long v15, v10, v6

    if-nez v15, :cond_126

    cmp-long v10, v13, v6

    if-eqz v10, :cond_126

    iput-wide v13, v1, Ld0/c;->o:J

    iget-wide v6, v1, Ld0/c;->n:J

    add-long/2addr v6, v13

    invoke-static {v2, v6, v7}, Ld0/k;->c(Ld0/k;J)V

    :cond_126
    iget-object v6, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    if-ne v6, v4, :cond_12c

    const/4 v10, 0x1

    goto :goto_12d

    :cond_12c
    const/4 v10, 0x0

    :goto_12d
    xor-int/lit8 v4, v10, 0x1

    if-eqz v4, :cond_147

    invoke-interface {v8}, Landroidx/media3/datasource/b;->getUri()Landroid/net/Uri;

    move-result-object v4

    iput-object v4, v1, Ld0/c;->i:Landroid/net/Uri;

    iget-object v0, v0, Lc0/g;->a:Landroid/net/Uri;

    invoke-virtual {v0, v4}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v12

    if-eqz v0, :cond_143

    iget-object v10, v1, Ld0/c;->i:Landroid/net/Uri;

    goto :goto_144

    :cond_143
    const/4 v10, 0x0

    :goto_144
    invoke-static {v2, v10}, Ld0/k;->d(Ld0/k;Landroid/net/Uri;)V

    :cond_147
    iget-object v0, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    if-ne v0, v3, :cond_150

    move-object/from16 v0, v17

    invoke-interface {v5, v0, v2}, Ld0/a;->f(Ljava/lang/String;Ld0/k;)V

    :cond_150
    return-void
.end method


# virtual methods
.method public final a(Lc0/g;)J
    .registers 18
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    iget-object v2, v1, Ld0/c;->a:Ld0/a;

    :try_start_6
    iget-object v4, v1, Ld0/c;->e:Ld0/g;

    check-cast v4, LO0/d;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v4, v0, Lc0/g;->h:Ljava/lang/String;
    :try_end_f
    .catchall {:try_start_6 .. :try_end_f} :catchall_62

    iget-wide v5, v0, Lc0/g;->f:J

    if-eqz v4, :cond_14

    goto :goto_1a

    :cond_14
    :try_start_14
    iget-object v4, v0, Lc0/g;->a:Landroid/net/Uri;

    invoke-virtual {v4}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_1a
    invoke-virtual/range {p1 .. p1}, Lc0/g;->a()Lc0/g$a;

    move-result-object v7

    invoke-virtual {v7, v4}, Lc0/g$a;->f(Ljava/lang/String;)V

    invoke-virtual {v7}, Lc0/g$a;->a()Lc0/g;

    move-result-object v7

    iput-object v7, v1, Ld0/c;->j:Lc0/g;

    iget-object v8, v7, Lc0/g;->a:Landroid/net/Uri;

    invoke-interface {v2, v4}, Ld0/a;->a(Ljava/lang/String;)Ld0/l;

    move-result-object v9

    invoke-virtual {v9}, Ld0/l;->d()Ljava/lang/String;

    move-result-object v9

    if-nez v9, :cond_35

    const/4 v9, 0x0

    goto :goto_39

    :cond_35
    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v9

    :goto_39
    if-eqz v9, :cond_3c

    move-object v8, v9

    :cond_3c
    iput-object v8, v1, Ld0/c;->i:Landroid/net/Uri;

    iput-wide v5, v1, Ld0/c;->n:J

    iget-boolean v8, v1, Ld0/c;->g:Z
    :try_end_42
    .catchall {:try_start_14 .. :try_end_42} :catchall_62

    const/4 v9, 0x0

    const-wide/16 v10, -0x1

    iget-wide v12, v0, Lc0/g;->g:J

    if-eqz v8, :cond_4e

    :try_start_49
    iget-boolean v0, v1, Ld0/c;->q:Z

    if-eqz v0, :cond_4e

    goto :goto_56

    :cond_4e
    iget-boolean v0, v1, Ld0/c;->h:Z

    if-eqz v0, :cond_58

    cmp-long v0, v12, v10

    if-nez v0, :cond_58

    :goto_56
    const/4 v0, 0x1

    goto :goto_59

    :cond_58
    const/4 v0, 0x0

    :goto_59
    iput-boolean v0, v1, Ld0/c;->r:Z

    const-wide/16 v14, 0x0

    if-eqz v0, :cond_64

    iput-wide v10, v1, Ld0/c;->o:J

    goto :goto_82

    :catchall_62
    move-exception v0

    goto :goto_a7

    :cond_64
    invoke-interface {v2, v4}, Ld0/a;->a(Ljava/lang/String;)Ld0/l;

    move-result-object v0

    invoke-virtual {v0}, Ld0/l;->c()J

    move-result-wide v3

    iput-wide v3, v1, Ld0/c;->o:J

    cmp-long v0, v3, v10

    if-eqz v0, :cond_82

    sub-long/2addr v3, v5

    iput-wide v3, v1, Ld0/c;->o:J

    cmp-long v0, v3, v14

    if-ltz v0, :cond_7a

    goto :goto_82

    :cond_7a
    new-instance v0, Lc0/e;

    const/16 v3, 0x7d8

    invoke-direct {v0, v3}, Lc0/e;-><init>(I)V

    throw v0

    :cond_82
    :goto_82
    cmp-long v0, v12, v10

    if-eqz v0, :cond_94

    iget-wide v3, v1, Ld0/c;->o:J

    cmp-long v5, v3, v10

    if-nez v5, :cond_8e

    move-wide v3, v12

    goto :goto_92

    :cond_8e
    invoke-static {v3, v4, v12, v13}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    :goto_92
    iput-wide v3, v1, Ld0/c;->o:J

    :cond_94
    iget-wide v3, v1, Ld0/c;->o:J

    cmp-long v5, v3, v14

    if-gtz v5, :cond_9e

    cmp-long v5, v3, v10

    if-nez v5, :cond_a1

    :cond_9e
    invoke-direct {v1, v7, v9}, Ld0/c;->l(Lc0/g;Z)V

    :cond_a1
    if-eqz v0, :cond_a4

    goto :goto_a6

    :cond_a4
    iget-wide v12, v1, Ld0/c;->o:J
    :try_end_a6
    .catchall {:try_start_49 .. :try_end_a6} :catchall_62

    :goto_a6
    return-wide v12

    :goto_a7
    iget-object v3, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    iget-object v4, v1, Ld0/c;->b:Landroidx/media3/datasource/b;

    if-eq v3, v4, :cond_b1

    instance-of v3, v0, Ld0/a$a;

    if-eqz v3, :cond_b4

    :cond_b1
    const/4 v2, 0x1

    iput-boolean v2, v1, Ld0/c;->q:Z

    :cond_b4
    throw v0
.end method

.method public final c()Ljava/util/Map;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Ld0/c;->l:Landroidx/media3/datasource/b;

    iget-object v1, p0, Ld0/c;->b:Landroidx/media3/datasource/b;

    const/4 v2, 0x1

    if-ne v0, v1, :cond_9

    const/4 v0, 0x1

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    xor-int/2addr v0, v2

    if-eqz v0, :cond_14

    iget-object v0, p0, Ld0/c;->d:Landroidx/media3/datasource/b;

    invoke-interface {v0}, Landroidx/media3/datasource/b;->c()Ljava/util/Map;

    move-result-object v0

    goto :goto_18

    :cond_14
    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    :goto_18
    return-object v0
.end method

.method public final close()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x0

    iput-object v0, p0, Ld0/c;->j:Lc0/g;

    iput-object v0, p0, Ld0/c;->i:Landroid/net/Uri;

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Ld0/c;->n:J

    :try_start_9
    invoke-direct {p0}, Ld0/c;->k()V
    :try_end_c
    .catchall {:try_start_9 .. :try_end_c} :catchall_d

    return-void

    :catchall_d
    move-exception v0

    iget-object v1, p0, Ld0/c;->l:Landroidx/media3/datasource/b;

    iget-object v2, p0, Ld0/c;->b:Landroidx/media3/datasource/b;

    if-eq v1, v2, :cond_18

    instance-of v1, v0, Ld0/a$a;

    if-eqz v1, :cond_1b

    :cond_18
    const/4 v1, 0x1

    iput-boolean v1, p0, Ld0/c;->q:Z

    :cond_1b
    throw v0
.end method

.method public final e(Lc0/r;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Ld0/c;->b:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1}, Landroidx/media3/datasource/b;->e(Lc0/r;)V

    iget-object v0, p0, Ld0/c;->d:Landroidx/media3/datasource/b;

    invoke-interface {v0, p1}, Landroidx/media3/datasource/b;->e(Lc0/r;)V

    return-void
.end method

.method public final getUri()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Ld0/c;->i:Landroid/net/Uri;

    return-object v0
.end method

.method public final read([BII)I
    .registers 21
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v1, p0

    move/from16 v0, p3

    iget-object v2, v1, Ld0/c;->b:Landroidx/media3/datasource/b;

    const/4 v3, 0x0

    if-nez v0, :cond_a

    return v3

    :cond_a
    iget-wide v4, v1, Ld0/c;->o:J

    const/4 v6, -0x1

    const-wide/16 v7, 0x0

    cmp-long v9, v4, v7

    if-nez v9, :cond_14

    return v6

    :cond_14
    iget-object v4, v1, Ld0/c;->j:Lc0/g;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v5, v1, Ld0/c;->k:Lc0/g;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v9, 0x1

    :try_start_1f
    iget-wide v10, v1, Ld0/c;->n:J

    iget-wide v12, v1, Ld0/c;->s:J

    cmp-long v14, v10, v12

    if-ltz v14, :cond_2e

    invoke-direct {v1, v4, v9}, Ld0/c;->l(Lc0/g;Z)V

    goto :goto_2e

    :catchall_2b
    move-exception v0

    goto/16 :goto_a3

    :cond_2e
    :goto_2e
    iget-object v10, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v11, p1

    move/from16 v12, p2

    invoke-interface {v10, v11, v12, v0}, Landroidx/media3/common/i;->read([BII)I

    move-result v10

    const-wide/16 v13, -0x1

    if-eq v10, v6, :cond_56

    iget-wide v3, v1, Ld0/c;->n:J

    int-to-long v5, v10

    add-long/2addr v3, v5

    iput-wide v3, v1, Ld0/c;->n:J

    iget-wide v3, v1, Ld0/c;->m:J

    add-long/2addr v3, v5

    iput-wide v3, v1, Ld0/c;->m:J

    iget-wide v3, v1, Ld0/c;->o:J

    cmp-long v0, v3, v13

    if-eqz v0, :cond_53

    sub-long/2addr v3, v5

    iput-wide v3, v1, Ld0/c;->o:J

    :cond_53
    move/from16 v16, v10

    goto :goto_97

    :cond_56
    iget-object v6, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    if-ne v6, v2, :cond_5c

    const/4 v15, 0x1

    goto :goto_5d

    :cond_5c
    const/4 v15, 0x0

    :goto_5d
    xor-int/2addr v15, v9

    if-eqz v15, :cond_88

    move/from16 v16, v10

    iget-wide v9, v5, Lc0/g;->g:J

    cmp-long v5, v9, v13

    if-eqz v5, :cond_6e

    iget-wide v13, v1, Ld0/c;->m:J

    cmp-long v5, v13, v9

    if-gez v5, :cond_8a

    :cond_6e
    iget-object v0, v4, Lc0/g;->h:Ljava/lang/String;

    sget v3, La0/T;->a:I

    iput-wide v7, v1, Ld0/c;->o:J

    iget-object v3, v1, Ld0/c;->c:Lc0/q;

    if-ne v6, v3, :cond_97

    new-instance v3, Ld0/k;

    invoke-direct {v3}, Ld0/k;-><init>()V

    iget-wide v4, v1, Ld0/c;->n:J

    invoke-static {v3, v4, v5}, Ld0/k;->c(Ld0/k;J)V

    iget-object v4, v1, Ld0/c;->a:Ld0/a;

    invoke-interface {v4, v0, v3}, Ld0/a;->f(Ljava/lang/String;Ld0/k;)V

    goto :goto_97

    :cond_88
    move/from16 v16, v10

    :cond_8a
    iget-wide v5, v1, Ld0/c;->o:J

    cmp-long v9, v5, v7

    if-gtz v9, :cond_98

    const-wide/16 v7, -0x1

    cmp-long v9, v5, v7

    if-nez v9, :cond_97

    goto :goto_98

    :cond_97
    :goto_97
    return v16

    :cond_98
    :goto_98
    invoke-direct/range {p0 .. p0}, Ld0/c;->k()V

    invoke-direct {v1, v4, v3}, Ld0/c;->l(Lc0/g;Z)V

    invoke-virtual/range {p0 .. p3}, Ld0/c;->read([BII)I

    move-result v0
    :try_end_a2
    .catchall {:try_start_1f .. :try_end_a2} :catchall_2b

    return v0

    :goto_a3
    iget-object v3, v1, Ld0/c;->l:Landroidx/media3/datasource/b;

    if-eq v3, v2, :cond_ab

    instance-of v2, v0, Ld0/a$a;

    if-eqz v2, :cond_ae

    :cond_ab
    const/4 v2, 0x1

    iput-boolean v2, v1, Ld0/c;->q:Z

    :cond_ae
    throw v0
.end method
