.class public final Ld0/b;
.super Ljava/lang/Object;
.source "CacheDataSink.java"

# interfaces
.implements Lc0/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld0/b$a;,
        Ld0/b$b;
    }
.end annotation


# instance fields
.field private final a:Ld0/a;

.field private final b:J

.field private final c:I

.field private d:Lc0/g;

.field private e:J

.field private f:Ljava/io/File;

.field private g:Ljava/io/OutputStream;

.field private h:J

.field private i:J

.field private j:Ld0/p;


# direct methods
.method public constructor <init>(Ld0/a;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld0/b;->a:Ld0/a;

    const-wide/32 v0, 0x500000

    iput-wide v0, p0, Ld0/b;->b:J

    const/16 p1, 0x5000

    iput p1, p0, Ld0/b;->c:I

    return-void
.end method

.method private b()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Ld0/b;->g:Ljava/io/OutputStream;

    if-nez v0, :cond_5

    return-void

    :cond_5
    const/4 v1, 0x0

    :try_start_6
    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_1c

    iget-object v0, p0, Ld0/b;->g:Ljava/io/OutputStream;

    invoke-static {v0}, La0/T;->h(Ljava/io/Closeable;)V

    iput-object v1, p0, Ld0/b;->g:Ljava/io/OutputStream;

    iget-object v0, p0, Ld0/b;->f:Ljava/io/File;

    iput-object v1, p0, Ld0/b;->f:Ljava/io/File;

    iget-object v1, p0, Ld0/b;->a:Ld0/a;

    iget-wide v2, p0, Ld0/b;->h:J

    invoke-interface {v1, v0, v2, v3}, Ld0/a;->h(Ljava/io/File;J)V

    return-void

    :catchall_1c
    move-exception v0

    iget-object v2, p0, Ld0/b;->g:Ljava/io/OutputStream;

    invoke-static {v2}, La0/T;->h(Ljava/io/Closeable;)V

    iput-object v1, p0, Ld0/b;->g:Ljava/io/OutputStream;

    iget-object v2, p0, Ld0/b;->f:Ljava/io/File;

    iput-object v1, p0, Ld0/b;->f:Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    throw v0
.end method

.method private c(Lc0/g;)V
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-wide v0, p1, Lc0/g;->g:J

    const-wide/16 v2, -0x1

    cmp-long v4, v0, v2

    if-nez v4, :cond_a

    :goto_8
    move-wide v7, v2

    goto :goto_14

    :cond_a
    iget-wide v2, p0, Ld0/b;->i:J

    sub-long/2addr v0, v2

    iget-wide v2, p0, Ld0/b;->e:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    goto :goto_8

    :goto_14
    sget v0, La0/T;->a:I

    iget-wide v0, p1, Lc0/g;->f:J

    iget-wide v2, p0, Ld0/b;->i:J

    add-long v5, v0, v2

    iget-object v4, p0, Ld0/b;->a:Ld0/a;

    iget-object v9, p1, Lc0/g;->h:Ljava/lang/String;

    invoke-interface/range {v4 .. v9}, Ld0/a;->g(JJLjava/lang/String;)Ljava/io/File;

    move-result-object p1

    iput-object p1, p0, Ld0/b;->f:Ljava/io/File;

    new-instance p1, Ljava/io/FileOutputStream;

    iget-object v0, p0, Ld0/b;->f:Ljava/io/File;

    invoke-direct {p1, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    iget v0, p0, Ld0/b;->c:I

    if-lez v0, :cond_45

    iget-object v1, p0, Ld0/b;->j:Ld0/p;

    if-nez v1, :cond_3d

    new-instance v1, Ld0/p;

    invoke-direct {v1, p1, v0}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;I)V

    iput-object v1, p0, Ld0/b;->j:Ld0/p;

    goto :goto_40

    :cond_3d
    invoke-virtual {v1, p1}, Ld0/p;->c(Ljava/io/OutputStream;)V

    :goto_40
    iget-object p1, p0, Ld0/b;->j:Ld0/p;

    iput-object p1, p0, Ld0/b;->g:Ljava/io/OutputStream;

    goto :goto_47

    :cond_45
    iput-object p1, p0, Ld0/b;->g:Ljava/io/OutputStream;

    :goto_47
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Ld0/b;->h:J

    return-void
.end method


# virtual methods
.method public final a(Lc0/g;)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/b$a;
        }
    .end annotation

    iget-object v0, p1, Lc0/g;->h:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v0, p1, Lc0/g;->g:J

    const-wide/16 v2, -0x1

    cmp-long v4, v0, v2

    if-nez v4, :cond_18

    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Lc0/g;->c(I)Z

    move-result v0

    if-eqz v0, :cond_18

    const/4 p1, 0x0

    iput-object p1, p0, Ld0/b;->d:Lc0/g;

    return-void

    :cond_18
    iput-object p1, p0, Ld0/b;->d:Lc0/g;

    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Lc0/g;->c(I)Z

    move-result v0

    if-eqz v0, :cond_24

    iget-wide v0, p0, Ld0/b;->b:J

    goto :goto_29

    :cond_24
    const-wide v0, 0x7fffffffffffffffL

    :goto_29
    iput-wide v0, p0, Ld0/b;->e:J

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Ld0/b;->i:J

    :try_start_2f
    invoke-direct {p0, p1}, Ld0/b;->c(Lc0/g;)V
    :try_end_32
    .catch Ljava/io/IOException; {:try_start_2f .. :try_end_32} :catch_33

    return-void

    :catch_33
    move-exception p1

    new-instance v0, Ld0/b$a;

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final close()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/b$a;
        }
    .end annotation

    iget-object v0, p0, Ld0/b;->d:Lc0/g;

    if-nez v0, :cond_5

    return-void

    :cond_5
    :try_start_5
    invoke-direct {p0}, Ld0/b;->b()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_8} :catch_9

    return-void

    :catch_9
    move-exception v0

    new-instance v1, Ld0/b$a;

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method

.method public final write([BII)V
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/b$a;
        }
    .end annotation

    iget-object v0, p0, Ld0/b;->d:Lc0/g;

    if-nez v0, :cond_5

    return-void

    :cond_5
    const/4 v1, 0x0

    :goto_6
    if-ge v1, p3, :cond_42

    :try_start_8
    iget-wide v2, p0, Ld0/b;->h:J

    iget-wide v4, p0, Ld0/b;->e:J

    cmp-long v6, v2, v4

    if-nez v6, :cond_19

    invoke-direct {p0}, Ld0/b;->b()V

    invoke-direct {p0, v0}, Ld0/b;->c(Lc0/g;)V

    goto :goto_19

    :catch_17
    move-exception p1

    goto :goto_3c

    :cond_19
    :goto_19
    sub-int v2, p3, v1

    int-to-long v2, v2

    iget-wide v4, p0, Ld0/b;->e:J

    iget-wide v6, p0, Ld0/b;->h:J

    sub-long/2addr v4, v6

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    long-to-int v3, v2

    iget-object v2, p0, Ld0/b;->g:Ljava/io/OutputStream;

    sget v4, La0/T;->a:I

    add-int v4, p2, v1

    invoke-virtual {v2, p1, v4, v3}, Ljava/io/OutputStream;->write([BII)V

    add-int/2addr v1, v3

    iget-wide v4, p0, Ld0/b;->h:J

    int-to-long v2, v3

    add-long/2addr v4, v2

    iput-wide v4, p0, Ld0/b;->h:J

    iget-wide v4, p0, Ld0/b;->i:J

    add-long/2addr v4, v2

    iput-wide v4, p0, Ld0/b;->i:J
    :try_end_3b
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_3b} :catch_17

    goto :goto_6

    :goto_3c
    new-instance p2, Ld0/b$a;

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_42
    return-void
.end method
