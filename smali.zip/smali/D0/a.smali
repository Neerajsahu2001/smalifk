.class public interface abstract Ld0/a;
.super Ljava/lang/Object;
.source "Cache.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld0/a$a;,
        Ld0/a$b;
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/String;)Ld0/l;
.end method

.method public abstract b(Ld0/h;)V
.end method

.method public abstract c(Ld0/h;)V
.end method

.method public abstract d(JJLjava/lang/String;)Ld0/h;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;,
            Ld0/a$a;
        }
    .end annotation
.end method

.method public abstract e(JJLjava/lang/String;)Ld0/h;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation
.end method

.method public abstract f(Ljava/lang/String;Ld0/k;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation
.end method

.method public abstract g(JJLjava/lang/String;)Ljava/io/File;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation
.end method

.method public abstract h(Ljava/io/File;J)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation
.end method

.method public abstract release()V
.end method
