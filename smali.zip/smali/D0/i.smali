.class final Ld0/i;
.super Ljava/lang/Object;
.source "CachedContent.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld0/i$a;
    }
.end annotation


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;

.field private final c:Ljava/util/TreeSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeSet<",
            "Ld0/s;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ld0/i$a;",
            ">;"
        }
    .end annotation
.end field

.field private e:Ld0/l;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ld0/l;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ld0/i;->a:I

    iput-object p2, p0, Ld0/i;->b:Ljava/lang/String;

    iput-object p3, p0, Ld0/i;->e:Ld0/l;

    new-instance p1, Ljava/util/TreeSet;

    invoke-direct {p1}, Ljava/util/TreeSet;-><init>()V

    iput-object p1, p0, Ld0/i;->c:Ljava/util/TreeSet;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Ld0/i;->d:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final a(Ld0/s;)V
    .registers 3

    iget-object v0, p0, Ld0/i;->c:Ljava/util/TreeSet;

    invoke-virtual {v0, p1}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final b(Ld0/k;)Z
    .registers 3

    iget-object v0, p0, Ld0/i;->e:Ld0/l;

    invoke-virtual {v0, p1}, Ld0/l;->a(Ld0/k;)Ld0/l;

    move-result-object p1

    iput-object p1, p0, Ld0/i;->e:Ld0/l;

    invoke-virtual {p1, v0}, Ld0/l;->equals(Ljava/lang/Object;)Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    return p1
.end method

.method public final c()Ld0/l;
    .registers 2

    iget-object v0, p0, Ld0/i;->e:Ld0/l;

    return-object v0
.end method

.method public final d(JJ)Ld0/s;
    .registers 15

    new-instance v9, Ld0/s;

    iget-object v1, p0, Ld0/i;->b:Ljava/lang/String;

    const-wide/16 v4, -0x1

    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v8, 0x0

    move-object v0, v9

    move-wide v2, p1

    invoke-direct/range {v0 .. v8}, Ld0/h;-><init>(Ljava/lang/String;JJJLjava/io/File;)V

    iget-object v0, p0, Ld0/i;->c:Ljava/util/TreeSet;

    invoke-virtual {v0, v9}, Ljava/util/TreeSet;->floor(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld0/s;

    if-eqz v1, :cond_25

    iget-wide v2, v1, Ld0/h;->b:J

    iget-wide v4, v1, Ld0/h;->c:J

    add-long/2addr v2, v4

    cmp-long v4, v2, p1

    if-lez v4, :cond_25

    return-object v1

    :cond_25
    invoke-virtual {v0, v9}, Ljava/util/TreeSet;->ceiling(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld0/s;

    if-eqz v0, :cond_3c

    iget-wide v0, v0, Ld0/h;->b:J

    sub-long/2addr v0, p1

    const-wide/16 v2, -0x1

    cmp-long v4, p3, v2

    if-nez v4, :cond_38

    move-wide p3, v0

    goto :goto_3c

    :cond_38
    invoke-static {v0, v1, p3, p4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p3

    :cond_3c
    :goto_3c
    move-wide v4, p3

    new-instance p3, Ld0/s;

    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v8, 0x0

    iget-object v1, p0, Ld0/i;->b:Ljava/lang/String;

    move-object v0, p3

    move-wide v2, p1

    invoke-direct/range {v0 .. v8}, Ld0/h;-><init>(Ljava/lang/String;JJJLjava/io/File;)V

    return-object p3
.end method

.method public final e()Ljava/util/TreeSet;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/TreeSet<",
            "Ld0/s;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ld0/i;->c:Ljava/util/TreeSet;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    const/4 v1, 0x0

    if-eqz p1, :cond_39

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const-class v3, Ld0/i;

    if-eq v3, v2, :cond_10

    goto :goto_39

    :cond_10
    check-cast p1, Ld0/i;

    iget v2, p0, Ld0/i;->a:I

    iget v3, p1, Ld0/i;->a:I

    if-ne v2, v3, :cond_37

    iget-object v2, p0, Ld0/i;->b:Ljava/lang/String;

    iget-object v3, p1, Ld0/i;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_37

    iget-object v2, p0, Ld0/i;->c:Ljava/util/TreeSet;

    iget-object v3, p1, Ld0/i;->c:Ljava/util/TreeSet;

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_37

    iget-object v2, p0, Ld0/i;->e:Ld0/l;

    iget-object p1, p1, Ld0/i;->e:Ld0/l;

    invoke-virtual {v2, p1}, Ld0/l;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_37

    goto :goto_38

    :cond_37
    const/4 v0, 0x0

    :goto_38
    return v0

    :cond_39
    :goto_39
    return v1
.end method

.method public final f()Z
    .registers 2

    iget-object v0, p0, Ld0/i;->c:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->isEmpty()Z

    move-result v0

    return v0
.end method

.method public final g(JJ)Z
    .registers 14

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_2
    iget-object v2, p0, Ld0/i;->d:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_34

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/i$a;

    iget-wide v3, v2, Ld0/i$a;->a:J

    iget-wide v5, v2, Ld0/i$a;->b:J

    const-wide/16 v7, -0x1

    cmp-long v2, v5, v7

    if-nez v2, :cond_1f

    cmp-long v2, p1, v3

    if-ltz v2, :cond_31

    goto :goto_2f

    :cond_1f
    cmp-long v2, p3, v7

    if-nez v2, :cond_24

    goto :goto_31

    :cond_24
    cmp-long v2, v3, p1

    if-gtz v2, :cond_31

    add-long v7, p1, p3

    add-long/2addr v3, v5

    cmp-long v2, v7, v3

    if-gtz v2, :cond_31

    :goto_2f
    const/4 p1, 0x1

    return p1

    :cond_31
    :goto_31
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_34
    return v0
.end method

.method public final h()Z
    .registers 2

    iget-object v0, p0, Ld0/i;->d:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    return v0
.end method

.method public final hashCode()I
    .registers 4

    iget v0, p0, Ld0/i;->a:I

    const/16 v1, 0x1f

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Ld0/i;->b:Ljava/lang/String;

    invoke-static {v2, v0, v1}, LD/a;->a(Ljava/lang/String;II)I

    move-result v0

    iget-object v1, p0, Ld0/i;->e:Ld0/l;

    invoke-virtual {v1}, Ld0/l;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public final i(JJ)Z
    .registers 14

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_2
    iget-object v2, p0, Ld0/i;->d:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_33

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/i$a;

    iget-wide v3, v2, Ld0/i$a;->a:J

    const-wide/16 v5, -0x1

    cmp-long v7, v3, p1

    if-gtz v7, :cond_24

    iget-wide v7, v2, Ld0/i$a;->b:J

    cmp-long v2, v7, v5

    if-eqz v2, :cond_32

    add-long/2addr v3, v7

    cmp-long v2, v3, p1

    if-lez v2, :cond_2f

    goto :goto_32

    :cond_24
    cmp-long v2, p3, v5

    if-eqz v2, :cond_32

    add-long v5, p1, p3

    cmp-long v2, v5, v3

    if-lez v2, :cond_2f

    goto :goto_32

    :cond_2f
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_32
    :goto_32
    return v0

    :cond_33
    new-instance v0, Ld0/i$a;

    invoke-direct {v0, p1, p2, p3, p4}, Ld0/i$a;-><init>(JJ)V

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 p1, 0x1

    return p1
.end method

.method public final j(Ld0/h;)Z
    .registers 3

    iget-object v0, p0, Ld0/i;->c:Ljava/util/TreeSet;

    invoke-virtual {v0, p1}, Ljava/util/TreeSet;->remove(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    iget-object p1, p1, Ld0/h;->e:Ljava/io/File;

    if-eqz p1, :cond_f

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    :cond_f
    const/4 p1, 0x1

    return p1

    :cond_11
    const/4 p1, 0x0

    return p1
.end method

.method public final k(Ld0/s;JZ)Ld0/s;
    .registers 20

    move-object v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Ld0/i;->c:Ljava/util/TreeSet;

    invoke-virtual {v2, v1}, Ljava/util/TreeSet;->remove(Ljava/lang/Object;)Z

    move-result v3

    invoke-static {v3}, Lcom/facebook/soloader/m;->e(Z)V

    iget-object v3, v1, Ld0/h;->e:Ljava/io/File;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz p4, :cond_47

    invoke-virtual {v3}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v6, v1, Ld0/h;->b:J

    iget v5, v0, Ld0/i;->a:I

    move-wide/from16 v8, p2

    invoke-static/range {v4 .. v9}, Ld0/s;->c(Ljava/io/File;IJJ)Ljava/io/File;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v5

    if-eqz v5, :cond_2c

    move-object v14, v4

    goto :goto_48

    :cond_2c
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Failed to rename "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " to "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v5, "CachedContent"

    invoke-static {v5, v4}, La0/p;->g(Ljava/lang/String;Ljava/lang/String;)V

    :cond_47
    move-object v14, v3

    :goto_48
    iget-boolean v3, v1, Ld0/h;->d:Z

    invoke-static {v3}, Lcom/facebook/soloader/m;->e(Z)V

    new-instance v3, Ld0/s;

    iget-wide v10, v1, Ld0/h;->c:J

    iget-object v7, v1, Ld0/h;->a:Ljava/lang/String;

    iget-wide v8, v1, Ld0/h;->b:J

    move-object v6, v3

    move-wide/from16 v12, p2

    invoke-direct/range {v6 .. v14}, Ld0/h;-><init>(Ljava/lang/String;JJJLjava/io/File;)V

    invoke-virtual {v2, v3}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    return-object v3
.end method

.method public final l(J)V
    .registers 8

    const/4 v0, 0x0

    :goto_1
    iget-object v1, p0, Ld0/i;->d:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1c

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/i$a;

    iget-wide v2, v2, Ld0/i$a;->a:J

    cmp-long v4, v2, p1

    if-nez v4, :cond_19

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    return-void

    :cond_19
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1c
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    throw p1
.end method
