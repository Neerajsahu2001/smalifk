.class public final Ld0/o;
.super Ljava/lang/Object;
.source "NoOpCacheEvictor.java"

# interfaces
.implements Ld0/d;


# virtual methods
.method public final a()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final b(Ld0/h;)V
    .registers 2

    return-void
.end method

.method public final c(Ld0/a;J)V
    .registers 4

    return-void
.end method

.method public final d(Ld0/a;Ld0/h;Ld0/h;)V
    .registers 4

    return-void
.end method

.method public final e(Ld0/a;Ld0/h;)V
    .registers 3

    return-void
.end method
