.class public final Ld0/c$a;
.super Ljava/lang/Object;
.source "CacheDataSource.java"

# interfaces
.implements Landroidx/media3/datasource/b$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:Ld0/a;

.field private b:Landroidx/media3/datasource/b$a;

.field private c:Lc0/c$a;

.field private d:Z

.field private e:Landroidx/media3/datasource/b$a;

.field private f:I


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/media3/datasource/d$b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ld0/c$a;->b:Landroidx/media3/datasource/b$a;

    return-void
.end method


# virtual methods
.method public final a()Landroidx/media3/datasource/b;
    .registers 9

    iget-object v0, p0, Ld0/c$a;->e:Landroidx/media3/datasource/b$a;

    const/4 v1, 0x0

    if-eqz v0, :cond_b

    invoke-interface {v0}, Landroidx/media3/datasource/b$a;->a()Landroidx/media3/datasource/b;

    move-result-object v0

    move-object v4, v0

    goto :goto_c

    :cond_b
    move-object v4, v1

    :goto_c
    iget v7, p0, Ld0/c$a;->f:I

    iget-object v3, p0, Ld0/c$a;->a:Ld0/a;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Ld0/c$a;->d:Z

    if-nez v0, :cond_22

    if-nez v4, :cond_1a

    goto :goto_22

    :cond_1a
    iget-object v0, p0, Ld0/c$a;->c:Lc0/c$a;

    if-eqz v0, :cond_24

    invoke-interface {v0}, Lc0/c$a;->a()Ld0/b;

    move-result-object v1

    :cond_22
    :goto_22
    move-object v6, v1

    goto :goto_31

    :cond_24
    new-instance v0, Ld0/b$b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v0, v3}, Ld0/b$b;->b(Ld0/a;)V

    invoke-virtual {v0}, Ld0/b$b;->a()Ld0/b;

    move-result-object v1

    goto :goto_22

    :goto_31
    new-instance v0, Ld0/c;

    iget-object v1, p0, Ld0/c$a;->b:Landroidx/media3/datasource/b$a;

    invoke-interface {v1}, Landroidx/media3/datasource/b$a;->a()Landroidx/media3/datasource/b;

    move-result-object v5

    move-object v2, v0

    invoke-direct/range {v2 .. v7}, Ld0/c;-><init>(Ld0/a;Landroidx/media3/datasource/b;Landroidx/media3/datasource/b;Lc0/c;I)V

    return-object v0
.end method

.method public final b(Ld0/a;)V
    .registers 2

    iput-object p1, p0, Ld0/c$a;->a:Ld0/a;

    return-void
.end method

.method public final c(Landroidx/media3/datasource/d$b;)V
    .registers 2

    iput-object p1, p0, Ld0/c$a;->b:Landroidx/media3/datasource/b$a;

    return-void
.end method

.method public final d(Ld0/b$b;)V
    .registers 2

    iput-object p1, p0, Ld0/c$a;->c:Lc0/c$a;

    const/4 p1, 0x0

    iput-boolean p1, p0, Ld0/c$a;->d:Z

    return-void
.end method

.method public final e()V
    .registers 2

    const/4 v0, 0x2

    iput v0, p0, Ld0/c$a;->f:I

    return-void
.end method

.method public final f(Landroidx/media3/datasource/DefaultDataSource$Factory;)V
    .registers 2

    iput-object p1, p0, Ld0/c$a;->e:Landroidx/media3/datasource/b$a;

    return-void
.end method
