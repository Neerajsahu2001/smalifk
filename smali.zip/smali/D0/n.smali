.class public final Ld0/n;
.super Ljava/lang/Object;
.source "LeastRecentlyUsedCacheEvictor.java"

# interfaces
.implements Ld0/d;


# instance fields
.field private final a:J

.field private final b:Ljava/util/TreeSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeSet<",
            "Ld0/h;",
            ">;"
        }
    .end annotation
.end field

.field private c:J


# direct methods
.method public constructor <init>(J)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Ld0/n;->a:J

    new-instance p1, Ljava/util/TreeSet;

    new-instance p2, Ld0/m;

    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    invoke-direct {p1, p2}, Ljava/util/TreeSet;-><init>(Ljava/util/Comparator;)V

    iput-object p1, p0, Ld0/n;->b:Ljava/util/TreeSet;

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public final b(Ld0/h;)V
    .registers 6

    iget-object v0, p0, Ld0/n;->b:Ljava/util/TreeSet;

    invoke-virtual {v0, p1}, Ljava/util/TreeSet;->remove(Ljava/lang/Object;)Z

    iget-wide v0, p0, Ld0/n;->c:J

    iget-wide v2, p1, Ld0/h;->c:J

    sub-long/2addr v0, v2

    iput-wide v0, p0, Ld0/n;->c:J

    return-void
.end method

.method public final c(Ld0/a;J)V
    .registers 9

    const-wide/16 v0, -0x1

    cmp-long v2, p2, v0

    if-eqz v2, :cond_21

    :goto_6
    iget-wide v0, p0, Ld0/n;->c:J

    add-long/2addr v0, p2

    iget-wide v2, p0, Ld0/n;->a:J

    cmp-long v4, v0, v2

    if-lez v4, :cond_21

    iget-object v0, p0, Ld0/n;->b:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_21

    invoke-virtual {v0}, Ljava/util/TreeSet;->first()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld0/h;

    invoke-interface {p1, v0}, Ld0/a;->b(Ld0/h;)V

    goto :goto_6

    :cond_21
    return-void
.end method

.method public final d(Ld0/a;Ld0/h;Ld0/h;)V
    .registers 4

    invoke-virtual {p0, p2}, Ld0/n;->b(Ld0/h;)V

    invoke-virtual {p0, p1, p3}, Ld0/n;->e(Ld0/a;Ld0/h;)V

    return-void
.end method

.method public final e(Ld0/a;Ld0/h;)V
    .registers 8

    iget-object v0, p0, Ld0/n;->b:Ljava/util/TreeSet;

    invoke-virtual {v0, p2}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    iget-wide v1, p0, Ld0/n;->c:J

    iget-wide v3, p2, Ld0/h;->c:J

    add-long/2addr v1, v3

    iput-wide v1, p0, Ld0/n;->c:J

    :goto_c
    iget-wide v1, p0, Ld0/n;->c:J

    iget-wide v3, p0, Ld0/n;->a:J

    cmp-long p2, v1, v3

    if-lez p2, :cond_24

    invoke-virtual {v0}, Ljava/util/TreeSet;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_24

    invoke-virtual {v0}, Ljava/util/TreeSet;->first()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ld0/h;

    invoke-interface {p1, p2}, Ld0/a;->b(Ld0/h;)V

    goto :goto_c

    :cond_24
    return-void
.end method
