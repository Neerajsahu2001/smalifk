.class final Ld0/j$b;
.super Ljava/lang/Object;
.source "CachedContentIndex.java"

# interfaces
.implements Ld0/j$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# instance fields
.field private final a:Z

.field private final b:Ljavax/crypto/Cipher;

.field private final c:Ljavax/crypto/spec/SecretKeySpec;

.field private final d:Ljava/security/SecureRandom;

.field private final e:La0/a;

.field private f:Z

.field private g:Ld0/p;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Ld0/j$b;->a:Z

    const/4 v0, 0x0

    iput-object v0, p0, Ld0/j$b;->b:Ljavax/crypto/Cipher;

    iput-object v0, p0, Ld0/j$b;->c:Ljavax/crypto/spec/SecretKeySpec;

    iput-object v0, p0, Ld0/j$b;->d:Ljava/security/SecureRandom;

    new-instance v0, La0/a;

    invoke-direct {v0, p1}, La0/a;-><init>(Ljava/io/File;)V

    iput-object v0, p0, Ld0/j$b;->e:La0/a;

    return-void
.end method

.method private static h(Ld0/i;I)I
    .registers 6

    iget v0, p0, Ld0/i;->a:I

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Ld0/i;->b:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    const/4 v0, 0x2

    if-ge p1, v0, :cond_20

    invoke-virtual {p0}, Ld0/i;->c()Ld0/l;

    move-result-object p0

    invoke-virtual {p0}, Ld0/l;->c()J

    move-result-wide p0

    mul-int/lit8 v1, v1, 0x1f

    const/16 v0, 0x20

    ushr-long v2, p0, v0

    xor-long/2addr p0, v2

    long-to-int p1, p0

    add-int/2addr v1, p1

    goto :goto_2b

    :cond_20
    mul-int/lit8 v1, v1, 0x1f

    invoke-virtual {p0}, Ld0/i;->c()Ld0/l;

    move-result-object p0

    invoke-virtual {p0}, Ld0/l;->hashCode()I

    move-result p0

    add-int/2addr v1, p0

    :goto_2b
    return v1
.end method

.method private static i(ILjava/io/DataInputStream;)Ld0/i;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    if-ge p0, v2, :cond_1e

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide p0

    new-instance v2, Ld0/k;

    invoke-direct {v2}, Ld0/k;-><init>()V

    invoke-static {v2, p0, p1}, Ld0/k;->c(Ld0/k;J)V

    sget-object p0, Ld0/l;->c:Ld0/l;

    invoke-virtual {p0, v2}, Ld0/l;->a(Ld0/k;)Ld0/l;

    move-result-object p0

    goto :goto_22

    :cond_1e
    invoke-static {p1}, Ld0/j;->a(Ljava/io/DataInputStream;)Ld0/l;

    move-result-object p0

    :goto_22
    new-instance p1, Ld0/i;

    invoke-direct {p1, v0, v1, p0}, Ld0/i;-><init>(ILjava/lang/String;Ld0/l;)V

    return-object p1
.end method


# virtual methods
.method public final a(Ld0/i;)V
    .registers 2

    const/4 p1, 0x1

    iput-boolean p1, p0, Ld0/j$b;->f:Z

    return-void
.end method

.method public final b()Z
    .registers 2

    iget-object v0, p0, Ld0/j$b;->e:La0/a;

    invoke-virtual {v0}, La0/a;->c()Z

    move-result v0

    return v0
.end method

.method public final c(Ljava/util/HashMap;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ld0/i;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-boolean v0, p0, Ld0/j$b;->f:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    invoke-virtual {p0, p1}, Ld0/j$b;->f(Ljava/util/HashMap;)V

    return-void
.end method

.method public final d(J)V
    .registers 3

    return-void
.end method

.method public final delete()V
    .registers 2

    iget-object v0, p0, Ld0/j$b;->e:La0/a;

    invoke-virtual {v0}, La0/a;->a()V

    return-void
.end method

.method public final e(Ld0/i;Z)V
    .registers 3

    const/4 p1, 0x1

    iput-boolean p1, p0, Ld0/j$b;->f:Z

    return-void
.end method

.method public final f(Ljava/util/HashMap;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ld0/i;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Ld0/j$b;->b:Ljavax/crypto/Cipher;

    iget-object v1, p0, Ld0/j$b;->e:La0/a;

    const/4 v2, 0x0

    :try_start_5
    invoke-virtual {v1}, La0/a;->e()Ljava/io/OutputStream;

    move-result-object v3

    iget-object v4, p0, Ld0/j$b;->g:Ld0/p;

    if-nez v4, :cond_18

    new-instance v4, Ld0/p;

    invoke-direct {v4, v3}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V

    iput-object v4, p0, Ld0/j$b;->g:Ld0/p;

    goto :goto_1b

    :catchall_15
    move-exception p1

    goto/16 :goto_a0

    :cond_18
    invoke-virtual {v4, v3}, Ld0/p;->c(Ljava/io/OutputStream;)V

    :goto_1b
    iget-object v3, p0, Ld0/j$b;->g:Ld0/p;

    new-instance v4, Ljava/io/DataOutputStream;

    invoke-direct {v4, v3}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_22
    .catchall {:try_start_5 .. :try_end_22} :catchall_15

    const/4 v2, 0x2

    :try_start_23
    invoke-virtual {v4, v2}, Ljava/io/DataOutputStream;->writeInt(I)V
    :try_end_26
    .catchall {:try_start_23 .. :try_end_26} :catchall_55

    iget-boolean v5, p0, Ld0/j$b;->a:Z

    :try_start_28
    invoke-virtual {v4, v5}, Ljava/io/DataOutputStream;->writeInt(I)V

    if-eqz v5, :cond_61

    const/16 v5, 0x10

    new-array v5, v5, [B

    iget-object v6, p0, Ld0/j$b;->d:Ljava/security/SecureRandom;

    sget v7, La0/T;->a:I

    invoke-virtual {v6, v5}, Ljava/security/SecureRandom;->nextBytes([B)V

    invoke-virtual {v4, v5}, Ljava/io/OutputStream;->write([B)V

    new-instance v6, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {v6, v5}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V
    :try_end_40
    .catchall {:try_start_28 .. :try_end_40} :catchall_55

    :try_start_40
    iget-object v5, p0, Ld0/j$b;->c:Ljavax/crypto/spec/SecretKeySpec;

    const/4 v7, 0x1

    invoke-virtual {v0, v7, v5, v6}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V
    :try_end_46
    .catch Ljava/security/InvalidKeyException; {:try_start_40 .. :try_end_46} :catch_5a
    .catch Ljava/security/InvalidAlgorithmParameterException; {:try_start_40 .. :try_end_46} :catch_58
    .catchall {:try_start_40 .. :try_end_46} :catchall_55

    :try_start_46
    invoke-virtual {v4}, Ljava/io/DataOutputStream;->flush()V

    new-instance v5, Ljava/io/DataOutputStream;

    new-instance v6, Ljavax/crypto/CipherOutputStream;

    invoke-direct {v6, v3, v0}, Ljavax/crypto/CipherOutputStream;-><init>(Ljava/io/OutputStream;Ljavax/crypto/Cipher;)V

    invoke-direct {v5, v6}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    move-object v4, v5

    goto :goto_61

    :catchall_55
    move-exception p1

    move-object v2, v4

    goto :goto_a0

    :catch_58
    move-exception p1

    goto :goto_5b

    :catch_5a
    move-exception p1

    :goto_5b
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :cond_61
    :goto_61
    invoke-virtual {p1}, Ljava/util/HashMap;->size()I

    move-result v0

    invoke-virtual {v4, v0}, Ljava/io/DataOutputStream;->writeInt(I)V

    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v0, 0x0

    const/4 v3, 0x0

    :goto_72
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_95

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld0/i;

    iget v6, v5, Ld0/i;->a:I

    invoke-virtual {v4, v6}, Ljava/io/DataOutputStream;->writeInt(I)V

    iget-object v6, v5, Ld0/i;->b:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V

    invoke-virtual {v5}, Ld0/i;->c()Ld0/l;

    move-result-object v6

    invoke-static {v6, v4}, Ld0/j;->b(Ld0/l;Ljava/io/DataOutputStream;)V

    invoke-static {v5, v2}, Ld0/j$b;->h(Ld0/i;I)I

    move-result v5

    add-int/2addr v3, v5

    goto :goto_72

    :cond_95
    invoke-virtual {v4, v3}, Ljava/io/DataOutputStream;->writeInt(I)V

    invoke-virtual {v1, v4}, La0/a;->b(Ljava/io/DataOutputStream;)V
    :try_end_9b
    .catchall {:try_start_46 .. :try_end_9b} :catchall_55

    sget p1, La0/T;->a:I

    iput-boolean v0, p0, Ld0/j$b;->f:Z

    return-void

    :goto_a0
    invoke-static {v2}, La0/T;->h(Ljava/io/Closeable;)V

    throw p1
.end method

.method public final g(Ljava/util/HashMap;Landroid/util/SparseArray;)V
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ld0/i;",
            ">;",
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    iget-boolean v0, p0, Ld0/j$b;->f:Z

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    iget-object v0, p0, Ld0/j$b;->e:La0/a;

    invoke-virtual {v0}, La0/a;->c()Z

    move-result v2

    if-nez v2, :cond_11

    goto/16 :goto_bb

    :cond_11
    const/4 v2, 0x0

    :try_start_12
    new-instance v3, Ljava/io/BufferedInputStream;

    invoke-virtual {v0}, La0/a;->d()Ljava/io/FileInputStream;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    new-instance v4, Ljava/io/DataInputStream;

    invoke-direct {v4, v3}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_20
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_20} :catch_a5
    .catchall {:try_start_12 .. :try_end_20} :catchall_a3

    :try_start_20
    invoke-virtual {v4}, Ljava/io/DataInputStream;->readInt()I

    move-result v2

    if-ltz v2, :cond_35

    const/4 v5, 0x2

    if-le v2, v5, :cond_2a

    goto :goto_35

    :cond_2a
    invoke-virtual {v4}, Ljava/io/DataInputStream;->readInt()I

    move-result v6
    :try_end_2e
    .catch Ljava/io/IOException; {:try_start_20 .. :try_end_2e} :catch_5c
    .catchall {:try_start_20 .. :try_end_2e} :catchall_59

    and-int/2addr v6, v1

    if-eqz v6, :cond_68

    iget-object v6, p0, Ld0/j$b;->b:Ljavax/crypto/Cipher;

    if-nez v6, :cond_3a

    :cond_35
    :goto_35
    invoke-static {v4}, La0/T;->h(Ljava/io/Closeable;)V

    goto/16 :goto_b2

    :cond_3a
    const/16 v7, 0x10

    :try_start_3c
    new-array v7, v7, [B

    invoke-virtual {v4, v7}, Ljava/io/DataInputStream;->readFully([B)V

    new-instance v8, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {v8, v7}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V
    :try_end_46
    .catch Ljava/io/IOException; {:try_start_3c .. :try_end_46} :catch_5c
    .catchall {:try_start_3c .. :try_end_46} :catchall_59

    :try_start_46
    iget-object v7, p0, Ld0/j$b;->c:Ljavax/crypto/spec/SecretKeySpec;

    sget v9, La0/T;->a:I

    invoke-virtual {v6, v5, v7, v8}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V
    :try_end_4d
    .catch Ljava/security/InvalidKeyException; {:try_start_46 .. :try_end_4d} :catch_61
    .catch Ljava/security/InvalidAlgorithmParameterException; {:try_start_46 .. :try_end_4d} :catch_5f
    .catch Ljava/io/IOException; {:try_start_46 .. :try_end_4d} :catch_5c
    .catchall {:try_start_46 .. :try_end_4d} :catchall_59

    :try_start_4d
    new-instance v5, Ljava/io/DataInputStream;

    new-instance v7, Ljavax/crypto/CipherInputStream;

    invoke-direct {v7, v3, v6}, Ljavax/crypto/CipherInputStream;-><init>(Ljava/io/InputStream;Ljavax/crypto/Cipher;)V

    invoke-direct {v5, v7}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    move-object v4, v5

    goto :goto_6e

    :catchall_59
    move-exception p1

    move-object v2, v4

    goto :goto_a7

    :catch_5c
    nop

    move-object v2, v4

    goto :goto_ad

    :catch_5f
    move-exception v1

    goto :goto_62

    :catch_61
    move-exception v1

    :goto_62
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_68
    iget-boolean v3, p0, Ld0/j$b;->a:Z

    if-eqz v3, :cond_6e

    iput-boolean v1, p0, Ld0/j$b;->f:Z

    :cond_6e
    :goto_6e
    invoke-virtual {v4}, Ljava/io/DataInputStream;->readInt()I

    move-result v3

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    :goto_75
    if-ge v6, v3, :cond_8d

    invoke-static {v2, v4}, Ld0/j$b;->i(ILjava/io/DataInputStream;)Ld0/i;

    move-result-object v8
    :try_end_7b
    .catch Ljava/io/IOException; {:try_start_4d .. :try_end_7b} :catch_5c
    .catchall {:try_start_4d .. :try_end_7b} :catchall_59

    iget-object v9, v8, Ld0/i;->b:Ljava/lang/String;

    :try_start_7d
    invoke-virtual {p1, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget v10, v8, Ld0/i;->a:I

    invoke-virtual {p2, v10, v9}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    invoke-static {v8, v2}, Ld0/j$b;->h(Ld0/i;I)I

    move-result v8

    add-int/2addr v7, v8

    add-int/lit8 v6, v6, 0x1

    goto :goto_75

    :cond_8d
    invoke-virtual {v4}, Ljava/io/DataInputStream;->readInt()I

    move-result v2

    invoke-virtual {v4}, Ljava/io/InputStream;->read()I

    move-result v3
    :try_end_95
    .catch Ljava/io/IOException; {:try_start_7d .. :try_end_95} :catch_5c
    .catchall {:try_start_7d .. :try_end_95} :catchall_59

    const/4 v6, -0x1

    if-ne v3, v6, :cond_99

    goto :goto_9a

    :cond_99
    const/4 v1, 0x0

    :goto_9a
    if-ne v2, v7, :cond_35

    if-nez v1, :cond_9f

    goto :goto_35

    :cond_9f
    invoke-static {v4}, La0/T;->h(Ljava/io/Closeable;)V

    goto :goto_bb

    :catchall_a3
    move-exception p1

    goto :goto_a7

    :catch_a5
    nop

    goto :goto_ad

    :goto_a7
    if-eqz v2, :cond_ac

    invoke-static {v2}, La0/T;->h(Ljava/io/Closeable;)V

    :cond_ac
    throw p1

    :goto_ad
    if-eqz v2, :cond_b2

    invoke-static {v2}, La0/T;->h(Ljava/io/Closeable;)V

    :cond_b2
    :goto_b2
    invoke-virtual {p1}, Ljava/util/HashMap;->clear()V

    invoke-virtual {p2}, Landroid/util/SparseArray;->clear()V

    invoke-virtual {v0}, La0/a;->a()V

    :goto_bb
    return-void
.end method
