.class final Ld0/q;
.super Ljava/lang/Thread;
.source "SimpleCache.java"


# instance fields
.field final synthetic a:Landroid/os/ConditionVariable;

.field final synthetic b:Ld0/r;


# direct methods
.method constructor <init>(Ld0/r;Landroid/os/ConditionVariable;)V
    .registers 3

    iput-object p1, p0, Ld0/q;->b:Ld0/r;

    iput-object p2, p0, Ld0/q;->a:Landroid/os/ConditionVariable;

    const-string p1, "ExoPlayer:SimpleCacheInit"

    invoke-direct {p0, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Ld0/q;->b:Ld0/r;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Ld0/q;->a:Landroid/os/ConditionVariable;

    invoke-virtual {v1}, Landroid/os/ConditionVariable;->open()V

    iget-object v1, p0, Ld0/q;->b:Ld0/r;

    invoke-static {v1}, Ld0/r;->i(Ld0/r;)V

    iget-object v1, p0, Ld0/q;->b:Ld0/r;

    invoke-static {v1}, Ld0/r;->j(Ld0/r;)Ld0/d;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-exit v0

    return-void

    :catchall_18
    move-exception v1

    monitor-exit v0
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_18

    throw v1
.end method
