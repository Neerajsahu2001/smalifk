.class public final synthetic Ld0/m;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/util/Comparator;


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 12

    check-cast p1, Ld0/h;

    check-cast p2, Ld0/h;

    iget-wide v0, p1, Ld0/h;->f:J

    iget-wide v2, p2, Ld0/h;->f:J

    sub-long v4, v0, v2

    const-wide/16 v6, 0x0

    cmp-long v8, v4, v6

    if-nez v8, :cond_15

    invoke-virtual {p1, p2}, Ld0/h;->a(Ld0/h;)I

    move-result p1

    goto :goto_1c

    :cond_15
    cmp-long p1, v0, v2

    if-gez p1, :cond_1b

    const/4 p1, -0x1

    goto :goto_1c

    :cond_1b
    const/4 p1, 0x1

    :goto_1c
    return p1
.end method
