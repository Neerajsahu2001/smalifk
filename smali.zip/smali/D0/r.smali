.class public final Ld0/r;
.super Ljava/lang/Object;
.source "SimpleCache.java"

# interfaces
.implements Ld0/a;


# static fields
.field private static final k:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Ljava/io/File;

.field private final b:Ld0/d;

.field private final c:Ld0/j;

.field private final d:Ld0/f;

.field private final e:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ld0/a$b;",
            ">;>;"
        }
    .end annotation
.end field

.field private final f:Ljava/util/Random;

.field private final g:Z

.field private h:J

.field private i:Z

.field private j:Ld0/a$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Ld0/r;->k:Ljava/util/HashSet;

    return-void
.end method

.method public constructor <init>(Ljava/io/File;Ld0/d;Landroidx/media3/database/StandaloneDatabaseProvider;)V
    .registers 8

    new-instance v0, Ld0/j;

    invoke-direct {v0, p3, p1}, Ld0/j;-><init>(Landroidx/media3/database/StandaloneDatabaseProvider;Ljava/io/File;)V

    new-instance v1, Ld0/f;

    invoke-direct {v1, p3}, Ld0/f;-><init>(Landroidx/media3/database/StandaloneDatabaseProvider;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-class p3, Ld0/r;

    monitor-enter p3

    :try_start_10
    sget-object v2, Ld0/r;->k:Ljava/util/HashSet;

    invoke-virtual {p1}, Ljava/io/File;->getAbsoluteFile()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v2
    :try_end_1a
    .catchall {:try_start_10 .. :try_end_1a} :catchall_5a

    monitor-exit p3

    if-eqz v2, :cond_4e

    iput-object p1, p0, Ld0/r;->a:Ljava/io/File;

    iput-object p2, p0, Ld0/r;->b:Ld0/d;

    iput-object v0, p0, Ld0/r;->c:Ld0/j;

    iput-object v1, p0, Ld0/r;->d:Ld0/f;

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Ld0/r;->e:Ljava/util/HashMap;

    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    iput-object p1, p0, Ld0/r;->f:Ljava/util/Random;

    invoke-interface {p2}, Ld0/d;->a()Z

    move-result p1

    iput-boolean p1, p0, Ld0/r;->g:Z

    const-wide/16 p1, -0x1

    iput-wide p1, p0, Ld0/r;->h:J

    new-instance p1, Landroid/os/ConditionVariable;

    invoke-direct {p1}, Landroid/os/ConditionVariable;-><init>()V

    new-instance p2, Ld0/q;

    invoke-direct {p2, p0, p1}, Ld0/q;-><init>(Ld0/r;Landroid/os/ConditionVariable;)V

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    invoke-virtual {p1}, Landroid/os/ConditionVariable;->block()V

    return-void

    :cond_4e
    new-instance p2, Ljava/lang/IllegalStateException;

    const-string p3, "Another SimpleCache instance uses the folder: "

    invoke-static {p3, p1}, Landroidx/core/content/e;->a(Ljava/lang/String;Ljava/io/File;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :catchall_5a
    move-exception p1

    monitor-exit p3

    throw p1
.end method

.method static i(Ld0/r;)V
    .registers 13

    iget-object v0, p0, Ld0/r;->c:Ld0/j;

    iget-object v1, p0, Ld0/r;->a:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_13

    :try_start_a
    invoke-static {v1}, Ld0/r;->m(Ljava/io/File;)V
    :try_end_d
    .catch Ld0/a$a; {:try_start_a .. :try_end_d} :catch_e

    goto :goto_13

    :catch_e
    move-exception v0

    iput-object v0, p0, Ld0/r;->j:Ld0/a$a;

    goto/16 :goto_e4

    :cond_13
    :goto_13
    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v2

    const-string v3, "SimpleCache"

    if-nez v2, :cond_35

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Failed to list cache directory files: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, La0/p;->c(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ld0/a$a;

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    iput-object v1, p0, Ld0/r;->j:Ld0/a$a;

    goto/16 :goto_e4

    :cond_35
    array-length v4, v2

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_38
    const-wide/16 v7, -0x1

    if-ge v6, v4, :cond_72

    aget-object v9, v2, v6

    invoke-virtual {v9}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v10

    const-string v11, ".uid"

    invoke-virtual {v10, v11}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_6f

    const/16 v11, 0x2e

    :try_start_4c
    invoke-virtual {v10, v11}, Ljava/lang/String;->indexOf(I)I

    move-result v11

    invoke-virtual {v10, v5, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0x10

    invoke-static {v10, v11}, Ljava/lang/Long;->parseLong(Ljava/lang/String;I)J

    move-result-wide v4
    :try_end_5a
    .catch Ljava/lang/NumberFormatException; {:try_start_4c .. :try_end_5a} :catch_5b

    goto :goto_73

    :catch_5b
    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "Malformed UID file: "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v3, v7}, La0/p;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v9}, Ljava/io/File;->delete()Z

    :cond_6f
    add-int/lit8 v6, v6, 0x1

    goto :goto_38

    :cond_72
    move-wide v4, v7

    :goto_73
    iput-wide v4, p0, Ld0/r;->h:J

    cmp-long v6, v4, v7

    if-nez v6, :cond_9a

    :try_start_79
    invoke-static {v1}, Ld0/r;->n(Ljava/io/File;)J

    move-result-wide v4

    iput-wide v4, p0, Ld0/r;->h:J
    :try_end_7f
    .catch Ljava/io/IOException; {:try_start_79 .. :try_end_7f} :catch_80

    goto :goto_9a

    :catch_80
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "Failed to create cache UID: "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1, v0}, La0/p;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v2, Ld0/a$a;

    invoke-direct {v2, v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    iput-object v2, p0, Ld0/r;->j:Ld0/a$a;

    goto :goto_e4

    :cond_9a
    :goto_9a
    :try_start_9a
    iget-wide v4, p0, Ld0/r;->h:J

    invoke-virtual {v0, v4, v5}, Ld0/j;->h(J)V
    :try_end_9f
    .catch Ljava/io/IOException; {:try_start_9a .. :try_end_9f} :catch_b8

    const/4 v4, 0x1

    iget-object v5, p0, Ld0/r;->d:Ld0/f;

    if-eqz v5, :cond_ba

    :try_start_a4
    iget-wide v6, p0, Ld0/r;->h:J

    invoke-virtual {v5, v6, v7}, Ld0/f;->b(J)V

    invoke-virtual {v5}, Ld0/f;->a()Ljava/util/HashMap;

    move-result-object v6

    invoke-direct {p0, v1, v4, v2, v6}, Ld0/r;->o(Ljava/io/File;Z[Ljava/io/File;Ljava/util/HashMap;)V

    invoke-virtual {v6}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v2

    invoke-virtual {v5, v2}, Ld0/f;->d(Ljava/util/Set;)V

    goto :goto_be

    :catch_b8
    move-exception v0

    goto :goto_cc

    :cond_ba
    const/4 v5, 0x0

    invoke-direct {p0, v1, v4, v2, v5}, Ld0/r;->o(Ljava/io/File;Z[Ljava/io/File;Ljava/util/HashMap;)V
    :try_end_be
    .catch Ljava/io/IOException; {:try_start_a4 .. :try_end_be} :catch_b8

    :goto_be
    invoke-virtual {v0}, Ld0/j;->j()V

    :try_start_c1
    invoke-virtual {v0}, Ld0/j;->k()V
    :try_end_c4
    .catch Ljava/io/IOException; {:try_start_c1 .. :try_end_c4} :catch_c5

    goto :goto_e4

    :catch_c5
    move-exception p0

    const-string v0, "Storing index file failed"

    invoke-static {v3, v0, p0}, La0/p;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_e4

    :goto_cc
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "Failed to initialize cache indices: "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1, v0}, La0/p;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v2, Ld0/a$a;

    invoke-direct {v2, v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    iput-object v2, p0, Ld0/r;->j:Ld0/a$a;

    :goto_e4
    return-void
.end method

.method static synthetic j(Ld0/r;)Ld0/d;
    .registers 1

    iget-object p0, p0, Ld0/r;->b:Ld0/d;

    return-object p0
.end method

.method private k(Ld0/s;)V
    .registers 5

    iget-object v0, p0, Ld0/r;->c:Ld0/j;

    iget-object v1, p1, Ld0/h;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ld0/j;->g(Ljava/lang/String;)Ld0/i;

    move-result-object v0

    invoke-virtual {v0, p1}, Ld0/i;->a(Ld0/s;)V

    iget-object v0, p0, Ld0/r;->e:Ljava/util/HashMap;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    if-eqz v0, :cond_29

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_1b
    if-ltz v1, :cond_29

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/a$b;

    invoke-interface {v2, p0, p1}, Ld0/a$b;->e(Ld0/a;Ld0/h;)V

    add-int/lit8 v1, v1, -0x1

    goto :goto_1b

    :cond_29
    iget-object v0, p0, Ld0/r;->b:Ld0/d;

    invoke-interface {v0, p0, p1}, Ld0/a$b;->e(Ld0/a;Ld0/h;)V

    return-void
.end method

.method private static m(Ljava/io/File;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation

    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-nez v0, :cond_26

    invoke-virtual {p0}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_26

    :cond_d
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Failed to create cache directory: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "SimpleCache"

    invoke-static {v0, p0}, La0/p;->c(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Ld0/a$a;

    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_26
    :goto_26
    return-void
.end method

.method private static n(Ljava/io/File;)J
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    invoke-virtual {v0}, Ljava/util/Random;->nextLong()J

    move-result-wide v0

    const-wide/high16 v2, -0x8000000000000000L

    cmp-long v4, v0, v2

    if-nez v4, :cond_12

    const-wide/16 v0, 0x0

    goto :goto_16

    :cond_12
    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    :goto_16
    const/16 v2, 0x10

    invoke-static {v0, v1, v2}, Ljava/lang/Long;->toString(JI)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/io/File;

    const-string v4, ".uid"

    invoke-static {v2, v4}, Landroid/support/v4/media/session/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, p0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->createNewFile()Z

    move-result p0

    if-eqz p0, :cond_2e

    return-wide v0

    :cond_2e
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Failed to create UID file: "

    invoke-static {v0, v3}, Landroidx/core/content/e;->a(Ljava/lang/String;Ljava/io/File;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private o(Ljava/io/File;Z[Ljava/io/File;Ljava/util/HashMap;)V
    .registers 14

    if-eqz p3, :cond_65

    array-length v0, p3

    if-nez v0, :cond_6

    goto :goto_65

    :cond_6
    array-length p1, p3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_9
    if-ge v1, p1, :cond_64

    aget-object v8, p3, v1

    invoke-virtual {v8}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    if-eqz p2, :cond_24

    const/16 v3, 0x2e

    invoke-virtual {v2, v3}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_24

    invoke-virtual {v8}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v2

    invoke-direct {p0, v8, v0, v2, p4}, Ld0/r;->o(Ljava/io/File;Z[Ljava/io/File;Ljava/util/HashMap;)V

    goto :goto_61

    :cond_24
    if-eqz p2, :cond_37

    const-string v3, "cached_content_index.exi"

    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_61

    const-string v3, ".uid"

    invoke-virtual {v2, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_37

    goto :goto_61

    :cond_37
    if-eqz p4, :cond_40

    invoke-virtual {p4, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/e;

    goto :goto_41

    :cond_40
    const/4 v2, 0x0

    :goto_41
    if-eqz v2, :cond_48

    iget-wide v3, v2, Ld0/e;->a:J

    iget-wide v5, v2, Ld0/e;->b:J

    goto :goto_51

    :cond_48
    const-wide/16 v2, -0x1

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    move-wide v5, v4

    move-wide v3, v2

    :goto_51
    iget-object v7, p0, Ld0/r;->c:Ld0/j;

    move-object v2, v8

    invoke-static/range {v2 .. v7}, Ld0/s;->b(Ljava/io/File;JJLd0/j;)Ld0/s;

    move-result-object v2

    if-eqz v2, :cond_5e

    invoke-direct {p0, v2}, Ld0/r;->k(Ld0/s;)V

    goto :goto_61

    :cond_5e
    invoke-virtual {v8}, Ljava/io/File;->delete()Z

    :cond_61
    :goto_61
    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_64
    return-void

    :cond_65
    :goto_65
    if-nez p2, :cond_6a

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    :cond_6a
    return-void
.end method

.method private p(Ld0/h;)V
    .registers 7

    iget-object v0, p1, Ld0/h;->a:Ljava/lang/String;

    iget-object v1, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v1, v0}, Ld0/j;->d(Ljava/lang/String;)Ld0/i;

    move-result-object v0

    if-eqz v0, :cond_53

    invoke-virtual {v0, p1}, Ld0/i;->j(Ld0/h;)Z

    move-result v2

    if-nez v2, :cond_11

    goto :goto_53

    :cond_11
    iget-object v2, p0, Ld0/r;->d:Ld0/f;

    if-eqz v2, :cond_29

    iget-object v3, p1, Ld0/h;->e:Ljava/io/File;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    :try_start_1e
    invoke-virtual {v2, v3}, Ld0/f;->c(Ljava/lang/String;)V
    :try_end_21
    .catch Ljava/io/IOException; {:try_start_1e .. :try_end_21} :catch_22

    goto :goto_29

    :catch_22
    const-string v2, "Failed to remove file index entry for: "

    const-string v4, "SimpleCache"

    invoke-static {v2, v3, v4}, Landroidx/core/content/b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_29
    :goto_29
    iget-object v0, v0, Ld0/i;->b:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ld0/j;->i(Ljava/lang/String;)V

    iget-object v0, p0, Ld0/r;->e:Ljava/util/HashMap;

    iget-object v1, p1, Ld0/h;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    if-eqz v0, :cond_4e

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_40
    if-ltz v1, :cond_4e

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/a$b;

    invoke-interface {v2, p1}, Ld0/a$b;->b(Ld0/h;)V

    add-int/lit8 v1, v1, -0x1

    goto :goto_40

    :cond_4e
    iget-object v0, p0, Ld0/r;->b:Ld0/d;

    invoke-interface {v0, p1}, Ld0/a$b;->b(Ld0/h;)V

    :cond_53
    :goto_53
    return-void
.end method

.method private q()V
    .registers 10

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v1}, Ld0/j;->e()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_42

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/i;

    invoke-virtual {v2}, Ld0/i;->e()Ljava/util/TreeSet;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_23
    :goto_23
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld0/h;

    iget-object v4, v3, Ld0/h;->e:Ljava/io/File;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Ljava/io/File;->length()J

    move-result-wide v4

    iget-wide v6, v3, Ld0/h;->c:J

    cmp-long v8, v4, v6

    if-eqz v8, :cond_23

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_23

    :cond_42
    const/4 v1, 0x0

    :goto_43
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_55

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld0/h;

    invoke-direct {p0, v2}, Ld0/r;->p(Ld0/h;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_43

    :cond_55
    return-void
.end method

.method private r(Ljava/lang/String;Ld0/s;)Ld0/s;
    .registers 12

    iget-boolean v0, p0, Ld0/r;->g:Z

    if-nez v0, :cond_5

    return-object p2

    :cond_5
    iget-object v0, p2, Ld0/h;->e:Ljava/io/File;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v6

    iget-wide v2, p2, Ld0/h;->c:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const/4 v0, 0x1

    iget-object v1, p0, Ld0/r;->d:Ld0/f;

    if-eqz v1, :cond_27

    move-wide v4, v7

    :try_start_1a
    invoke-virtual/range {v1 .. v6}, Ld0/f;->e(JJLjava/lang/String;)V
    :try_end_1d
    .catch Ljava/io/IOException; {:try_start_1a .. :try_end_1d} :catch_1e

    goto :goto_25

    :catch_1e
    const-string v1, "SimpleCache"

    const-string v2, "Failed to update index with new touch timestamp."

    invoke-static {v1, v2}, La0/p;->g(Ljava/lang/String;Ljava/lang/String;)V

    :goto_25
    const/4 v1, 0x0

    goto :goto_28

    :cond_27
    const/4 v1, 0x1

    :goto_28
    iget-object v2, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v2, p1}, Ld0/j;->d(Ljava/lang/String;)Ld0/i;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, p2, v7, v8, v1}, Ld0/i;->k(Ld0/s;JZ)Ld0/s;

    move-result-object p1

    iget-object v1, p0, Ld0/r;->e:Ljava/util/HashMap;

    iget-object v2, p2, Ld0/h;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    if-eqz v1, :cond_54

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v0

    :goto_46
    if-ltz v2, :cond_54

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld0/a$b;

    invoke-interface {v0, p0, p2, p1}, Ld0/a$b;->d(Ld0/a;Ld0/h;Ld0/h;)V

    add-int/lit8 v2, v2, -0x1

    goto :goto_46

    :cond_54
    iget-object v0, p0, Ld0/r;->b:Ld0/d;

    invoke-interface {v0, p0, p2, p1}, Ld0/a$b;->d(Ld0/a;Ld0/h;Ld0/h;)V

    return-object p1
.end method

.method private static declared-synchronized s(Ljava/io/File;)V
    .registers 3

    const-class v0, Ld0/r;

    monitor-enter v0

    :try_start_3
    sget-object v1, Ld0/r;->k:Ljava/util/HashSet;

    invoke-virtual {p0}, Ljava/io/File;->getAbsoluteFile()Ljava/io/File;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z
    :try_end_c
    .catchall {:try_start_3 .. :try_end_c} :catchall_e

    monitor-exit v0

    return-void

    :catchall_e
    move-exception p0

    monitor-exit v0

    throw p0
.end method


# virtual methods
.method public final declared-synchronized a(Ljava/lang/String;)Ld0/l;
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    iget-object v0, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v0, p1}, Ld0/j;->d(Ljava/lang/String;)Ld0/i;

    move-result-object p1

    if-eqz p1, :cond_15

    invoke-virtual {p1}, Ld0/i;->c()Ld0/l;

    move-result-object p1

    goto :goto_17

    :cond_15
    sget-object p1, Ld0/l;->c:Ld0/l;
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_19

    :goto_17
    monitor-exit p0

    return-object p1

    :catchall_19
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized b(Ld0/h;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    invoke-direct {p0, p1}, Ld0/r;->p(Ld0/h;)V
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_d

    monitor-exit p0

    return-void

    :catchall_d
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized c(Ld0/h;)V
    .registers 5

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    iget-object v0, p0, Ld0/r;->c:Ld0/j;

    iget-object v1, p1, Ld0/h;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ld0/j;->d(Ljava/lang/String;)Ld0/i;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v1, p1, Ld0/h;->b:J

    invoke-virtual {v0, v1, v2}, Ld0/i;->l(J)V

    iget-object p1, p0, Ld0/r;->c:Ld0/j;

    iget-object v0, v0, Ld0/i;->b:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ld0/j;->i(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_22
    .catchall {:try_start_1 .. :try_end_22} :catchall_24

    monitor-exit p0

    return-void

    :catchall_24
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized d(JJLjava/lang/String;)Ld0/h;
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;,
            Ld0/a$a;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    invoke-virtual {p0}, Ld0/r;->l()V

    :goto_b
    invoke-virtual/range {p0 .. p5}, Ld0/r;->e(JJLjava/lang/String;)Ld0/h;

    move-result-object v0
    :try_end_f
    .catchall {:try_start_1 .. :try_end_f} :catchall_17

    if-eqz v0, :cond_13

    monitor-exit p0

    return-object v0

    :cond_13
    :try_start_13
    invoke-virtual {p0}, Ljava/lang/Object;->wait()V
    :try_end_16
    .catchall {:try_start_13 .. :try_end_16} :catchall_17

    goto :goto_b

    :catchall_17
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized e(JJLjava/lang/String;)Ld0/h;
    .registers 16
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    invoke-virtual {p0}, Ld0/r;->l()V

    iget-object v0, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v0, p5}, Ld0/j;->d(Ljava/lang/String;)Ld0/i;

    move-result-object v0

    if-nez v0, :cond_23

    new-instance v0, Ld0/s;

    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v9, 0x0

    move-object v1, v0

    move-object v2, p5

    move-wide v3, p1

    move-wide v5, p3

    invoke-direct/range {v1 .. v9}, Ld0/h;-><init>(Ljava/lang/String;JJJLjava/io/File;)V

    goto :goto_3f

    :cond_23
    :goto_23
    invoke-virtual {v0, p1, p2, p3, p4}, Ld0/i;->d(JJ)Ld0/s;

    move-result-object v1

    iget-boolean v2, v1, Ld0/h;->d:Z

    if-eqz v2, :cond_3e

    iget-object v2, v1, Ld0/h;->e:Ljava/io/File;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/io/File;->length()J

    move-result-wide v2

    iget-wide v4, v1, Ld0/h;->c:J

    cmp-long v6, v2, v4

    if-eqz v6, :cond_3e

    invoke-direct {p0}, Ld0/r;->q()V

    goto :goto_23

    :cond_3e
    move-object v0, v1

    :goto_3f
    iget-boolean p3, v0, Ld0/h;->d:Z

    if-eqz p3, :cond_4b

    invoke-direct {p0, p5, v0}, Ld0/r;->r(Ljava/lang/String;Ld0/s;)Ld0/s;

    move-result-object p1
    :try_end_47
    .catchall {:try_start_1 .. :try_end_47} :catchall_49

    monitor-exit p0

    return-object p1

    :catchall_49
    move-exception p1

    goto :goto_5e

    :cond_4b
    :try_start_4b
    iget-object p3, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {p3, p5}, Ld0/j;->g(Ljava/lang/String;)Ld0/i;

    move-result-object p3

    iget-wide p4, v0, Ld0/h;->c:J

    invoke-virtual {p3, p1, p2, p4, p5}, Ld0/i;->i(JJ)Z

    move-result p1
    :try_end_57
    .catchall {:try_start_4b .. :try_end_57} :catchall_49

    if-eqz p1, :cond_5b

    monitor-exit p0

    return-object v0

    :cond_5b
    monitor-exit p0

    const/4 p1, 0x0

    return-object p1

    :goto_5e
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized f(Ljava/lang/String;Ld0/k;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    invoke-virtual {p0}, Ld0/r;->l()V

    iget-object v0, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v0, p1, p2}, Ld0/j;->c(Ljava/lang/String;Ld0/k;)V
    :try_end_10
    .catchall {:try_start_1 .. :try_end_10} :catchall_17

    :try_start_10
    iget-object p1, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {p1}, Ld0/j;->k()V
    :try_end_15
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_15} :catch_19
    .catchall {:try_start_10 .. :try_end_15} :catchall_17

    monitor-exit p0

    return-void

    :catchall_17
    move-exception p1

    goto :goto_20

    :catch_19
    move-exception p1

    :try_start_1a
    new-instance p2, Ld0/a$a;

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p2
    :try_end_20
    .catchall {:try_start_1a .. :try_end_20} :catchall_17

    :goto_20
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized g(JJLjava/lang/String;)Ljava/io/File;
    .registers 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    invoke-virtual {p0}, Ld0/r;->l()V

    iget-object v0, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v0, p5}, Ld0/j;->d(Ljava/lang/String;)Ld0/i;

    move-result-object p5

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5, p1, p2, p3, p4}, Ld0/i;->g(JJ)Z

    move-result v0

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    iget-object v0, p0, Ld0/r;->a:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_2e

    iget-object v0, p0, Ld0/r;->a:Ljava/io/File;

    invoke-static {v0}, Ld0/r;->m(Ljava/io/File;)V

    invoke-direct {p0}, Ld0/r;->q()V

    goto :goto_2e

    :catchall_2c
    move-exception p1

    goto :goto_5c

    :cond_2e
    :goto_2e
    iget-object v0, p0, Ld0/r;->b:Ld0/d;

    invoke-interface {v0, p0, p3, p4}, Ld0/d;->c(Ld0/a;J)V

    new-instance v1, Ljava/io/File;

    iget-object p3, p0, Ld0/r;->a:Ljava/io/File;

    iget-object p4, p0, Ld0/r;->f:Ljava/util/Random;

    const/16 v0, 0xa

    invoke-virtual {p4, v0}, Ljava/util/Random;->nextInt(I)I

    move-result p4

    invoke-static {p4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p4

    invoke-direct {v1, p3, p4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p3

    if-nez p3, :cond_4f

    invoke-static {v1}, Ld0/r;->m(Ljava/io/File;)V

    :cond_4f
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    iget v2, p5, Ld0/i;->a:I

    move-wide v3, p1

    invoke-static/range {v1 .. v6}, Ld0/s;->c(Ljava/io/File;IJJ)Ljava/io/File;

    move-result-object p1
    :try_end_5a
    .catchall {:try_start_1 .. :try_end_5a} :catchall_2c

    monitor-exit p0

    return-object p1

    :goto_5c
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized h(Ljava/io/File;J)V
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0
    :try_end_c
    .catchall {:try_start_1 .. :try_end_c} :catchall_1b

    if-nez v0, :cond_10

    monitor-exit p0

    return-void

    :cond_10
    const-wide/16 v2, 0x0

    cmp-long v0, p2, v2

    if-nez v0, :cond_1d

    :try_start_16
    invoke-virtual {p1}, Ljava/io/File;->delete()Z
    :try_end_19
    .catchall {:try_start_16 .. :try_end_19} :catchall_1b

    monitor-exit p0

    return-void

    :catchall_1b
    move-exception p1

    goto :goto_8c

    :cond_1d
    :try_start_1d
    iget-object v7, p0, Ld0/r;->c:Ld0/j;

    const-wide v5, -0x7fffffffffffffffL    # -4.9E-324

    move-object v2, p1

    move-wide v3, p2

    invoke-static/range {v2 .. v7}, Ld0/s;->b(Ljava/io/File;JJLd0/j;)Ld0/s;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p3, p0, Ld0/r;->c:Ld0/j;

    iget-object v0, p2, Ld0/h;->a:Ljava/lang/String;

    invoke-virtual {p3, v0}, Ld0/j;->d(Ljava/lang/String;)Ld0/i;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v2, p2, Ld0/h;->b:J

    iget-wide v4, p2, Ld0/h;->c:J

    invoke-virtual {p3, v2, v3, v4, v5}, Ld0/i;->g(JJ)Z

    move-result v0

    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    invoke-virtual {p3}, Ld0/i;->c()Ld0/l;

    move-result-object p3

    invoke-virtual {p3}, Ld0/l;->c()J

    move-result-wide v2

    const-wide/16 v4, -0x1

    cmp-long p3, v2, v4

    if-eqz p3, :cond_5f

    iget-wide v4, p2, Ld0/h;->b:J

    iget-wide v6, p2, Ld0/h;->c:J

    add-long/2addr v4, v6

    cmp-long p3, v4, v2

    if-gtz p3, :cond_5b

    goto :goto_5c

    :cond_5b
    const/4 v1, 0x0

    :goto_5c
    invoke-static {v1}, Lcom/facebook/soloader/m;->e(Z)V

    :cond_5f
    iget-object p3, p0, Ld0/r;->d:Ld0/f;

    if-eqz p3, :cond_78

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v5
    :try_end_67
    .catchall {:try_start_1d .. :try_end_67} :catchall_1b

    :try_start_67
    iget-object v0, p0, Ld0/r;->d:Ld0/f;

    iget-wide v1, p2, Ld0/h;->c:J

    iget-wide v3, p2, Ld0/h;->f:J

    invoke-virtual/range {v0 .. v5}, Ld0/f;->e(JJLjava/lang/String;)V
    :try_end_70
    .catch Ljava/io/IOException; {:try_start_67 .. :try_end_70} :catch_71
    .catchall {:try_start_67 .. :try_end_70} :catchall_1b

    goto :goto_78

    :catch_71
    move-exception p1

    :try_start_72
    new-instance p2, Ld0/a$a;

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_78
    :goto_78
    invoke-direct {p0, p2}, Ld0/r;->k(Ld0/s;)V
    :try_end_7b
    .catchall {:try_start_72 .. :try_end_7b} :catchall_1b

    :try_start_7b
    iget-object p1, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {p1}, Ld0/j;->k()V
    :try_end_80
    .catch Ljava/io/IOException; {:try_start_7b .. :try_end_80} :catch_85
    .catchall {:try_start_7b .. :try_end_80} :catchall_1b

    :try_start_80
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_83
    .catchall {:try_start_80 .. :try_end_83} :catchall_1b

    monitor-exit p0

    return-void

    :catch_85
    move-exception p1

    :try_start_86
    new-instance p2, Ld0/a$a;

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p2
    :try_end_8c
    .catchall {:try_start_86 .. :try_end_8c} :catchall_1b

    :goto_8c
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized l()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ld0/a$a;
        }
    .end annotation

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Ld0/r;->j:Ld0/a$a;
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_8

    if-nez v0, :cond_7

    monitor-exit p0

    return-void

    :cond_7
    :try_start_7
    throw v0
    :try_end_8
    .catchall {:try_start_7 .. :try_end_8} :catchall_8

    :catchall_8
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized release()V
    .registers 5

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Ld0/r;->i:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_1d

    if-eqz v0, :cond_7

    monitor-exit p0

    return-void

    :cond_7
    :try_start_7
    iget-object v0, p0, Ld0/r;->e:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    invoke-direct {p0}, Ld0/r;->q()V
    :try_end_f
    .catchall {:try_start_7 .. :try_end_f} :catchall_1d

    const/4 v0, 0x1

    :try_start_10
    iget-object v1, p0, Ld0/r;->c:Ld0/j;

    invoke-virtual {v1}, Ld0/j;->k()V
    :try_end_15
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_15} :catch_21
    .catchall {:try_start_10 .. :try_end_15} :catchall_1f

    :try_start_15
    iget-object v1, p0, Ld0/r;->a:Ljava/io/File;

    invoke-static {v1}, Ld0/r;->s(Ljava/io/File;)V

    :goto_1a
    iput-boolean v0, p0, Ld0/r;->i:Z
    :try_end_1c
    .catchall {:try_start_15 .. :try_end_1c} :catchall_1d

    goto :goto_2f

    :catchall_1d
    move-exception v0

    goto :goto_39

    :catchall_1f
    move-exception v1

    goto :goto_31

    :catch_21
    move-exception v1

    :try_start_22
    const-string v2, "SimpleCache"

    const-string v3, "Storing index file failed"

    invoke-static {v2, v3, v1}, La0/p;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_29
    .catchall {:try_start_22 .. :try_end_29} :catchall_1f

    :try_start_29
    iget-object v1, p0, Ld0/r;->a:Ljava/io/File;

    invoke-static {v1}, Ld0/r;->s(Ljava/io/File;)V
    :try_end_2e
    .catchall {:try_start_29 .. :try_end_2e} :catchall_1d

    goto :goto_1a

    :goto_2f
    monitor-exit p0

    return-void

    :goto_31
    :try_start_31
    iget-object v2, p0, Ld0/r;->a:Ljava/io/File;

    invoke-static {v2}, Ld0/r;->s(Ljava/io/File;)V

    iput-boolean v0, p0, Ld0/r;->i:Z

    throw v1
    :try_end_39
    .catchall {:try_start_31 .. :try_end_39} :catchall_1d

    :goto_39
    monitor-exit p0

    throw v0
.end method
