.class public final La6/b;
.super Landroidx/fragment/app/Fragment;
.source "MultiTabChildFragment.java"

# interfaces
.implements Lcom/newrelic/agent/android/api/v2/TraceFieldInterface;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La6/b$a;
    }
.end annotation


# instance fields
.field protected P:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Q:Lcom/google/android/material/tabs/TabLayout;

.field R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

.field S:La6/c;

.field T:Landroid/view/ViewGroup;

.field private W:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LGe/G;",
            ">;"
        }
    .end annotation
.end field

.field private X:Landroid/view/View;

.field private Y:Ljava/lang/String;

.field private Z:La6/b$a;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La6/b;->P:Ljava/util/ArrayList;

    return-void
.end method

.method public static newInstance(La6/c;Ljava/lang/String;Ljava/util/Map;)Landroidx/fragment/app/Fragment;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La6/c;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LGe/G;",
            ">;)",
            "Landroidx/fragment/app/Fragment;"
        }
    .end annotation

    new-instance v0, La6/b;

    invoke-direct {v0}, La6/b;-><init>()V

    iget-object v1, p0, La6/c;->d:Landroid/os/Bundle;

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    invoke-virtual {v0, p0, p1, p2}, La6/b;->setChildTabData(La6/c;Ljava/lang/String;Ljava/util/Map;)V

    return-object v0
.end method


# virtual methods
.method public dispatchActionToReact(Lcom/flipkart/android/redux/state/m;)V
    .registers 5

    iget-object v0, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getAdapter()Landroidx/viewpager/widget/a;

    move-result-object v0

    instance-of v1, v0, La6/a;

    if-eqz v1, :cond_25

    iget-object v1, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v1}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    move-result v1

    check-cast v0, La6/a;

    iget-object v2, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    move-result v2

    invoke-virtual {v0, v2, v1}, La6/a;->getFragmentAtPosition(II)Landroidx/fragment/app/Fragment;

    move-result-object v0

    instance-of v1, v0, Lcom/flipkart/android/reactmultiwidget/fragments/ReactViewModelFragment;

    if-eqz v1, :cond_25

    check-cast v0, Lcom/flipkart/android/reactmultiwidget/fragments/ReactViewModelFragment;

    invoke-virtual {v0, p1}, Lcom/flipkart/android/reactnative/nativeuimodules/multiwidget/ReactMultiWidgetFragment;->emitAction(Lcom/flipkart/android/redux/state/m;)V

    :cond_25
    return-void
.end method

.method public getDefaultViewModelCreationExtras()LW/a;
    .registers 2

    sget-object v0, LW/a$a;->b:LW/a$a;

    return-object v0
.end method

.method public onAttach(Landroid/content/Context;)V
    .registers 3

    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onAttach(Landroid/content/Context;)V

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object p1

    instance-of v0, p1, La6/b$a;

    if-eqz v0, :cond_f

    check-cast p1, La6/b$a;

    iput-object p1, p0, La6/b;->Z:La6/b$a;

    :cond_f
    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 6

    const-string p3, "MultiTabChildFragment#onCreateView"

    const/4 v0, 0x0

    :try_start_3
    invoke-static {v0, p3, v0}, Lcom/newrelic/agent/android/tracing/TraceMachine;->enterMethod(Lcom/newrelic/agent/android/tracing/Trace;Ljava/lang/String;Ljava/util/ArrayList;)V

    goto :goto_a

    :catch_7
    invoke-static {v0, p3, v0}, Lcom/newrelic/agent/android/tracing/TraceMachine;->enterMethod(Lcom/newrelic/agent/android/tracing/Trace;Ljava/lang/String;Ljava/util/ArrayList;)V
    :try_end_a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_a} :catch_7

    :goto_a
    const p3, 0x7f0e0086

    const/4 v1, 0x0

    invoke-virtual {p1, p3, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f0b0193

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    iput-object p2, p0, La6/b;->X:Landroid/view/View;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object p2

    const p3, 0x7f0b007a

    invoke-virtual {p2, p3}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/view/ViewGroup;

    iput-object p2, p0, La6/b;->T:Landroid/view/ViewGroup;

    const/4 p3, 0x0

    if-eqz p2, :cond_30

    invoke-virtual {p2, p3}, Landroid/view/View;->setElevation(F)V

    :cond_30
    const p2, 0x7f0b019a

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/google/android/material/tabs/TabLayout;

    iput-object p2, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    if-eqz p2, :cond_40

    invoke-virtual {p2, p3}, Landroid/view/View;->setElevation(F)V

    :cond_40
    const p2, 0x7f0b0199

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    iput-object p2, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    iget-object p3, p0, La6/b;->W:Ljava/util/Map;

    if-eqz p3, :cond_58

    const-string v0, "L2"

    invoke-interface {p3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    move-object v0, p3

    check-cast v0, LGe/G;

    :cond_58
    if-eqz v0, :cond_63

    iget-object p3, v0, LGe/G;->i:Ljava/lang/Boolean;

    if-eqz p3, :cond_63

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    goto :goto_64

    :cond_63
    const/4 p3, 0x0

    :goto_64
    invoke-virtual {p2, p3}, Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;->setPagingEnabled(Z)V

    iget-object p2, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {p2, v1}, Landroidx/viewpager/widget/ViewPager;->setOffscreenPageLimit(I)V

    iget-object p2, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    invoke-virtual {p2, v1}, Lcom/google/android/material/tabs/TabLayout;->u(I)V

    iget-object p2, p0, La6/b;->Z:La6/b$a;

    if-eqz p2, :cond_7e

    iget-object p3, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    invoke-interface {p2}, La6/b$a;->getOnSelectionChangedListener()Lcom/google/android/material/tabs/TabLayout$c;

    move-result-object p2

    invoke-virtual {p3, p2}, Lcom/google/android/material/tabs/TabLayout;->b(Lcom/google/android/material/tabs/TabLayout$c;)V

    :cond_7e
    invoke-static {}, Lcom/newrelic/agent/android/tracing/TraceMachine;->exitMethod()V

    return-object p1
.end method

.method public onDetach()V
    .registers 2

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDetach()V

    const/4 v0, 0x0

    iput-object v0, p0, La6/b;->Z:La6/b$a;

    return-void
.end method

.method public onTabSelected(Ljava/lang/String;)V
    .registers 5

    iget-object v0, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getAdapter()Landroidx/viewpager/widget/a;

    move-result-object v0

    instance-of v1, v0, La6/a;

    if-eqz v1, :cond_28

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_28

    iget-object v1, p0, La6/b;->P:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_28

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p1

    check-cast v0, La6/a;

    iget-object v1, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, La6/a;->onTabSelected(IILjava/lang/String;)V

    :cond_28
    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .registers 3

    invoke-super {p0, p1, p2}, Landroidx/fragment/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->isVisible()Z

    move-result p1

    if-eqz p1, :cond_c

    invoke-virtual {p0}, La6/b;->updateChildFragment()V

    :cond_c
    return-void
.end method

.method public setChildTabData(La6/c;Ljava/lang/String;Ljava/util/Map;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La6/c;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LGe/G;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La6/b;->S:La6/c;

    iput-object p3, p0, La6/b;->W:Ljava/util/Map;

    iput-object p2, p0, La6/b;->Y:Ljava/lang/String;

    invoke-virtual {p0}, La6/b;->updateChildFragment()V

    return-void
.end method

.method public setUserVisibleHint(Z)V
    .registers 2

    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->setUserVisibleHint(Z)V

    if-eqz p1, :cond_8

    invoke-virtual {p0}, La6/b;->updateChildFragment()V

    :cond_8
    return-void
.end method

.method public updateChildFragment()V
    .registers 13

    iget-object v0, p0, La6/b;->P:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, La6/b;->S:La6/c;

    if-eqz v1, :cond_35

    iget-object v1, v1, La6/c;->e:Ljava/util/List;

    if-eqz v1, :cond_13

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_35

    :cond_13
    iget-object v1, p0, La6/b;->S:La6/c;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v1, La6/c;->e:Ljava/util/List;

    iget-object v1, p0, La6/b;->S:La6/c;

    iget-object v2, v1, La6/c;->e:Ljava/util/List;

    new-instance v11, La6/c;

    iget-object v5, v1, La6/c;->g:LMe/H0;

    iget-object v6, v1, La6/c;->h:LGe/b;

    const/4 v10, 0x0

    const/4 v8, 0x0

    iget-object v4, v1, La6/c;->a:Ljava/lang/String;

    iget-object v7, v1, La6/c;->d:Landroid/os/Bundle;

    const-string v9, "L2"

    move-object v3, v11

    invoke-direct/range {v3 .. v10}, La6/c;-><init>(Ljava/lang/String;LMe/H0;LGe/b;Landroid/os/Bundle;Ljava/util/List;Ljava/lang/String;Z)V

    invoke-interface {v2, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_35
    iget-object v1, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    const/16 v2, 0x8

    if-eqz v1, :cond_11a

    iget-object v1, p0, La6/b;->S:La6/c;

    if-eqz v1, :cond_11a

    iget-object v1, v1, La6/c;->e:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_11a

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/o;

    move-result-object v1

    if-eqz v1, :cond_11a

    new-instance v7, Ljava/util/HashMap;

    iget-object v1, p0, La6/b;->S:La6/c;

    iget-object v1, v1, La6/c;->e:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v7, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v1, 0x0

    const/4 v3, 0x0

    :goto_5c
    iget-object v4, p0, La6/b;->S:La6/c;

    iget-object v4, v4, La6/c;->e:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_81

    iget-object v4, p0, La6/b;->S:La6/c;

    iget-object v4, v4, La6/c;->e:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La6/c;

    if-eqz v4, :cond_7e

    iget-object v4, v4, La6/c;->a:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v7, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7e
    add-int/lit8 v3, v3, 0x1

    goto :goto_5c

    :cond_81
    iget-object v3, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v3}, Landroidx/viewpager/widget/ViewPager;->getAdapter()Landroidx/viewpager/widget/a;

    move-result-object v3

    instance-of v4, v3, La6/a;

    if-eqz v4, :cond_95

    check-cast v3, La6/a;

    iget-object v4, p0, La6/b;->S:La6/c;

    iget-object v4, v4, La6/c;->e:Ljava/util/List;

    invoke-virtual {v3, v4, v7}, La6/a;->swap(Ljava/util/List;Ljava/util/Map;)V

    goto :goto_b0

    :cond_95
    new-instance v10, La6/a;

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/o;

    move-result-object v5

    iget-object v3, p0, La6/b;->S:La6/c;

    iget-object v6, v3, La6/c;->e:Ljava/util/List;

    const/4 v8, 0x0

    iget-object v9, p0, La6/b;->W:Ljava/util/Map;

    move-object v3, v10

    invoke-direct/range {v3 .. v9}, La6/a;-><init>(Landroid/content/Context;Landroidx/fragment/app/o;Ljava/util/List;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    iget-object v3, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v3, v10}, Landroidx/viewpager/widget/ViewPager;->setAdapter(Landroidx/viewpager/widget/a;)V

    move-object v3, v10

    :goto_b0
    iget-object v4, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    iget-object v5, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v4, v5}, Lcom/google/android/material/tabs/TabLayout;->y(Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;)V

    const/4 v4, 0x0

    :goto_b8
    iget-object v5, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    invoke-virtual {v5}, Lcom/google/android/material/tabs/TabLayout;->k()I

    move-result v5

    if-ge v4, v5, :cond_ce

    iget-object v5, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    invoke-virtual {v5, v4}, Lcom/google/android/material/tabs/TabLayout;->j(I)Lcom/google/android/material/tabs/TabLayout$f;

    move-result-object v5

    if-eqz v5, :cond_cb

    invoke-virtual {v3, v5, v4}, La6/a;->setTabInfo(Lcom/google/android/material/tabs/TabLayout$f;I)V

    :cond_cb
    add-int/lit8 v4, v4, 0x1

    goto :goto_b8

    :cond_ce
    iget-object v3, p0, La6/b;->Y:Ljava/lang/String;

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_e5

    iget-object v3, p0, La6/b;->Y:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e5

    iget-object v3, p0, La6/b;->Y:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v0

    goto :goto_e6

    :cond_e5
    const/4 v0, 0x0

    :goto_e6
    iget-object v3, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {v3, v0}, Landroidx/viewpager/widget/ViewPager;->setCurrentItem(I)V

    iget-object v3, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    invoke-virtual {v3, v0}, Lcom/google/android/material/tabs/TabLayout;->j(I)Lcom/google/android/material/tabs/TabLayout$f;

    move-result-object v0

    if-eqz v0, :cond_fe

    iget-object v3, p0, La6/b;->Z:La6/b$a;

    if-eqz v3, :cond_fe

    invoke-interface {v3}, La6/b$a;->getOnSelectionChangedListener()Lcom/google/android/material/tabs/TabLayout$c;

    move-result-object v3

    invoke-interface {v3, v0}, Lcom/google/android/material/tabs/TabLayout$b;->onTabSelected(Lcom/google/android/material/tabs/TabLayout$f;)V

    :cond_fe
    iget-object v0, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    iget-object v3, p0, La6/b;->S:La6/c;

    iget-boolean v3, v3, La6/c;->i:Z

    if-eqz v3, :cond_108

    const/4 v3, 0x0

    goto :goto_10a

    :cond_108
    const/16 v3, 0x8

    :goto_10a
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, La6/b;->X:Landroid/view/View;

    iget-object v3, p0, La6/b;->S:La6/c;

    iget-boolean v3, v3, La6/c;->i:Z

    if-eqz v3, :cond_116

    const/4 v2, 0x0

    :cond_116
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    goto :goto_12c

    :cond_11a
    iget-object v0, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    if-eqz v0, :cond_12c

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/tabs/TabLayout;->y(Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;)V

    iget-object v0, p0, La6/b;->Q:Lcom/google/android/material/tabs/TabLayout;

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, La6/b;->X:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_12c
    :goto_12c
    return-void
.end method

.method public updateSelectedChildNode(Ljava/lang/String;)V
    .registers 4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_19

    iget-object v0, p0, La6/b;->P:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v0

    iput-object p1, p0, La6/b;->Y:Ljava/lang/String;

    iget-object p1, p0, La6/b;->R:Lcom/flipkart/android/newmultiwidget/ui/widgets/richnavigation/CustomViewPager;

    invoke-virtual {p1, v0}, Landroidx/viewpager/widget/ViewPager;->setCurrentItem(I)V

    :cond_19
    return-void
.end method
