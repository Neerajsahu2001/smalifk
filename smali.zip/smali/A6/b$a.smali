.class public interface abstract La6/b$a;
.super Ljava/lang/Object;
.source "MultiTabChildFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La6/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract getOnSelectionChangedListener()Lcom/google/android/material/tabs/TabLayout$c;
.end method
