.class public final La6/a;
.super Landroidx/fragment/app/s;
.source "CustomPagerAdapter.java"


# instance fields
.field private final g:Landroidx/fragment/app/o;

.field private h:I

.field private i:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private j:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La6/c;",
            ">;"
        }
    .end annotation
.end field

.field private k:Landroid/content/Context;

.field private l:I

.field private m:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LGe/G;",
            ">;"
        }
    .end annotation
.end field

.field private n:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/fragment/app/o;Ljava/util/List;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroidx/fragment/app/o;",
            "Ljava/util/List<",
            "La6/c;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LGe/G;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0, p2}, Landroidx/fragment/app/s;-><init>(Landroidx/fragment/app/o;)V

    const/4 v0, -0x1

    iput v0, p0, La6/a;->h:I

    iput v0, p0, La6/a;->l:I

    iput-object p2, p0, La6/a;->g:Landroidx/fragment/app/o;

    iput-object p1, p0, La6/a;->k:Landroid/content/Context;

    iput-object p3, p0, La6/a;->j:Ljava/util/List;

    iput-object p4, p0, La6/a;->i:Ljava/util/Map;

    iput-object p6, p0, La6/a;->m:Ljava/util/Map;

    iput-object p5, p0, La6/a;->n:Ljava/lang/String;

    return-void
.end method

.method private static b(LGe/b;Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    iget-object v0, p0, LGe/b;->f:Ljava/util/Map;

    const-string v1, "bundleName"

    invoke-interface {v0, v1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, LGe/b;->f:Ljava/util/Map;

    const-string v0, "screenName"

    invoke-interface {p2, v0, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, LGe/b;->f:Ljava/util/Map;

    sget-object p3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const-string v0, "MENU_CONTEXT"

    invoke-interface {p2, v0, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-eqz p1, :cond_2d

    iget-object p2, p0, LGe/b;->f:Ljava/util/Map;

    const-string p3, "tabKey"

    invoke-virtual {p1, p3}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    invoke-interface {p2, p3, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p0, p0, LGe/b;->f:Ljava/util/Map;

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const-string p2, "SHOW_DUMMY_TOOLBAR"

    invoke-interface {p0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2d
    return-void
.end method


# virtual methods
.method public getCount()I
    .registers 2

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getFragmentAtPosition(II)Landroidx/fragment/app/Fragment;
    .registers 6

    invoke-virtual {p0, p2}, La6/a;->getItemId(I)J

    move-result-wide v0

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v2, "android:switcher:"

    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ":"

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, La6/a;->g:Landroidx/fragment/app/o;

    invoke-virtual {p2, p1}, Landroidx/fragment/app/o;->T(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object p1

    return-object p1
.end method

.method public getItem(I)Landroidx/fragment/app/Fragment;
    .registers 8

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p1, v0, :cond_f3

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La6/c;

    iget-object v0, p1, La6/c;->f:Ljava/lang/String;

    const-string v1, "L1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_23

    iget-object v0, p0, La6/a;->n:Ljava/lang/String;

    iget-object v1, p0, La6/a;->m:Ljava/util/Map;

    invoke-static {p1, v0, v1}, La6/b;->newInstance(La6/c;Ljava/lang/String;Ljava/util/Map;)Landroidx/fragment/app/Fragment;

    move-result-object p1

    return-object p1

    :cond_23
    const-string v0, "L2"

    iget-object v1, p1, La6/c;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f3

    iget-object v0, p1, La6/c;->g:LMe/H0;

    if-eqz v0, :cond_ed

    iget-object v0, p1, La6/c;->h:LGe/b;

    if-eqz v0, :cond_ed

    iget-object v1, v0, LGe/b;->a:Ljava/lang/String;

    sget-object v2, Lcom/flipkart/android/urlmanagement/AppAction;->productListView:Lcom/flipkart/android/urlmanagement/AppAction;

    invoke-virtual {v2}, Lcom/flipkart/android/urlmanagement/AppAction;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    iget-object v3, p0, La6/a;->k:Landroid/content/Context;

    iget-object p1, p1, La6/c;->d:Landroid/os/Bundle;

    const-string v4, "bundleName"

    const-string v5, "screenName"

    if-eqz v2, :cond_7b

    const-string v1, "cross"

    const-string v2, "productList"

    invoke-static {v0, p1, v1, v2}, La6/a;->b(LGe/b;Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, v0, LGe/b;->f:Ljava/util/Map;

    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iget-object v1, v0, LGe/b;->f:Ljava/util/Map;

    invoke-interface {v1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_74

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_74

    invoke-static {v3, p1, v1, v0}, Lcom/flipkart/android/reactnative/nativeuimodules/d;->newInstance(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;LGe/b;)Lcom/flipkart/android/reactnative/nativeuimodules/d;

    move-result-object p1

    goto/16 :goto_f2

    :cond_74
    new-instance p1, Landroidx/fragment/app/Fragment;

    invoke-direct {p1}, Landroidx/fragment/app/Fragment;-><init>()V

    goto/16 :goto_f2

    :cond_7b
    sget-object v2, Lcom/flipkart/android/urlmanagement/AppAction;->multiWidgetPage:Lcom/flipkart/android/urlmanagement/AppAction;

    invoke-virtual {v2}, Lcom/flipkart/android/urlmanagement/AppAction;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_ed

    iget-object v1, v0, LGe/b;->f:Ljava/util/Map;

    invoke-static {v1, v5}, Lcom/flipkart/android/utils/d1;->fetchString(Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    check-cast v2, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {v2}, Lcom/flipkart/android/init/FlipkartApplication;->getPageRouter()Lq4/i;

    move-result-object v2

    if-eqz v2, :cond_ed

    invoke-virtual {v2, v1}, Lq4/i;->getPageScreenType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "multi_widget_react"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b2

    new-instance v0, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;

    invoke-direct {v0}, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;-><init>()V

    invoke-virtual {v0, p1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    move-object p1, v0

    goto :goto_f2

    :cond_b2
    iget-object v1, v0, LGe/b;->f:Ljava/util/Map;

    invoke-interface {v1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "multiWidget"

    invoke-static {v0, p1, v2, v1}, La6/a;->b(LGe/b;Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, v0, LGe/b;->f:Ljava/util/Map;

    const-string v5, "projectName"

    invoke-interface {p1, v5, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, v0, LGe/b;->f:Ljava/util/Map;

    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iget-object v2, v0, LGe/b;->f:Ljava/util/Map;

    invoke-interface {v2, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_e7

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_e7

    invoke-static {v3, p1, v1, v2, v0}, Lcom/flipkart/android/reactnative/nativeuimodules/multiwidget/e;->newInstance(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LGe/b;)Lcom/flipkart/android/reactnative/nativeuimodules/multiwidget/ReactMultiWidgetFragment;

    move-result-object p1

    goto :goto_f2

    :cond_e7
    new-instance p1, Landroidx/fragment/app/Fragment;

    invoke-direct {p1}, Landroidx/fragment/app/Fragment;-><init>()V

    goto :goto_f2

    :cond_ed
    new-instance p1, Landroidx/fragment/app/Fragment;

    invoke-direct {p1}, Landroidx/fragment/app/Fragment;-><init>()V

    :goto_f2
    return-object p1

    :cond_f3
    new-instance p1, Landroidx/fragment/app/Fragment;

    invoke-direct {p1}, Landroidx/fragment/app/Fragment;-><init>()V

    return-object p1
.end method

.method public getItemId(I)J
    .registers 4

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La6/c;

    iget-object p1, p1, La6/c;->a:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p1

    shl-int/lit8 v0, p1, 0xf

    xor-int/lit16 v0, v0, -0x3283

    add-int/2addr p1, v0

    ushr-int/lit8 v0, p1, 0xa

    xor-int/2addr p1, v0

    shl-int/lit8 v0, p1, 0x3

    add-int/2addr p1, v0

    ushr-int/lit8 v0, p1, 0x6

    xor-int/2addr p1, v0

    shl-int/lit8 v0, p1, 0x2

    shl-int/lit8 v1, p1, 0xe

    add-int/2addr v0, v1

    add-int/2addr v0, p1

    ushr-int/lit8 p1, v0, 0x10

    xor-int/2addr p1, v0

    int-to-long v0, p1

    return-wide v0
.end method

.method public getItemPosition(Ljava/lang/Object;)I
    .registers 4

    instance-of v0, p1, Landroidx/fragment/app/Fragment;

    if-eqz v0, :cond_1d

    check-cast p1, Landroidx/fragment/app/Fragment;

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_1d

    const-string v0, "tabKey"

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, La6/a;->i:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    goto :goto_1e

    :cond_1d
    const/4 p1, 0x0

    :goto_1e
    if-nez p1, :cond_22

    const/4 p1, -0x2

    goto :goto_26

    :cond_22
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    :goto_26
    return p1
.end method

.method public getPageTitle(I)Ljava/lang/CharSequence;
    .registers 2

    invoke-virtual {p0, p1}, La6/a;->getTabInfo(I)La6/c;

    move-result-object p1

    if-eqz p1, :cond_9

    iget-object p1, p1, La6/c;->b:Ljava/lang/String;

    goto :goto_b

    :cond_9
    const-string p1, ""

    :goto_b
    return-object p1
.end method

.method public getTabInfo(I)La6/c;
    .registers 3

    if-ltz p1, :cond_13

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-le v0, p1, :cond_13

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La6/c;

    goto :goto_14

    :cond_13
    const/4 p1, 0x0

    :goto_14
    return-object p1
.end method

.method public onTabSelected(IILjava/lang/String;)V
    .registers 5

    const/4 v0, -0x1

    iput v0, p0, La6/a;->h:I

    invoke-virtual {p0, p1, p2}, La6/a;->getFragmentAtPosition(II)Landroidx/fragment/app/Fragment;

    move-result-object p1

    instance-of v0, p1, La6/b;

    if-eqz v0, :cond_11

    check-cast p1, La6/b;

    invoke-virtual {p1, p3}, La6/b;->onTabSelected(Ljava/lang/String;)V

    goto :goto_29

    :cond_11
    instance-of p3, p1, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;

    if-eqz p3, :cond_1d

    check-cast p1, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;

    iget-object p2, p0, La6/a;->k:Landroid/content/Context;

    invoke-virtual {p1, p2}, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;->onTabSelected(Landroid/content/Context;)V

    goto :goto_29

    :cond_1d
    instance-of p3, p1, Lcom/flipkart/android/reactnative/nativeuimodules/d;

    if-eqz p3, :cond_27

    check-cast p1, Lcom/flipkart/android/reactnative/nativeuimodules/d;

    invoke-virtual {p1}, Lcom/flipkart/android/reactnative/nativeuimodules/d;->onTabSelected()V

    goto :goto_29

    :cond_27
    iput p2, p0, La6/a;->h:I

    :goto_29
    return-void
.end method

.method public setPrimaryItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V
    .registers 8

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p2, v0, :cond_51

    iget v0, p0, La6/a;->l:I

    if-eq v0, p2, :cond_51

    iput p2, p0, La6/a;->l:I

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La6/c;

    iget-object v1, v0, La6/c;->f:Ljava/lang/String;

    const-string v2, "L1"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2f

    instance-of v1, p3, La6/b;

    if-eqz v1, :cond_2f

    move-object v1, p3

    check-cast v1, La6/b;

    iget-object v2, p0, La6/a;->n:Ljava/lang/String;

    iget-object v3, p0, La6/a;->m:Ljava/util/Map;

    invoke-virtual {v1, v0, v2, v3}, La6/b;->setChildTabData(La6/c;Ljava/lang/String;Ljava/util/Map;)V

    goto :goto_51

    :cond_2f
    const-string v1, "L2"

    iget-object v0, v0, La6/c;->f:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_51

    instance-of v0, p3, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;

    if-eqz v0, :cond_51

    move-object v0, p3

    check-cast v0, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;->initOnUserVisibleHint(Z)V

    iget v1, p0, La6/a;->h:I

    if-ne p2, v1, :cond_52

    iget-object v1, p0, La6/a;->k:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;->onTabSelected(Landroid/content/Context;)V

    const/4 v1, -0x1

    iput v1, p0, La6/a;->h:I

    goto :goto_52

    :cond_51
    :goto_51
    const/4 v0, 0x0

    :cond_52
    :goto_52
    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/s;->setPrimaryItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V

    if-eqz v0, :cond_61

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/d;

    move-result-object p1

    if-eqz p1, :cond_61

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Lcom/flipkart/android/newmultiwidget/MultiTabInsideFragment;->initOnUserVisibleHint(Z)V

    :cond_61
    return-void
.end method

.method public setTabInfo(Lcom/google/android/material/tabs/TabLayout$f;I)V
    .registers 8

    iget-object v0, p0, La6/a;->j:Ljava/util/List;

    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La6/c;

    iget-object v0, p2, La6/c;->f:Ljava/lang/String;

    const-string v1, "L1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    iget-object v2, p0, La6/a;->k:Landroid/content/Context;

    iget-object v3, p0, La6/a;->m:Ljava/util/Map;

    if-eqz v0, :cond_2e

    new-instance v0, LGe/G;

    invoke-direct {v0}, LGe/G;-><init>()V

    if-eqz v3, :cond_29

    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_29

    invoke-interface {v3, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LGe/G;

    :cond_29
    invoke-static {v2, p2, v0}, La6/d;->getL1TabItemView(Landroid/content/Context;La6/c;LGe/G;)Landroid/view/View;

    move-result-object v0

    goto :goto_51

    :cond_2e
    iget-object v0, p2, La6/c;->f:Ljava/lang/String;

    const-string v1, "L2"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_50

    new-instance v0, LGe/G;

    invoke-direct {v0}, LGe/G;-><init>()V

    if-eqz v3, :cond_4b

    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_4b

    invoke-interface {v3, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LGe/G;

    :cond_4b
    invoke-static {v2, p2, v0}, La6/d;->getL2TabItemView(Landroid/content/Context;La6/c;LGe/G;)Landroid/view/View;

    move-result-object v0

    goto :goto_51

    :cond_50
    const/4 v0, 0x0

    :goto_51
    invoke-virtual {p1, v0}, Lcom/google/android/material/tabs/TabLayout$f;->l(Landroid/view/View;)V

    invoke-virtual {p1, p2}, Lcom/google/android/material/tabs/TabLayout$f;->o(La6/c;)V

    return-void
.end method

.method public swap(Ljava/util/List;Ljava/util/Map;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "La6/c;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La6/a;->j:Ljava/util/List;

    iput-object p2, p0, La6/a;->i:Ljava/util/Map;

    invoke-virtual {p0}, Landroidx/viewpager/widget/a;->notifyDataSetChanged()V

    return-void
.end method

.method public updateSelectedChildNode(IILjava/lang/String;)V
    .registers 4

    invoke-virtual {p0, p1, p2}, La6/a;->getFragmentAtPosition(II)Landroidx/fragment/app/Fragment;

    move-result-object p1

    instance-of p2, p1, La6/b;

    if-eqz p2, :cond_d

    check-cast p1, La6/b;

    invoke-virtual {p1, p3}, La6/b;->updateSelectedChildNode(Ljava/lang/String;)V

    :cond_d
    return-void
.end method
