.class public final La6/d;
.super Ljava/lang/Object;
.source "TabLayoutBuilder.java"


# direct methods
.method private static a(Landroid/content/Context;Lcom/google/android/material/tabs/TabLayout;)V
    .registers 6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f060162

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f0601fa

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {p1}, Lcom/google/android/material/tabs/TabLayout;->k()I

    move-result v2

    const/4 v3, 0x1

    if-le v2, v3, :cond_36

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v2, 0x7f06001d

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/google/android/material/tabs/TabLayout;->r(I)V

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    :cond_36
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result p0

    invoke-virtual {p1, p0, v0}, Lcom/google/android/material/tabs/TabLayout;->v(II)V

    return-void
.end method

.method public static getL1TabItemView(Landroid/content/Context;La6/c;LGe/G;)Landroid/view/View;
    .registers 9

    const/4 v0, 0x0

    if-eqz p2, :cond_1a

    iget-object v1, p2, LGe/G;->j:Ljava/lang/String;

    if-eqz v1, :cond_1a

    const-string v2, "TITLE_FIXED_WIDTH"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19

    const-string v1, "TITLE_DYNAMIC_WIDTH"

    iget-object v2, p2, LGe/G;->j:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1a

    :cond_19
    return-object v0

    :cond_1a
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v2, 0x7f0e01c1

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v0, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    new-instance v2, Landroid/view/ViewGroup$LayoutParams;

    const/16 v4, 0x38

    invoke-static {p0, v4}, Lcom/flipkart/android/utils/Y0;->dpToPx(Landroid/content/Context;I)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v2, v5, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v2, 0x7f0b06de

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iget-object v4, p1, La6/c;->b:Ljava/lang/String;

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_4b

    iget-object v4, p1, La6/c;->b:Ljava/lang/String;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_4b
    const v2, 0x7f0b06dd

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iget-object v4, p1, La6/c;->c:LMe/r1;

    if-eqz v4, :cond_75

    iget-object v0, v4, LMe/r1;->f:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_6b

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    const/4 v5, 0x0

    invoke-static {p0, v4, v5, v5, v0}, Lcom/flipkart/android/utils/h0;->getSatyaUrl(Landroid/content/Context;LMe/r1;FFF)Lcom/flipkart/android/satyabhama/FkRukminiRequest;

    move-result-object v0

    goto :goto_75

    :cond_6b
    iget-object v0, v4, LMe/r1;->e:Ljava/lang/String;

    iget-object v4, v4, LMe/r1;->a:Ljava/util/Map;

    const-string v5, "BANNER"

    invoke-static {p0, v0, v4, v5}, Lcom/flipkart/android/utils/h0;->getImageUrl(Landroid/content/Context;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Lcom/flipkart/android/satyabhama/FkRukminiRequest;

    move-result-object v0

    :cond_75
    :goto_75
    if-eqz v0, :cond_a1

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-static {p0}, Lcom/flipkart/android/satyabhama/b;->getSatyabhama(Landroid/content/Context;)Lii/a;

    move-result-object v4

    invoke-virtual {v4, p0}, Lii/a;->with(Landroid/content/Context;)Lii/c;

    move-result-object v4

    invoke-interface {v4, v0}, Lii/c;->load(Lcom/flipkart/satyabhama/models/RukminiRequest;)Lii/c;

    move-result-object v4

    invoke-virtual {v0}, Lcom/flipkart/android/satyabhama/FkRukminiRequest;->getWidth()I

    move-result v5

    invoke-virtual {v0}, Lcom/flipkart/android/satyabhama/FkRukminiRequest;->getHeight()I

    move-result v0

    invoke-interface {v4, v5, v0}, Lii/c;->override(II)Lii/c;

    move-result-object v0

    invoke-interface {v0, p0, v3}, Lii/c;->withRoundedCorners(Landroid/content/Context;I)Lii/c;

    move-result-object v0

    invoke-static {p0}, Lcom/flipkart/android/utils/h0;->getImageLoadListener(Landroid/content/Context;)Lki/b;

    move-result-object v3

    invoke-interface {v0, v3}, Lii/c;->listener(Lki/b;)Lii/c;

    move-result-object v0

    invoke-interface {v0, v2}, Lii/c;->into(Landroid/widget/ImageView;)Lcom/flipkart/satyabhama/models/SatyaViewTarget;

    :cond_a1
    if-eqz p2, :cond_c4

    iget-object v0, p2, LGe/G;->a:Ljava/lang/Integer;

    if-eqz v0, :cond_c4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-lez v0, :cond_c4

    iget-object p2, p2, LGe/G;->a:Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {p0, p2}, Lcom/flipkart/android/utils/Y0;->dpToPx(Landroid/content/Context;I)I

    move-result p0

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p2

    iget v0, p2, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-eq v0, p0, :cond_c4

    iput p0, p2, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {v1, p2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_c4
    const p0, 0x7f0b045d

    invoke-virtual {v1, p0, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    return-object v1
.end method

.method public static getL2TabItemView(Landroid/content/Context;La6/c;LGe/G;)Landroid/view/View;
    .registers 7

    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const v3, 0x7f0e0085

    invoke-virtual {v0, v3, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0b0707

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const/high16 v2, 0x40000000    # 2.0f

    invoke-virtual {v1, v2}, Landroid/view/View;->setElevation(F)V

    iget-object v3, p1, La6/c;->b:Ljava/lang/String;

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_40

    iget-object v3, p1, La6/c;->b:Ljava/lang/String;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz p2, :cond_36

    iget-object p2, p2, LGe/G;->b:Ljava/lang/String;

    if-eqz p2, :cond_36

    invoke-static {p2}, Lcom/flipkart/android/utils/w;->parseColor(Ljava/lang/String;)I

    move-result p2

    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_40

    :cond_36
    const p2, 0x7f060069

    invoke-static {p0, p2}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p2

    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_40
    :goto_40
    const p2, 0x7f0601fa

    invoke-static {p0, p2}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p0

    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    check-cast p2, Landroid/graphics/drawable/GradientDrawable;

    invoke-virtual {p2, p0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {p2, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const p0, 0x7f0b045d

    invoke-virtual {v0, p0, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    return-object v0
.end method

.method public static setTabLayoutParams(Landroid/content/Context;Lcom/google/android/material/tabs/TabLayout;LGe/G;)V
    .registers 4

    if-eqz p1, :cond_2b

    if-eqz p2, :cond_2b

    iget-object p2, p2, LGe/G;->j:Ljava/lang/String;

    if-eqz p2, :cond_2b

    const-string v0, "TITLE_FIXED_WIDTH"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_21

    const-string v0, "TITLE_DYNAMIC_WIDTH"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_19

    goto :goto_2b

    :cond_19
    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/material/tabs/TabLayout;->u(I)V

    invoke-static {p0, p1}, La6/d;->a(Landroid/content/Context;Lcom/google/android/material/tabs/TabLayout;)V

    goto :goto_2b

    :cond_21
    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Lcom/google/android/material/tabs/TabLayout;->u(I)V

    invoke-virtual {p1}, Lcom/google/android/material/tabs/TabLayout;->t()V

    invoke-static {p0, p1}, La6/d;->a(Landroid/content/Context;Lcom/google/android/material/tabs/TabLayout;)V

    :cond_2b
    :goto_2b
    return-void
.end method

.method public static stickTab(Lcom/google/android/material/tabs/TabLayout;)V
    .registers 2

    if-eqz p0, :cond_c

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Lcom/google/android/material/appbar/AppBarLayout$LayoutParams;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/AppBarLayout$LayoutParams;->b(I)V

    :cond_c
    return-void
.end method
