.class public interface abstract LA6/f;
.super Ljava/lang/Object;
.source "PageLoadObservers.kt"


# virtual methods
.method public abstract onPayloadEmit()V
.end method

.method public abstract onPayloadReady()V
.end method

.method public abstract onPayloadReceivedAt(J)V
.end method

.method public abstract onReadyForEmit()V
.end method
