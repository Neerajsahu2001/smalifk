.class public interface abstract LA6/h;
.super Ljava/lang/Object;
.source "PageLoadObservers.kt"


# virtual methods
.method public abstract onScroll()V
.end method
