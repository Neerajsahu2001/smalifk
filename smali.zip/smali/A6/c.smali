.class public final La6/c;
.super Ljava/lang/Object;
.source "TabInfo.java"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:LMe/r1;

.field public final d:Landroid/os/Bundle;

.field public e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La6/c;",
            ">;"
        }
    .end annotation
.end field

.field public f:Ljava/lang/String;

.field public g:LMe/H0;

.field public h:LGe/b;

.field public i:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;LMe/H0;LGe/b;Landroid/os/Bundle;Ljava/util/List;Ljava/lang/String;Z)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LMe/H0;",
            "LGe/b;",
            "Landroid/os/Bundle;",
            "Ljava/util/List<",
            "La6/c;",
            ">;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La6/c;->a:Ljava/lang/String;

    iput-object p2, p0, La6/c;->g:LMe/H0;

    iput-object p3, p0, La6/c;->h:LGe/b;

    iget-object p1, p2, LMe/y;->b:Ljava/lang/String;

    iput-object p1, p0, La6/c;->b:Ljava/lang/String;

    iget-object p1, p2, LMe/y;->a:LMe/r1;

    iput-object p1, p0, La6/c;->c:LMe/r1;

    iput-object p4, p0, La6/c;->d:Landroid/os/Bundle;

    iput-object p5, p0, La6/c;->e:Ljava/util/List;

    iput-object p6, p0, La6/c;->f:Ljava/lang/String;

    iput-boolean p7, p0, La6/c;->i:Z

    return-void
.end method
