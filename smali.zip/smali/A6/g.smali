.class public interface abstract LA6/g;
.super Ljava/lang/Object;
.source "PageLoadObservers.kt"


# virtual methods
.method public abstract onChangeUri()V
.end method

.method public abstract onPagePainted(Lcom/flipkart/android/datagovernance/NavigationContext;)V
.end method

.method public abstract onPageRenderedAt(J)V
.end method

.method public abstract onPageResponseParsedAt(J)V
.end method

.method public abstract onPageResponseProcessedAt(J)V
.end method

.method public abstract processRenderMetrics(Lcom/facebook/react/bridge/ReadableMap;)V
.end method
