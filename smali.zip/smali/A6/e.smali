.class public interface abstract LA6/e;
.super Ljava/lang/Object;
.source "PageLoadObservers.kt"


# virtual methods
.method public abstract onContentfulPageLoadComplete()V
.end method

.method public abstract onContentfulPageLoadFailure()V
.end method
