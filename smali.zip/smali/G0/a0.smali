.class public final Lg0/a0;
.super Ljava/lang/Object;
.source "DefaultAnalyticsCollector.java"

# interfaces
.implements Lg0/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lg0/a0$a;
    }
.end annotation


# instance fields
.field private final a:La0/b;

.field private final b:Landroidx/media3/common/A$b;

.field private final c:Landroidx/media3/common/A$c;

.field private final d:Lg0/a0$a;

.field private final e:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lg0/b$a;",
            ">;"
        }
    .end annotation
.end field

.field private f:La0/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/o<",
            "Lg0/b;",
            ">;"
        }
    .end annotation
.end field

.field private g:Landroidx/media3/common/y;

.field private h:La0/l;

.field private i:Z


# direct methods
.method public constructor <init>(La0/b;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lg0/a0;->a:La0/b;

    new-instance v0, La0/o;

    sget v1, La0/T;->a:I

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    if-eqz v1, :cond_13

    goto :goto_17

    :cond_13
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    :goto_17
    new-instance v2, LDi/q;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v1, p1, v2}, La0/o;-><init>(Landroid/os/Looper;La0/b;La0/o$b;)V

    iput-object v0, p0, Lg0/a0;->f:La0/o;

    new-instance p1, Landroidx/media3/common/A$b;

    invoke-direct {p1}, Landroidx/media3/common/A$b;-><init>()V

    iput-object p1, p0, Lg0/a0;->b:Landroidx/media3/common/A$b;

    new-instance v0, Landroidx/media3/common/A$c;

    invoke-direct {v0}, Landroidx/media3/common/A$c;-><init>()V

    iput-object v0, p0, Lg0/a0;->c:Landroidx/media3/common/A$c;

    new-instance v0, Lg0/a0$a;

    invoke-direct {v0, p1}, Lg0/a0$a;-><init>(Landroidx/media3/common/A$b;)V

    iput-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Lg0/a0;->e:Landroid/util/SparseArray;

    return-void
.end method

.method public static synthetic M(Lg0/a0;Landroidx/media3/common/y;Lg0/b;Landroidx/media3/common/l;)V
    .registers 5

    new-instance v0, Lg0/b$b;

    iget-object p0, p0, Lg0/a0;->e:Landroid/util/SparseArray;

    invoke-direct {v0, p3, p0}, Lg0/b$b;-><init>(Landroidx/media3/common/l;Landroid/util/SparseArray;)V

    invoke-interface {p2, p1, v0}, Lg0/b;->P(Landroidx/media3/common/y;Lg0/b$b;)V

    return-void
.end method

.method public static N(Lg0/a0;)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/I;

    invoke-direct {v1, v0}, Lg0/I;-><init>(Ljava/lang/Object;)V

    const/16 v2, 0x404

    invoke-virtual {p0, v0, v2, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    iget-object p0, p0, Lg0/a0;->f:La0/o;

    invoke-virtual {p0}, La0/o;->f()V

    return-void
.end method

.method private Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;
    .registers 5

    iget-object v0, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    if-nez p1, :cond_a

    move-object v1, v0

    goto :goto_10

    :cond_a
    iget-object v1, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v1, p1}, Lg0/a0$a;->f(Landroidx/media3/exoplayer/source/o$b;)Landroidx/media3/common/A;

    move-result-object v1

    :goto_10
    if-eqz p1, :cond_24

    if-nez v1, :cond_15

    goto :goto_24

    :cond_15
    iget-object v0, p1, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    iget-object v2, p0, Lg0/a0;->b:Landroidx/media3/common/A$b;

    invoke-virtual {v1, v0, v2}, Landroidx/media3/common/A;->h(Ljava/lang/Object;Landroidx/media3/common/A$b;)Landroidx/media3/common/A$b;

    move-result-object v0

    iget v0, v0, Landroidx/media3/common/A$b;->c:I

    invoke-virtual {p0, v1, v0, p1}, Lg0/a0;->P(Landroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    return-object p1

    :cond_24
    :goto_24
    iget-object p1, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {p1}, Landroidx/media3/common/y;->Q()I

    move-result p1

    iget-object v1, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->v()Landroidx/media3/common/A;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/media3/common/A;->p()I

    move-result v2

    if-ge p1, v2, :cond_37

    goto :goto_39

    :cond_37
    sget-object v1, Landroidx/media3/common/A;->a:Landroidx/media3/common/A;

    :goto_39
    invoke-virtual {p0, v1, p1, v0}, Lg0/a0;->P(Landroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    return-object p1
.end method

.method private R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;
    .registers 4

    iget-object v0, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz p2, :cond_1b

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0, p2}, Lg0/a0$a;->f(Landroidx/media3/exoplayer/source/o$b;)Landroidx/media3/common/A;

    move-result-object v0

    if-eqz v0, :cond_14

    invoke-direct {p0, p2}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    goto :goto_1a

    :cond_14
    sget-object v0, Landroidx/media3/common/A;->a:Landroidx/media3/common/A;

    invoke-virtual {p0, v0, p1, p2}, Lg0/a0;->P(Landroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    :goto_1a
    return-object p1

    :cond_1b
    iget-object p2, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {p2}, Landroidx/media3/common/y;->v()Landroidx/media3/common/A;

    move-result-object p2

    invoke-virtual {p2}, Landroidx/media3/common/A;->p()I

    move-result v0

    if-ge p1, v0, :cond_28

    goto :goto_2a

    :cond_28
    sget-object p2, Landroidx/media3/common/A;->a:Landroidx/media3/common/A;

    :goto_2a
    const/4 v0, 0x0

    invoke-virtual {p0, p2, p1, v0}, Lg0/a0;->P(Landroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    return-object p1
.end method

.method private S()Lg0/b$a;
    .registers 2

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0}, Lg0/a0$a;->h()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final A(ILandroidx/media3/exoplayer/source/o$b;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, LK/e;

    invoke-direct {p2, p1}, LK/e;-><init>(Ljava/lang/Object;)V

    const/16 v0, 0x3ff

    invoke-virtual {p0, p1, v0, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final B(ILandroidx/media3/exoplayer/source/o$b;I)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/L;

    invoke-direct {p2, p3, p1}, Lg0/L;-><init>(ILg0/b$a;)V

    const/16 p3, 0x3fe

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final C(ILandroidx/media3/exoplayer/source/o$b;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/T;

    invoke-direct {p2, p1}, Lg0/T;-><init>(Ljava/lang/Object;)V

    const/16 v0, 0x402

    invoke-virtual {p0, p1, v0, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final D(ILandroidx/media3/exoplayer/source/o$b;Ljava/lang/Exception;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/M;

    invoke-direct {p2, p1, p3}, Lg0/M;-><init>(Ljava/lang/Object;Ljava/io/Serializable;)V

    const/16 p3, 0x400

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final E(ILandroidx/media3/exoplayer/source/o$b;Lq0/h;)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/n;

    const/4 v0, 0x1

    invoke-direct {p2, p1, p3, v0}, Lg0/n;-><init>(Lg0/b$a;Ljava/lang/Object;I)V

    const/16 p3, 0x3ed

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final F(ILandroidx/media3/exoplayer/source/o$b;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lcom/flipkart/android/activity/x;

    invoke-direct {p2, p1}, Lcom/flipkart/android/activity/x;-><init>(Ljava/lang/Object;)V

    const/16 v0, 0x401

    invoke-virtual {p0, p1, v0, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final G(ILandroidx/media3/exoplayer/source/o$b;Lq0/g;Lq0/h;)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/Z;

    invoke-direct {p2, p1, p3, p4}, Lg0/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p3, 0x3e8

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final H(ILandroidx/media3/exoplayer/source/o$b;Lq0/g;Lq0/h;)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/N;

    invoke-direct {p2, p1, p3, p4}, Lg0/N;-><init>(Lg0/b$a;Lq0/g;Lq0/h;)V

    const/16 p3, 0x3e9

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final I(Lg0/b;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lg0/a0;->f:La0/o;

    invoke-virtual {v0, p1}, La0/o;->b(Ljava/lang/Object;)V

    return-void
.end method

.method public final J(ILandroidx/media3/exoplayer/source/o$b;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/Q;

    invoke-direct {p2, p1}, Lg0/Q;-><init>(Lg0/b$a;)V

    const/16 v0, 0x403

    invoke-virtual {p0, p1, v0, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final K(Landroidx/media3/common/y;Landroid/os/Looper;)V
    .registers 5

    iget-object v0, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    if-eqz v0, :cond_13

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-static {v0}, Lg0/a0$a;->a(Lg0/a0$a;)Lgk/w;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_13

    :cond_11
    const/4 v0, 0x0

    goto :goto_14

    :cond_13
    :goto_13
    const/4 v0, 0x1

    :goto_14
    invoke-static {v0}, Lcom/facebook/soloader/m;->e(Z)V

    iput-object p1, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    iget-object v0, p0, Lg0/a0;->a:La0/b;

    const/4 v1, 0x0

    invoke-interface {v0, p2, v1}, La0/b;->b(Landroid/os/Looper;Landroid/os/Handler$Callback;)La0/l;

    move-result-object v0

    iput-object v0, p0, Lg0/a0;->h:La0/l;

    iget-object v0, p0, Lg0/a0;->f:La0/o;

    new-instance v1, Lg0/h;

    invoke-direct {v1, p0, p1}, Lg0/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, p2, v1}, La0/o;->c(Landroid/os/Looper;Lg0/h;)La0/o;

    move-result-object p1

    iput-object p1, p0, Lg0/a0;->f:La0/o;

    return-void
.end method

.method public final L(ILandroidx/media3/exoplayer/source/o$b;Lq0/g;Lq0/h;)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Landroidx/fragment/app/c;

    invoke-direct {p2, p1, p3, p4}, Landroidx/fragment/app/c;-><init>(Lg0/b$a;Lq0/g;Lq0/h;)V

    const/16 p3, 0x3ea

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method protected final O()Lg0/b$a;
    .registers 2

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0}, Lg0/a0$a;->d()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    return-object v0
.end method

.method protected final P(Landroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v4, p1

    move/from16 v5, p2

    invoke-virtual/range {p1 .. p1}, Landroidx/media3/common/A;->q()Z

    move-result v1

    if-eqz v1, :cond_f

    const/4 v1, 0x0

    move-object v6, v1

    goto :goto_11

    :cond_f
    move-object/from16 v6, p3

    :goto_11
    iget-object v1, v0, Lg0/a0;->a:La0/b;

    invoke-interface {v1}, La0/b;->elapsedRealtime()J

    move-result-wide v2

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->v()Landroidx/media3/common/A;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroidx/media3/common/A;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->Q()I

    move-result v1

    if-ne v5, v1, :cond_2d

    const/4 v1, 0x1

    goto :goto_2e

    :cond_2d
    const/4 v1, 0x0

    :goto_2e
    const-wide/16 v7, 0x0

    if-eqz v6, :cond_55

    invoke-virtual {v6}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result v9

    if-eqz v9, :cond_55

    if-eqz v1, :cond_71

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->p()I

    move-result v1

    iget v9, v6, Landroidx/media3/exoplayer/source/o$b;->b:I

    if-ne v1, v9, :cond_71

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->I()I

    move-result v1

    iget v9, v6, Landroidx/media3/exoplayer/source/o$b;->c:I

    if-ne v1, v9, :cond_71

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->getCurrentPosition()J

    move-result-wide v7

    goto :goto_71

    :cond_55
    if-eqz v1, :cond_5e

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->L()J

    move-result-wide v7

    goto :goto_71

    :cond_5e
    invoke-virtual/range {p1 .. p1}, Landroidx/media3/common/A;->q()Z

    move-result v1

    if-eqz v1, :cond_65

    goto :goto_71

    :cond_65
    iget-object v1, v0, Lg0/a0;->c:Landroidx/media3/common/A$c;

    invoke-virtual {v4, v5, v1, v7, v8}, Landroidx/media3/common/A;->n(ILandroidx/media3/common/A$c;J)Landroidx/media3/common/A$c;

    move-result-object v1

    iget-wide v7, v1, Landroidx/media3/common/A$c;->l:J

    invoke-static {v7, v8}, La0/T;->j0(J)J

    move-result-wide v7

    :cond_71
    :goto_71
    iget-object v1, v0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v1}, Lg0/a0$a;->d()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v11

    new-instance v16, Lg0/b$a;

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->v()Landroidx/media3/common/A;

    move-result-object v9

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->Q()I

    move-result v10

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->getCurrentPosition()J

    move-result-wide v12

    iget-object v1, v0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-interface {v1}, Landroidx/media3/common/y;->f()J

    move-result-wide v14

    move-object/from16 v1, v16

    move-object/from16 v4, p1

    move/from16 v5, p2

    invoke-direct/range {v1 .. v15}, Lg0/b$a;-><init>(JLandroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;JLandroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;JJ)V

    return-object v16
.end method

.method protected final T(Lg0/b$a;ILa0/o$a;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lg0/b$a;",
            "I",
            "La0/o$a<",
            "Lg0/b;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Lg0/a0;->e:Landroid/util/SparseArray;

    invoke-virtual {v0, p2, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iget-object p1, p0, Lg0/a0;->f:La0/o;

    invoke-virtual {p1, p2, p3}, La0/o;->h(ILa0/o$a;)V

    return-void
.end method

.method public final a(Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/n;

    const/4 v2, 0x0

    invoke-direct {v1, v0, p1, v2}, Lg0/n;-><init>(Lg0/b$a;Ljava/lang/Object;I)V

    const/16 p1, 0x3fb

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final b(Landroidx/media3/exoplayer/audio/h$a;)V
    .registers 4

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/U;

    invoke-direct {v1, v0, p1}, Lg0/U;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p1, 0x407

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/Y;

    const/4 v2, 0x0

    invoke-direct {v1, v0, p1, v2}, Lg0/Y;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 p1, 0x3f4

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final d(Landroidx/media3/exoplayer/audio/h$a;)V
    .registers 4

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/V;

    invoke-direct {v1, v0, p1}, Lg0/V;-><init>(Lg0/b$a;Landroidx/media3/exoplayer/audio/h$a;)V

    const/16 p1, 0x408

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final e(Landroidx/media3/exoplayer/k;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/W;

    const/4 v2, 0x0

    invoke-direct {v1, v0, p1, v2}, Lg0/W;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 p1, 0x3ef

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final f(Landroidx/media3/exoplayer/k;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/E;

    const/4 v2, 0x1

    invoke-direct {v1, v0, p1, v2}, Lg0/E;-><init>(Lg0/b$a;Ljava/lang/Object;I)V

    const/16 p1, 0x3f7

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final g(ILandroidx/media3/exoplayer/source/o$b;Lq0/h;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/H;

    invoke-direct {p2, p1, p3}, Lg0/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p3, 0x3ec

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final h(Ljava/lang/Exception;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/Y;

    const/4 v2, 0x1

    invoke-direct {v1, v0, p1, v2}, Lg0/Y;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 p1, 0x3f6

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final i(J)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, La0/B;

    invoke-direct {v1, v0, p1, p2}, La0/B;-><init>(Lg0/b$a;J)V

    const/16 p1, 0x3f2

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final j(Landroidx/media3/common/m;Landroidx/media3/exoplayer/l;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/z;

    invoke-direct {v1, v0, p1, p2}, Lg0/z;-><init>(Lg0/b$a;Landroidx/media3/common/m;Landroidx/media3/exoplayer/l;)V

    const/16 p1, 0x3f1

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final k(Ljava/lang/Exception;)V
    .registers 4

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/g;

    invoke-direct {v1, v0, p1}, Lg0/g;-><init>(Ljava/lang/Object;Ljava/io/Serializable;)V

    const/16 p1, 0x406

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final l(JLjava/lang/Object;)V
    .registers 6

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/P;

    invoke-direct {v1, v0, p3, p1, p2}, Lg0/P;-><init>(Lg0/b$a;Ljava/lang/Object;J)V

    const/16 p1, 0x1a

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final m(Landroidx/media3/exoplayer/k;)V
    .registers 4

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0}, Lg0/a0$a;->g()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/u;

    invoke-direct {v1, v0, p1}, Lg0/u;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p1, 0x3f5

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final n(JJLjava/lang/String;)V
    .registers 15

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v7

    new-instance v8, Lg0/l;

    move-object v0, v8

    move-object v1, v7

    move-object v2, p5

    move-wide v3, p3

    move-wide v5, p1

    invoke-direct/range {v0 .. v6}, Lg0/l;-><init>(Lg0/b$a;Ljava/lang/String;JJ)V

    const/16 p1, 0x3f0

    invoke-virtual {p0, v7, p1, v8}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final o(IJ)V
    .registers 6

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0}, Lg0/a0$a;->g()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    new-instance v1, LS/a;

    invoke-direct {v1, p1, p2, p3, v0}, LS/a;-><init>(IJLg0/b$a;)V

    const/16 p1, 0x3fd

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onAvailableCommandsChanged(Landroidx/media3/common/y$a;)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, LU9/d;

    invoke-direct {v1, v0, p1}, LU9/d;-><init>(Lg0/b$a;Landroidx/media3/common/y$a;)V

    const/16 p1, 0xd

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onCues(LZ/b;)V
    .registers 5

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/E;

    const/4 v2, 0x0

    invoke-direct {v1, v0, p1, v2}, Lg0/E;-><init>(Lg0/b$a;Ljava/lang/Object;I)V

    const/16 p1, 0x1b

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onCues(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LZ/a;",
            ">;)V"
        }
    .end annotation

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/r;

    invoke-direct {v1, v0, p1}, Lg0/r;-><init>(Lg0/b$a;Ljava/util/List;)V

    const/16 p1, 0x1b

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onEvents(Landroidx/media3/common/y;Landroidx/media3/common/y$b;)V
    .registers 3

    return-void
.end method

.method public final onIsLoadingChanged(Z)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/X;

    invoke-direct {v1, v0, p1}, Lg0/X;-><init>(Lg0/b$a;Z)V

    const/4 p1, 0x3

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onIsPlayingChanged(Z)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/j;

    invoke-direct {v1, v0, p1}, Lg0/j;-><init>(Lg0/b$a;Z)V

    const/4 p1, 0x7

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onLoadingChanged(Z)V
    .registers 2

    return-void
.end method

.method public final onMediaItemTransition(Landroidx/media3/common/q;I)V
    .registers 5

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/e;

    invoke-direct {v1, v0, p1, p2}, Lg0/e;-><init>(Lg0/b$a;Landroidx/media3/common/q;I)V

    const/4 p1, 0x1

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onMediaMetadataChanged(Landroidx/media3/common/s;)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Landroidx/core/os/m;

    invoke-direct {v1, v0, p1}, Landroidx/core/os/m;-><init>(Lg0/b$a;Landroidx/media3/common/s;)V

    const/16 p1, 0xe

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onMetadata(Landroidx/media3/common/Metadata;)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/i;

    invoke-direct {v1, v0, p1}, Lg0/i;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p1, 0x1c

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPlayWhenReadyChanged(ZI)V
    .registers 5

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/q;

    invoke-direct {v1, p2, v0, p1}, Lg0/q;-><init>(ILg0/b$a;Z)V

    const/4 p1, 0x5

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPlaybackParametersChanged(Landroidx/media3/common/x;)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/c;

    invoke-direct {v1, v0, p1}, Lg0/c;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p1, 0xc

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPlaybackStateChanged(I)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/v;

    invoke-direct {v1, p1, v0}, Lg0/v;-><init>(ILg0/b$a;)V

    const/4 p1, 0x4

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPlaybackSuppressionReasonChanged(I)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/m;

    invoke-direct {v1, p1, v0}, Lg0/m;-><init>(ILg0/b$a;)V

    const/4 p1, 0x6

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPlayerError(Landroidx/media3/common/w;)V
    .registers 4

    move-object v0, p1

    check-cast v0, Landroidx/media3/exoplayer/p;

    instance-of v1, v0, Landroidx/media3/exoplayer/p;

    if-eqz v1, :cond_10

    iget-object v0, v0, Landroidx/media3/exoplayer/p;->h:Landroidx/media3/exoplayer/source/o$b;

    if-eqz v0, :cond_10

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    goto :goto_14

    :cond_10
    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    :goto_14
    new-instance v1, Lg0/s;

    invoke-direct {v1, v0, p1}, Lg0/s;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p1, 0xa

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPlayerErrorChanged(Landroidx/media3/common/w;)V
    .registers 4

    move-object v0, p1

    check-cast v0, Landroidx/media3/exoplayer/p;

    instance-of v1, v0, Landroidx/media3/exoplayer/p;

    if-eqz v1, :cond_10

    iget-object v0, v0, Landroidx/media3/exoplayer/p;->h:Landroidx/media3/exoplayer/source/o$b;

    if-eqz v0, :cond_10

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    goto :goto_14

    :cond_10
    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    :goto_14
    new-instance v1, Lg0/p;

    invoke-direct {v1, v0, p1}, Lg0/p;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p1, 0xa

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPlayerStateChanged(ZI)V
    .registers 5

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Landroidx/media3/container/a;

    invoke-direct {v1, p2, v0, p1}, Landroidx/media3/container/a;-><init>(ILg0/b$a;Z)V

    const/4 p1, -0x1

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onPositionDiscontinuity(I)V
    .registers 2

    return-void
.end method

.method public final onPositionDiscontinuity(Landroidx/media3/common/y$d;Landroidx/media3/common/y$d;I)V
    .registers 6

    const/4 v0, 0x1

    if-ne p3, v0, :cond_6

    const/4 v0, 0x0

    iput-boolean v0, p0, Lg0/a0;->i:Z

    :cond_6
    iget-object v0, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v1, v0}, Lg0/a0$a;->j(Landroidx/media3/common/y;)V

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/A;

    invoke-direct {v1, p3, p1, p2, v0}, Lg0/A;-><init>(ILandroidx/media3/common/y$d;Landroidx/media3/common/y$d;Lg0/b$a;)V

    const/16 p1, 0xb

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onRenderedFirstFrame()V
    .registers 1

    return-void
.end method

.method public final onRepeatModeChanged(I)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/B;

    invoke-direct {v1, p1, v0}, Lg0/B;-><init>(ILg0/b$a;)V

    const/16 p1, 0x8

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onShuffleModeEnabledChanged(Z)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/D;

    invoke-direct {v1, v0, p1}, Lg0/D;-><init>(Lg0/b$a;Z)V

    const/16 p1, 0x9

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onSkipSilenceEnabledChanged(Z)V
    .registers 4

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/S;

    invoke-direct {v1, v0, p1}, Lg0/S;-><init>(Lg0/b$a;Z)V

    const/16 p1, 0x17

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onSurfaceSizeChanged(II)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/F;

    invoke-direct {v1, v0, p1, p2}, Lg0/F;-><init>(Lg0/b$a;II)V

    const/16 p1, 0x18

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onTimelineChanged(Landroidx/media3/common/A;I)V
    .registers 4

    iget-object p1, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0, p1}, Lg0/a0$a;->l(Landroidx/media3/common/y;)V

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object p1

    new-instance v0, Lg0/d;

    invoke-direct {v0, p2, p1}, Lg0/d;-><init>(ILg0/b$a;)V

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onTrackSelectionParametersChanged(Landroidx/media3/common/TrackSelectionParameters;)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Landroidx/coordinatorlayout/widget/a;

    invoke-direct {v1, v0, p1}, Landroidx/coordinatorlayout/widget/a;-><init>(Lg0/b$a;Landroidx/media3/common/TrackSelectionParameters;)V

    const/16 p1, 0x13

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onTracksChanged(Landroidx/media3/common/D;)V
    .registers 4

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/k;

    invoke-direct {v1, v0, p1}, Lg0/k;-><init>(Lg0/b$a;Landroidx/media3/common/D;)V

    const/4 p1, 0x2

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onVideoSizeChanged(Landroidx/media3/common/H;)V
    .registers 4

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/O;

    invoke-direct {v1, v0, p1}, Lg0/O;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 p1, 0x19

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final onVolumeChanged(F)V
    .registers 4

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/f;

    invoke-direct {v1, v0, p1}, Lg0/f;-><init>(Lg0/b$a;F)V

    const/16 p1, 0x16

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final p(IJ)V
    .registers 6

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0}, Lg0/a0$a;->g()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/o;

    invoke-direct {v1, p1, p2, p3, v0}, Lg0/o;-><init>(IJLg0/b$a;)V

    const/16 p1, 0x3fa

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final q(Landroidx/media3/common/m;Landroidx/media3/exoplayer/l;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/x;

    invoke-direct {v1, v0, p1, p2}, Lg0/x;-><init>(Lg0/b$a;Landroidx/media3/common/m;Landroidx/media3/exoplayer/l;)V

    const/16 p1, 0x3f9

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final r(Landroidx/media3/exoplayer/k;)V
    .registers 4

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0}, Lg0/a0$a;->g()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/t;

    invoke-direct {v1, v0, p1}, Lg0/t;-><init>(Lg0/b$a;Landroidx/media3/exoplayer/k;)V

    const/16 p1, 0x3fc

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final release()V
    .registers 4

    iget-object v0, p0, Lg0/a0;->h:La0/l;

    invoke-static {v0}, Lcom/facebook/soloader/m;->g(Ljava/lang/Object;)V

    new-instance v1, Landroidx/lifecycle/e;

    const/4 v2, 0x1

    invoke-direct {v1, v2, p0}, Landroidx/lifecycle/e;-><init>(ILjava/lang/Object;)V

    invoke-interface {v0, v1}, La0/l;->h(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final s(Ljava/lang/Exception;)V
    .registers 5

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v0

    new-instance v1, Lg0/W;

    const/4 v2, 0x1

    invoke-direct {v1, v0, p1, v2}, Lg0/W;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 p1, 0x405

    invoke-virtual {p0, v0, p1, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final t(JJLjava/lang/String;)V
    .registers 15

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v7

    new-instance v8, Lg0/C;

    move-object v0, v8

    move-object v1, v7

    move-object v2, p5

    move-wide v3, p3

    move-wide v5, p1

    invoke-direct/range {v0 .. v6}, Lg0/C;-><init>(Lg0/b$a;Ljava/lang/String;JJ)V

    const/16 p1, 0x3f8

    invoke-virtual {p0, v7, p1, v8}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final u(IJJ)V
    .registers 15

    invoke-direct {p0}, Lg0/a0;->S()Lg0/b$a;

    move-result-object v7

    new-instance v8, Lg0/J;

    move-object v0, v8

    move-object v1, v7

    move v2, p1

    move-wide v3, p2

    move-wide v5, p4

    invoke-direct/range {v0 .. v6}, Lg0/J;-><init>(Lg0/b$a;IJJ)V

    const/16 p1, 0x3f3

    invoke-virtual {p0, v7, p1, v8}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final v(Ljava/util/List;Landroidx/media3/exoplayer/source/o$b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/media3/exoplayer/source/o$b;",
            ">;",
            "Landroidx/media3/exoplayer/source/o$b;",
            ")V"
        }
    .end annotation

    iget-object v0, p0, Lg0/a0;->g:Landroidx/media3/common/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v1, p1, p2, v0}, Lg0/a0$a;->k(Ljava/util/List;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/y;)V

    return-void
.end method

.method public final w(Lg0/b;)V
    .registers 3

    iget-object v0, p0, Lg0/a0;->f:La0/o;

    invoke-virtual {v0, p1}, La0/o;->g(Ljava/lang/Object;)V

    return-void
.end method

.method public final x(IJJ)V
    .registers 15

    iget-object v0, p0, Lg0/a0;->d:Lg0/a0$a;

    invoke-virtual {v0}, Lg0/a0$a;->e()Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    invoke-direct {p0, v0}, Lg0/a0;->Q(Landroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object v0

    new-instance v8, Lg0/G;

    move-object v1, v8

    move-object v2, v0

    move v3, p1

    move-wide v4, p2

    move-wide v6, p4

    invoke-direct/range {v1 .. v7}, Lg0/G;-><init>(Lg0/b$a;IJJ)V

    const/16 p1, 0x3ee

    invoke-virtual {p0, v0, p1, v8}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method

.method public final y()V
    .registers 4

    iget-boolean v0, p0, Lg0/a0;->i:Z

    if-nez v0, :cond_14

    invoke-virtual {p0}, Lg0/a0;->O()Lg0/b$a;

    move-result-object v0

    const/4 v1, 0x1

    iput-boolean v1, p0, Lg0/a0;->i:Z

    new-instance v1, Lg0/y;

    invoke-direct {v1, v0}, Lg0/y;-><init>(Ljava/lang/Object;)V

    const/4 v2, -0x1

    invoke-virtual {p0, v0, v2, v1}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    :cond_14
    return-void
.end method

.method public final z(ILandroidx/media3/exoplayer/source/o$b;Lq0/g;Lq0/h;Ljava/io/IOException;Z)V
    .registers 13

    invoke-direct {p0, p1, p2}, Lg0/a0;->R(ILandroidx/media3/exoplayer/source/o$b;)Lg0/b$a;

    move-result-object p1

    new-instance p2, Lg0/K;

    move-object v0, p2

    move-object v1, p1

    move-object v2, p3

    move-object v3, p4

    move-object v4, p5

    move v5, p6

    invoke-direct/range {v0 .. v5}, Lg0/K;-><init>(Lg0/b$a;Lq0/g;Lq0/h;Ljava/io/IOException;Z)V

    const/16 p3, 0x3eb

    invoke-virtual {p0, p1, p3, p2}, Lg0/a0;->T(Lg0/b$a;ILa0/o$a;)V

    return-void
.end method
