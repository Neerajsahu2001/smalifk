.class public final synthetic Lg0/h;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$b;
.implements Lzj/b;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/h;->a:Ljava/lang/Object;

    iput-object p2, p0, Lg0/h;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;Landroidx/media3/common/l;)V
    .registers 5

    iget-object v0, p0, Lg0/h;->a:Ljava/lang/Object;

    check-cast v0, Lg0/a0;

    iget-object v1, p0, Lg0/h;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/media3/common/y;

    check-cast p1, Lg0/b;

    invoke-static {v0, v1, p1, p2}, Lg0/a0;->M(Lg0/a0;Landroidx/media3/common/y;Lg0/b;Landroidx/media3/common/l;)V

    return-void
.end method

.method public final then(Lzj/k;)Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Lg0/h;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v1, p0, Lg0/h;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/Intent;

    invoke-static {v0, v1, p1}, Lcom/google/firebase/messaging/FcmBroadcastProcessor;->a(Landroid/content/Context;Landroid/content/Intent;Lzj/k;)Lzj/k;

    move-result-object p1

    return-object p1
.end method
