.class public final synthetic Lg0/q;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;


# instance fields
.field public final synthetic a:Lg0/b$a;

.field public final synthetic b:Z

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(ILg0/b$a;Z)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lg0/q;->a:Lg0/b$a;

    iput-boolean p3, p0, Lg0/q;->b:Z

    iput p1, p0, Lg0/q;->c:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 5

    check-cast p1, Lg0/b;

    iget-object v0, p0, Lg0/q;->a:Lg0/b$a;

    iget-boolean v1, p0, Lg0/q;->b:Z

    iget v2, p0, Lg0/q;->c:I

    invoke-interface {p1, v2, v0, v1}, Lg0/b;->D(ILg0/b$a;Z)V

    return-void
.end method
