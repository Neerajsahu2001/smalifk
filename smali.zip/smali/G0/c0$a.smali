.class final Lg0/c0$a;
.super Ljava/lang/Object;
.source "DefaultPlaybackSessionManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg0/c0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private b:I

.field private c:J

.field private d:Landroidx/media3/exoplayer/source/o$b;

.field private e:Z

.field private f:Z

.field final synthetic g:Lg0/c0;


# direct methods
.method public constructor <init>(Lg0/c0;Ljava/lang/String;ILandroidx/media3/exoplayer/source/o$b;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/c0$a;->g:Lg0/c0;

    iput-object p2, p0, Lg0/c0$a;->a:Ljava/lang/String;

    iput p3, p0, Lg0/c0$a;->b:I

    if-nez p4, :cond_e

    const-wide/16 p1, -0x1

    goto :goto_10

    :cond_e
    iget-wide p1, p4, Landroidx/media3/exoplayer/source/o$b;->d:J

    :goto_10
    iput-wide p1, p0, Lg0/c0$a;->c:J

    if-eqz p4, :cond_1c

    invoke-virtual {p4}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result p1

    if-eqz p1, :cond_1c

    iput-object p4, p0, Lg0/c0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    :cond_1c
    return-void
.end method

.method static synthetic a(Lg0/c0$a;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lg0/c0$a;->a:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic b(Lg0/c0$a;)J
    .registers 3

    iget-wide v0, p0, Lg0/c0$a;->c:J

    return-wide v0
.end method

.method static synthetic c(Lg0/c0$a;)I
    .registers 1

    iget p0, p0, Lg0/c0$a;->b:I

    return p0
.end method

.method static synthetic d(Lg0/c0$a;)Z
    .registers 1

    iget-boolean p0, p0, Lg0/c0$a;->e:Z

    return p0
.end method

.method static synthetic e(Lg0/c0$a;)V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg0/c0$a;->e:Z

    return-void
.end method

.method static synthetic f(Lg0/c0$a;)Z
    .registers 1

    iget-boolean p0, p0, Lg0/c0$a;->f:Z

    return p0
.end method

.method static synthetic g(Lg0/c0$a;)V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lg0/c0$a;->f:Z

    return-void
.end method

.method static synthetic h(Lg0/c0$a;)Landroidx/media3/exoplayer/source/o$b;
    .registers 1

    iget-object p0, p0, Lg0/c0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    return-object p0
.end method


# virtual methods
.method public final i(ILandroidx/media3/exoplayer/source/o$b;)Z
    .registers 10

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p2, :cond_a

    iget p2, p0, Lg0/c0$a;->b:I

    if-ne p1, p2, :cond_9

    const/4 v0, 0x1

    :cond_9
    return v0

    :cond_a
    iget-wide v2, p2, Landroidx/media3/exoplayer/source/o$b;->d:J

    iget-object p1, p0, Lg0/c0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-nez p1, :cond_1e

    invoke-virtual {p2}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result p1

    if-nez p1, :cond_1d

    iget-wide p1, p0, Lg0/c0$a;->c:J

    cmp-long v4, v2, p1

    if-nez v4, :cond_1d

    const/4 v0, 0x1

    :cond_1d
    return v0

    :cond_1e
    iget-wide v4, p1, Landroidx/media3/exoplayer/source/o$b;->d:J

    cmp-long v6, v2, v4

    if-nez v6, :cond_31

    iget v2, p2, Landroidx/media3/exoplayer/source/o$b;->b:I

    iget v3, p1, Landroidx/media3/exoplayer/source/o$b;->b:I

    if-ne v2, v3, :cond_31

    iget p2, p2, Landroidx/media3/exoplayer/source/o$b;->c:I

    iget p1, p1, Landroidx/media3/exoplayer/source/o$b;->c:I

    if-ne p2, p1, :cond_31

    const/4 v0, 0x1

    :cond_31
    return v0
.end method

.method public final j(Lg0/b$a;)Z
    .registers 12

    iget-object v0, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_f

    iget v0, p0, Lg0/c0$a;->b:I

    iget p1, p1, Lg0/b$a;->c:I

    if-eq v0, p1, :cond_d

    goto :goto_e

    :cond_d
    const/4 v1, 0x0

    :goto_e
    return v1

    :cond_f
    iget-wide v3, p0, Lg0/c0$a;->c:J

    const-wide/16 v5, -0x1

    cmp-long v7, v3, v5

    if-nez v7, :cond_18

    return v2

    :cond_18
    iget-wide v5, v0, Landroidx/media3/exoplayer/source/o$b;->d:J

    cmp-long v7, v5, v3

    if-lez v7, :cond_1f

    return v1

    :cond_1f
    iget-object v3, p0, Lg0/c0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-nez v3, :cond_24

    return v2

    :cond_24
    iget-object p1, p1, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget-object v4, v0, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    invoke-virtual {p1, v4}, Landroidx/media3/common/A;->b(Ljava/lang/Object;)I

    move-result v4

    iget-object v5, v3, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    invoke-virtual {p1, v5}, Landroidx/media3/common/A;->b(Ljava/lang/Object;)I

    move-result p1

    iget-wide v5, v0, Landroidx/media3/exoplayer/source/o$b;->d:J

    iget-wide v7, v3, Landroidx/media3/exoplayer/source/o$b;->d:J

    cmp-long v9, v5, v7

    if-ltz v9, :cond_61

    if-ge v4, p1, :cond_3d

    goto :goto_61

    :cond_3d
    if-le v4, p1, :cond_40

    return v1

    :cond_40
    invoke-virtual {v0}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result p1

    iget v4, v3, Landroidx/media3/exoplayer/source/o$b;->b:I

    if-eqz p1, :cond_57

    iget p1, v0, Landroidx/media3/exoplayer/source/o$b;->b:I

    if-gt p1, v4, :cond_56

    if-ne p1, v4, :cond_55

    iget p1, v3, Landroidx/media3/exoplayer/source/o$b;->c:I

    iget v0, v0, Landroidx/media3/exoplayer/source/o$b;->c:I

    if-le v0, p1, :cond_55

    goto :goto_56

    :cond_55
    const/4 v1, 0x0

    :cond_56
    :goto_56
    return v1

    :cond_57
    const/4 p1, -0x1

    iget v0, v0, Landroidx/media3/exoplayer/source/o$b;->e:I

    if-eq v0, p1, :cond_60

    if-le v0, v4, :cond_5f

    goto :goto_60

    :cond_5f
    const/4 v1, 0x0

    :cond_60
    :goto_60
    return v1

    :cond_61
    :goto_61
    return v2
.end method

.method public final k(ILandroidx/media3/exoplayer/source/o$b;)V
    .registers 8

    iget-wide v0, p0, Lg0/c0$a;->c:J

    const-wide/16 v2, -0x1

    cmp-long v4, v0, v2

    if-nez v4, :cond_1c

    iget v0, p0, Lg0/c0$a;->b:I

    if-ne p1, v0, :cond_1c

    if-eqz p2, :cond_1c

    iget-object p1, p0, Lg0/c0$a;->g:Lg0/c0;

    invoke-static {p1}, Lg0/c0;->b(Lg0/c0;)J

    move-result-wide v0

    iget-wide p1, p2, Landroidx/media3/exoplayer/source/o$b;->d:J

    cmp-long v2, p1, v0

    if-ltz v2, :cond_1c

    iput-wide p1, p0, Lg0/c0$a;->c:J

    :cond_1c
    return-void
.end method

.method public final l(Landroidx/media3/common/A;Landroidx/media3/common/A;)Z
    .registers 8

    iget v0, p0, Lg0/c0$a;->b:I

    invoke-virtual {p1}, Landroidx/media3/common/A;->p()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, -0x1

    if-lt v0, v1, :cond_11

    invoke-virtual {p2}, Landroidx/media3/common/A;->p()I

    move-result p1

    if-ge v0, p1, :cond_40

    goto :goto_41

    :cond_11
    iget-object v1, p0, Lg0/c0$a;->g:Lg0/c0;

    invoke-static {v1}, Lg0/c0;->c(Lg0/c0;)Landroidx/media3/common/A$c;

    move-result-object v4

    invoke-virtual {p1, v0, v4}, Landroidx/media3/common/A;->o(ILandroidx/media3/common/A$c;)V

    invoke-static {v1}, Lg0/c0;->c(Lg0/c0;)Landroidx/media3/common/A$c;

    move-result-object v0

    iget v0, v0, Landroidx/media3/common/A$c;->n:I

    :goto_20
    invoke-static {v1}, Lg0/c0;->c(Lg0/c0;)Landroidx/media3/common/A$c;

    move-result-object v4

    iget v4, v4, Landroidx/media3/common/A$c;->o:I

    if-gt v0, v4, :cond_40

    invoke-virtual {p1, v0}, Landroidx/media3/common/A;->m(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {p2, v4}, Landroidx/media3/common/A;->b(Ljava/lang/Object;)I

    move-result v4

    if-eq v4, v3, :cond_3d

    invoke-static {v1}, Lg0/c0;->d(Lg0/c0;)Landroidx/media3/common/A$b;

    move-result-object p1

    invoke-virtual {p2, v4, p1, v2}, Landroidx/media3/common/A;->g(ILandroidx/media3/common/A$b;Z)Landroidx/media3/common/A$b;

    move-result-object p1

    iget v0, p1, Landroidx/media3/common/A$b;->c:I

    goto :goto_41

    :cond_3d
    add-int/lit8 v0, v0, 0x1

    goto :goto_20

    :cond_40
    const/4 v0, -0x1

    :goto_41
    iput v0, p0, Lg0/c0$a;->b:I

    if-ne v0, v3, :cond_46

    return v2

    :cond_46
    iget-object p1, p0, Lg0/c0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    const/4 v0, 0x1

    if-nez p1, :cond_4c

    return v0

    :cond_4c
    iget-object p1, p1, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    invoke-virtual {p2, p1}, Landroidx/media3/common/A;->b(Ljava/lang/Object;)I

    move-result p1

    if-eq p1, v3, :cond_55

    const/4 v2, 0x1

    :cond_55
    return v2
.end method
