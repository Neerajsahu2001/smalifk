.class public final synthetic Lg0/t;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;


# instance fields
.field public final synthetic a:Lg0/b$a;

.field public final synthetic b:Landroidx/media3/exoplayer/k;


# direct methods
.method public synthetic constructor <init>(Lg0/b$a;Landroidx/media3/exoplayer/k;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/t;->a:Lg0/b$a;

    iput-object p2, p0, Lg0/t;->b:Landroidx/media3/exoplayer/k;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Lg0/b;

    iget-object v0, p0, Lg0/t;->a:Lg0/b$a;

    iget-object v1, p0, Lg0/t;->b:Landroidx/media3/exoplayer/k;

    invoke-interface {p1, v0, v1}, Lg0/b;->O(Lg0/b$a;Landroidx/media3/exoplayer/k;)V

    return-void
.end method
