.class public final synthetic Lg0/w;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;
.implements LLi/b$a;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/w;->a:Ljava/lang/Object;

    iput-object p2, p0, Lg0/w;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final execute()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lg0/w;->a:Ljava/lang/Object;

    check-cast v0, LJi/k;

    iget-object v1, p0, Lg0/w;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v0, v1}, LJi/k;->e(LJi/k;Ljava/lang/Iterable;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lg0/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method
