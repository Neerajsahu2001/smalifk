.class public final synthetic Lg0/o;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;


# instance fields
.field public final synthetic a:Lg0/b$a;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(IJLg0/b$a;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p4, p0, Lg0/o;->a:Lg0/b$a;

    iput p1, p0, Lg0/o;->b:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Lg0/b;

    iget v0, p0, Lg0/o;->b:I

    iget-object v1, p0, Lg0/o;->a:Lg0/b$a;

    invoke-interface {p1, v0, v1}, Lg0/b;->T(ILg0/b$a;)V

    return-void
.end method
