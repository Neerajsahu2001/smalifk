.class public final Lg0/b$a;
.super Ljava/lang/Object;
.source "AnalyticsListener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg0/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:J

.field public final b:Landroidx/media3/common/A;

.field public final c:I

.field public final d:Landroidx/media3/exoplayer/source/o$b;

.field public final e:J

.field public final f:Landroidx/media3/common/A;

.field public final g:I

.field public final h:Landroidx/media3/exoplayer/source/o$b;

.field public final i:J

.field public final j:J


# direct methods
.method public constructor <init>(JLandroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;JLandroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;JJ)V
    .registers 15

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lg0/b$a;->a:J

    iput-object p3, p0, Lg0/b$a;->b:Landroidx/media3/common/A;

    iput p4, p0, Lg0/b$a;->c:I

    iput-object p5, p0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iput-wide p6, p0, Lg0/b$a;->e:J

    iput-object p8, p0, Lg0/b$a;->f:Landroidx/media3/common/A;

    iput p9, p0, Lg0/b$a;->g:I

    iput-object p10, p0, Lg0/b$a;->h:Landroidx/media3/exoplayer/source/o$b;

    iput-wide p11, p0, Lg0/b$a;->i:J

    iput-wide p13, p0, Lg0/b$a;->j:J

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    const/4 v1, 0x0

    if-eqz p1, :cond_69

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const-class v3, Lg0/b$a;

    if-eq v3, v2, :cond_10

    goto :goto_69

    :cond_10
    check-cast p1, Lg0/b$a;

    iget-wide v2, p0, Lg0/b$a;->a:J

    iget-wide v4, p1, Lg0/b$a;->a:J

    cmp-long v6, v2, v4

    if-nez v6, :cond_67

    iget v2, p0, Lg0/b$a;->c:I

    iget v3, p1, Lg0/b$a;->c:I

    if-ne v2, v3, :cond_67

    iget-wide v2, p0, Lg0/b$a;->e:J

    iget-wide v4, p1, Lg0/b$a;->e:J

    cmp-long v6, v2, v4

    if-nez v6, :cond_67

    iget v2, p0, Lg0/b$a;->g:I

    iget v3, p1, Lg0/b$a;->g:I

    if-ne v2, v3, :cond_67

    iget-wide v2, p0, Lg0/b$a;->i:J

    iget-wide v4, p1, Lg0/b$a;->i:J

    cmp-long v6, v2, v4

    if-nez v6, :cond_67

    iget-wide v2, p0, Lg0/b$a;->j:J

    iget-wide v4, p1, Lg0/b$a;->j:J

    cmp-long v6, v2, v4

    if-nez v6, :cond_67

    iget-object v2, p0, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget-object v3, p1, Lg0/b$a;->b:Landroidx/media3/common/A;

    invoke-static {v2, v3}, Lcom/facebook/yoga/f;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_67

    iget-object v2, p0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iget-object v3, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-static {v2, v3}, Lcom/facebook/yoga/f;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_67

    iget-object v2, p0, Lg0/b$a;->f:Landroidx/media3/common/A;

    iget-object v3, p1, Lg0/b$a;->f:Landroidx/media3/common/A;

    invoke-static {v2, v3}, Lcom/facebook/yoga/f;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_67

    iget-object v2, p0, Lg0/b$a;->h:Landroidx/media3/exoplayer/source/o$b;

    iget-object p1, p1, Lg0/b$a;->h:Landroidx/media3/exoplayer/source/o$b;

    invoke-static {v2, p1}, Lcom/facebook/yoga/f;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_67

    goto :goto_68

    :cond_67
    const/4 v0, 0x0

    :goto_68
    return v0

    :cond_69
    :goto_69
    return v1
.end method

.method public final hashCode()I
    .registers 13

    iget-wide v0, p0, Lg0/b$a;->a:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iget v1, p0, Lg0/b$a;->c:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-wide v2, p0, Lg0/b$a;->e:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    iget v3, p0, Lg0/b$a;->g:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-wide v4, p0, Lg0/b$a;->i:J

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    iget-wide v5, p0, Lg0/b$a;->j:J

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    iget-object v6, p0, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget-object v7, p0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iget-object v8, p0, Lg0/b$a;->f:Landroidx/media3/common/A;

    iget-object v9, p0, Lg0/b$a;->h:Landroidx/media3/exoplayer/source/o$b;

    const/16 v10, 0xa

    new-array v10, v10, [Ljava/lang/Object;

    const/4 v11, 0x0

    aput-object v0, v10, v11

    const/4 v0, 0x1

    aput-object v6, v10, v0

    const/4 v0, 0x2

    aput-object v1, v10, v0

    const/4 v0, 0x3

    aput-object v7, v10, v0

    const/4 v0, 0x4

    aput-object v2, v10, v0

    const/4 v0, 0x5

    aput-object v8, v10, v0

    const/4 v0, 0x6

    aput-object v3, v10, v0

    const/4 v0, 0x7

    aput-object v9, v10, v0

    const/16 v0, 0x8

    aput-object v4, v10, v0

    const/16 v0, 0x9

    aput-object v5, v10, v0

    invoke-static {v10}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    return v0
.end method
