.class public final synthetic Lg0/y;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;
.implements Lb5/c$a;


# instance fields
.field public final synthetic a:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/y;->a:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lg0/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final locationEnableStatusCallback(Z)V
    .registers 3

    iget-object v0, p0, Lg0/y;->a:Ljava/lang/Object;

    check-cast v0, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;

    invoke-static {v0, p1}, Lcom/flipkart/android/activity/HomeFragmentHolderActivity;->t(Lcom/flipkart/android/activity/HomeFragmentHolderActivity;Z)V

    return-void
.end method
