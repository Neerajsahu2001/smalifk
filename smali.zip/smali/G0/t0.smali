.class public interface abstract Lg0/t0;
.super Ljava/lang/Object;
.source "PlaybackSessionManager.java"


# virtual methods
.method public abstract N(Lg0/b$a;Ljava/lang/String;)V
.end method

.method public abstract f(Ljava/lang/String;)V
.end method

.method public abstract l(Lg0/b$a;Ljava/lang/String;)V
.end method

.method public abstract v(Lg0/b$a;Ljava/lang/String;Z)V
.end method
