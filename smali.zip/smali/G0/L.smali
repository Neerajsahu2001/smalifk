.class public final synthetic Lg0/l;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;


# instance fields
.field public final synthetic a:Lg0/b$a;

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lg0/b$a;Ljava/lang/String;JJ)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/l;->a:Lg0/b$a;

    iput-object p2, p0, Lg0/l;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Lg0/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lg0/l;->a:Lg0/b$a;

    iget-object v1, p0, Lg0/l;->b:Ljava/lang/String;

    invoke-interface {p1, v0, v1}, Lg0/b;->b(Lg0/b$a;Ljava/lang/String;)V

    return-void
.end method
