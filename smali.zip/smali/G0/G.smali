.class public final synthetic Lg0/g;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;
.implements Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$g$a;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/io/Serializable;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/io/Serializable;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/g;->a:Ljava/lang/Object;

    iput-object p2, p0, Lg0/g;->b:Ljava/io/Serializable;

    return-void
.end method


# virtual methods
.method public final a(ILandroidx/media3/common/B;[I)Ljava/util/List;
    .registers 6

    iget-object v0, p0, Lg0/g;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;

    iget-object v1, p0, Lg0/g;->b:Ljava/io/Serializable;

    check-cast v1, Ljava/lang/String;

    invoke-static {p1, p2, v0, v1, p3}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->m(ILandroidx/media3/common/B;Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;Ljava/lang/String;[I)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lg0/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method
