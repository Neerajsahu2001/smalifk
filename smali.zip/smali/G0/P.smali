.class public final synthetic Lg0/p;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;
.implements Lcom/facebook/react/touch/OnInterceptTouchEventListener;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/p;->a:Ljava/lang/Object;

    iput-object p2, p0, Lg0/p;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lg0/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final onInterceptTouchEvent(Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Z
    .registers 5

    iget-object v0, p0, Lg0/p;->a:Ljava/lang/Object;

    check-cast v0, Lcom/flipkart/android/reactnative/nativeuimodules/ViewWrapper;

    iget-object v1, p0, Lg0/p;->b:Ljava/lang/Object;

    check-cast v1, Lcom/flipkart/android/guidednavigation/j;

    invoke-static {v0, v1, p1, p2}, Lcom/flipkart/android/reactnative/nativeuimodules/ViewWrapperManager;->a(Lcom/flipkart/android/reactnative/nativeuimodules/ViewWrapper;Lcom/flipkart/android/guidednavigation/j;Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method
