.class public final synthetic Lg0/i;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;
.implements Lcom/flipkart/android/newmultiwidget/ui/widgets/vernacular/e;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/i;->a:Ljava/lang/Object;

    iput-object p2, p0, Lg0/i;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Lg0/i;->a:Ljava/lang/Object;

    check-cast v0, Lg0/b$a;

    iget-object v1, p0, Lg0/i;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/media3/common/Metadata;

    check-cast p1, Lg0/b;

    invoke-interface {p1, v0, v1}, Lg0/b;->S(Lg0/b$a;Landroidx/media3/common/Metadata;)V

    return-void
.end method

.method public final onLanguageSelected(I)V
    .registers 4

    iget-object v0, p0, Lg0/i;->a:Ljava/lang/Object;

    check-cast v0, Lcom/flipkart/android/newmultiwidget/ui/widgets/vernacular/x;

    iget-object v1, p0, Lg0/i;->b:Ljava/lang/Object;

    check-cast v1, LZh/t;

    invoke-static {v0, v1, p1}, Lcom/flipkart/android/newmultiwidget/ui/widgets/vernacular/x;->i(Lcom/flipkart/android/newmultiwidget/ui/widgets/vernacular/x;LZh/t;I)V

    return-void
.end method
