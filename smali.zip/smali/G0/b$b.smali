.class public final Lg0/b$b;
.super Ljava/lang/Object;
.source "AnalyticsListener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg0/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private final a:Landroidx/media3/common/l;

.field private final b:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lg0/b$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/media3/common/l;Landroid/util/SparseArray;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/media3/common/l;",
            "Landroid/util/SparseArray<",
            "Lg0/b$a;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/b$b;->a:Landroidx/media3/common/l;

    new-instance v0, Landroid/util/SparseArray;

    invoke-virtual {p1}, Landroidx/media3/common/l;->d()I

    move-result v1

    invoke-direct {v0, v1}, Landroid/util/SparseArray;-><init>(I)V

    const/4 v1, 0x0

    :goto_f
    invoke-virtual {p1}, Landroidx/media3/common/l;->d()I

    move-result v2

    if-ge v1, v2, :cond_28

    invoke-virtual {p1, v1}, Landroidx/media3/common/l;->c(I)I

    move-result v2

    invoke-virtual {p2, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lg0/b$a;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_28
    iput-object v0, p0, Lg0/b$b;->b:Landroid/util/SparseArray;

    return-void
.end method


# virtual methods
.method public final a(I)Z
    .registers 3

    iget-object v0, p0, Lg0/b$b;->a:Landroidx/media3/common/l;

    invoke-virtual {v0, p1}, Landroidx/media3/common/l;->a(I)Z

    move-result p1

    return p1
.end method

.method public final b(I)I
    .registers 3

    iget-object v0, p0, Lg0/b$b;->a:Landroidx/media3/common/l;

    invoke-virtual {v0, p1}, Landroidx/media3/common/l;->c(I)I

    move-result p1

    return p1
.end method

.method public final c(I)Lg0/b$a;
    .registers 3

    iget-object v0, p0, Lg0/b$b;->b:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lg0/b$a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p1
.end method

.method public final d()I
    .registers 2

    iget-object v0, p0, Lg0/b$b;->a:Landroidx/media3/common/l;

    invoke-virtual {v0}, Landroidx/media3/common/l;->d()I

    move-result v0

    return v0
.end method
