.class public interface abstract Lg0/a;
.super Ljava/lang/Object;
.source "AnalyticsCollector.java"

# interfaces
.implements Landroidx/media3/common/y$c;
.implements Landroidx/media3/exoplayer/source/p;
.implements Landroidx/media3/exoplayer/upstream/b$a;
.implements Lk0/n;


# virtual methods
.method public abstract I(Lg0/b;)V
.end method

.method public abstract K(Landroidx/media3/common/y;Landroid/os/Looper;)V
.end method

.method public abstract a(Ljava/lang/String;)V
.end method

.method public abstract b(Landroidx/media3/exoplayer/audio/h$a;)V
.end method

.method public abstract c(Ljava/lang/String;)V
.end method

.method public abstract d(Landroidx/media3/exoplayer/audio/h$a;)V
.end method

.method public abstract e(Landroidx/media3/exoplayer/k;)V
.end method

.method public abstract f(Landroidx/media3/exoplayer/k;)V
.end method

.method public abstract h(Ljava/lang/Exception;)V
.end method

.method public abstract i(J)V
.end method

.method public abstract j(Landroidx/media3/common/m;Landroidx/media3/exoplayer/l;)V
.end method

.method public abstract k(Ljava/lang/Exception;)V
.end method

.method public abstract l(JLjava/lang/Object;)V
.end method

.method public abstract m(Landroidx/media3/exoplayer/k;)V
.end method

.method public abstract n(JJLjava/lang/String;)V
.end method

.method public abstract o(IJ)V
.end method

.method public abstract p(IJ)V
.end method

.method public abstract q(Landroidx/media3/common/m;Landroidx/media3/exoplayer/l;)V
.end method

.method public abstract r(Landroidx/media3/exoplayer/k;)V
.end method

.method public abstract release()V
.end method

.method public abstract s(Ljava/lang/Exception;)V
.end method

.method public abstract t(JJLjava/lang/String;)V
.end method

.method public abstract u(IJJ)V
.end method

.method public abstract v(Ljava/util/List;Landroidx/media3/exoplayer/source/o$b;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/media3/exoplayer/source/o$b;",
            ">;",
            "Landroidx/media3/exoplayer/source/o$b;",
            ")V"
        }
    .end annotation
.end method

.method public abstract w(Lg0/b;)V
.end method

.method public abstract y()V
.end method
