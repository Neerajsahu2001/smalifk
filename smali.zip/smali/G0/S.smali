.class public final synthetic Lg0/s;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;
.implements Lcom/facebook/react/touch/OnInterceptTouchEventListener;
.implements LLi/b$a;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/s;->a:Ljava/lang/Object;

    iput-object p2, p0, Lg0/s;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final execute()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lg0/s;->a:Ljava/lang/Object;

    check-cast v0, LJi/k;

    iget-object v1, p0, Lg0/s;->b:Ljava/lang/Object;

    check-cast v1, LDi/o;

    invoke-static {v0, v1}, LJi/k;->d(LJi/k;LDi/o;)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Lg0/s;->a:Ljava/lang/Object;

    check-cast v0, Lg0/b$a;

    iget-object v1, p0, Lg0/s;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/media3/common/w;

    check-cast p1, Lg0/b;

    invoke-interface {p1, v0, v1}, Lg0/b;->q(Lg0/b$a;Landroidx/media3/common/w;)V

    return-void
.end method

.method public final onInterceptTouchEvent(Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Z
    .registers 5

    iget-object v0, p0, Lg0/s;->a:Ljava/lang/Object;

    check-cast v0, Lcom/flipkart/android/reactnative/nativeuimodules/viewability/TrackerView;

    iget-object v1, p0, Lg0/s;->b:Ljava/lang/Object;

    check-cast v1, Lcom/flipkart/android/guidednavigation/j;

    invoke-static {v0, v1, p1, p2}, Lcom/flipkart/android/reactnative/nativeuimodules/viewability/TrackerViewManager;->a(Lcom/flipkart/android/reactnative/nativeuimodules/viewability/TrackerView;Lcom/flipkart/android/guidednavigation/j;Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method
