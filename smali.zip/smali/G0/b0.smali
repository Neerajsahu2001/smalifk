.class public final synthetic Lg0/b0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lfk/n;


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 2

    invoke-static {}, Lg0/c0;->a()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
