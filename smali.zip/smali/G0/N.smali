.class public final synthetic Lg0/n;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lg0/b$a;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lg0/b$a;Ljava/lang/Object;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p3, p0, Lg0/n;->a:I

    iput-object p1, p0, Lg0/n;->b:Lg0/b$a;

    iput-object p2, p0, Lg0/n;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 5

    iget v0, p0, Lg0/n;->a:I

    iget-object v1, p0, Lg0/n;->b:Lg0/b$a;

    iget-object v2, p0, Lg0/n;->c:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_1a

    check-cast v2, Lq0/h;

    check-cast p1, Lg0/b;

    invoke-interface {p1, v1, v2}, Lg0/b;->x(Lg0/b$a;Lq0/h;)V

    return-void

    :pswitch_11
    check-cast v2, Ljava/lang/String;

    check-cast p1, Lg0/b;

    invoke-interface {p1, v1, v2}, Lg0/b;->k(Lg0/b$a;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method
