.class public final synthetic Lg0/e;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;


# instance fields
.field public final synthetic a:Lg0/b$a;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lg0/b$a;Landroidx/media3/common/q;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/e;->a:Lg0/b$a;

    iput p3, p0, Lg0/e;->b:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Lg0/b;

    iget-object v0, p0, Lg0/e;->a:Lg0/b$a;

    iget v1, p0, Lg0/e;->b:I

    invoke-interface {p1, v0, v1}, Lg0/b;->J(Lg0/b$a;I)V

    return-void
.end method
