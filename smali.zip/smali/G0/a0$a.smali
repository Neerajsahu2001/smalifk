.class final Lg0/a0$a;
.super Ljava/lang/Object;
.source "DefaultAnalyticsCollector.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg0/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/media3/common/A$b;

.field private b:Lgk/w;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lgk/w<",
            "Landroidx/media3/exoplayer/source/o$b;",
            ">;"
        }
    .end annotation
.end field

.field private c:Lgk/x;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lgk/x<",
            "Landroidx/media3/exoplayer/source/o$b;",
            "Landroidx/media3/common/A;",
            ">;"
        }
    .end annotation
.end field

.field private d:Landroidx/media3/exoplayer/source/o$b;

.field private e:Landroidx/media3/exoplayer/source/o$b;

.field private f:Landroidx/media3/exoplayer/source/o$b;


# direct methods
.method public constructor <init>(Landroidx/media3/common/A$b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/a0$a;->a:Landroidx/media3/common/A$b;

    invoke-static {}, Lgk/w;->v()Lgk/w;

    move-result-object p1

    iput-object p1, p0, Lg0/a0$a;->b:Lgk/w;

    invoke-static {}, Lgk/x;->j()Lgk/x;

    move-result-object p1

    iput-object p1, p0, Lg0/a0$a;->c:Lgk/x;

    return-void
.end method

.method static synthetic a(Lg0/a0$a;)Lgk/w;
    .registers 1

    iget-object p0, p0, Lg0/a0$a;->b:Lgk/w;

    return-object p0
.end method

.method private b(Lgk/x$a;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgk/x$a<",
            "Landroidx/media3/exoplayer/source/o$b;",
            "Landroidx/media3/common/A;",
            ">;",
            "Landroidx/media3/exoplayer/source/o$b;",
            "Landroidx/media3/common/A;",
            ")V"
        }
    .end annotation

    if-nez p2, :cond_3

    return-void

    :cond_3
    iget-object v0, p2, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    invoke-virtual {p3, v0}, Landroidx/media3/common/A;->b(Ljava/lang/Object;)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_10

    invoke-virtual {p1, p2, p3}, Lgk/x$a;->b(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1d

    :cond_10
    iget-object p3, p0, Lg0/a0$a;->c:Lgk/x;

    invoke-virtual {p3, p2}, Lgk/x;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroidx/media3/common/A;

    if-eqz p3, :cond_1d

    invoke-virtual {p1, p2, p3}, Lgk/x$a;->b(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_1d
    :goto_1d
    return-void
.end method

.method private static c(Landroidx/media3/common/y;Lgk/w;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A$b;)Landroidx/media3/exoplayer/source/o$b;
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/media3/common/y;",
            "Lgk/w<",
            "Landroidx/media3/exoplayer/source/o$b;",
            ">;",
            "Landroidx/media3/exoplayer/source/o$b;",
            "Landroidx/media3/common/A$b;",
            ")",
            "Landroidx/media3/exoplayer/source/o$b;"
        }
    .end annotation

    invoke-interface {p0}, Landroidx/media3/common/y;->v()Landroidx/media3/common/A;

    move-result-object v0

    invoke-interface {p0}, Landroidx/media3/common/y;->F()I

    move-result v1

    invoke-virtual {v0}, Landroidx/media3/common/A;->q()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_11

    move-object v2, v3

    goto :goto_15

    :cond_11
    invoke-virtual {v0, v1}, Landroidx/media3/common/A;->m(I)Ljava/lang/Object;

    move-result-object v2

    :goto_15
    invoke-interface {p0}, Landroidx/media3/common/y;->e()Z

    move-result v4

    if-nez v4, :cond_38

    invoke-virtual {v0}, Landroidx/media3/common/A;->q()Z

    move-result v4

    if-eqz v4, :cond_22

    goto :goto_38

    :cond_22
    invoke-virtual {v0, v1, p3}, Landroidx/media3/common/A;->f(ILandroidx/media3/common/A$b;)Landroidx/media3/common/A$b;

    move-result-object v0

    invoke-interface {p0}, Landroidx/media3/common/y;->getCurrentPosition()J

    move-result-wide v4

    invoke-static {v4, v5}, La0/T;->T(J)J

    move-result-wide v4

    invoke-virtual {p3}, Landroidx/media3/common/A$b;->l()J

    move-result-wide v6

    sub-long/2addr v4, v6

    invoke-virtual {v0, v4, v5}, Landroidx/media3/common/A$b;->d(J)I

    move-result p3

    goto :goto_39

    :cond_38
    :goto_38
    const/4 p3, -0x1

    :goto_39
    const/4 v0, 0x0

    :goto_3a
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    if-ge v0, v1, :cond_5f

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/media3/exoplayer/source/o$b;

    invoke-interface {p0}, Landroidx/media3/common/y;->e()Z

    move-result v6

    invoke-interface {p0}, Landroidx/media3/common/y;->p()I

    move-result v7

    invoke-interface {p0}, Landroidx/media3/common/y;->I()I

    move-result v8

    move-object v4, v1

    move-object v5, v2

    move v9, p3

    invoke-static/range {v4 .. v9}, Lg0/a0$a;->i(Landroidx/media3/exoplayer/source/o$b;Ljava/lang/Object;ZIII)Z

    move-result v4

    if-eqz v4, :cond_5c

    return-object v1

    :cond_5c
    add-int/lit8 v0, v0, 0x1

    goto :goto_3a

    :cond_5f
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_7d

    if-eqz p2, :cond_7d

    invoke-interface {p0}, Landroidx/media3/common/y;->e()Z

    move-result v6

    invoke-interface {p0}, Landroidx/media3/common/y;->p()I

    move-result v7

    invoke-interface {p0}, Landroidx/media3/common/y;->I()I

    move-result v8

    move-object v4, p2

    move-object v5, v2

    move v9, p3

    invoke-static/range {v4 .. v9}, Lg0/a0$a;->i(Landroidx/media3/exoplayer/source/o$b;Ljava/lang/Object;ZIII)Z

    move-result p0

    if-eqz p0, :cond_7d

    return-object p2

    :cond_7d
    return-object v3
.end method

.method private static i(Landroidx/media3/exoplayer/source/o$b;Ljava/lang/Object;ZIII)Z
    .registers 7

    iget-object v0, p0, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v0, 0x0

    if-nez p1, :cond_a

    return v0

    :cond_a
    iget p1, p0, Landroidx/media3/exoplayer/source/o$b;->b:I

    if-eqz p2, :cond_14

    if-ne p1, p3, :cond_14

    iget p3, p0, Landroidx/media3/exoplayer/source/o$b;->c:I

    if-eq p3, p4, :cond_1d

    :cond_14
    if-nez p2, :cond_1e

    const/4 p2, -0x1

    if-ne p1, p2, :cond_1e

    iget p0, p0, Landroidx/media3/exoplayer/source/o$b;->e:I

    if-ne p0, p5, :cond_1e

    :cond_1d
    const/4 v0, 0x1

    :cond_1e
    return v0
.end method

.method private m(Landroidx/media3/common/A;)V
    .registers 5

    invoke-static {}, Lgk/x;->a()Lgk/x$a;

    move-result-object v0

    iget-object v1, p0, Lg0/a0$a;->b:Lgk/w;

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_3a

    iget-object v1, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {p0, v0, v1, p1}, Lg0/a0$a;->b(Lgk/x$a;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A;)V

    iget-object v1, p0, Lg0/a0$a;->f:Landroidx/media3/exoplayer/source/o$b;

    iget-object v2, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    invoke-static {v1, v2}, Lcom/facebook/yoga/f;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20

    iget-object v1, p0, Lg0/a0$a;->f:Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {p0, v0, v1, p1}, Lg0/a0$a;->b(Lgk/x$a;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A;)V

    :cond_20
    iget-object v1, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iget-object v2, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    invoke-static {v1, v2}, Lcom/facebook/yoga/f;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    iget-object v1, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iget-object v2, p0, Lg0/a0$a;->f:Landroidx/media3/exoplayer/source/o$b;

    invoke-static {v1, v2}, Lcom/facebook/yoga/f;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    iget-object v1, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {p0, v0, v1, p1}, Lg0/a0$a;->b(Lgk/x$a;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A;)V

    goto :goto_60

    :cond_3a
    const/4 v1, 0x0

    :goto_3b
    iget-object v2, p0, Lg0/a0$a;->b:Lgk/w;

    invoke-virtual {v2}, Ljava/util/AbstractCollection;->size()I

    move-result v2

    if-ge v1, v2, :cond_51

    iget-object v2, p0, Lg0/a0$a;->b:Lgk/w;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {p0, v0, v2, p1}, Lg0/a0$a;->b(Lgk/x$a;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_3b

    :cond_51
    iget-object v1, p0, Lg0/a0$a;->b:Lgk/w;

    iget-object v2, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-virtual {v1, v2}, Lgk/w;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    iget-object v1, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {p0, v0, v1, p1}, Lg0/a0$a;->b(Lgk/x$a;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A;)V

    :cond_60
    :goto_60
    invoke-virtual {v0}, Lgk/x$a;->a()Lgk/x;

    move-result-object p1

    iput-object p1, p0, Lg0/a0$a;->c:Lgk/x;

    return-void
.end method


# virtual methods
.method public final d()Landroidx/media3/exoplayer/source/o$b;
    .registers 2

    iget-object v0, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    return-object v0
.end method

.method public final e()Landroidx/media3/exoplayer/source/o$b;
    .registers 2

    iget-object v0, p0, Lg0/a0$a;->b:Lgk/w;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 v0, 0x0

    goto :goto_12

    :cond_a
    iget-object v0, p0, Lg0/a0$a;->b:Lgk/w;

    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/e3;->l(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/media3/exoplayer/source/o$b;

    :goto_12
    return-object v0
.end method

.method public final f(Landroidx/media3/exoplayer/source/o$b;)Landroidx/media3/common/A;
    .registers 3

    iget-object v0, p0, Lg0/a0$a;->c:Lgk/x;

    invoke-virtual {v0, p1}, Lgk/x;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/media3/common/A;

    return-object p1
.end method

.method public final g()Landroidx/media3/exoplayer/source/o$b;
    .registers 2

    iget-object v0, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    return-object v0
.end method

.method public final h()Landroidx/media3/exoplayer/source/o$b;
    .registers 2

    iget-object v0, p0, Lg0/a0$a;->f:Landroidx/media3/exoplayer/source/o$b;

    return-object v0
.end method

.method public final j(Landroidx/media3/common/y;)V
    .registers 5

    iget-object v0, p0, Lg0/a0$a;->b:Lgk/w;

    iget-object v1, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    iget-object v2, p0, Lg0/a0$a;->a:Landroidx/media3/common/A$b;

    invoke-static {p1, v0, v1, v2}, Lg0/a0$a;->c(Landroidx/media3/common/y;Lgk/w;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A$b;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object p1

    iput-object p1, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    return-void
.end method

.method public final k(Ljava/util/List;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/y;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/media3/exoplayer/source/o$b;",
            ">;",
            "Landroidx/media3/exoplayer/source/o$b;",
            "Landroidx/media3/common/y;",
            ")V"
        }
    .end annotation

    invoke-static {p1}, Lgk/w;->s(Ljava/util/Collection;)Lgk/w;

    move-result-object v0

    iput-object v0, p0, Lg0/a0$a;->b:Lgk/w;

    move-object v0, p1

    check-cast v0, Ljava/util/AbstractCollection;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1d

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/media3/exoplayer/source/o$b;

    iput-object p1, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p0, Lg0/a0$a;->f:Landroidx/media3/exoplayer/source/o$b;

    :cond_1d
    iget-object p1, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-nez p1, :cond_2d

    iget-object p1, p0, Lg0/a0$a;->b:Lgk/w;

    iget-object p2, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    iget-object v0, p0, Lg0/a0$a;->a:Landroidx/media3/common/A$b;

    invoke-static {p3, p1, p2, v0}, Lg0/a0$a;->c(Landroidx/media3/common/y;Lgk/w;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A$b;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object p1

    iput-object p1, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    :cond_2d
    invoke-interface {p3}, Landroidx/media3/common/y;->v()Landroidx/media3/common/A;

    move-result-object p1

    invoke-direct {p0, p1}, Lg0/a0$a;->m(Landroidx/media3/common/A;)V

    return-void
.end method

.method public final l(Landroidx/media3/common/y;)V
    .registers 5

    iget-object v0, p0, Lg0/a0$a;->b:Lgk/w;

    iget-object v1, p0, Lg0/a0$a;->e:Landroidx/media3/exoplayer/source/o$b;

    iget-object v2, p0, Lg0/a0$a;->a:Landroidx/media3/common/A$b;

    invoke-static {p1, v0, v1, v2}, Lg0/a0$a;->c(Landroidx/media3/common/y;Lgk/w;Landroidx/media3/exoplayer/source/o$b;Landroidx/media3/common/A$b;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object v0

    iput-object v0, p0, Lg0/a0$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-interface {p1}, Landroidx/media3/common/y;->v()Landroidx/media3/common/A;

    move-result-object p1

    invoke-direct {p0, p1}, Lg0/a0$a;->m(Landroidx/media3/common/A;)V

    return-void
.end method
