.class public final Lg0/s0;
.super Ljava/lang/Object;
.source "MediaMetricsListener.java"

# interfaces
.implements Lg0/b;
.implements Lg0/t0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lg0/s0$b;,
        Lg0/s0$a;
    }
.end annotation


# instance fields
.field private A:Z

.field private final a:Landroid/content/Context;

.field private final b:Lg0/c0;

.field private final c:Landroid/media/metrics/PlaybackSession;

.field private final d:J

.field private final e:Landroidx/media3/common/A$c;

.field private final f:Landroidx/media3/common/A$b;

.field private final g:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private final h:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private i:Ljava/lang/String;

.field private j:Landroid/media/metrics/PlaybackMetrics$Builder;

.field private k:I

.field private l:I

.field private m:I

.field private n:Landroidx/media3/common/w;

.field private o:Lg0/s0$b;

.field private p:Lg0/s0$b;

.field private q:Lg0/s0$b;

.field private r:Landroidx/media3/common/m;

.field private s:Landroidx/media3/common/m;

.field private t:Landroidx/media3/common/m;

.field private u:Z

.field private v:I

.field private w:Z

.field private x:I

.field private y:I

.field private z:I


# direct methods
.method private constructor <init>(Landroid/content/Context;Landroid/media/metrics/PlaybackSession;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lg0/s0;->a:Landroid/content/Context;

    iput-object p2, p0, Lg0/s0;->c:Landroid/media/metrics/PlaybackSession;

    new-instance p1, Landroidx/media3/common/A$c;

    invoke-direct {p1}, Landroidx/media3/common/A$c;-><init>()V

    iput-object p1, p0, Lg0/s0;->e:Landroidx/media3/common/A$c;

    new-instance p1, Landroidx/media3/common/A$b;

    invoke-direct {p1}, Landroidx/media3/common/A$b;-><init>()V

    iput-object p1, p0, Lg0/s0;->f:Landroidx/media3/common/A$b;

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Lg0/s0;->h:Ljava/util/HashMap;

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Lg0/s0;->g:Ljava/util/HashMap;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide p1

    iput-wide p1, p0, Lg0/s0;->d:J

    const/4 p1, 0x0

    iput p1, p0, Lg0/s0;->l:I

    iput p1, p0, Lg0/s0;->m:I

    new-instance p1, Lg0/c0;

    invoke-direct {p1}, Lg0/c0;-><init>()V

    iput-object p1, p0, Lg0/s0;->b:Lg0/c0;

    invoke-virtual {p1, p0}, Lg0/c0;->l(Lg0/t0;)V

    return-void
.end method

.method private W(Lg0/s0$b;)Z
    .registers 3

    if-eqz p1, :cond_12

    iget-object v0, p0, Lg0/s0;->b:Lg0/c0;

    invoke-virtual {v0}, Lg0/c0;->h()Ljava/lang/String;

    move-result-object v0

    iget-object p1, p1, Lg0/s0$b;->c:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_12

    const/4 p1, 0x1

    goto :goto_13

    :cond_12
    const/4 p1, 0x0

    :goto_13
    return p1
.end method

.method public static X(Landroid/content/Context;)Lg0/s0;
    .registers 3

    const-string v0, "media_metrics"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lg0/i0;->a(Ljava/lang/Object;)Landroid/media/metrics/MediaMetricsManager;

    move-result-object v0

    if-nez v0, :cond_e

    const/4 p0, 0x0

    goto :goto_18

    :cond_e
    new-instance v1, Lg0/s0;

    invoke-static {v0}, Landroidx/core/view/i;->b(Landroid/media/metrics/MediaMetricsManager;)Landroid/media/metrics/PlaybackSession;

    move-result-object v0

    invoke-direct {v1, p0, v0}, Lg0/s0;-><init>(Landroid/content/Context;Landroid/media/metrics/PlaybackSession;)V

    move-object p0, v1

    :goto_18
    return-object p0
.end method

.method private Y()V
    .registers 8

    iget-object v0, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    const/4 v1, 0x0

    if-eqz v0, :cond_69

    iget-boolean v2, p0, Lg0/s0;->A:Z

    if-eqz v2, :cond_69

    iget v2, p0, Lg0/s0;->z:I

    invoke-static {v0, v2}, Lg0/m0;->a(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    iget-object v0, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    iget v2, p0, Lg0/s0;->x:I

    invoke-static {v0, v2}, Lg0/n0;->a(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    iget-object v0, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    iget v2, p0, Lg0/s0;->y:I

    invoke-static {v0, v2}, Lg0/o0;->a(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    iget-object v0, p0, Lg0/s0;->g:Ljava/util/HashMap;

    iget-object v2, p0, Lg0/s0;->i:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    iget-object v2, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    const-wide/16 v3, 0x0

    if-nez v0, :cond_2e

    move-wide v5, v3

    goto :goto_32

    :cond_2e
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    :goto_32
    invoke-static {v2, v5, v6}, Lg0/p0;->a(Landroid/media/metrics/PlaybackMetrics$Builder;J)V

    iget-object v0, p0, Lg0/s0;->h:Ljava/util/HashMap;

    iget-object v2, p0, Lg0/s0;->i:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    iget-object v2, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    if-nez v0, :cond_45

    move-wide v5, v3

    goto :goto_49

    :cond_45
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    :goto_49
    invoke-static {v2, v5, v6}, Lg0/q0;->b(Landroid/media/metrics/PlaybackMetrics$Builder;J)V

    iget-object v2, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    if-eqz v0, :cond_5a

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    cmp-long v0, v5, v3

    if-lez v0, :cond_5a

    const/4 v0, 0x1

    goto :goto_5b

    :cond_5a
    const/4 v0, 0x0

    :goto_5b
    invoke-static {v2, v0}, Landroidx/media3/exoplayer/X;->b(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    iget-object v0, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    invoke-static {v0}, LP6/f;->a(Landroid/media/metrics/PlaybackMetrics$Builder;)Landroid/media/metrics/PlaybackMetrics;

    move-result-object v0

    iget-object v2, p0, Lg0/s0;->c:Landroid/media/metrics/PlaybackSession;

    invoke-static {v2, v0}, LP6/g;->a(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackMetrics;)V

    :cond_69
    const/4 v0, 0x0

    iput-object v0, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    iput-object v0, p0, Lg0/s0;->i:Ljava/lang/String;

    iput v1, p0, Lg0/s0;->z:I

    iput v1, p0, Lg0/s0;->x:I

    iput v1, p0, Lg0/s0;->y:I

    iput-object v0, p0, Lg0/s0;->r:Landroidx/media3/common/m;

    iput-object v0, p0, Lg0/s0;->s:Landroidx/media3/common/m;

    iput-object v0, p0, Lg0/s0;->t:Landroidx/media3/common/m;

    iput-boolean v1, p0, Lg0/s0;->A:Z

    return-void
.end method

.method private a0(Landroidx/media3/common/A;Landroidx/media3/exoplayer/source/o$b;)V
    .registers 11

    iget-object v0, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    if-nez p2, :cond_5

    return-void

    :cond_5
    iget-object p2, p2, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    invoke-virtual {p1, p2}, Landroidx/media3/common/A;->b(Ljava/lang/Object;)I

    move-result p2

    const/4 v1, -0x1

    if-ne p2, v1, :cond_f

    return-void

    :cond_f
    iget-object v1, p0, Lg0/s0;->f:Landroidx/media3/common/A$b;

    const/4 v2, 0x0

    invoke-virtual {p1, p2, v1, v2}, Landroidx/media3/common/A;->g(ILandroidx/media3/common/A$b;Z)Landroidx/media3/common/A$b;

    iget p2, v1, Landroidx/media3/common/A$b;->c:I

    iget-object v1, p0, Lg0/s0;->e:Landroidx/media3/common/A$c;

    invoke-virtual {p1, p2, v1}, Landroidx/media3/common/A;->o(ILandroidx/media3/common/A$c;)V

    iget-object p1, v1, Landroidx/media3/common/A$c;->c:Landroidx/media3/common/q;

    iget-object p1, p1, Landroidx/media3/common/q;->b:Landroidx/media3/common/q$f;

    const/4 p2, 0x2

    const/4 v3, 0x1

    if-nez p1, :cond_25

    goto :goto_3a

    :cond_25
    iget-object v2, p1, Landroidx/media3/common/q$f;->a:Landroid/net/Uri;

    iget-object p1, p1, Landroidx/media3/common/q$f;->b:Ljava/lang/String;

    invoke-static {v2, p1}, La0/T;->M(Landroid/net/Uri;Ljava/lang/String;)I

    move-result p1

    if-eqz p1, :cond_39

    if-eq p1, v3, :cond_37

    if-eq p1, p2, :cond_35

    const/4 v2, 0x1

    goto :goto_3a

    :cond_35
    const/4 v2, 0x4

    goto :goto_3a

    :cond_37
    const/4 v2, 0x5

    goto :goto_3a

    :cond_39
    const/4 v2, 0x3

    :goto_3a
    invoke-static {v0, v2}, Lg0/h0;->b(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    iget-wide v4, v1, Landroidx/media3/common/A$c;->m:J

    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long p1, v4, v6

    if-eqz p1, :cond_5f

    iget-boolean p1, v1, Landroidx/media3/common/A$c;->k:Z

    if-nez p1, :cond_5f

    iget-boolean p1, v1, Landroidx/media3/common/A$c;->i:Z

    if-nez p1, :cond_5f

    invoke-virtual {v1}, Landroidx/media3/common/A$c;->a()Z

    move-result p1

    if-nez p1, :cond_5f

    iget-wide v4, v1, Landroidx/media3/common/A$c;->m:J

    invoke-static {v4, v5}, La0/T;->j0(J)J

    move-result-wide v4

    invoke-static {v0, v4, v5}, Lcom/flipkart/android/reactnative/nativemodules/upi/d;->b(Landroid/media/metrics/PlaybackMetrics$Builder;J)V

    :cond_5f
    invoke-virtual {v1}, Landroidx/media3/common/A$c;->a()Z

    move-result p1

    if-eqz p1, :cond_66

    goto :goto_67

    :cond_66
    const/4 p2, 0x1

    :goto_67
    invoke-static {v0, p2}, Lg0/i0;->b(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    iput-boolean v3, p0, Lg0/s0;->A:Z

    return-void
.end method

.method private b0(IJLandroidx/media3/common/m;I)V
    .registers 8

    invoke-static {p1}, LJ/h;->a(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    move-result-object p1

    iget-wide v0, p0, Lg0/s0;->d:J

    sub-long/2addr p2, v0

    invoke-static {p1, p2, p3}, Lg0/r0;->a(Landroid/media/metrics/TrackChangeEvent$Builder;J)Landroid/media/metrics/TrackChangeEvent$Builder;

    move-result-object p1

    const/4 p2, 0x1

    if-eqz p4, :cond_90

    invoke-static {p1}, LJ/e;->d(Landroid/media/metrics/TrackChangeEvent$Builder;)V

    const/4 p3, 0x2

    if-eq p5, p2, :cond_1d

    const/4 v0, 0x3

    if-eq p5, p3, :cond_1e

    if-eq p5, v0, :cond_1b

    const/4 v0, 0x1

    goto :goto_1e

    :cond_1b
    const/4 v0, 0x4

    goto :goto_1e

    :cond_1d
    const/4 v0, 0x2

    :cond_1e
    :goto_1e
    invoke-static {p1, v0}, Lg0/d0;->b(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    iget-object p5, p4, Landroidx/media3/common/m;->m:Ljava/lang/String;

    if-eqz p5, :cond_28

    invoke-static {p1, p5}, LJ/g;->b(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    :cond_28
    iget-object p5, p4, Landroidx/media3/common/m;->n:Ljava/lang/String;

    if-eqz p5, :cond_2f

    invoke-static {p1, p5}, LJ/h;->c(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    :cond_2f
    iget-object p5, p4, Landroidx/media3/common/m;->j:Ljava/lang/String;

    if-eqz p5, :cond_36

    invoke-static {p1, p5}, Lg0/e0;->c(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    :cond_36
    const/4 p5, -0x1

    iget v0, p4, Landroidx/media3/common/m;->i:I

    if-eq v0, p5, :cond_3e

    invoke-static {p1, v0}, Lg0/f0;->d(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    :cond_3e
    iget v0, p4, Landroidx/media3/common/m;->t:I

    if-eq v0, p5, :cond_45

    invoke-static {p1, v0}, Lg0/g0;->b(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    :cond_45
    iget v0, p4, Landroidx/media3/common/m;->u:I

    if-eq v0, p5, :cond_4c

    invoke-static {p1, v0}, Lg0/h0;->c(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    :cond_4c
    iget v0, p4, Landroidx/media3/common/m;->B:I

    if-eq v0, p5, :cond_53

    invoke-static {p1, v0}, Lcom/flipkart/android/reactnative/nativemodules/upi/d;->c(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    :cond_53
    iget v0, p4, Landroidx/media3/common/m;->C:I

    if-eq v0, p5, :cond_5a

    invoke-static {p1, v0}, Lg0/g0;->c(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    :cond_5a
    iget-object v0, p4, Landroidx/media3/common/m;->d:Ljava/lang/String;

    if-eqz v0, :cond_84

    sget v1, La0/T;->a:I

    const-string v1, "-"

    invoke-virtual {v0, v1, p5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p5

    const/4 v0, 0x0

    aget-object v0, p5, v0

    array-length v1, p5

    if-lt v1, p3, :cond_6f

    aget-object p3, p5, p2

    goto :goto_70

    :cond_6f
    const/4 p3, 0x0

    :goto_70
    invoke-static {v0, p3}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p3

    iget-object p5, p3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast p5, Ljava/lang/String;

    invoke-static {p1, p5}, Landroidx/core/view/b;->d(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    iget-object p3, p3, Landroid/util/Pair;->second:Ljava/lang/Object;

    if-eqz p3, :cond_84

    check-cast p3, Ljava/lang/String;

    invoke-static {p1, p3}, Landroidx/core/view/d;->c(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    :cond_84
    const/high16 p3, -0x40800000    # -1.0f

    iget p4, p4, Landroidx/media3/common/m;->v:F

    cmpl-float p3, p4, p3

    if-eqz p3, :cond_93

    invoke-static {p1, p4}, Landroidx/core/view/e;->b(Landroid/media/metrics/TrackChangeEvent$Builder;F)V

    goto :goto_93

    :cond_90
    invoke-static {p1}, La0/v;->c(Landroid/media/metrics/TrackChangeEvent$Builder;)V

    :cond_93
    :goto_93
    iput-boolean p2, p0, Lg0/s0;->A:Z

    iget-object p2, p0, Lg0/s0;->c:Landroid/media/metrics/PlaybackSession;

    invoke-static {p1}, La0/w;->b(Landroid/media/metrics/TrackChangeEvent$Builder;)Landroid/media/metrics/TrackChangeEvent;

    move-result-object p1

    invoke-static {p2, p1}, LP6/i;->b(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/TrackChangeEvent;)V

    return-void
.end method


# virtual methods
.method public final synthetic A(Lg0/b$a;)V
    .registers 2

    return-void
.end method

.method public final synthetic B(ILg0/b$a;)V
    .registers 3

    return-void
.end method

.method public final synthetic C(Lg0/b$a;Z)V
    .registers 3

    return-void
.end method

.method public final synthetic D(ILg0/b$a;Z)V
    .registers 4

    return-void
.end method

.method public final synthetic E(Lg0/b$a;II)V
    .registers 4

    return-void
.end method

.method public final synthetic F(ILg0/b$a;)V
    .registers 3

    return-void
.end method

.method public final synthetic G(Lg0/b$a;)V
    .registers 2

    return-void
.end method

.method public final synthetic H(Lg0/b$a;)V
    .registers 2

    return-void
.end method

.method public final synthetic I(Lg0/b$a;)V
    .registers 2

    return-void
.end method

.method public final synthetic J(Lg0/b$a;I)V
    .registers 3

    return-void
.end method

.method public final synthetic K(Lg0/b$a;Landroidx/media3/common/D;)V
    .registers 3

    return-void
.end method

.method public final synthetic L(Lg0/b$a;F)V
    .registers 3

    return-void
.end method

.method public final synthetic M(ILg0/b$a;)V
    .registers 3

    return-void
.end method

.method public final N(Lg0/b$a;Ljava/lang/String;)V
    .registers 5

    iget-object v0, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result v1

    if-eqz v1, :cond_b

    return-void

    :cond_b
    invoke-direct {p0}, Lg0/s0;->Y()V

    iput-object p2, p0, Lg0/s0;->i:Ljava/lang/String;

    invoke-static {}, Lg0/k0;->b()Landroid/media/metrics/PlaybackMetrics$Builder;

    move-result-object p2

    invoke-static {p2}, La0/w;->a(Landroid/media/metrics/PlaybackMetrics$Builder;)Landroid/media/metrics/PlaybackMetrics$Builder;

    move-result-object p2

    invoke-static {p2}, Landroidx/core/view/f;->a(Landroid/media/metrics/PlaybackMetrics$Builder;)Landroid/media/metrics/PlaybackMetrics$Builder;

    move-result-object p2

    iput-object p2, p0, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    iget-object p1, p1, Lg0/b$a;->b:Landroidx/media3/common/A;

    invoke-direct {p0, p1, v0}, Lg0/s0;->a0(Landroidx/media3/common/A;Landroidx/media3/exoplayer/source/o$b;)V

    return-void
.end method

.method public final O(Lg0/b$a;Landroidx/media3/exoplayer/k;)V
    .registers 4

    iget p1, p0, Lg0/s0;->x:I

    iget v0, p2, Landroidx/media3/exoplayer/k;->g:I

    add-int/2addr p1, v0

    iput p1, p0, Lg0/s0;->x:I

    iget p1, p0, Lg0/s0;->y:I

    iget p2, p2, Landroidx/media3/exoplayer/k;->e:I

    add-int/2addr p1, p2

    iput p1, p0, Lg0/s0;->y:I

    return-void
.end method

.method public final P(Landroidx/media3/common/y;Lg0/b$b;)V
    .registers 31

    move-object/from16 v6, p0

    move-object/from16 v7, p2

    invoke-virtual/range {p2 .. p2}, Lg0/b$b;->d()I

    move-result v0

    if-nez v0, :cond_b

    return-void

    :cond_b
    const/4 v8, 0x0

    const/4 v0, 0x0

    :goto_d
    invoke-virtual/range {p2 .. p2}, Lg0/b$b;->d()I

    move-result v1

    iget-object v9, v6, Lg0/s0;->b:Lg0/c0;

    const/16 v10, 0xb

    if-ge v0, v1, :cond_33

    invoke-virtual {v7, v0}, Lg0/b$b;->b(I)I

    move-result v1

    invoke-virtual {v7, v1}, Lg0/b$b;->c(I)Lg0/b$a;

    move-result-object v2

    if-nez v1, :cond_25

    invoke-virtual {v9, v2}, Lg0/c0;->p(Lg0/b$a;)V

    goto :goto_30

    :cond_25
    if-ne v1, v10, :cond_2d

    iget v1, v6, Lg0/s0;->k:I

    invoke-virtual {v9, v1, v2}, Lg0/c0;->o(ILg0/b$a;)V

    goto :goto_30

    :cond_2d
    invoke-virtual {v9, v2}, Lg0/c0;->n(Lg0/b$a;)V

    :goto_30
    add-int/lit8 v0, v0, 0x1

    goto :goto_d

    :cond_33
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v11

    invoke-virtual {v7, v8}, Lg0/b$b;->a(I)Z

    move-result v0

    if-eqz v0, :cond_4c

    invoke-virtual {v7, v8}, Lg0/b$b;->c(I)Lg0/b$a;

    move-result-object v0

    iget-object v1, v6, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    if-eqz v1, :cond_4c

    iget-object v1, v0, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget-object v0, v0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {v6, v1, v0}, Lg0/s0;->a0(Landroidx/media3/common/A;Landroidx/media3/exoplayer/source/o$b;)V

    :cond_4c
    const/4 v13, 0x2

    invoke-virtual {v7, v13}, Lg0/b$b;->a(I)Z

    move-result v0

    const/4 v14, 0x1

    if-eqz v0, :cond_c2

    iget-object v0, v6, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    if-eqz v0, :cond_c2

    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->l()Landroidx/media3/common/D;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media3/common/D;->a()Lgk/w;

    move-result-object v0

    invoke-virtual {v0, v8}, Lgk/w;->u(I)Lgk/c0;

    move-result-object v0

    :cond_64
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_87

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/media3/common/D$a;

    const/4 v2, 0x0

    :goto_71
    iget v3, v1, Landroidx/media3/common/D$a;->a:I

    if-ge v2, v3, :cond_64

    invoke-virtual {v1, v2}, Landroidx/media3/common/D$a;->g(I)Z

    move-result v3

    if-eqz v3, :cond_84

    invoke-virtual {v1, v2}, Landroidx/media3/common/D$a;->b(I)Landroidx/media3/common/m;

    move-result-object v3

    iget-object v3, v3, Landroidx/media3/common/m;->r:Landroidx/media3/common/DrmInitData;

    if-eqz v3, :cond_84

    goto :goto_88

    :cond_84
    add-int/lit8 v2, v2, 0x1

    goto :goto_71

    :cond_87
    const/4 v3, 0x0

    :goto_88
    if-eqz v3, :cond_c2

    iget-object v0, v6, Lg0/s0;->j:Landroid/media/metrics/PlaybackMetrics$Builder;

    invoke-static {v0}, Landroidx/core/view/e;->a(Ljava/lang/Object;)Landroid/media/metrics/PlaybackMetrics$Builder;

    move-result-object v0

    const/4 v1, 0x0

    :goto_91
    iget v2, v3, Landroidx/media3/common/DrmInitData;->schemeDataCount:I

    if-ge v1, v2, :cond_be

    invoke-virtual {v3, v1}, Landroidx/media3/common/DrmInitData;->get(I)Landroidx/media3/common/DrmInitData$SchemeData;

    move-result-object v2

    iget-object v2, v2, Landroidx/media3/common/DrmInitData$SchemeData;->uuid:Ljava/util/UUID;

    sget-object v10, Landroidx/media3/common/g;->d:Ljava/util/UUID;

    invoke-virtual {v2, v10}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_a5

    const/4 v1, 0x3

    goto :goto_bf

    :cond_a5
    sget-object v10, Landroidx/media3/common/g;->e:Ljava/util/UUID;

    invoke-virtual {v2, v10}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_af

    const/4 v1, 0x2

    goto :goto_bf

    :cond_af
    sget-object v10, Landroidx/media3/common/g;->c:Ljava/util/UUID;

    invoke-virtual {v2, v10}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b9

    const/4 v1, 0x6

    goto :goto_bf

    :cond_b9
    add-int/lit8 v1, v1, 0x1

    const/16 v10, 0xb

    goto :goto_91

    :cond_be
    const/4 v1, 0x1

    :goto_bf
    invoke-static {v0, v1}, La0/v;->b(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    :cond_c2
    const/16 v0, 0x3f3

    invoke-virtual {v7, v0}, Lg0/b$b;->a(I)Z

    move-result v0

    if-eqz v0, :cond_cf

    iget v0, v6, Lg0/s0;->z:I

    add-int/2addr v0, v14

    iput v0, v6, Lg0/s0;->z:I

    :cond_cf
    iget-object v0, v6, Lg0/s0;->n:Landroidx/media3/common/w;

    iget-object v1, v6, Lg0/s0;->a:Landroid/content/Context;

    iget-object v15, v6, Lg0/s0;->c:Landroid/media/metrics/PlaybackSession;

    move-wide/from16 v17, v11

    iget-wide v10, v6, Lg0/s0;->d:J

    const/4 v3, 0x5

    const/4 v12, 0x4

    if-nez v0, :cond_eb

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/16 v8, 0xd

    const/16 v20, 0x6

    const/16 v21, 0x8

    const/16 v23, 0x7

    const/16 v24, 0x9

    goto/16 :goto_36d

    :cond_eb
    iget v2, v6, Lg0/s0;->v:I

    if-ne v2, v12, :cond_f1

    const/4 v2, 0x1

    goto :goto_f2

    :cond_f1
    const/4 v2, 0x0

    :goto_f2
    const/16 v12, 0x3e9

    iget v5, v0, Landroidx/media3/common/w;->a:I

    if-ne v5, v12, :cond_10b

    new-instance v2, Lg0/s0$a;

    const/16 v5, 0x14

    invoke-direct {v2, v5, v8}, Lg0/s0$a;-><init>(II)V

    :goto_ff
    const/16 v8, 0xd

    const/16 v20, 0x6

    const/16 v21, 0x8

    const/16 v23, 0x7

    const/16 v24, 0x9

    goto/16 :goto_345

    :cond_10b
    instance-of v12, v0, Landroidx/media3/exoplayer/p;

    if-eqz v12, :cond_11c

    move-object v12, v0

    check-cast v12, Landroidx/media3/exoplayer/p;

    iget v4, v12, Landroidx/media3/exoplayer/p;->c:I

    if-ne v4, v14, :cond_118

    const/4 v4, 0x1

    goto :goto_119

    :cond_118
    const/4 v4, 0x0

    :goto_119
    iget v12, v12, Landroidx/media3/exoplayer/p;->g:I

    goto :goto_11e

    :cond_11c
    const/4 v4, 0x0

    const/4 v12, 0x0

    :goto_11e
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v13, v14, Ljava/io/IOException;

    const/16 v25, 0x19

    const/16 v26, 0x1a

    const/16 v8, 0x17

    if-eqz v13, :cond_28f

    instance-of v4, v14, Lc0/m;

    if-eqz v4, :cond_13d

    check-cast v14, Lc0/m;

    new-instance v2, Lg0/s0$a;

    iget v4, v14, Lc0/m;->d:I

    invoke-direct {v2, v3, v4}, Lg0/s0$a;-><init>(II)V

    goto :goto_ff

    :cond_13d
    instance-of v4, v14, Lc0/l;

    if-nez v4, :cond_145

    instance-of v4, v14, Landroidx/media3/common/v;

    if-eqz v4, :cond_14e

    :cond_145
    const/16 v4, 0x9

    const/4 v5, 0x0

    const/4 v8, 0x7

    const/4 v12, 0x6

    const/16 v13, 0x8

    goto/16 :goto_280

    :cond_14e
    instance-of v2, v14, Lc0/k;

    if-nez v2, :cond_156

    instance-of v4, v14, Lc0/s$a;

    if-eqz v4, :cond_15b

    :cond_156
    const/16 v4, 0x9

    const/4 v5, 0x0

    goto/16 :goto_235

    :cond_15b
    const/16 v2, 0x3ea

    const/16 v4, 0x15

    if-ne v5, v2, :cond_168

    new-instance v2, Lg0/s0$a;

    const/4 v5, 0x0

    invoke-direct {v2, v4, v5}, Lg0/s0$a;-><init>(II)V

    goto :goto_ff

    :cond_168
    instance-of v2, v14, Lk0/h$a;

    if-eqz v2, :cond_1f0

    invoke-virtual {v14}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v5, La0/T;->a:I

    if-lt v5, v4, :cond_1a2

    instance-of v4, v2, Landroid/media/MediaDrm$MediaDrmStateException;

    if-eqz v4, :cond_1a2

    check-cast v2, Landroid/media/MediaDrm$MediaDrmStateException;

    invoke-virtual {v2}, Landroid/media/MediaDrm$MediaDrmStateException;->getDiagnosticInfo()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, La0/T;->A(Ljava/lang/String;)I

    move-result v2

    invoke-static {v2}, La0/T;->z(I)I

    move-result v4

    packed-switch v4, :pswitch_data_57a

    const/16 v4, 0x1b

    goto :goto_19a

    :pswitch_18f
    const/16 v4, 0x1a

    goto :goto_19a

    :pswitch_192
    const/16 v4, 0x19

    goto :goto_19a

    :pswitch_195
    const/16 v4, 0x1c

    goto :goto_19a

    :pswitch_198
    const/16 v4, 0x18

    :goto_19a
    new-instance v5, Lg0/s0$a;

    invoke-direct {v5, v4, v2}, Lg0/s0$a;-><init>(II)V

    move-object v2, v5

    goto/16 :goto_ff

    :cond_1a2
    if-lt v5, v8, :cond_1b4

    invoke-static {v2}, Lcom/facebook/react/views/text/c;->c(Ljava/lang/Throwable;)Z

    move-result v4

    if-eqz v4, :cond_1b4

    new-instance v2, Lg0/s0$a;

    const/4 v4, 0x0

    const/16 v5, 0x1b

    invoke-direct {v2, v5, v4}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_1b4
    const/4 v4, 0x0

    instance-of v5, v2, Landroid/media/NotProvisionedException;

    if-eqz v5, :cond_1c2

    new-instance v2, Lg0/s0$a;

    const/16 v13, 0x18

    invoke-direct {v2, v13, v4}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_1c2
    instance-of v5, v2, Landroid/media/DeniedByServerException;

    if-eqz v5, :cond_1cf

    new-instance v2, Lg0/s0$a;

    const/16 v5, 0x1d

    invoke-direct {v2, v5, v4}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_1cf
    instance-of v5, v2, Lk0/C;

    if-eqz v5, :cond_1da

    new-instance v2, Lg0/s0$a;

    invoke-direct {v2, v8, v4}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_1da
    instance-of v2, v2, Lk0/c$d;

    if-eqz v2, :cond_1e7

    new-instance v2, Lg0/s0$a;

    const/16 v5, 0x1c

    invoke-direct {v2, v5, v4}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_1e7
    new-instance v2, Lg0/s0$a;

    const/16 v5, 0x1e

    invoke-direct {v2, v5, v4}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_1f0
    instance-of v2, v14, Landroidx/media3/datasource/d$c;

    if-eqz v2, :cond_22b

    invoke-virtual {v14}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    instance-of v2, v2, Ljava/io/FileNotFoundException;

    if-eqz v2, :cond_22b

    invoke-virtual {v14}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    sget v5, La0/T;->a:I

    if-lt v5, v4, :cond_221

    instance-of v4, v2, Landroid/system/ErrnoException;

    if-eqz v4, :cond_221

    check-cast v2, Landroid/system/ErrnoException;

    iget v2, v2, Landroid/system/ErrnoException;->errno:I

    sget v4, Landroid/system/OsConstants;->EACCES:I

    if-ne v2, v4, :cond_221

    new-instance v2, Lg0/s0$a;

    const/16 v4, 0x20

    const/4 v5, 0x0

    invoke-direct {v2, v4, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_221
    const/4 v5, 0x0

    new-instance v2, Lg0/s0$a;

    const/16 v4, 0x1f

    invoke-direct {v2, v4, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_22b
    const/4 v5, 0x0

    new-instance v2, Lg0/s0$a;

    const/16 v4, 0x9

    invoke-direct {v2, v4, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :goto_235
    invoke-static {v1}, La0/z;->b(Landroid/content/Context;)La0/z;

    move-result-object v8

    invoke-virtual {v8}, La0/z;->c()I

    move-result v8

    const/4 v12, 0x1

    if-ne v8, v12, :cond_248

    new-instance v2, Lg0/s0$a;

    const/4 v8, 0x3

    invoke-direct {v2, v8, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_248
    invoke-virtual {v14}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v8

    instance-of v12, v8, Ljava/net/UnknownHostException;

    if-eqz v12, :cond_258

    new-instance v2, Lg0/s0$a;

    const/4 v12, 0x6

    invoke-direct {v2, v12, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_258
    const/4 v12, 0x6

    instance-of v8, v8, Ljava/net/SocketTimeoutException;

    if-eqz v8, :cond_265

    new-instance v2, Lg0/s0$a;

    const/4 v8, 0x7

    invoke-direct {v2, v8, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_265
    const/4 v8, 0x7

    if-eqz v2, :cond_277

    check-cast v14, Lc0/k;

    iget v2, v14, Lc0/k;->c:I

    const/4 v13, 0x1

    if-ne v2, v13, :cond_277

    new-instance v2, Lg0/s0$a;

    const/4 v13, 0x4

    invoke-direct {v2, v13, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :cond_277
    new-instance v2, Lg0/s0$a;

    const/16 v13, 0x8

    invoke-direct {v2, v13, v5}, Lg0/s0$a;-><init>(II)V

    goto/16 :goto_ff

    :goto_280
    new-instance v14, Lg0/s0$a;

    if-eqz v2, :cond_287

    const/16 v2, 0xa

    goto :goto_289

    :cond_287
    const/16 v2, 0xb

    :goto_289
    invoke-direct {v14, v2, v5}, Lg0/s0$a;-><init>(II)V

    move-object v2, v14

    goto/16 :goto_ff

    :cond_28f
    const/4 v2, 0x0

    const/16 v5, 0x1b

    const/16 v13, 0x18

    const/16 v20, 0x6

    const/16 v21, 0x8

    const/16 v23, 0x7

    const/16 v24, 0x9

    const/16 v27, 0x1c

    if-eqz v4, :cond_2b1

    if-eqz v12, :cond_2a5

    const/4 v3, 0x1

    if-ne v12, v3, :cond_2b1

    :cond_2a5
    new-instance v3, Lg0/s0$a;

    const/16 v4, 0x23

    invoke-direct {v3, v4, v2}, Lg0/s0$a;-><init>(II)V

    :goto_2ac
    move-object v2, v3

    const/16 v8, 0xd

    goto/16 :goto_345

    :cond_2b1
    if-eqz v4, :cond_2be

    const/4 v3, 0x3

    if-ne v12, v3, :cond_2be

    new-instance v3, Lg0/s0$a;

    const/16 v4, 0xf

    invoke-direct {v3, v4, v2}, Lg0/s0$a;-><init>(II)V

    goto :goto_2ac

    :cond_2be
    if-eqz v4, :cond_2c9

    const/4 v3, 0x2

    if-ne v12, v3, :cond_2c9

    new-instance v3, Lg0/s0$a;

    invoke-direct {v3, v8, v2}, Lg0/s0$a;-><init>(II)V

    goto :goto_2ac

    :cond_2c9
    instance-of v2, v14, Landroidx/media3/exoplayer/mediacodec/m$c;

    if-eqz v2, :cond_2de

    check-cast v14, Landroidx/media3/exoplayer/mediacodec/m$c;

    iget-object v2, v14, Landroidx/media3/exoplayer/mediacodec/m$c;->d:Ljava/lang/String;

    invoke-static {v2}, La0/T;->A(Ljava/lang/String;)I

    move-result v2

    new-instance v3, Lg0/s0$a;

    const/16 v8, 0xd

    invoke-direct {v3, v8, v2}, Lg0/s0$a;-><init>(II)V

    :goto_2dc
    move-object v2, v3

    goto :goto_345

    :cond_2de
    const/16 v8, 0xd

    instance-of v2, v14, Ln0/a;

    const/16 v3, 0xe

    if-eqz v2, :cond_2f0

    check-cast v14, Ln0/a;

    new-instance v2, Lg0/s0$a;

    iget v4, v14, Ln0/a;->a:I

    invoke-direct {v2, v3, v4}, Lg0/s0$a;-><init>(II)V

    goto :goto_345

    :cond_2f0
    instance-of v2, v14, Ljava/lang/OutOfMemoryError;

    if-eqz v2, :cond_2fb

    new-instance v2, Lg0/s0$a;

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Lg0/s0$a;-><init>(II)V

    goto :goto_345

    :cond_2fb
    instance-of v2, v14, Landroidx/media3/exoplayer/audio/h$c;

    if-eqz v2, :cond_30b

    check-cast v14, Landroidx/media3/exoplayer/audio/h$c;

    new-instance v2, Lg0/s0$a;

    const/16 v3, 0x11

    iget v4, v14, Landroidx/media3/exoplayer/audio/h$c;->a:I

    invoke-direct {v2, v3, v4}, Lg0/s0$a;-><init>(II)V

    goto :goto_345

    :cond_30b
    instance-of v2, v14, Landroidx/media3/exoplayer/audio/h$f;

    if-eqz v2, :cond_31b

    check-cast v14, Landroidx/media3/exoplayer/audio/h$f;

    new-instance v2, Lg0/s0$a;

    const/16 v3, 0x12

    iget v4, v14, Landroidx/media3/exoplayer/audio/h$f;->a:I

    invoke-direct {v2, v3, v4}, Lg0/s0$a;-><init>(II)V

    goto :goto_345

    :cond_31b
    instance-of v2, v14, Landroid/media/MediaCodec$CryptoException;

    if-eqz v2, :cond_33d

    check-cast v14, Landroid/media/MediaCodec$CryptoException;

    invoke-virtual {v14}, Landroid/media/MediaCodec$CryptoException;->getErrorCode()I

    move-result v2

    invoke-static {v2}, La0/T;->z(I)I

    move-result v3

    packed-switch v3, :pswitch_data_586

    const/16 v13, 0x1b

    goto :goto_337

    :pswitch_32f
    const/16 v13, 0x1a

    goto :goto_337

    :pswitch_332
    const/16 v13, 0x19

    goto :goto_337

    :pswitch_335
    const/16 v13, 0x1c

    :goto_337
    :pswitch_337
    new-instance v3, Lg0/s0$a;

    invoke-direct {v3, v13, v2}, Lg0/s0$a;-><init>(II)V

    goto :goto_2dc

    :cond_33d
    new-instance v2, Lg0/s0$a;

    const/16 v3, 0x16

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Lg0/s0$a;-><init>(II)V

    :goto_345
    invoke-static {}, Lg0/f0;->c()Landroid/media/metrics/PlaybackErrorEvent$Builder;

    move-result-object v3

    sub-long v4, v17, v10

    invoke-static {v3, v4, v5}, Landroidx/core/view/g;->c(Landroid/media/metrics/PlaybackErrorEvent$Builder;J)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    move-result-object v3

    iget v4, v2, Lg0/s0$a;->a:I

    invoke-static {v3, v4}, Landroidx/core/view/h;->c(Landroid/media/metrics/PlaybackErrorEvent$Builder;I)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    move-result-object v3

    iget v2, v2, Lg0/s0$a;->b:I

    invoke-static {v3, v2}, La0/J;->c(Landroid/media/metrics/PlaybackErrorEvent$Builder;I)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    move-result-object v2

    invoke-static {v2, v0}, Lcom/flipkart/android/notification/e;->a(Landroid/media/metrics/PlaybackErrorEvent$Builder;Landroidx/media3/common/w;)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    move-result-object v0

    invoke-static {v0}, Lg0/l0;->a(Landroid/media/metrics/PlaybackErrorEvent$Builder;)Landroid/media/metrics/PlaybackErrorEvent;

    move-result-object v0

    invoke-static {v15, v0}, La0/M;->b(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackErrorEvent;)V

    const/4 v0, 0x1

    iput-boolean v0, v6, Lg0/s0;->A:Z

    const/4 v2, 0x0

    iput-object v2, v6, Lg0/s0;->n:Landroidx/media3/common/w;

    const/4 v2, 0x2

    :goto_36d
    invoke-virtual {v7, v2}, Lg0/b$b;->a(I)Z

    move-result v3

    if-eqz v3, :cond_38b

    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->l()Landroidx/media3/common/D;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroidx/media3/common/D;->c(I)Z

    move-result v4

    invoke-virtual {v3, v0}, Landroidx/media3/common/D;->c(I)Z

    move-result v12

    const/4 v5, 0x3

    invoke-virtual {v3, v5}, Landroidx/media3/common/D;->c(I)Z

    move-result v13

    if-nez v4, :cond_393

    if-nez v12, :cond_393

    if-eqz v13, :cond_38b

    goto :goto_393

    :cond_38b
    move-object/from16 v19, v1

    const/16 v8, 0xa

    const/16 v22, 0x5

    goto/16 :goto_404

    :cond_393
    :goto_393
    if-nez v4, :cond_3c3

    iget-object v0, v6, Lg0/s0;->r:Landroidx/media3/common/m;

    const/4 v14, 0x0

    invoke-static {v0, v14}, La0/T;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3a3

    move-object/from16 v19, v1

    const/16 v8, 0xa

    goto :goto_3c8

    :cond_3a3
    iget-object v0, v6, Lg0/s0;->r:Landroidx/media3/common/m;

    if-nez v0, :cond_3aa

    const/16 v16, 0x1

    goto :goto_3ac

    :cond_3aa
    const/16 v16, 0x0

    :goto_3ac
    iput-object v14, v6, Lg0/s0;->r:Landroidx/media3/common/m;

    const/4 v2, 0x1

    move-object/from16 v0, p0

    move-object/from16 v19, v1

    move v1, v2

    const/16 v4, 0xa

    const/16 v22, 0x5

    move-wide/from16 v2, v17

    const/16 v8, 0xa

    move-object v4, v14

    move/from16 v5, v16

    invoke-direct/range {v0 .. v5}, Lg0/s0;->b0(IJLandroidx/media3/common/m;I)V

    goto :goto_3ca

    :cond_3c3
    move-object/from16 v19, v1

    const/16 v8, 0xa

    const/4 v14, 0x0

    :goto_3c8
    const/16 v22, 0x5

    :goto_3ca
    if-nez v12, :cond_3e7

    iget-object v0, v6, Lg0/s0;->s:Landroidx/media3/common/m;

    invoke-static {v0, v14}, La0/T;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3d5

    goto :goto_3e7

    :cond_3d5
    iget-object v0, v6, Lg0/s0;->s:Landroidx/media3/common/m;

    if-nez v0, :cond_3db

    const/4 v5, 0x1

    goto :goto_3dc

    :cond_3db
    const/4 v5, 0x0

    :goto_3dc
    iput-object v14, v6, Lg0/s0;->s:Landroidx/media3/common/m;

    const/4 v1, 0x0

    move-object/from16 v0, p0

    move-wide/from16 v2, v17

    move-object v4, v14

    invoke-direct/range {v0 .. v5}, Lg0/s0;->b0(IJLandroidx/media3/common/m;I)V

    :cond_3e7
    :goto_3e7
    if-nez v13, :cond_404

    iget-object v0, v6, Lg0/s0;->t:Landroidx/media3/common/m;

    invoke-static {v0, v14}, La0/T;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3f2

    goto :goto_404

    :cond_3f2
    iget-object v0, v6, Lg0/s0;->t:Landroidx/media3/common/m;

    if-nez v0, :cond_3f8

    const/4 v5, 0x1

    goto :goto_3f9

    :cond_3f8
    const/4 v5, 0x0

    :goto_3f9
    iput-object v14, v6, Lg0/s0;->t:Landroidx/media3/common/m;

    const/4 v1, 0x2

    move-object/from16 v0, p0

    move-wide/from16 v2, v17

    move-object v4, v14

    invoke-direct/range {v0 .. v5}, Lg0/s0;->b0(IJLandroidx/media3/common/m;I)V

    :cond_404
    :goto_404
    iget-object v0, v6, Lg0/s0;->o:Lg0/s0$b;

    invoke-direct {v6, v0}, Lg0/s0;->W(Lg0/s0$b;)Z

    move-result v0

    if-eqz v0, :cond_437

    iget-object v0, v6, Lg0/s0;->o:Lg0/s0$b;

    iget-object v4, v0, Lg0/s0$b;->a:Landroidx/media3/common/m;

    iget v1, v4, Landroidx/media3/common/m;->u:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_437

    iget-object v1, v6, Lg0/s0;->r:Landroidx/media3/common/m;

    invoke-static {v1, v4}, La0/T;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_41f

    :goto_41d
    const/4 v0, 0x0

    goto :goto_435

    :cond_41f
    iget-object v1, v6, Lg0/s0;->r:Landroidx/media3/common/m;

    iget v0, v0, Lg0/s0$b;->b:I

    if-nez v1, :cond_429

    if-nez v0, :cond_429

    const/4 v5, 0x1

    goto :goto_42a

    :cond_429
    move v5, v0

    :goto_42a
    iput-object v4, v6, Lg0/s0;->r:Landroidx/media3/common/m;

    const/4 v1, 0x1

    move-object/from16 v0, p0

    move-wide/from16 v2, v17

    invoke-direct/range {v0 .. v5}, Lg0/s0;->b0(IJLandroidx/media3/common/m;I)V

    goto :goto_41d

    :goto_435
    iput-object v0, v6, Lg0/s0;->o:Lg0/s0$b;

    :cond_437
    iget-object v0, v6, Lg0/s0;->p:Lg0/s0$b;

    invoke-direct {v6, v0}, Lg0/s0;->W(Lg0/s0$b;)Z

    move-result v0

    if-eqz v0, :cond_465

    iget-object v0, v6, Lg0/s0;->p:Lg0/s0$b;

    iget-object v4, v0, Lg0/s0$b;->a:Landroidx/media3/common/m;

    iget-object v1, v6, Lg0/s0;->s:Landroidx/media3/common/m;

    invoke-static {v1, v4}, La0/T;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_44d

    :goto_44b
    const/4 v0, 0x0

    goto :goto_463

    :cond_44d
    iget-object v1, v6, Lg0/s0;->s:Landroidx/media3/common/m;

    iget v0, v0, Lg0/s0$b;->b:I

    if-nez v1, :cond_457

    if-nez v0, :cond_457

    const/4 v5, 0x1

    goto :goto_458

    :cond_457
    move v5, v0

    :goto_458
    iput-object v4, v6, Lg0/s0;->s:Landroidx/media3/common/m;

    const/4 v1, 0x0

    move-object/from16 v0, p0

    move-wide/from16 v2, v17

    invoke-direct/range {v0 .. v5}, Lg0/s0;->b0(IJLandroidx/media3/common/m;I)V

    goto :goto_44b

    :goto_463
    iput-object v0, v6, Lg0/s0;->p:Lg0/s0$b;

    :cond_465
    iget-object v0, v6, Lg0/s0;->q:Lg0/s0$b;

    invoke-direct {v6, v0}, Lg0/s0;->W(Lg0/s0$b;)Z

    move-result v0

    if-eqz v0, :cond_493

    iget-object v0, v6, Lg0/s0;->q:Lg0/s0$b;

    iget-object v4, v0, Lg0/s0$b;->a:Landroidx/media3/common/m;

    iget-object v1, v6, Lg0/s0;->t:Landroidx/media3/common/m;

    invoke-static {v1, v4}, La0/T;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_47b

    :goto_479
    const/4 v0, 0x0

    goto :goto_491

    :cond_47b
    iget-object v1, v6, Lg0/s0;->t:Landroidx/media3/common/m;

    iget v0, v0, Lg0/s0$b;->b:I

    if-nez v1, :cond_485

    if-nez v0, :cond_485

    const/4 v5, 0x1

    goto :goto_486

    :cond_485
    move v5, v0

    :goto_486
    iput-object v4, v6, Lg0/s0;->t:Landroidx/media3/common/m;

    const/4 v1, 0x2

    move-object/from16 v0, p0

    move-wide/from16 v2, v17

    invoke-direct/range {v0 .. v5}, Lg0/s0;->b0(IJLandroidx/media3/common/m;I)V

    goto :goto_479

    :goto_491
    iput-object v0, v6, Lg0/s0;->q:Lg0/s0$b;

    :cond_493
    invoke-static/range {v19 .. v19}, La0/z;->b(Landroid/content/Context;)La0/z;

    move-result-object v0

    invoke-virtual {v0}, La0/z;->c()I

    move-result v0

    packed-switch v0, :pswitch_data_592

    :pswitch_49e
    const/4 v5, 0x1

    goto :goto_4b3

    :pswitch_4a0
    const/4 v5, 0x7

    goto :goto_4b3

    :pswitch_4a2
    const/16 v5, 0x8

    goto :goto_4b3

    :pswitch_4a5
    const/4 v5, 0x3

    goto :goto_4b3

    :pswitch_4a7
    const/4 v5, 0x6

    goto :goto_4b3

    :pswitch_4a9
    const/4 v5, 0x5

    goto :goto_4b3

    :pswitch_4ab
    const/4 v5, 0x4

    goto :goto_4b3

    :pswitch_4ad
    const/4 v5, 0x2

    goto :goto_4b3

    :pswitch_4af
    const/16 v5, 0x9

    goto :goto_4b3

    :pswitch_4b2
    const/4 v5, 0x0

    :goto_4b3
    iget v0, v6, Lg0/s0;->m:I

    if-eq v5, v0, :cond_4ce

    iput v5, v6, Lg0/s0;->m:I

    invoke-static {}, Lg0/e0;->b()Landroid/media/metrics/NetworkEvent$Builder;

    move-result-object v0

    invoke-static {v0, v5}, Lg0/j0;->a(Landroid/media/metrics/NetworkEvent$Builder;I)Landroid/media/metrics/NetworkEvent$Builder;

    move-result-object v0

    sub-long v1, v17, v10

    invoke-static {v0, v1, v2}, Lg0/k0;->a(Landroid/media/metrics/NetworkEvent$Builder;J)Landroid/media/metrics/NetworkEvent$Builder;

    move-result-object v0

    invoke-static {v0}, Landroidx/core/view/b;->a(Landroid/media/metrics/NetworkEvent$Builder;)Landroid/media/metrics/NetworkEvent;

    move-result-object v0

    invoke-static {v15, v0}, Landroidx/core/view/d;->b(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/NetworkEvent;)V

    :cond_4ce
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->P()I

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_4d9

    const/4 v0, 0x0

    iput-boolean v0, v6, Lg0/s0;->u:Z

    goto :goto_4da

    :cond_4d9
    const/4 v0, 0x0

    :goto_4da
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->j()Landroidx/media3/exoplayer/p;

    move-result-object v1

    if-nez v1, :cond_4e3

    iput-boolean v0, v6, Lg0/s0;->w:Z

    goto :goto_4ec

    :cond_4e3
    invoke-virtual {v7, v8}, Lg0/b$b;->a(I)Z

    move-result v0

    if-eqz v0, :cond_4ec

    const/4 v0, 0x1

    iput-boolean v0, v6, Lg0/s0;->w:Z

    :cond_4ec
    :goto_4ec
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->P()I

    move-result v0

    iget-boolean v1, v6, Lg0/s0;->u:Z

    if-eqz v1, :cond_4f7

    const/4 v0, 0x5

    :goto_4f5
    const/4 v1, 0x1

    goto :goto_54a

    :cond_4f7
    iget-boolean v1, v6, Lg0/s0;->w:Z

    if-eqz v1, :cond_4fe

    const/16 v0, 0xd

    goto :goto_4f5

    :cond_4fe
    const/4 v1, 0x4

    if-ne v0, v1, :cond_504

    const/16 v0, 0xb

    goto :goto_4f5

    :cond_504
    const/16 v2, 0xc

    const/4 v3, 0x2

    if-ne v0, v3, :cond_527

    iget v0, v6, Lg0/s0;->l:I

    if-eqz v0, :cond_525

    if-eq v0, v3, :cond_525

    if-ne v0, v2, :cond_512

    goto :goto_525

    :cond_512
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->B()Z

    move-result v0

    if-nez v0, :cond_51a

    const/4 v0, 0x7

    goto :goto_4f5

    :cond_51a
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->u()I

    move-result v0

    if-eqz v0, :cond_522

    const/16 v20, 0xa

    :cond_522
    move/from16 v0, v20

    goto :goto_4f5

    :cond_525
    :goto_525
    const/4 v0, 0x2

    goto :goto_4f5

    :cond_527
    const/4 v3, 0x3

    if-ne v0, v3, :cond_53e

    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->B()Z

    move-result v0

    if-nez v0, :cond_532

    const/4 v0, 0x4

    goto :goto_4f5

    :cond_532
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/y;->u()I

    move-result v0

    if-eqz v0, :cond_539

    goto :goto_53b

    :cond_539
    const/16 v24, 0x3

    :goto_53b
    move/from16 v0, v24

    goto :goto_4f5

    :cond_53e
    const/4 v1, 0x1

    if-ne v0, v1, :cond_548

    iget v0, v6, Lg0/s0;->l:I

    if-eqz v0, :cond_548

    const/16 v0, 0xc

    goto :goto_54a

    :cond_548
    iget v0, v6, Lg0/s0;->l:I

    :goto_54a
    iget v2, v6, Lg0/s0;->l:I

    if-eq v2, v0, :cond_569

    iput v0, v6, Lg0/s0;->l:I

    iput-boolean v1, v6, Lg0/s0;->A:Z

    invoke-static {}, LP6/h;->a()Landroid/media/metrics/PlaybackStateEvent$Builder;

    move-result-object v0

    iget v1, v6, Lg0/s0;->l:I

    invoke-static {v0, v1}, LP6/h;->b(Landroid/media/metrics/PlaybackStateEvent$Builder;I)Landroid/media/metrics/PlaybackStateEvent$Builder;

    move-result-object v0

    sub-long v11, v17, v10

    invoke-static {v0, v11, v12}, LP6/i;->a(Landroid/media/metrics/PlaybackStateEvent$Builder;J)Landroid/media/metrics/PlaybackStateEvent$Builder;

    move-result-object v0

    invoke-static {v0}, LJ/e;->a(Landroid/media/metrics/PlaybackStateEvent$Builder;)Landroid/media/metrics/PlaybackStateEvent;

    move-result-object v0

    invoke-static {v15, v0}, Lg0/d0;->a(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackStateEvent;)V

    :cond_569
    const/16 v0, 0x404

    invoke-virtual {v7, v0}, Lg0/b$b;->a(I)Z

    move-result v1

    if-eqz v1, :cond_578

    invoke-virtual {v7, v0}, Lg0/b$b;->c(I)Lg0/b$a;

    move-result-object v0

    invoke-virtual {v9, v0}, Lg0/c0;->g(Lg0/b$a;)V

    :cond_578
    return-void

    nop

    :pswitch_data_57a
    .packed-switch 0x1772
        :pswitch_198
        :pswitch_195
        :pswitch_192
        :pswitch_18f
    .end packed-switch

    :pswitch_data_586
    .packed-switch 0x1772
        :pswitch_337
        :pswitch_335
        :pswitch_332
        :pswitch_32f
    .end packed-switch

    :pswitch_data_592
    .packed-switch 0x0
        :pswitch_4b2
        :pswitch_4af
        :pswitch_4ad
        :pswitch_4ab
        :pswitch_4a9
        :pswitch_4a7
        :pswitch_49e
        :pswitch_4a5
        :pswitch_49e
        :pswitch_4a2
        :pswitch_4a0
    .end packed-switch
.end method

.method public final synthetic Q(Lg0/b$a;)V
    .registers 2

    return-void
.end method

.method public final synthetic R(Lg0/b$a;Ljava/lang/Exception;)V
    .registers 3

    return-void
.end method

.method public final synthetic S(Lg0/b$a;Landroidx/media3/common/Metadata;)V
    .registers 3

    return-void
.end method

.method public final synthetic T(ILg0/b$a;)V
    .registers 3

    return-void
.end method

.method public final synthetic U(Lg0/b$a;Z)V
    .registers 3

    return-void
.end method

.method public final synthetic V(Lg0/b$a;Landroidx/media3/common/m;)V
    .registers 3

    return-void
.end method

.method public final Z()Landroid/media/metrics/LogSessionId;
    .registers 2

    iget-object v0, p0, Lg0/s0;->c:Landroid/media/metrics/PlaybackSession;

    invoke-static {v0}, LJ/g;->a(Landroid/media/metrics/PlaybackSession;)Landroid/media/metrics/LogSessionId;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic a(Lg0/b$a;Landroidx/media3/common/x;)V
    .registers 3

    return-void
.end method

.method public final synthetic b(Lg0/b$a;Ljava/lang/String;)V
    .registers 3

    return-void
.end method

.method public final c(Lg0/b$a;Lq0/h;)V
    .registers 7

    iget-object v0, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-nez v0, :cond_5

    return-void

    :cond_5
    new-instance v0, Lg0/s0$b;

    iget-object v1, p2, Lq0/h;->c:Landroidx/media3/common/m;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget-object v3, p0, Lg0/s0;->b:Lg0/c0;

    invoke-virtual {v3, p1, v2}, Lg0/c0;->k(Landroidx/media3/common/A;Landroidx/media3/exoplayer/source/o$b;)Ljava/lang/String;

    move-result-object p1

    iget v2, p2, Lq0/h;->d:I

    invoke-direct {v0, v1, v2, p1}, Lg0/s0$b;-><init>(Landroidx/media3/common/m;ILjava/lang/String;)V

    iget p1, p2, Lq0/h;->b:I

    if-eqz p1, :cond_32

    const/4 p2, 0x1

    if-eq p1, p2, :cond_2f

    const/4 p2, 0x2

    if-eq p1, p2, :cond_32

    const/4 p2, 0x3

    if-eq p1, p2, :cond_2c

    goto :goto_34

    :cond_2c
    iput-object v0, p0, Lg0/s0;->q:Lg0/s0$b;

    goto :goto_34

    :cond_2f
    iput-object v0, p0, Lg0/s0;->p:Lg0/s0$b;

    goto :goto_34

    :cond_32
    iput-object v0, p0, Lg0/s0;->o:Lg0/s0$b;

    :goto_34
    return-void
.end method

.method public final synthetic d(Lg0/b$a;Landroidx/media3/exoplayer/audio/h$a;)V
    .registers 3

    return-void
.end method

.method public final synthetic e(Lg0/b$a;Landroidx/media3/exoplayer/audio/h$a;)V
    .registers 3

    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .registers 2

    return-void
.end method

.method public final synthetic g(Lg0/b$a;Ljava/lang/String;)V
    .registers 3

    return-void
.end method

.method public final synthetic h(Lg0/b$a;Ljava/lang/String;)V
    .registers 3

    return-void
.end method

.method public final synthetic i(Lg0/b$a;)V
    .registers 2

    return-void
.end method

.method public final synthetic j(Lg0/b$a;)V
    .registers 2

    return-void
.end method

.method public final synthetic k(Lg0/b$a;Ljava/lang/String;)V
    .registers 3

    return-void
.end method

.method public final l(Lg0/b$a;Ljava/lang/String;)V
    .registers 3

    return-void
.end method

.method public final synthetic m(ILg0/b$a;)V
    .registers 3

    return-void
.end method

.method public final synthetic n(Lg0/b$a;Z)V
    .registers 3

    return-void
.end method

.method public final o(Lg0/b$a;Landroidx/media3/common/H;)V
    .registers 6

    iget-object p1, p0, Lg0/s0;->o:Lg0/s0$b;

    if-eqz p1, :cond_28

    iget-object v0, p1, Lg0/s0$b;->a:Landroidx/media3/common/m;

    iget v1, v0, Landroidx/media3/common/m;->u:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_28

    invoke-virtual {v0}, Landroidx/media3/common/m;->a()Landroidx/media3/common/m$a;

    move-result-object v0

    iget v1, p2, Landroidx/media3/common/H;->a:I

    invoke-virtual {v0, v1}, Landroidx/media3/common/m$a;->v0(I)V

    iget p2, p2, Landroidx/media3/common/H;->b:I

    invoke-virtual {v0, p2}, Landroidx/media3/common/m$a;->Y(I)V

    invoke-virtual {v0}, Landroidx/media3/common/m$a;->K()Landroidx/media3/common/m;

    move-result-object p2

    new-instance v0, Lg0/s0$b;

    iget v1, p1, Lg0/s0$b;->b:I

    iget-object p1, p1, Lg0/s0$b;->c:Ljava/lang/String;

    invoke-direct {v0, p2, v1, p1}, Lg0/s0$b;-><init>(Landroidx/media3/common/m;ILjava/lang/String;)V

    iput-object v0, p0, Lg0/s0;->o:Lg0/s0$b;

    :cond_28
    return-void
.end method

.method public final synthetic p(ILg0/b$a;)V
    .registers 3

    return-void
.end method

.method public final q(Lg0/b$a;Landroidx/media3/common/w;)V
    .registers 3

    iput-object p2, p0, Lg0/s0;->n:Landroidx/media3/common/w;

    return-void
.end method

.method public final r(Lg0/b$a;Lq0/h;Ljava/io/IOException;)V
    .registers 4

    iget p1, p2, Lq0/h;->a:I

    iput p1, p0, Lg0/s0;->v:I

    return-void
.end method

.method public final synthetic s(Lg0/b$a;Z)V
    .registers 3

    return-void
.end method

.method public final synthetic t(Lg0/b$a;Landroidx/media3/common/m;)V
    .registers 3

    return-void
.end method

.method public final synthetic u(Lg0/b$a;IJJ)V
    .registers 7

    return-void
.end method

.method public final v(Lg0/b$a;Ljava/lang/String;Z)V
    .registers 4

    iget-object p1, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-eqz p1, :cond_a

    invoke-virtual {p1}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result p1

    if-nez p1, :cond_16

    :cond_a
    iget-object p1, p0, Lg0/s0;->i:Ljava/lang/String;

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_13

    goto :goto_16

    :cond_13
    invoke-direct {p0}, Lg0/s0;->Y()V

    :cond_16
    :goto_16
    iget-object p1, p0, Lg0/s0;->g:Ljava/util/HashMap;

    invoke-virtual {p1, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Lg0/s0;->h:Ljava/util/HashMap;

    invoke-virtual {p1, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final synthetic w(Lg0/b$a;Ljava/lang/Object;)V
    .registers 3

    return-void
.end method

.method public final synthetic x(Lg0/b$a;Lq0/h;)V
    .registers 3

    return-void
.end method

.method public final y(ILandroidx/media3/common/y$d;Landroidx/media3/common/y$d;Lg0/b$a;)V
    .registers 5

    const/4 p2, 0x1

    if-ne p1, p2, :cond_5

    iput-boolean p2, p0, Lg0/s0;->u:Z

    :cond_5
    iput p1, p0, Lg0/s0;->k:I

    return-void
.end method

.method public final z(Lg0/b$a;IJ)V
    .registers 13

    iget-object v0, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-eqz v0, :cond_3e

    iget-object p1, p1, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget-object v1, p0, Lg0/s0;->b:Lg0/c0;

    invoke-virtual {v1, p1, v0}, Lg0/c0;->k(Landroidx/media3/common/A;Landroidx/media3/exoplayer/source/o$b;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lg0/s0;->h:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    iget-object v2, p0, Lg0/s0;->g:Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    const-wide/16 v4, 0x0

    if-nez v1, :cond_22

    move-wide v6, v4

    goto :goto_26

    :cond_22
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    :goto_26
    add-long/2addr v6, p3

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-nez v3, :cond_31

    goto :goto_35

    :cond_31
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    :goto_35
    int-to-long p2, p2

    add-long/2addr v4, p2

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    invoke-virtual {v2, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3e
    return-void
.end method
