.class public final Lg0/c0;
.super Ljava/lang/Object;
.source "DefaultPlaybackSessionManager.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lg0/c0$a;
    }
.end annotation


# static fields
.field private static final h:Ljava/util/Random;


# instance fields
.field private final a:Landroidx/media3/common/A$c;

.field private final b:Landroidx/media3/common/A$b;

.field private final c:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lg0/c0$a;",
            ">;"
        }
    .end annotation
.end field

.field private d:Lg0/t0;

.field private e:Landroidx/media3/common/A;

.field private f:Ljava/lang/String;

.field private g:J


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    sput-object v0, Lg0/c0;->h:Ljava/util/Random;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/media3/common/A$c;

    invoke-direct {v0}, Landroidx/media3/common/A$c;-><init>()V

    iput-object v0, p0, Lg0/c0;->a:Landroidx/media3/common/A$c;

    new-instance v0, Landroidx/media3/common/A$b;

    invoke-direct {v0}, Landroidx/media3/common/A$b;-><init>()V

    iput-object v0, p0, Lg0/c0;->b:Landroidx/media3/common/A$b;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lg0/c0;->c:Ljava/util/HashMap;

    sget-object v0, Landroidx/media3/common/A;->a:Landroidx/media3/common/A;

    iput-object v0, p0, Lg0/c0;->e:Landroidx/media3/common/A;

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lg0/c0;->g:J

    return-void
.end method

.method public static a()Ljava/lang/String;
    .registers 2

    const/16 v0, 0xc

    new-array v0, v0, [B

    sget-object v1, Lg0/c0;->h:Ljava/util/Random;

    invoke-virtual {v1, v0}, Ljava/util/Random;->nextBytes([B)V

    const/16 v1, 0xa

    invoke-static {v0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic b(Lg0/c0;)J
    .registers 3

    invoke-direct {p0}, Lg0/c0;->i()J

    move-result-wide v0

    return-wide v0
.end method

.method static synthetic c(Lg0/c0;)Landroidx/media3/common/A$c;
    .registers 1

    iget-object p0, p0, Lg0/c0;->a:Landroidx/media3/common/A$c;

    return-object p0
.end method

.method static synthetic d(Lg0/c0;)Landroidx/media3/common/A$b;
    .registers 1

    iget-object p0, p0, Lg0/c0;->b:Landroidx/media3/common/A$b;

    return-object p0
.end method

.method private f(Lg0/c0$a;)V
    .registers 7

    invoke-static {p1}, Lg0/c0$a;->b(Lg0/c0$a;)J

    move-result-wide v0

    const-wide/16 v2, -0x1

    cmp-long v4, v0, v2

    if-eqz v4, :cond_10

    invoke-static {p1}, Lg0/c0$a;->b(Lg0/c0$a;)J

    move-result-wide v0

    iput-wide v0, p0, Lg0/c0;->g:J

    :cond_10
    const/4 p1, 0x0

    iput-object p1, p0, Lg0/c0;->f:Ljava/lang/String;

    return-void
.end method

.method private i()J
    .registers 7

    iget-object v0, p0, Lg0/c0;->c:Ljava/util/HashMap;

    iget-object v1, p0, Lg0/c0;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lg0/c0$a;

    if-eqz v0, :cond_1b

    invoke-static {v0}, Lg0/c0$a;->b(Lg0/c0$a;)J

    move-result-wide v1

    const-wide/16 v3, -0x1

    cmp-long v5, v1, v3

    if-eqz v5, :cond_1b

    invoke-static {v0}, Lg0/c0$a;->b(Lg0/c0$a;)J

    move-result-wide v0

    goto :goto_20

    :cond_1b
    iget-wide v0, p0, Lg0/c0;->g:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    :goto_20
    return-wide v0
.end method

.method private j(ILandroidx/media3/exoplayer/source/o$b;)Lg0/c0$a;
    .registers 14

    iget-object v0, p0, Lg0/c0;->c:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v2, 0x0

    const-wide v3, 0x7fffffffffffffffL

    :cond_10
    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_49

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lg0/c0$a;

    invoke-virtual {v5, p1, p2}, Lg0/c0$a;->k(ILandroidx/media3/exoplayer/source/o$b;)V

    invoke-virtual {v5, p1, p2}, Lg0/c0$a;->i(ILandroidx/media3/exoplayer/source/o$b;)Z

    move-result v6

    if-eqz v6, :cond_10

    invoke-static {v5}, Lg0/c0$a;->b(Lg0/c0$a;)J

    move-result-wide v6

    const-wide/16 v8, -0x1

    cmp-long v10, v6, v8

    if-eqz v10, :cond_46

    cmp-long v8, v6, v3

    if-gez v8, :cond_34

    goto :goto_46

    :cond_34
    if-nez v8, :cond_10

    sget v6, La0/T;->a:I

    invoke-static {v2}, Lg0/c0$a;->h(Lg0/c0$a;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object v6

    if-eqz v6, :cond_10

    invoke-static {v5}, Lg0/c0$a;->h(Lg0/c0$a;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object v6

    if-eqz v6, :cond_10

    move-object v2, v5

    goto :goto_10

    :cond_46
    :goto_46
    move-object v2, v5

    move-wide v3, v6

    goto :goto_10

    :cond_49
    if-nez v2, :cond_57

    invoke-static {}, Lg0/c0;->a()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lg0/c0$a;

    invoke-direct {v2, p0, v1, p1, p2}, Lg0/c0$a;-><init>(Lg0/c0;Ljava/lang/String;ILandroidx/media3/exoplayer/source/o$b;)V

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_57
    return-object v2
.end method

.method private m(Lg0/b$a;)V
    .registers 9

    iget-object v0, p1, Lg0/b$a;->b:Landroidx/media3/common/A;

    invoke-virtual {v0}, Landroidx/media3/common/A;->q()Z

    move-result v0

    iget-object v1, p0, Lg0/c0;->c:Ljava/util/HashMap;

    if-eqz v0, :cond_1b

    iget-object p1, p0, Lg0/c0;->f:Ljava/lang/String;

    if-eqz p1, :cond_1a

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lg0/c0$a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, p1}, Lg0/c0;->f(Lg0/c0$a;)V

    :cond_1a
    return-void

    :cond_1b
    iget-object v0, p0, Lg0/c0;->f:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lg0/c0$a;

    iget v1, p1, Lg0/b$a;->c:I

    iget-object v2, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {p0, v1, v2}, Lg0/c0;->j(ILandroidx/media3/exoplayer/source/o$b;)Lg0/c0$a;

    move-result-object v3

    invoke-static {v3}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lg0/c0;->f:Ljava/lang/String;

    invoke-virtual {p0, p1}, Lg0/c0;->n(Lg0/b$a;)V

    if-eqz v2, :cond_76

    invoke-virtual {v2}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result p1

    if-eqz p1, :cond_76

    iget-wide v3, v2, Landroidx/media3/exoplayer/source/o$b;->d:J

    if-eqz v0, :cond_62

    invoke-static {v0}, Lg0/c0$a;->b(Lg0/c0$a;)J

    move-result-wide v5

    cmp-long p1, v5, v3

    if-nez p1, :cond_62

    invoke-static {v0}, Lg0/c0$a;->h(Lg0/c0$a;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object p1

    if-eqz p1, :cond_62

    invoke-static {v0}, Lg0/c0$a;->h(Lg0/c0$a;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object p1

    iget p1, p1, Landroidx/media3/exoplayer/source/o$b;->b:I

    iget v5, v2, Landroidx/media3/exoplayer/source/o$b;->b:I

    if-ne p1, v5, :cond_62

    invoke-static {v0}, Lg0/c0$a;->h(Lg0/c0$a;)Landroidx/media3/exoplayer/source/o$b;

    move-result-object p1

    iget p1, p1, Landroidx/media3/exoplayer/source/o$b;->c:I

    iget v0, v2, Landroidx/media3/exoplayer/source/o$b;->c:I

    if-eq p1, v0, :cond_76

    :cond_62
    new-instance p1, Landroidx/media3/exoplayer/source/o$b;

    iget-object v0, v2, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    invoke-direct {p1, v0, v3, v4}, Landroidx/media3/exoplayer/source/o$b;-><init>(Ljava/lang/Object;J)V

    invoke-direct {p0, v1, p1}, Lg0/c0;->j(ILandroidx/media3/exoplayer/source/o$b;)Lg0/c0$a;

    move-result-object p1

    iget-object v0, p0, Lg0/c0;->d:Lg0/t0;

    invoke-static {p1}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Lg0/t0;->f(Ljava/lang/String;)V

    :cond_76
    return-void
.end method


# virtual methods
.method public final declared-synchronized e(Lg0/b$a;Ljava/lang/String;)Z
    .registers 5

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lg0/c0;->c:Ljava/util/HashMap;

    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lg0/c0$a;
    :try_end_9
    .catchall {:try_start_1 .. :try_end_9} :catchall_1f

    if-nez p2, :cond_e

    monitor-exit p0

    const/4 p1, 0x0

    return p1

    :cond_e
    :try_start_e
    iget v0, p1, Lg0/b$a;->c:I

    iget-object v1, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-virtual {p2, v0, v1}, Lg0/c0$a;->k(ILandroidx/media3/exoplayer/source/o$b;)V

    iget v0, p1, Lg0/b$a;->c:I

    iget-object p1, p1, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-virtual {p2, v0, p1}, Lg0/c0$a;->i(ILandroidx/media3/exoplayer/source/o$b;)Z

    move-result p1
    :try_end_1d
    .catchall {:try_start_e .. :try_end_1d} :catchall_1f

    monitor-exit p0

    return p1

    :catchall_1f
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized g(Lg0/b$a;)V
    .registers 6

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lg0/c0;->f:Ljava/lang/String;

    if-eqz v0, :cond_16

    iget-object v1, p0, Lg0/c0;->c:Ljava/util/HashMap;

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lg0/c0$a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, v0}, Lg0/c0;->f(Lg0/c0$a;)V

    goto :goto_16

    :catchall_14
    move-exception p1

    goto :goto_44

    :cond_16
    :goto_16
    iget-object v0, p0, Lg0/c0;->c:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_20
    :goto_20
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_42

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lg0/c0$a;

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    invoke-static {v1}, Lg0/c0$a;->d(Lg0/c0$a;)Z

    move-result v2

    if-eqz v2, :cond_20

    iget-object v2, p0, Lg0/c0;->d:Lg0/t0;

    if-eqz v2, :cond_20

    invoke-static {v1}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    invoke-interface {v2, p1, v1, v3}, Lg0/t0;->v(Lg0/b$a;Ljava/lang/String;Z)V
    :try_end_41
    .catchall {:try_start_1 .. :try_end_41} :catchall_14

    goto :goto_20

    :cond_42
    monitor-exit p0

    return-void

    :goto_44
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized h()Ljava/lang/String;
    .registers 2

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lg0/c0;->f:Ljava/lang/String;
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_5

    monitor-exit p0

    return-object v0

    :catchall_5
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized k(Landroidx/media3/common/A;Landroidx/media3/exoplayer/source/o$b;)Ljava/lang/String;
    .registers 5

    monitor-enter p0

    :try_start_1
    iget-object v0, p2, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    iget-object v1, p0, Lg0/c0;->b:Landroidx/media3/common/A$b;

    invoke-virtual {p1, v0, v1}, Landroidx/media3/common/A;->h(Ljava/lang/Object;Landroidx/media3/common/A$b;)Landroidx/media3/common/A$b;

    move-result-object p1

    iget p1, p1, Landroidx/media3/common/A$b;->c:I

    invoke-direct {p0, p1, p2}, Lg0/c0;->j(ILandroidx/media3/exoplayer/source/o$b;)Lg0/c0$a;

    move-result-object p1

    invoke-static {p1}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object p1
    :try_end_13
    .catchall {:try_start_1 .. :try_end_13} :catchall_15

    monitor-exit p0

    return-object p1

    :catchall_15
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final l(Lg0/t0;)V
    .registers 2

    iput-object p1, p0, Lg0/c0;->d:Lg0/t0;

    return-void
.end method

.method public final declared-synchronized n(Lg0/b$a;)V
    .registers 23

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    monitor-enter p0

    :try_start_5
    iget-object v2, v1, Lg0/c0;->d:Lg0/t0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v0, Lg0/b$a;->b:Landroidx/media3/common/A;

    invoke-virtual {v2}, Landroidx/media3/common/A;->q()Z

    move-result v2
    :try_end_10
    .catchall {:try_start_5 .. :try_end_10} :catchall_44

    if-eqz v2, :cond_14

    monitor-exit p0

    return-void

    :cond_14
    :try_start_14
    iget-object v2, v0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-eqz v2, :cond_47

    iget-wide v2, v2, Landroidx/media3/exoplayer/source/o$b;->d:J

    invoke-direct/range {p0 .. p0}, Lg0/c0;->i()J

    move-result-wide v4
    :try_end_1e
    .catchall {:try_start_14 .. :try_end_1e} :catchall_44

    cmp-long v6, v2, v4

    if-gez v6, :cond_24

    monitor-exit p0

    return-void

    :cond_24
    :try_start_24
    iget-object v2, v1, Lg0/c0;->c:Ljava/util/HashMap;

    iget-object v3, v1, Lg0/c0;->f:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lg0/c0$a;

    if-eqz v2, :cond_47

    invoke-static {v2}, Lg0/c0$a;->b(Lg0/c0$a;)J

    move-result-wide v3

    const-wide/16 v5, -0x1

    cmp-long v7, v3, v5

    if-nez v7, :cond_47

    invoke-static {v2}, Lg0/c0$a;->c(Lg0/c0$a;)I

    move-result v2

    iget v3, v0, Lg0/b$a;->c:I
    :try_end_40
    .catchall {:try_start_24 .. :try_end_40} :catchall_44

    if-eq v2, v3, :cond_47

    monitor-exit p0

    return-void

    :catchall_44
    move-exception v0

    goto/16 :goto_10b

    :cond_47
    :try_start_47
    iget v2, v0, Lg0/b$a;->c:I

    iget-object v3, v0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    invoke-direct {v1, v2, v3}, Lg0/c0;->j(ILandroidx/media3/exoplayer/source/o$b;)Lg0/c0$a;

    move-result-object v2

    iget-object v3, v1, Lg0/c0;->f:Ljava/lang/String;

    if-nez v3, :cond_59

    invoke-static {v2}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v1, Lg0/c0;->f:Ljava/lang/String;

    :cond_59
    iget-object v3, v0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    if-eqz v3, :cond_d2

    invoke-virtual {v3}, Landroidx/media3/exoplayer/source/o$b;->b()Z

    move-result v3

    if-eqz v3, :cond_d2

    new-instance v9, Landroidx/media3/exoplayer/source/o$b;

    iget-object v3, v0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iget-object v4, v3, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    iget-wide v5, v3, Landroidx/media3/exoplayer/source/o$b;->d:J

    iget v3, v3, Landroidx/media3/exoplayer/source/o$b;->b:I

    invoke-direct {v9, v3, v5, v6, v4}, Landroidx/media3/exoplayer/source/o$b;-><init>(IJLjava/lang/Object;)V

    iget v3, v0, Lg0/b$a;->c:I

    invoke-direct {v1, v3, v9}, Lg0/c0;->j(ILandroidx/media3/exoplayer/source/o$b;)Lg0/c0$a;

    move-result-object v3

    invoke-static {v3}, Lg0/c0$a;->d(Lg0/c0$a;)Z

    move-result v4

    if-nez v4, :cond_d2

    invoke-static {v3}, Lg0/c0$a;->e(Lg0/c0$a;)V

    iget-object v4, v0, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget-object v5, v0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iget-object v5, v5, Landroidx/media3/exoplayer/source/o$b;->a:Ljava/lang/Object;

    iget-object v6, v1, Lg0/c0;->b:Landroidx/media3/common/A$b;

    invoke-virtual {v4, v5, v6}, Landroidx/media3/common/A;->h(Ljava/lang/Object;Landroidx/media3/common/A$b;)Landroidx/media3/common/A$b;

    iget-object v4, v1, Lg0/c0;->b:Landroidx/media3/common/A$b;

    iget-object v5, v0, Lg0/b$a;->d:Landroidx/media3/exoplayer/source/o$b;

    iget v5, v5, Landroidx/media3/exoplayer/source/o$b;->b:I

    invoke-virtual {v4, v5}, Landroidx/media3/common/A$b;->f(I)J

    move-result-wide v4

    invoke-static {v4, v5}, La0/T;->j0(J)J

    move-result-wide v4

    iget-object v6, v1, Lg0/c0;->b:Landroidx/media3/common/A$b;

    iget-wide v6, v6, Landroidx/media3/common/A$b;->e:J

    invoke-static {v6, v7}, La0/T;->j0(J)J

    move-result-wide v6

    add-long/2addr v4, v6

    const-wide/16 v6, 0x0

    invoke-static {v6, v7, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v10

    new-instance v15, Lg0/b$a;

    iget-wide v5, v0, Lg0/b$a;->a:J

    iget-object v7, v0, Lg0/b$a;->b:Landroidx/media3/common/A;

    iget v8, v0, Lg0/b$a;->c:I

    iget-object v12, v0, Lg0/b$a;->f:Landroidx/media3/common/A;

    iget v13, v0, Lg0/b$a;->g:I

    iget-object v14, v0, Lg0/b$a;->h:Landroidx/media3/exoplayer/source/o$b;

    move-object/from16 v19, v2

    move-object/from16 v20, v3

    iget-wide v2, v0, Lg0/b$a;->i:J

    move-wide/from16 v16, v2

    iget-wide v2, v0, Lg0/b$a;->j:J

    move-object v4, v15

    move-object v0, v15

    move-wide/from16 v15, v16

    move-wide/from16 v17, v2

    invoke-direct/range {v4 .. v18}, Lg0/b$a;-><init>(JLandroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;JLandroidx/media3/common/A;ILandroidx/media3/exoplayer/source/o$b;JJ)V

    iget-object v2, v1, Lg0/c0;->d:Lg0/t0;

    invoke-static/range {v20 .. v20}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v0, v3}, Lg0/t0;->l(Lg0/b$a;Ljava/lang/String;)V

    goto :goto_d4

    :cond_d2
    move-object/from16 v19, v2

    :goto_d4
    invoke-static/range {v19 .. v19}, Lg0/c0$a;->d(Lg0/c0$a;)Z

    move-result v0

    if-nez v0, :cond_e9

    invoke-static/range {v19 .. v19}, Lg0/c0$a;->e(Lg0/c0$a;)V

    iget-object v0, v1, Lg0/c0;->d:Lg0/t0;

    invoke-static/range {v19 .. v19}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v3, p1

    invoke-interface {v0, v3, v2}, Lg0/t0;->l(Lg0/b$a;Ljava/lang/String;)V

    goto :goto_eb

    :cond_e9
    move-object/from16 v3, p1

    :goto_eb
    invoke-static/range {v19 .. v19}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Lg0/c0;->f:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_109

    invoke-static/range {v19 .. v19}, Lg0/c0$a;->f(Lg0/c0$a;)Z

    move-result v0

    if-nez v0, :cond_109

    invoke-static/range {v19 .. v19}, Lg0/c0$a;->g(Lg0/c0$a;)V

    iget-object v0, v1, Lg0/c0;->d:Lg0/t0;

    invoke-static/range {v19 .. v19}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v3, v2}, Lg0/t0;->N(Lg0/b$a;Ljava/lang/String;)V
    :try_end_109
    .catchall {:try_start_47 .. :try_end_109} :catchall_44

    :cond_109
    monitor-exit p0

    return-void

    :goto_10b
    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized o(ILg0/b$a;)V
    .registers 9

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lg0/c0;->d:Lg0/t0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p1, :cond_c

    const/4 p1, 0x1

    goto :goto_d

    :cond_c
    const/4 p1, 0x0

    :goto_d
    iget-object v2, p0, Lg0/c0;->c:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_17
    :goto_17
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lg0/c0$a;

    invoke-virtual {v3, p2}, Lg0/c0$a;->j(Lg0/b$a;)Z

    move-result v4

    if-eqz v4, :cond_17

    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    invoke-static {v3}, Lg0/c0$a;->d(Lg0/c0$a;)Z

    move-result v4

    if-eqz v4, :cond_17

    invoke-static {v3}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lg0/c0;->f:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz p1, :cond_4a

    if-eqz v4, :cond_4a

    invoke-static {v3}, Lg0/c0$a;->f(Lg0/c0$a;)Z

    move-result v5

    if-eqz v5, :cond_4a

    const/4 v5, 0x1

    goto :goto_4b

    :catchall_48
    move-exception p1

    goto :goto_5f

    :cond_4a
    const/4 v5, 0x0

    :goto_4b
    if-eqz v4, :cond_50

    invoke-direct {p0, v3}, Lg0/c0;->f(Lg0/c0$a;)V

    :cond_50
    iget-object v4, p0, Lg0/c0;->d:Lg0/t0;

    invoke-static {v3}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v4, p2, v3, v5}, Lg0/t0;->v(Lg0/b$a;Ljava/lang/String;Z)V

    goto :goto_17

    :cond_5a
    invoke-direct {p0, p2}, Lg0/c0;->m(Lg0/b$a;)V
    :try_end_5d
    .catchall {:try_start_1 .. :try_end_5d} :catchall_48

    monitor-exit p0

    return-void

    :goto_5f
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized p(Lg0/b$a;)V
    .registers 7

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lg0/c0;->d:Lg0/t0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lg0/c0;->e:Landroidx/media3/common/A;

    iget-object v1, p1, Lg0/b$a;->b:Landroidx/media3/common/A;

    iput-object v1, p0, Lg0/c0;->e:Landroidx/media3/common/A;

    iget-object v1, p0, Lg0/c0;->c:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_16
    :goto_16
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_56

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lg0/c0$a;

    iget-object v3, p0, Lg0/c0;->e:Landroidx/media3/common/A;

    invoke-virtual {v2, v0, v3}, Lg0/c0$a;->l(Landroidx/media3/common/A;Landroidx/media3/common/A;)Z

    move-result v3

    if-eqz v3, :cond_33

    invoke-virtual {v2, p1}, Lg0/c0$a;->j(Lg0/b$a;)Z

    move-result v3

    if-eqz v3, :cond_16

    goto :goto_33

    :catchall_31
    move-exception p1

    goto :goto_5b

    :cond_33
    :goto_33
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    invoke-static {v2}, Lg0/c0$a;->d(Lg0/c0$a;)Z

    move-result v3

    if-eqz v3, :cond_16

    invoke-static {v2}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lg0/c0;->f:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4b

    invoke-direct {p0, v2}, Lg0/c0;->f(Lg0/c0$a;)V

    :cond_4b
    iget-object v3, p0, Lg0/c0;->d:Lg0/t0;

    invoke-static {v2}, Lg0/c0$a;->a(Lg0/c0$a;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    invoke-interface {v3, p1, v2, v4}, Lg0/t0;->v(Lg0/b$a;Ljava/lang/String;Z)V

    goto :goto_16

    :cond_56
    invoke-direct {p0, p1}, Lg0/c0;->m(Lg0/b$a;)V
    :try_end_59
    .catchall {:try_start_1 .. :try_end_59} :catchall_31

    monitor-exit p0

    return-void

    :goto_5b
    monitor-exit p0

    throw p1
.end method
