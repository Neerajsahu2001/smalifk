.class public final synthetic Lg0/f;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements La0/o$a;


# instance fields
.field public final synthetic a:Lg0/b$a;

.field public final synthetic b:F


# direct methods
.method public synthetic constructor <init>(Lg0/b$a;F)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/f;->a:Lg0/b$a;

    iput p2, p0, Lg0/f;->b:F

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Lg0/b;

    iget-object v0, p0, Lg0/f;->a:Lg0/b$a;

    iget v1, p0, Lg0/f;->b:F

    invoke-interface {p1, v0, v1}, Lg0/b;->L(Lg0/b$a;F)V

    return-void
.end method
