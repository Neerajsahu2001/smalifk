.class final LG0/e$a;
.super Ly0/x;
.source "StartOffsetExtractorOutput.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LG0/e;->n(Ly0/E;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Ly0/E;

.field final synthetic c:LG0/e;


# direct methods
.method constructor <init>(LG0/e;Ly0/E;Ly0/E;)V
    .registers 4

    iput-object p1, p0, LG0/e$a;->c:LG0/e;

    iput-object p3, p0, LG0/e$a;->b:Ly0/E;

    invoke-direct {p0, p2}, Ly0/x;-><init>(Ly0/E;)V

    return-void
.end method


# virtual methods
.method public final d(J)Ly0/E$a;
    .registers 12

    iget-object v0, p0, LG0/e$a;->b:Ly0/E;

    invoke-interface {v0, p1, p2}, Ly0/E;->d(J)Ly0/E$a;

    move-result-object p1

    new-instance p2, Ly0/E$a;

    new-instance v0, Ly0/F;

    iget-object v1, p1, Ly0/E$a;->a:Ly0/F;

    iget-wide v2, v1, Ly0/F;->a:J

    iget-wide v4, v1, Ly0/F;->b:J

    iget-object v1, p0, LG0/e$a;->c:LG0/e;

    invoke-static {v1}, LG0/e;->a(LG0/e;)J

    move-result-wide v6

    add-long/2addr v4, v6

    invoke-direct {v0, v2, v3, v4, v5}, Ly0/F;-><init>(JJ)V

    new-instance v2, Ly0/F;

    iget-object p1, p1, Ly0/E$a;->b:Ly0/F;

    iget-wide v3, p1, Ly0/F;->a:J

    iget-wide v5, p1, Ly0/F;->b:J

    invoke-static {v1}, LG0/e;->a(LG0/e;)J

    move-result-wide v7

    add-long/2addr v5, v7

    invoke-direct {v2, v3, v4, v5, v6}, Ly0/F;-><init>(JJ)V

    invoke-direct {p2, v0, v2}, Ly0/E$a;-><init>(Ly0/F;Ly0/F;)V

    return-object p2
.end method
