.class public final Lg0/u0$a;
.super Ljava/lang/Object;
.source "PlaybackStats.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg0/u0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Lg0/b$a;

.field public final b:Ljava/lang/Exception;


# direct methods
.method public constructor <init>(Lg0/b$a;Ljava/lang/Exception;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/u0$a;->a:Lg0/b$a;

    iput-object p2, p0, Lg0/u0$a;->b:Ljava/lang/Exception;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    const/4 v0, 0x0

    if-eqz p1, :cond_26

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-class v2, Lg0/u0$a;

    if-eq v2, v1, :cond_10

    goto :goto_26

    :cond_10
    check-cast p1, Lg0/u0$a;

    iget-object v1, p0, Lg0/u0$a;->a:Lg0/b$a;

    iget-object v2, p1, Lg0/u0$a;->a:Lg0/b$a;

    invoke-virtual {v1, v2}, Lg0/b$a;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d

    return v0

    :cond_1d
    iget-object v0, p0, Lg0/u0$a;->b:Ljava/lang/Exception;

    iget-object p1, p1, Lg0/u0$a;->b:Ljava/lang/Exception;

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_26
    :goto_26
    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lg0/u0$a;->a:Lg0/b$a;

    invoke-virtual {v0}, Lg0/b$a;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lg0/u0$a;->b:Ljava/lang/Exception;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
