.class public interface abstract Lb6/a;
.super Ljava/lang/Object;
.source "SearchByDialogFragmentCallback.kt"

# interfaces
.implements Lcom/flipkart/android/newmultiwidget/ui/widgets/q;


# virtual methods
.method public abstract attachObserver(Landroidx/lifecycle/J;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/lifecycle/J<",
            "Lcom/flipkart/android/voice/i;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract synthetic getCurrentMarketplace()Ljava/lang/String;
.end method

.method public abstract synthetic getLifecycle()Landroidx/lifecycle/q;
.end method

.method public abstract getNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;
.end method

.method public abstract synthetic getOverLayListener()Lcom/flipkart/android/newmultiwidget/t;
.end method

.method public abstract synthetic getPageDetails()Lcom/flipkart/android/fragments/B$h;
.end method

.method public abstract synthetic getSatyabhamaBuilder()Lii/c;
.end method

.method public abstract synthetic getScreenName()Ljava/lang/String;
.end method

.method public abstract synthetic initYoutubePlayer(Lcom/flipkart/youtubeview/YouTubePlayerView;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Boolean;Lxi/a;)V
.end method

.method public abstract isBinded()Z
.end method

.method public abstract openSearch(Ljava/lang/String;Ljava/lang/String;Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;)V
.end method

.method public abstract responseReceived()V
.end method

.method public abstract synthetic showPermissionDialog(Lcom/flipkart/android/permissions/g$b;)V
.end method

.method public abstract startListening(Lb6/d$a;)V
.end method

.method public abstract stopListening()V
.end method

.method public abstract widgetRendered()V
.end method
