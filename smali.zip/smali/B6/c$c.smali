.class final LB6/c$c;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactDataProvider.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB6/c;->fetchPageData(Ljava/lang/String;ZZ)Lzp/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lzp/c<",
        "-",
        "Ly6/b;",
        ">;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.repository.ReactDataProvider$fetchPageData$1"
    f = "ReactDataProvider.kt"
    l = {
        0x46,
        0x4f,
        0x59
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

.field b:Ly6/a;

.field c:I

.field d:I

.field e:I

.field private synthetic f:Ljava/lang/Object;

.field final synthetic g:LB6/c;

.field final synthetic h:Ljava/lang/String;

.field final synthetic i:Z

.field final synthetic j:Z


# direct methods
.method constructor <init>(LB6/c;Ljava/lang/String;ZZLXn/d;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LB6/c;",
            "Ljava/lang/String;",
            "ZZ",
            "LXn/d<",
            "-",
            "LB6/c$c;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LB6/c$c;->g:LB6/c;

    iput-object p2, p0, LB6/c$c;->h:Ljava/lang/String;

    iput-boolean p3, p0, LB6/c$c;->i:Z

    iput-boolean p4, p0, LB6/c$c;->j:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance v6, LB6/c$c;

    iget-boolean v3, p0, LB6/c$c;->i:Z

    iget-boolean v4, p0, LB6/c$c;->j:Z

    iget-object v1, p0, LB6/c$c;->g:LB6/c;

    iget-object v2, p0, LB6/c$c;->h:Ljava/lang/String;

    move-object v0, v6

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, LB6/c$c;-><init>(LB6/c;Ljava/lang/String;ZZLXn/d;)V

    iput-object p1, v6, LB6/c$c;->f:Ljava/lang/Object;

    return-object v6
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lzp/c;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LB6/c$c;->invoke(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lzp/c;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/c<",
            "-",
            "Ly6/b;",
            ">;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LB6/c$c;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LB6/c$c;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LB6/c$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 22

    move-object/from16 v0, p0

    sget-object v1, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v2, v0, LB6/c$c;->e:I

    iget-boolean v3, v0, LB6/c$c;->i:Z

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v6, v0, LB6/c$c;->h:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v9, 0x1

    iget-object v10, v0, LB6/c$c;->g:LB6/c;

    if-eqz v2, :cond_43

    if-eq v2, v9, :cond_36

    if-eq v2, v5, :cond_25

    if-ne v2, v4, :cond_1d

    invoke-static/range {p1 .. p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto/16 :goto_142

    :cond_1d
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_25
    iget v2, v0, LB6/c$c;->d:I

    iget v5, v0, LB6/c$c;->c:I

    iget-object v11, v0, LB6/c$c;->b:Ly6/a;

    iget-object v12, v0, LB6/c$c;->a:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    iget-object v13, v0, LB6/c$c;->f:Ljava/lang/Object;

    check-cast v13, Lzp/c;

    invoke-static/range {p1 .. p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto/16 :goto_f1

    :cond_36
    iget-object v2, v0, LB6/c$c;->a:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    iget-object v11, v0, LB6/c$c;->f:Ljava/lang/Object;

    check-cast v11, Lzp/c;

    invoke-static/range {p1 .. p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    move-object/from16 v12, p1

    move-object v13, v11

    goto :goto_71

    :cond_43
    invoke-static/range {p1 .. p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object v2, v0, LB6/c$c;->f:Ljava/lang/Object;

    check-cast v2, Lzp/c;

    invoke-static {v10}, LB6/c;->access$getLoadTraceManager$p(LB6/c;)Lcom/flipkart/android/init/n;

    move-result-object v11

    invoke-virtual {v11, v6}, Lcom/flipkart/android/init/n;->getLoadTraceTracker(Ljava/lang/String;)Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    move-result-object v11

    if-eqz v11, :cond_62

    invoke-static {v10}, LB6/c;->access$getLoadTraceScreenName$p(LB6/c;)Ljava/lang/String;

    move-result-object v17

    const/4 v14, 0x0

    const/4 v15, 0x0

    iget-object v13, v0, LB6/c$c;->h:Ljava/lang/String;

    const/16 v16, 0x0

    move-object v12, v11

    invoke-virtual/range {v12 .. v17}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->addPageMeta(Ljava/lang/String;ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    :cond_62
    iput-object v2, v0, LB6/c$c;->f:Ljava/lang/Object;

    iput-object v11, v0, LB6/c$c;->a:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    iput v9, v0, LB6/c$c;->e:I

    invoke-static {v10, v6, v0}, LB6/c;->access$fetchPageFromDB(LB6/c;Ljava/lang/String;LXn/d;)Ljava/lang/Object;

    move-result-object v12

    if-ne v12, v1, :cond_6f

    return-object v1

    :cond_6f
    move-object v13, v2

    move-object v2, v11

    :goto_71
    move-object v11, v12

    check-cast v11, Ly6/a;

    const-wide/16 v14, 0x0

    if-eqz v11, :cond_8e

    invoke-virtual {v11}, Ly6/a;->getScreenData()LG5/t;

    move-result-object v12

    if-eqz v12, :cond_8e

    invoke-virtual {v12}, LG5/t;->getForceInvalidate()Ljava/lang/Long;

    move-result-object v12

    if-eqz v12, :cond_8e

    invoke-virtual {v12}, Ljava/lang/Number;->longValue()J

    move-result-wide v16

    cmp-long v12, v16, v14

    if-eqz v12, :cond_8e

    const/4 v12, 0x1

    goto :goto_8f

    :cond_8e
    const/4 v12, 0x0

    :goto_8f
    if-eqz v11, :cond_9c

    invoke-virtual {v11}, Ly6/a;->getScreenData()LG5/t;

    move-result-object v8

    iget-boolean v9, v0, LB6/c$c;->j:Z

    invoke-static {v10, v8, v9}, LB6/c;->access$getTTL(LB6/c;LG5/t;Z)Ljava/lang/Long;

    move-result-object v8

    goto :goto_9d

    :cond_9c
    move-object v8, v7

    :goto_9d
    if-nez v8, :cond_a0

    goto :goto_aa

    :cond_a0
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v18

    cmp-long v9, v18, v14

    if-nez v9, :cond_aa

    const/4 v9, 0x1

    goto :goto_ab

    :cond_aa
    :goto_aa
    const/4 v9, 0x0

    :goto_ab
    if-nez v12, :cond_c8

    invoke-virtual {v10}, LB6/c;->getMapiRequestUtils$flipkart_ecom_app_uploadSigned()LB6/b;

    move-result-object v12

    if-eqz v11, :cond_be

    invoke-virtual {v11}, Ly6/a;->getScreenData()LG5/t;

    move-result-object v14

    if-eqz v14, :cond_be

    invoke-virtual {v14}, LG5/t;->getLastUpdatedTime()Ljava/lang/Long;

    move-result-object v14

    goto :goto_bf

    :cond_be
    move-object v14, v7

    :goto_bf
    invoke-virtual {v12, v8, v14}, LB6/b;->hasExpired(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v8

    if-eqz v8, :cond_c6

    goto :goto_c8

    :cond_c6
    const/4 v8, 0x0

    goto :goto_c9

    :cond_c8
    :goto_c8
    const/4 v8, 0x1

    :goto_c9
    if-eqz v11, :cond_f4

    if-nez v9, :cond_f4

    if-nez v3, :cond_f4

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    invoke-virtual {v11, v12}, Ly6/a;->setDBExpired(Ljava/lang/Boolean;)V

    new-instance v12, Ly6/b$a;

    invoke-direct {v12, v11}, Ly6/b$a;-><init>(Ly6/a;)V

    iput-object v13, v0, LB6/c$c;->f:Ljava/lang/Object;

    iput-object v2, v0, LB6/c$c;->a:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    iput-object v11, v0, LB6/c$c;->b:Ly6/a;

    iput v9, v0, LB6/c$c;->c:I

    iput v8, v0, LB6/c$c;->d:I

    iput v5, v0, LB6/c$c;->e:I

    invoke-interface {v13, v12, v0}, Lzp/c;->emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v1, :cond_ee

    return-object v1

    :cond_ee
    move-object v12, v2

    move v2, v8

    move v5, v9

    :goto_f1
    move v8, v2

    move v9, v5

    move-object v2, v12

    :cond_f4
    invoke-static {v10}, LB6/c;->access$getDatabaseLoadObserver$p(LB6/c;)LA6/a;

    move-result-object v5

    if-eqz v5, :cond_109

    if-eqz v11, :cond_fe

    const/4 v12, 0x1

    goto :goto_ff

    :cond_fe
    const/4 v12, 0x0

    :goto_ff
    if-eqz v11, :cond_105

    if-eqz v8, :cond_105

    const/4 v14, 0x1

    goto :goto_106

    :cond_105
    const/4 v14, 0x0

    :goto_106
    invoke-interface {v5, v12, v14}, LA6/a;->onDatabaseRead(ZZ)V

    :cond_109
    if-nez v8, :cond_10d

    if-eqz v3, :cond_142

    :cond_10d
    if-eqz v11, :cond_112

    const-string v3, "network+cache"

    goto :goto_114

    :cond_112
    const-string v3, "network"

    :goto_114
    if-eqz v2, :cond_119

    invoke-virtual {v2, v3}, Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;->updateDataSource(Ljava/lang/String;)V

    :cond_119
    invoke-virtual {v10}, LB6/c;->getMapiRequestUtils$flipkart_ecom_app_uploadSigned()LB6/b;

    move-result-object v2

    if-eqz v9, :cond_121

    const/4 v8, 0x1

    goto :goto_122

    :cond_121
    const/4 v8, 0x0

    :goto_122
    invoke-static {v10}, LB6/c;->access$getNetworkConfig$p(LB6/c;)LB6/c$b;

    move-result-object v3

    invoke-virtual {v2, v6, v8, v3, v11}, LB6/b;->createPageRequest(Ljava/lang/String;ZLB6/c$b;Ly6/a;)Lwd/t;

    move-result-object v2

    invoke-virtual {v10, v2}, LB6/c;->fetchPageFromNetwork$flipkart_ecom_app_uploadSigned(Lwd/t;)Lzp/b;

    move-result-object v2

    new-instance v3, LB6/c$c$a;

    invoke-direct {v3, v13}, LB6/c$c$a;-><init>(Lzp/c;)V

    iput-object v7, v0, LB6/c$c;->f:Ljava/lang/Object;

    iput-object v7, v0, LB6/c$c;->a:Lcom/flipkart/android/perf/AppPerfTrackerConsolidated;

    iput-object v7, v0, LB6/c$c;->b:Ly6/a;

    iput v4, v0, LB6/c$c;->e:I

    invoke-interface {v2, v3, v0}, Lzp/b;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v1, :cond_142

    return-object v1

    :cond_142
    :goto_142
    sget-object v1, LUn/r;->a:LUn/r;

    return-object v1
.end method
