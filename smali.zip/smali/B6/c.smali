.class public final synthetic Lb6/c;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements LJ4/f$a;
.implements Lcom/google/firebase/inject/Deferred$DeferredHandler;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lb6/c;->a:I

    iput-object p2, p0, Lb6/c;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final handle(Lcom/google/firebase/inject/Provider;)V
    .registers 3

    iget-object v0, p0, Lb6/c;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/crashlytics/AnalyticsDeferredProxy;

    invoke-static {v0, p1}, Lcom/google/firebase/crashlytics/AnalyticsDeferredProxy;->a(Lcom/google/firebase/crashlytics/AnalyticsDeferredProxy;Lcom/google/firebase/inject/Provider;)V

    return-void
.end method

.method public final onFinished()V
    .registers 4

    iget v0, p0, Lb6/c;->a:I

    const-string v1, "$it"

    iget-object v2, p0, Lb6/c;->b:Ljava/lang/Object;

    check-cast v2, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    packed-switch v0, :pswitch_data_1c

    sget v0, Lcom/flipkart/android/reactnative/nativeuimodules/voice/c;->l:I

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->startRotateInterpolation()V

    return-void

    :pswitch_14
    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->startRotateInterpolation()V

    return-void

    nop

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_14
    .end packed-switch
.end method
