.class public final Lb6/d;
.super Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;
.source "SearchByVoiceInputWidget.kt"

# interfaces
.implements Landroidx/lifecycle/J;
.implements Lcom/flipkart/android/customviews/ExpandingCollapsingButton$c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb6/d$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;",
        "Landroidx/lifecycle/J<",
        "Lcom/flipkart/android/voice/i;",
        ">;",
        "Lcom/flipkart/android/customviews/ExpandingCollapsingButton$c;"
    }
.end annotation


# instance fields
.field private A0:Landroid/widget/LinearLayout;

.field private B0:Landroid/widget/TextView;

.field private C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

.field private D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

.field private E0:Lcom/flipkart/android/voice/i;

.field private F0:Ljava/lang/String;

.field private G0:Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

.field private H0:Ljava/lang/Boolean;

.field private Q:Landroid/widget/TextView;

.field private R:Landroid/widget/TextView;

.field private S:Landroid/widget/TextView;

.field private T:Landroid/widget/TextView;

.field private W:Landroid/widget/TextView;

.field private X:Landroid/widget/TextView;

.field private Y:Landroid/widget/TextView;

.field private Z:Landroid/view/ViewGroup;

.field private z0:Landroid/view/ViewGroup;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;-><init>()V

    return-void
.end method

.method public static final synthetic access$getContext(Lb6/d;)Landroid/content/Context;
    .registers 1

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$getMRecognitionProgressView$p(Lb6/d;)Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;
    .registers 1

    iget-object p0, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    return-object p0
.end method

.method public static final synthetic access$getNavigationContext(Lb6/d;)Lcom/flipkart/android/datagovernance/NavigationContext;
    .registers 1

    invoke-direct {p0}, Lb6/d;->g()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$getVoiceQueryLatencyTracker$p(Lb6/d;)Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;
    .registers 1

    iget-object p0, p0, Lb6/d;->G0:Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    return-object p0
.end method

.method public static final synthetic access$onStartListeningClicked(Lb6/d;)V
    .registers 1

    invoke-direct {p0}, Lb6/d;->h()V

    return-void
.end method

.method public static final access$onStopListeningClicked(Lb6/d;)V
    .registers 2

    iget-object p0, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->D:Lcom/flipkart/android/newmultiwidget/ui/widgets/q;

    if-eqz p0, :cond_d

    instance-of v0, p0, Lb6/a;

    if-eqz v0, :cond_d

    check-cast p0, Lb6/a;

    invoke-interface {p0}, Lb6/a;->stopListening()V

    :cond_d
    return-void
.end method

.method private final g()Lcom/flipkart/android/datagovernance/NavigationContext;
    .registers 3

    iget-object v0, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->D:Lcom/flipkart/android/newmultiwidget/ui/widgets/q;

    if-eqz v0, :cond_14

    instance-of v1, v0, Lb6/a;

    if-eqz v1, :cond_14

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.newmultiwidget.ui.widgets.searchbyvoice.SearchByDialogFragmentCallback"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lb6/a;

    invoke-interface {v0}, Lb6/a;->getNavigationContext()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v0

    return-object v0

    :cond_14
    const/4 v0, 0x0

    return-object v0
.end method

.method private final h()V
    .registers 4

    iget-object v0, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->D:Lcom/flipkart/android/newmultiwidget/ui/widgets/q;

    if-eqz v0, :cond_52

    instance-of v0, v0, Lb6/a;

    if-eqz v0, :cond_52

    sget-object v0, LL7/b;->a:LL7/b;

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "this.context"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Lcom/flipkart/android/utils/earcon/Earcon;->MIC_TAP:Lcom/flipkart/android/utils/earcon/Earcon;

    invoke-virtual {v0, v1, v2}, LL7/b;->playEarcon(Landroid/content/Context;Lcom/flipkart/android/utils/earcon/Earcon;)V

    iget-object v0, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->D:Lcom/flipkart/android/newmultiwidget/ui/widgets/q;

    const-string v1, "null cannot be cast to non-null type com.flipkart.android.newmultiwidget.ui.widgets.searchbyvoice.SearchByDialogFragmentCallback"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lb6/a;

    new-instance v1, Lb6/d$d;

    invoke-direct {v1, p0}, Lb6/d$d;-><init>(Lb6/d;)V

    invoke-interface {v0, v1}, Lb6/a;->startListening(Lb6/d$a;)V

    new-instance v0, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;

    const-string v1, "InitiateSearch"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->ingestEvent(Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/config/c;->getVoiceConfig()Lcom/flipkart/android/configmodel/t2;

    move-result-object v0

    if-eqz v0, :cond_52

    iget-boolean v0, v0, Lcom/flipkart/android/configmodel/t2;->K:Z

    if-nez v0, :cond_52

    new-instance v0, Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "context"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lb6/d;->G0:Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    :cond_52
    return-void
.end method

.method private final i(Ljava/lang/String;)V
    .registers 6

    iget-object v0, p0, Lb6/d;->T:Landroid/widget/TextView;

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/16 v3, 0x8

    if-eqz v0, :cond_6d

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_6d

    iget-object v0, p0, Lb6/d;->T:Landroid/widget/TextView;

    if-nez v0, :cond_13

    goto :goto_16

    :cond_13
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_16
    iget-object p1, p0, Lb6/d;->Q:Landroid/widget/TextView;

    if-nez p1, :cond_1b

    goto :goto_1e

    :cond_1b
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_1e
    iget-object p1, p0, Lb6/d;->R:Landroid/widget/TextView;

    if-nez p1, :cond_23

    goto :goto_26

    :cond_23
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_26
    iget-object p1, p0, Lb6/d;->T:Landroid/widget/TextView;

    if-nez p1, :cond_2b

    goto :goto_2e

    :cond_2b
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    :goto_2e
    iget-object p1, p0, Lb6/d;->Z:Landroid/view/ViewGroup;

    if-nez p1, :cond_33

    goto :goto_36

    :cond_33
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_36
    iget-object p1, p0, Lb6/d;->Y:Landroid/widget/TextView;

    if-nez p1, :cond_3b

    goto :goto_3e

    :cond_3b
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_3e
    iget-object p1, p0, Lb6/d;->H0:Ljava/lang/Boolean;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5b

    iget-object p1, p0, Lb6/d;->z0:Landroid/view/ViewGroup;

    if-nez p1, :cond_4d

    goto :goto_50

    :cond_4d
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_50
    iget-object p1, p0, Lb6/d;->S:Landroid/widget/TextView;

    if-nez p1, :cond_56

    goto/16 :goto_c8

    :cond_56
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    goto/16 :goto_c8

    :cond_5b
    iget-object p1, p0, Lb6/d;->z0:Landroid/view/ViewGroup;

    if-nez p1, :cond_60

    goto :goto_63

    :cond_60
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_63
    iget-object p1, p0, Lb6/d;->S:Landroid/widget/TextView;

    if-nez p1, :cond_69

    goto/16 :goto_c8

    :cond_69
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    goto :goto_c8

    :cond_6d
    iget-object p1, p0, Lb6/d;->H0:Ljava/lang/Boolean;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_90

    iget-object p1, p0, Lb6/d;->S:Landroid/widget/TextView;

    if-nez p1, :cond_7c

    goto :goto_7f

    :cond_7c
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    :goto_7f
    iget-object p1, p0, Lb6/d;->R:Landroid/widget/TextView;

    if-nez p1, :cond_84

    goto :goto_87

    :cond_84
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_87
    iget-object p1, p0, Lb6/d;->z0:Landroid/view/ViewGroup;

    if-nez p1, :cond_8c

    goto :goto_a8

    :cond_8c
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    goto :goto_a8

    :cond_90
    iget-object p1, p0, Lb6/d;->R:Landroid/widget/TextView;

    if-nez p1, :cond_95

    goto :goto_98

    :cond_95
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    :goto_98
    iget-object p1, p0, Lb6/d;->S:Landroid/widget/TextView;

    if-nez p1, :cond_9d

    goto :goto_a0

    :cond_9d
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_a0
    iget-object p1, p0, Lb6/d;->z0:Landroid/view/ViewGroup;

    if-nez p1, :cond_a5

    goto :goto_a8

    :cond_a5
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_a8
    iget-object p1, p0, Lb6/d;->Q:Landroid/widget/TextView;

    if-nez p1, :cond_ad

    goto :goto_b0

    :cond_ad
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_b0
    iget-object p1, p0, Lb6/d;->T:Landroid/widget/TextView;

    if-nez p1, :cond_b5

    goto :goto_b8

    :cond_b5
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_b8
    iget-object p1, p0, Lb6/d;->Z:Landroid/view/ViewGroup;

    if-nez p1, :cond_bd

    goto :goto_c0

    :cond_bd
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_c0
    iget-object p1, p0, Lb6/d;->Y:Landroid/widget/TextView;

    if-nez p1, :cond_c5

    goto :goto_c8

    :cond_c5
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_c8
    return-void
.end method


# virtual methods
.method public bindData(LG5/M;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/newmultiwidget/ui/widgets/q;)V
    .registers 10

    const-string v0, "widget"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "widgetPageInfo"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "parentCallback"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1, p2, p3}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->bindData(LG5/M;Lcom/flipkart/android/datagovernance/utils/WidgetPageInfo;Lcom/flipkart/android/newmultiwidget/ui/widgets/q;)V

    check-cast p3, Lb6/a;

    invoke-interface {p3}, Lb6/a;->isBinded()Z

    move-result p2

    if-eqz p2, :cond_1b

    return-void

    :cond_1b
    invoke-interface {p3}, Lb6/a;->responseReceived()V

    const/4 p2, 0x0

    iput-object p2, p0, Lb6/d;->E0:Lcom/flipkart/android/voice/i;

    invoke-interface {p3, p0}, Lb6/a;->attachObserver(Landroidx/lifecycle/J;)V

    invoke-virtual {p1}, LG5/M;->getData_()LK5/h;

    move-result-object p1

    if-eqz p1, :cond_2d

    iget-object v0, p1, LK5/h;->b:Ljg/g0;

    goto :goto_2e

    :cond_2d
    move-object v0, p2

    :goto_2e
    if-nez v0, :cond_31

    return-void

    :cond_31
    iget-object p1, p1, LK5/h;->b:Ljg/g0;

    check-cast p1, LWg/f;

    if-eqz p1, :cond_3e

    iget-object v0, p1, LWg/f;->b:Ljg/p;

    if-eqz v0, :cond_3e

    iget-object v0, v0, Ljg/p;->a:Ljava/util/List;

    goto :goto_3f

    :cond_3e
    move-object v0, p2

    :goto_3f
    const/4 v1, 0x0

    if-eqz v0, :cond_53

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_53

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LLe/f;

    iget-object v0, v0, LLe/f;->c:LMe/R3;

    check-cast v0, LMe/T2;

    goto :goto_54

    :cond_53
    move-object v0, p2

    :goto_54
    iget-object v2, p0, Lb6/d;->Q:Landroid/widget/TextView;

    invoke-virtual {p0, v2, v0}, Lb6/d;->setRichText(Landroid/widget/TextView;LMe/T2;)V

    iget-object v2, p0, Lb6/d;->W:Landroid/widget/TextView;

    invoke-virtual {p0, v2, v0}, Lb6/d;->setRichText(Landroid/widget/TextView;LMe/T2;)V

    iget-object v2, p0, Lb6/d;->X:Landroid/widget/TextView;

    invoke-virtual {p0, v2, v0}, Lb6/d;->setRichText(Landroid/widget/TextView;LMe/T2;)V

    iget-object v0, p0, Lb6/d;->Y:Landroid/widget/TextView;

    if-eqz p1, :cond_6a

    iget-object v2, p1, LWg/f;->d:LMe/T2;

    goto :goto_6b

    :cond_6a
    move-object v2, p2

    :goto_6b
    invoke-virtual {p0, v0, v2}, Lb6/d;->setRichText(Landroid/widget/TextView;LMe/T2;)V

    iget-object v0, p0, Lb6/d;->R:Landroid/widget/TextView;

    if-eqz p1, :cond_75

    iget-object v2, p1, LWg/f;->c:LMe/T2;

    goto :goto_76

    :cond_75
    move-object v2, p2

    :goto_76
    invoke-virtual {p0, v0, v2}, Lb6/d;->setRichText(Landroid/widget/TextView;LMe/T2;)V

    iget-object v0, p0, Lb6/d;->S:Landroid/widget/TextView;

    if-eqz p1, :cond_80

    iget-object v2, p1, LWg/f;->c:LMe/T2;

    goto :goto_81

    :cond_80
    move-object v2, p2

    :goto_81
    invoke-virtual {p0, v0, v2}, Lb6/d;->setRichText(Landroid/widget/TextView;LMe/T2;)V

    if-eqz p1, :cond_8d

    iget-object v0, p1, LWg/f;->a:Ljg/p;

    if-eqz v0, :cond_8d

    iget-object v0, v0, Ljg/p;->a:Ljava/util/List;

    goto :goto_8e

    :cond_8d
    move-object v0, p2

    :goto_8e
    if-eqz v0, :cond_a2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x1

    if-le v2, v3, :cond_a2

    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LLe/f;

    iget-object v2, v2, LLe/f;->c:LMe/R3;

    check-cast v2, LMe/T2;

    goto :goto_a3

    :cond_a2
    move-object v2, p2

    :goto_a3
    iget-object v3, p0, Lb6/d;->B0:Landroid/widget/TextView;

    invoke-virtual {p0, v3, v2}, Lb6/d;->setRichText(Landroid/widget/TextView;LMe/T2;)V

    if-eqz v0, :cond_eb

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_eb

    iget-object v2, p0, Lb6/d;->A0:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_b7

    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    :cond_b7
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_c1
    :goto_c1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_eb

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LLe/f;

    iget-object v3, v3, LLe/f;->c:LMe/R3;

    check-cast v3, LMe/T2;

    if-eqz v3, :cond_c1

    iget-object v4, p0, Lb6/d;->A0:Landroid/widget/LinearLayout;

    if-eqz v4, :cond_c1

    new-instance v4, Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v4, v3, v1}, Lf6/b;->setRichTextValue(Landroid/widget/TextView;LMe/T2;Z)V

    iget-object v3, p0, Lb6/d;->A0:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_c1

    invoke-virtual {v3, v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_c1

    :cond_eb
    if-eqz p1, :cond_fa

    iget-object v0, p1, LWg/f;->e:LLe/f;

    if-eqz v0, :cond_fa

    iget-object v0, v0, LLe/f;->c:LMe/R3;

    check-cast v0, Lmf/F;

    if-eqz v0, :cond_fa

    iget-object v0, v0, Lmf/F;->a:LMe/r1;

    goto :goto_fb

    :cond_fa
    move-object v0, p2

    :goto_fb
    if-eqz v0, :cond_164

    iget-object v0, p1, LWg/f;->e:LLe/f;

    if-eqz v0, :cond_10a

    iget-object v0, v0, LLe/f;->c:LMe/R3;

    check-cast v0, Lmf/F;

    if-eqz v0, :cond_10a

    iget-object v0, v0, Lmf/F;->a:LMe/r1;

    goto :goto_10b

    :cond_10a
    move-object v0, p2

    :goto_10b
    if-nez v0, :cond_10e

    goto :goto_13e

    :cond_10e
    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f070332

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v1

    float-to-int v1, v1

    iget-object v0, v0, LMe/r1;->e:Ljava/lang/String;

    invoke-static {v0, v1, v1}, Lcom/flipkart/android/utils/h0;->getRukminiUrl(Ljava/lang/String;II)Lcom/flipkart/android/satyabhama/FkRukminiRequest;

    move-result-object v0

    if-nez v0, :cond_127

    goto :goto_13e

    :cond_127
    const v1, 0x7f08026e

    invoke-virtual {v0, v1}, Lcom/flipkart/satyabhama/models/RukminiRequest;->setDefaultResourceId(I)V

    invoke-virtual {v0, v1}, Lcom/flipkart/satyabhama/models/RukminiRequest;->setErrorResourceId(I)V

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    new-instance v3, Lb6/e;

    invoke-direct {v3, p0}, Lb6/e;-><init>(Lb6/d;)V

    invoke-static {v1, v0, v2, v3}, Lcom/flipkart/android/utils/h0;->loadImage(Landroid/content/Context;Lcom/flipkart/android/satyabhama/FkRukminiRequest;Landroid/widget/ImageView;Lki/b;)V

    :goto_13e
    iget-object p1, p1, LWg/f;->e:LLe/f;

    if-eqz p1, :cond_14a

    iget-object p1, p1, LLe/f;->c:LMe/R3;

    check-cast p1, Lmf/F;

    if-eqz p1, :cond_14a

    iget-object p2, p1, Lmf/F;->b:Ljava/lang/String;

    :cond_14a
    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0601f7

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result p1

    invoke-static {p2, p1}, Lcom/flipkart/android/utils/w;->parseColor(Ljava/lang/String;I)I

    move-result p1

    iget-object p2, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz p2, :cond_164

    invoke-virtual {p2, p1}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->setSingleColor(I)V

    :cond_164
    iget-object p1, p0, Lb6/d;->Q:Landroid/widget/TextView;

    const/16 p2, 0x8

    if-nez p1, :cond_16b

    goto :goto_16e

    :cond_16b
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_16e
    iget-object p1, p0, Lb6/d;->R:Landroid/widget/TextView;

    if-nez p1, :cond_173

    goto :goto_176

    :cond_173
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_176
    iget-object p1, p0, Lb6/d;->T:Landroid/widget/TextView;

    if-nez p1, :cond_17b

    goto :goto_17e

    :cond_17b
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_17e
    iget-object p1, p0, Lb6/d;->Z:Landroid/view/ViewGroup;

    if-nez p1, :cond_183

    goto :goto_186

    :cond_183
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_186
    iget-object p1, p0, Lb6/d;->Y:Landroid/widget/TextView;

    if-nez p1, :cond_18b

    goto :goto_18f

    :cond_18b
    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    :goto_18f
    iget-object p1, p0, Lb6/d;->z0:Landroid/view/ViewGroup;

    if-nez p1, :cond_194

    goto :goto_197

    :cond_194
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_197
    iget-object p1, p0, Lb6/d;->S:Landroid/widget/TextView;

    if-nez p1, :cond_19c

    goto :goto_19f

    :cond_19c
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_19f
    invoke-interface {p3}, Lb6/a;->widgetRendered()V

    invoke-direct {p0}, Lb6/d;->h()V

    return-void
.end method

.method public collapsed()V
    .registers 3

    iget-object v0, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v0, :cond_23

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_b

    goto :goto_23

    :cond_b
    iget-object v0, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-nez v0, :cond_10

    goto :goto_14

    :cond_10
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_14
    iget-object v0, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v0, :cond_1c

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->setIsSpeaking(Z)V

    :cond_1c
    iget-object v0, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v0, :cond_23

    invoke-virtual {v0}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->play()V

    :cond_23
    :goto_23
    iget-object v0, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    if-eqz v0, :cond_38

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/16 v1, 0x8

    if-ne v0, v1, :cond_30

    goto :goto_38

    :cond_30
    iget-object v0, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    if-nez v0, :cond_35

    goto :goto_38

    :cond_35
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_38
    :goto_38
    return-void
.end method

.method public createView(Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 5

    const-string v0, "parent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f0e0248

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    const/4 v0, 0x0

    if-eqz p1, :cond_24

    const v1, 0x7f0b078f

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_25

    :cond_24
    move-object p1, v0

    :goto_25
    iput-object p1, p0, Lb6/d;->Q:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_35

    const v1, 0x7f0b0796

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_36

    :cond_35
    move-object p1, v0

    :goto_36
    iput-object p1, p0, Lb6/d;->R:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_46

    const v1, 0x7f0b0638

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_47

    :cond_46
    move-object p1, v0

    :goto_47
    iput-object p1, p0, Lb6/d;->S:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_57

    const v1, 0x7f0b07aa

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_58

    :cond_57
    move-object p1, v0

    :goto_58
    iput-object p1, p0, Lb6/d;->T:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_68

    const v1, 0x7f0b0789

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_69

    :cond_68
    move-object p1, v0

    :goto_69
    iput-object p1, p0, Lb6/d;->W:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_79

    const v1, 0x7f0b0636

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_7a

    :cond_79
    move-object p1, v0

    :goto_7a
    iput-object p1, p0, Lb6/d;->X:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_8a

    const v1, 0x7f0b078e

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_8b

    :cond_8a
    move-object p1, v0

    :goto_8b
    iput-object p1, p0, Lb6/d;->Y:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_9b

    const v1, 0x7f0b024c

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    goto :goto_9c

    :cond_9b
    move-object p1, v0

    :goto_9c
    iput-object p1, p0, Lb6/d;->Z:Landroid/view/ViewGroup;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_ac

    const v1, 0x7f0b0637

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    goto :goto_ad

    :cond_ac
    move-object p1, v0

    :goto_ad
    iput-object p1, p0, Lb6/d;->z0:Landroid/view/ViewGroup;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_bd

    const v1, 0x7f0b0405

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    goto :goto_be

    :cond_bd
    move-object p1, v0

    :goto_be
    iput-object p1, p0, Lb6/d;->A0:Landroid/widget/LinearLayout;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_ce

    const v1, 0x7f0b0639

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    goto :goto_cf

    :cond_ce
    move-object p1, v0

    :goto_cf
    iput-object p1, p0, Lb6/d;->B0:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_df

    const v1, 0x7f0b05b6

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    goto :goto_e0

    :cond_df
    move-object p1, v0

    :goto_e0
    iput-object p1, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    if-eqz p1, :cond_f0

    const v0, 0x7f0b0697

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    move-object v0, p1

    check-cast v0, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    :cond_f0
    iput-object v0, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    sget-object p1, Lq4/a;->a:Lq4/a;

    sget-object v0, Lcom/flipkart/android/configmodel/ABKey;->enableSearchCue:Lcom/flipkart/android/configmodel/ABKey;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v1

    invoke-virtual {v1}, Lcom/flipkart/android/config/c;->getSearchCueEnabled()Z

    move-result v1

    invoke-virtual {p1, v0, v1}, Lq4/a;->getBooleanOrDefault(Lcom/flipkart/android/configmodel/ABKey;Z)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iput-object p1, p0, Lb6/d;->H0:Ljava/lang/Boolean;

    iget-object p1, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    if-eqz p1, :cond_114

    new-instance v0, Lb6/d$b;

    invoke-direct {v0, p0}, Lb6/d$b;-><init>(Lb6/d;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_114
    iget-object p1, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz p1, :cond_120

    new-instance v0, Lb6/d$c;

    invoke-direct {v0, p0}, Lb6/d$c;-><init>(Lb6/d;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_120
    iget-object p1, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz p1, :cond_136

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f0601f7

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->setSingleColor(I)V

    :cond_136
    iget-object p1, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->a:Landroid/view/View;

    return-object p1
.end method

.method public expanded()V
    .registers 1

    return-void
.end method

.method public onChanged(Lcom/flipkart/android/voice/i;)V
    .registers 11

    if-eqz p1, :cond_16f

    instance-of v0, p1, Lcom/flipkart/android/voice/i$c;

    if-eqz v0, :cond_17

    iget-object v0, p0, Lb6/d;->E0:Lcom/flipkart/android/voice/i;

    if-eqz v0, :cond_b6

    instance-of v0, v0, Lcom/flipkart/android/voice/i$c;

    if-nez v0, :cond_b6

    iget-object v0, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    if-eqz v0, :cond_b6

    invoke-virtual {v0, p0}, Lcom/flipkart/android/customviews/ExpandingCollapsingButton;->expand(Lcom/flipkart/android/customviews/ExpandingCollapsingButton$c;)V

    goto/16 :goto_b6

    :cond_17
    instance-of v0, p1, Lcom/flipkart/android/voice/i$f;

    const/4 v1, 0x0

    if-eqz v0, :cond_28

    iget-object v0, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    if-eqz v0, :cond_23

    invoke-virtual {v0, p0}, Lcom/flipkart/android/customviews/ExpandingCollapsingButton;->collapse(Lcom/flipkart/android/customviews/ExpandingCollapsingButton$c;)V

    :cond_23
    invoke-direct {p0, v1}, Lb6/d;->i(Ljava/lang/String;)V

    goto/16 :goto_b6

    :cond_28
    instance-of v0, p1, Lcom/flipkart/android/voice/i$d;

    if-eqz v0, :cond_64

    iget-object v0, p0, Lb6/d;->E0:Lcom/flipkart/android/voice/i;

    if-eqz v0, :cond_16f

    instance-of v1, v0, Lcom/flipkart/android/voice/i$c;

    if-nez v1, :cond_16f

    instance-of v0, v0, Lcom/flipkart/android/voice/i$b;

    if-eqz v0, :cond_3a

    goto/16 :goto_16f

    :cond_3a
    move-object v0, p1

    check-cast v0, Lcom/flipkart/android/voice/i$d;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/i$d;->component1()D

    move-result-wide v1

    invoke-virtual {v0}, Lcom/flipkart/android/voice/i$d;->component2()Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    move-result-object v0

    iget-object v3, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v3, :cond_4d

    double-to-float v1, v1

    invoke-virtual {v3, v1}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->onRmsChanged(F)V

    :cond_4d
    if-eqz v0, :cond_b6

    invoke-direct {p0}, Lb6/d;->g()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v1

    if-eqz v1, :cond_5c

    iget-object v2, p0, Lb6/d;->G0:Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    if-eqz v2, :cond_5c

    invoke-virtual {v2, v1}, Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;->trackTranscriptionReceived(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_5c
    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;->getText()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lb6/d;->i(Ljava/lang/String;)V

    goto :goto_b6

    :cond_64
    instance-of v0, p1, Lcom/flipkart/android/voice/i$b;

    const/4 v2, 0x0

    if-eqz v0, :cond_ba

    iget-object v0, p0, Lb6/d;->E0:Lcom/flipkart/android/voice/i;

    if-eqz v0, :cond_16f

    instance-of v0, v0, Lcom/flipkart/android/voice/i$b;

    if-eqz v0, :cond_73

    goto/16 :goto_16f

    :cond_73
    iget-object v0, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v0, :cond_96

    invoke-virtual {v0}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->isFetchingAnimationOn()Z

    move-result v1

    if-eqz v1, :cond_7e

    goto :goto_96

    :cond_7e
    sget-object v1, LL7/b;->a:LL7/b;

    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v4, "context"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v4, Lcom/flipkart/android/utils/earcon/Earcon;->MIC_END:Lcom/flipkart/android/utils/earcon/Earcon;

    invoke-virtual {v1, v3, v4}, LL7/b;->playEarcon(Landroid/content/Context;Lcom/flipkart/android/utils/earcon/Earcon;)V

    new-instance v1, Lb6/c;

    invoke-direct {v1, v2, v0}, Lb6/c;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, v1}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->startTransformInterpolation(LJ4/f$a;)V

    :cond_96
    :goto_96
    move-object v0, p1

    check-cast v0, Lcom/flipkart/android/voice/i$b;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/i$b;->component1()Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;

    move-result-object v0

    if-eqz v0, :cond_b6

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;->getText()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_b6

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;->getText()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lb6/d;->F0:Ljava/lang/String;

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/Transcription;->getText()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lb6/d;->i(Ljava/lang/String;)V

    :cond_b6
    :goto_b6
    iput-object p1, p0, Lb6/d;->E0:Lcom/flipkart/android/voice/i;

    goto/16 :goto_16f

    :cond_ba
    iget-object v0, p0, Lb6/d;->E0:Lcom/flipkart/android/voice/i;

    if-nez v0, :cond_c0

    goto/16 :goto_16f

    :cond_c0
    check-cast p1, Lcom/flipkart/android/voice/i$e;

    invoke-virtual {p1}, Lcom/flipkart/android/voice/i$e;->component1()Lcom/flipkart/android/voice/s2tlibrary/common/model/NerText;

    move-result-object v0

    iget-object v3, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v3, :cond_e8

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v3

    const/4 v4, 0x4

    if-ne v3, v4, :cond_d2

    goto :goto_e8

    :cond_d2
    iget-object v3, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-nez v3, :cond_d7

    goto :goto_da

    :cond_d7
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    :goto_da
    iget-object v3, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v3, :cond_e1

    invoke-virtual {v3, v2}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->setIsSpeaking(Z)V

    :cond_e1
    iget-object v3, p0, Lb6/d;->D0:Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    if-eqz v3, :cond_e8

    invoke-virtual {v3}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->stop()V

    :cond_e8
    :goto_e8
    iget-object v3, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    if-eqz v3, :cond_fb

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v3

    if-nez v3, :cond_f3

    goto :goto_fb

    :cond_f3
    iget-object v3, p0, Lb6/d;->C0:Lcom/flipkart/android/customviews/ExpandingCollapsingButton;

    if-nez v3, :cond_f8

    goto :goto_fb

    :cond_f8
    invoke-virtual {v3, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_fb
    :goto_fb
    if-eqz v0, :cond_101

    invoke-virtual {v0}, Lcom/flipkart/android/voice/s2tlibrary/common/model/NerText;->getText()Ljava/lang/String;

    move-result-object v1

    :cond_101
    invoke-virtual {p0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v2, "null cannot be cast to non-null type com.flipkart.android.init.FlipkartApplication"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/flipkart/android/init/FlipkartApplication;

    invoke-virtual {v0}, Lcom/flipkart/android/init/FlipkartApplication;->getActivity()Landroid/app/Activity;

    move-result-object v2

    instance-of v3, v2, Lcom/flipkart/android/voice/j;

    if-nez v3, :cond_119

    goto :goto_16f

    :cond_119
    check-cast v2, Lcom/flipkart/android/voice/j;

    invoke-virtual {v0, v0, v2}, Lcom/flipkart/android/init/FlipkartApplication;->getVoiceController(Landroid/content/Context;Lcom/flipkart/android/voice/j;)Lcom/flipkart/android/voice/h;

    move-result-object v0

    invoke-virtual {v0}, Lcom/flipkart/android/voice/h;->getAudioID()Ljava/lang/String;

    move-result-object v6

    iget-object v7, p0, Lb6/d;->F0:Ljava/lang/String;

    if-eqz v1, :cond_157

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_157

    invoke-direct {p0}, Lb6/d;->g()Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v0

    if-eqz v0, :cond_13a

    iget-object v2, p0, Lb6/d;->G0:Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    if-eqz v2, :cond_13a

    invoke-virtual {v2, v0}, Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;->trackFinalOutput(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_13a
    new-instance v0, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;

    const-string v3, "AddQuery"

    const/4 v5, 0x0

    const/4 v8, 0x0

    move-object v2, v0

    move-object v4, v1

    invoke-direct/range {v2 .. v8}, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/flipkart/android/voice/i$e;->getFilter()Ljava/lang/String;

    move-result-object p1

    iget-object v2, p0, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->D:Lcom/flipkart/android/newmultiwidget/ui/widgets/q;

    if-eqz v2, :cond_16f

    instance-of v3, v2, Lb6/a;

    if-eqz v3, :cond_16f

    check-cast v2, Lb6/a;

    invoke-interface {v2, v1, p1, v0}, Lb6/a;->openSearch(Ljava/lang/String;Ljava/lang/String;Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;)V

    goto :goto_16f

    :cond_157
    invoke-virtual {p1}, Lcom/flipkart/android/voice/i$e;->getErrorType()I

    move-result p1

    new-instance v0, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    const-string v3, "Error"

    const/4 v5, 0x0

    move-object v2, v0

    move-object v4, v1

    invoke-direct/range {v2 .. v8}, Lcom/flipkart/android/datagovernance/events/SearchByVoiceEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/flipkart/android/newmultiwidget/ui/widgets/BaseWidget;->ingestEvent(Lcom/flipkart/android/datagovernance/events/DGEvent;)V

    invoke-virtual {p0}, Lb6/d;->setError()V

    :cond_16f
    :goto_16f
    return-void
.end method

.method public bridge synthetic onChanged(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lcom/flipkart/android/voice/i;

    invoke-virtual {p0, p1}, Lb6/d;->onChanged(Lcom/flipkart/android/voice/i;)V

    return-void
.end method

.method public final setError()V
    .registers 4

    iget-object v0, p0, Lb6/d;->Q:Landroid/widget/TextView;

    const/16 v1, 0x8

    if-nez v0, :cond_7

    goto :goto_a

    :cond_7
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_a
    iget-object v0, p0, Lb6/d;->R:Landroid/widget/TextView;

    if-nez v0, :cond_f

    goto :goto_12

    :cond_f
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_12
    iget-object v0, p0, Lb6/d;->S:Landroid/widget/TextView;

    if-nez v0, :cond_17

    goto :goto_1a

    :cond_17
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_1a
    iget-object v0, p0, Lb6/d;->T:Landroid/widget/TextView;

    if-nez v0, :cond_1f

    goto :goto_22

    :cond_1f
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_22
    iget-object v0, p0, Lb6/d;->Z:Landroid/view/ViewGroup;

    const/4 v2, 0x0

    if-nez v0, :cond_28

    goto :goto_2b

    :cond_28
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :goto_2b
    iget-object v0, p0, Lb6/d;->Y:Landroid/widget/TextView;

    if-nez v0, :cond_30

    goto :goto_33

    :cond_30
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :goto_33
    iget-object v0, p0, Lb6/d;->z0:Landroid/view/ViewGroup;

    if-nez v0, :cond_38

    goto :goto_3b

    :cond_38
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_3b
    return-void
.end method

.method public final setRichText(Landroid/widget/TextView;LMe/T2;)V
    .registers 4

    if-eqz p1, :cond_6

    const/4 v0, 0x0

    invoke-static {p1, p2, v0}, Lf6/b;->setRichTextValue(Landroid/widget/TextView;LMe/T2;Z)V

    :cond_6
    return-void
.end method
