.class public final LB6/c$b;
.super Ljava/lang/Object;
.source "ReactDataProvider.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LB6/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private final a:Z

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Lwd/w;


# direct methods
.method public constructor <init>()V
    .registers 8

    const/16 v5, 0xf

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v6}, LB6/c$b;-><init>(ZLjava/lang/String;Ljava/lang/String;Lwd/w;ILkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(ZLjava/lang/String;Ljava/lang/String;Lwd/w;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, LB6/c$b;->a:Z

    iput-object p2, p0, LB6/c$b;->b:Ljava/lang/String;

    iput-object p3, p0, LB6/c$b;->c:Ljava/lang/String;

    iput-object p4, p0, LB6/c$b;->d:Lwd/w;

    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/String;Ljava/lang/String;Lwd/w;ILkotlin/jvm/internal/i;)V
    .registers 8

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_5

    const/4 p1, 0x0

    :cond_5
    and-int/lit8 p6, p5, 0x2

    const/4 v0, 0x0

    if-eqz p6, :cond_b

    move-object p2, v0

    :cond_b
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_10

    move-object p3, v0

    :cond_10
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_15

    move-object p4, v0

    :cond_15
    invoke-direct {p0, p1, p2, p3, p4}, LB6/c$b;-><init>(ZLjava/lang/String;Ljava/lang/String;Lwd/w;)V

    return-void
.end method

.method public static synthetic copy$default(LB6/c$b;ZLjava/lang/String;Ljava/lang/String;Lwd/w;ILjava/lang/Object;)LB6/c$b;
    .registers 7

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_6

    iget-boolean p1, p0, LB6/c$b;->a:Z

    :cond_6
    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_c

    iget-object p2, p0, LB6/c$b;->b:Ljava/lang/String;

    :cond_c
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_12

    iget-object p3, p0, LB6/c$b;->c:Ljava/lang/String;

    :cond_12
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_18

    iget-object p4, p0, LB6/c$b;->d:Lwd/w;

    :cond_18
    invoke-virtual {p0, p1, p2, p3, p4}, LB6/c$b;->copy(ZLjava/lang/String;Ljava/lang/String;Lwd/w;)LB6/c$b;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Z
    .registers 2

    iget-boolean v0, p0, LB6/c$b;->a:Z

    return v0
.end method

.method public final component2()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LB6/c$b;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final component3()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LB6/c$b;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final component4()Lwd/w;
    .registers 2

    iget-object v0, p0, LB6/c$b;->d:Lwd/w;

    return-object v0
.end method

.method public final copy(ZLjava/lang/String;Ljava/lang/String;Lwd/w;)LB6/c$b;
    .registers 6

    new-instance v0, LB6/c$b;

    invoke-direct {v0, p1, p2, p3, p4}, LB6/c$b;-><init>(ZLjava/lang/String;Ljava/lang/String;Lwd/w;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LB6/c$b;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, LB6/c$b;

    iget-boolean v1, p1, LB6/c$b;->a:Z

    iget-boolean v3, p0, LB6/c$b;->a:Z

    if-eq v3, v1, :cond_13

    return v2

    :cond_13
    iget-object v1, p0, LB6/c$b;->b:Ljava/lang/String;

    iget-object v3, p1, LB6/c$b;->b:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    return v2

    :cond_1e
    iget-object v1, p0, LB6/c$b;->c:Ljava/lang/String;

    iget-object v3, p1, LB6/c$b;->c:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_29

    return v2

    :cond_29
    iget-object v1, p0, LB6/c$b;->d:Lwd/w;

    iget-object p1, p1, LB6/c$b;->d:Lwd/w;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_34

    return v2

    :cond_34
    return v0
.end method

.method public final getBasePath()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LB6/c$b;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final getHostName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LB6/c$b;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final getRequestContext()Lwd/w;
    .registers 2

    iget-object v0, p0, LB6/c$b;->d:Lwd/w;

    return-object v0
.end method

.method public hashCode()I
    .registers 4

    iget-boolean v0, p0, LB6/c$b;->a:Z

    if-eqz v0, :cond_5

    const/4 v0, 0x1

    :cond_5
    mul-int/lit8 v0, v0, 0x1f

    const/4 v1, 0x0

    iget-object v2, p0, LB6/c$b;->b:Ljava/lang/String;

    if-nez v2, :cond_e

    const/4 v2, 0x0

    goto :goto_12

    :cond_e
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_12
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$b;->c:Ljava/lang/String;

    if-nez v2, :cond_1b

    const/4 v2, 0x0

    goto :goto_1f

    :cond_1b
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_1f
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$b;->d:Lwd/w;

    if-nez v2, :cond_27

    goto :goto_2b

    :cond_27
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_2b
    add-int/2addr v0, v1

    return v0
.end method

.method public final isSecureFetch()Z
    .registers 2

    iget-boolean v0, p0, LB6/c$b;->a:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "NetworkConfig(isSecureFetch="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-boolean v1, p0, LB6/c$b;->a:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", hostName="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$b;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", basePath="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$b;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", requestContext="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$b;->d:Lwd/w;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
