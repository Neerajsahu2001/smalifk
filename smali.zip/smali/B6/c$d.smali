.class final LB6/c$d;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactDataProvider.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB6/c;->fetchPageFromNetwork$flipkart_ecom_app_uploadSigned(Lwd/t;)Lzp/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lzp/c<",
        "-",
        "Ly6/b;",
        ">;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.repository.ReactDataProvider$fetchPageFromNetwork$1"
    f = "ReactDataProvider.kt"
    l = {
        0x80,
        0xa4
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field private synthetic b:Ljava/lang/Object;

.field final synthetic c:Lwd/t;

.field final synthetic d:LB6/c;


# direct methods
.method constructor <init>(Lwd/t;LB6/c;LXn/d;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd/t;",
            "LB6/c;",
            "LXn/d<",
            "-",
            "LB6/c$d;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LB6/c$d;->c:Lwd/t;

    iput-object p2, p0, LB6/c$d;->d:LB6/c;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance v0, LB6/c$d;

    iget-object v1, p0, LB6/c$d;->c:Lwd/t;

    iget-object v2, p0, LB6/c$d;->d:LB6/c;

    invoke-direct {v0, v1, v2, p2}, LB6/c$d;-><init>(Lwd/t;LB6/c;LXn/d;)V

    iput-object p1, v0, LB6/c$d;->b:Ljava/lang/Object;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lzp/c;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LB6/c$d;->invoke(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lzp/c;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/c<",
            "-",
            "Ly6/b;",
            ">;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LB6/c$d;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LB6/c$d;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LB6/c$d;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LB6/c$d;->a:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_22

    if-eq v1, v3, :cond_19

    if-ne v1, v2, :cond_11

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto/16 :goto_d5

    :cond_11
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_19
    iget-object v1, p0, LB6/c$d;->b:Ljava/lang/Object;

    check-cast v1, Lzp/c;

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto/16 :goto_c7

    :cond_22
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LB6/c$d;->b:Ljava/lang/Object;

    move-object v1, p1

    check-cast v1, Lzp/c;

    new-instance p1, Lcom/flipkart/android/perf/f;

    invoke-direct {p1}, Lcom/flipkart/android/perf/f;-><init>()V

    iget-object v5, p0, LB6/c$d;->c:Lwd/t;

    iget-object v4, v5, Lwd/t;->b:Lwd/r;

    if-eqz v4, :cond_39

    iget-object v4, v4, Lwd/r;->e:Ljava/lang/Integer;

    if-nez v4, :cond_3e

    :cond_39
    new-instance v4, Ljava/lang/Integer;

    invoke-direct {v4, v3}, Ljava/lang/Integer;-><init>(I)V

    :cond_3e
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    iget-object v6, v5, Lwd/t;->b:Lwd/r;

    if-eqz v6, :cond_4a

    iget-object v6, v6, Lwd/r;->g:Ljava/lang/Long;

    if-nez v6, :cond_51

    :cond_4a
    new-instance v6, Ljava/lang/Long;

    const-wide/16 v7, 0x0

    invoke-direct {v6, v7, v8}, Ljava/lang/Long;-><init>(J)V

    :cond_51
    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    move-result-wide v6

    iget-object v8, v5, Lwd/t;->a:Ljava/lang/String;

    invoke-virtual {p1, v8, v4, v6, v7}, Lcom/flipkart/android/perf/f;->startAndGetPerfTracker(Ljava/lang/String;IJ)Lcom/flipkart/android/perf/b;

    move-result-object v9

    iget-object v8, p0, LB6/c$d;->d:LB6/c;

    invoke-static {v8}, LB6/c;->access$getContext$p(LB6/c;)Landroid/content/Context;

    move-result-object v8

    iget-object v10, v5, Lwd/t;->a:Ljava/lang/String;

    new-instance v11, Ljava/lang/Long;

    invoke-direct {v11, v6, v7}, Ljava/lang/Long;-><init>(J)V

    invoke-virtual {p1, v8, v10, v4, v11}, Lcom/flipkart/android/perf/f;->startAndGetPerfTrackerForHomePage(Landroid/content/Context;Ljava/lang/String;ILjava/lang/Long;)Lcom/flipkart/android/perf/b;

    move-result-object v10

    sget-object p1, Lq4/a;->a:Lq4/a;

    sget-object v4, Lcom/flipkart/android/configmodel/ABKey;->enableMainThreadImprovements:Lcom/flipkart/android/configmodel/ABKey;

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getConfigManager()Lcom/flipkart/android/config/c;

    move-result-object v6

    invoke-virtual {v6}, Lcom/flipkart/android/config/c;->enableMainThreadImprovements()Z

    move-result v6

    invoke-virtual {p1, v4, v6}, Lq4/a;->getBooleanOrDefault(Lcom/flipkart/android/configmodel/ABKey;Z)Z

    move-result v6

    new-instance v11, Lcom/flipkart/android/perf/a$b;

    const-string p1, "network"

    invoke-direct {v11, p1}, Lcom/flipkart/android/perf/a$b;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Lcom/flipkart/android/perf/a$b;->startTrace()V

    iput-object v1, p0, LB6/c$d;->b:Ljava/lang/Object;

    iget-object v8, p0, LB6/c$d;->d:LB6/c;

    iput v3, p0, LB6/c$d;->a:I

    new-instance p1, LXn/i;

    invoke-static {p0}, LYn/b;->b(LXn/d;)LXn/d;

    move-result-object v3

    invoke-direct {p1, v3}, LXn/i;-><init>(LXn/d;)V

    sget-object v3, Lz6/b;->a:Lz6/b;

    iget-object v4, v5, Lwd/t;->a:Ljava/lang/String;

    const-string v7, "pageRequest.pageUri"

    invoke-static {v4, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v4}, Lz6/b;->getCall(Ljava/lang/String;)Lz6/a;

    move-result-object v4

    if-nez v4, :cond_ad

    new-instance v4, Lz6/a;

    invoke-static {v8}, LB6/c;->access$getNetworkConfig$p(LB6/c;)LB6/c$b;

    move-result-object v12

    invoke-direct {v4, v5, v12}, Lz6/a;-><init>(Lwd/t;LB6/c$b;)V

    :cond_ad
    move-object v12, v4

    iget-object v4, v5, Lwd/t;->a:Ljava/lang/String;

    invoke-static {v4, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v4, v12}, Lz6/b;->addCall(Ljava/lang/String;Lz6/a;)V

    new-instance v3, LB6/c$d$a;

    move-object v4, v3

    move-object v7, p1

    invoke-direct/range {v4 .. v11}, LB6/c$d$a;-><init>(Lwd/t;ZLXn/i;LB6/c;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/a$b;)V

    invoke-virtual {v12, v3}, Lz6/a;->registerCallback(Lva/b;)V

    invoke-virtual {p1}, LXn/i;->a()Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_c7

    return-object v0

    :cond_c7
    :goto_c7
    check-cast p1, Ly6/b;

    const/4 v3, 0x0

    iput-object v3, p0, LB6/c$d;->b:Ljava/lang/Object;

    iput v2, p0, LB6/c$d;->a:I

    invoke-interface {v1, p1, p0}, Lzp/c;->emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_d5

    return-object v0

    :cond_d5
    :goto_d5
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
