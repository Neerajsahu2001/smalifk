.class public final Lb6/d$b;
.super Lcom/flipkart/android/voice/view/b;
.source "SearchByVoiceInputWidget.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb6/d;->createView(Landroid/view/ViewGroup;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic c:Lb6/d;


# direct methods
.method constructor <init>(Lb6/d;)V
    .registers 4

    iput-object p1, p0, Lb6/d$b;->c:Lb6/d;

    const-wide/16 v0, 0x1f4

    invoke-direct {p0, v0, v1}, Lcom/flipkart/android/voice/view/b;-><init>(J)V

    return-void
.end method


# virtual methods
.method public onDebouncedClick(Landroid/view/View;)V
    .registers 3

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Lb6/d$b;->c:Lb6/d;

    invoke-static {p1}, Lb6/d;->access$onStartListeningClicked(Lb6/d;)V

    return-void
.end method
