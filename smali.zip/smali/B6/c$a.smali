.class public final LB6/c$a;
.super Ljava/lang/Object;
.source "ReactDataProvider.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LB6/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:Landroid/content/Context;

.field private b:Lcom/flipkart/android/reactmultiwidget/db/b;

.field private c:Lcom/flipkart/android/gson/Serializer;

.field private d:Lcom/flipkart/android/datagovernance/DGEventsController;

.field private e:LB6/c$b;

.field private f:Lkotlinx/coroutines/G;

.field private g:Ljava/lang/String;

.field private h:LA6/a;

.field private i:LA6/d;


# direct methods
.method public constructor <init>()V
    .registers 13

    const/16 v10, 0x1ff

    const/4 v11, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v11}, LB6/c$a;-><init>(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;ILkotlin/jvm/internal/i;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB6/c$a;->a:Landroid/content/Context;

    iput-object p2, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    iput-object p3, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    iput-object p4, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    iput-object p5, p0, LB6/c$a;->e:LB6/c$b;

    iput-object p6, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    iput-object p7, p0, LB6/c$a;->g:Ljava/lang/String;

    iput-object p8, p0, LB6/c$a;->h:LA6/a;

    iput-object p9, p0, LB6/c$a;->i:LA6/d;

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;ILkotlin/jvm/internal/i;)V
    .registers 22

    move/from16 v0, p10

    and-int/lit8 v1, v0, 0x1

    const/4 v2, 0x0

    if-eqz v1, :cond_9

    move-object v1, v2

    goto :goto_a

    :cond_9
    move-object v1, p1

    :goto_a
    and-int/lit8 v3, v0, 0x2

    if-eqz v3, :cond_10

    move-object v3, v2

    goto :goto_11

    :cond_10
    move-object v3, p2

    :goto_11
    and-int/lit8 v4, v0, 0x4

    if-eqz v4, :cond_17

    move-object v4, v2

    goto :goto_18

    :cond_17
    move-object v4, p3

    :goto_18
    and-int/lit8 v5, v0, 0x8

    if-eqz v5, :cond_1e

    move-object v5, v2

    goto :goto_1f

    :cond_1e
    move-object v5, p4

    :goto_1f
    and-int/lit8 v6, v0, 0x10

    if-eqz v6, :cond_25

    move-object v6, v2

    goto :goto_26

    :cond_25
    move-object v6, p5

    :goto_26
    and-int/lit8 v7, v0, 0x20

    if-eqz v7, :cond_2c

    move-object v7, v2

    goto :goto_2e

    :cond_2c
    move-object/from16 v7, p6

    :goto_2e
    and-int/lit8 v8, v0, 0x40

    if-eqz v8, :cond_34

    move-object v8, v2

    goto :goto_36

    :cond_34
    move-object/from16 v8, p7

    :goto_36
    and-int/lit16 v9, v0, 0x80

    if-eqz v9, :cond_3c

    move-object v9, v2

    goto :goto_3e

    :cond_3c
    move-object/from16 v9, p8

    :goto_3e
    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_43

    goto :goto_45

    :cond_43
    move-object/from16 v2, p9

    :goto_45
    move-object p1, p0

    move-object p2, v1

    move-object p3, v3

    move-object p4, v4

    move-object p5, v5

    move-object/from16 p6, v6

    move-object/from16 p7, v7

    move-object/from16 p8, v8

    move-object/from16 p9, v9

    move-object/from16 p10, v2

    invoke-direct/range {p1 .. p10}, LB6/c$a;-><init>(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;)V

    return-void
.end method

.method public static synthetic copy$default(LB6/c$a;Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;ILjava/lang/Object;)LB6/c$a;
    .registers 22

    move-object v0, p0

    move/from16 v1, p10

    and-int/lit8 v2, v1, 0x1

    if-eqz v2, :cond_a

    iget-object v2, v0, LB6/c$a;->a:Landroid/content/Context;

    goto :goto_b

    :cond_a
    move-object v2, p1

    :goto_b
    and-int/lit8 v3, v1, 0x2

    if-eqz v3, :cond_12

    iget-object v3, v0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    goto :goto_13

    :cond_12
    move-object v3, p2

    :goto_13
    and-int/lit8 v4, v1, 0x4

    if-eqz v4, :cond_1a

    iget-object v4, v0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    goto :goto_1b

    :cond_1a
    move-object v4, p3

    :goto_1b
    and-int/lit8 v5, v1, 0x8

    if-eqz v5, :cond_22

    iget-object v5, v0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    goto :goto_23

    :cond_22
    move-object v5, p4

    :goto_23
    and-int/lit8 v6, v1, 0x10

    if-eqz v6, :cond_2a

    iget-object v6, v0, LB6/c$a;->e:LB6/c$b;

    goto :goto_2b

    :cond_2a
    move-object v6, p5

    :goto_2b
    and-int/lit8 v7, v1, 0x20

    if-eqz v7, :cond_32

    iget-object v7, v0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    goto :goto_34

    :cond_32
    move-object/from16 v7, p6

    :goto_34
    and-int/lit8 v8, v1, 0x40

    if-eqz v8, :cond_3b

    iget-object v8, v0, LB6/c$a;->g:Ljava/lang/String;

    goto :goto_3d

    :cond_3b
    move-object/from16 v8, p7

    :goto_3d
    and-int/lit16 v9, v1, 0x80

    if-eqz v9, :cond_44

    iget-object v9, v0, LB6/c$a;->h:LA6/a;

    goto :goto_46

    :cond_44
    move-object/from16 v9, p8

    :goto_46
    and-int/lit16 v1, v1, 0x100

    if-eqz v1, :cond_4d

    iget-object v1, v0, LB6/c$a;->i:LA6/d;

    goto :goto_4f

    :cond_4d
    move-object/from16 v1, p9

    :goto_4f
    move-object p1, v2

    move-object p2, v3

    move-object p3, v4

    move-object p4, v5

    move-object p5, v6

    move-object/from16 p6, v7

    move-object/from16 p7, v8

    move-object/from16 p8, v9

    move-object/from16 p9, v1

    invoke-virtual/range {p0 .. p9}, LB6/c$a;->copy(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;)LB6/c$a;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final build()LB6/c;
    .registers 14

    iget-object v0, p0, LB6/c$a;->a:Landroid/content/Context;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object v0

    :cond_8
    move-object v2, v0

    iget-object v0, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    if-nez v0, :cond_1a

    invoke-static {}, Lcom/flipkart/android/init/FlipkartApplication;->getAppContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc5/a;->getSerializer(Landroid/content/Context;)Lcom/flipkart/android/gson/Serializer;

    move-result-object v0

    const-string v1, "getSerializer(FlipkartApplication.getAppContext())"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1a
    move-object v4, v0

    iget-object v0, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    if-nez v0, :cond_25

    sget-object v0, Lcom/flipkart/android/reactmultiwidget/db/b;->d:Lcom/flipkart/android/reactmultiwidget/db/b$a;

    invoke-virtual {v0}, Lcom/flipkart/android/reactmultiwidget/db/b$a;->getInstance()Lcom/flipkart/android/reactmultiwidget/db/b;

    move-result-object v0

    :cond_25
    move-object v3, v0

    iget-object v0, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    if-nez v0, :cond_2e

    invoke-static {}, Lcom/flipkart/android/datagovernance/DGEventsController;->getInstance()Lcom/flipkart/android/datagovernance/DGEventsController;

    move-result-object v0

    :cond_2e
    move-object v5, v0

    iget-object v0, p0, LB6/c$a;->e:LB6/c$b;

    if-nez v0, :cond_41

    new-instance v0, LB6/c$b;

    const/16 v11, 0xf

    const/4 v12, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v6, v0

    invoke-direct/range {v6 .. v12}, LB6/c$b;-><init>(ZLjava/lang/String;Ljava/lang/String;Lwd/w;ILkotlin/jvm/internal/i;)V

    goto :goto_42

    :cond_41
    move-object v6, v0

    :goto_42
    new-instance v0, LB6/c;

    const-string v1, "defaultContext"

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "defaultDGEventsController"

    invoke-static {v5, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v7, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    iget-object v8, p0, LB6/c$a;->g:Ljava/lang/String;

    iget-object v9, p0, LB6/c$a;->h:LA6/a;

    iget-object v10, p0, LB6/c$a;->i:LA6/d;

    const/4 v11, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v11}, LB6/c;-><init>(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;Lkotlin/jvm/internal/i;)V

    return-object v0
.end method

.method public final component1()Landroid/content/Context;
    .registers 2

    iget-object v0, p0, LB6/c$a;->a:Landroid/content/Context;

    return-object v0
.end method

.method public final component2()Lcom/flipkart/android/reactmultiwidget/db/b;
    .registers 2

    iget-object v0, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    return-object v0
.end method

.method public final component3()Lcom/flipkart/android/gson/Serializer;
    .registers 2

    iget-object v0, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    return-object v0
.end method

.method public final component4()Lcom/flipkart/android/datagovernance/DGEventsController;
    .registers 2

    iget-object v0, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    return-object v0
.end method

.method public final component5()LB6/c$b;
    .registers 2

    iget-object v0, p0, LB6/c$a;->e:LB6/c$b;

    return-object v0
.end method

.method public final component6()Lkotlinx/coroutines/G;
    .registers 2

    iget-object v0, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    return-object v0
.end method

.method public final component7()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LB6/c$a;->g:Ljava/lang/String;

    return-object v0
.end method

.method public final component8()LA6/a;
    .registers 2

    iget-object v0, p0, LB6/c$a;->h:LA6/a;

    return-object v0
.end method

.method public final component9()LA6/d;
    .registers 2

    iget-object v0, p0, LB6/c$a;->i:LA6/d;

    return-object v0
.end method

.method public final copy(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;)LB6/c$a;
    .registers 21

    new-instance v10, LB6/c$a;

    move-object v0, v10

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object/from16 v9, p9

    invoke-direct/range {v0 .. v9}, LB6/c$a;-><init>(Landroid/content/Context;Lcom/flipkart/android/reactmultiwidget/db/b;Lcom/flipkart/android/gson/Serializer;Lcom/flipkart/android/datagovernance/DGEventsController;LB6/c$b;Lkotlinx/coroutines/G;Ljava/lang/String;LA6/a;LA6/d;)V

    return-object v10
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LB6/c$a;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, LB6/c$a;

    iget-object v1, p0, LB6/c$a;->a:Landroid/content/Context;

    iget-object v3, p1, LB6/c$a;->a:Landroid/content/Context;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    iget-object v3, p1, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-object v1, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    iget-object v3, p1, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2d

    return v2

    :cond_2d
    iget-object v1, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    iget-object v3, p1, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_38

    return v2

    :cond_38
    iget-object v1, p0, LB6/c$a;->e:LB6/c$b;

    iget-object v3, p1, LB6/c$a;->e:LB6/c$b;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_43

    return v2

    :cond_43
    iget-object v1, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    iget-object v3, p1, LB6/c$a;->f:Lkotlinx/coroutines/G;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4e

    return v2

    :cond_4e
    iget-object v1, p0, LB6/c$a;->g:Ljava/lang/String;

    iget-object v3, p1, LB6/c$a;->g:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_59

    return v2

    :cond_59
    iget-object v1, p0, LB6/c$a;->h:LA6/a;

    iget-object v3, p1, LB6/c$a;->h:LA6/a;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_64

    return v2

    :cond_64
    iget-object v1, p0, LB6/c$a;->i:LA6/d;

    iget-object p1, p1, LB6/c$a;->i:LA6/d;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6f

    return v2

    :cond_6f
    return v0
.end method

.method public final getContext()Landroid/content/Context;
    .registers 2

    iget-object v0, p0, LB6/c$a;->a:Landroid/content/Context;

    return-object v0
.end method

.method public final getCoroutineScope()Lkotlinx/coroutines/G;
    .registers 2

    iget-object v0, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    return-object v0
.end method

.method public final getDatabaseLoadObserver()LA6/a;
    .registers 2

    iget-object v0, p0, LB6/c$a;->h:LA6/a;

    return-object v0
.end method

.method public final getDgEventsController()Lcom/flipkart/android/datagovernance/DGEventsController;
    .registers 2

    iget-object v0, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    return-object v0
.end method

.method public final getLoadTraceScreenName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LB6/c$a;->g:Ljava/lang/String;

    return-object v0
.end method

.method public final getNetworkConfig()LB6/c$b;
    .registers 2

    iget-object v0, p0, LB6/c$a;->e:LB6/c$b;

    return-object v0
.end method

.method public final getNetworkLoadObserver()LA6/d;
    .registers 2

    iget-object v0, p0, LB6/c$a;->i:LA6/d;

    return-object v0
.end method

.method public final getReactDBHelper()Lcom/flipkart/android/reactmultiwidget/db/b;
    .registers 2

    iget-object v0, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    return-object v0
.end method

.method public final getSerializer()Lcom/flipkart/android/gson/Serializer;
    .registers 2

    iget-object v0, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    return-object v0
.end method

.method public hashCode()I
    .registers 4

    iget-object v0, p0, LB6/c$a;->a:Landroid/content/Context;

    const/4 v1, 0x0

    if-nez v0, :cond_7

    const/4 v0, 0x0

    goto :goto_b

    :cond_7
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_b
    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    if-nez v2, :cond_13

    const/4 v2, 0x0

    goto :goto_17

    :cond_13
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_17
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    if-nez v2, :cond_20

    const/4 v2, 0x0

    goto :goto_24

    :cond_20
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_24
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    if-nez v2, :cond_2d

    const/4 v2, 0x0

    goto :goto_31

    :cond_2d
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_31
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->e:LB6/c$b;

    if-nez v2, :cond_3a

    const/4 v2, 0x0

    goto :goto_3e

    :cond_3a
    invoke-virtual {v2}, LB6/c$b;->hashCode()I

    move-result v2

    :goto_3e
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    if-nez v2, :cond_47

    const/4 v2, 0x0

    goto :goto_4b

    :cond_47
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_4b
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->g:Ljava/lang/String;

    if-nez v2, :cond_54

    const/4 v2, 0x0

    goto :goto_58

    :cond_54
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_58
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->h:LA6/a;

    if-nez v2, :cond_61

    const/4 v2, 0x0

    goto :goto_65

    :cond_61
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_65
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, LB6/c$a;->i:LA6/d;

    if-nez v2, :cond_6d

    goto :goto_71

    :cond_6d
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_71
    add-int/2addr v0, v1

    return v0
.end method

.method public final setContext(Landroid/content/Context;)LB6/c$a;
    .registers 3

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LB6/c$a;->a:Landroid/content/Context;

    return-object p0
.end method

.method public final setContext(Landroid/content/Context;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->a:Landroid/content/Context;

    return-void
.end method

.method public final setCoroutineScope(Lkotlinx/coroutines/G;)LB6/c$a;
    .registers 3

    const-string v0, "coroutineScope"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    return-object p0
.end method

.method public final setCoroutineScope(Lkotlinx/coroutines/G;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    return-void
.end method

.method public final setDBHelper(Lcom/flipkart/android/reactmultiwidget/db/b;)LB6/c$a;
    .registers 3

    const-string v0, "dbHelper"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    return-object p0
.end method

.method public final setDGEventsController(Lcom/flipkart/android/datagovernance/DGEventsController;)LB6/c$a;
    .registers 3

    const-string v0, "dgEventsController"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    return-object p0
.end method

.method public final setDatabaseLoadObserver(LA6/a;)LB6/c$a;
    .registers 2

    iput-object p1, p0, LB6/c$a;->h:LA6/a;

    return-object p0
.end method

.method public final setDatabaseLoadObserver(LA6/a;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->h:LA6/a;

    return-void
.end method

.method public final setDgEventsController(Lcom/flipkart/android/datagovernance/DGEventsController;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    return-void
.end method

.method public final setLoadTraceScreenName(Ljava/lang/String;)LB6/c$a;
    .registers 2

    iput-object p1, p0, LB6/c$a;->g:Ljava/lang/String;

    return-object p0
.end method

.method public final setLoadTraceScreenName(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->g:Ljava/lang/String;

    return-void
.end method

.method public final setNetworkConfig(LB6/c$b;)LB6/c$a;
    .registers 3

    const-string v0, "networkConfig"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LB6/c$a;->e:LB6/c$b;

    return-object p0
.end method

.method public final setNetworkConfig(LB6/c$b;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->e:LB6/c$b;

    return-void
.end method

.method public final setNetworkLoadObserver(LA6/d;)LB6/c$a;
    .registers 2

    iput-object p1, p0, LB6/c$a;->i:LA6/d;

    return-object p0
.end method

.method public final setNetworkLoadObserver(LA6/d;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->i:LA6/d;

    return-void
.end method

.method public final setReactDBHelper(Lcom/flipkart/android/reactmultiwidget/db/b;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    return-void
.end method

.method public final setSerializer(Lcom/flipkart/android/gson/Serializer;)LB6/c$a;
    .registers 3

    const-string v0, "serializer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    return-object p0
.end method

.method public final setSerializer(Lcom/flipkart/android/gson/Serializer;)V
    .registers 2

    iput-object p1, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Builder(context="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LB6/c$a;->a:Landroid/content/Context;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", reactDBHelper="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->b:Lcom/flipkart/android/reactmultiwidget/db/b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", serializer="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->c:Lcom/flipkart/android/gson/Serializer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", dgEventsController="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->d:Lcom/flipkart/android/datagovernance/DGEventsController;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", networkConfig="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->e:LB6/c$b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", coroutineScope="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->f:Lkotlinx/coroutines/G;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", loadTraceScreenName="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", databaseLoadObserver="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->h:LA6/a;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", networkLoadObserver="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LB6/c$a;->i:LA6/d;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
