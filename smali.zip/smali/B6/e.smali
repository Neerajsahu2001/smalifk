.class public final Lb6/e;
.super Ljava/lang/Object;
.source "SearchByVoiceInputWidget.kt"

# interfaces
.implements Lki/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lki/b<",
        "Lcom/flipkart/satyabhama/models/BaseRequest;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lb6/d;


# direct methods
.method constructor <init>(Lb6/d;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb6/e;->a:Lb6/d;

    return-void
.end method


# virtual methods
.method public onLoadFailure(Ljava/lang/Exception;Lcom/flipkart/satyabhama/models/BaseRequest;)Z
    .registers 4

    const-string v0, "e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "model"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Lb6/e;->a:Lb6/d;

    invoke-static {p1}, Lb6/d;->access$getMRecognitionProgressView$p(Lb6/d;)Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;

    move-result-object p2

    if-eqz p2, :cond_24

    invoke-static {p1}, Lb6/d;->access$getContext(Lb6/d;)Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0601f7

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result p1

    invoke-virtual {p2, p1}, Lcom/flipkart/android/customviews/speechrecognitionview/RecognitionProgressView;->setSingleColor(I)V

    :cond_24
    const/4 p1, 0x0

    return p1
.end method

.method public bridge synthetic onLoadFailure(Ljava/lang/Exception;Ljava/lang/Object;)Z
    .registers 3

    check-cast p2, Lcom/flipkart/satyabhama/models/BaseRequest;

    invoke-virtual {p0, p1, p2}, Lb6/e;->onLoadFailure(Ljava/lang/Exception;Lcom/flipkart/satyabhama/models/BaseRequest;)Z

    move-result p1

    return p1
.end method

.method public onLoadSuccess(Ljava/lang/Object;Lcom/flipkart/satyabhama/models/BaseRequest;Z)Z
    .registers 4

    const-string p3, "resource"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "model"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return p1
.end method

.method public bridge synthetic onLoadSuccess(Ljava/lang/Object;Ljava/lang/Object;Z)Z
    .registers 4

    check-cast p2, Lcom/flipkart/satyabhama/models/BaseRequest;

    invoke-virtual {p0, p1, p2, p3}, Lb6/e;->onLoadSuccess(Ljava/lang/Object;Lcom/flipkart/satyabhama/models/BaseRequest;Z)Z

    move-result p1

    return p1
.end method
