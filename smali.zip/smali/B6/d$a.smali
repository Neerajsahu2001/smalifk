.class public interface abstract Lb6/d$a;
.super Ljava/lang/Object;
.source "SearchByVoiceInputWidget.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb6/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract packetCreated(I)V
.end method

.method public abstract packetUploaded(I)V
.end method

.method public abstract recordingStopped()V
.end method
