.class final LB6/b$a;
.super Lkotlin/jvm/internal/p;
.source "MapiRequestUtils.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB6/b;-><init>(Lcom/flipkart/android/gson/Serializer;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LB6/b;


# direct methods
.method constructor <init>(LB6/b;)V
    .registers 2

    iput-object p1, p0, LB6/b$a;->a:LB6/b;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, LB6/b$a;->invoke()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final invoke()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LB6/b$a;->a:LB6/b;

    invoke-static {v0}, LB6/b;->access$createResourceVersion(LB6/b;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
