.class public final LB6/c$d$a;
.super Ljava/lang/Object;
.source "ReactDataProvider.kt"

# interfaces
.implements Lva/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB6/c$d;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lva/b<",
        "LGe/e0<",
        "Lxk/s;",
        ">;",
        "LGe/e0<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lwd/t;

.field final synthetic b:Z

.field final synthetic c:LXn/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LXn/d<",
            "Ly6/b;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic d:LB6/c;

.field final synthetic e:Lcom/flipkart/android/perf/b;

.field final synthetic f:Lcom/flipkart/android/perf/b;

.field final synthetic g:Lcom/flipkart/android/perf/a$b;


# direct methods
.method constructor <init>(Lwd/t;ZLXn/i;LB6/c;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/a$b;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB6/c$d$a;->a:Lwd/t;

    iput-boolean p2, p0, LB6/c$d$a;->b:Z

    iput-object p3, p0, LB6/c$d$a;->c:LXn/d;

    iput-object p4, p0, LB6/c$d$a;->d:LB6/c;

    iput-object p5, p0, LB6/c$d$a;->e:Lcom/flipkart/android/perf/b;

    iput-object p6, p0, LB6/c$d$a;->f:Lcom/flipkart/android/perf/b;

    iput-object p7, p0, LB6/c$d$a;->g:Lcom/flipkart/android/perf/a$b;

    return-void
.end method


# virtual methods
.method public onFailure(Lta/a;Lwa/a;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lwa/a<",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    const-string v0, "errorInfo"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lz6/b;->a:Lz6/b;

    iget-object v1, p0, LB6/c$d$a;->a:Lwd/t;

    iget-object v2, v1, Lwd/t;->a:Ljava/lang/String;

    const-string v3, "pageRequest.pageUri"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lz6/b;->removeCall(Ljava/lang/String;)V

    iget-object v0, p0, LB6/c$d$a;->f:Lcom/flipkart/android/perf/b;

    invoke-static {p2, v0}, Lcom/flipkart/android/perf/f;->stopTraceForFailure(Lwa/a;Lcom/flipkart/android/perf/b;)V

    iget-object v0, p0, LB6/c$d$a;->e:Lcom/flipkart/android/perf/b;

    invoke-static {p2, v0}, Lcom/flipkart/android/perf/f;->stopTraceForFailure(Lwa/a;Lcom/flipkart/android/perf/b;)V

    iget-object v0, v1, Lwd/t;->a:Ljava/lang/String;

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v1, Lwd/t;->b:Lwd/r;

    const/4 v4, 0x0

    if-eqz v2, :cond_2a

    iget-object v2, v2, Lwd/r;->e:Ljava/lang/Integer;

    goto :goto_2b

    :cond_2a
    move-object v2, v4

    :goto_2b
    iget v5, p2, Lwa/a;->b:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget-object v7, p0, LB6/c$d$a;->d:LB6/c;

    iget-object v8, p0, LB6/c$d$a;->g:Lcom/flipkart/android/perf/a$b;

    invoke-static {v7, v8, v0, v2, v6}, LB6/c;->access$stopLoadTrace(LB6/c;Lcom/flipkart/android/perf/a$b;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;)V

    invoke-static {v7}, LB6/c;->access$getNetworkLoadObserver$p(LB6/c;)LA6/d;

    move-result-object v0

    if-eqz v0, :cond_4b

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget-object v6, v1, Lwd/t;->b:Lwd/r;

    if-eqz v6, :cond_48

    iget-object v4, v6, Lwd/r;->e:Ljava/lang/Integer;

    :cond_48
    invoke-interface {v0, v2, v4}, LA6/d;->onNetworkCallFailure(Ljava/lang/Integer;Ljava/lang/Integer;)V

    :cond_4b
    new-instance v0, LHc/b;

    invoke-direct {v0}, LHc/b;-><init>()V

    iput v5, v0, LHc/b;->a:I

    iget-object v2, p2, Lwa/a;->d:Ljava/lang/String;

    iput-object v2, v0, LHc/b;->b:Ljava/lang/String;

    iget-object v2, p2, Lwa/a;->f:Ljava/lang/Object;

    check-cast v2, LGe/e0;

    if-eqz v2, :cond_64

    iget-object v2, v2, LGe/e0;->a:Ljava/lang/Object;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, LHc/b;->c:Ljava/lang/String;

    :cond_64
    if-eqz p1, :cond_78

    invoke-interface {p1}, Lta/a;->request()Lokhttp3/Request;

    move-result-object p1

    if-eqz p1, :cond_78

    invoke-virtual {p1}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object p1

    if-eqz p1, :cond_78

    invoke-virtual {p1}, Lokhttp3/HttpUrl;->toString()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_7d

    :cond_78
    iget-object p1, v1, Lwd/t;->a:Ljava/lang/String;

    invoke-static {p1, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_7d
    iget-object v1, v1, Lwd/t;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v7, p2, p1, v1}, LB6/c;->access$sendClientErrorEvent(LB6/c;Lwa/a;Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Ly6/b$b;

    invoke-direct {p1, v0}, Ly6/b$b;-><init>(LHc/b;)V

    iget-object p2, p0, LB6/c$d$a;->c:LXn/d;

    invoke-interface {p2, p1}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    return-void
.end method

.method public onSuccess(Lta/a;Lretrofit2/F;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lta/a<",
            "LGe/e0<",
            "Lxk/s;",
            ">;",
            "LGe/e0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lretrofit2/F<",
            "LGe/e0<",
            "Lxk/s;",
            ">;>;)V"
        }
    .end annotation

    sget-object p1, Lz6/b;->a:Lz6/b;

    iget-object v0, p0, LB6/c$d$a;->a:Lwd/t;

    iget-object v0, v0, Lwd/t;->a:Ljava/lang/String;

    const-string v1, "pageRequest.pageUri"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Lz6/b;->removeCall(Ljava/lang/String;)V

    iget-boolean p1, p0, LB6/c$d$a;->b:Z

    if-nez p1, :cond_26

    iget-object v4, p0, LB6/c$d$a;->f:Lcom/flipkart/android/perf/b;

    iget-object v5, p0, LB6/c$d$a;->g:Lcom/flipkart/android/perf/a$b;

    iget-object v0, p0, LB6/c$d$a;->d:LB6/c;

    iget-object v2, p0, LB6/c$d$a;->a:Lwd/t;

    iget-object v3, p0, LB6/c$d$a;->e:Lcom/flipkart/android/perf/b;

    move-object v1, p2

    invoke-static/range {v0 .. v5}, LB6/c;->access$handleSuccessfulResponse(LB6/c;Lretrofit2/F;Lwd/t;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/a$b;)Ly6/b;

    move-result-object p1

    iget-object p2, p0, LB6/c$d$a;->c:LXn/d;

    invoke-interface {p2, p1}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    :cond_26
    return-void
.end method

.method public performUpdate(Lretrofit2/F;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/F<",
            "LGe/e0<",
            "Lxk/s;",
            ">;>;)V"
        }
    .end annotation

    iget-object v0, p0, LB6/c$d$a;->d:LB6/c;

    invoke-static {v0}, LB6/c;->access$getContext$p(LB6/c;)Landroid/content/Context;

    move-result-object v0

    if-eqz p1, :cond_13

    invoke-virtual {p1}, Lretrofit2/F;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGe/e0;

    if-eqz v1, :cond_13

    iget-object v1, v1, LGe/e0;->l:LNf/b;

    goto :goto_14

    :cond_13
    const/4 v1, 0x0

    :goto_14
    invoke-static {v0, v1}, La8/h;->processFlippiResponse(Landroid/content/Context;LNf/b;)V

    iget-boolean v0, p0, LB6/c$d$a;->b:Z

    if-eqz v0, :cond_2f

    iget-object v5, p0, LB6/c$d$a;->f:Lcom/flipkart/android/perf/b;

    iget-object v6, p0, LB6/c$d$a;->g:Lcom/flipkart/android/perf/a$b;

    iget-object v1, p0, LB6/c$d$a;->d:LB6/c;

    iget-object v3, p0, LB6/c$d$a;->a:Lwd/t;

    iget-object v4, p0, LB6/c$d$a;->e:Lcom/flipkart/android/perf/b;

    move-object v2, p1

    invoke-static/range {v1 .. v6}, LB6/c;->access$handleSuccessfulResponse(LB6/c;Lretrofit2/F;Lwd/t;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/b;Lcom/flipkart/android/perf/a$b;)Ly6/b;

    move-result-object p1

    iget-object v0, p0, LB6/c$d$a;->c:LXn/d;

    invoke-interface {v0, p1}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    :cond_2f
    return-void
.end method
