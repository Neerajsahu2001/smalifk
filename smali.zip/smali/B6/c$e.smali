.class final LB6/c$e;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactDataProvider.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB6/c;->fetchPaginatedData(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)Lzp/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lzp/c<",
        "-",
        "Ly6/b;",
        ">;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.repository.ReactDataProvider$fetchPaginatedData$1"
    f = "ReactDataProvider.kt"
    l = {
        0x62
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field private synthetic b:Ljava/lang/Object;

.field final synthetic c:LB6/c;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Lcom/facebook/react/bridge/ReadableMap;


# direct methods
.method constructor <init>(LB6/c;Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;LXn/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LB6/c;",
            "Ljava/lang/String;",
            "Lcom/facebook/react/bridge/ReadableMap;",
            "LXn/d<",
            "-",
            "LB6/c$e;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LB6/c$e;->c:LB6/c;

    iput-object p2, p0, LB6/c$e;->d:Ljava/lang/String;

    iput-object p3, p0, LB6/c$e;->e:Lcom/facebook/react/bridge/ReadableMap;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance v0, LB6/c$e;

    iget-object v1, p0, LB6/c$e;->d:Ljava/lang/String;

    iget-object v2, p0, LB6/c$e;->e:Lcom/facebook/react/bridge/ReadableMap;

    iget-object v3, p0, LB6/c$e;->c:LB6/c;

    invoke-direct {v0, v3, v1, v2, p2}, LB6/c$e;-><init>(LB6/c;Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;LXn/d;)V

    iput-object p1, v0, LB6/c$e;->b:Ljava/lang/Object;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lzp/c;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LB6/c$e;->invoke(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lzp/c;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/c<",
            "-",
            "Ly6/b;",
            ">;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LB6/c$e;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LB6/c$e;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LB6/c$e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LB6/c$e;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_42

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LB6/c$e;->b:Ljava/lang/Object;

    check-cast p1, Lzp/c;

    iget-object v1, p0, LB6/c$e;->c:LB6/c;

    invoke-virtual {v1}, LB6/c;->getMapiRequestUtils$flipkart_ecom_app_uploadSigned()LB6/b;

    move-result-object v3

    iget-object v4, p0, LB6/c$e;->e:Lcom/facebook/react/bridge/ReadableMap;

    invoke-static {v1}, LB6/c;->access$getNetworkConfig$p(LB6/c;)LB6/c$b;

    move-result-object v5

    iget-object v6, p0, LB6/c$e;->d:Ljava/lang/String;

    invoke-virtual {v3, v6, v4, v5}, LB6/b;->createPaginationRequest(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;LB6/c$b;)Lwd/t;

    move-result-object v3

    if-eqz v3, :cond_42

    invoke-virtual {v1, v3}, LB6/c;->fetchPageFromNetwork$flipkart_ecom_app_uploadSigned(Lwd/t;)Lzp/b;

    move-result-object v1

    new-instance v3, LB6/c$e$a;

    invoke-direct {v3, p1}, LB6/c$e$a;-><init>(Lzp/c;)V

    iput v2, p0, LB6/c$e;->a:I

    invoke-interface {v1, v3, p0}, Lzp/b;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_42

    return-object v0

    :cond_42
    :goto_42
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
