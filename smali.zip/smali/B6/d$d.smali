.class public final Lb6/d$d;
.super Ljava/lang/Object;
.source "SearchByVoiceInputWidget.kt"

# interfaces
.implements Lb6/d$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb6/d;->h()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lb6/d;


# direct methods
.method constructor <init>(Lb6/d;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb6/d$d;->a:Lb6/d;

    return-void
.end method


# virtual methods
.method public packetCreated(I)V
    .registers 3

    const/4 v0, 0x1

    if-ne p1, v0, :cond_e

    iget-object p1, p0, Lb6/d$d;->a:Lb6/d;

    invoke-static {p1}, Lb6/d;->access$getVoiceQueryLatencyTracker$p(Lb6/d;)Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    move-result-object p1

    if-eqz p1, :cond_e

    invoke-virtual {p1}, Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;->trackFirstPacketCreated()V

    :cond_e
    return-void
.end method

.method public packetUploaded(I)V
    .registers 3

    iget-object p1, p0, Lb6/d$d;->a:Lb6/d;

    invoke-static {p1}, Lb6/d;->access$getNavigationContext(Lb6/d;)Lcom/flipkart/android/datagovernance/NavigationContext;

    move-result-object v0

    if-eqz v0, :cond_11

    invoke-static {p1}, Lb6/d;->access$getVoiceQueryLatencyTracker$p(Lb6/d;)Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    move-result-object p1

    if-eqz p1, :cond_11

    invoke-virtual {p1, v0}, Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;->trackPacketUploaded(Lcom/flipkart/android/datagovernance/NavigationContext;)V

    :cond_11
    return-void
.end method

.method public recordingStopped()V
    .registers 2

    iget-object v0, p0, Lb6/d$d;->a:Lb6/d;

    invoke-static {v0}, Lb6/d;->access$getVoiceQueryLatencyTracker$p(Lb6/d;)Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;

    move-result-object v0

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Lcom/flipkart/android/voice/util/metric/VoiceQueryLatencyTracker;->trackStopRecording()V

    :cond_b
    return-void
.end method
