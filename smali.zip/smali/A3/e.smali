.class public final La3/e;
.super Ljava/lang/Object;
.source "RoundingParams.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La3/e$a;
    }
.end annotation


# instance fields
.field private a:La3/e$a;

.field private b:Z

.field private c:[F

.field private d:I

.field private e:F

.field private f:I

.field private g:F

.field private h:Z


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, La3/e$a;->BITMAP_ONLY:La3/e$a;

    iput-object v0, p0, La3/e;->a:La3/e$a;

    const/4 v0, 0x0

    iput-boolean v0, p0, La3/e;->b:Z

    const/4 v1, 0x0

    iput-object v1, p0, La3/e;->c:[F

    iput v0, p0, La3/e;->d:I

    const/4 v1, 0x0

    iput v1, p0, La3/e;->e:F

    iput v0, p0, La3/e;->f:I

    iput v1, p0, La3/e;->g:F

    iput-boolean v0, p0, La3/e;->h:Z

    return-void
.end method

.method public static a()La3/e;
    .registers 3

    new-instance v0, La3/e;

    invoke-direct {v0}, La3/e;-><init>()V

    iget-object v1, v0, La3/e;->c:[F

    if-nez v1, :cond_f

    const/16 v1, 0x8

    new-array v1, v1, [F

    iput-object v1, v0, La3/e;->c:[F

    :cond_f
    iget-object v1, v0, La3/e;->c:[F

    const/4 v2, 0x0

    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([FF)V

    return-object v0
.end method


# virtual methods
.method public final b()I
    .registers 2

    iget v0, p0, La3/e;->f:I

    return v0
.end method

.method public final c()F
    .registers 2

    iget v0, p0, La3/e;->e:F

    return v0
.end method

.method public final d()[F
    .registers 2

    iget-object v0, p0, La3/e;->c:[F

    return-object v0
.end method

.method public final e()I
    .registers 2

    iget v0, p0, La3/e;->d:I

    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    const/4 v0, 0x0

    if-eqz p1, :cond_54

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-class v2, La3/e;

    if-eq v2, v1, :cond_10

    goto :goto_54

    :cond_10
    check-cast p1, La3/e;

    iget-boolean v1, p0, La3/e;->b:Z

    iget-boolean v2, p1, La3/e;->b:Z

    if-eq v1, v2, :cond_19

    return v0

    :cond_19
    iget v1, p0, La3/e;->d:I

    iget v2, p1, La3/e;->d:I

    if-eq v1, v2, :cond_20

    return v0

    :cond_20
    iget v1, p1, La3/e;->e:F

    iget v2, p0, La3/e;->e:F

    invoke-static {v1, v2}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_2b

    return v0

    :cond_2b
    iget v1, p0, La3/e;->f:I

    iget v2, p1, La3/e;->f:I

    if-eq v1, v2, :cond_32

    return v0

    :cond_32
    iget v1, p1, La3/e;->g:F

    iget v2, p0, La3/e;->g:F

    invoke-static {v1, v2}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_3d

    return v0

    :cond_3d
    iget-object v1, p0, La3/e;->a:La3/e$a;

    iget-object v2, p1, La3/e;->a:La3/e$a;

    if-eq v1, v2, :cond_44

    return v0

    :cond_44
    iget-boolean v1, p0, La3/e;->h:Z

    iget-boolean v2, p1, La3/e;->h:Z

    if-eq v1, v2, :cond_4b

    return v0

    :cond_4b
    iget-object v0, p0, La3/e;->c:[F

    iget-object p1, p1, La3/e;->c:[F

    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([F[F)Z

    move-result p1

    return p1

    :cond_54
    :goto_54
    return v0
.end method

.method public final f()F
    .registers 2

    iget v0, p0, La3/e;->g:F

    return v0
.end method

.method public final g()Z
    .registers 2

    iget-boolean v0, p0, La3/e;->h:Z

    return v0
.end method

.method public final h()Z
    .registers 2

    iget-boolean v0, p0, La3/e;->b:Z

    return v0
.end method

.method public final hashCode()I
    .registers 6

    iget-object v0, p0, La3/e;->a:La3/e$a;

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v2, p0, La3/e;->b:Z

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, La3/e;->c:[F

    if-eqz v2, :cond_1b

    invoke-static {v2}, Ljava/util/Arrays;->hashCode([F)I

    move-result v2

    goto :goto_1c

    :cond_1b
    const/4 v2, 0x0

    :goto_1c
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget v2, p0, La3/e;->d:I

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget v2, p0, La3/e;->e:F

    const/4 v3, 0x0

    cmpl-float v4, v2, v3

    if-eqz v4, :cond_30

    invoke-static {v2}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v2

    goto :goto_31

    :cond_30
    const/4 v2, 0x0

    :goto_31
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget v2, p0, La3/e;->f:I

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget v2, p0, La3/e;->g:F

    cmpl-float v3, v2, v3

    if-eqz v3, :cond_43

    invoke-static {v2}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v1

    :cond_43
    add-int/2addr v0, v1

    mul-int/lit16 v0, v0, 0x3c1

    iget-boolean v1, p0, La3/e;->h:Z

    add-int/2addr v0, v1

    return v0
.end method

.method public final i()La3/e$a;
    .registers 2

    iget-object v0, p0, La3/e;->a:La3/e$a;

    return-object v0
.end method

.method public final j(FI)V
    .registers 5

    const/4 v0, 0x0

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_7

    const/4 v0, 0x1

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    const-string v1, "the border width cannot be < 0"

    invoke-static {v0, v1}, LD2/j;->b(ZLjava/lang/String;)V

    iput p1, p0, La3/e;->e:F

    iput p2, p0, La3/e;->f:I

    return-void
.end method

.method public final k(I)V
    .registers 2

    iput p1, p0, La3/e;->f:I

    return-void
.end method

.method public final l(F)V
    .registers 4

    const/4 v0, 0x0

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_7

    const/4 v0, 0x1

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    const-string v1, "the border width cannot be < 0"

    invoke-static {v0, v1}, LD2/j;->b(ZLjava/lang/String;)V

    iput p1, p0, La3/e;->e:F

    return-void
.end method

.method public final m(FFFF)V
    .registers 7

    iget-object v0, p0, La3/e;->c:[F

    if-nez v0, :cond_a

    const/16 v0, 0x8

    new-array v0, v0, [F

    iput-object v0, p0, La3/e;->c:[F

    :cond_a
    iget-object v0, p0, La3/e;->c:[F

    const/4 v1, 0x1

    aput p1, v0, v1

    const/4 v1, 0x0

    aput p1, v0, v1

    const/4 p1, 0x3

    aput p2, v0, p1

    const/4 p1, 0x2

    aput p2, v0, p1

    const/4 p1, 0x5

    aput p3, v0, p1

    const/4 p1, 0x4

    aput p3, v0, p1

    const/4 p1, 0x7

    aput p4, v0, p1

    const/4 p1, 0x6

    aput p4, v0, p1

    return-void
.end method

.method public final n(I)V
    .registers 2

    iput p1, p0, La3/e;->d:I

    sget-object p1, La3/e$a;->OVERLAY_COLOR:La3/e$a;

    iput-object p1, p0, La3/e;->a:La3/e$a;

    return-void
.end method

.method public final o(F)V
    .registers 4

    const/4 v0, 0x0

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_7

    const/4 v0, 0x1

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    const-string v1, "the padding cannot be < 0"

    invoke-static {v0, v1}, LD2/j;->b(ZLjava/lang/String;)V

    iput p1, p0, La3/e;->g:F

    return-void
.end method

.method public final p()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, La3/e;->h:Z

    return-void
.end method

.method public final q(Z)V
    .registers 2

    iput-boolean p1, p0, La3/e;->b:Z

    return-void
.end method

.method public final r(La3/e$a;)V
    .registers 2

    iput-object p1, p0, La3/e;->a:La3/e$a;

    return-void
.end method
