.class public final La3/c;
.super Ljava/lang/Object;
.source "GenericDraweeHierarchyInflater.java"


# direct methods
.method private static a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;
    .registers 4

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p1

    if-nez p1, :cond_9

    const/4 p0, 0x0

    goto :goto_11

    :cond_9
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    :goto_11
    return-object p0
.end method

.method private static b(La3/b;)La3/e;
    .registers 2

    invoke-virtual {p0}, La3/b;->q()La3/e;

    move-result-object v0

    if-nez v0, :cond_e

    new-instance v0, La3/e;

    invoke-direct {v0}, La3/e;-><init>()V

    invoke-virtual {p0, v0}, La3/b;->F(La3/e;)V

    :cond_e
    invoke-virtual {p0}, La3/b;->q()La3/e;

    move-result-object p0

    return-object p0
.end method

.method private static c(Landroid/content/res/TypedArray;I)Lcom/facebook/drawee/drawable/r$a;
    .registers 3

    const/4 v0, -0x2

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p0

    packed-switch p0, :pswitch_data_40

    new-instance p0, Ljava/lang/RuntimeException;

    const-string p1, "XML attribute not specified!"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_10
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->i:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_15
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->h:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_1a
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->g:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_1f
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->f:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_24
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->e:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_29
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->d:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_2e
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->c:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_33
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->b:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_38
    sget-object p0, Lcom/facebook/drawee/drawable/r$b;->a:Lcom/facebook/drawee/drawable/r$b;

    check-cast p0, Lcom/facebook/drawee/drawable/r$a;

    return-object p0

    :pswitch_3d
    const/4 p0, 0x0

    return-object p0

    nop

    :pswitch_data_40
    .packed-switch -0x1
        :pswitch_3d
        :pswitch_38
        :pswitch_33
        :pswitch_2e
        :pswitch_29
        :pswitch_24
        :pswitch_1f
        :pswitch_1a
        :pswitch_15
        :pswitch_10
    .end packed-switch
.end method

.method public static d(Landroid/content/Context;Landroid/util/AttributeSet;)La3/b;
    .registers 20

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    invoke-static {}, Lt3/b;->b()V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    new-instance v3, La3/b;

    invoke-direct {v3, v2}, La3/b;-><init>(Landroid/content/res/Resources;)V

    if-eqz v0, :cond_21c

    sget-object v6, LR2/a;->GenericDraweeHierarchy:[I

    invoke-virtual {v1, v0, v6}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v6

    :try_start_18
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v0
    :try_end_1c
    .catchall {:try_start_18 .. :try_end_1c} :catchall_202

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x1

    const/4 v15, 0x1

    const/16 v17, 0x0

    :goto_28
    if-ge v7, v0, :cond_1b1

    :try_start_2a
    invoke-virtual {v6, v7}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v4

    sget v5, LR2/a;->GenericDraweeHierarchy_actualImageScaleType:I

    if-ne v4, v5, :cond_43

    invoke-static {v6, v4}, La3/c;->c(Landroid/content/res/TypedArray;I)Lcom/facebook/drawee/drawable/r$a;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->r(Lcom/facebook/drawee/drawable/r$a;)V

    :goto_39
    move/from16 p1, v0

    :goto_3b
    move/from16 v5, v17

    :cond_3d
    :goto_3d
    const/4 v1, 0x0

    goto/16 :goto_1a7

    :catchall_40
    move-exception v0

    goto/16 :goto_20b

    :cond_43
    sget v5, LR2/a;->GenericDraweeHierarchy_placeholderImage:I

    if-ne v4, v5, :cond_4f

    invoke-static {v1, v6, v4}, La3/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->y(Landroid/graphics/drawable/Drawable;)V

    goto :goto_39

    :cond_4f
    sget v5, LR2/a;->GenericDraweeHierarchy_pressedStateOverlayImage:I

    if-ne v4, v5, :cond_5b

    invoke-static {v1, v6, v4}, La3/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->A(Landroid/graphics/drawable/Drawable;)V

    goto :goto_39

    :cond_5b
    sget v5, LR2/a;->GenericDraweeHierarchy_progressBarImage:I

    if-ne v4, v5, :cond_67

    invoke-static {v1, v6, v4}, La3/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->B(Landroid/graphics/drawable/Drawable;)V

    goto :goto_39

    :cond_67
    sget v5, LR2/a;->GenericDraweeHierarchy_fadeDuration:I

    if-ne v4, v5, :cond_74

    const/4 v5, 0x0

    invoke-virtual {v6, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    invoke-virtual {v3, v4}, La3/b;->u(I)V

    goto :goto_39

    :cond_74
    sget v5, LR2/a;->GenericDraweeHierarchy_viewAspectRatio:I

    if-ne v4, v5, :cond_81

    const/4 v5, 0x0

    invoke-virtual {v6, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-virtual {v3, v4}, La3/b;->t(F)V

    goto :goto_39

    :cond_81
    sget v5, LR2/a;->GenericDraweeHierarchy_placeholderImageScaleType:I

    if-ne v4, v5, :cond_8d

    invoke-static {v6, v4}, La3/c;->c(Landroid/content/res/TypedArray;I)Lcom/facebook/drawee/drawable/r$a;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->z(Lcom/facebook/drawee/drawable/r$a;)V

    goto :goto_39

    :cond_8d
    sget v5, LR2/a;->GenericDraweeHierarchy_retryImage:I

    if-ne v4, v5, :cond_99

    invoke-static {v1, v6, v4}, La3/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->D(Landroid/graphics/drawable/Drawable;)V

    goto :goto_39

    :cond_99
    sget v5, LR2/a;->GenericDraweeHierarchy_retryImageScaleType:I

    if-ne v4, v5, :cond_a5

    invoke-static {v6, v4}, La3/c;->c(Landroid/content/res/TypedArray;I)Lcom/facebook/drawee/drawable/r$a;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->E(Lcom/facebook/drawee/drawable/r$a;)V

    goto :goto_39

    :cond_a5
    sget v5, LR2/a;->GenericDraweeHierarchy_failureImage:I

    if-ne v4, v5, :cond_b1

    invoke-static {v1, v6, v4}, La3/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->v(Landroid/graphics/drawable/Drawable;)V

    goto :goto_39

    :cond_b1
    sget v5, LR2/a;->GenericDraweeHierarchy_failureImageScaleType:I

    if-ne v4, v5, :cond_be

    invoke-static {v6, v4}, La3/c;->c(Landroid/content/res/TypedArray;I)Lcom/facebook/drawee/drawable/r$a;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->w(Lcom/facebook/drawee/drawable/r$a;)V

    goto/16 :goto_39

    :cond_be
    sget v5, LR2/a;->GenericDraweeHierarchy_progressBarImageScaleType:I

    if-ne v4, v5, :cond_cb

    invoke-static {v6, v4}, La3/c;->c(Landroid/content/res/TypedArray;I)Lcom/facebook/drawee/drawable/r$a;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->C(Lcom/facebook/drawee/drawable/r$a;)V

    goto/16 :goto_39

    :cond_cb
    sget v5, LR2/a;->GenericDraweeHierarchy_progressBarAutoRotateInterval:I

    if-ne v4, v5, :cond_d8

    invoke-virtual {v6, v4, v2}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v2

    move/from16 p1, v0

    :goto_d5
    const/4 v1, 0x0

    goto/16 :goto_1a9

    :cond_d8
    sget v5, LR2/a;->GenericDraweeHierarchy_backgroundImage:I

    if-ne v4, v5, :cond_e5

    invoke-static {v1, v6, v4}, La3/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->s(Landroid/graphics/drawable/Drawable;)V

    goto/16 :goto_39

    :cond_e5
    sget v5, LR2/a;->GenericDraweeHierarchy_overlayImage:I

    if-ne v4, v5, :cond_f2

    invoke-static {v1, v6, v4}, La3/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, La3/b;->x(Landroid/graphics/drawable/Drawable;)V

    goto/16 :goto_39

    :cond_f2
    sget v5, LR2/a;->GenericDraweeHierarchy_roundAsCircle:I

    if-ne v4, v5, :cond_106

    invoke-static {v3}, La3/c;->b(La3/b;)La3/e;

    move-result-object v5

    move/from16 p1, v0

    const/4 v0, 0x0

    invoke-virtual {v6, v4, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    invoke-virtual {v5, v4}, La3/e;->q(Z)V

    goto/16 :goto_3b

    :cond_106
    move/from16 p1, v0

    sget v0, LR2/a;->GenericDraweeHierarchy_roundedCornerRadius:I

    if-ne v4, v0, :cond_113

    move/from16 v5, v17

    invoke-virtual {v6, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v17

    goto :goto_d5

    :cond_113
    move/from16 v5, v17

    sget v0, LR2/a;->GenericDraweeHierarchy_roundTopLeft:I

    if-ne v4, v0, :cond_120

    invoke-virtual {v6, v4, v8}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v8

    :goto_11d
    move/from16 v17, v5

    goto :goto_d5

    :cond_120
    sget v0, LR2/a;->GenericDraweeHierarchy_roundTopRight:I

    if-ne v4, v0, :cond_129

    invoke-virtual {v6, v4, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v10

    goto :goto_11d

    :cond_129
    sget v0, LR2/a;->GenericDraweeHierarchy_roundBottomLeft:I

    if-ne v4, v0, :cond_132

    invoke-virtual {v6, v4, v14}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v14

    goto :goto_11d

    :cond_132
    sget v0, LR2/a;->GenericDraweeHierarchy_roundBottomRight:I

    if-ne v4, v0, :cond_13b

    invoke-virtual {v6, v4, v12}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v12

    goto :goto_11d

    :cond_13b
    sget v0, LR2/a;->GenericDraweeHierarchy_roundTopStart:I

    if-ne v4, v0, :cond_144

    invoke-virtual {v6, v4, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v9

    goto :goto_11d

    :cond_144
    sget v0, LR2/a;->GenericDraweeHierarchy_roundTopEnd:I

    if-ne v4, v0, :cond_14d

    invoke-virtual {v6, v4, v11}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v11

    goto :goto_11d

    :cond_14d
    sget v0, LR2/a;->GenericDraweeHierarchy_roundBottomStart:I

    if-ne v4, v0, :cond_156

    invoke-virtual {v6, v4, v15}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v15

    goto :goto_11d

    :cond_156
    sget v0, LR2/a;->GenericDraweeHierarchy_roundBottomEnd:I

    if-ne v4, v0, :cond_15f

    invoke-virtual {v6, v4, v13}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v13

    goto :goto_11d

    :cond_15f
    sget v0, LR2/a;->GenericDraweeHierarchy_roundWithOverlayColor:I

    if-ne v4, v0, :cond_171

    invoke-static {v3}, La3/c;->b(La3/b;)La3/e;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v6, v4, v1}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v4

    invoke-virtual {v0, v4}, La3/e;->n(I)V

    goto/16 :goto_3d

    :cond_171
    sget v0, LR2/a;->GenericDraweeHierarchy_roundingBorderWidth:I

    if-ne v4, v0, :cond_184

    invoke-static {v3}, La3/c;->b(La3/b;)La3/e;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v6, v4, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    int-to-float v1, v4

    invoke-virtual {v0, v1}, La3/e;->l(F)V

    goto/16 :goto_3d

    :cond_184
    sget v0, LR2/a;->GenericDraweeHierarchy_roundingBorderColor:I

    if-ne v4, v0, :cond_196

    invoke-static {v3}, La3/c;->b(La3/b;)La3/e;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v6, v4, v1}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v4

    invoke-virtual {v0, v4}, La3/e;->k(I)V

    goto/16 :goto_3d

    :cond_196
    sget v0, LR2/a;->GenericDraweeHierarchy_roundingBorderPadding:I

    if-ne v4, v0, :cond_3d

    invoke-static {v3}, La3/c;->b(La3/b;)La3/e;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v6, v4, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v0, v4}, La3/e;->o(F)V
    :try_end_1a7
    .catchall {:try_start_2a .. :try_end_1a7} :catchall_40

    :goto_1a7
    move/from16 v17, v5

    :goto_1a9
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v1, p0

    move/from16 v0, p1

    goto/16 :goto_28

    :cond_1b1
    move/from16 v5, v17

    const/4 v1, 0x0

    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Configuration;->getLayoutDirection()I

    move-result v0

    const/4 v4, 0x1

    if-ne v0, v4, :cond_1e8

    if-eqz v8, :cond_1cc

    if-eqz v11, :cond_1cc

    const/4 v0, 0x1

    goto :goto_1cd

    :cond_1cc
    const/4 v0, 0x0

    :goto_1cd
    if-eqz v10, :cond_1d3

    if-eqz v9, :cond_1d3

    const/4 v4, 0x1

    goto :goto_1d4

    :cond_1d3
    const/4 v4, 0x0

    :goto_1d4
    if-eqz v12, :cond_1da

    if-eqz v15, :cond_1da

    const/4 v6, 0x1

    goto :goto_1db

    :cond_1da
    const/4 v6, 0x0

    :goto_1db
    if-eqz v14, :cond_1e2

    if-eqz v13, :cond_1e2

    :goto_1df
    const/16 v16, 0x1

    goto :goto_1e4

    :cond_1e2
    const/16 v16, 0x0

    :goto_1e4
    move v1, v5

    move v5, v2

    move v2, v0

    goto :goto_223

    :cond_1e8
    if-eqz v8, :cond_1ee

    if-eqz v9, :cond_1ee

    const/4 v0, 0x1

    goto :goto_1ef

    :cond_1ee
    const/4 v0, 0x0

    :goto_1ef
    if-eqz v10, :cond_1f5

    if-eqz v11, :cond_1f5

    const/4 v4, 0x1

    goto :goto_1f6

    :cond_1f5
    const/4 v4, 0x0

    :goto_1f6
    if-eqz v12, :cond_1fc

    if-eqz v13, :cond_1fc

    const/4 v6, 0x1

    goto :goto_1fd

    :cond_1fc
    const/4 v6, 0x0

    :goto_1fd
    if-eqz v14, :cond_1e2

    if-eqz v15, :cond_1e2

    goto :goto_1df

    :catchall_202
    move-exception v0

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x1

    const/4 v15, 0x1

    :goto_20b
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Configuration;->getLayoutDirection()I

    move-result v1

    const/4 v2, 0x1

    throw v0

    :cond_21c
    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/16 v16, 0x1

    :goto_223
    invoke-virtual {v3}, La3/b;->l()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_237

    if-lez v5, :cond_237

    new-instance v0, Lcom/facebook/drawee/drawable/c;

    invoke-virtual {v3}, La3/b;->l()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-direct {v0, v7, v5}, Lcom/facebook/drawee/drawable/c;-><init>(Landroid/graphics/drawable/Drawable;I)V

    invoke-virtual {v3, v0}, La3/b;->B(Landroid/graphics/drawable/Drawable;)V

    :cond_237
    if-lez v1, :cond_254

    invoke-static {v3}, La3/c;->b(La3/b;)La3/e;

    move-result-object v0

    if-eqz v2, :cond_241

    int-to-float v2, v1

    goto :goto_242

    :cond_241
    const/4 v2, 0x0

    :goto_242
    if-eqz v4, :cond_246

    int-to-float v4, v1

    goto :goto_247

    :cond_246
    const/4 v4, 0x0

    :goto_247
    if-eqz v6, :cond_24b

    int-to-float v5, v1

    goto :goto_24c

    :cond_24b
    const/4 v5, 0x0

    :goto_24c
    if-eqz v16, :cond_250

    int-to-float v1, v1

    goto :goto_251

    :cond_250
    const/4 v1, 0x0

    :goto_251
    invoke-virtual {v0, v2, v4, v5, v1}, La3/e;->m(FFFF)V

    :cond_254
    invoke-static {}, Lt3/b;->b()V

    return-object v3
.end method
