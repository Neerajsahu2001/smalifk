.class public final La3/f;
.super Ljava/lang/Object;
.source "WrappingUtils.java"


# static fields
.field private static final a:Landroid/graphics/drawable/ColorDrawable;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    sput-object v0, La3/f;->a:Landroid/graphics/drawable/ColorDrawable;

    return-void
.end method

.method private static a(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .registers 5

    instance-of v0, p0, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz v0, :cond_17

    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    new-instance v0, Lcom/facebook/drawee/drawable/l;

    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getPaint()Landroid/graphics/Paint;

    move-result-object p0

    invoke-direct {v0, p2, v1, p0}, Lcom/facebook/drawee/drawable/l;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;Landroid/graphics/Paint;)V

    invoke-static {v0, p1}, La3/f;->b(Lcom/facebook/drawee/drawable/k;La3/e;)V

    return-object v0

    :cond_17
    instance-of p2, p0, Landroid/graphics/drawable/NinePatchDrawable;

    if-eqz p2, :cond_26

    check-cast p0, Landroid/graphics/drawable/NinePatchDrawable;

    new-instance p2, Lcom/facebook/drawee/drawable/p;

    invoke-direct {p2, p0}, Lcom/facebook/drawee/drawable/p;-><init>(Landroid/graphics/drawable/NinePatchDrawable;)V

    invoke-static {p2, p1}, La3/f;->b(Lcom/facebook/drawee/drawable/k;La3/e;)V

    return-object p2

    :cond_26
    instance-of p2, p0, Landroid/graphics/drawable/ColorDrawable;

    if-eqz p2, :cond_39

    check-cast p0, Landroid/graphics/drawable/ColorDrawable;

    new-instance p2, Lcom/facebook/drawee/drawable/m;

    invoke-virtual {p0}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result p0

    invoke-direct {p2, p0}, Lcom/facebook/drawee/drawable/m;-><init>(I)V

    invoke-static {p2, p1}, La3/f;->b(Lcom/facebook/drawee/drawable/k;La3/e;)V

    return-object p2

    :cond_39
    const-string p1, "Don\'t know how to round that drawable: %s"

    const/4 p2, 0x1

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v0, 0x0

    aput-object p0, p2, v0

    const-string v0, "WrappingUtils"

    invoke-static {v0, p1, p2}, LE2/a;->C(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p0
.end method

.method static b(Lcom/facebook/drawee/drawable/k;La3/e;)V
    .registers 4

    invoke-virtual {p1}, La3/e;->h()Z

    move-result v0

    invoke-interface {p0, v0}, Lcom/facebook/drawee/drawable/k;->a(Z)V

    invoke-virtual {p1}, La3/e;->d()[F

    move-result-object v0

    invoke-interface {p0, v0}, Lcom/facebook/drawee/drawable/k;->h([F)V

    invoke-virtual {p1}, La3/e;->b()I

    move-result v0

    invoke-virtual {p1}, La3/e;->c()F

    move-result v1

    invoke-interface {p0, v1, v0}, Lcom/facebook/drawee/drawable/k;->b(FI)V

    invoke-virtual {p1}, La3/e;->f()F

    move-result v0

    invoke-interface {p0, v0}, Lcom/facebook/drawee/drawable/k;->c(F)V

    invoke-interface {p0}, Lcom/facebook/drawee/drawable/k;->g()V

    invoke-virtual {p1}, La3/e;->g()Z

    move-result p1

    invoke-interface {p0, p1}, Lcom/facebook/drawee/drawable/k;->e(Z)V

    return-void
.end method

.method static c(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .registers 6

    :try_start_0
    invoke-static {}, Lt3/b;->b()V

    if-eqz p0, :cond_41

    if-eqz p1, :cond_41

    invoke-virtual {p1}, La3/e;->i()La3/e$a;

    move-result-object v0

    sget-object v1, La3/e$a;->BITMAP_ONLY:La3/e$a;

    if-eq v0, v1, :cond_10

    goto :goto_41

    :cond_10
    instance-of v0, p0, Lcom/facebook/drawee/drawable/h;

    if-eqz v0, :cond_39

    move-object v0, p0

    check-cast v0, Lcom/facebook/drawee/drawable/h;

    :goto_17
    invoke-interface {v0}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-eq v1, v0, :cond_26

    instance-of v2, v1, Lcom/facebook/drawee/drawable/d;

    if-nez v2, :cond_22

    goto :goto_26

    :cond_22
    move-object v0, v1

    check-cast v0, Lcom/facebook/drawee/drawable/d;

    goto :goto_17

    :cond_26
    :goto_26
    sget-object v1, La3/f;->a:Landroid/graphics/drawable/ColorDrawable;

    invoke-interface {v0, v1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-static {v1, p1, p2}, La3/f;->a(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    :try_end_33
    .catchall {:try_start_0 .. :try_end_33} :catchall_37

    invoke-static {}, Lt3/b;->b()V

    return-object p0

    :catchall_37
    move-exception p0

    goto :goto_45

    :cond_39
    :try_start_39
    invoke-static {p0, p1, p2}, La3/f;->a(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p0
    :try_end_3d
    .catchall {:try_start_39 .. :try_end_3d} :catchall_37

    invoke-static {}, Lt3/b;->b()V

    return-object p0

    :cond_41
    :goto_41
    invoke-static {}, Lt3/b;->b()V

    return-object p0

    :goto_45
    invoke-static {}, Lt3/b;->b()V

    throw p0
.end method

.method static d(Landroid/graphics/drawable/Drawable;La3/e;)Landroid/graphics/drawable/Drawable;
    .registers 4

    :try_start_0
    invoke-static {}, Lt3/b;->b()V

    if-eqz p0, :cond_25

    if-eqz p1, :cond_25

    invoke-virtual {p1}, La3/e;->i()La3/e$a;

    move-result-object v0

    sget-object v1, La3/e$a;->OVERLAY_COLOR:La3/e$a;

    if-eq v0, v1, :cond_10

    goto :goto_25

    :cond_10
    new-instance v0, Lcom/facebook/drawee/drawable/n;

    invoke-direct {v0, p0}, Lcom/facebook/drawee/drawable/n;-><init>(Landroid/graphics/drawable/Drawable;)V

    invoke-static {v0, p1}, La3/f;->b(Lcom/facebook/drawee/drawable/k;La3/e;)V

    invoke-virtual {p1}, La3/e;->e()I

    move-result p0

    invoke-virtual {v0, p0}, Lcom/facebook/drawee/drawable/n;->i(I)V
    :try_end_1f
    .catchall {:try_start_0 .. :try_end_1f} :catchall_23

    invoke-static {}, Lt3/b;->b()V

    return-object v0

    :catchall_23
    move-exception p0

    goto :goto_29

    :cond_25
    :goto_25
    invoke-static {}, Lt3/b;->b()V

    return-object p0

    :goto_29
    invoke-static {}, Lt3/b;->b()V

    throw p0
.end method

.method static e(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;
    .registers 3

    invoke-static {}, Lt3/b;->b()V

    if-eqz p0, :cond_11

    if-nez p1, :cond_8

    goto :goto_11

    :cond_8
    new-instance v0, Lcom/facebook/drawee/drawable/q;

    invoke-direct {v0, p0, p1}, Lcom/facebook/drawee/drawable/q;-><init>(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)V

    invoke-static {}, Lt3/b;->b()V

    return-object v0

    :cond_11
    :goto_11
    invoke-static {}, Lt3/b;->b()V

    return-object p0
.end method

.method static f(Lcom/facebook/drawee/drawable/d;La3/e;Landroid/content/res/Resources;)V
    .registers 6

    :goto_0
    invoke-interface {p0}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eq v0, p0, :cond_f

    instance-of v1, v0, Lcom/facebook/drawee/drawable/d;

    if-nez v1, :cond_b

    goto :goto_f

    :cond_b
    move-object p0, v0

    check-cast p0, Lcom/facebook/drawee/drawable/d;

    goto :goto_0

    :cond_f
    :goto_f
    invoke-interface {p0}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz p1, :cond_36

    invoke-virtual {p1}, La3/e;->i()La3/e$a;

    move-result-object v1

    sget-object v2, La3/e$a;->BITMAP_ONLY:La3/e$a;

    if-ne v1, v2, :cond_36

    instance-of v1, v0, Lcom/facebook/drawee/drawable/k;

    if-eqz v1, :cond_27

    check-cast v0, Lcom/facebook/drawee/drawable/k;

    invoke-static {v0, p1}, La3/f;->b(Lcom/facebook/drawee/drawable/k;La3/e;)V

    goto :goto_50

    :cond_27
    if-eqz v0, :cond_50

    sget-object v1, La3/f;->a:Landroid/graphics/drawable/ColorDrawable;

    invoke-interface {p0, v1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    invoke-static {v0, p1, p2}, La3/f;->a(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-interface {p0, p1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    goto :goto_50

    :cond_36
    instance-of p0, v0, Lcom/facebook/drawee/drawable/k;

    if-eqz p0, :cond_50

    check-cast v0, Lcom/facebook/drawee/drawable/k;

    const/4 p0, 0x0

    invoke-interface {v0, p0}, Lcom/facebook/drawee/drawable/k;->a(Z)V

    invoke-interface {v0}, Lcom/facebook/drawee/drawable/k;->d()V

    const/4 p1, 0x0

    invoke-interface {v0, p1, p0}, Lcom/facebook/drawee/drawable/k;->b(FI)V

    invoke-interface {v0, p1}, Lcom/facebook/drawee/drawable/k;->c(F)V

    invoke-interface {v0}, Lcom/facebook/drawee/drawable/k;->g()V

    invoke-interface {v0, p0}, Lcom/facebook/drawee/drawable/k;->e(Z)V

    :cond_50
    :goto_50
    return-void
.end method

.method static g(La3/d;La3/e;)V
    .registers 6

    invoke-interface {p0}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    sget-object v1, La3/f;->a:Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {p1}, La3/e;->i()La3/e$a;

    move-result-object v2

    sget-object v3, La3/e$a;->OVERLAY_COLOR:La3/e$a;

    if-ne v2, v3, :cond_2b

    instance-of v2, v0, Lcom/facebook/drawee/drawable/n;

    if-eqz v2, :cond_1f

    check-cast v0, Lcom/facebook/drawee/drawable/n;

    invoke-static {v0, p1}, La3/f;->b(Lcom/facebook/drawee/drawable/k;La3/e;)V

    invoke-virtual {p1}, La3/e;->e()I

    move-result p0

    invoke-virtual {v0, p0}, Lcom/facebook/drawee/drawable/n;->i(I)V

    goto :goto_3c

    :cond_1f
    invoke-interface {p0, v1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-static {v0, p1}, La3/f;->d(Landroid/graphics/drawable/Drawable;La3/e;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-interface {p0, p1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    goto :goto_3c

    :cond_2b
    instance-of p1, v0, Lcom/facebook/drawee/drawable/n;

    if-eqz p1, :cond_3c

    check-cast v0, Lcom/facebook/drawee/drawable/n;

    invoke-virtual {v0, v1}, Lcom/facebook/drawee/drawable/h;->setCurrent(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-interface {p0, p1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    const/4 p0, 0x0

    invoke-virtual {v1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_3c
    :goto_3c
    return-void
.end method

.method static h(Lcom/facebook/drawee/drawable/d;Lcom/facebook/drawee/drawable/r$b;)Lcom/facebook/drawee/drawable/q;
    .registers 3

    sget-object v0, La3/f;->a:Landroid/graphics/drawable/ColorDrawable;

    invoke-interface {p0, v0}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-static {v0, p1}, La3/f;->e(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-interface {p0, p1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    const-string p0, "Parent has no child drawable!"

    invoke-static {p1, p0}, LD2/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lcom/facebook/drawee/drawable/q;

    return-object p1
.end method
