.class public final La3/d;
.super Lcom/facebook/drawee/drawable/h;
.source "RootDrawable.java"

# interfaces
.implements Lcom/facebook/drawee/drawable/u;


# instance fields
.field a:Landroid/graphics/drawable/Drawable;

.field private b:Lcom/facebook/drawee/drawable/v;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/facebook/drawee/drawable/h;-><init>(Landroid/graphics/drawable/Drawable;)V

    const/4 p1, 0x0

    iput-object p1, p0, La3/d;->a:Landroid/graphics/drawable/Drawable;

    return-void
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .registers 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongCall"
        }
    .end annotation

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    iget-object v0, p0, La3/d;->b:Lcom/facebook/drawee/drawable/v;

    if-eqz v0, :cond_10

    check-cast v0, Lc3/a;

    invoke-virtual {v0}, Lc3/a;->j()V

    :cond_10
    invoke-super {p0, p1}, Lcom/facebook/drawee/drawable/h;->draw(Landroid/graphics/Canvas;)V

    iget-object v0, p0, La3/d;->a:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_23

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    iget-object v0, p0, La3/d;->a:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_23
    return-void
.end method

.method public final f(Lcom/facebook/drawee/drawable/v;)V
    .registers 2

    iput-object p1, p0, La3/d;->b:Lcom/facebook/drawee/drawable/v;

    return-void
.end method

.method public final getIntrinsicHeight()I
    .registers 2

    const/4 v0, -0x1

    return v0
.end method

.method public final getIntrinsicWidth()I
    .registers 2

    const/4 v0, -0x1

    return v0
.end method

.method public final setVisible(ZZ)Z
    .registers 4

    iget-object v0, p0, La3/d;->b:Lcom/facebook/drawee/drawable/v;

    if-eqz v0, :cond_9

    check-cast v0, Lc3/a;

    invoke-virtual {v0, p1}, Lc3/a;->l(Z)V

    :cond_9
    invoke-super {p0, p1, p2}, Lcom/facebook/drawee/drawable/h;->setVisible(ZZ)Z

    move-result p1

    return p1
.end method
