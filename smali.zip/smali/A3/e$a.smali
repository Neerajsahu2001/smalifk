.class public final enum La3/e$a;
.super Ljava/lang/Enum;
.source "RoundingParams.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La3/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "La3/e$a;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[La3/e$a;

.field public static final enum BITMAP_ONLY:La3/e$a;

.field public static final enum OVERLAY_COLOR:La3/e$a;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance v2, La3/e$a;

    const-string v3, "OVERLAY_COLOR"

    invoke-direct {v2, v3, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, La3/e$a;->OVERLAY_COLOR:La3/e$a;

    new-instance v3, La3/e$a;

    const-string v4, "BITMAP_ONLY"

    invoke-direct {v3, v4, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, La3/e$a;->BITMAP_ONLY:La3/e$a;

    const/4 v4, 0x2

    new-array v4, v4, [La3/e$a;

    aput-object v2, v4, v1

    aput-object v3, v4, v0

    sput-object v4, La3/e$a;->$VALUES:[La3/e$a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)La3/e$a;
    .registers 2

    const-class v0, La3/e$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La3/e$a;

    return-object p0
.end method

.method public static values()[La3/e$a;
    .registers 1

    sget-object v0, La3/e$a;->$VALUES:[La3/e$a;

    invoke-virtual {v0}, [La3/e$a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La3/e$a;

    return-object v0
.end method
