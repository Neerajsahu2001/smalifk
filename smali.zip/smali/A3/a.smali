.class public final La3/a;
.super Ljava/lang/Object;
.source "GenericDraweeHierarchy.java"

# interfaces
.implements Lb3/c;


# instance fields
.field private final a:Landroid/graphics/drawable/ColorDrawable;

.field private final b:Landroid/content/res/Resources;

.field private c:La3/e;

.field private final d:La3/d;

.field private final e:Lcom/facebook/drawee/drawable/g;

.field private final f:Lcom/facebook/drawee/drawable/h;


# direct methods
.method constructor <init>(La3/b;)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    iput-object v0, p0, La3/a;->a:Landroid/graphics/drawable/ColorDrawable;

    invoke-static {}, Lt3/b;->b()V

    invoke-virtual {p1}, La3/b;->n()Landroid/content/res/Resources;

    move-result-object v2

    iput-object v2, p0, La3/a;->b:Landroid/content/res/Resources;

    invoke-virtual {p1}, La3/b;->q()La3/e;

    move-result-object v2

    iput-object v2, p0, La3/a;->c:La3/e;

    new-instance v2, Lcom/facebook/drawee/drawable/h;

    invoke-direct {v2, v0}, Lcom/facebook/drawee/drawable/h;-><init>(Landroid/graphics/drawable/Drawable;)V

    iput-object v2, p0, La3/a;->f:Lcom/facebook/drawee/drawable/h;

    invoke-virtual {p1}, La3/b;->h()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x1

    if-eqz v0, :cond_31

    invoke-virtual {p1}, La3/b;->h()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_32

    :cond_31
    const/4 v0, 0x1

    :goto_32
    if-nez v0, :cond_35

    const/4 v0, 0x1

    :cond_35
    invoke-virtual {p1}, La3/b;->k()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_3d

    const/4 v4, 0x1

    goto :goto_3e

    :cond_3d
    const/4 v4, 0x0

    :goto_3e
    add-int/2addr v0, v4

    add-int/lit8 v4, v0, 0x6

    new-array v4, v4, [Landroid/graphics/drawable/Drawable;

    invoke-virtual {p1}, La3/b;->c()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    const/4 v6, 0x0

    invoke-direct {p0, v5, v6}, La3/a;->f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-virtual {p1}, La3/b;->i()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    invoke-virtual {p1}, La3/b;->j()Lcom/facebook/drawee/drawable/r$b;

    move-result-object v7

    invoke-direct {p0, v5, v7}, La3/a;->f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    aput-object v5, v4, v3

    invoke-virtual {p1}, La3/b;->b()Lcom/facebook/drawee/drawable/r$b;

    move-result-object v5

    invoke-virtual {v2, v6}, Lcom/facebook/drawee/drawable/h;->setColorFilter(Landroid/graphics/ColorFilter;)V

    invoke-static {v2, v5}, La3/f;->e(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x2

    aput-object v2, v4, v5

    invoke-virtual {p1}, La3/b;->l()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {p1}, La3/b;->m()Lcom/facebook/drawee/drawable/r$b;

    move-result-object v5

    invoke-direct {p0, v2, v5}, La3/a;->f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x3

    aput-object v2, v4, v5

    invoke-virtual {p1}, La3/b;->o()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {p1}, La3/b;->p()Lcom/facebook/drawee/drawable/r$b;

    move-result-object v5

    invoke-direct {p0, v2, v5}, La3/a;->f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x4

    aput-object v2, v4, v5

    invoke-virtual {p1}, La3/b;->f()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {p1}, La3/b;->g()Lcom/facebook/drawee/drawable/r$b;

    move-result-object v5

    invoke-direct {p0, v2, v5}, La3/a;->f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x5

    aput-object v2, v4, v5

    if-lez v0, :cond_d2

    invoke-virtual {p1}, La3/b;->h()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_bf

    invoke-virtual {p1}, La3/b;->h()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_c0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable;

    add-int/lit8 v5, v1, 0x1

    add-int/lit8 v1, v1, 0x6

    invoke-direct {p0, v2, v6}, La3/a;->f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    aput-object v2, v4, v1

    move v1, v5

    goto :goto_a7

    :cond_bf
    const/4 v1, 0x1

    :cond_c0
    invoke-virtual {p1}, La3/b;->k()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_d2

    add-int/lit8 v1, v1, 0x6

    invoke-virtual {p1}, La3/b;->k()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-direct {p0, v0, v6}, La3/a;->f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    aput-object v0, v4, v1

    :cond_d2
    new-instance v0, Lcom/facebook/drawee/drawable/g;

    invoke-direct {v0, v4}, Lcom/facebook/drawee/drawable/g;-><init>([Landroid/graphics/drawable/Drawable;)V

    iput-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {p1}, La3/b;->e()I

    move-result p1

    invoke-virtual {v0, p1}, Lcom/facebook/drawee/drawable/g;->k(I)V

    iget-object p1, p0, La3/a;->c:La3/e;

    invoke-static {v0, p1}, La3/f;->d(Landroid/graphics/drawable/Drawable;La3/e;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    new-instance v1, La3/d;

    invoke-direct {v1, p1}, La3/d;-><init>(Landroid/graphics/drawable/Drawable;)V

    iput-object v1, p0, La3/a;->d:La3/d;

    invoke-virtual {v1}, Lcom/facebook/drawee/drawable/h;->mutate()Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->e()V

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->g()V

    invoke-direct {p0}, La3/a;->h()V

    invoke-direct {p0, v3}, La3/a;->g(I)V

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->j()V

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->f()V

    invoke-static {}, Lt3/b;->b()V

    return-void
.end method

.method private f(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;
    .registers 5

    iget-object v0, p0, La3/a;->c:La3/e;

    iget-object v1, p0, La3/a;->b:Landroid/content/res/Resources;

    invoke-static {p1, v0, v1}, La3/f;->c(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-static {p1, p2}, La3/f;->e(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    return-object p1
.end method

.method private g(I)V
    .registers 3

    if-ltz p1, :cond_7

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {v0, p1}, Lcom/facebook/drawee/drawable/g;->h(I)V

    :cond_7
    return-void
.end method

.method private h()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, La3/a;->i(I)V

    const/4 v0, 0x2

    invoke-direct {p0, v0}, La3/a;->i(I)V

    const/4 v0, 0x3

    invoke-direct {p0, v0}, La3/a;->i(I)V

    const/4 v0, 0x4

    invoke-direct {p0, v0}, La3/a;->i(I)V

    const/4 v0, 0x5

    invoke-direct {p0, v0}, La3/a;->i(I)V

    return-void
.end method

.method private i(I)V
    .registers 3

    if-ltz p1, :cond_7

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {v0, p1}, Lcom/facebook/drawee/drawable/g;->i(I)V

    :cond_7
    return-void
.end method

.method private l(I)Lcom/facebook/drawee/drawable/d;
    .registers 3

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {v0, p1}, Lcom/facebook/drawee/drawable/b;->b(I)Lcom/facebook/drawee/drawable/d;

    move-result-object p1

    invoke-interface {p1}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v0, v0, Lcom/facebook/drawee/drawable/i;

    if-eqz v0, :cond_14

    invoke-interface {p1}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    check-cast p1, Lcom/facebook/drawee/drawable/i;

    :cond_14
    invoke-interface {p1}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v0, v0, Lcom/facebook/drawee/drawable/q;

    if-eqz v0, :cond_22

    invoke-interface {p1}, Lcom/facebook/drawee/drawable/d;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    check-cast p1, Lcom/facebook/drawee/drawable/q;

    :cond_22
    return-object p1
.end method

.method private n(I)Lcom/facebook/drawee/drawable/q;
    .registers 3

    invoke-direct {p0, p1}, La3/a;->l(I)Lcom/facebook/drawee/drawable/d;

    move-result-object p1

    instance-of v0, p1, Lcom/facebook/drawee/drawable/q;

    if-eqz v0, :cond_b

    check-cast p1, Lcom/facebook/drawee/drawable/q;

    return-object p1

    :cond_b
    sget-object v0, Lcom/facebook/drawee/drawable/r$b;->a:Lcom/facebook/drawee/drawable/r$b;

    invoke-static {p1, v0}, La3/f;->h(Lcom/facebook/drawee/drawable/d;Lcom/facebook/drawee/drawable/r$b;)Lcom/facebook/drawee/drawable/q;

    move-result-object p1

    return-object p1
.end method

.method private q(Landroid/graphics/drawable/Drawable;I)V
    .registers 5

    if-nez p1, :cond_9

    iget-object p1, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p2}, Lcom/facebook/drawee/drawable/b;->d(Landroid/graphics/drawable/Drawable;I)Landroid/graphics/drawable/Drawable;

    return-void

    :cond_9
    iget-object v0, p0, La3/a;->c:La3/e;

    iget-object v1, p0, La3/a;->b:Landroid/content/res/Resources;

    invoke-static {p1, v0, v1}, La3/f;->c(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-direct {p0, p2}, La3/a;->l(I)Lcom/facebook/drawee/drawable/d;

    move-result-object p2

    invoke-interface {p2, p1}, Lcom/facebook/drawee/drawable/d;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method private t(F)V
    .registers 5

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Lcom/facebook/drawee/drawable/b;->a(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_a

    return-void

    :cond_a
    const v2, 0x3f7fbe77    # 0.999f

    cmpl-float v2, p1, v2

    if-ltz v2, :cond_1f

    instance-of v2, v0, Landroid/graphics/drawable/Animatable;

    if-eqz v2, :cond_1b

    move-object v2, v0

    check-cast v2, Landroid/graphics/drawable/Animatable;

    invoke-interface {v2}, Landroid/graphics/drawable/Animatable;->stop()V

    :cond_1b
    invoke-direct {p0, v1}, La3/a;->i(I)V

    goto :goto_2c

    :cond_1f
    instance-of v2, v0, Landroid/graphics/drawable/Animatable;

    if-eqz v2, :cond_29

    move-object v2, v0

    check-cast v2, Landroid/graphics/drawable/Animatable;

    invoke-interface {v2}, Landroid/graphics/drawable/Animatable;->start()V

    :cond_29
    invoke-direct {p0, v1}, La3/a;->g(I)V

    :goto_2c
    const v1, 0x461c4000    # 10000.0f

    mul-float p1, p1, v1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    return-void
.end method


# virtual methods
.method public final a(FZ)V
    .registers 5

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Lcom/facebook/drawee/drawable/b;->a(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-nez v1, :cond_a

    return-void

    :cond_a
    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->e()V

    invoke-direct {p0, p1}, La3/a;->t(F)V

    if-eqz p2, :cond_15

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->j()V

    :cond_15
    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->f()V

    return-void
.end method

.method public final b()La3/d;
    .registers 2

    iget-object v0, p0, La3/a;->d:La3/d;

    return-object v0
.end method

.method public final c(Landroid/graphics/drawable/Drawable;FZ)V
    .registers 6

    iget-object v0, p0, La3/a;->c:La3/e;

    iget-object v1, p0, La3/a;->b:Landroid/content/res/Resources;

    invoke-static {p1, v0, v1}, La3/f;->c(Landroid/graphics/drawable/Drawable;La3/e;Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, La3/a;->f:Lcom/facebook/drawee/drawable/h;

    invoke-virtual {v0, p1}, Lcom/facebook/drawee/drawable/h;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    iget-object p1, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {p1}, Lcom/facebook/drawee/drawable/g;->e()V

    invoke-direct {p0}, La3/a;->h()V

    const/4 v0, 0x2

    invoke-direct {p0, v0}, La3/a;->g(I)V

    invoke-direct {p0, p2}, La3/a;->t(F)V

    if-eqz p3, :cond_24

    invoke-virtual {p1}, Lcom/facebook/drawee/drawable/g;->j()V

    :cond_24
    invoke-virtual {p1}, Lcom/facebook/drawee/drawable/g;->f()V

    return-void
.end method

.method public final d()V
    .registers 4

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->e()V

    invoke-direct {p0}, La3/a;->h()V

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Lcom/facebook/drawee/drawable/b;->a(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-eqz v2, :cond_13

    invoke-direct {p0, v1}, La3/a;->g(I)V

    goto :goto_17

    :cond_13
    const/4 v1, 0x1

    invoke-direct {p0, v1}, La3/a;->g(I)V

    :goto_17
    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->f()V

    return-void
.end method

.method public final e(Landroid/graphics/drawable/Drawable;)V
    .registers 3

    iget-object v0, p0, La3/a;->d:La3/d;

    iput-object p1, v0, La3/d;->a:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method

.method public final getBounds()Landroid/graphics/Rect;
    .registers 2

    iget-object v0, p0, La3/a;->d:La3/d;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public final j()V
    .registers 3

    const/4 v0, 0x2

    invoke-direct {p0, v0}, La3/a;->l(I)Lcom/facebook/drawee/drawable/d;

    move-result-object v1

    instance-of v1, v1, Lcom/facebook/drawee/drawable/q;

    if-nez v1, :cond_a

    return-void

    :cond_a
    invoke-direct {p0, v0}, La3/a;->n(I)Lcom/facebook/drawee/drawable/q;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final k()Lcom/facebook/drawee/drawable/r$b;
    .registers 3

    const/4 v0, 0x2

    invoke-direct {p0, v0}, La3/a;->l(I)Lcom/facebook/drawee/drawable/d;

    move-result-object v1

    instance-of v1, v1, Lcom/facebook/drawee/drawable/q;

    if-nez v1, :cond_b

    const/4 v0, 0x0

    return-object v0

    :cond_b
    invoke-direct {p0, v0}, La3/a;->n(I)Lcom/facebook/drawee/drawable/q;

    move-result-object v0

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/q;->k()Lcom/facebook/drawee/drawable/r$b;

    move-result-object v0

    return-object v0
.end method

.method public final m()La3/e;
    .registers 2

    iget-object v0, p0, La3/a;->c:La3/e;

    return-object v0
.end method

.method public final o(Lcom/facebook/drawee/drawable/r$b;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x2

    invoke-direct {p0, v0}, La3/a;->n(I)Lcom/facebook/drawee/drawable/q;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/facebook/drawee/drawable/q;->l(Lcom/facebook/drawee/drawable/r$b;)V

    return-void
.end method

.method public final p(Lcom/facebook/drawee/drawable/m;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, La3/a;->q(Landroid/graphics/drawable/Drawable;I)V

    return-void
.end method

.method public final r(I)V
    .registers 3

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {v0, p1}, Lcom/facebook/drawee/drawable/g;->k(I)V

    return-void
.end method

.method public final reset()V
    .registers 3

    iget-object v0, p0, La3/a;->f:Lcom/facebook/drawee/drawable/h;

    iget-object v1, p0, La3/a;->a:Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v0, v1}, Lcom/facebook/drawee/drawable/h;->setDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    if-eqz v0, :cond_1e

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->e()V

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->g()V

    invoke-direct {p0}, La3/a;->h()V

    const/4 v1, 0x1

    invoke-direct {p0, v1}, La3/a;->g(I)V

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->j()V

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/g;->f()V

    :cond_1e
    return-void
.end method

.method public final s(Landroid/graphics/drawable/Drawable;Lcom/facebook/drawee/drawable/r$b;)V
    .registers 4

    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, La3/a;->q(Landroid/graphics/drawable/Drawable;I)V

    invoke-direct {p0, v0}, La3/a;->n(I)Lcom/facebook/drawee/drawable/q;

    move-result-object p1

    invoke-virtual {p1, p2}, Lcom/facebook/drawee/drawable/q;->l(Lcom/facebook/drawee/drawable/r$b;)V

    return-void
.end method

.method public final u(Landroid/graphics/drawable/Drawable;)V
    .registers 3

    const/4 v0, 0x3

    invoke-direct {p0, p1, v0}, La3/a;->q(Landroid/graphics/drawable/Drawable;I)V

    return-void
.end method

.method public final v(La3/e;)V
    .registers 5

    iput-object p1, p0, La3/a;->c:La3/e;

    iget-object v0, p0, La3/a;->d:La3/d;

    invoke-static {v0, p1}, La3/f;->g(La3/d;La3/e;)V

    const/4 p1, 0x0

    :goto_8
    iget-object v0, p0, La3/a;->e:Lcom/facebook/drawee/drawable/g;

    invoke-virtual {v0}, Lcom/facebook/drawee/drawable/b;->c()I

    move-result v0

    if-ge p1, v0, :cond_1e

    invoke-direct {p0, p1}, La3/a;->l(I)Lcom/facebook/drawee/drawable/d;

    move-result-object v0

    iget-object v1, p0, La3/a;->c:La3/e;

    iget-object v2, p0, La3/a;->b:Landroid/content/res/Resources;

    invoke-static {v0, v1, v2}, La3/f;->f(Lcom/facebook/drawee/drawable/d;La3/e;Landroid/content/res/Resources;)V

    add-int/lit8 p1, p1, 0x1

    goto :goto_8

    :cond_1e
    return-void
.end method
