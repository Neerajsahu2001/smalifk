.class public final La3/b;
.super Ljava/lang/Object;
.source "GenericDraweeHierarchyBuilder.java"


# static fields
.field public static final q:Lcom/facebook/drawee/drawable/r$b;

.field public static final r:Lcom/facebook/drawee/drawable/r$b;


# instance fields
.field private a:Landroid/content/res/Resources;

.field private b:I

.field private c:F

.field private d:Landroid/graphics/drawable/Drawable;

.field private e:Lcom/facebook/drawee/drawable/r$b;

.field private f:Landroid/graphics/drawable/Drawable;

.field private g:Lcom/facebook/drawee/drawable/r$b;

.field private h:Landroid/graphics/drawable/Drawable;

.field private i:Lcom/facebook/drawee/drawable/r$b;

.field private j:Landroid/graphics/drawable/Drawable;

.field private k:Lcom/facebook/drawee/drawable/r$b;

.field private l:Lcom/facebook/drawee/drawable/r$b;

.field private m:Landroid/graphics/drawable/Drawable;

.field private n:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field private o:Landroid/graphics/drawable/StateListDrawable;

.field private p:La3/e;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Lcom/facebook/drawee/drawable/r$b;->f:Lcom/facebook/drawee/drawable/r$b;

    sput-object v0, La3/b;->q:Lcom/facebook/drawee/drawable/r$b;

    sget-object v0, Lcom/facebook/drawee/drawable/r$b;->g:Lcom/facebook/drawee/drawable/r$b;

    sput-object v0, La3/b;->r:Lcom/facebook/drawee/drawable/r$b;

    return-void
.end method

.method public constructor <init>(Landroid/content/res/Resources;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La3/b;->a:Landroid/content/res/Resources;

    const/16 p1, 0x12c

    iput p1, p0, La3/b;->b:I

    const/4 p1, 0x0

    iput p1, p0, La3/b;->c:F

    const/4 p1, 0x0

    iput-object p1, p0, La3/b;->d:Landroid/graphics/drawable/Drawable;

    sget-object v0, La3/b;->q:Lcom/facebook/drawee/drawable/r$b;

    iput-object v0, p0, La3/b;->e:Lcom/facebook/drawee/drawable/r$b;

    iput-object p1, p0, La3/b;->f:Landroid/graphics/drawable/Drawable;

    iput-object v0, p0, La3/b;->g:Lcom/facebook/drawee/drawable/r$b;

    iput-object p1, p0, La3/b;->h:Landroid/graphics/drawable/Drawable;

    iput-object v0, p0, La3/b;->i:Lcom/facebook/drawee/drawable/r$b;

    iput-object p1, p0, La3/b;->j:Landroid/graphics/drawable/Drawable;

    iput-object v0, p0, La3/b;->k:Lcom/facebook/drawee/drawable/r$b;

    sget-object v0, La3/b;->r:Lcom/facebook/drawee/drawable/r$b;

    iput-object v0, p0, La3/b;->l:Lcom/facebook/drawee/drawable/r$b;

    iput-object p1, p0, La3/b;->m:Landroid/graphics/drawable/Drawable;

    iput-object p1, p0, La3/b;->n:Ljava/util/List;

    iput-object p1, p0, La3/b;->o:Landroid/graphics/drawable/StateListDrawable;

    iput-object p1, p0, La3/b;->p:La3/e;

    return-void
.end method


# virtual methods
.method public final A(Landroid/graphics/drawable/Drawable;)V
    .registers 4

    if-nez p1, :cond_6

    const/4 p1, 0x0

    iput-object p1, p0, La3/b;->o:Landroid/graphics/drawable/StateListDrawable;

    goto :goto_17

    :cond_6
    new-instance v0, Landroid/graphics/drawable/StateListDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    const v1, 0x10100a7

    filled-new-array {v1}, [I

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    iput-object v0, p0, La3/b;->o:Landroid/graphics/drawable/StateListDrawable;

    :goto_17
    return-void
.end method

.method public final B(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    iput-object p1, p0, La3/b;->j:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public final C(Lcom/facebook/drawee/drawable/r$a;)V
    .registers 2

    iput-object p1, p0, La3/b;->k:Lcom/facebook/drawee/drawable/r$b;

    return-void
.end method

.method public final D(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    iput-object p1, p0, La3/b;->f:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public final E(Lcom/facebook/drawee/drawable/r$a;)V
    .registers 2

    iput-object p1, p0, La3/b;->g:Lcom/facebook/drawee/drawable/r$b;

    return-void
.end method

.method public final F(La3/e;)V
    .registers 2

    iput-object p1, p0, La3/b;->p:La3/e;

    return-void
.end method

.method public final a()La3/a;
    .registers 3

    iget-object v0, p0, La3/b;->n:Ljava/util/List;

    if-eqz v0, :cond_18

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_8

    :cond_18
    new-instance v0, La3/a;

    invoke-direct {v0, p0}, La3/a;-><init>(La3/b;)V

    return-object v0
.end method

.method public final b()Lcom/facebook/drawee/drawable/r$b;
    .registers 2

    iget-object v0, p0, La3/b;->l:Lcom/facebook/drawee/drawable/r$b;

    return-object v0
.end method

.method public final c()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, La3/b;->m:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final d()F
    .registers 2

    iget v0, p0, La3/b;->c:F

    return v0
.end method

.method public final e()I
    .registers 2

    iget v0, p0, La3/b;->b:I

    return v0
.end method

.method public final f()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, La3/b;->h:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final g()Lcom/facebook/drawee/drawable/r$b;
    .registers 2

    iget-object v0, p0, La3/b;->i:Lcom/facebook/drawee/drawable/r$b;

    return-object v0
.end method

.method public final h()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La3/b;->n:Ljava/util/List;

    return-object v0
.end method

.method public final i()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, La3/b;->d:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final j()Lcom/facebook/drawee/drawable/r$b;
    .registers 2

    iget-object v0, p0, La3/b;->e:Lcom/facebook/drawee/drawable/r$b;

    return-object v0
.end method

.method public final k()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, La3/b;->o:Landroid/graphics/drawable/StateListDrawable;

    return-object v0
.end method

.method public final l()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, La3/b;->j:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final m()Lcom/facebook/drawee/drawable/r$b;
    .registers 2

    iget-object v0, p0, La3/b;->k:Lcom/facebook/drawee/drawable/r$b;

    return-object v0
.end method

.method public final n()Landroid/content/res/Resources;
    .registers 2

    iget-object v0, p0, La3/b;->a:Landroid/content/res/Resources;

    return-object v0
.end method

.method public final o()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, La3/b;->f:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final p()Lcom/facebook/drawee/drawable/r$b;
    .registers 2

    iget-object v0, p0, La3/b;->g:Lcom/facebook/drawee/drawable/r$b;

    return-object v0
.end method

.method public final q()La3/e;
    .registers 2

    iget-object v0, p0, La3/b;->p:La3/e;

    return-object v0
.end method

.method public final r(Lcom/facebook/drawee/drawable/r$a;)V
    .registers 2

    iput-object p1, p0, La3/b;->l:Lcom/facebook/drawee/drawable/r$b;

    return-void
.end method

.method public final s(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    iput-object p1, p0, La3/b;->m:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public final t(F)V
    .registers 2

    iput p1, p0, La3/b;->c:F

    return-void
.end method

.method public final u(I)V
    .registers 2

    iput p1, p0, La3/b;->b:I

    return-void
.end method

.method public final v(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    iput-object p1, p0, La3/b;->h:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public final w(Lcom/facebook/drawee/drawable/r$a;)V
    .registers 2

    iput-object p1, p0, La3/b;->i:Lcom/facebook/drawee/drawable/r$b;

    return-void
.end method

.method public final x(Landroid/graphics/drawable/Drawable;)V
    .registers 4

    if-nez p1, :cond_6

    const/4 p1, 0x0

    iput-object p1, p0, La3/b;->n:Ljava/util/List;

    goto :goto_12

    :cond_6
    const/4 v0, 0x1

    new-array v0, v0, [Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, La3/b;->n:Ljava/util/List;

    :goto_12
    return-void
.end method

.method public final y(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    iput-object p1, p0, La3/b;->d:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public final z(Lcom/facebook/drawee/drawable/r$a;)V
    .registers 2

    iput-object p1, p0, La3/b;->e:Lcom/facebook/drawee/drawable/r$b;

    return-void
.end method
