.class public interface abstract Lc/b;
.super Ljava/lang/Object;
.source "OnContextAvailableListener.java"


# virtual methods
.method public abstract a()V
.end method
