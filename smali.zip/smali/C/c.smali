.class public final LC/c;
.super Ljava/lang/Object;


# static fields
.field public static final Base_CardView:I = 0x7f140015

.field public static final CardView:I = 0x7f1400dd

.field public static final CardView_Dark:I = 0x7f1400de

.field public static final CardView_Light:I = 0x7f1400df
