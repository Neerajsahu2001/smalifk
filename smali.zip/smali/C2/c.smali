.class public interface abstract Lc2/c;
.super Ljava/lang/Object;
.source "Headers.java"


# static fields
.field public static final a:Lc2/e;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lc2/e$a;

    invoke-direct {v0}, Lc2/e$a;-><init>()V

    invoke-virtual {v0}, Lc2/e$a;->a()Lc2/e;

    move-result-object v0

    sput-object v0, Lc2/c;->a:Lc2/e;

    return-void
.end method


# virtual methods
.method public abstract getHeaders()Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method
