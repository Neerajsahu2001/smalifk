.class final Lc2/g;
.super Lq2/g;
.source "ModelCache.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lq2/g<",
        "Lc2/h$a<",
        "Ljava/lang/Object;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# virtual methods
.method protected final e(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Lc2/h$a;

    invoke-virtual {p1}, Lc2/h$a;->b()V

    return-void
.end method
