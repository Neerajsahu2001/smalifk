.class public interface abstract Lc2/i;
.super Ljava/lang/Object;
.source "ModelLoaderFactory.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "Y:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract build(Lcom/bumptech/glide/load/model/i;)Lcom/bumptech/glide/load/model/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/bumptech/glide/load/model/i;",
            ")",
            "Lcom/bumptech/glide/load/model/f<",
            "TT;TY;>;"
        }
    .end annotation
.end method
