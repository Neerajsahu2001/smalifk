.class public final Lc2/a;
.super Ljava/lang/Object;
.source "ByteBufferEncoder.java"

# interfaces
.implements LW1/d;


# direct methods
.method public static c(C)Z
    .registers 2

    const/16 v0, 0x61

    if-lt p0, v0, :cond_8

    const/16 v0, 0x7a

    if-le p0, v0, :cond_10

    :cond_8
    const/16 v0, 0x41

    if-lt p0, v0, :cond_12

    const/16 v0, 0x5a

    if-gt p0, v0, :cond_12

    :cond_10
    const/4 p0, 0x1

    goto :goto_13

    :cond_12
    const/4 p0, 0x0

    :goto_13
    return p0
.end method

.method public static d(IILjava/lang/CharSequence;II)Z
    .registers 8

    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x0

    if-lt p1, v0, :cond_8

    return v1

    :cond_8
    sub-int v0, p1, p0

    const/4 v2, 0x1

    add-int/2addr v0, v2

    if-lt v0, p3, :cond_22

    if-le v0, p4, :cond_11

    goto :goto_22

    :cond_11
    :goto_11
    if-gt p0, p1, :cond_21

    invoke-interface {p2, p0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p3

    invoke-static {p3}, Lc2/a;->c(C)Z

    move-result p3

    if-nez p3, :cond_1e

    return v1

    :cond_1e
    add-int/lit8 p0, p0, 0x1

    goto :goto_11

    :cond_21
    return v2

    :cond_22
    :goto_22
    return v1
.end method

.method public static e(IILjava/lang/CharSequence;II)Z
    .registers 8

    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x0

    if-lt p1, v0, :cond_8

    return v1

    :cond_8
    sub-int v0, p1, p0

    const/4 v2, 0x1

    add-int/2addr v0, v2

    if-lt v0, p3, :cond_2b

    if-le v0, p4, :cond_11

    goto :goto_2b

    :cond_11
    :goto_11
    if-gt p0, p1, :cond_2a

    invoke-interface {p2, p0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p3

    invoke-static {p3}, Lc2/a;->c(C)Z

    move-result p4

    if-nez p4, :cond_27

    const/16 p4, 0x30

    if-lt p3, p4, :cond_26

    const/16 p4, 0x39

    if-gt p3, p4, :cond_26

    goto :goto_27

    :cond_26
    return v1

    :cond_27
    :goto_27
    add-int/lit8 p0, p0, 0x1

    goto :goto_11

    :cond_2a
    return v2

    :cond_2b
    :goto_2b
    return v1
.end method


# virtual methods
.method public a(Ljava/lang/Object;Ljava/io/File;LW1/i;)Z
    .registers 4

    check-cast p1, Ljava/nio/ByteBuffer;

    :try_start_2
    invoke-static {p1, p2}, Lq2/a;->c(Ljava/nio/ByteBuffer;Ljava/io/File;)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_5} :catch_7

    const/4 p1, 0x1

    goto :goto_17

    :catch_7
    move-exception p1

    const/4 p2, 0x3

    const-string p3, "ByteBufferEncoder"

    invoke-static {p3, p2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p2

    if-eqz p2, :cond_16

    const-string p2, "Failed to write data"

    invoke-static {p3, p2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_16
    const/4 p1, 0x0

    :goto_17
    return p1
.end method
