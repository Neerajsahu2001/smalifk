.class public interface abstract Lc2/f;
.super Ljava/lang/Object;
.source "Model.java"


# virtual methods
.method public abstract a()Z
.end method
