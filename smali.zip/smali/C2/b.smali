.class public Lc2/b;
.super Ljava/lang/Object;
.source "GlideUrl.java"

# interfaces
.implements LW1/f;


# static fields
.field private static final ALLOWED_URI_CHARS:Ljava/lang/String; = "@#&=*+-_.,:!?()/~\'%;$"


# instance fields
.field private volatile cacheKeyBytes:[B

.field private hashCode:I

.field private final headers:Lc2/c;

.field private safeStringUrl:Ljava/lang/String;

.field private safeUrl:Ljava/net/URL;

.field private final stringUrl:Ljava/lang/String;

.field private final url:Ljava/net/URL;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    sget-object v0, Lc2/c;->a:Lc2/e;

    invoke-direct {p0, p1, v0}, Lc2/b;-><init>(Ljava/lang/String;Lc2/c;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lc2/c;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lc2/b;->url:Ljava/net/URL;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_16

    iput-object p1, p0, Lc2/b;->stringUrl:Ljava/lang/String;

    const-string p1, "Argument must not be null"

    invoke-static {p2, p1}, LHj/a;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p2, p0, Lc2/b;->headers:Lc2/c;

    return-void

    :cond_16
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Must not be null or empty"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Ljava/net/URL;)V
    .registers 3

    sget-object v0, Lc2/c;->a:Lc2/e;

    invoke-direct {p0, p1, v0}, Lc2/b;-><init>(Ljava/net/URL;Lc2/c;)V

    return-void
.end method

.method public constructor <init>(Ljava/net/URL;Lc2/c;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "Argument must not be null"

    invoke-static {p1, v0}, LHj/a;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lc2/b;->url:Ljava/net/URL;

    const/4 p1, 0x0

    iput-object p1, p0, Lc2/b;->stringUrl:Ljava/lang/String;

    invoke-static {p2, v0}, LHj/a;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p2, p0, Lc2/b;->headers:Lc2/c;

    return-void
.end method

.method private getCacheKeyBytes()[B
    .registers 3

    iget-object v0, p0, Lc2/b;->cacheKeyBytes:[B

    if-nez v0, :cond_10

    invoke-virtual {p0}, Lc2/b;->getCacheKey()Ljava/lang/String;

    move-result-object v0

    sget-object v1, LW1/f;->a0:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    iput-object v0, p0, Lc2/b;->cacheKeyBytes:[B

    :cond_10
    iget-object v0, p0, Lc2/b;->cacheKeyBytes:[B

    return-object v0
.end method

.method private getSafeStringUrl()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lc2/b;->safeStringUrl:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_23

    iget-object v0, p0, Lc2/b;->stringUrl:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1b

    iget-object v0, p0, Lc2/b;->url:Ljava/net/URL;

    const-string v1, "Argument must not be null"

    invoke-static {v0, v1}, LHj/a;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1b
    const-string v1, "@#&=*+-_.,:!?()/~\'%;$"

    invoke-static {v0, v1}, Landroid/net/Uri;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lc2/b;->safeStringUrl:Ljava/lang/String;

    :cond_23
    iget-object v0, p0, Lc2/b;->safeStringUrl:Ljava/lang/String;

    return-object v0
.end method

.method private getSafeUrl()Ljava/net/URL;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/net/MalformedURLException;
        }
    .end annotation

    iget-object v0, p0, Lc2/b;->safeUrl:Ljava/net/URL;

    if-nez v0, :cond_f

    new-instance v0, Ljava/net/URL;

    invoke-direct {p0}, Lc2/b;->getSafeStringUrl()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lc2/b;->safeUrl:Ljava/net/URL;

    :cond_f
    iget-object v0, p0, Lc2/b;->safeUrl:Ljava/net/URL;

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 5

    instance-of v0, p1, Lc2/b;

    const/4 v1, 0x0

    if-eqz v0, :cond_20

    check-cast p1, Lc2/b;

    invoke-virtual {p0}, Lc2/b;->getCacheKey()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lc2/b;->getCacheKey()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    iget-object v0, p0, Lc2/b;->headers:Lc2/c;

    iget-object p1, p1, Lc2/b;->headers:Lc2/c;

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_20

    const/4 v1, 0x1

    :cond_20
    return v1
.end method

.method public getCacheKey()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lc2/b;->stringUrl:Ljava/lang/String;

    if-eqz v0, :cond_5

    goto :goto_10

    :cond_5
    iget-object v0, p0, Lc2/b;->url:Ljava/net/URL;

    const-string v1, "Argument must not be null"

    invoke-static {v0, v1}, LHj/a;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_10
    return-object v0
.end method

.method public getHeaders()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lc2/b;->headers:Lc2/c;

    invoke-interface {v0}, Lc2/c;->getHeaders()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public hashCode()I
    .registers 3

    iget v0, p0, Lc2/b;->hashCode:I

    if-nez v0, :cond_19

    invoke-virtual {p0}, Lc2/b;->getCacheKey()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    iput v0, p0, Lc2/b;->hashCode:I

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lc2/b;->headers:Lc2/c;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    iput v1, p0, Lc2/b;->hashCode:I

    :cond_19
    iget v0, p0, Lc2/b;->hashCode:I

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    invoke-virtual {p0}, Lc2/b;->getCacheKey()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public toStringUrl()Ljava/lang/String;
    .registers 2

    invoke-direct {p0}, Lc2/b;->getSafeStringUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public toURL()Ljava/net/URL;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/net/MalformedURLException;
        }
    .end annotation

    invoke-direct {p0}, Lc2/b;->getSafeUrl()Ljava/net/URL;

    move-result-object v0

    return-object v0
.end method

.method public updateDiskCacheKey(Ljava/security/MessageDigest;)V
    .registers 3

    invoke-direct {p0}, Lc2/b;->getCacheKeyBytes()[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/security/MessageDigest;->update([B)V

    return-void
.end method
