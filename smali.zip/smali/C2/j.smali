.class public final Lc2/j;
.super Ljava/lang/Object;
.source "StreamEncoder.java"

# interfaces
.implements LW1/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LW1/d<",
        "Ljava/io/InputStream;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:LZ1/b;


# direct methods
.method public constructor <init>(LZ1/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc2/j;->a:LZ1/b;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/io/File;LW1/i;)Z
    .registers 9

    check-cast p1, Ljava/io/InputStream;

    const-string p3, "StreamEncoder"

    const/high16 v0, 0x10000

    const-class v1, [B

    iget-object v2, p0, Lc2/j;->a:LZ1/b;

    invoke-interface {v2, v0, v1}, LZ1/b;->c(ILjava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    const/4 v1, 0x0

    const/4 v3, 0x0

    :try_start_12
    new-instance v4, Ljava/io/FileOutputStream;

    invoke-direct {v4, p2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_17
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_17} :catch_35
    .catchall {:try_start_12 .. :try_end_17} :catchall_33

    :goto_17
    :try_start_17
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    move-result p2

    const/4 v3, -0x1

    if-eq p2, v3, :cond_28

    invoke-virtual {v4, v0, v1, p2}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_17

    :catchall_22
    move-exception p1

    move-object v3, v4

    goto :goto_4b

    :catch_25
    move-exception p1

    move-object v3, v4

    goto :goto_36

    :cond_28
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_2b
    .catch Ljava/io/IOException; {:try_start_17 .. :try_end_2b} :catch_25
    .catchall {:try_start_17 .. :try_end_2b} :catchall_22

    :try_start_2b
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_2e
    .catch Ljava/io/IOException; {:try_start_2b .. :try_end_2e} :catch_2e

    :catch_2e
    invoke-interface {v2, v0}, LZ1/b;->put(Ljava/lang/Object;)V

    const/4 v1, 0x1

    goto :goto_4a

    :catchall_33
    move-exception p1

    goto :goto_4b

    :catch_35
    move-exception p1

    :goto_36
    const/4 p2, 0x3

    :try_start_37
    invoke-static {p3, p2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p2

    if-eqz p2, :cond_42

    const-string p2, "Failed to encode data onto the OutputStream"

    invoke-static {p3, p2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_42
    .catchall {:try_start_37 .. :try_end_42} :catchall_33

    :cond_42
    if-eqz v3, :cond_47

    :try_start_44
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V
    :try_end_47
    .catch Ljava/io/IOException; {:try_start_44 .. :try_end_47} :catch_47

    :catch_47
    :cond_47
    invoke-interface {v2, v0}, LZ1/b;->put(Ljava/lang/Object;)V

    :goto_4a
    return v1

    :goto_4b
    if-eqz v3, :cond_50

    :try_start_4d
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V
    :try_end_50
    .catch Ljava/io/IOException; {:try_start_4d .. :try_end_50} :catch_50

    :catch_50
    :cond_50
    invoke-interface {v2, v0}, LZ1/b;->put(Ljava/lang/Object;)V

    throw p1
.end method
