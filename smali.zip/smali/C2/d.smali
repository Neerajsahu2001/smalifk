.class public interface abstract Lc2/d;
.super Ljava/lang/Object;
.source "LazyHeaderFactory.java"


# virtual methods
.method public abstract a()Ljava/lang/String;
.end method
