.class final Lc2/h$a;
.super Ljava/lang/Object;
.source "ModelCache.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc2/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static final d:Ljava/util/ArrayDeque;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TA;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget v0, Lq2/j;->c:I

    new-instance v0, Ljava/util/ArrayDeque;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/ArrayDeque;-><init>(I)V

    sput-object v0, Lc2/h$a;->d:Ljava/util/ArrayDeque;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static a(Ljava/lang/Object;)Lc2/h$a;
    .registers 3

    sget-object v0, Lc2/h$a;->d:Ljava/util/ArrayDeque;

    monitor-enter v0

    :try_start_3
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc2/h$a;

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_3 .. :try_end_a} :catchall_19

    if-nez v1, :cond_11

    new-instance v1, Lc2/h$a;

    invoke-direct {v1}, Lc2/h$a;-><init>()V

    :cond_11
    iput-object p0, v1, Lc2/h$a;->c:Ljava/lang/Object;

    const/4 p0, 0x0

    iput p0, v1, Lc2/h$a;->b:I

    iput p0, v1, Lc2/h$a;->a:I

    return-object v1

    :catchall_19
    move-exception p0

    :try_start_1a
    monitor-exit v0
    :try_end_1b
    .catchall {:try_start_1a .. :try_end_1b} :catchall_19

    throw p0
.end method


# virtual methods
.method public final b()V
    .registers 3

    sget-object v0, Lc2/h$a;->d:Ljava/util/ArrayDeque;

    monitor-enter v0

    :try_start_3
    invoke-virtual {v0, p0}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :catchall_8
    move-exception v1

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_3 .. :try_end_a} :catchall_8

    throw v1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    instance-of v0, p1, Lc2/h$a;

    const/4 v1, 0x0

    if-eqz v0, :cond_1e

    check-cast p1, Lc2/h$a;

    iget v0, p0, Lc2/h$a;->b:I

    iget v2, p1, Lc2/h$a;->b:I

    if-ne v0, v2, :cond_1e

    iget v0, p0, Lc2/h$a;->a:I

    iget v2, p1, Lc2/h$a;->a:I

    if-ne v0, v2, :cond_1e

    iget-object v0, p0, Lc2/h$a;->c:Ljava/lang/Object;

    iget-object p1, p1, Lc2/h$a;->c:Ljava/lang/Object;

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1e

    const/4 v1, 0x1

    :cond_1e
    return v1
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, Lc2/h$a;->a:I

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lc2/h$a;->b:I

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lc2/h$a;->c:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
