.class public final Lc2/h;
.super Ljava/lang/Object;
.source "ModelCache.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc2/h$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private final a:Lq2/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lq2/g<",
            "Lc2/h$a<",
            "TA;>;TB;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lc2/g;

    const-wide/16 v1, 0x1f4

    invoke-direct {v0, v1, v2}, Lq2/g;-><init>(J)V

    iput-object v0, p0, Lc2/h;->a:Lq2/g;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-static {p1}, Lc2/h$a;->a(Ljava/lang/Object;)Lc2/h$a;

    move-result-object p1

    iget-object v0, p0, Lc2/h;->a:Lq2/g;

    invoke-virtual {v0, p1}, Lq2/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1}, Lc2/h$a;->b()V

    return-object v0
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    invoke-static {p1}, Lc2/h$a;->a(Ljava/lang/Object;)Lc2/h$a;

    move-result-object p1

    iget-object v0, p0, Lc2/h;->a:Lq2/g;

    invoke-virtual {v0, p1, p2}, Lq2/g;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
