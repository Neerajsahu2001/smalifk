.class public interface abstract Ld6/b$a;
.super Ljava/lang/Object;
.source "EmptyLoader.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld6/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract create(Landroid/database/Cursor;)Landroid/database/Cursor;
.end method
