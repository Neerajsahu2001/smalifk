.class final LD6/b$f;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactViewModelV4.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b;->fetchAndHandlePageData$flipkart_ecom_app_uploadSigned(ZZ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.viewmodel.ReactViewModelV4$fetchAndHandlePageData$1"
    f = "ReactViewModelV4.kt"
    l = {
        0x4c
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field final synthetic b:LD6/b;

.field final synthetic c:Z

.field final synthetic d:Z


# direct methods
.method constructor <init>(LD6/b;ZZLXn/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LD6/b;",
            "ZZ",
            "LXn/d<",
            "-",
            "LD6/b$f;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LD6/b$f;->b:LD6/b;

    iput-boolean p2, p0, LD6/b$f;->c:Z

    iput-boolean p3, p0, LD6/b$f;->d:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LD6/b$f;

    iget-boolean v0, p0, LD6/b$f;->c:Z

    iget-boolean v1, p0, LD6/b$f;->d:Z

    iget-object v2, p0, LD6/b$f;->b:LD6/b;

    invoke-direct {p1, v2, v0, v1, p2}, LD6/b$f;-><init>(LD6/b;ZZLXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LD6/b$f;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LD6/b$f;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LD6/b$f;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LD6/b$f;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LD6/b$f;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_3c

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LD6/b$f;->b:LD6/b;

    invoke-static {p1}, LD6/b;->access$getDataProviderBuilder$p(LD6/b;)LB6/c$a;

    move-result-object v1

    invoke-virtual {v1}, LB6/c$a;->build()LB6/c;

    move-result-object v1

    invoke-virtual {p1}, LD6/b;->getPageUrl()Ljava/lang/String;

    move-result-object v3

    iget-boolean v4, p0, LD6/b$f;->c:Z

    iget-boolean v5, p0, LD6/b$f;->d:Z

    invoke-virtual {v1, v3, v4, v5}, LB6/c;->fetchPageData(Ljava/lang/String;ZZ)Lzp/b;

    move-result-object v1

    new-instance v3, LD6/b$f$a;

    invoke-direct {v3, p1}, LD6/b$f$a;-><init>(LD6/b;)V

    iput v2, p0, LD6/b$f;->a:I

    invoke-interface {v1, v3, p0}, Lzp/b;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3c

    return-object v0

    :cond_3c
    :goto_3c
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
