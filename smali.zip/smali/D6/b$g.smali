.class final LD6/b$g;
.super Lkotlin/jvm/internal/p;
.source "ReactViewModelV4.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b;->fetchAndHandlePageData$flipkart_ecom_app_uploadSigned(ZZ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Ljava/lang/Throwable;",
        "LUn/r;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LD6/b$g;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LD6/b$g;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LD6/b$g;->a:LD6/b$g;

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Ljava/lang/Throwable;

    invoke-virtual {p0, p1}, LD6/b$g;->invoke(Ljava/lang/Throwable;)V

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method

.method public final invoke(Ljava/lang/Throwable;)V
    .registers 3

    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    if-nez v0, :cond_7

    invoke-static {p1}, LO7/c;->logException(Ljava/lang/Throwable;)V

    :cond_7
    return-void
.end method
