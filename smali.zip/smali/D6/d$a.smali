.class public interface abstract Ld6/d$a;
.super Ljava/lang/Object;
.source "FrameworkHelper.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld6/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract onReady(Ld6/c;)V
.end method
