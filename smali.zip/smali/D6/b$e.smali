.class final LD6/b$e;
.super Lkotlin/coroutines/jvm/internal/c;
.source "ReactViewModelV4.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b;->emitNetworkResponse$flipkart_ecom_app_uploadSigned(Lxk/s;ZLXn/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.viewmodel.ReactViewModelV4"
    f = "ReactViewModelV4.kt"
    l = {
        0x8d
    }
    m = "emitNetworkResponse$flipkart_ecom_app_uploadSigned"
.end annotation


# instance fields
.field a:LD6/b;

.field b:Lxk/s;

.field c:Ljava/lang/String;

.field d:I

.field synthetic e:Ljava/lang/Object;

.field final synthetic f:LD6/b;

.field g:I


# direct methods
.method constructor <init>(LD6/b;LXn/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LD6/b;",
            "LXn/d<",
            "-",
            "LD6/b$e;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LD6/b$e;->f:LD6/b;

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/c;-><init>(LXn/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iput-object p1, p0, LD6/b$e;->e:Ljava/lang/Object;

    iget p1, p0, LD6/b$e;->g:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LD6/b$e;->g:I

    const/4 p1, 0x0

    const/4 v0, 0x0

    iget-object v1, p0, LD6/b$e;->f:LD6/b;

    invoke-virtual {v1, p1, v0, p0}, LD6/b;->emitNetworkResponse$flipkart_ecom_app_uploadSigned(Lxk/s;ZLXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
