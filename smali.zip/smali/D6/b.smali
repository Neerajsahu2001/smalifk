.class public final Ld6/b;
.super Landroidx/loader/content/CursorLoader;
.source "EmptyLoader.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld6/b$a;
    }
.end annotation


# instance fields
.field private w:Ld6/b$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ld6/b$a;)V
    .registers 3

    invoke-direct {p0, p1}, Landroidx/loader/content/CursorLoader;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Ld6/b;->w:Ld6/b$a;

    return-void
.end method


# virtual methods
.method public loadInBackground()Landroid/database/Cursor;
    .registers 4

    new-instance v0, Landroid/database/MatrixCursor;

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/String;

    invoke-direct {v0, v2, v1}, Landroid/database/MatrixCursor;-><init>([Ljava/lang/String;I)V

    iget-object v1, p0, Ld6/b;->w:Ld6/b$a;

    invoke-interface {v1, v0}, Ld6/b$a;->create(Landroid/database/Cursor;)Landroid/database/Cursor;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic loadInBackground()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, Ld6/b;->loadInBackground()Landroid/database/Cursor;

    move-result-object v0

    return-object v0
.end method
