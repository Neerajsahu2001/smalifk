.class final LD6/b$i;
.super Lkotlin/jvm/internal/p;
.source "ReactViewModelV4.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;LB6/c$a;Lxk/j;LA6/f;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Landroidx/lifecycle/I<",
        "Ly6/e;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final a:LD6/b$i;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LD6/b$i;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LD6/b$i;->a:LD6/b$i;

    return-void
.end method


# virtual methods
.method public final invoke()Landroidx/lifecycle/I;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/lifecycle/I<",
            "Ly6/e;",
            ">;"
        }
    .end annotation

    new-instance v0, Landroidx/lifecycle/I;

    sget-object v1, Ly6/e$b;->a:Ly6/e$b;

    invoke-direct {v0, v1}, Landroidx/lifecycle/I;-><init>(Ljava/lang/Object;)V

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, LD6/b$i;->invoke()Landroidx/lifecycle/I;

    move-result-object v0

    return-object v0
.end method
