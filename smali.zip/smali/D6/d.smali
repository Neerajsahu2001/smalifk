.class public final Ld6/d;
.super Ljava/lang/Object;
.source "FrameworkHelper.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld6/d$a;
    }
.end annotation


# instance fields
.field private a:Ld6/c;

.field private b:Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;

.field private c:Ls8/b;

.field private d:Landroidx/collection/b;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/collection/b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/collection/b;-><init>(I)V

    iput-object v0, p0, Ld6/d;->d:Landroidx/collection/b;

    return-void
.end method

.method public static enable()V
    .registers 0

    return-void
.end method


# virtual methods
.method public getASMStateHandlerFactory()Ls8/b;
    .registers 2

    iget-object v0, p0, Ld6/d;->c:Ls8/b;

    if-nez v0, :cond_b

    new-instance v0, Ls8/b;

    invoke-direct {v0}, Ls8/b;-><init>()V

    iput-object v0, p0, Ld6/d;->c:Ls8/b;

    :cond_b
    iget-object v0, p0, Ld6/d;->c:Ls8/b;

    return-object v0
.end method

.method public initialize()V
    .registers 2

    new-instance v0, Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;

    invoke-direct {v0}, Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;-><init>()V

    iput-object v0, p0, Ld6/d;->b:Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;

    invoke-virtual {p0}, Ld6/d;->ready()V

    return-void
.end method

.method public declared-synchronized onFrameworkReady(Ld6/d$a;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Ld6/d;->a:Ld6/c;

    if-nez v0, :cond_10

    iget-object v0, p0, Ld6/d;->d:Landroidx/collection/b;

    invoke-virtual {v0, p1}, Landroidx/collection/b;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0}, Ld6/d;->initialize()V

    goto :goto_13

    :catchall_e
    move-exception p1

    goto :goto_15

    :cond_10
    invoke-interface {p1, v0}, Ld6/d$a;->onReady(Ld6/c;)V
    :try_end_13
    .catchall {:try_start_1 .. :try_end_13} :catchall_e

    :goto_13
    monitor-exit p0

    return-void

    :goto_15
    monitor-exit p0

    throw p1
.end method

.method public ready()V
    .registers 5

    new-instance v0, Ld6/c;

    iget-object v1, p0, Ld6/d;->b:Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;

    invoke-direct {v0, v1}, Ld6/c;-><init>(Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;)V

    iput-object v0, p0, Ld6/d;->a:Ld6/c;

    iget-object v0, p0, Ld6/d;->d:Landroidx/collection/b;

    invoke-virtual {v0}, Landroidx/collection/b;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_21

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld6/d$a;

    iget-object v3, p0, Ld6/d;->a:Ld6/c;

    invoke-interface {v2, v3}, Ld6/d$a;->onReady(Ld6/c;)V

    goto :goto_f

    :cond_21
    invoke-virtual {v0}, Landroidx/collection/b;->clear()V

    return-void
.end method
