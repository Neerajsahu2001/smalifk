.class public interface abstract Ld6/a;
.super Ljava/lang/Object;
.source "ActivityInterface.java"


# virtual methods
.method public abstract doLogin()V
.end method

.method public abstract isActivityAlive()Z
.end method

.method public abstract onBackPressed()V
.end method

.method public abstract openFragment(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V
.end method

.method public abstract shouldLockNavDrawer(Z)V
.end method
