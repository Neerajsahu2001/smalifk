.class public final Ld6/c;
.super Ljava/lang/Object;
.source "Framework.java"


# static fields
.field private static b:LEb/b;


# instance fields
.field private final a:Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, LEb/b;

    const-string v1, "910000"

    const-string v2, "1.0"

    invoke-direct {v0, v1, v2}, LEb/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    sput-object v0, Ld6/c;->b:LEb/b;

    return-void
.end method

.method constructor <init>(Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld6/c;->a:Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;

    return-void
.end method

.method public static getVersion()LEb/b;
    .registers 1

    sget-object v0, Ld6/c;->b:LEb/b;

    return-object v0
.end method


# virtual methods
.method public getPageProcessorFactory()Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;
    .registers 2

    iget-object v0, p0, Ld6/c;->a:Lcom/flipkart/android/newmultiwidget/data/provider/processors/n;

    return-object v0
.end method
