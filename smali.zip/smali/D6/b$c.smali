.class final LD6/b$c;
.super Lkotlin/coroutines/jvm/internal/c;
.source "ReactViewModelV4.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b;->a(Ly6/a;LXn/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.viewmodel.ReactViewModelV4"
    f = "ReactViewModelV4.kt"
    l = {
        0x70
    }
    m = "emitCachedResponse"
.end annotation


# instance fields
.field a:LD6/b;

.field b:Ly6/a;

.field c:Lxk/s;

.field d:Lkotlin/jvm/internal/D;

.field e:Lcom/flipkart/android/perf/a$b;

.field f:Lxk/m;

.field synthetic g:Ljava/lang/Object;

.field final synthetic h:LD6/b;

.field i:I


# direct methods
.method constructor <init>(LD6/b;LXn/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LD6/b;",
            "LXn/d<",
            "-",
            "LD6/b$c;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LD6/b$c;->h:LD6/b;

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/c;-><init>(LXn/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LD6/b$c;->g:Ljava/lang/Object;

    iget p1, p0, LD6/b$c;->i:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LD6/b$c;->i:I

    iget-object p1, p0, LD6/b$c;->h:LD6/b;

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, LD6/b;->access$emitCachedResponse(LD6/b;Ly6/a;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
