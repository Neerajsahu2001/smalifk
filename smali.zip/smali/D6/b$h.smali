.class final LD6/b$h;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactViewModelV4.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b;->fetchNext(Lcom/facebook/react/bridge/ReadableMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.viewmodel.ReactViewModelV4$fetchNext$1"
    f = "ReactViewModelV4.kt"
    l = {
        0xdd
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field final synthetic b:LD6/b;

.field final synthetic c:Lcom/facebook/react/bridge/ReadableMap;


# direct methods
.method constructor <init>(LD6/b;Lcom/facebook/react/bridge/ReadableMap;LXn/d;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LD6/b;",
            "Lcom/facebook/react/bridge/ReadableMap;",
            "LXn/d<",
            "-",
            "LD6/b$h;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LD6/b$h;->b:LD6/b;

    iput-object p2, p0, LD6/b$h;->c:Lcom/facebook/react/bridge/ReadableMap;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LD6/b$h;

    iget-object v0, p0, LD6/b$h;->b:LD6/b;

    iget-object v1, p0, LD6/b$h;->c:Lcom/facebook/react/bridge/ReadableMap;

    invoke-direct {p1, v0, v1, p2}, LD6/b$h;-><init>(LD6/b;Lcom/facebook/react/bridge/ReadableMap;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LD6/b$h;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LD6/b$h;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LD6/b$h;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LD6/b$h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LD6/b$h;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_3a

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LD6/b$h;->b:LD6/b;

    invoke-static {p1}, LD6/b;->access$getDataProviderBuilder$p(LD6/b;)LB6/c$a;

    move-result-object v1

    invoke-virtual {v1}, LB6/c$a;->build()LB6/c;

    move-result-object v1

    invoke-virtual {p1}, LD6/b;->getPageUrl()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, LD6/b$h;->c:Lcom/facebook/react/bridge/ReadableMap;

    invoke-virtual {v1, v3, v4}, LB6/c;->fetchPaginatedData(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)Lzp/b;

    move-result-object v1

    new-instance v3, LD6/b$h$a;

    invoke-direct {v3, p1}, LD6/b$h$a;-><init>(LD6/b;)V

    iput v2, p0, LD6/b$h;->a:I

    invoke-interface {v1, v3, p0}, Lzp/b;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3a

    return-object v0

    :cond_3a
    :goto_3a
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
