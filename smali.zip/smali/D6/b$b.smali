.class final LD6/b$b;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ReactViewModelV4.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b;->doBottomSheetAndAutoSuggestCleanup()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.flipkart.android.reactmultiwidget.viewmodel.ReactViewModelV4$doBottomSheetAndAutoSuggestCleanup$1"
    f = "ReactViewModelV4.kt"
    l = {}
    m = "invokeSuspend"
.end annotation


# instance fields
.field final synthetic a:LD6/b;


# direct methods
.method constructor <init>(LD6/b;LXn/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LD6/b;",
            "LXn/d<",
            "-",
            "LD6/b$b;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LD6/b$b;->a:LD6/b;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, LD6/b$b;

    iget-object v0, p0, LD6/b$b;->a:LD6/b;

    invoke-direct {p1, v0, p2}, LD6/b$b;-><init>(LD6/b;LXn/d;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LD6/b$b;->invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/G;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/G;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, LD6/b$b;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LD6/b$b;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LD6/b$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LD6/b$b;->a:LD6/b;

    invoke-virtual {p1}, LD6/b;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/flipkart/android/newmultiwidget/utils/b;->deleteBottomSheetAttachmentResponses(Landroid/content/Context;)V

    invoke-virtual {p1}, LD6/b;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    invoke-static {p1}, Lcom/flipkart/android/newmultiwidget/data/provider/c;->deleteOlderData(Landroid/content/ContentResolver;)V

    const/4 p1, 0x1

    sput-boolean p1, Lcom/flipkart/android/init/FlipkartApplication;->Q:Z

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
