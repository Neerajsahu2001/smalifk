.class final LD6/b$f$a;
.super Ljava/lang/Object;
.source "ReactViewModelV4.kt"

# interfaces
.implements Lzp/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD6/b$f;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lzp/c;"
    }
.end annotation


# instance fields
.field final synthetic a:LD6/b;


# direct methods
.method constructor <init>(LD6/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD6/b$f$a;->a:LD6/b;

    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ly6/b;

    invoke-virtual {p0, p1, p2}, LD6/b$f$a;->emit(Ly6/b;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final emit(Ly6/b;LXn/d;)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ly6/b;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    iget-object v0, p0, LD6/b$f$a;->a:LD6/b;

    invoke-virtual {v0, p1, p2}, LD6/b;->handlePageResponse$flipkart_ecom_app_uploadSigned(Ly6/b;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_b

    return-object p1

    :cond_b
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
