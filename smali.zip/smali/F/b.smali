.class public final LF/b;
.super Ljava/lang/Object;


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f140196

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f140197

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f140199

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f14019c

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f14019e

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f140279

.field public static final Widget_Compat_NotificationActionText:I = 0x7f14027a

.field public static final Widget_Support_CoordinatorLayout:I = 0x7f1402ab
