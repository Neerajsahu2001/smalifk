.class public final LC/b0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/s0;
.implements LD/O;


# instance fields
.field public final a:LD/Z;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object v0

    invoke-direct {p0, v0}, LC/b0;-><init>(LD/Z;)V

    return-void
.end method

.method public constructor <init>(LD/Z;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/b0;->a:LD/Z;

    sget-object v0, LH/j;->y0:LD/c;

    const/4 v1, 0x0

    :try_start_8
    invoke-virtual {p1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object p1
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_e

    :catch_d
    move-object p1, v1

    :goto_e
    check-cast p1, Ljava/lang/Class;

    const-class v0, LC/f0;

    if-eqz p1, :cond_37

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1b

    goto :goto_37

    :cond_1b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid target class configuration for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_37
    :goto_37
    sget-object p1, LH/j;->y0:LD/c;

    iget-object v2, p0, LC/b0;->a:LD/Z;

    invoke-virtual {v2, p1, v0}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object p1, LH/j;->x0:LD/c;

    :try_start_40
    invoke-virtual {v2, p1}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v1
    :try_end_44
    .catch Ljava/lang/IllegalArgumentException; {:try_start_40 .. :try_end_44} :catch_44

    :catch_44
    if-nez v1, :cond_69

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "-"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object v0, LH/j;->x0:LD/c;

    iget-object v1, p0, LC/b0;->a:LD/Z;

    invoke-virtual {v1, v0, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    :cond_69
    return-void
.end method


# virtual methods
.method public final a(Landroid/util/Size;)Ljava/lang/Object;
    .registers 4

    sget-object v0, LD/P;->j0:LD/c;

    iget-object v1, p0, LC/b0;->a:LD/Z;

    invoke-virtual {v1, v0, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    return-object p0
.end method

.method public final b()LD/Y;
    .registers 2

    iget-object v0, p0, LC/b0;->a:LD/Z;

    return-object v0
.end method

.method public final c(I)Ljava/lang/Object;
    .registers 4

    sget-object v0, LD/P;->h0:LD/c;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-object v1, p0, LC/b0;->a:LD/Z;

    invoke-virtual {v1, v0, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    return-object p0
.end method

.method public final d()LD/t0;
    .registers 3

    new-instance v0, LD/L;

    iget-object v1, p0, LC/b0;->a:LD/Z;

    invoke-static {v1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v1

    invoke-direct {v0, v1}, LD/L;-><init>(LD/c0;)V

    return-object v0
.end method

.method public final e()LC/f0;
    .registers 8

    sget-object v0, LD/P;->g0:LD/c;

    iget-object v1, p0, LC/b0;->a:LD/Z;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    :try_start_8
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_e

    :catch_d
    move-object v0, v2

    :goto_e
    if-eqz v0, :cond_23

    sget-object v0, LD/P;->j0:LD/c;

    :try_start_12
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_16
    .catch Ljava/lang/IllegalArgumentException; {:try_start_12 .. :try_end_16} :catch_17

    goto :goto_18

    :catch_17
    move-object v0, v2

    :goto_18
    if-nez v0, :cond_1b

    goto :goto_23

    :cond_1b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_23
    :goto_23
    sget-object v0, LD/L;->f:LD/c;

    :try_start_25
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_29
    .catch Ljava/lang/IllegalArgumentException; {:try_start_25 .. :try_end_29} :catch_2a

    goto :goto_2b

    :catch_2a
    move-object v0, v2

    :goto_2b
    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_49

    sget-object v5, LD/L;->e:LD/c;

    :try_start_33
    invoke-virtual {v1, v5}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v5
    :try_end_37
    .catch Ljava/lang/IllegalArgumentException; {:try_start_33 .. :try_end_37} :catch_38

    goto :goto_39

    :catch_38
    move-object v5, v2

    :goto_39
    if-nez v5, :cond_3d

    move v5, v4

    goto :goto_3e

    :cond_3d
    move v5, v3

    :goto_3e
    const-string v6, "Cannot set buffer format with CaptureProcessor defined."

    invoke-static {v5, v6}, Ll7/C5;->b(ZLjava/lang/String;)V

    sget-object v5, LD/N;->f0:LD/c;

    invoke-virtual {v1, v5, v0}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_6a

    :cond_49
    sget-object v0, LD/L;->e:LD/c;

    :try_start_4b
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_4f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4b .. :try_end_4f} :catch_50

    goto :goto_51

    :catch_50
    move-object v0, v2

    :goto_51
    if-eqz v0, :cond_5f

    sget-object v0, LD/N;->f0:LD/c;

    const/16 v5, 0x23

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v0, v5}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_6a

    :cond_5f
    sget-object v0, LD/N;->f0:LD/c;

    const/16 v5, 0x100

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v0, v5}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    :goto_6a
    new-instance v0, LC/f0;

    new-instance v5, LD/L;

    invoke-static {v1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v6

    invoke-direct {v5, v6}, LD/L;-><init>(LD/c0;)V

    invoke-direct {v0, v5}, LC/f0;-><init>(LD/L;)V

    sget-object v5, LD/P;->j0:LD/c;

    :try_start_7a
    invoke-virtual {v1, v5}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v2
    :try_end_7e
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7a .. :try_end_7e} :catch_7e

    :catch_7e
    check-cast v2, Landroid/util/Size;

    if-eqz v2, :cond_91

    new-instance v5, Landroid/util/Rational;

    invoke-virtual {v2}, Landroid/util/Size;->getWidth()I

    move-result v6

    invoke-virtual {v2}, Landroid/util/Size;->getHeight()I

    move-result v2

    invoke-direct {v5, v6, v2}, Landroid/util/Rational;-><init>(II)V

    iput-object v5, v0, LC/f0;->q:Landroid/util/Rational;

    :cond_91
    sget-object v2, LD/L;->g:LD/c;

    const/4 v5, 0x2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    :try_start_98
    invoke-virtual {v1, v2}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v6
    :try_end_9c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_98 .. :try_end_9c} :catch_9c

    :catch_9c
    check-cast v6, Ljava/lang/Integer;

    const-string v2, "Maximum outstanding image count must be at least 1"

    invoke-static {v6, v2}, Ll7/C5;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    if-lt v6, v4, :cond_aa

    move v3, v4

    :cond_aa
    invoke-static {v3, v2}, Ll7/C5;->b(ZLjava/lang/String;)V

    sget-object v2, LH/i;->w0:LD/c;

    invoke-static {}, Lcom/bumptech/glide/c;->d()LF/j;

    move-result-object v3

    :try_start_b3
    invoke-virtual {v1, v2}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v3
    :try_end_b7
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b3 .. :try_end_b7} :catch_b7

    :catch_b7
    check-cast v3, Ljava/util/concurrent/Executor;

    const-string v2, "The IO executor can\'t be null"

    invoke-static {v3, v2}, Ll7/C5;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, LD/L;->c:LD/c;

    iget-object v3, v1, LD/c0;->a:Ljava/util/TreeMap;

    invoke-virtual {v3, v2}, Ljava/util/TreeMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f7

    invoke-virtual {v1, v2}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    if-eqz v1, :cond_e3

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-eqz v2, :cond_f7

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-eq v2, v4, :cond_f7

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-ne v2, v5, :cond_e3

    goto :goto_f7

    :cond_e3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "The flash mode is not allowed to set: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_f7
    :goto_f7
    return-object v0
.end method
