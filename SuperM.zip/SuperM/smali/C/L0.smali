.class public interface abstract LC/l0;
.super Ljava/lang/Object;
.source "SourceFile"
