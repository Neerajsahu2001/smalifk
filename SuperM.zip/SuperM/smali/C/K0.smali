.class public interface abstract LC/k0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/AutoCloseable;


# virtual methods
.method public abstract Q()LC/h0;
.end method

.method public abstract X()Landroid/media/Image;
.end method

.method public abstract getHeight()I
.end method

.method public abstract getWidth()I
.end method

.method public abstract j()I
.end method

.method public abstract k()[LA/d;
.end method
