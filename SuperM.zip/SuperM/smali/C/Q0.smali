.class public final synthetic LC/q0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC/q0;->a:I

    iput-object p2, p0, LC/q0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v3, p0, LC/q0;->a:I

    packed-switch v3, :pswitch_data_1e8

    iget-object v1, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/core/widget/ContentLoadingProgressBar;

    const-wide/16 v3, -0x1

    iput-wide v3, v1, Landroidx/core/widget/ContentLoadingProgressBar;->a:J

    iput-boolean v2, v1, Landroidx/core/widget/ContentLoadingProgressBar;->d:Z

    iget-object v3, v1, Landroidx/core/widget/ContentLoadingProgressBar;->e:LB1/F;

    invoke-virtual {v1, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-boolean v2, v1, Landroidx/core/widget/ContentLoadingProgressBar;->b:Z

    iget-boolean v2, v1, Landroidx/core/widget/ContentLoadingProgressBar;->c:Z

    if-nez v2, :cond_26

    iget-object v2, v1, Landroidx/core/widget/ContentLoadingProgressBar;->f:LC/Z;

    const-wide/16 v3, 0x1f4

    invoke-virtual {v1, v2, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    iput-boolean v0, v1, Landroidx/core/widget/ContentLoadingProgressBar;->c:Z

    :cond_26
    return-void

    :pswitch_27
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lw/l;

    invoke-virtual {v0}, Lw/l;->s()J

    return-void

    :pswitch_2f
    new-instance v0, Landroidx/privacysandbox/ads/adservices/adid/b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sget-object v1, Lq2/d;->a:Ll7/z7;

    iget-object v3, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    invoke-static {v3, v0, v1, v2}, Lq2/d;->c(Landroid/content/Context;Ljava/util/concurrent/Executor;Lq2/c;Z)V

    return-void

    :pswitch_3e
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/airbnb/lottie/LottieAnimationView;

    const-string v1, "$view"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_5b

    sget-object v1, Ln3/c;->f:Ln3/c;

    iget-object v2, v0, Lcom/airbnb/lottie/LottieAnimationView;->n:Ljava/util/HashSet;

    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iget-object v0, v0, Lcom/airbnb/lottie/LottieAnimationView;->h:Ln3/t;

    invoke-virtual {v0}, Ln3/t;->n()V

    :cond_5b
    return-void

    :pswitch_5c
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/AppLifecycleIntegration;

    invoke-virtual {v0}, Lio/sentry/android/core/AppLifecycleIntegration;->a()V

    return-void

    :pswitch_64
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lf9/j;

    const-string v3, "this$0"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, v0, Lf9/j;->b:Lx9/o;

    iget-object v3, v3, Lx9/o;->d:Lw9/g;

    new-instance v4, Lf9/d;

    invoke-direct {v4, v0, v1}, Lf9/d;-><init>(Lf9/j;I)V

    const/4 v5, 0x4

    invoke-static {v3, v5, v4, v1}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    monitor-enter v0

    :try_start_7b
    iget-object v3, v0, Lf9/j;->e:LV7/b;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v3, v4}, LV7/b;->a(Ljava/lang/Object;)V

    sget-object v3, Lc9/u;->a:Ljava/util/LinkedHashMap;

    iget-object v3, v0, Lf9/j;->a:Landroid/content/Context;

    iget-object v4, v0, Lf9/j;->b:Lx9/o;

    invoke-static {v3, v4}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object v3

    iget-object v4, v0, Lf9/j;->g:Ljava/lang/String;

    if-eqz v4, :cond_d7

    invoke-static {v4}, LZd/q;->o(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_97

    goto :goto_d7

    :cond_97
    iget-object v6, v3, LK9/b;->b:LL9/a;

    invoke-interface {v6}, LL9/a;->a()Z

    move-result v6

    if-eqz v6, :cond_cf

    iget-object v6, v3, LK9/b;->c:Lx9/o;

    invoke-static {v6}, Lm7/A;->u(Lx9/o;)Z

    invoke-virtual {v3, v4}, LK9/b;->g0(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_d7

    iget-object v3, v0, Lf9/j;->b:Lx9/o;

    iget-object v3, v3, Lx9/o;->d:Lw9/g;

    new-instance v6, Lf9/e;

    invoke-direct {v6, v0, v1}, Lf9/e;-><init>(Lf9/j;I)V

    invoke-static {v3, v5, v6, v1}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    iput-object v4, v0, Lf9/j;->g:Ljava/lang/String;

    sget-boolean v1, Lm7/k;->a:Z

    if-eqz v1, :cond_e6

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iget-object v3, v0, Lf9/j;->e:LV7/b;

    invoke-virtual {v3, v1}, LV7/b;->a(Ljava/lang/Object;)V

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, v0, Lf9/j;->d:LV7/b;

    invoke-virtual {v2, v1}, LV7/b;->a(Ljava/lang/Object;)V

    goto :goto_e6

    :catchall_cd
    move-exception v1

    goto :goto_e8

    :cond_cf
    new-instance v1, Ln9/b;

    const-string v2, "Account/SDK disabled."

    invoke-direct {v1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_d7
    :goto_d7
    iget-object v2, v0, Lf9/j;->b:Lx9/o;

    iget-object v2, v2, Lx9/o;->d:Lw9/g;

    new-instance v3, Lf9/f;

    invoke-direct {v3, v0, v1}, Lf9/f;-><init>(Lf9/j;I)V

    invoke-static {v2, v5, v3, v1}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-virtual {v0}, Lf9/j;->b()Ljava/lang/String;
    :try_end_e6
    .catchall {:try_start_7b .. :try_end_e6} :catchall_cd

    :cond_e6
    :goto_e6
    monitor-exit v0

    return-void

    :goto_e8
    monitor-exit v0

    throw v1

    :pswitch_ea
    sget v0, Lcom/supermoney/payments/MainActivity;->o1:I

    const-string v0, "this$0"

    iget-object v1, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v1, Lcom/supermoney/payments/MainActivity;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/supermoney/payments/MainActivity;->hideSplash()V

    return-void

    :pswitch_f9
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Landroid/app/Activity;

    invoke-static {v0}, Lcom/supermoney/payments/reactnative/nativemodule/DeviceInfoModule;->d(Landroid/app/Activity;)V

    return-void

    :pswitch_101
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/newrelic/agent/android/harvest/HarvestTimer;

    invoke-static {v0}, Lcom/newrelic/agent/android/harvest/HarvestTimer;->a(Lcom/newrelic/agent/android/harvest/HarvestTimer;)V

    return-void

    :pswitch_109
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/perf/metrics/AppStartTrace;

    invoke-static {v0}, Lcom/google/firebase/perf/metrics/AppStartTrace;->c(Lcom/google/firebase/perf/metrics/AppStartTrace;)V

    return-void

    :pswitch_111
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/fabric/mounting/SurfaceMountingManager;

    invoke-static {v0}, Lcom/facebook/react/fabric/mounting/SurfaceMountingManager;->a(Lcom/facebook/react/fabric/mounting/SurfaceMountingManager;)V

    return-void

    :pswitch_119
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/devsupport/LogBoxModule;

    invoke-static {v0}, Lcom/facebook/react/devsupport/LogBoxModule;->a(Lcom/facebook/react/devsupport/LogBoxModule;)V

    return-void

    :pswitch_121
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/bridge/CatalystInstanceImpl;

    invoke-static {v0}, Lcom/facebook/react/bridge/CatalystInstanceImpl;->c(Lcom/facebook/react/bridge/CatalystInstanceImpl;)V

    return-void

    :pswitch_129
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/modules/devloading/DevLoadingModule;

    invoke-static {v0}, Lcom/facebook/react/modules/devloading/DevLoadingModule;->b(Lcom/facebook/react/modules/devloading/DevLoadingModule;)V

    return-void

    :pswitch_131
    sget v0, Landroidx/media3/ui/DefaultTimeBar;->P:I

    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/ui/DefaultTimeBar;

    invoke-virtual {v0, v2}, Landroidx/media3/ui/DefaultTimeBar;->f(Z)V

    return-void

    :pswitch_13b
    iget-object v1, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/appcompat/widget/Toolbar;

    iget-object v3, v1, Landroidx/appcompat/widget/Toolbar;->H:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_145
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_15d

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/view/MenuItem;

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->n()Landroidx/appcompat/view/menu/MenuBuilder;

    move-result-object v5

    invoke-interface {v4}, Landroid/view/MenuItem;->getItemId()I

    move-result v4

    invoke-interface {v5, v4}, Landroid/view/Menu;->removeItem(I)V

    goto :goto_145

    :cond_15d
    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->n()Landroidx/appcompat/view/menu/MenuBuilder;

    move-result-object v3

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->n()Landroidx/appcompat/view/menu/MenuBuilder;

    move-result-object v5

    move v6, v2

    :goto_16b
    invoke-interface {v5}, Landroid/view/Menu;->size()I

    move-result v7

    if-ge v6, v7, :cond_17a

    invoke-interface {v5, v6}, Landroid/view/Menu;->getItem(I)Landroid/view/MenuItem;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/2addr v6, v0

    goto :goto_16b

    :cond_17a
    new-instance v5, Landroidx/appcompat/view/SupportMenuInflater;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6}, Landroidx/appcompat/view/SupportMenuInflater;-><init>(Landroid/content/Context;)V

    iget-object v6, v1, Landroidx/appcompat/widget/Toolbar;->G:Landroidx/core/view/p;

    iget-object v6, v6, Landroidx/core/view/p;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v6}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_18b
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_19f

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/core/view/t;

    check-cast v7, Landroidx/fragment/app/W;

    iget-object v7, v7, Landroidx/fragment/app/W;->a:Landroidx/fragment/app/g0;

    invoke-virtual {v7, v3, v5}, Landroidx/fragment/app/g0;->j(Landroid/view/Menu;Landroid/view/MenuInflater;)Z

    goto :goto_18b

    :cond_19f
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->n()Landroidx/appcompat/view/menu/MenuBuilder;

    move-result-object v5

    :goto_1a8
    invoke-interface {v5}, Landroid/view/Menu;->size()I

    move-result v6

    if-ge v2, v6, :cond_1b7

    invoke-interface {v5, v2}, Landroid/view/Menu;->getItem(I)Landroid/view/MenuItem;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/2addr v2, v0

    goto :goto_1a8

    :cond_1b7
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    iput-object v3, v1, Landroidx/appcompat/widget/Toolbar;->H:Ljava/util/ArrayList;

    return-void

    :pswitch_1bd
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/modules/debug/DevSettingsModule;

    invoke-static {v0}, Lcom/facebook/react/modules/debug/DevSettingsModule;->b(Lcom/facebook/react/modules/debug/DevSettingsModule;)V

    return-void

    :pswitch_1c5
    const-string v0, "$handler"

    iget-object v1, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v1, LOb/d;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, LOb/d;->e()V

    return-void

    :pswitch_1d2
    const-string v0, "this$0"

    iget-object v1, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v1, LOb/a;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, LOb/d;->m()V

    return-void

    :pswitch_1df
    iget-object v0, p0, LC/q0;->b:Ljava/lang/Object;

    check-cast v0, Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void

    nop

    :pswitch_data_1e8
    .packed-switch 0x0
        :pswitch_1df
        :pswitch_1d2
        :pswitch_1c5
        :pswitch_1bd
        :pswitch_13b
        :pswitch_131
        :pswitch_129
        :pswitch_121
        :pswitch_119
        :pswitch_111
        :pswitch_109
        :pswitch_101
        :pswitch_f9
        :pswitch_ea
        :pswitch_64
        :pswitch_5c
        :pswitch_3e
        :pswitch_2f
        :pswitch_27
    .end packed-switch
.end method
