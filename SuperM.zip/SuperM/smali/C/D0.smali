.class public final synthetic LC/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC/d0;->a:I

    iput-object p2, p0, LC/d0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object v2, p0, LC/d0;->b:Ljava/lang/Object;

    iget v3, p0, LC/d0;->a:I

    packed-switch v3, :pswitch_data_154

    check-cast v2, LC/F0;

    invoke-virtual {v2}, LC/F0;->e()V

    return-void

    :pswitch_f
    check-cast v2, Ljava/util/LinkedHashSet;

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_15
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_28

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lw/e0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v1}, Lw/e0;->c(Lw/e0;)V

    goto :goto_15

    :cond_28
    return-void

    :pswitch_29
    check-cast v2, Lt1/T;

    invoke-virtual {v2}, Lt1/T;->z()V

    return-void

    :pswitch_2f
    check-cast v2, Lcom/airbnb/lottie/LottieAnimationView;

    const-string v0, "$view"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    invoke-virtual {v2}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_45

    iput-boolean v1, v2, Lcom/airbnb/lottie/LottieAnimationView;->l:Z

    iget-object v0, v2, Lcom/airbnb/lottie/LottieAnimationView;->h:Ln3/t;

    invoke-virtual {v0}, Ln3/t;->k()V

    :cond_45
    return-void

    :pswitch_46
    check-cast v2, Lk1/f;

    iget-boolean v0, v2, Lk1/f;->c:Z

    if-eqz v0, :cond_4d

    goto :goto_60

    :cond_4d
    iget-object v0, v2, Lk1/f;->b:Lk1/i;

    if-eqz v0, :cond_56

    iget-object v1, v2, Lk1/f;->a:Lk1/k;

    invoke-interface {v0, v1}, Lk1/i;->c(Lk1/k;)V

    :cond_56
    iget-object v0, v2, Lk1/f;->d:Lk1/g;

    iget-object v0, v0, Lk1/g;->n:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v0, 0x1

    iput-boolean v0, v2, Lk1/f;->c:Z

    :goto_60
    return-void

    :pswitch_61
    check-cast v2, Lio/sentry/M1;

    invoke-virtual {v2}, Lio/sentry/M1;->getCacheDirPathWithoutDsn()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_f6

    new-instance v4, Ljava/io/File;

    const-string v5, "app_start_profiling_config"

    invoke-direct {v4, v3, v5}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_70
    invoke-static {v4}, Ll7/l5;->b(Ljava/io/File;)Z

    invoke-virtual {v2}, Lio/sentry/M1;->isEnableAppStartProfiling()Z

    move-result v3

    if-nez v3, :cond_7b

    goto/16 :goto_f6

    :cond_7b
    invoke-virtual {v2}, Lio/sentry/M1;->isTracingEnabled()Z

    move-result v3

    if-nez v3, :cond_91

    invoke-virtual {v2}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object v0

    sget-object v3, Lio/sentry/y1;->INFO:Lio/sentry/y1;

    const-string v4, "Tracing is disabled and app start profiling will not start."

    new-array v1, v1, [Ljava/lang/Object;

    invoke-interface {v0, v3, v4, v1}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_f6

    :catchall_8f
    move-exception v0

    goto :goto_eb

    :cond_91
    invoke-virtual {v4}, Ljava/io/File;->createNewFile()Z

    move-result v3

    if-eqz v3, :cond_f6

    new-instance v3, Lio/sentry/i2;

    sget-object v5, Lio/sentry/protocol/H;->CUSTOM:Lio/sentry/protocol/H;

    const-string v6, "app.launch"

    const-string v7, "profile"

    invoke-direct {v3, v6, v5, v7, v0}, Lio/sentry/i2;-><init>(Ljava/lang/String;Lio/sentry/protocol/H;Ljava/lang/String;LO6/f;)V

    new-instance v0, LM4/a;

    invoke-direct {v0, v3, v1}, LM4/a;-><init>(Ljava/lang/Object;Z)V

    new-instance v1, Lfc/l;

    const/16 v3, 0x13

    invoke-direct {v1, v2, v3}, Lfc/l;-><init>(Lio/sentry/M1;I)V

    invoke-virtual {v1, v0}, Lfc/l;->P(LM4/a;)LO6/f;

    move-result-object v0

    new-instance v1, Lio/sentry/Z0;

    invoke-direct {v1, v2, v0}, Lio/sentry/Z0;-><init>(Lio/sentry/M1;LO6/f;)V

    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_bc
    .catchall {:try_start_70 .. :try_end_bc} :catchall_8f

    :try_start_bc
    new-instance v3, Ljava/io/BufferedWriter;

    new-instance v4, Ljava/io/OutputStreamWriter;

    sget-object v5, Lio/sentry/X0;->d:Ljava/nio/charset/Charset;

    invoke-direct {v4, v0, v5}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v3, v4}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V
    :try_end_c8
    .catchall {:try_start_bc .. :try_end_c8} :catchall_d6

    :try_start_c8
    invoke-virtual {v2}, Lio/sentry/M1;->getSerializer()Lio/sentry/O;

    move-result-object v4

    invoke-interface {v4, v1, v3}, Lio/sentry/O;->f(Ljava/lang/Object;Ljava/io/BufferedWriter;)V
    :try_end_cf
    .catchall {:try_start_c8 .. :try_end_cf} :catchall_d8

    :try_start_cf
    invoke-virtual {v3}, Ljava/io/Writer;->close()V
    :try_end_d2
    .catchall {:try_start_cf .. :try_end_d2} :catchall_d6

    :try_start_d2
    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    :try_end_d5
    .catchall {:try_start_d2 .. :try_end_d5} :catchall_8f

    goto :goto_f6

    :catchall_d6
    move-exception v1

    goto :goto_e2

    :catchall_d8
    move-exception v1

    :try_start_d9
    invoke-virtual {v3}, Ljava/io/Writer;->close()V
    :try_end_dc
    .catchall {:try_start_d9 .. :try_end_dc} :catchall_dd

    goto :goto_e1

    :catchall_dd
    move-exception v3

    :try_start_de
    invoke-virtual {v1, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_e1
    throw v1
    :try_end_e2
    .catchall {:try_start_de .. :try_end_e2} :catchall_d6

    :goto_e2
    :try_start_e2
    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    :try_end_e5
    .catchall {:try_start_e2 .. :try_end_e5} :catchall_e6

    goto :goto_ea

    :catchall_e6
    move-exception v0

    :try_start_e7
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_ea
    throw v1
    :try_end_eb
    .catchall {:try_start_e7 .. :try_end_eb} :catchall_8f

    :goto_eb
    invoke-virtual {v2}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object v1

    sget-object v2, Lio/sentry/y1;->ERROR:Lio/sentry/y1;

    const-string v3, "Unable to create app start profiling config file. "

    invoke-interface {v1, v2, v3, v0}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_f6
    :goto_f6
    return-void

    :pswitch_f7
    check-cast v2, Li1/e;

    invoke-virtual {v2, v1}, Li1/e;->A(Z)V

    return-void

    :pswitch_fd
    sget v0, Lcom/swmansion/rnscreens/ScreenStack;->s:I

    check-cast v2, Lcom/swmansion/rnscreens/p;

    if-eqz v2, :cond_10c

    check-cast v2, Lcom/swmansion/rnscreens/ScreenFragment;

    invoke-virtual {v2}, Lcom/swmansion/rnscreens/ScreenFragment;->v()Lcom/swmansion/rnscreens/m;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    :cond_10c
    return-void

    :pswitch_10d
    check-cast v2, Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;

    invoke-static {v2}, Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;->e(Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;)V

    return-void

    :pswitch_113
    check-cast v2, Lcom/google/firebase/perf/transport/TransportManager;

    invoke-static {v2}, Lcom/google/firebase/perf/transport/TransportManager;->a(Lcom/google/firebase/perf/transport/TransportManager;)V

    return-void

    :pswitch_119
    check-cast v2, Lcom/google/firebase/perf/metrics/AppStartTrace;

    invoke-static {v2}, Lcom/google/firebase/perf/metrics/AppStartTrace;->b(Lcom/google/firebase/perf/metrics/AppStartTrace;)V

    return-void

    :pswitch_11f
    check-cast v2, Lcom/google/firebase/installations/FirebaseInstallations;

    invoke-static {v2}, Lcom/google/firebase/installations/FirebaseInstallations;->d(Lcom/google/firebase/installations/FirebaseInstallations;)V

    return-void

    :pswitch_125
    check-cast v2, Lcom/facebook/react/bridge/CatalystInstanceImpl;

    invoke-static {v2}, Lcom/facebook/react/bridge/CatalystInstanceImpl;->f(Lcom/facebook/react/bridge/CatalystInstanceImpl;)V

    return-void

    :pswitch_12b
    check-cast v2, Landroidx/media3/ui/A;

    iget-object v0, v2, Landroidx/media3/ui/A;->n:Landroid/animation/AnimatorSet;

    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    return-void

    :pswitch_133
    sget v0, Landroidx/media3/ui/LegacyPlayerControlView;->V0:I

    check-cast v2, Landroidx/media3/ui/LegacyPlayerControlView;

    invoke-virtual {v2}, Landroidx/media3/ui/LegacyPlayerControlView;->i()V

    return-void

    :pswitch_13b
    check-cast v2, Lcom/facebook/react/modules/debug/FpsDebugFrameCallback;

    invoke-static {v2}, Lcom/facebook/react/modules/debug/FpsDebugFrameCallback;->b(Lcom/facebook/react/modules/debug/FpsDebugFrameCallback;)V

    return-void

    :pswitch_141
    check-cast v2, LN/u;

    iget-object v1, v2, LN/u;->g:LN/i;

    if-eqz v1, :cond_14c

    invoke-virtual {v1}, LN/i;->a()V

    iput-object v0, v2, LN/u;->g:LN/i;

    :cond_14c
    return-void

    :pswitch_14d
    check-cast v2, LC/e0;

    invoke-virtual {v2}, LC/e0;->b()V

    return-void

    nop

    :pswitch_data_154
    .packed-switch 0x0
        :pswitch_14d
        :pswitch_141
        :pswitch_13b
        :pswitch_133
        :pswitch_12b
        :pswitch_125
        :pswitch_11f
        :pswitch_119
        :pswitch_113
        :pswitch_10d
        :pswitch_fd
        :pswitch_f7
        :pswitch_61
        :pswitch_46
        :pswitch_2f
        :pswitch_29
        :pswitch_f
    .end packed-switch
.end method
