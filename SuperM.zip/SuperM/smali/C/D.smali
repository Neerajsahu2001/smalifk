.class public abstract LC/d;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Ljava/lang/Object;)I
    .registers 3

    const-string v0, "attribute"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p0, Ljava/util/Date;

    if-eqz v0, :cond_b

    const/4 p0, 0x2

    goto :goto_19

    :cond_b
    instance-of v0, p0, Landroid/location/Location;

    const/4 v1, 0x1

    if-eqz v0, :cond_12

    move p0, v1

    goto :goto_14

    :cond_12
    instance-of p0, p0, Lba/b;

    :goto_14
    if-eqz p0, :cond_18

    const/4 p0, 0x3

    goto :goto_19

    :cond_18
    move p0, v1

    :goto_19
    return p0
.end method

.method public static b(Ljava/lang/String;)LB3/a;
    .registers 4

    const-string v0, "instanceName"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LB3/a;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_8
    sget-object v1, LB3/a;->d:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_1b

    new-instance v2, LB3/a;

    invoke-direct {v2}, LB3/a;-><init>()V

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1b

    :catchall_19
    move-exception p0

    goto :goto_1f

    :cond_1b
    :goto_1b
    check-cast v2, LB3/a;
    :try_end_1d
    .catchall {:try_start_8 .. :try_end_1d} :catchall_19

    monitor-exit v0

    return-object v2

    :goto_1f
    monitor-exit v0

    throw p0
.end method

.method public static final c(Ljava/util/LinkedHashMap;)J
    .registers 9

    const-string v0, "sdkInstances"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lkotlin/jvm/internal/y;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_12
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3a

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lx9/o;

    iget-wide v2, v0, Lkotlin/jvm/internal/y;->a:J

    iget-object v4, v1, Lx9/o;->b:Lr9/a;

    iget-object v4, v4, Lr9/a;->i:LU7/e;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v1, Lx9/o;->c:LJ9/a;

    iget-object v1, v1, LJ9/a;->c:LE9/b;

    iget-wide v4, v1, LE9/b;->b:J

    const-wide/16 v6, -0x1

    invoke-static {v6, v7, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v4

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    iput-wide v1, v0, Lkotlin/jvm/internal/y;->a:J

    goto :goto_12

    :cond_3a
    sget-object p0, Lw9/g;->d:Lsa/x;

    new-instance p0, Lh9/b;

    const/4 v1, 0x1

    invoke-direct {p0, v1, v0}, Lh9/b;-><init>(ILjava/lang/Object;)V

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v2, p0, v1}, LW4/c;->h(ILHc/a;I)V

    iget-wide v0, v0, Lkotlin/jvm/internal/y;->a:J

    return-wide v0
.end method

.method public static final d(Ljava/lang/Object;)Z
    .registers 7

    const-string v0, "attributeValue"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, LC/d;->e(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_c0

    sget-object v0, Lh9/g;->a:Lh9/g;

    const-string v2, "null cannot be cast to non-null type java.lang.Class<*>"

    instance-of v3, p0, [Ljava/lang/Object;

    const/4 v4, 0x0

    if-eqz v3, :cond_bb

    check-cast p0, [Ljava/lang/Object;

    :try_start_17
    const-class v3, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v5

    invoke-static {v5, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v3
    :try_end_28
    .catchall {:try_start_17 .. :try_end_28} :catchall_29

    goto :goto_30

    :catchall_29
    move-exception v3

    sget-object v5, Lw9/g;->d:Lsa/x;

    invoke-static {v1, v3, v0}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    move v3, v4

    :goto_30
    if-nez v3, :cond_b9

    :try_start_32
    const-class v3, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v5

    invoke-static {v5, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v3
    :try_end_43
    .catchall {:try_start_32 .. :try_end_43} :catchall_44

    goto :goto_4b

    :catchall_44
    move-exception v3

    sget-object v5, Lw9/g;->d:Lsa/x;

    invoke-static {v1, v3, v0}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    move v3, v4

    :goto_4b
    if-nez v3, :cond_b9

    :try_start_4d
    const-class v3, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v5

    invoke-static {v5, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v3
    :try_end_5e
    .catchall {:try_start_4d .. :try_end_5e} :catchall_5f

    goto :goto_66

    :catchall_5f
    move-exception v3

    sget-object v5, Lw9/g;->d:Lsa/x;

    invoke-static {v1, v3, v0}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    move v3, v4

    :goto_66
    if-nez v3, :cond_b9

    :try_start_68
    const-class v3, Ljava/lang/Short;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v5

    invoke-static {v5, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v3
    :try_end_79
    .catchall {:try_start_68 .. :try_end_79} :catchall_7a

    goto :goto_81

    :catchall_7a
    move-exception v3

    sget-object v5, Lw9/g;->d:Lsa/x;

    invoke-static {v1, v3, v0}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    move v3, v4

    :goto_81
    if-nez v3, :cond_b9

    :try_start_83
    const-class v3, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v5

    invoke-static {v5, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v3
    :try_end_94
    .catchall {:try_start_83 .. :try_end_94} :catchall_95

    goto :goto_9c

    :catchall_95
    move-exception v3

    sget-object v5, Lw9/g;->d:Lsa/x;

    invoke-static {v1, v3, v0}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    move v3, v4

    :goto_9c
    if-nez v3, :cond_b9

    :try_start_9e
    const-class v3, Ljava/lang/Double;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object p0

    invoke-static {p0, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p0
    :try_end_af
    .catchall {:try_start_9e .. :try_end_af} :catchall_b0

    goto :goto_b7

    :catchall_b0
    move-exception p0

    sget-object v2, Lw9/g;->d:Lsa/x;

    invoke-static {v1, p0, v0}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    move p0, v4

    :goto_b7
    if-eqz p0, :cond_bb

    :cond_b9
    move p0, v1

    goto :goto_bc

    :cond_bb
    move p0, v4

    :goto_bc
    if-eqz p0, :cond_bf

    goto :goto_c0

    :cond_bf
    move v1, v4

    :cond_c0
    :goto_c0
    return v1
.end method

.method public static final e(Ljava/lang/Object;)Z
    .registers 2

    const-string v0, "attributeValue"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p0, [I

    if-nez v0, :cond_1c

    instance-of v0, p0, [S

    if-nez v0, :cond_1c

    instance-of v0, p0, [D

    if-nez v0, :cond_1c

    instance-of v0, p0, [F

    if-nez v0, :cond_1c

    instance-of p0, p0, [J

    if-eqz p0, :cond_1a

    goto :goto_1c

    :cond_1a
    const/4 p0, 0x0

    goto :goto_1d

    :cond_1c
    :goto_1c
    const/4 p0, 0x1

    :goto_1d
    return p0
.end method

.method public static final f(Landroid/content/Context;Lx9/o;)Z
    .registers 4

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sdkInstance"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object v0

    iget-object v1, p1, Lx9/o;->c:LJ9/a;

    iget-boolean v1, v1, LJ9/a;->a:Z

    if-eqz v1, :cond_2c

    iget-object v0, v0, LK9/b;->b:LL9/a;

    invoke-interface {v0}, LL9/a;->a()Z

    move-result v1

    if-eqz v1, :cond_2c

    invoke-interface {v0}, LL9/a;->a0()Lx9/f;

    move-result-object v0

    iget-boolean v0, v0, Lx9/f;->a:Z

    if-nez v0, :cond_2c

    invoke-static {p1}, Lm7/A;->u(Lx9/o;)Z

    invoke-static {p0, p1}, Lm7/A;->z(Landroid/content/Context;Lx9/o;)V

    const/4 p0, 0x1

    goto :goto_2d

    :cond_2c
    const/4 p0, 0x0

    :goto_2d
    return p0
.end method

.method public static final g(Landroid/content/Context;Lx9/g;Lx9/o;)V
    .registers 10

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sdkInstance"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p2}, Lm7/A;->u(Lx9/o;)Z

    invoke-static {p0, p2}, Lm7/A;->z(Landroid/content/Context;Lx9/o;)V

    invoke-static {p2}, Lc9/u;->i(Lx9/o;)LX9/f;

    move-result-object v0

    iget-boolean v0, v0, LX9/f;->b:Z

    if-eqz v0, :cond_22

    sget-object p0, Lh9/h;->a:Lh9/h;

    iget-object p1, p2, Lx9/o;->d:Lw9/g;

    const/4 p2, 0x0

    const/4 v0, 0x3

    invoke-static {p1, p2, p0, v0}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    return-void

    :cond_22
    new-instance v0, LB9/c;

    iget-wide v5, p1, Lx9/g;->d:J

    iget-object v2, p1, Lx9/g;->c:Ljava/lang/String;

    const-wide/16 v3, -0x1

    move-object v1, v0

    invoke-direct/range {v1 .. v6}, LB9/c;-><init>(Ljava/lang/String;JJ)V

    invoke-static {p0, p2}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object p0

    iget-object p0, p0, LK9/b;->b:LL9/a;

    invoke-interface {p0, v0}, LL9/a;->o0(LB9/c;)J

    return-void
.end method
