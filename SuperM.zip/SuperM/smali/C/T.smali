.class public final synthetic LC/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:LC/v;

.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:Ljava/util/concurrent/Executor;

.field public final synthetic d:Landroidx/concurrent/futures/k;

.field public final synthetic e:J


# direct methods
.method public synthetic constructor <init>(LC/v;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/k;J)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/t;->a:LC/v;

    iput-object p2, p0, LC/t;->b:Landroid/content/Context;

    iput-object p3, p0, LC/t;->c:Ljava/util/concurrent/Executor;

    iput-object p4, p0, LC/t;->d:Landroidx/concurrent/futures/k;

    iput-wide p5, p0, LC/t;->e:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 12

    iget-object v1, p0, LC/t;->a:LC/v;

    iget-object v0, p0, LC/t;->b:Landroid/content/Context;

    iget-object v2, p0, LC/t;->c:Ljava/util/concurrent/Executor;

    iget-object v5, p0, LC/t;->d:Landroidx/concurrent/futures/k;

    iget-wide v3, p0, LC/t;->e:J

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, 0x0

    :try_start_e
    invoke-static {v0}, LZ6/f;->b(Landroid/content/Context;)Landroid/app/Application;

    move-result-object v7

    iput-object v7, v1, LC/v;->i:Landroid/content/Context;

    if-nez v7, :cond_26

    invoke-static {v0}, LZ6/f;->a(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v0

    iput-object v0, v1, LC/v;->i:Landroid/content/Context;

    goto :goto_26

    :catch_1d
    move-exception v0

    goto/16 :goto_bf

    :catch_20
    move-exception v0

    goto/16 :goto_bf

    :catch_23
    move-exception v0

    goto/16 :goto_bf

    :cond_26
    :goto_26
    iget-object v0, v1, LC/v;->c:LC/y;

    invoke-virtual {v0}, LC/y;->i()Lu/a;

    move-result-object v0

    if-eqz v0, :cond_b2

    iget-object v0, v1, LC/v;->d:Ljava/util/concurrent/Executor;

    iget-object v7, v1, LC/v;->e:Landroid/os/Handler;

    new-instance v8, LD/b;

    invoke-direct {v8, v0, v7}, LD/b;-><init>(Ljava/util/concurrent/Executor;Landroid/os/Handler;)V

    iget-object v0, v1, LC/v;->c:LC/y;

    invoke-virtual {v0}, LC/y;->c()LC/q;

    move-result-object v0

    iget-object v7, v1, LC/v;->i:Landroid/content/Context;

    new-instance v9, Lf3/e;

    invoke-direct {v9, v7, v8, v0}, Lf3/e;-><init>(Landroid/content/Context;LD/b;LC/q;)V

    iput-object v9, v1, LC/v;->f:Lf3/e;

    iget-object v7, v1, LC/v;->c:LC/y;

    invoke-virtual {v7}, LC/y;->k()Lu/b;

    move-result-object v7

    if-eqz v7, :cond_a5

    iget-object v7, v1, LC/v;->i:Landroid/content/Context;

    iget-object v8, v1, LC/v;->f:Lf3/e;

    iget-object v9, v8, Lf3/e;->c:Ljava/lang/Object;

    check-cast v9, Lx/t;

    new-instance v10, Ljava/util/LinkedHashSet;

    iget-object v8, v8, Lf3/e;->d:Ljava/lang/Object;

    check-cast v8, Ljava/util/ArrayList;

    invoke-direct {v10, v8}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    invoke-static {v7, v9, v10}, Lu/b;->a(Landroid/content/Context;Ljava/lang/Object;Ljava/util/LinkedHashSet;)Lw3/d;

    move-result-object v7

    iput-object v7, v1, LC/v;->g:Lw3/d;

    iget-object v7, v1, LC/v;->c:LC/y;

    invoke-virtual {v7}, LC/y;->l()Lu/a;

    move-result-object v7

    if-eqz v7, :cond_98

    iget-object v7, v1, LC/v;->i:Landroid/content/Context;

    new-instance v8, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;

    invoke-direct {v8, v7}, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;-><init>(Landroid/content/Context;)V

    iput-object v8, v1, LC/v;->h:Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;

    instance-of v7, v2, LC/o;

    if-eqz v7, :cond_82

    move-object v7, v2

    check-cast v7, LC/o;

    iget-object v8, v1, LC/v;->f:Lf3/e;

    invoke-virtual {v7, v8}, LC/o;->a(Lf3/e;)V

    :cond_82
    iget-object v7, v1, LC/v;->a:Lw3/d;

    iget-object v8, v1, LC/v;->f:Lf3/e;

    invoke-virtual {v7, v8}, Lw3/d;->p(Lf3/e;)V

    iget-object v7, v1, LC/v;->i:Landroid/content/Context;

    iget-object v8, v1, LC/v;->a:Lw3/d;

    invoke-static {v7, v8, v0}, Ll7/H0;->f(Landroid/content/Context;Lw3/d;LC/q;)V

    invoke-virtual {v1}, LC/v;->a()V

    invoke-virtual {v5, v6}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    goto/16 :goto_12f

    :cond_98
    new-instance v0, LC/m0;

    new-instance v7, Ljava/lang/IllegalArgumentException;

    const-string v8, "Invalid app configuration provided. Missing UseCaseConfigFactory."

    invoke-direct {v7, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v7}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :cond_a5
    new-instance v0, LC/m0;

    new-instance v7, Ljava/lang/IllegalArgumentException;

    const-string v8, "Invalid app configuration provided. Missing CameraDeviceSurfaceManager."

    invoke-direct {v7, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v7}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :cond_b2
    new-instance v0, LC/m0;

    new-instance v7, Ljava/lang/IllegalArgumentException;

    const-string v8, "Invalid app configuration provided. Missing CameraFactory."

    invoke-direct {v7, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v7}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v0
    :try_end_bf
    .catch LD/v; {:try_start_e .. :try_end_bf} :catch_23
    .catch LC/m0; {:try_start_e .. :try_end_bf} :catch_20
    .catch Ljava/lang/RuntimeException; {:try_start_e .. :try_end_bf} :catch_1d

    :goto_bf
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    sub-long/2addr v7, v3

    const-wide/16 v9, 0x9c4

    cmp-long v7, v7, v9

    if-gez v7, :cond_109

    const-string v6, "CameraX"

    const-string v7, "Retry init. Start time "

    const-string v8, " current time "

    invoke-static {v3, v4, v7, v8}, LA8/v;->n(JLjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x5

    invoke-static {v8, v6}, LHe/b;->h(ILjava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_e9

    invoke-static {v6, v7, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_e9
    iget-object v6, v1, LC/v;->e:Landroid/os/Handler;

    new-instance v7, LC/u;

    move-object v0, v7

    invoke-direct/range {v0 .. v5}, LC/u;-><init>(LC/v;Ljava/util/concurrent/Executor;JLandroidx/concurrent/futures/k;)V

    const-string v0, "retry_token"

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1c

    if-lt v1, v2, :cond_fd

    invoke-static {v6, v7}, Lm0/h;->c(Landroid/os/Handler;LC/u;)Z

    goto :goto_12f

    :cond_fd
    invoke-static {v6, v7}, Landroid/os/Message;->obtain(Landroid/os/Handler;Ljava/lang/Runnable;)Landroid/os/Message;

    move-result-object v1

    iput-object v0, v1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const-wide/16 v2, 0x1f4

    invoke-virtual {v6, v1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto :goto_12f

    :cond_109
    iget-object v2, v1, LC/v;->b:Ljava/lang/Object;

    monitor-enter v2

    const/4 v3, 0x3

    :try_start_10d
    iput v3, v1, LC/v;->k:I

    monitor-exit v2
    :try_end_110
    .catchall {:try_start_10d .. :try_end_110} :catchall_130

    instance-of v1, v0, LD/v;

    if-eqz v1, :cond_11f

    const-string v0, "CameraX"

    const-string v1, "The device might underreport the amount of the cameras. Finish the initialize task since we are already reaching the maximum number of retries."

    invoke-static {v0, v1}, LHe/b;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    goto :goto_12f

    :cond_11f
    instance-of v1, v0, LC/m0;

    if-eqz v1, :cond_127

    invoke-virtual {v5, v0}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Throwable;)Z

    goto :goto_12f

    :cond_127
    new-instance v1, LC/m0;

    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    invoke-virtual {v5, v1}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Throwable;)Z

    :goto_12f
    return-void

    :catchall_130
    move-exception v0

    :try_start_131
    monitor-exit v2
    :try_end_132
    .catchall {:try_start_131 .. :try_end_132} :catchall_130

    throw v0
.end method
