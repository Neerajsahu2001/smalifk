.class public final synthetic LC/w0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq/a;
.implements LD1/z;
.implements Li8/f;
.implements Lv7/d;
.implements Lp6/e;
.implements Lcom/horcrux/svg/d;
.implements Landroidx/core/view/z;
.implements LZ0/m;
.implements Ljavax/inject/Provider;
.implements LZ0/e;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, LC/w0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public accept(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Lt1/Z;

    iget-object p1, p1, Lt1/Z;->b:Lk1/n;

    invoke-interface {p1}, Lk1/n;->a()V

    return-void
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iget v0, p0, LC/w0;->a:I

    packed-switch v0, :pswitch_data_18

    :pswitch_5
    check-cast p1, Lcom/google/firebase/messaging/reporting/MessagingClientEventExtension;

    invoke-virtual {p1}, Lcom/google/firebase/messaging/reporting/MessagingClientEventExtension;->toByteArray()[B

    move-result-object p1

    return-object p1

    :pswitch_c
    new-instance v0, Lg1/q;

    check-cast p1, LZ0/y;

    invoke-direct {v0, p1}, Lg1/q;-><init>(LZ0/y;)V

    return-object v0

    :pswitch_14
    check-cast p1, Ljava/lang/Void;

    const/4 p1, 0x0

    return-object p1

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_14
        :pswitch_5
        :pswitch_c
    .end packed-switch
.end method

.method public d()[LD1/w;
    .registers 4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget v2, p0, LC/w0;->a:I

    packed-switch v2, :pswitch_data_1c

    new-instance v2, Lj2/c;

    invoke-direct {v2}, Lj2/c;-><init>()V

    new-array v1, v1, [LD1/w;

    aput-object v2, v1, v0

    return-object v1

    :pswitch_11
    new-instance v2, LY1/d;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    new-array v1, v1, [LD1/w;

    aput-object v2, v1, v0

    return-object v1

    nop

    :pswitch_data_1c
    .packed-switch 0x1
        :pswitch_11
    .end packed-switch
.end method

.method public get()Ljava/lang/Object;
    .registers 2

    iget v0, p0, LC/w0;->a:I

    packed-switch v0, :pswitch_data_12

    new-instance v0, Lcom/facebook/react/views/text/ReactVirtualTextViewManager;

    invoke-direct {v0}, Lcom/facebook/react/views/text/ReactVirtualTextViewManager;-><init>()V

    return-object v0

    :pswitch_b
    new-instance v0, Lcom/facebook/react/views/switchview/ReactSwitchManager;

    invoke-direct {v0}, Lcom/facebook/react/views/switchview/ReactSwitchManager;-><init>()V

    return-object v0

    nop

    :pswitch_data_12
    .packed-switch 0x9
        :pswitch_b
    .end packed-switch
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 3

    iget v0, p0, LC/w0;->a:I

    check-cast p1, Lg1/b;

    packed-switch v0, :pswitch_data_10

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_b
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    nop

    :pswitch_data_10
    .packed-switch 0x7
        :pswitch_b
    .end packed-switch
.end method

.method public onComplete(Lv7/i;)V
    .registers 4

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    if-nez v0, :cond_11

    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    const-string v0, "NotifeeAlarmManager"

    const-string v1, "Failed to display notification"

    invoke-static {v0, v1, p1}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_11
    return-void
.end method

.method public x(Landroid/view/View;Landroidx/core/view/Q0;)Landroidx/core/view/Q0;
    .registers 7

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1, p2}, Landroidx/core/view/g0;->i(Landroid/view/View;Landroidx/core/view/Q0;)Landroidx/core/view/Q0;

    move-result-object p1

    const-string p2, "onApplyWindowInsets(...)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v0, 0x0

    const/16 v1, 0x1e

    if-lt p2, v1, :cond_4a

    iget-object p1, p1, Landroidx/core/view/Q0;->a:Landroidx/core/view/O0;

    const/4 v2, 0x1

    invoke-virtual {p1, v2}, Landroidx/core/view/O0;->f(I)Lh0/e;

    move-result-object p1

    const-string v3, "getInsets(...)"

    invoke-static {p1, v3}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-lt p2, v1, :cond_29

    new-instance p2, Landroidx/core/view/H0;

    invoke-direct {p2}, Landroidx/core/view/H0;-><init>()V

    goto :goto_38

    :cond_29
    const/16 v1, 0x1d

    if-lt p2, v1, :cond_33

    new-instance p2, Landroidx/core/view/G0;

    invoke-direct {p2}, Landroidx/core/view/G0;-><init>()V

    goto :goto_38

    :cond_33
    new-instance p2, Landroidx/core/view/F0;

    invoke-direct {p2}, Landroidx/core/view/F0;-><init>()V

    :goto_38
    iget v1, p1, Lh0/e;->c:I

    iget v3, p1, Lh0/e;->d:I

    iget p1, p1, Lh0/e;->a:I

    invoke-static {p1, v0, v1, v3}, Lh0/e;->b(IIII)Lh0/e;

    move-result-object p1

    invoke-virtual {p2, v2, p1}, Landroidx/core/view/I0;->c(ILh0/e;)V

    invoke-virtual {p2}, Landroidx/core/view/I0;->b()Landroidx/core/view/Q0;

    move-result-object p1

    goto :goto_5a

    :cond_4a
    invoke-virtual {p1}, Landroidx/core/view/Q0;->b()I

    move-result p2

    invoke-virtual {p1}, Landroidx/core/view/Q0;->c()I

    move-result v1

    invoke-virtual {p1}, Landroidx/core/view/Q0;->a()I

    move-result v2

    invoke-virtual {p1, p2, v0, v1, v2}, Landroidx/core/view/Q0;->f(IIII)Landroidx/core/view/Q0;

    move-result-object p1

    :goto_5a
    return-object p1
.end method
