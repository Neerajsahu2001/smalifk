.class public final LC/t0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LD/e0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, LC/s0;

    invoke-direct {v0}, LC/s0;-><init>()V

    sget-object v1, LD/t0;->r0:LD/c;

    const/4 v2, 0x2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget-object v0, v0, LC/s0;->a:LD/Z;

    invoke-virtual {v0, v1, v2}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object v1, LD/P;->g0:LD/c;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    new-instance v1, LD/e0;

    invoke-static {v0}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v0

    invoke-direct {v1, v0}, LD/e0;-><init>(LD/c0;)V

    sput-object v1, LC/t0;->a:LD/e0;

    return-void
.end method
