.class public abstract LC/g0;
.super Ljava/lang/Exception;
.source "SourceFile"
