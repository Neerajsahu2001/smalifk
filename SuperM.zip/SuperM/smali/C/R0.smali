.class public final synthetic LC/r0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/l0;


# instance fields
.field public final synthetic a:LC/v0;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:LD/e0;

.field public final synthetic d:Landroid/util/Size;


# direct methods
.method public synthetic constructor <init>(LC/v0;Ljava/lang/String;LD/e0;Landroid/util/Size;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/r0;->a:LC/v0;

    iput-object p2, p0, LC/r0;->b:Ljava/lang/String;

    iput-object p3, p0, LC/r0;->c:LD/e0;

    iput-object p4, p0, LC/r0;->d:Landroid/util/Size;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 5

    iget-object v0, p0, LC/r0;->a:LC/v0;

    iget-object v1, p0, LC/r0;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, LC/R0;->g(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1c

    iget-object v2, p0, LC/r0;->c:LD/e0;

    iget-object v3, p0, LC/r0;->d:Landroid/util/Size;

    invoke-virtual {v0, v1, v2, v3}, LC/v0;->w(Ljava/lang/String;LD/e0;Landroid/util/Size;)LD/k0;

    move-result-object v1

    invoke-virtual {v1}, LD/k0;->c()LD/n0;

    move-result-object v1

    invoke-virtual {v0, v1}, LC/R0;->v(LD/n0;)V

    invoke-virtual {v0}, LC/R0;->i()V

    :cond_1c
    return-void
.end method
