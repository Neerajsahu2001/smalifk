.class public interface abstract LC/u0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract o(LC/P0;)V
.end method
