.class public final LC/e0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC/G;


# instance fields
.field public final a:Ljava/util/ArrayDeque;

.field public b:I

.field public final c:I

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lu/a;Lu/a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, LC/e0;->a:Ljava/util/ArrayDeque;

    const/4 p1, 0x0

    iput p1, p0, LC/e0;->b:I

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/e0;->d:Ljava/lang/Object;

    const/4 p1, 0x2

    iput p1, p0, LC/e0;->c:I

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/RuntimeException;)V
    .registers 5

    iget-object v0, p0, LC/e0;->d:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, LC/e0;->a:Ljava/util/ArrayDeque;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v2, p0, LC/e0;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    monitor-exit v0
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_32

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_1b

    return-void

    :cond_1b
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Le/b;->p(Ljava/lang/Object;)V

    instance-of v0, p1, LC/k;

    if-nez v0, :cond_2d

    instance-of v0, p1, LC/g0;

    if-eqz v0, :cond_2d

    move-object v0, p1

    check-cast v0, LC/g0;

    :cond_2d
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    const/4 p1, 0x0

    throw p1

    :catchall_32
    move-exception p1

    :try_start_33
    monitor-exit v0
    :try_end_34
    .catchall {:try_start_33 .. :try_end_34} :catchall_32

    throw p1
.end method

.method public final b()V
    .registers 4

    iget-object v0, p0, LC/e0;->d:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget v1, p0, LC/e0;->b:I

    iget v2, p0, LC/e0;->c:I

    if-lt v1, v2, :cond_14

    const-string v1, "ImageCapture"

    const-string v2, "Too many acquire images. Close image to be able to process next."

    invoke-static {v1, v2}, LHe/b;->i(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v0

    return-void

    :catchall_12
    move-exception v1

    goto :goto_1f

    :cond_14
    iget-object v1, p0, LC/e0;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Le/b;->p(Ljava/lang/Object;)V

    monitor-exit v0

    return-void

    :goto_1f
    monitor-exit v0
    :try_end_20
    .catchall {:try_start_3 .. :try_end_20} :catchall_12

    throw v1
.end method

.method public final e(LC/k0;)V
    .registers 5

    iget-object p1, p0, LC/e0;->d:Ljava/lang/Object;

    monitor-enter p1

    :try_start_3
    iget v0, p0, LC/e0;->b:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, LC/e0;->b:I

    invoke-static {}, Lcom/bumptech/glide/c;->e()LF/f;

    move-result-object v0

    new-instance v1, LC/d0;

    const/4 v2, 0x0

    invoke-direct {v1, v2, p0}, LC/d0;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, v1}, LF/f;->execute(Ljava/lang/Runnable;)V

    monitor-exit p1

    return-void

    :catchall_18
    move-exception v0

    monitor-exit p1
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_18

    throw v0
.end method
