.class public final LC/s0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/s0;
.implements LD/O;


# instance fields
.field public final a:LD/Z;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object v0

    invoke-direct {p0, v0}, LC/s0;-><init>(LD/Z;)V

    return-void
.end method

.method public constructor <init>(LD/Z;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/s0;->a:LD/Z;

    sget-object v0, LH/j;->y0:LD/c;

    const/4 v1, 0x0

    :try_start_8
    invoke-virtual {p1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object p1
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_e

    :catch_d
    move-object p1, v1

    :goto_e
    check-cast p1, Ljava/lang/Class;

    const-class v0, LC/v0;

    if-eqz p1, :cond_37

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1b

    goto :goto_37

    :cond_1b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid target class configuration for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_37
    :goto_37
    sget-object p1, LH/j;->y0:LD/c;

    iget-object v2, p0, LC/s0;->a:LD/Z;

    invoke-virtual {v2, p1, v0}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object p1, LH/j;->x0:LD/c;

    :try_start_40
    invoke-virtual {v2, p1}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v1
    :try_end_44
    .catch Ljava/lang/IllegalArgumentException; {:try_start_40 .. :try_end_44} :catch_44

    :catch_44
    if-nez v1, :cond_69

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "-"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object v0, LH/j;->x0:LD/c;

    iget-object v1, p0, LC/s0;->a:LD/Z;

    invoke-virtual {v1, v0, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    :cond_69
    return-void
.end method


# virtual methods
.method public final a(Landroid/util/Size;)Ljava/lang/Object;
    .registers 4

    sget-object v0, LD/P;->j0:LD/c;

    iget-object v1, p0, LC/s0;->a:LD/Z;

    invoke-virtual {v1, v0, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    return-object p0
.end method

.method public final b()LD/Y;
    .registers 2

    iget-object v0, p0, LC/s0;->a:LD/Z;

    return-object v0
.end method

.method public final bridge synthetic c(I)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0, p1}, LC/s0;->f(I)V

    return-object p0
.end method

.method public final d()LD/t0;
    .registers 3

    new-instance v0, LD/e0;

    iget-object v1, p0, LC/s0;->a:LD/Z;

    invoke-static {v1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v1

    invoke-direct {v0, v1}, LD/e0;-><init>(LD/c0;)V

    return-object v0
.end method

.method public final e()LC/v0;
    .registers 4

    sget-object v0, LD/P;->g0:LD/c;

    iget-object v1, p0, LC/s0;->a:LD/Z;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    :try_start_8
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_e

    :catch_d
    move-object v0, v2

    :goto_e
    if-eqz v0, :cond_21

    sget-object v0, LD/P;->j0:LD/c;

    :try_start_12
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v2
    :try_end_16
    .catch Ljava/lang/IllegalArgumentException; {:try_start_12 .. :try_end_16} :catch_16

    :catch_16
    if-nez v2, :cond_19

    goto :goto_21

    :cond_19
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_21
    :goto_21
    new-instance v0, LC/v0;

    new-instance v2, LD/e0;

    invoke-static {v1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v1

    invoke-direct {v2, v1}, LD/e0;-><init>(LD/c0;)V

    invoke-direct {v0, v2}, LC/R0;-><init>(LD/t0;)V

    sget-object v1, LC/v0;->r:LF/f;

    iput-object v1, v0, LC/v0;->m:Ljava/util/concurrent/Executor;

    return-object v0
.end method

.method public final f(I)V
    .registers 5

    sget-object v0, LD/P;->h0:LD/c;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, LC/s0;->a:LD/Z;

    invoke-virtual {v2, v0, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object v0, LD/P;->i0:LD/c;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v2, v0, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    return-void
.end method
