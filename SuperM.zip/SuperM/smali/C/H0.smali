.class public interface abstract LC/h0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LE/j;)V
.end method

.method public abstract b()LD/q0;
.end method

.method public abstract c()J
.end method

.method public abstract d()I
.end method
