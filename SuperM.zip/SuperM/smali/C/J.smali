.class public interface abstract LC/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Lw/l;
.end method

.method public abstract b()Lw/u;
.end method
