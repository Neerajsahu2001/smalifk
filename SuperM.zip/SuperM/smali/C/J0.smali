.class public final synthetic LC/j0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC/G;


# instance fields
.field public final synthetic a:LC/k0;

.field public final synthetic b:LC/k0;


# direct methods
.method public synthetic constructor <init>(LC/k0;LC/k0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/j0;->a:LC/k0;

    iput-object p2, p0, LC/j0;->b:LC/k0;

    return-void
.end method


# virtual methods
.method public final e(LC/k0;)V
    .registers 2

    sget p1, Landroidx/camera/core/ImageProcessingUtil;->a:I

    iget-object p1, p0, LC/j0;->a:LC/k0;

    if-eqz p1, :cond_d

    iget-object p1, p0, LC/j0;->b:LC/k0;

    if-eqz p1, :cond_d

    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    :cond_d
    return-void
.end method
