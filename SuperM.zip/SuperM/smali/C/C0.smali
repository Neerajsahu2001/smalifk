.class public final LC/c0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LD/L;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, LC/b0;

    invoke-direct {v0}, LC/b0;-><init>()V

    sget-object v1, LD/t0;->r0:LD/c;

    const/4 v2, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget-object v0, v0, LC/b0;->a:LD/Z;

    invoke-virtual {v0, v1, v2}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object v1, LD/P;->g0:LD/c;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    new-instance v1, LD/L;

    invoke-static {v0}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v0

    invoke-direct {v1, v0}, LD/L;-><init>(LD/c0;)V

    sput-object v1, LC/c0;->a:LD/L;

    return-void
.end method
