.class public final LC/y0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/S;
.implements Landroidx/core/view/z;
.implements LJd/d;
.implements LK0/l;
.implements Lorg/chromium/support_lib_boundary/WebMessageListenerBoundaryInterface;
.implements LN6/j;
.implements LT8/a;
.implements Landroidx/core/view/d;
.implements Lq/a;
.implements Lcom/google/android/gms/internal/measurement/C3;
.implements Lee/h;
.implements Ly1/B;
.implements Lokhttp3/Callback;
.implements LG4/a;
.implements Lr7/U1;
.implements LG/d;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    iput p1, p0, LC/y0;->a:I

    sparse-switch p1, :sswitch_data_36

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    return-void

    :sswitch_10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Lv7/v;

    invoke-direct {p1}, Lv7/v;-><init>()V

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    return-void

    :sswitch_1b
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    return-void

    :sswitch_26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    sget-object v0, La9/a;->a:Ljava/util/Set;

    invoke-interface {p1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    return-void

    :sswitch_data_36
    .sparse-switch
        0xa -> :sswitch_26
        0x18 -> :sswitch_1b
        0x1c -> :sswitch_10
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC/y0;->a:I

    iput-object p2, p0, LC/y0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    iput p1, p0, LC/y0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LXc/J;)V
    .registers 3

    const/4 v0, 0x3

    iput v0, p0, LC/y0;->a:I

    const-string v0, "packageFragmentProvider"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/ClipData;I)V
    .registers 4

    const/16 v0, 0xb

    iput v0, p0, LC/y0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1, p2}, LZ0/r;->o(Landroid/content/ClipData;I)Landroid/view/ContentInfo$Builder;

    move-result-object p1

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x4

    iput v0, p0, LC/y0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/internal/measurement/c3;)V
    .registers 3

    const/16 v0, 0xd

    iput v0, p0, LC/y0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lcom/google/android/gms/internal/measurement/n3;->a:Ljava/nio/charset/Charset;

    if-eqz p1, :cond_10

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    iput-object p0, p1, Lcom/google/android/gms/internal/measurement/c3;->e:LC/y0;

    return-void

    :cond_10
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "output"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Ljava/util/List;)V
    .registers 3

    const/16 v0, 0x11

    iput v0, p0, LC/y0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_f

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    :cond_f
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lorg/json/JSONObject;)V
    .registers 4

    const/16 v0, 0x14

    iput v0, p0, LC/y0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_c
    new-instance v1, Lorg/json/JSONObject;

    invoke-static {p1}, Lcom/newrelic/agent/android/instrumentation/JSONObjectInstrumentation;->toString(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_15
    .catch Lorg/json/JSONException; {:try_start_c .. :try_end_15} :catch_17

    move-object v0, v1

    goto :goto_1f

    :catch_17
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ll7/R5;->b(Ljava/lang/String;)V

    :goto_1f
    iput-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>([BI)V
    .registers 4

    const/16 v0, 0x1a

    iput v0, p0, LC/y0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p1

    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object p1

    invoke-virtual {p1, p2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    iput-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public A(FI)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    invoke-virtual {v0, p2, p1}, Lcom/google/android/gms/internal/measurement/c3;->g(II)V

    return-void
.end method

.method public B(I)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    const/4 v1, 0x4

    invoke-virtual {v0, p1, v1}, Lcom/google/android/gms/internal/measurement/c3;->y(II)V

    return-void
.end method

.method public C(ID)V
    .registers 5

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p2, p3}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide p2

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/internal/measurement/c3;->h(IJ)V

    return-void
.end method

.method public D(II)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/measurement/c3;->s(II)V

    return-void
.end method

.method public E(IJ)V
    .registers 5

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/internal/measurement/c3;->h(IJ)V

    return-void
.end method

.method public F(ILcom/google/android/gms/internal/measurement/b3;)V
    .registers 5

    const/4 v0, 0x2

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v1, p1, v0}, Lcom/google/android/gms/internal/measurement/c3;->y(II)V

    invoke-virtual {v1, p2}, Lcom/google/android/gms/internal/measurement/c3;->j(Lcom/google/android/gms/internal/measurement/b3;)V

    return-void
.end method

.method public G(ILjava/lang/Object;Lcom/google/android/gms/internal/measurement/M3;)V
    .registers 6

    check-cast p2, Lcom/google/android/gms/internal/measurement/T2;

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    const/4 v1, 0x3

    invoke-virtual {v0, p1, v1}, Lcom/google/android/gms/internal/measurement/c3;->y(II)V

    iget-object v1, v0, Lcom/google/android/gms/internal/measurement/c3;->e:LC/y0;

    invoke-interface {p3, p2, v1}, Lcom/google/android/gms/internal/measurement/M3;->c(Ljava/lang/Object;LC/y0;)V

    const/4 p2, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/measurement/c3;->y(II)V

    return-void
.end method

.method public H(IZ)V
    .registers 5

    const/4 v0, 0x0

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v1, p1, v0}, Lcom/google/android/gms/internal/measurement/c3;->y(II)V

    int-to-byte p1, p2

    invoke-virtual {v1, p1}, Lcom/google/android/gms/internal/measurement/c3;->e(B)V

    return-void
.end method

.method public I(I)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    const/4 v1, 0x3

    invoke-virtual {v0, p1, v1}, Lcom/google/android/gms/internal/measurement/c3;->y(II)V

    return-void
.end method

.method public J(II)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/measurement/c3;->g(II)V

    return-void
.end method

.method public K(IJ)V
    .registers 5

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/internal/measurement/c3;->t(IJ)V

    return-void
.end method

.method public L(ILjava/lang/Object;Lcom/google/android/gms/internal/measurement/M3;)V
    .registers 6

    check-cast p2, Lcom/google/android/gms/internal/measurement/T2;

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    const/4 v1, 0x2

    invoke-virtual {v0, p1, v1}, Lcom/google/android/gms/internal/measurement/c3;->y(II)V

    invoke-virtual {p2, p3}, Lcom/google/android/gms/internal/measurement/T2;->a(Lcom/google/android/gms/internal/measurement/M3;)I

    move-result p1

    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/measurement/c3;->x(I)V

    iget-object p1, v0, Lcom/google/android/gms/internal/measurement/c3;->e:LC/y0;

    invoke-interface {p3, p2, p1}, Lcom/google/android/gms/internal/measurement/M3;->c(Ljava/lang/Object;LC/y0;)V

    return-void
.end method

.method public M(II)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/measurement/c3;->s(II)V

    return-void
.end method

.method public N(IJ)V
    .registers 5

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/internal/measurement/c3;->h(IJ)V

    return-void
.end method

.method public O(II)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/measurement/c3;->g(II)V

    return-void
.end method

.method public P(IJ)V
    .registers 7

    const/4 v0, 0x1

    shl-long v0, p2, v0

    const/16 v2, 0x3f

    shr-long/2addr p2, v2

    xor-long/2addr p2, v0

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/internal/measurement/c3;->t(IJ)V

    return-void
.end method

.method public Q(II)V
    .registers 4

    shl-int/lit8 v0, p2, 0x1

    shr-int/lit8 p2, p2, 0x1f

    xor-int/2addr p2, v0

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/measurement/c3;->B(II)V

    return-void
.end method

.method public R(IJ)V
    .registers 5

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/internal/measurement/c3;->t(IJ)V

    return-void
.end method

.method public S(II)V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/c3;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/measurement/c3;->B(II)V

    return-void
.end method

.method public a()Landroidx/core/view/g;
    .registers 4

    new-instance v0, Landroidx/core/view/g;

    new-instance v1, LA/d;

    iget-object v2, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v2, Landroid/view/ContentInfo$Builder;

    invoke-static {v2}, LHa/i;->n(Landroid/view/ContentInfo$Builder;)Landroid/view/ContentInfo;

    move-result-object v2

    invoke-direct {v1, v2}, LA/d;-><init>(Landroid/view/ContentInfo;)V

    invoke-direct {v0, v1}, Landroidx/core/view/g;-><init>(Landroidx/core/view/e;)V

    return-object v0
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 6

    check-cast p1, LQ6/d;

    check-cast p2, Lv7/j;

    invoke-virtual {p1}, LO6/e;->t()Landroid/os/IInterface;

    move-result-object p1

    check-cast p1, LQ6/a;

    invoke-virtual {p1}, Lcom/google/android/gms/internal/measurement/M;->c()Landroid/os/Parcel;

    move-result-object v0

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/common/internal/TelemetryData;

    invoke-static {v0, v1}, Lf7/a;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    :try_start_15
    iget-object p1, p1, Lcom/google/android/gms/internal/measurement/M;->b:Landroid/os/IBinder;

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p1, v1, v0, v2, v1}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_1c
    .catchall {:try_start_15 .. :try_end_1c} :catchall_23

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {p2, v2}, Lv7/j;->b(Ljava/lang/Object;)V

    return-void

    :catchall_23
    move-exception p1

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p1
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Ljava/lang/Void;

    iget-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast p1, Lg/i;

    return-object p1
.end method

.method public b()V
    .registers 3

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Li1/e;

    iget-object v1, v0, Li1/e;->B:Ly1/A;

    invoke-virtual {v1}, Ly1/A;->b()V

    iget-object v0, v0, Li1/e;->D:Lb1/a;

    if-nez v0, :cond_e

    return-void

    :cond_e
    throw v0
.end method

.method public c(Landroid/os/Bundle;)V
    .registers 3

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo$Builder;

    invoke-static {v0, p1}, LO6/H;->y(Landroid/view/ContentInfo$Builder;Landroid/os/Bundle;)V

    return-void
.end method

.method public collect(Lee/i;Lyc/d;)Ljava/lang/Object;
    .registers 9

    instance-of v0, p2, Lee/a;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lee/a;

    iget v1, v0, Lee/a;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lee/a;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lee/a;

    invoke-direct {v0, p0, p2}, Lee/a;-><init>(LC/y0;Lyc/d;)V

    :goto_18
    iget-object p2, v0, Lee/a;->b:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, Lee/a;->d:I

    sget-object v3, Luc/z;->a:Luc/z;

    const/4 v4, 0x1

    if-eqz v2, :cond_35

    if-ne v2, v4, :cond_2d

    iget-object p1, v0, Lee/a;->a:Lfe/v;

    :try_start_27
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_2a
    .catchall {:try_start_27 .. :try_end_2a} :catchall_2b

    goto :goto_55

    :catchall_2b
    move-exception p2

    goto :goto_5f

    :cond_2d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_35
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V

    new-instance p2, Lfe/v;

    invoke-interface {v0}, Lyc/d;->getContext()Lyc/j;

    move-result-object v2

    invoke-direct {p2, p1, v2}, Lfe/v;-><init>(Lee/i;Lyc/j;)V

    :try_start_41
    iput-object p2, v0, Lee/a;->a:Lfe/v;

    iput v4, v0, Lee/a;->d:I

    iget-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast p1, LHc/c;

    invoke-interface {p1, p2, v0}, LHc/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_4d
    .catchall {:try_start_41 .. :try_end_4d} :catchall_5d

    if-ne p1, v1, :cond_50

    goto :goto_51

    :cond_50
    move-object p1, v3

    :goto_51
    if-ne p1, v1, :cond_54

    return-object v1

    :cond_54
    move-object p1, p2

    :goto_55
    invoke-virtual {p1}, LAc/c;->releaseIntercepted()V

    return-object v3

    :goto_59
    move-object v5, p2

    move-object p2, p1

    move-object p1, v5

    goto :goto_5f

    :catchall_5d
    move-exception p1

    goto :goto_59

    :goto_5f
    invoke-virtual {p1}, LAc/c;->releaseIntercepted()V

    throw p2
.end method

.method public create()Ljava/lang/Object;
    .registers 4

    new-instance v0, Ll4/j;

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, Lj8/W;

    iget-object v2, v1, Lj8/W;->b:Ljava/lang/Object;

    check-cast v2, Ll4/r;

    iget-object v1, v1, Lj8/W;->c:Ljava/lang/Object;

    check-cast v1, LW2/D;

    invoke-direct {v0, v2, v1}, Ll4/j;-><init>(Ll4/r;LW2/D;)V

    return-object v0
.end method

.method public d(Ljava/lang/Class;)Lcom/google/android/gms/internal/measurement/L3;
    .registers 7

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, [Lcom/google/android/gms/internal/measurement/C3;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_18

    aget-object v3, v0, v2

    invoke-interface {v3, p1}, Lcom/google/android/gms/internal/measurement/C3;->p(Ljava/lang/Class;)Z

    move-result v4

    if-eqz v4, :cond_15

    invoke-interface {v3, p1}, Lcom/google/android/gms/internal/measurement/C3;->d(Ljava/lang/Class;)Lcom/google/android/gms/internal/measurement/L3;

    move-result-object p1

    return-object p1

    :cond_15
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_18
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const-string v1, "No factory is available for message type: "

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public e()Landroid/graphics/Rect;
    .registers 9

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;

    iget-object v0, v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;->e:[Landroid/graphics/Point;

    if-eqz v0, :cond_37

    const/4 v1, 0x0

    const/high16 v2, -0x80000000

    const v3, 0x7fffffff

    move v4, v3

    move v5, v4

    move v3, v2

    :goto_11
    array-length v6, v0

    if-ge v1, v6, :cond_31

    aget-object v6, v0, v1

    iget v7, v6, Landroid/graphics/Point;->x:I

    invoke-static {v4, v7}, Ljava/lang/Math;->min(II)I

    move-result v4

    iget v7, v6, Landroid/graphics/Point;->x:I

    invoke-static {v2, v7}, Ljava/lang/Math;->max(II)I

    move-result v2

    iget v7, v6, Landroid/graphics/Point;->y:I

    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    move-result v5

    iget v6, v6, Landroid/graphics/Point;->y:I

    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    move-result v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_11

    :cond_31
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0, v4, v5, v2, v3}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object v0

    :cond_37
    const/4 v0, 0x0

    return-object v0
.end method

.method public f(Landroid/net/Uri;)V
    .registers 3

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo$Builder;

    invoke-static {v0, p1}, LHa/i;->x(Landroid/view/ContentInfo$Builder;Landroid/net/Uri;)V

    return-void
.end method

.method public getSupportedFeatures()[Ljava/lang/String;
    .registers 2

    const-string v0, "WEB_MESSAGE_LISTENER"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public h()I
    .registers 2

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;

    iget v0, v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;->f:I

    return v0
.end method

.method public j()I
    .registers 2

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;

    iget v0, v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;->a:I

    return v0
.end method

.method public k(LD/T;)V
    .registers 7

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, LC/B0;

    const-string v1, "ImageProxyBundle does not contain this id: "

    iget-object v2, v0, LC/B0;->a:Ljava/lang/Object;

    monitor-enter v2

    :try_start_9
    iget-boolean v3, v0, LC/B0;->e:Z

    if-eqz v3, :cond_11

    monitor-exit v2
    :try_end_e
    .catchall {:try_start_9 .. :try_end_e} :catchall_f

    goto :goto_57

    :catchall_f
    move-exception p1

    goto :goto_59

    :cond_11
    :try_start_11
    invoke-interface {p1}, LD/T;->h()LC/k0;

    move-result-object p1
    :try_end_15
    .catch Ljava/lang/IllegalStateException; {:try_start_11 .. :try_end_15} :catch_4e
    .catchall {:try_start_11 .. :try_end_15} :catchall_4c

    if-eqz p1, :cond_56

    :try_start_17
    invoke-interface {p1}, LC/k0;->Q()LC/h0;

    move-result-object v3

    invoke-interface {v3}, LC/h0;->b()LD/q0;

    move-result-object v3

    iget-object v4, v0, LC/B0;->p:Ljava/lang/String;

    iget-object v3, v3, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    iget-object v4, v0, LC/B0;->r:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_46

    const-string v0, "ProcessingImageReader"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, LHe/b;->i(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    goto :goto_56

    :cond_46
    iget-object v0, v0, LC/B0;->q:LC/I0;

    invoke-virtual {v0, p1}, LC/I0;->a(LC/k0;)V
    :try_end_4b
    .catchall {:try_start_17 .. :try_end_4b} :catchall_f

    goto :goto_56

    :catchall_4c
    move-exception p1

    goto :goto_58

    :catch_4e
    move-exception p1

    :try_start_4f
    const-string v0, "ProcessingImageReader"

    const-string v1, "Failed to acquire latest image."

    invoke-static {v0, v1, p1}, LHe/b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_56
    .catchall {:try_start_4f .. :try_end_56} :catchall_4c

    :cond_56
    :goto_56
    :try_start_56
    monitor-exit v2

    :goto_57
    return-void

    :goto_58
    throw p1

    :goto_59
    monitor-exit v2
    :try_end_5a
    .catchall {:try_start_56 .. :try_end_5a} :catchall_f

    throw p1
.end method

.method public m(I)V
    .registers 3

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo$Builder;

    invoke-static {v0, p1}, LO6/H;->x(Landroid/view/ContentInfo$Builder;I)V

    return-void
.end method

.method public n()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;

    iget-object v0, v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;->b:Ljava/lang/String;

    return-object v0
.end method

.method public o(Ll7/P0;)V
    .registers 11

    new-instance v7, LK0/a;

    const-string v0, "EmojiCompatInitializer"

    invoke-direct {v7, v0}, LK0/a;-><init>(Ljava/lang/String;)V

    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, Ljava/util/concurrent/LinkedBlockingDeque;

    invoke-direct {v6}, Ljava/util/concurrent/LinkedBlockingDeque;-><init>()V

    const-wide/16 v3, 0xf

    const/4 v1, 0x0

    const/4 v2, 0x1

    move-object v0, v8

    invoke-direct/range {v0 .. v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    const/4 v0, 0x1

    invoke-virtual {v8, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    new-instance v0, LK0/p;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v8, v1}, LK0/p;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v8, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    .registers 6

    iget-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast p1, Lj3/x;

    iget-object v0, p1, Lj3/x;->b:Ljava/lang/String;

    invoke-static {v0}, Lj3/x;->a(Ljava/lang/String;)V

    iget-object v0, p1, Lj3/x;->o:Lcom/facebook/react/bridge/WritableMap;

    if-nez v0, :cond_13

    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v0

    iput-object v0, p1, Lj3/x;->o:Lcom/facebook/react/bridge/WritableMap;

    :cond_13
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-class v1, Ljava/net/SocketTimeoutException;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_32

    iget-object p2, p1, Lj3/x;->o:Lcom/facebook/react/bridge/WritableMap;

    const-string v0, "timeout"

    const/4 v2, 0x1

    invoke-interface {p2, v0, v2}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    const-string p2, "The request timed out."

    filled-new-array {p2, v1, v1}, [Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Lj3/x;->e([Ljava/lang/Object;)V

    goto :goto_3d

    :cond_32
    invoke-virtual {p2}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object p2

    filled-new-array {p2, v1, v1}, [Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Lj3/x;->e([Ljava/lang/Object;)V

    :goto_3d
    invoke-virtual {p1}, Lj3/x;->f()V

    return-void
.end method

.method public onPostMessage(Landroid/webkit/WebView;Ljava/lang/reflect/InvocationHandler;Landroid/net/Uri;ZLjava/lang/reflect/InvocationHandler;)V
    .registers 11

    const-class p1, Lorg/chromium/support_lib_boundary/WebMessageBoundaryInterface;

    invoke-static {p1, p2}, LHe/b;->a(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lorg/chromium/support_lib_boundary/WebMessageBoundaryInterface;

    invoke-interface {p1}, Lorg/chromium/support_lib_boundary/WebMessageBoundaryInterface;->getData()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1}, Lorg/chromium/support_lib_boundary/WebMessageBoundaryInterface;->getPorts()[Ljava/lang/reflect/InvocationHandler;

    move-result-object p1

    array-length p4, p1

    new-array p4, p4, [LC5/p;

    const/4 v0, 0x0

    :goto_14
    array-length v1, p1

    if-ge v0, v1, :cond_2f

    new-instance v1, LC5/p;

    aget-object v2, p1, v0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v1, v3, v4}, LC5/p;-><init>(IZ)V

    const-class v3, Lorg/chromium/support_lib_boundary/WebMessagePortBoundaryInterface;

    invoke-static {v3, v2}, LHe/b;->a(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/chromium/support_lib_boundary/WebMessagePortBoundaryInterface;

    iput-object v2, v1, LC5/p;->b:Ljava/lang/Object;

    aput-object v1, p4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_14

    :cond_2f
    const-class p1, Lorg/chromium/support_lib_boundary/JsReplyProxyBoundaryInterface;

    invoke-static {p1, p5}, LHe/b;->a(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lorg/chromium/support_lib_boundary/JsReplyProxyBoundaryInterface;

    new-instance p4, LH4/k;

    const/4 p5, 0x1

    invoke-direct {p4, p5, p1}, LH4/k;-><init>(ILjava/lang/Object;)V

    invoke-interface {p1, p4}, Lorg/chromium/support_lib_boundary/IsomorphicObjectBoundaryInterface;->getOrCreatePeer(Ljava/util/concurrent/Callable;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LM2/b;

    iget-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast p1, LC5/p;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p3

    iget-object p1, p1, LC5/p;->b:Ljava/lang/Object;

    check-cast p1, LVa/g;

    invoke-virtual {p1, p2, p3}, LVa/g;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public onResponse(Lokhttp3/Call;Lokhttp3/Response;)V
    .registers 16

    iget-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast p1, Lj3/x;

    iget-object v0, p1, Lj3/x;->a:Lj3/c;

    iget-object v0, v0, Lj3/c;->e:Lcom/facebook/react/bridge/ReadableMap;

    const/4 v1, 0x0

    const-string v2, ""

    if-eqz v0, :cond_70

    const-string v3, "title"

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1f

    iget-object v4, p1, Lj3/x;->a:Lj3/c;

    iget-object v4, v4, Lj3/c;->e:Lcom/facebook/react/bridge/ReadableMap;

    invoke-interface {v4, v3}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object v5, v3

    goto :goto_20

    :cond_1f
    move-object v5, v2

    :goto_20
    const-string v3, "description"

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2e

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object v6, v3

    goto :goto_2f

    :cond_2e
    move-object v6, v2

    :goto_2f
    const-string v3, "mime"

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3d

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_3b
    move-object v8, v3

    goto :goto_40

    :cond_3d
    const-string v3, "text/plain"

    goto :goto_3b

    :goto_40
    const-string v3, "mediaScannable"

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_4e

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->getBoolean(Ljava/lang/String;)Z

    move-result v3

    move v7, v3

    goto :goto_4f

    :cond_4e
    move v7, v1

    :goto_4f
    const-string v3, "notification"

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5d

    invoke-interface {v0, v3}, Lcom/facebook/react/bridge/ReadableMap;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    move v12, v0

    goto :goto_5e

    :cond_5d
    move v12, v1

    :goto_5e
    sget-object v0, Lj3/q;->b:Lcom/facebook/react/bridge/ReactApplicationContext;

    const-string v3, "download"

    invoke-virtual {v0, v3}, Lcom/facebook/react/bridge/ReactContext;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Landroid/app/DownloadManager;

    iget-object v9, p1, Lj3/x;->f:Ljava/lang/String;

    const-wide/16 v10, 0x0

    invoke-virtual/range {v4 .. v12}, Landroid/app/DownloadManager;->addCompletedDownload(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;JZ)J

    :cond_70
    invoke-virtual {p2}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v0

    const-string v3, "Content-Type"

    invoke-static {v0, v3}, Lj3/x;->c(Lokhttp3/Headers;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "text/"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    const/4 v4, 0x1

    xor-int/2addr v3, v4

    const-string v5, "application/json"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    xor-int/2addr v5, v4

    iget-object v6, p1, Lj3/x;->a:Lj3/c;

    iget-object v7, v6, Lj3/c;->n:Lcom/facebook/react/bridge/ReadableArray;

    if-eqz v7, :cond_b1

    move v7, v1

    :goto_90
    iget-object v8, v6, Lj3/c;->n:Lcom/facebook/react/bridge/ReadableArray;

    invoke-interface {v8}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    move-result v9

    if-ge v7, v9, :cond_b1

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v8, v7}, Lcom/facebook/react/bridge/ReadableArray;->getString(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_ae

    move v0, v4

    goto :goto_b2

    :cond_ae
    add-int/lit8 v7, v7, 0x1

    goto :goto_90

    :cond_b1
    move v0, v1

    :goto_b2
    if-nez v5, :cond_b6

    if-eqz v3, :cond_b8

    :cond_b6
    if-eqz v0, :cond_ba

    :cond_b8
    move v0, v4

    goto :goto_bb

    :cond_ba
    move v0, v1

    :goto_bb
    invoke-virtual {p1, p2, v0}, Lj3/x;->d(Lokhttp3/Response;Z)Lcom/facebook/react/bridge/WritableMap;

    move-result-object v3

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v5

    sget-object v7, Lj3/q;->b:Lcom/facebook/react/bridge/ReactApplicationContext;

    const-class v8, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;

    invoke-virtual {v7, v8}, Lcom/facebook/react/bridge/ReactContext;->getJSModule(Ljava/lang/Class;)Lcom/facebook/react/bridge/JavaScriptModule;

    move-result-object v7

    check-cast v7, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;

    const-string v9, "ReactNativeBlobUtilState"

    invoke-interface {v7, v9, v5}, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;->emit(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {p1, p2, v0}, Lj3/x;->d(Lokhttp3/Response;Z)Lcom/facebook/react/bridge/WritableMap;

    move-result-object v5

    sget-object v7, Lj3/q;->b:Lcom/facebook/react/bridge/ReactApplicationContext;

    invoke-virtual {v7, v8}, Lcom/facebook/react/bridge/ReactContext;->getJSModule(Ljava/lang/Class;)Lcom/facebook/react/bridge/JavaScriptModule;

    move-result-object v7

    check-cast v7, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;

    invoke-interface {v7, v9, v5}, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;->emit(Ljava/lang/String;Ljava/lang/Object;)V

    iget v5, p1, Lj3/x;->m:I

    invoke-static {v5}, Lw/q;->c(I)I

    move-result v5

    const-string v7, "UTF-8"

    const-string v8, "path"

    const-string v9, "utf8"

    const/4 v10, 0x0

    if-eqz v5, :cond_1b2

    if-eq v5, v4, :cond_11b

    :try_start_f2
    new-instance v0, Ljava/lang/String;

    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object v1

    invoke-direct {v0, v1, v7}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v10, v9, v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V
    :try_end_10a
    .catch Ljava/io/IOException; {:try_start_f2 .. :try_end_10a} :catch_10c

    goto/16 :goto_286

    :catch_10c
    const-string v0, "ReactNativeBlobUtil failed to encode response data to UTF8 string."

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V

    goto/16 :goto_286

    :cond_11b
    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    :try_start_11f
    invoke-virtual {v0}, Lokhttp3/ResponseBody;->bytes()[B
    :try_end_122
    .catch Ljava/lang/Exception; {:try_start_11f .. :try_end_122} :catch_122

    :catch_122
    :try_start_122
    check-cast v0, Lk3/d;
    :try_end_124
    .catch Ljava/lang/ClassCastException; {:try_start_122 .. :try_end_124} :catch_165

    if-eqz v0, :cond_14e

    iget-wide v4, v0, Lk3/d;->c:J

    invoke-virtual {v0}, Lk3/d;->contentLength()J

    move-result-wide v6

    cmp-long v1, v4, v6

    if-eqz v1, :cond_14e

    invoke-virtual {v0}, Lk3/d;->contentLength()J

    move-result-wide v4

    const-wide/16 v6, -0x1

    cmp-long v1, v4, v6

    if-nez v1, :cond_13f

    iget-boolean v0, v0, Lk3/d;->f:Z

    if-eqz v0, :cond_13f

    goto :goto_14e

    :cond_13f
    const-string v0, "Download interrupted."

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V

    goto/16 :goto_286

    :cond_14e
    :goto_14e
    iget-object v0, p1, Lj3/x;->f:Ljava/lang/String;

    const-string v1, "?append=true"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p1, Lj3/x;->f:Ljava/lang/String;

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v10, v8, v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V

    goto/16 :goto_286

    :catch_165
    if-eqz v0, :cond_1a3

    :try_start_167
    invoke-virtual {v0}, Lokhttp3/ResponseBody;->source()Lokio/BufferedSource;

    move-result-object p2

    invoke-interface {p2}, Lokio/BufferedSource;->m()Lue/k;

    move-result-object p2

    iget-wide v5, p2, Lue/k;->b:J

    const-wide/16 v7, 0x0

    cmp-long p2, v5, v7

    if-lez p2, :cond_179

    move p2, v4

    goto :goto_17a

    :cond_179
    move p2, v1

    :goto_17a
    invoke-virtual {v0}, Lokhttp3/ResponseBody;->contentLength()J

    move-result-wide v5

    cmp-long v2, v5, v7

    if-lez v2, :cond_183

    move v1, v4

    :cond_183
    if-eqz p2, :cond_190

    if-eqz v1, :cond_190

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v10
    :try_end_18b
    .catch Ljava/io/IOException; {:try_start_167 .. :try_end_18b} :catch_18c

    goto :goto_190

    :catch_18c
    move-exception p2

    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_190
    :goto_190
    const-string p2, "Unexpected FileStorage response file: "

    invoke-static {p2, v10}, LA8/v;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v0

    filled-new-array {p2, v0}, [Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Lj3/x;->e([Ljava/lang/Object;)V

    goto/16 :goto_290

    :cond_1a3
    const-string p2, "Unexpected FileStorage response with no file."

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v0

    filled-new-array {p2, v0}, [Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Lj3/x;->e([Ljava/lang/Object;)V

    goto/16 :goto_290

    :cond_1b2
    if-eqz v0, :cond_1f9

    :try_start_1b4
    iget-object v0, v6, Lj3/c;->i:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1f9

    iget-object v0, p1, Lj3/x;->b:Ljava/lang/String;

    invoke-static {v0}, Lj3/g;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/ResponseBody;->byteStream()Ljava/io/InputStream;

    move-result-object v2

    new-instance v4, Ljava/io/FileOutputStream;

    new-instance v5, Ljava/io/File;

    invoke-direct {v5, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v4, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/16 v5, 0x2800

    new-array v5, v5, [B

    :goto_1d8
    invoke-virtual {v2, v5}, Ljava/io/InputStream;->read([B)I

    move-result v6

    const/4 v7, -0x1

    if-eq v6, v7, :cond_1e3

    invoke-virtual {v4, v5, v1, v6}, Ljava/io/FileOutputStream;->write([BII)V

    goto :goto_1d8

    :cond_1e3
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    invoke-virtual {v4}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v4}, Ljava/io/FileOutputStream;->close()V

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v10, v8, v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V

    goto/16 :goto_286

    :cond_1f9
    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object v0

    iget-object v1, p1, Lj3/x;->a:Lj3/c;

    iget-object v2, v1, Lj3/c;->b:Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_220

    iget-object v2, v1, Lj3/c;->a:Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_218

    iget-object v1, v1, Lj3/c;->c:Ljava/lang/String;

    if-nez v1, :cond_218

    goto :goto_220

    :cond_218
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Write file with transform was specified but the shared file transformer is not set"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_220
    :goto_220
    iget v1, p1, Lj3/x;->n:I
    :try_end_222
    .catch Ljava/io/IOException; {:try_start_1b4 .. :try_end_222} :catch_279

    const/4 v2, 0x2

    const/4 v4, 0x3

    const-string v5, "base64"

    if-ne v1, v4, :cond_238

    :try_start_228
    invoke-static {v0, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v10, v5, v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V
    :try_end_237
    .catch Ljava/io/IOException; {:try_start_228 .. :try_end_237} :catch_279

    goto :goto_290

    :cond_238
    :try_start_238
    invoke-static {v7}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v1

    invoke-virtual {v1}, Ljava/nio/charset/Charset;->newDecoder()Ljava/nio/charset/CharsetDecoder;

    move-result-object v4

    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/nio/charset/CharsetDecoder;->decode(Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;

    new-instance v4, Ljava/lang/String;

    invoke-direct {v4, v0, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    filled-new-array {v10, v9, v4}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1, v1}, Lj3/x;->e([Ljava/lang/Object;)V
    :try_end_253
    .catch Ljava/nio/charset/CharacterCodingException; {:try_start_238 .. :try_end_253} :catch_254
    .catch Ljava/io/IOException; {:try_start_238 .. :try_end_253} :catch_279

    goto :goto_286

    :catch_254
    :try_start_254
    iget v1, p1, Lj3/x;->n:I

    if-ne v1, v2, :cond_269

    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([B)V

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v0

    filled-new-array {v10, v9, v1, v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V

    goto :goto_286

    :cond_269
    invoke-static {v0, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v10, v5, v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V
    :try_end_278
    .catch Ljava/io/IOException; {:try_start_254 .. :try_end_278} :catch_279

    goto :goto_286

    :catch_279
    const-string v0, "ReactNativeBlobUtil failed to encode response data to BASE64 string."

    invoke-interface {v3}, Lcom/facebook/react/bridge/WritableMap;->copy()Lcom/facebook/react/bridge/WritableMap;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lj3/x;->e([Ljava/lang/Object;)V

    :goto_286
    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p2

    invoke-virtual {p2}, Lokhttp3/ResponseBody;->close()V

    invoke-virtual {p1}, Lj3/x;->f()V

    :goto_290
    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/Void;

    return-void
.end method

.method public p(Ljava/lang/Class;)Z
    .registers 7

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, [Lcom/google/android/gms/internal/measurement/C3;

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_7
    if-ge v3, v1, :cond_16

    aget-object v4, v0, v3

    invoke-interface {v4, p1}, Lcom/google/android/gms/internal/measurement/C3;->p(Ljava/lang/Class;)Z

    move-result v4

    if-eqz v4, :cond_13

    const/4 p1, 0x1

    return p1

    :cond_13
    add-int/lit8 v3, v3, 0x1

    goto :goto_7

    :cond_16
    return v2
.end method

.method public q()[Landroid/graphics/Point;
    .registers 2

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;

    iget-object v0, v0, Lcom/google/android/gms/internal/mlkit_vision_barcode/zzvj;->e:[Landroid/graphics/Point;

    return-object v0
.end method

.method public r(Lwd/a;)LJd/c;
    .registers 5

    const-string v0, "classId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lwd/a;->g()Lwd/b;

    move-result-object v0

    const-string v1, "classId.packageFqName"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, LXc/J;

    invoke-static {v1, v0}, Lm7/j3;->d(LXc/J;Lwd/b;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_37

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LXc/I;

    instance-of v2, v1, LKd/d;

    if-nez v2, :cond_2b

    goto :goto_1a

    :cond_2b
    check-cast v1, LKd/d;

    iget-object v1, v1, LKd/d;->j:LB3/c;

    invoke-virtual {v1, p1}, LB3/c;->r(Lwd/a;)LJd/c;

    move-result-object v1

    if-nez v1, :cond_36

    goto :goto_1a

    :cond_36
    return-object v1

    :cond_37
    const/4 p1, 0x0

    return-object p1
.end method

.method public s(Lyc/d;)Ljava/lang/Object;
    .registers 19

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    instance-of v2, v1, LI3/a;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, LI3/a;

    iget v3, v2, LI3/a;->f:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, LI3/a;->f:I

    goto :goto_1c

    :cond_17
    new-instance v2, LI3/a;

    invoke-direct {v2, v0, v1}, LI3/a;-><init>(LC/y0;Lyc/d;)V

    :goto_1c
    iget-object v1, v2, LI3/a;->d:Ljava/lang/Object;

    sget-object v3, Lzc/a;->a:Lzc/a;

    iget v4, v2, LI3/a;->f:I

    sget-object v5, Luc/z;->a:Luc/z;

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v4, :cond_43

    if-eq v4, v8, :cond_39

    if-ne v4, v7, :cond_31

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto/16 :goto_c6

    :cond_31
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_39
    iget-object v4, v2, LI3/a;->c:LL3/a;

    iget-object v8, v2, LI3/a;->b:LC3/g;

    iget-object v9, v2, LI3/a;->a:LC/y0;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_8c

    :cond_43
    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object v1, v0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, LC3/e;

    iget-object v4, v1, LC3/e;->a:LC3/g;

    const-string v9, "null cannot be cast to non-null type com.amplitude.android.Configuration"

    invoke-static {v4, v9}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, LC3/e;->d()LK3/d;

    move-result-object v9

    instance-of v10, v9, LK3/d;

    if-eqz v10, :cond_5a

    goto :goto_5b

    :cond_5a
    const/4 v9, 0x0

    :goto_5b
    iget-object v15, v1, LC3/e;->l:LL3/a;

    if-eqz v9, :cond_8f

    new-instance v14, LK3/d;

    iget-object v12, v4, LC3/g;->a:Ljava/lang/String;

    iget-object v13, v9, LK3/d;->c:Ljava/lang/String;

    iget-object v11, v4, LC3/g;->b:Landroid/content/Context;

    iget-object v1, v1, LC3/e;->o:LA3/c;

    move-object v10, v14

    move-object/from16 v16, v13

    move-object v13, v15

    move-object v7, v14

    move-object/from16 v14, v16

    move-object v6, v15

    move-object v15, v1

    invoke-direct/range {v10 .. v15}, LK3/d;-><init>(Landroid/content/Context;Ljava/lang/String;LL3/a;Ljava/lang/String;LA3/c;)V

    new-instance v1, LAc/f;

    invoke-direct {v1, v7, v9, v6}, LAc/f;-><init>(LK3/d;LK3/d;LL3/a;)V

    iput-object v0, v2, LI3/a;->a:LC/y0;

    iput-object v4, v2, LI3/a;->b:LC3/g;

    iput-object v6, v2, LI3/a;->c:LL3/a;

    iput v8, v2, LI3/a;->f:I

    invoke-virtual {v1, v2}, LAc/f;->t(Lyc/d;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v3, :cond_89

    return-object v3

    :cond_89
    move-object v9, v0

    move-object v8, v4

    move-object v4, v6

    :goto_8c
    move-object v6, v4

    move-object v4, v8

    goto :goto_91

    :cond_8f
    move-object v6, v15

    move-object v9, v0

    :goto_91
    iget-object v1, v9, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, LC3/e;

    iget-object v7, v1, LC3/e;->j:LK3/d;

    if-eqz v7, :cond_c7

    instance-of v8, v7, LK3/d;

    if-eqz v8, :cond_9e

    goto :goto_9f

    :cond_9e
    const/4 v7, 0x0

    :goto_9f
    if-eqz v7, :cond_c6

    new-instance v8, LK3/d;

    iget-object v11, v4, LC3/g;->b:Landroid/content/Context;

    iget-object v15, v1, LC3/e;->o:LA3/c;

    iget-object v12, v4, LC3/g;->a:Ljava/lang/String;

    iget-object v14, v7, LK3/d;->c:Ljava/lang/String;

    move-object v10, v8

    move-object v13, v6

    invoke-direct/range {v10 .. v15}, LK3/d;-><init>(Landroid/content/Context;Ljava/lang/String;LL3/a;Ljava/lang/String;LA3/c;)V

    new-instance v1, LAc/f;

    invoke-direct {v1, v8, v7, v6}, LAc/f;-><init>(LK3/d;LK3/d;LL3/a;)V

    const/4 v4, 0x0

    iput-object v4, v2, LI3/a;->a:LC/y0;

    iput-object v4, v2, LI3/a;->b:LC3/g;

    iput-object v4, v2, LI3/a;->c:LL3/a;

    const/4 v4, 0x2

    iput v4, v2, LI3/a;->f:I

    invoke-virtual {v1, v2}, LAc/f;->t(Lyc/d;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v3, :cond_c6

    return-object v3

    :cond_c6
    :goto_c6
    return-object v5

    :cond_c7
    const/4 v4, 0x0

    const-string v1, "identifyInterceptStorage"

    invoke-static {v1}, Lkotlin/jvm/internal/l;->m(Ljava/lang/String;)V

    throw v4
.end method

.method public t(Ljava/lang/Object;Ljava/lang/String;)F
    .registers 6

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/high16 v2, 0x7fc00000    # Float.NaN

    if-nez v1, :cond_d

    return v2

    :cond_d
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/HashMap;

    if-eqz p1, :cond_2c

    invoke-virtual {p1, p2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1c

    goto :goto_2c

    :cond_1c
    invoke-virtual {p1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [F

    if-nez p1, :cond_25

    return v2

    :cond_25
    array-length p2, p1

    if-lez p2, :cond_2c

    const/4 p2, 0x0

    aget p1, p1, p2

    return p1

    :cond_2c
    :goto_2c
    return v2
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    iget v0, p0, LC/y0;->a:I

    packed-switch v0, :pswitch_data_2c

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "(optOutActivities="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v1, Lvc/w;->a:Lvc/w;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", activityNames="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/LinkedHashSet;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_data_2c
    .packed-switch 0xa
        :pswitch_a
    .end packed-switch
.end method

.method public u(I)S
    .registers 5

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/Buffer;->remaining()I

    move-result v1

    sub-int/2addr v1, p1

    const/4 v2, 0x2

    if-lt v1, v2, :cond_11

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result p1

    goto :goto_12

    :cond_11
    const/4 p1, -0x1

    :goto_12
    return p1
.end method

.method public v(Ljava/lang/Throwable;)V
    .registers 7

    const-string v0, "Opening session with fail "

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, Lw/K;

    iget-object v1, v1, Lw/K;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_9
    iget-object v2, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v2, Lw/K;

    iget-object v2, v2, Lw/K;->e:Lw/h0;

    iget-object v2, v2, Lw/h0;->a:Ljava/lang/Object;

    check-cast v2, Lw/e0;

    invoke-virtual {v2}, Lw/e0;->p()Z

    iget-object v2, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v2, Lw/K;

    iget v2, v2, Lw/K;->l:I

    invoke-static {v2}, Lw/q;->c(I)I

    move-result v2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eq v2, v3, :cond_2a

    if-eq v2, v4, :cond_2a

    const/4 v3, 0x6

    if-eq v2, v3, :cond_2a

    goto :goto_51

    :cond_2a
    instance-of v2, p1, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_51

    const-string v2, "CaptureSession"

    iget-object v3, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v3, Lw/K;

    iget v3, v3, Lw/K;->l:I

    invoke-static {v3}, Ldb/s;->p(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v2}, LHe/b;->h(ILjava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_47

    invoke-static {v2, v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_47
    iget-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast p1, Lw/K;

    invoke-virtual {p1}, Lw/K;->b()V

    goto :goto_51

    :catchall_4f
    move-exception p1

    goto :goto_53

    :cond_51
    :goto_51
    monitor-exit v1

    return-void

    :goto_53
    monitor-exit v1
    :try_end_54
    .catchall {:try_start_9 .. :try_end_54} :catchall_4f

    throw p1
.end method

.method public w()V
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Ljc/m;

    iget-object v1, v0, Ljc/m;->f:Ljc/E;

    sget-object v2, Ljc/w;->b:Ljc/w;

    invoke-virtual {v1, v2}, Ljc/E;->m(Ljc/w;)V

    iget-object v0, v0, Ljc/m;->f:Ljc/E;

    const-string v1, "onAdsParamsFetchFinished"

    invoke-virtual {v0, v1}, Ljc/E;->k(Ljava/lang/String;)V

    return-void
.end method

.method public x(Landroid/view/View;Landroidx/core/view/Q0;)Landroidx/core/view/Q0;
    .registers 5

    iget-object p1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    iget-object v0, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->m:LC7/f;

    if-eqz v0, :cond_f

    iget-object v1, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->f:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget-object v1, v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_f
    new-instance v0, LC7/m;

    iget-object v1, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->i:Landroid/widget/FrameLayout;

    invoke-direct {v0, v1, p2}, LC7/m;-><init>(Landroid/view/View;Landroidx/core/view/Q0;)V

    iput-object v0, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->m:LC7/f;

    iget-object p1, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->f:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget-object p1, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_25

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_25
    return-object p2
.end method

.method public y(Ljava/lang/String;)Ljava/lang/Double;
    .registers 5

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lorg/json/JSONObject;

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;)D

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->remove(Ljava/lang/String;)Ljava/lang/Object;

    goto :goto_17

    :cond_16
    const/4 v1, 0x0

    :goto_17
    return-object v1
.end method

.method public z(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v0, Lorg/json/JSONObject;

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->remove(Ljava/lang/String;)Ljava/lang/Object;

    return-object v1
.end method

.method public zza(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V
    .registers 6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    iget-object v1, p0, LC/y0;->b:Ljava/lang/Object;

    check-cast v1, Lr7/O1;

    if-eqz v0, :cond_1b

    iget-object p1, v1, Lr7/O1;->l:Lr7/j0;

    if-eqz p1, :cond_27

    iget-object p1, p1, Lr7/j0;->i:Lr7/I;

    invoke-static {p1}, Lr7/j0;->e(Lr7/A0;)V

    const-string p3, "AppId not known when logging event"

    iget-object p1, p1, Lr7/I;->g:Lr7/K;

    invoke-virtual {p1, p2, p3}, Lr7/K;->a(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :cond_1b
    invoke-virtual {v1}, Lr7/O1;->V()Lr7/g0;

    move-result-object v0

    new-instance v1, LVa/e;

    invoke-direct {v1, p0, p1, p2, p3}, LVa/e;-><init>(LC/y0;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    invoke-virtual {v0, v1}, Lr7/g0;->G0(Ljava/lang/Runnable;)V

    :cond_27
    return-void
.end method
