.class public final LC/v;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final l:Ljava/lang/Object;

.field public static final m:Landroid/util/SparseArray;


# instance fields
.field public final a:Lw3/d;

.field public final b:Ljava/lang/Object;

.field public final c:LC/y;

.field public final d:Ljava/util/concurrent/Executor;

.field public final e:Landroid/os/Handler;

.field public f:Lf3/e;

.field public g:Lw3/d;

.field public h:Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;

.field public i:Landroid/content/Context;

.field public final j:Landroidx/concurrent/futures/n;

.field public k:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LC/v;->l:Ljava/lang/Object;

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    sput-object v0, LC/v;->m:Landroid/util/SparseArray;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lw3/d;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lw3/d;-><init>(I)V

    iput-object v0, p0, LC/v;->a:Lw3/d;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LC/v;->b:Ljava/lang/Object;

    const/4 v0, 0x1

    iput v0, p0, LC/v;->k:I

    const-string v1, "CameraX"

    invoke-static {p1}, LZ6/f;->b(Landroid/content/Context;)Landroid/app/Application;

    move-result-object v2

    instance-of v3, v2, LC/x;

    const/4 v4, 0x0

    if-eqz v3, :cond_23

    check-cast v2, LC/x;

    goto :goto_70

    :cond_23
    :try_start_23
    invoke-static {p1}, LZ6/f;->a(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    new-instance v5, Landroid/content/ComponentName;

    const-class v6, Landroidx/camera/core/impl/MetadataHolderService;

    invoke-direct {v5, v2, v6}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v2, 0x280

    invoke-virtual {v3, v5, v2}, Landroid/content/pm/PackageManager;->getServiceInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ServiceInfo;

    move-result-object v2

    iget-object v2, v2, Landroid/content/pm/ServiceInfo;->metaData:Landroid/os/Bundle;

    if-eqz v2, :cond_51

    const-string v3, "androidx.camera.core.impl.MetadataHolderService.DEFAULT_CONFIG_PROVIDER"

    invoke-virtual {v2, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_52

    :catch_43
    move-exception v2

    goto :goto_6a

    :catch_45
    move-exception v2

    goto :goto_6a

    :catch_47
    move-exception v2

    goto :goto_6a

    :catch_49
    move-exception v2

    goto :goto_6a

    :catch_4b
    move-exception v2

    goto :goto_6a

    :catch_4d
    move-exception v2

    goto :goto_6a

    :catch_4f
    move-exception v2

    goto :goto_6a

    :cond_51
    move-object v2, v4

    :goto_52
    if-nez v2, :cond_5b

    const-string v2, "No default CameraXConfig.Provider specified in meta-data. The most likely cause is you did not include a default implementation in your build such as \'camera-camera2\'."

    invoke-static {v1, v2}, LHe/b;->c(Ljava/lang/String;Ljava/lang/String;)V

    :goto_59
    move-object v2, v4

    goto :goto_70

    :cond_5b
    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC/x;
    :try_end_69
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_23 .. :try_end_69} :catch_4f
    .catch Ljava/lang/ClassNotFoundException; {:try_start_23 .. :try_end_69} :catch_4d
    .catch Ljava/lang/InstantiationException; {:try_start_23 .. :try_end_69} :catch_4b
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_23 .. :try_end_69} :catch_49
    .catch Ljava/lang/NoSuchMethodException; {:try_start_23 .. :try_end_69} :catch_47
    .catch Ljava/lang/IllegalAccessException; {:try_start_23 .. :try_end_69} :catch_45
    .catch Ljava/lang/NullPointerException; {:try_start_23 .. :try_end_69} :catch_43

    goto :goto_70

    :goto_6a
    const-string v3, "Failed to retrieve default CameraXConfig.Provider from meta-data"

    invoke-static {v1, v3, v2}, LHe/b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_59

    :goto_70
    if-eqz v2, :cond_156

    invoke-interface {v2}, LC/x;->getCameraXConfig()LC/y;

    move-result-object v1

    iput-object v1, p0, LC/v;->c:LC/y;

    sget-object v2, LC/y;->e:LD/c;

    iget-object v1, v1, LC/y;->a:LD/c0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7f
    invoke-virtual {v1, v2}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v1
    :try_end_83
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7f .. :try_end_83} :catch_84

    goto :goto_85

    :catch_84
    move-object v1, v4

    :goto_85
    check-cast v1, Ljava/util/concurrent/Executor;

    iget-object v2, p0, LC/v;->c:LC/y;

    sget-object v3, LC/y;->f:LD/c;

    iget-object v2, v2, LC/y;->a:LD/c0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_90
    invoke-virtual {v2, v3}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v2
    :try_end_94
    .catch Ljava/lang/IllegalArgumentException; {:try_start_90 .. :try_end_94} :catch_95

    goto :goto_96

    :catch_95
    move-object v2, v4

    :goto_96
    check-cast v2, Landroid/os/Handler;

    if-nez v1, :cond_9f

    new-instance v1, LC/o;

    invoke-direct {v1}, LC/o;-><init>()V

    :cond_9f
    iput-object v1, p0, LC/v;->d:Ljava/util/concurrent/Executor;

    if-nez v2, :cond_ba

    new-instance v1, Landroid/os/HandlerThread;

    const-string v2, "CameraX-scheduler"

    const/16 v3, 0xa

    invoke-direct {v1, v2, v3}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v1}, Ll7/l6;->a(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object v1

    iput-object v1, p0, LC/v;->e:Landroid/os/Handler;

    goto :goto_bc

    :cond_ba
    iput-object v2, p0, LC/v;->e:Landroid/os/Handler;

    :goto_bc
    iget-object v1, p0, LC/v;->c:LC/y;

    sget-object v2, LC/y;->g:LD/c;

    invoke-interface {v1, v2, v4}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    sget-object v2, LC/v;->l:Ljava/lang/Object;

    monitor-enter v2

    if-nez v1, :cond_d0

    :try_start_cb
    monitor-exit v2

    goto :goto_132

    :catchall_cd
    move-exception p1

    goto/16 :goto_154

    :cond_d0
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const-string v4, "minLogLevel"

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v4, v3, v6, v5}, Ll7/C5;->c(Ljava/lang/String;III)V

    sget-object v3, LC/v;->m:Landroid/util/SparseArray;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_f7

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    add-int/2addr v4, v0

    goto :goto_f8

    :cond_f7
    move v4, v0

    :goto_f8
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v1, v4}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-nez v1, :cond_10c

    sput v6, LHe/b;->a:I

    goto :goto_131

    :cond_10c
    invoke-virtual {v3, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_115

    sput v6, LHe/b;->a:I

    goto :goto_131

    :cond_115
    const/4 v1, 0x4

    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_11f

    sput v1, LHe/b;->a:I

    goto :goto_131

    :cond_11f
    const/4 v1, 0x5

    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_129

    sput v1, LHe/b;->a:I

    goto :goto_131

    :cond_129
    invoke-virtual {v3, v5}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_131

    sput v5, LHe/b;->a:I

    :cond_131
    :goto_131
    monitor-exit v2
    :try_end_132
    .catchall {:try_start_cb .. :try_end_132} :catchall_cd

    :goto_132
    iget-object v1, p0, LC/v;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_135
    iget v2, p0, LC/v;->k:I

    if-ne v2, v0, :cond_13a

    goto :goto_13b

    :cond_13a
    const/4 v0, 0x0

    :goto_13b
    const-string v2, "CameraX.initInternal() should only be called once per instance"

    invoke-static {v0, v2}, Ll7/C5;->f(ZLjava/lang/String;)V

    const/4 v0, 0x2

    iput v0, p0, LC/v;->k:I

    new-instance v0, LC/s;

    const/4 v2, 0x0

    invoke-direct {v0, v2, p0, p1}, LC/s;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v0}, Lm7/U3;->a(Landroidx/concurrent/futures/l;)Landroidx/concurrent/futures/n;

    move-result-object p1

    monitor-exit v1
    :try_end_14e
    .catchall {:try_start_135 .. :try_end_14e} :catchall_151

    iput-object p1, p0, LC/v;->j:Landroidx/concurrent/futures/n;

    return-void

    :catchall_151
    move-exception p1

    :try_start_152
    monitor-exit v1
    :try_end_153
    .catchall {:try_start_152 .. :try_end_153} :catchall_151

    throw p1

    :goto_154
    :try_start_154
    monitor-exit v2
    :try_end_155
    .catchall {:try_start_154 .. :try_end_155} :catchall_cd

    throw p1

    :cond_156
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "CameraX is not configured properly. The most likely cause is you did not include a default implementation in your build such as \'camera-camera2\'."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()V
    .registers 3

    iget-object v0, p0, LC/v;->b:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x4

    :try_start_4
    iput v1, p0, LC/v;->k:I

    monitor-exit v0

    return-void

    :catchall_8
    move-exception v1

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_4 .. :try_end_a} :catchall_8

    throw v1
.end method
