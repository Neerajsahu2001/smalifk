.class public final LC/o0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/T;
.implements LC/G;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:LC/n0;

.field public c:I

.field public final d:LA/h;

.field public e:Z

.field public final f:LD/T;

.field public g:LD/S;

.field public h:Ljava/util/concurrent/Executor;

.field public final i:Landroid/util/LongSparseArray;

.field public final j:Landroid/util/LongSparseArray;

.field public k:I

.field public final l:Ljava/util/ArrayList;

.field public final m:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(IIII)V
    .registers 6

    new-instance v0, LC/c;

    invoke-static {p1, p2, p3, p4}, Landroid/media/ImageReader;->newInstance(IIII)Landroid/media/ImageReader;

    move-result-object p1

    invoke-direct {v0, p1}, LC/c;-><init>(Landroid/media/ImageReader;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/o0;->a:Ljava/lang/Object;

    new-instance p1, LC/n0;

    invoke-direct {p1, p0}, LC/n0;-><init>(LC/o0;)V

    iput-object p1, p0, LC/o0;->b:LC/n0;

    const/4 p1, 0x0

    iput p1, p0, LC/o0;->c:I

    new-instance p2, LA/h;

    const/4 p3, 0x2

    invoke-direct {p2, p3, p0}, LA/h;-><init>(ILjava/lang/Object;)V

    iput-object p2, p0, LC/o0;->d:LA/h;

    iput-boolean p1, p0, LC/o0;->e:Z

    new-instance p2, Landroid/util/LongSparseArray;

    invoke-direct {p2}, Landroid/util/LongSparseArray;-><init>()V

    iput-object p2, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    new-instance p2, Landroid/util/LongSparseArray;

    invoke-direct {p2}, Landroid/util/LongSparseArray;-><init>()V

    iput-object p2, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, LC/o0;->m:Ljava/util/ArrayList;

    iput-object v0, p0, LC/o0;->f:LD/T;

    iput p1, p0, LC/o0;->k:I

    new-instance p1, Ljava/util/ArrayList;

    invoke-virtual {p0}, LC/o0;->f()I

    move-result p2

    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, LC/o0;->l:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final a()LC/k0;
    .registers 6

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_10

    monitor-exit v0

    const/4 v0, 0x0

    return-object v0

    :catchall_e
    move-exception v1

    goto :goto_7b

    :cond_10
    iget v1, p0, LC/o0;->k:I

    iget-object v2, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_73

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    :goto_20
    iget-object v3, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    if-ge v2, v3, :cond_46

    iget-object v3, p0, LC/o0;->m:Ljava/util/ArrayList;

    iget-object v4, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_43

    iget-object v3, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LC/k0;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_43
    add-int/lit8 v2, v2, 0x1

    goto :goto_20

    :cond_46
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_4a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC/k0;

    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    goto :goto_4a

    :cond_5a
    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v2, v1, -0x1

    iget-object v3, p0, LC/o0;->l:Ljava/util/ArrayList;

    iput v1, p0, LC/o0;->k:I

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LC/k0;

    iget-object v2, p0, LC/o0;->m:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v0

    return-object v1

    :cond_73
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Maximum image number reached."

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_7b
    monitor-exit v0
    :try_end_7c
    .catchall {:try_start_3 .. :try_end_7c} :catchall_e

    throw v1
.end method

.method public final b()I
    .registers 3

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->f:LD/T;

    invoke-interface {v1}, LD/T;->b()I

    move-result v1

    monitor-exit v0

    return v1

    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public final c()V
    .registers 3

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->f:LD/T;

    invoke-interface {v1}, LD/T;->c()V

    const/4 v1, 0x0

    iput-object v1, p0, LC/o0;->g:LD/S;

    iput-object v1, p0, LC/o0;->h:Ljava/util/concurrent/Executor;

    const/4 v1, 0x0

    iput v1, p0, LC/o0;->c:I

    monitor-exit v0

    return-void

    :catchall_12
    move-exception v1

    monitor-exit v0
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_12

    throw v1
.end method

.method public final close()V
    .registers 4

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LC/o0;->e:Z

    if-eqz v1, :cond_b

    monitor-exit v0

    return-void

    :catchall_9
    move-exception v1

    goto :goto_35

    :cond_b
    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_16
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_26

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC/k0;

    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    goto :goto_16

    :cond_26
    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, LC/o0;->f:LD/T;

    invoke-interface {v1}, LD/T;->close()V

    const/4 v1, 0x1

    iput-boolean v1, p0, LC/o0;->e:Z

    monitor-exit v0

    return-void

    :goto_35
    monitor-exit v0
    :try_end_36
    .catchall {:try_start_3 .. :try_end_36} :catchall_9

    throw v1
.end method

.method public final d()Landroid/view/Surface;
    .registers 3

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->f:LD/T;

    invoke-interface {v1}, LD/T;->d()Landroid/view/Surface;

    move-result-object v1

    monitor-exit v0

    return-object v1

    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public final e(LC/k0;)V
    .registers 3

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p0, p1}, LC/o0;->i(LC/k0;)V

    monitor-exit v0

    return-void

    :catchall_8
    move-exception p1

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_3 .. :try_end_a} :catchall_8

    throw p1
.end method

.method public final f()I
    .registers 3

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->f:LD/T;

    invoke-interface {v1}, LD/T;->f()I

    move-result v1

    monitor-exit v0

    return v1

    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public final g(LD/S;Ljava/util/concurrent/Executor;)V
    .registers 5

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, LC/o0;->g:LD/S;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p0, LC/o0;->h:Ljava/util/concurrent/Executor;

    iget-object p1, p0, LC/o0;->f:LD/T;

    iget-object v1, p0, LC/o0;->d:LA/h;

    invoke-interface {p1, v1, p2}, LD/T;->g(LD/S;Ljava/util/concurrent/Executor;)V

    monitor-exit v0

    return-void

    :catchall_16
    move-exception p1

    monitor-exit v0
    :try_end_18
    .catchall {:try_start_3 .. :try_end_18} :catchall_16

    throw p1
.end method

.method public final getHeight()I
    .registers 3

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->f:LD/T;

    invoke-interface {v1}, LD/T;->getHeight()I

    move-result v1

    monitor-exit v0

    return v1

    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public final getWidth()I
    .registers 3

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->f:LD/T;

    invoke-interface {v1}, LD/T;->getWidth()I

    move-result v1

    monitor-exit v0

    return v1

    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public final h()LC/k0;
    .registers 5

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_10

    monitor-exit v0

    const/4 v0, 0x0

    return-object v0

    :catchall_e
    move-exception v1

    goto :goto_37

    :cond_10
    iget v1, p0, LC/o0;->k:I

    iget-object v2, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2f

    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    iget v2, p0, LC/o0;->k:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, LC/o0;->k:I

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LC/k0;

    iget-object v2, p0, LC/o0;->m:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v0

    return-object v1

    :cond_2f
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Maximum image number reached."

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_37
    monitor-exit v0
    :try_end_38
    .catchall {:try_start_3 .. :try_end_38} :catchall_e

    throw v1
.end method

.method public final i(LC/k0;)V
    .registers 5

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v1

    if-ltz v1, :cond_1b

    iget-object v2, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    iget v2, p0, LC/o0;->k:I

    if-gt v1, v2, :cond_1b

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, LC/o0;->k:I

    goto :goto_1b

    :catchall_19
    move-exception p1

    goto :goto_2b

    :cond_1b
    :goto_1b
    iget-object v1, p0, LC/o0;->m:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget p1, p0, LC/o0;->c:I

    if-lez p1, :cond_29

    iget-object p1, p0, LC/o0;->f:LD/T;

    invoke-virtual {p0, p1}, LC/o0;->k(LD/T;)V

    :cond_29
    monitor-exit v0

    return-void

    :goto_2b
    monitor-exit v0
    :try_end_2c
    .catchall {:try_start_3 .. :try_end_2c} :catchall_19

    throw p1
.end method

.method public final j(LC/G0;)V
    .registers 5

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-virtual {p0}, LC/o0;->f()I

    move-result v2

    if-ge v1, v2, :cond_1e

    invoke-virtual {p1, p0}, LC/H;->a(LC/G;)V

    iget-object v1, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, LC/o0;->g:LD/S;

    iget-object v1, p0, LC/o0;->h:Ljava/util/concurrent/Executor;

    goto :goto_2a

    :catchall_1c
    move-exception p1

    goto :goto_3d

    :cond_1e
    const-string v1, "TAG"

    const-string v2, "Maximum image number reached."

    invoke-static {v1, v2}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, LC/H;->close()V

    const/4 p1, 0x0

    move-object v1, p1

    :goto_2a
    monitor-exit v0
    :try_end_2b
    .catchall {:try_start_3 .. :try_end_2b} :catchall_1c

    if-eqz p1, :cond_3c

    if-eqz v1, :cond_39

    new-instance v0, LB1/h;

    const/4 v2, 0x2

    invoke-direct {v0, v2, p0, p1}, LB1/h;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_3c

    :cond_39
    invoke-interface {p1, p0}, LD/S;->k(LD/T;)V

    :cond_3c
    :goto_3c
    return-void

    :goto_3d
    :try_start_3d
    monitor-exit v0
    :try_end_3e
    .catchall {:try_start_3d .. :try_end_3e} :catchall_1c

    throw p1
.end method

.method public final k(LD/T;)V
    .registers 8

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LC/o0;->e:Z

    if-eqz v1, :cond_b

    monitor-exit v0

    return-void

    :catchall_9
    move-exception p1

    goto :goto_67

    :cond_b
    iget-object v1, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v1}, Landroid/util/LongSparseArray;->size()I

    move-result v1

    iget-object v2, p0, LC/o0;->l:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/2addr v1, v2

    invoke-interface {p1}, LD/T;->f()I

    move-result v2

    if-lt v1, v2, :cond_27

    const-string p1, "MetadataImageReader"

    const-string v1, "Skip to acquire the next image because the acquired image count has reached the max images count."

    invoke-static {p1, v1}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v0
    :try_end_26
    .catchall {:try_start_3 .. :try_end_26} :catchall_9

    return-void

    :cond_27
    :try_start_27
    invoke-interface {p1}, LD/T;->h()LC/k0;

    move-result-object v2
    :try_end_2b
    .catch Ljava/lang/IllegalStateException; {:try_start_27 .. :try_end_2b} :catch_48
    .catchall {:try_start_27 .. :try_end_2b} :catchall_46

    if-eqz v2, :cond_58

    :try_start_2d
    iget v3, p0, LC/o0;->c:I

    add-int/lit8 v3, v3, -0x1

    iput v3, p0, LC/o0;->c:I

    add-int/lit8 v1, v1, 0x1

    iget-object v3, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-interface {v2}, LC/k0;->Q()LC/h0;

    move-result-object v4

    invoke-interface {v4}, LC/h0;->c()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5, v2}, Landroid/util/LongSparseArray;->put(JLjava/lang/Object;)V

    invoke-virtual {p0}, LC/o0;->l()V
    :try_end_45
    .catchall {:try_start_2d .. :try_end_45} :catchall_9

    goto :goto_58

    :catchall_46
    move-exception p1

    goto :goto_66

    :catch_48
    move-exception v2

    :try_start_49
    const-string v3, "MetadataImageReader"

    const-string v4, "Failed to acquire next image."

    const/4 v5, 0x3

    invoke-static {v5, v3}, LHe/b;->h(ILjava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_57

    invoke-static {v3, v4, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_57
    .catchall {:try_start_49 .. :try_end_57} :catchall_46

    :cond_57
    const/4 v2, 0x0

    :cond_58
    :goto_58
    if-eqz v2, :cond_64

    :try_start_5a
    iget v2, p0, LC/o0;->c:I

    if-lez v2, :cond_64

    invoke-interface {p1}, LD/T;->f()I

    move-result v2

    if-lt v1, v2, :cond_27

    :cond_64
    monitor-exit v0

    return-void

    :goto_66
    throw p1

    :goto_67
    monitor-exit v0
    :try_end_68
    .catchall {:try_start_5a .. :try_end_68} :catchall_9

    throw p1
.end method

.method public final l()V
    .registers 8

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v1}, Landroid/util/LongSparseArray;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_b
    if-ltz v1, :cond_3c

    iget-object v2, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v2, v1}, Landroid/util/LongSparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC/h0;

    invoke-interface {v2}, LC/h0;->c()J

    move-result-wide v3

    iget-object v5, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v5, v3, v4}, Landroid/util/LongSparseArray;->get(J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LC/k0;

    if-eqz v5, :cond_39

    iget-object v6, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v6, v3, v4}, Landroid/util/LongSparseArray;->remove(J)V

    iget-object v3, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v3, v1}, Landroid/util/LongSparseArray;->removeAt(I)V

    new-instance v3, LC/G0;

    const/4 v4, 0x0

    invoke-direct {v3, v5, v4, v2}, LC/G0;-><init>(LC/k0;Landroid/util/Size;LC/h0;)V

    invoke-virtual {p0, v3}, LC/o0;->j(LC/G0;)V

    goto :goto_39

    :catchall_37
    move-exception v1

    goto :goto_41

    :cond_39
    :goto_39
    add-int/lit8 v1, v1, -0x1

    goto :goto_b

    :cond_3c
    invoke-virtual {p0}, LC/o0;->m()V

    monitor-exit v0

    return-void

    :goto_41
    monitor-exit v0
    :try_end_42
    .catchall {:try_start_3 .. :try_end_42} :catchall_37

    throw v1
.end method

.method public final m()V
    .registers 8

    iget-object v0, p0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v1}, Landroid/util/LongSparseArray;->size()I

    move-result v1

    if-eqz v1, :cond_7e

    iget-object v1, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v1}, Landroid/util/LongSparseArray;->size()I

    move-result v1

    if-nez v1, :cond_14

    goto :goto_7e

    :cond_14
    iget-object v1, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/util/LongSparseArray;->keyAt(I)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    iget-object v5, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v5, v2}, Landroid/util/LongSparseArray;->keyAt(I)J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/Long;->equals(Ljava/lang/Object;)Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Ll7/C5;->a(Z)V

    cmp-long v1, v5, v3

    if-lez v1, :cond_60

    iget-object v1, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v1}, Landroid/util/LongSparseArray;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_3e
    if-ltz v1, :cond_7c

    iget-object v2, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v2, v1}, Landroid/util/LongSparseArray;->keyAt(I)J

    move-result-wide v2

    cmp-long v2, v2, v5

    if-gez v2, :cond_5d

    iget-object v2, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v2, v1}, Landroid/util/LongSparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC/k0;

    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    iget-object v2, p0, LC/o0;->j:Landroid/util/LongSparseArray;

    invoke-virtual {v2, v1}, Landroid/util/LongSparseArray;->removeAt(I)V

    goto :goto_5d

    :catchall_5b
    move-exception v1

    goto :goto_80

    :cond_5d
    :goto_5d
    add-int/lit8 v1, v1, -0x1

    goto :goto_3e

    :cond_60
    iget-object v1, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v1}, Landroid/util/LongSparseArray;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_68
    if-ltz v1, :cond_7c

    iget-object v2, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v2, v1}, Landroid/util/LongSparseArray;->keyAt(I)J

    move-result-wide v5

    cmp-long v2, v5, v3

    if-gez v2, :cond_79

    iget-object v2, p0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-virtual {v2, v1}, Landroid/util/LongSparseArray;->removeAt(I)V

    :cond_79
    add-int/lit8 v1, v1, -0x1

    goto :goto_68

    :cond_7c
    monitor-exit v0

    return-void

    :cond_7e
    :goto_7e
    monitor-exit v0

    return-void

    :goto_80
    monitor-exit v0
    :try_end_81
    .catchall {:try_start_3 .. :try_end_81} :catchall_5b

    throw v1
.end method
