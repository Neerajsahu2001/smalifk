.class public final synthetic LC/x0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/concurrent/futures/l;
.implements Lq/a;
.implements LZ0/m;
.implements Lv7/d;
.implements Ly1/f;
.implements Lv7/b;
.implements Lv7/h;
.implements Lcom/nozbe/watermelondb/g;
.implements Lcom/nozbe/watermelondb/l;
.implements Lio/sentry/R0;
.implements Lv7/f;
.implements Lg/a;
.implements LA6/b;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC/x0;->a:I

    iput-object p2, p0, LC/x0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lg1/a;Landroidx/media3/exoplayer/f;)V
    .registers 3

    const/16 p2, 0xa

    iput p2, p0, LC/x0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/x0;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .registers 8

    const/4 v0, 0x0

    iget-object v1, p0, LC/x0;->b:Ljava/lang/Object;

    const/4 v2, 0x1

    iget v3, p0, LC/x0;->a:I

    packed-switch v3, :pswitch_data_b8

    check-cast p1, Landroidx/activity/result/ActivityResult;

    iget p1, p1, Landroidx/activity/result/ActivityResult;->a:I

    const/4 v0, -0x1

    check-cast v1, Lye/d;

    if-ne p1, v0, :cond_18

    iget-object p1, v1, Lye/d;->d:LHc/a;

    invoke-interface {p1}, LHc/a;->invoke()Ljava/lang/Object;

    goto :goto_1f

    :cond_18
    iget-object p1, v1, Lye/d;->f:LHc/b;

    const-string v0, "User Cancelled Pin or Pattern"

    invoke-interface {p1, v0}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1f
    return-void

    :pswitch_20
    check-cast p1, Ljava/util/List;

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    xor-int/2addr v2, v3

    check-cast v1, Lwe/X;

    if-eqz v2, :cond_39

    iget-object v1, v1, Lwe/X;->W0:Landroid/webkit/ValueCallback;

    if-eqz v1, :cond_41

    new-array v0, v0, [Landroid/net/Uri;

    invoke-interface {p1, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    invoke-interface {v1, p1}, Landroid/webkit/ValueCallback;->onReceiveValue(Ljava/lang/Object;)V

    goto :goto_41

    :cond_39
    iget-object p1, v1, Lwe/X;->W0:Landroid/webkit/ValueCallback;

    if-eqz p1, :cond_41

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Landroid/webkit/ValueCallback;->onReceiveValue(Ljava/lang/Object;)V

    :cond_41
    :goto_41
    return-void

    :pswitch_42
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    sget v3, Lcom/moengage/pushbase/internal/activity/PermissionActivity;->H:I

    check-cast v1, Lcom/moengage/pushbase/internal/activity/PermissionActivity;

    const-string v3, "this$0"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_51
    invoke-static {}, Lp9/c;->a()Ljava/util/concurrent/ExecutorService;

    move-result-object v3

    new-instance v4, Lya/h;

    invoke-direct {v4, p1}, Lya/h;-><init>(Z)V

    invoke-interface {v3, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_5d
    .catchall {:try_start_51 .. :try_end_5d} :catchall_81

    const/4 v3, 0x3

    const-string v4, "applicationContext"

    if-eqz p1, :cond_83

    :try_start_62
    sget-object p1, Lw9/g;->d:Lsa/x;

    new-instance p1, Le/s;

    const/16 v5, 0x15

    invoke-direct {p1, v5, v1}, Le/s;-><init>(ILjava/lang/Object;)V

    invoke-static {v0, p1, v3}, LW4/c;->h(ILHc/a;I)V

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1, v4}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v4

    invoke-static {p1, v4}, Lm7/l3;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    goto :goto_a1

    :catchall_81
    move-exception p1

    goto :goto_ad

    :cond_83
    sget-object p1, Lw9/g;->d:Lsa/x;

    new-instance p1, Lkd/g;

    const/16 v5, 0x10

    invoke-direct {p1, v5, v1}, Lkd/g;-><init>(ILjava/lang/Object;)V

    invoke-static {v0, p1, v3}, LW4/c;->h(ILHc/a;I)V

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1, v4}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v4

    invoke-static {p1, v4}, Lm7/l3;->b(Landroid/content/Context;Landroid/os/Bundle;)V

    :goto_a1
    new-instance p1, Lua/a;

    invoke-direct {p1, v1, v2}, Lua/a;-><init>(Lcom/moengage/pushbase/internal/activity/PermissionActivity;I)V

    invoke-static {v0, p1, v3}, LW4/c;->h(ILHc/a;I)V

    invoke-virtual {v1}, Landroid/app/Activity;->finish()V
    :try_end_ac
    .catchall {:try_start_62 .. :try_end_ac} :catchall_81

    goto :goto_b7

    :goto_ad
    sget-object v0, Lw9/g;->d:Lsa/x;

    new-instance v0, Lua/b;

    invoke-direct {v0, v1, v2}, Lua/b;-><init>(Lcom/moengage/pushbase/internal/activity/PermissionActivity;I)V

    invoke-static {v2, p1, v0}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    :goto_b7
    return-void

    :pswitch_data_b8
    .packed-switch 0xd
        :pswitch_42
        :pswitch_20
    .end packed-switch
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/lang/Void;

    sget-object p1, LN/l;->b:LN/l;

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, LN/e;

    invoke-virtual {v0, p1}, LN/e;->a(LN/l;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public b(Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/nozbe/watermelondb/WMDatabaseBridge;->i(Ljava/lang/String;Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public c()V
    .registers 6

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/nozbe/watermelondb/h;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const-string v3, "select * from sqlite_master where type=\'table\'"

    invoke-virtual {v0, v3, v2}, Lcom/nozbe/watermelondb/h;->c(Ljava/lang/String;[Ljava/lang/Object;)Landroid/database/Cursor;

    move-result-object v2

    :try_start_15
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    const-string v3, "name"

    invoke-interface {v2, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    const/4 v4, -0x1

    if-le v3, v4, :cond_31

    :cond_21
    invoke-interface {v2, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v4
    :try_end_2c
    .catchall {:try_start_15 .. :try_end_2c} :catchall_2f

    if-nez v4, :cond_21

    goto :goto_31

    :catchall_2f
    move-exception v0

    goto :goto_70

    :cond_31
    :goto_31
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_38
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "drop table if exists `"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "`"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/nozbe/watermelondb/h;->b(Ljava/lang/String;)V

    goto :goto_38

    :cond_5b
    const-string v1, "pragma writable_schema=1"

    invoke-virtual {v0, v1}, Lcom/nozbe/watermelondb/h;->b(Ljava/lang/String;)V

    const-string v1, "delete from sqlite_master where type in (\'table\', \'index\', \'trigger\')"

    invoke-virtual {v0, v1}, Lcom/nozbe/watermelondb/h;->b(Ljava/lang/String;)V

    const-string v1, "pragma user_version=0"

    invoke-virtual {v0, v1}, Lcom/nozbe/watermelondb/h;->b(Ljava/lang/String;)V

    const-string v1, "pragma writable_schema=0"

    invoke-virtual {v0, v1}, Lcom/nozbe/watermelondb/h;->b(Ljava/lang/String;)V

    return-void

    :goto_70
    if-eqz v2, :cond_7a

    :try_start_72
    invoke-interface {v2}, Landroid/database/Cursor;->close()V
    :try_end_75
    .catchall {:try_start_72 .. :try_end_75} :catchall_76

    goto :goto_7a

    :catchall_76
    move-exception v1

    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_7a
    :goto_7a
    throw v0
.end method

.method public d(LW0/E;)Lee/W;
    .registers 3

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Ly1/f;

    invoke-interface {v0, p1}, Ly1/f;->d(LW0/E;)Lee/W;

    move-result-object p1

    return-object p1
.end method

.method public e(Lio/sentry/Q0;)V
    .registers 9

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/replay/capture/t;

    const-string v1, "this$0"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "it"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lio/sentry/android/replay/capture/h;->h()Lio/sentry/protocol/y;

    move-result-object v1

    invoke-virtual {p1, v1}, Lio/sentry/Q0;->b(Lio/sentry/protocol/y;)V

    iget-object p1, p1, Lio/sentry/Q0;->e:Ljava/lang/String;

    if-eqz p1, :cond_21

    const/16 v1, 0x2e

    invoke-static {v1, p1, p1}, LZd/i;->V(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_1f
    move-object v4, p1

    goto :goto_23

    :cond_21
    const/4 p1, 0x0

    goto :goto_1f

    :goto_23
    sget-object p1, Lio/sentry/android/replay/capture/h;->r:[LOc/u;

    const/4 v1, 0x2

    aget-object p1, p1, v1

    iget-object v0, v0, Lio/sentry/android/replay/capture/h;->l:LW2/D;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "property"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, v0, LW2/D;->a:Ljava/lang/Object;

    check-cast p1, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1, v4}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_52

    new-instance p1, Lio/sentry/android/replay/capture/g;

    iget-object v1, v0, LW2/D;->c:Ljava/lang/Object;

    move-object v5, v1

    check-cast v5, Lio/sentry/android/replay/capture/h;

    const-string v6, "replay.screen-at-start"

    const-string v2, "replay.screen-at-start"

    move-object v1, p1

    invoke-direct/range {v1 .. v6}, Lio/sentry/android/replay/capture/g;-><init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Lio/sentry/android/replay/capture/h;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, LW2/D;->x(LHc/a;)V

    :cond_52
    return-void
.end method

.method public execute()Ljava/lang/Object;
    .registers 6

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Ly6/f;

    iget-object v0, v0, Ly6/f;->i:Lz6/c;

    check-cast v0, Lz6/o;

    invoke-virtual {v0}, Lz6/o;->a()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    :try_start_f
    const-string v2, "DELETE FROM log_event_dropped"

    invoke-virtual {v1, v2}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v2

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "UPDATE global_log_event_state SET last_metrics_upload_ms="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, Lz6/o;->b:LB6/a;

    invoke-interface {v0}, LB6/a;->a()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_36
    .catchall {:try_start_f .. :try_end_36} :catchall_3b

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    const/4 v0, 0x0

    return-object v0

    :catchall_3b
    move-exception v0

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw v0
.end method

.method public f(Lv7/i;)Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/Callable;

    invoke-static {v0, p1}, Lcom/google/firebase/crashlytics/internal/concurrency/CrashlyticsWorker;->b(Ljava/util/concurrent/Callable;Lv7/i;)Lv7/i;

    move-result-object p1

    return-object p1
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 3

    iget v0, p0, LC/x0;->a:I

    packed-switch v0, :pswitch_data_1e

    check-cast p1, Lg1/b;

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    invoke-interface {p1, v0}, Lg1/b;->C(Lg1/a;)V

    return-void

    :pswitch_f
    check-cast p1, LW0/O;

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/l0;

    iget-object v0, v0, Landroidx/media3/exoplayer/l0;->i:Lx1/x;

    iget-object v0, v0, Lx1/x;->d:LW0/b0;

    invoke-interface {p1, v0}, LW0/O;->K(LW0/b0;)V

    return-void

    nop

    :pswitch_data_1e
    .packed-switch 0x2
        :pswitch_f
    .end packed-switch
.end method

.method public n(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, LC/B0;

    iget-object v1, v0, LC/B0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_7
    iput-object p1, v0, LC/B0;->k:Landroidx/concurrent/futures/k;

    monitor-exit v1
    :try_end_a
    .catchall {:try_start_7 .. :try_end_a} :catchall_d

    const-string p1, "ProcessingImageReader-close"

    return-object p1

    :catchall_d
    move-exception p1

    :try_start_e
    monitor-exit v1
    :try_end_f
    .catchall {:try_start_e .. :try_end_f} :catchall_d

    throw p1
.end method

.method public onComplete(Lv7/i;)V
    .registers 5

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    iget v1, p0, LC/x0;->a:I

    packed-switch v1, :pswitch_data_40

    check-cast v0, Landroid/content/Context;

    const-string v1, "$context"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "task"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_13
    invoke-static {p1, v0}, Lm7/E4;->a(Lv7/i;Landroid/content/Context;)V
    :try_end_16
    .catchall {:try_start_13 .. :try_end_16} :catchall_17

    goto :goto_23

    :catchall_17
    move-exception p1

    sget-object v1, Lw9/g;->d:Lsa/x;

    sget-object v1, Lea/f;->c:Lea/f;

    const/4 v2, 0x1

    invoke-static {v2, p1, v1}, LW4/c;->g(ILjava/lang/Throwable;LHc/a;)V

    invoke-static {v0}, Lm7/E4;->c(Landroid/content/Context;)V

    :goto_23
    return-void

    :pswitch_24
    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v1

    check-cast v0, Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v2, 0x0

    if-eqz v1, :cond_37

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-interface {v0, v2, p1}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_3e

    :cond_37
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v0, p1, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_3e
    return-void

    nop

    :pswitch_data_40
    .packed-switch 0x3
        :pswitch_24
    .end packed-switch
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .registers 4

    const-string v0, "$tmp0"

    iget-object v1, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v1, LHc/b;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1, p1}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public then(Ljava/lang/Object;)Lv7/i;
    .registers 3

    iget-object v0, p0, LC/x0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;

    check-cast p1, Ljava/lang/Void;

    invoke-static {v0, p1}, Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;->g(Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;Ljava/lang/Void;)Lv7/i;

    move-result-object p1

    return-object p1
.end method
