.class public interface abstract LC/p;
.super Ljava/lang/Object;
.source "SourceFile"
