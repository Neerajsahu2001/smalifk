.class public final LC/n0;
.super LD/i;
.source "SourceFile"


# instance fields
.field public final synthetic a:LC/o0;


# direct methods
.method public constructor <init>(LC/o0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/n0;->a:LC/o0;

    return-void
.end method


# virtual methods
.method public final b(LD/n;)V
    .registers 8

    iget-object v0, p0, LC/n0;->a:LC/o0;

    iget-object v1, v0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    iget-boolean v2, v0, LC/o0;->e:Z

    if-eqz v2, :cond_d

    monitor-exit v1

    goto :goto_1f

    :catchall_b
    move-exception p1

    goto :goto_20

    :cond_d
    iget-object v2, v0, LC/o0;->i:Landroid/util/LongSparseArray;

    invoke-interface {p1}, LD/n;->c()J

    move-result-wide v3

    new-instance v5, LH/c;

    invoke-direct {v5, p1}, LH/c;-><init>(LD/n;)V

    invoke-virtual {v2, v3, v4, v5}, Landroid/util/LongSparseArray;->put(JLjava/lang/Object;)V

    invoke-virtual {v0}, LC/o0;->l()V

    monitor-exit v1

    :goto_1f
    return-void

    :goto_20
    monitor-exit v1
    :try_end_21
    .catchall {:try_start_5 .. :try_end_21} :catchall_b

    throw p1
.end method
