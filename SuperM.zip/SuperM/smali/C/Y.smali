.class public final LC/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LH/j;


# static fields
.field public static final b:LD/c;

.field public static final c:LD/c;

.field public static final d:LD/c;

.field public static final e:LD/c;

.field public static final f:LD/c;

.field public static final g:LD/c;

.field public static final h:LD/c;


# instance fields
.field public final a:LD/c0;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, LD/c;

    const-string v1, "camerax.core.appConfig.cameraFactoryProvider"

    const-class v2, Lu/a;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LC/y;->b:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.appConfig.deviceSurfaceManagerProvider"

    const-class v2, Lu/b;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LC/y;->c:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.appConfig.useCaseConfigFactoryProvider"

    const-class v2, Lu/a;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LC/y;->d:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.appConfig.cameraExecutor"

    const-class v2, Ljava/util/concurrent/Executor;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LC/y;->e:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.appConfig.schedulerHandler"

    const-class v2, Landroid/os/Handler;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LC/y;->f:LD/c;

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.appConfig.minimumLoggingLevel"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LC/y;->g:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.appConfig.availableCamerasLimiter"

    const-class v2, LC/q;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LC/y;->h:LD/c;

    return-void
.end method

.method public constructor <init>(LD/c0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/y;->a:LD/c0;

    return-void
.end method


# virtual methods
.method public final c()LC/q;
    .registers 3

    sget-object v0, LC/y;->h:LD/c;

    iget-object v1, p0, LC/y;->a:LD/c0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, LC/q;

    return-object v0
.end method

.method public final i()Lu/a;
    .registers 3

    sget-object v0, LC/y;->b:LD/c;

    iget-object v1, p0, LC/y;->a:LD/c0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Lu/a;

    return-object v0
.end method

.method public final k()Lu/b;
    .registers 3

    sget-object v0, LC/y;->c:LD/c;

    iget-object v1, p0, LC/y;->a:LD/c0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Lu/b;

    return-object v0
.end method

.method public final l()Lu/a;
    .registers 3

    sget-object v0, LC/y;->d:LD/c;

    iget-object v1, p0, LC/y;->a:LD/c0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Lu/a;

    return-object v0
.end method

.method public final p()LD/B;
    .registers 2

    iget-object v0, p0, LC/y;->a:LD/c0;

    return-object v0
.end method
