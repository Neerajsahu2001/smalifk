.class public final LC/f0;
.super LC/R0;
.source "SourceFile"


# static fields
.field public static final C:LC/c0;


# instance fields
.field public A:LC/M0;

.field public B:LC/e0;

.field public final l:LC/X;

.field public final m:Ljava/util/concurrent/Executor;

.field public final n:I

.field public final o:Ljava/util/concurrent/atomic/AtomicReference;

.field public final p:I

.field public q:Landroid/util/Rational;

.field public r:Ljava/util/concurrent/ExecutorService;

.field public s:LC/z;

.field public t:I

.field public u:LD/y;

.field public v:Z

.field public w:LD/k0;

.field public x:LC/F0;

.field public y:LC/B0;

.field public z:Ln8/r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LC/c0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LC/f0;->C:LC/c0;

    return-void
.end method

.method public constructor <init>(LD/L;)V
    .registers 5

    invoke-direct {p0, p1}, LC/R0;-><init>(LD/t0;)V

    new-instance p1, LC/X;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, LC/X;-><init>(I)V

    iput-object p1, p0, LC/f0;->l:LC/X;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, LC/f0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 p1, -0x1

    iput p1, p0, LC/f0;->p:I

    iput-object v0, p0, LC/f0;->q:Landroid/util/Rational;

    const/4 p1, 0x0

    iput-boolean p1, p0, LC/f0;->v:Z

    sget-object v0, LG/j;->b:LG/j;

    iput-object v0, p0, LC/f0;->z:Ln8/r;

    iget-object v0, p0, LC/R0;->f:LD/t0;

    check-cast v0, LD/L;

    sget-object v1, LD/L;->b:LD/c;

    invoke-interface {v0, v1}, LD/g0;->j(LD/c;)Z

    move-result v2

    if-eqz v2, :cond_38

    invoke-interface {v0, v1}, LD/g0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    iput v1, p0, LC/f0;->n:I

    goto :goto_3b

    :cond_38
    const/4 v1, 0x1

    iput v1, p0, LC/f0;->n:I

    :goto_3b
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    sget-object v1, LD/L;->j:LD/c;

    invoke-interface {v0, v1, p1}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    invoke-static {}, Lcom/bumptech/glide/c;->d()LF/j;

    move-result-object p1

    sget-object v1, LH/i;->w0:LD/c;

    invoke-interface {v0, v1, p1}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/concurrent/Executor;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, LC/f0;->m:Ljava/util/concurrent/Executor;

    new-instance v0, LF/m;

    invoke-direct {v0, p1}, LF/m;-><init>(Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public static B(ILjava/util/List;)Z
    .registers 4

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Pair;

    iget-object v0, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_20
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final A()I
    .registers 5

    iget-object v0, p0, LC/R0;->f:LD/t0;

    check-cast v0, LD/L;

    sget-object v1, LD/L;->k:LD/c;

    invoke-interface {v0, v1}, LD/g0;->j(LD/c;)Z

    move-result v2

    if-eqz v2, :cond_17

    invoke-interface {v0, v1}, LD/g0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    :cond_17
    iget v0, p0, LC/f0;->n:I

    if-eqz v0, :cond_33

    const/4 v1, 0x1

    if-eq v0, v1, :cond_30

    const/4 v1, 0x2

    if-ne v0, v1, :cond_22

    goto :goto_30

    :cond_22
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "CaptureMode "

    const-string v3, " is invalid"

    invoke-static {v0, v2, v3}, LA8/z;->d(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_30
    :goto_30
    const/16 v0, 0x5f

    return v0

    :cond_33
    const/16 v0, 0x64

    return v0
.end method

.method public final C()V
    .registers 5

    invoke-static {}, Lc8/c;->a()V

    iget-object v0, p0, LC/R0;->f:LD/t0;

    check-cast v0, LD/L;

    sget-object v1, LD/L;->h:LD/c;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Le/b;->p(Ljava/lang/Object;)V

    invoke-virtual {p0}, LC/R0;->a()Lw/s;

    move-result-object v1

    if-nez v1, :cond_18

    goto :goto_27

    :cond_18
    invoke-virtual {p0}, LC/R0;->a()Lw/s;

    move-result-object v1

    iget-object v1, v1, Lw/s;->t:LD/o;

    sget-object v3, LD/o;->d0:LD/c;

    invoke-interface {v1, v3, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Le/b;->p(Ljava/lang/Object;)V

    :goto_27
    iget-object v1, p0, LC/f0;->u:LD/y;

    if-eqz v1, :cond_2c

    return-void

    :cond_2c
    sget-object v1, LD/L;->d:LD/c;

    invoke-interface {v0, v1, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LC/z;

    const/4 v2, 0x1

    if-nez v1, :cond_39

    :goto_37
    move v1, v2

    goto :goto_42

    :cond_39
    iget-object v1, v1, LC/z;->a:Ljava/util/List;

    if-nez v1, :cond_3e

    goto :goto_37

    :cond_3e
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    :goto_42
    if-le v1, v2, :cond_45

    return-void

    :cond_45
    sget-object v1, LD/N;->f0:LD/c;

    const/16 v2, 0x100

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v1, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final D()V
    .registers 4

    iget-object v0, p0, LC/f0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LC/f0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_f

    monitor-exit v0

    return-void

    :catchall_d
    move-exception v1

    goto :goto_1c

    :cond_f
    invoke-virtual {p0}, LC/R0;->b()LD/q;

    move-result-object v1

    invoke-virtual {p0}, LC/f0;->z()I

    move-result v2

    invoke-interface {v1, v2}, LD/q;->d(I)V

    monitor-exit v0

    return-void

    :goto_1c
    monitor-exit v0
    :try_end_1d
    .catchall {:try_start_3 .. :try_end_1d} :catchall_d

    throw v1
.end method

.method public final d(ZLD/v0;)LD/t0;
    .registers 5

    iget v0, p0, LC/f0;->n:I

    const/4 v1, 0x1

    invoke-interface {p2, v1, v0}, LD/v0;->a(II)LD/B;

    move-result-object p2

    if-eqz p1, :cond_14

    sget-object p1, LC/f0;->C:LC/c0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, LC/c0;->a:LD/L;

    invoke-static {p2, p1}, LD/B;->w(LD/B;LD/B;)LD/c0;

    move-result-object p2

    :cond_14
    if-nez p2, :cond_18

    const/4 p1, 0x0

    goto :goto_2a

    :cond_18
    invoke-virtual {p0, p2}, LC/f0;->f(LD/B;)LD/s0;

    move-result-object p1

    check-cast p1, LC/b0;

    new-instance p2, LD/L;

    iget-object p1, p1, LC/b0;->a:LD/Z;

    invoke-static {p1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object p1

    invoke-direct {p2, p1}, LD/L;-><init>(LD/c0;)V

    move-object p1, p2

    :goto_2a
    return-object p1
.end method

.method public final f(LD/B;)LD/s0;
    .registers 3

    new-instance v0, LC/b0;

    invoke-static {p1}, LD/Z;->k(LD/B;)LD/Z;

    move-result-object p1

    invoke-direct {v0, p1}, LC/b0;-><init>(LD/Z;)V

    return-object v0
.end method

.method public final l()V
    .registers 6

    iget-object v0, p0, LC/R0;->f:LD/t0;

    check-cast v0, LD/L;

    sget-object v1, LD/t0;->q0:LD/c;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lw/x;

    if-eqz v1, :cond_6d

    new-instance v2, LD/w;

    invoke-direct {v2}, LD/w;-><init>()V

    invoke-virtual {v1, v0, v2}, Lw/x;->a(LD/t0;LD/w;)V

    invoke-virtual {v2}, LD/w;->d()LD/x;

    sget-object v1, LD/L;->e:LD/c;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LD/y;

    iput-object v1, p0, LC/f0;->u:LD/y;

    const/4 v1, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    sget-object v2, LD/L;->g:LD/c;

    invoke-interface {v0, v2, v1}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    iput v1, p0, LC/f0;->t:I

    invoke-static {}, Lcom/bumptech/glide/d;->c()LC/z;

    move-result-object v1

    sget-object v2, LD/L;->d:LD/c;

    invoke-interface {v0, v2, v1}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LC/z;

    iput-object v1, p0, LC/f0;->s:LC/z;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v2, LD/L;->i:LD/c;

    invoke-interface {v0, v2, v1}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, p0, LC/f0;->v:Z

    invoke-virtual {p0}, LC/R0;->a()Lw/s;

    move-result-object v0

    const-string v1, "Attached camera cannot be null"

    invoke-static {v0, v1}, Ll7/C5;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LC/a0;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LC/a0;-><init>(I)V

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, LC/f0;->r:Ljava/util/concurrent/ExecutorService;

    return-void

    :cond_6d
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Implementation is missing option unpacker for "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    sget-object v4, LH/j;->x0:LD/c;

    invoke-interface {v0, v4, v3}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final m()V
    .registers 1

    invoke-virtual {p0}, LC/f0;->D()V

    return-void
.end method

.method public final o()V
    .registers 5

    iget-object v0, p0, LC/f0;->z:Ln8/r;

    iget-object v1, p0, LC/f0;->B:LC/e0;

    if-eqz v1, :cond_12

    new-instance v1, LC/k;

    const-string v2, "Camera is closed."

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, LC/f0;->B:LC/e0;

    invoke-virtual {v2, v1}, LC/e0;->a(Ljava/lang/RuntimeException;)V

    :cond_12
    invoke-virtual {p0}, LC/f0;->w()V

    const/4 v1, 0x0

    iput-boolean v1, p0, LC/f0;->v:Z

    iget-object v1, p0, LC/f0;->r:Ljava/util/concurrent/ExecutorService;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, LC/Z;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v1}, LC/Z;-><init>(ILjava/lang/Object;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v1

    invoke-interface {v0, v2, v1}, Ln8/r;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public final p(Lw/u;LD/s0;)LD/t0;
    .registers 10

    invoke-interface {p2}, LD/s0;->d()LD/t0;

    move-result-object v0

    sget-object v1, LD/L;->e:LD/c;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "ImageCapture"

    if-eqz v0, :cond_28

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1d

    if-lt v0, v3, :cond_28

    const-string p1, "Requesting software JPEG due to a CaptureProcessor is set."

    invoke-static {v1, p1}, LHe/b;->f(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/L;->i:LD/c;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v3}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_63

    :cond_28
    iget-object p1, p1, Lw/u;->i:LI6/l;

    const-class v0, LJ/c;

    invoke-virtual {p1, v0}, LI6/l;->t(Ljava/lang/Class;)Z

    move-result p1

    if-eqz p1, :cond_63

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object v0

    sget-object v3, LD/L;->i:LD/c;

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    check-cast v0, LD/c0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_41
    invoke-virtual {v0, v3}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v4
    :try_end_45
    .catch Ljava/lang/IllegalArgumentException; {:try_start_41 .. :try_end_45} :catch_45

    :catch_45
    invoke-virtual {p1, v4}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_51

    const-string p1, "Device quirk suggests software JPEG encoder, but it has been explicitly disabled."

    invoke-static {v1, p1}, LHe/b;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_63

    :cond_51
    const-string p1, "Requesting software JPEG due to device quirk."

    invoke-static {v1, p1}, LHe/b;->f(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/L;->i:LD/c;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v3}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    :cond_63
    :goto_63
    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v3, LD/L;->i:LD/c;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    move-object v5, p1

    check-cast v5, LD/c0;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_73
    invoke-virtual {v5, v3}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v4
    :try_end_77
    .catch Ljava/lang/IllegalArgumentException; {:try_start_73 .. :try_end_77} :catch_77

    :catch_77
    invoke-virtual {v0, v4}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/16 v6, 0x100

    if-eqz v0, :cond_ac

    sget-object v0, LD/L;->f:LD/c;

    :try_start_83
    invoke-virtual {v5, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0
    :try_end_87
    .catch Ljava/lang/IllegalArgumentException; {:try_start_83 .. :try_end_87} :catch_88

    goto :goto_89

    :catch_88
    move-object v0, v2

    :goto_89
    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_9a

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-eq v0, v6, :cond_9a

    const-string v0, "Software JPEG cannot be used with non-JPEG output buffer format."

    invoke-static {v1, v0}, LHe/b;->i(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v3

    goto :goto_9b

    :cond_9a
    move v0, v4

    :goto_9b
    if-nez v0, :cond_ad

    const-string v5, "Unable to support software JPEG. Disabling."

    invoke-static {v1, v5}, LHe/b;->i(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v1, LD/L;->i:LD/c;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    check-cast p1, LD/Z;

    invoke-virtual {p1, v1, v5}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_ad

    :cond_ac
    move v0, v3

    :cond_ad
    :goto_ad
    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v1, LD/L;->f:LD/c;

    check-cast p1, LD/c0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_b8
    invoke-virtual {p1, v1}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object p1
    :try_end_bc
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b8 .. :try_end_bc} :catch_bd

    goto :goto_be

    :catch_bd
    move-object p1, v2

    :goto_be
    check-cast p1, Ljava/lang/Integer;

    const/16 v1, 0x23

    if-eqz p1, :cond_f5

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object v5

    sget-object v6, LD/L;->e:LD/c;

    check-cast v5, LD/c0;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_cf
    invoke-virtual {v5, v6}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v2
    :try_end_d3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_cf .. :try_end_d3} :catch_d3

    :catch_d3
    if-nez v2, :cond_d7

    move v2, v4

    goto :goto_d8

    :cond_d7
    move v2, v3

    :goto_d8
    const-string v5, "Cannot set buffer format with CaptureProcessor defined."

    invoke-static {v2, v5}, Ll7/C5;->b(ZLjava/lang/String;)V

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object v2

    sget-object v5, LD/N;->f0:LD/c;

    if-eqz v0, :cond_e6

    goto :goto_ea

    :cond_e6
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    :goto_ea
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    check-cast v2, LD/Z;

    invoke-virtual {v2, v5, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto/16 :goto_169

    :cond_f5
    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v5, LD/L;->e:LD/c;

    check-cast p1, LD/c0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_100
    invoke-virtual {p1, v5}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object p1
    :try_end_104
    .catch Ljava/lang/IllegalArgumentException; {:try_start_100 .. :try_end_104} :catch_105

    goto :goto_106

    :catch_105
    move-object p1, v2

    :goto_106
    if-nez p1, :cond_15a

    if-eqz v0, :cond_10b

    goto :goto_15a

    :cond_10b
    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/P;->m0:LD/c;

    check-cast p1, LD/c0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_116
    invoke-virtual {p1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v2
    :try_end_11a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_116 .. :try_end_11a} :catch_11a

    :catch_11a
    check-cast v2, Ljava/util/List;

    if-nez v2, :cond_12e

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/N;->f0:LD/c;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_169

    :cond_12e
    invoke-static {v6, v2}, LC/f0;->B(ILjava/util/List;)Z

    move-result p1

    if-eqz p1, :cond_144

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/N;->f0:LD/c;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_169

    :cond_144
    invoke-static {v1, v2}, LC/f0;->B(ILjava/util/List;)Z

    move-result p1

    if-eqz p1, :cond_169

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/N;->f0:LD/c;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_169

    :cond_15a
    :goto_15a
    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/N;->f0:LD/c;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    :cond_169
    :goto_169
    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/L;->g:LD/c;

    const/4 v1, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, LD/c0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_179
    invoke-virtual {p1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v1
    :try_end_17d
    .catch Ljava/lang/IllegalArgumentException; {:try_start_179 .. :try_end_17d} :catch_17d

    :catch_17d
    check-cast v1, Ljava/lang/Integer;

    const-string p1, "Maximum outstanding image count must be at least 1"

    invoke-static {v1, p1}, Ll7/C5;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-lt v0, v4, :cond_18b

    move v3, v4

    :cond_18b
    invoke-static {v3, p1}, Ll7/C5;->b(ZLjava/lang/String;)V

    invoke-interface {p2}, LD/s0;->d()LD/t0;

    move-result-object p1

    return-object p1
.end method

.method public final q()V
    .registers 3

    iget-object v0, p0, LC/f0;->B:LC/e0;

    if-eqz v0, :cond_10

    new-instance v0, LC/k;

    const-string v1, "Camera is closed."

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LC/f0;->B:LC/e0;

    invoke-virtual {v1, v0}, LC/e0;->a(Ljava/lang/RuntimeException;)V

    :cond_10
    return-void
.end method

.method public final r(Landroid/util/Size;)Landroid/util/Size;
    .registers 4

    invoke-virtual {p0}, LC/R0;->c()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, LC/R0;->f:LD/t0;

    check-cast v1, LD/L;

    invoke-virtual {p0, v0, v1, p1}, LC/f0;->x(Ljava/lang/String;LD/L;Landroid/util/Size;)LD/k0;

    move-result-object v0

    iput-object v0, p0, LC/f0;->w:LD/k0;

    invoke-virtual {v0}, LD/k0;->c()LD/n0;

    move-result-object v0

    invoke-virtual {p0, v0}, LC/R0;->v(LD/n0;)V

    const/4 v0, 0x1

    iput v0, p0, LC/R0;->c:I

    invoke-virtual {p0}, LC/R0;->j()V

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    invoke-virtual {p0}, LC/R0;->e()Ljava/lang/String;

    move-result-object v0

    const-string v1, "ImageCapture:"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final w()V
    .registers 5

    invoke-static {}, Lc8/c;->a()V

    invoke-virtual {p0}, LC/f0;->C()V

    iget-object v0, p0, LC/f0;->B:LC/e0;

    const/4 v1, 0x0

    if-eqz v0, :cond_17

    new-instance v2, Ljava/util/concurrent/CancellationException;

    const-string v3, "Request is canceled."

    invoke-direct {v2, v3}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, LC/e0;->a(Ljava/lang/RuntimeException;)V

    iput-object v1, p0, LC/f0;->B:LC/e0;

    :cond_17
    iget-object v0, p0, LC/f0;->A:LC/M0;

    iput-object v1, p0, LC/f0;->A:LC/M0;

    iput-object v1, p0, LC/f0;->x:LC/F0;

    iput-object v1, p0, LC/f0;->y:LC/B0;

    sget-object v1, LG/j;->b:LG/j;

    iput-object v1, p0, LC/f0;->z:Ln8/r;

    if-eqz v0, :cond_28

    invoke-virtual {v0}, LD/F;->a()V

    :cond_28
    return-void
.end method

.method public final x(Ljava/lang/String;LD/L;Landroid/util/Size;)LD/k0;
    .registers 19

    move-object v1, p0

    move-object/from16 v0, p2

    invoke-static {}, Lc8/c;->a()V

    invoke-virtual {p0}, LC/f0;->C()V

    invoke-static/range {p2 .. p2}, LD/k0;->d(LD/t0;)LD/k0;

    move-result-object v2

    iget v3, v1, LC/f0;->n:I

    const/4 v4, 0x2

    if-ne v3, v4, :cond_19

    invoke-virtual {p0}, LC/R0;->b()LD/q;

    move-result-object v3

    invoke-interface {v3, v2}, LD/q;->a(LD/k0;)V

    :cond_19
    sget-object v3, LD/L;->h:LD/c;

    const/4 v5, 0x0

    invoke-interface {v0, v3, v5}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Le/b;->p(Ljava/lang/Object;)V

    invoke-virtual {p0}, LC/R0;->a()Lw/s;

    move-result-object v3

    if-nez v3, :cond_2a

    goto :goto_39

    :cond_2a
    invoke-virtual {p0}, LC/R0;->a()Lw/s;

    move-result-object v3

    iget-object v3, v3, Lw/s;->t:LD/o;

    sget-object v6, LD/o;->d0:LD/c;

    invoke-interface {v3, v6, v5}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Le/b;->p(Ljava/lang/Object;)V

    :goto_39
    iget-object v3, v1, LC/f0;->u:LD/y;

    if-nez v3, :cond_5f

    iget-boolean v6, v1, LC/f0;->v:Z

    if-eqz v6, :cond_42

    goto :goto_5f

    :cond_42
    new-instance v3, LC/o0;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    move-result v6

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    move-result v7

    iget-object v8, v1, LC/R0;->f:LD/t0;

    invoke-interface {v8}, LD/N;->q()I

    move-result v8

    invoke-direct {v3, v6, v7, v8, v4}, LC/o0;-><init>(IIII)V

    new-instance v4, LC/F0;

    invoke-direct {v4, v3}, LC/F0;-><init>(LD/T;)V

    iput-object v4, v1, LC/f0;->x:LC/F0;

    move-object v6, v5

    goto/16 :goto_ea

    :cond_5f
    :goto_5f
    iget-object v4, v1, LC/R0;->f:LD/t0;

    invoke-interface {v4}, LD/N;->q()I

    move-result v4

    iget-object v6, v1, LC/R0;->f:LD/t0;

    invoke-interface {v6}, LD/N;->q()I

    move-result v6

    iget-boolean v7, v1, LC/f0;->v:Z

    if-eqz v7, :cond_a3

    const-string v3, "ImageCapture"

    const-string v6, "Using software JPEG encoder."

    invoke-static {v3, v6}, LHe/b;->f(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v3, v1, LC/f0;->u:LD/y;

    if-eqz v3, :cond_91

    new-instance v3, LH/n;

    invoke-virtual {p0}, LC/f0;->A()I

    move-result v6

    iget v7, v1, LC/f0;->t:I

    invoke-direct {v3, v6, v7}, LH/n;-><init>(II)V

    new-instance v6, LC/C;

    iget-object v7, v1, LC/f0;->u:LD/y;

    iget v8, v1, LC/f0;->t:I

    iget-object v9, v1, LC/f0;->r:Ljava/util/concurrent/ExecutorService;

    invoke-direct {v6, v7, v8, v3, v9}, LC/C;-><init>(LD/y;ILH/n;Ljava/util/concurrent/Executor;)V

    goto :goto_9d

    :cond_91
    new-instance v3, LH/n;

    invoke-virtual {p0}, LC/f0;->A()I

    move-result v6

    iget v7, v1, LC/f0;->t:I

    invoke-direct {v3, v6, v7}, LH/n;-><init>(II)V

    move-object v6, v3

    :goto_9d
    const/16 v7, 0x100

    move-object v14, v6

    move-object v6, v3

    move-object v3, v14

    goto :goto_a5

    :cond_a3
    move v7, v6

    move-object v6, v5

    :goto_a5
    new-instance v8, LC/A0;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    move-result v9

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    move-result v10

    iget v11, v1, LC/f0;->t:I

    invoke-static {}, Lcom/bumptech/glide/d;->c()LC/z;

    move-result-object v12

    invoke-virtual {p0, v12}, LC/f0;->y(LC/z;)LC/z;

    move-result-object v12

    new-instance v13, LC/o0;

    invoke-direct {v13, v9, v10, v4, v11}, LC/o0;-><init>(IIII)V

    invoke-direct {v8, v13, v12, v3}, LC/A0;-><init>(LC/o0;LC/z;LD/y;)V

    iget-object v3, v1, LC/f0;->r:Ljava/util/concurrent/ExecutorService;

    iput-object v3, v8, LC/A0;->f:Ljava/lang/Object;

    iput v7, v8, LC/A0;->b:I

    new-instance v3, LC/B0;

    invoke-direct {v3, v8}, LC/B0;-><init>(LC/A0;)V

    iput-object v3, v1, LC/f0;->y:LC/B0;

    iget-object v4, v3, LC/B0;->a:Ljava/lang/Object;

    monitor-enter v4

    :try_start_d1
    iget-object v3, v3, LC/B0;->g:LD/T;

    instance-of v7, v3, LC/o0;

    if-eqz v7, :cond_e0

    check-cast v3, LC/o0;

    iget-object v3, v3, LC/o0;->b:LC/n0;

    monitor-exit v4

    goto :goto_e1

    :catchall_dd
    move-exception v0

    goto/16 :goto_1c4

    :cond_e0
    monitor-exit v4
    :try_end_e1
    .catchall {:try_start_d1 .. :try_end_e1} :catchall_dd

    :goto_e1
    new-instance v3, LC/F0;

    iget-object v4, v1, LC/f0;->y:LC/B0;

    invoke-direct {v3, v4}, LC/F0;-><init>(LD/T;)V

    iput-object v3, v1, LC/f0;->x:LC/F0;

    :goto_ea
    iget-object v3, v1, LC/f0;->B:LC/e0;

    if-eqz v3, :cond_f8

    new-instance v4, Ljava/util/concurrent/CancellationException;

    const-string v7, "Request is canceled."

    invoke-direct {v4, v7}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v4}, LC/e0;->a(Ljava/lang/RuntimeException;)V

    :cond_f8
    new-instance v3, LC/e0;

    new-instance v4, Lu/a;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    if-nez v6, :cond_102

    goto :goto_107

    :cond_102
    new-instance v5, Lu/a;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    :goto_107
    invoke-direct {v3, v4, v5}, LC/e0;-><init>(Lu/a;Lu/a;)V

    iput-object v3, v1, LC/f0;->B:LC/e0;

    iget-object v3, v1, LC/f0;->x:LC/F0;

    iget-object v4, v1, LC/f0;->l:LC/X;

    invoke-static {}, Lcom/bumptech/glide/c;->e()LF/f;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, LC/F0;->g(LD/S;Ljava/util/concurrent/Executor;)V

    iget-object v3, v1, LC/f0;->A:LC/M0;

    if-eqz v3, :cond_11e

    invoke-virtual {v3}, LD/F;->a()V

    :cond_11e
    new-instance v3, LC/M0;

    iget-object v4, v1, LC/f0;->x:LC/F0;

    invoke-virtual {v4}, LC/F0;->d()Landroid/view/Surface;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v5, Landroid/util/Size;

    iget-object v6, v1, LC/f0;->x:LC/F0;

    invoke-virtual {v6}, LC/F0;->getWidth()I

    move-result v6

    iget-object v7, v1, LC/f0;->x:LC/F0;

    invoke-virtual {v7}, LC/F0;->getHeight()I

    move-result v7

    invoke-direct {v5, v6, v7}, Landroid/util/Size;-><init>(II)V

    iget-object v6, v1, LC/R0;->f:LD/t0;

    invoke-interface {v6}, LD/N;->q()I

    move-result v6

    invoke-direct {v3, v4, v5, v6}, LC/M0;-><init>(Landroid/view/Surface;Landroid/util/Size;I)V

    iput-object v3, v1, LC/f0;->A:LC/M0;

    iget-object v3, v1, LC/f0;->y:LC/B0;

    if-eqz v3, :cond_187

    iget-object v4, v3, LC/B0;->a:Ljava/lang/Object;

    monitor-enter v4

    :try_start_14c
    iget-boolean v5, v3, LC/B0;->e:Z

    if-eqz v5, :cond_16d

    iget-boolean v5, v3, LC/B0;->f:Z

    if-nez v5, :cond_16d

    iget-object v3, v3, LC/B0;->o:Ln8/r;

    new-instance v5, LC/w0;

    const/4 v6, 0x0

    invoke-direct {v5, v6}, LC/w0;-><init>(I)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v6

    new-instance v7, LO8/c;

    const/4 v8, 0x4

    invoke-direct {v7, v8, v5}, LO8/c;-><init>(ILjava/lang/Object;)V

    invoke-static {v3, v7, v6}, LG/g;->h(Ln8/r;LG/a;Ljava/util/concurrent/Executor;)LG/c;

    move-result-object v3

    goto :goto_183

    :catchall_16b
    move-exception v0

    goto :goto_185

    :cond_16d
    iget-object v5, v3, LC/B0;->l:Landroidx/concurrent/futures/n;

    if-nez v5, :cond_17d

    new-instance v5, LC/x0;

    const/4 v6, 0x0

    invoke-direct {v5, v6, v3}, LC/x0;-><init>(ILjava/lang/Object;)V

    invoke-static {v5}, Lm7/U3;->a(Landroidx/concurrent/futures/l;)Landroidx/concurrent/futures/n;

    move-result-object v5

    iput-object v5, v3, LC/B0;->l:Landroidx/concurrent/futures/n;

    :cond_17d
    iget-object v3, v3, LC/B0;->l:Landroidx/concurrent/futures/n;

    invoke-static {v3}, LG/g;->f(Ln8/r;)Ln8/r;

    move-result-object v3

    :goto_183
    monitor-exit v4

    goto :goto_189

    :goto_185
    monitor-exit v4
    :try_end_186
    .catchall {:try_start_14c .. :try_end_186} :catchall_16b

    throw v0

    :cond_187
    sget-object v3, LG/j;->b:LG/j;

    :goto_189
    iput-object v3, v1, LC/f0;->z:Ln8/r;

    iget-object v3, v1, LC/f0;->A:LC/M0;

    iget-object v3, v3, LD/F;->e:Landroidx/concurrent/futures/n;

    invoke-static {v3}, LG/g;->f(Ln8/r;)Ln8/r;

    move-result-object v3

    iget-object v4, v1, LC/f0;->x:LC/F0;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v5, LC/d0;

    const/16 v6, 0x11

    invoke-direct {v5, v6, v4}, LC/d0;-><init>(ILjava/lang/Object;)V

    invoke-static {}, Lcom/bumptech/glide/c;->e()LF/f;

    move-result-object v4

    invoke-interface {v3, v5, v4}, Ln8/r;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    iget-object v3, v1, LC/f0;->A:LC/M0;

    invoke-static {v3}, LD/f;->a(LD/F;)LW2/l;

    move-result-object v3

    invoke-virtual {v3}, LW2/l;->c()LD/f;

    move-result-object v3

    iget-object v4, v2, LD/j0;->a:Ljava/util/LinkedHashSet;

    invoke-interface {v4, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    new-instance v3, LC/Y;

    move-object/from16 v4, p1

    move-object/from16 v5, p3

    invoke-direct {v3, p0, v4, v0, v5}, LC/Y;-><init>(LC/f0;Ljava/lang/String;LD/L;Landroid/util/Size;)V

    iget-object v0, v2, LD/j0;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v2

    :goto_1c4
    :try_start_1c4
    monitor-exit v4
    :try_end_1c5
    .catchall {:try_start_1c4 .. :try_end_1c5} :catchall_dd

    throw v0
.end method

.method public final y(LC/z;)LC/z;
    .registers 4

    iget-object v0, p0, LC/f0;->s:LC/z;

    iget-object v0, v0, LC/z;->a:Ljava/util/List;

    if-eqz v0, :cond_12

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_d

    goto :goto_12

    :cond_d
    new-instance p1, LC/z;

    invoke-direct {p1, v0}, LC/z;-><init>(Ljava/util/List;)V

    :cond_12
    :goto_12
    return-object p1
.end method

.method public final z()I
    .registers 5

    iget-object v0, p0, LC/f0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    monitor-enter v0

    :try_start_3
    iget v1, p0, LC/f0;->p:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_9

    goto :goto_1e

    :cond_9
    iget-object v1, p0, LC/R0;->f:LD/t0;

    check-cast v1, LD/L;

    const/4 v2, 0x2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    sget-object v3, LD/L;->c:LD/c;

    invoke-interface {v1, v3, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    :goto_1e
    monitor-exit v0

    return v1

    :catchall_20
    move-exception v1

    monitor-exit v0
    :try_end_22
    .catchall {:try_start_3 .. :try_end_22} :catchall_20

    throw v1
.end method
