.class public final synthetic LC/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/concurrent/futures/l;
.implements Lapp/notifee/core/interfaces/MethodCallResult;
.implements Lcom/nozbe/watermelondb/l;
.implements LZ0/m;
.implements Lio/sentry/R0;
.implements Lv7/d;
.implements LG/a;
.implements Lx1/o;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, LC/s;->a:I

    iput-object p2, p0, LC/s;->b:Ljava/lang/Object;

    iput-object p3, p0, LC/s;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LM/e;LC/v;)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, LC/s;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/s;->c:Ljava/lang/Object;

    iput-object p2, p0, LC/s;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lg1/a;Landroidx/media3/common/b;Landroidx/media3/exoplayer/g;)V
    .registers 4

    const/4 p3, 0x5

    iput p3, p0, LC/s;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/s;->b:Ljava/lang/Object;

    iput-object p2, p0, LC/s;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ln8/r;
    .registers 5

    check-cast p1, Ljava/util/List;

    iget-object v0, p0, LC/s;->b:Ljava/lang/Object;

    check-cast v0, Lw/e0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "["

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "] getSurface...done"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "SyncCaptureSessionBase"

    invoke-static {v1, v0}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_43

    invoke-interface {p1, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result p1

    iget-object v0, p0, LC/s;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LD/F;

    new-instance v0, LD/D;

    const-string v1, "Surface closed"

    invoke-direct {v0, v1, p1}, LD/D;-><init>(Ljava/lang/String;LD/F;)V

    new-instance p1, LG/h;

    invoke-direct {p1, v0}, LG/h;-><init>(Ljava/lang/Exception;)V

    goto :goto_5b

    :cond_43
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_57

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Unable to open capture session without surfaces"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    new-instance v0, LG/h;

    invoke-direct {v0, p1}, LG/h;-><init>(Ljava/lang/Exception;)V

    move-object p1, v0

    goto :goto_5b

    :cond_57
    invoke-static {p1}, LG/g;->e(Ljava/lang/Object;)LG/j;

    move-result-object p1

    :goto_5b
    return-object p1
.end method

.method public b(Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, LC/s;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, LC/s;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/bridge/ReadableArray;

    invoke-static {v0, v1, p1}, Lcom/nozbe/watermelondb/WMDatabaseBridge;->j(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public c(ILW0/W;[I)Lj8/q0;
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v9, p2

    const/4 v10, 0x1

    sget-object v1, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->k:Lj8/p0;

    iget-object v1, v0, LC/s;->c:Ljava/lang/Object;

    check-cast v1, [I

    aget v11, v1, p1

    iget-object v1, v0, LC/s;->b:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Lx1/k;

    iget v1, v12, LW0/Z;->i:I

    const v13, 0x7fffffff

    if-eq v1, v13, :cond_7f

    iget v2, v12, LW0/Z;->j:I

    if-ne v2, v13, :cond_1f

    goto/16 :goto_7f

    :cond_1f
    move v4, v13

    const/4 v3, 0x0

    :goto_21
    iget v5, v9, LW0/W;->a:I

    if-ge v3, v5, :cond_7d

    iget-object v5, v9, LW0/W;->d:[Landroidx/media3/common/b;

    aget-object v5, v5, v3

    iget v6, v5, Landroidx/media3/common/b;->t:I

    if-lez v6, :cond_78

    iget v7, v5, Landroidx/media3/common/b;->u:I

    if-lez v7, :cond_78

    iget-boolean v8, v12, LW0/Z;->k:Z

    if-eqz v8, :cond_44

    if-le v6, v7, :cond_39

    move v8, v10

    goto :goto_3a

    :cond_39
    const/4 v8, 0x0

    :goto_3a
    if-le v1, v2, :cond_3e

    move v15, v10

    goto :goto_3f

    :cond_3e
    const/4 v15, 0x0

    :goto_3f
    if-eq v8, v15, :cond_44

    move v8, v1

    move v15, v2

    goto :goto_46

    :cond_44
    move v15, v1

    move v8, v2

    :goto_46
    mul-int v14, v6, v8

    mul-int v13, v7, v15

    if-lt v14, v13, :cond_56

    new-instance v8, Landroid/graphics/Point;

    invoke-static {v13, v6}, LZ0/F;->g(II)I

    move-result v6

    invoke-direct {v8, v15, v6}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_60

    :cond_56
    new-instance v6, Landroid/graphics/Point;

    invoke-static {v14, v7}, LZ0/F;->g(II)I

    move-result v13

    invoke-direct {v6, v13, v8}, Landroid/graphics/Point;-><init>(II)V

    move-object v8, v6

    :goto_60
    iget v5, v5, Landroidx/media3/common/b;->t:I

    mul-int v6, v5, v7

    iget v13, v8, Landroid/graphics/Point;->x:I

    int-to-float v13, v13

    const v14, 0x3f7ae148    # 0.98f

    mul-float/2addr v13, v14

    float-to-int v13, v13

    if-lt v5, v13, :cond_78

    iget v5, v8, Landroid/graphics/Point;->y:I

    int-to-float v5, v5

    mul-float/2addr v5, v14

    float-to-int v5, v5

    if-lt v7, v5, :cond_78

    if-ge v6, v4, :cond_78

    move v4, v6

    :cond_78
    add-int/2addr v3, v10

    const v13, 0x7fffffff

    goto :goto_21

    :cond_7d
    move v13, v4

    goto :goto_82

    :cond_7f
    :goto_7f
    const v13, 0x7fffffff

    :goto_82
    invoke-static {}, Lj8/T;->w()Lj8/P;

    move-result-object v14

    const/4 v15, 0x0

    :goto_87
    iget v1, v9, LW0/W;->a:I

    if-ge v15, v1, :cond_be

    iget-object v1, v9, LW0/W;->d:[Landroidx/media3/common/b;

    aget-object v1, v1, v15

    invoke-virtual {v1}, Landroidx/media3/common/b;->b()I

    move-result v1

    const v8, 0x7fffffff

    if-eq v13, v8, :cond_a1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_9e

    if-gt v1, v13, :cond_9e

    goto :goto_a1

    :cond_9e
    const/16 v16, 0x0

    goto :goto_a3

    :cond_a1
    :goto_a1
    move/from16 v16, v10

    :goto_a3
    new-instance v7, Lx1/q;

    aget v6, p3, v15

    move-object v1, v7

    move/from16 v2, p1

    move-object/from16 v3, p2

    move v4, v15

    move-object v5, v12

    move-object v10, v7

    move v7, v11

    move/from16 v17, v8

    move/from16 v8, v16

    invoke-direct/range {v1 .. v8}, Lx1/q;-><init>(ILW0/W;ILx1/k;IIZ)V

    invoke-virtual {v14, v10}, Lj8/M;->a(Ljava/lang/Object;)V

    const/4 v1, 0x1

    add-int/2addr v15, v1

    move v10, v1

    goto :goto_87

    :cond_be
    invoke-virtual {v14}, Lj8/P;->i()Lj8/q0;

    move-result-object v1

    return-object v1
.end method

.method public e(Lio/sentry/Q0;)V
    .registers 6

    iget-object v0, p0, LC/s;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/internal/gestures/f;

    iget-object v1, p0, LC/s;->c:Ljava/lang/Object;

    check-cast v1, Lio/sentry/Q;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, p1, Lio/sentry/Q0;->o:Ljava/lang/Object;

    monitor-enter v2

    :try_start_e
    iget-object v3, p1, Lio/sentry/Q0;->b:Lio/sentry/Q;

    if-nez v3, :cond_16

    invoke-virtual {p1, v1}, Lio/sentry/Q0;->c(Lio/sentry/Q;)V

    goto :goto_2b

    :cond_16
    iget-object p1, v0, Lio/sentry/android/core/internal/gestures/f;->c:Lio/sentry/android/core/SentryAndroidOptions;

    invoke-virtual {p1}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object p1

    sget-object v0, Lio/sentry/y1;->DEBUG:Lio/sentry/y1;

    invoke-interface {v1}, Lio/sentry/Q;->getName()Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v3, "Transaction \'%s\' won\'t be bound to the Scope since there\'s one already in there."

    invoke-interface {p1, v0, v3, v1}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_2b
    monitor-exit v2

    return-void

    :catchall_2d
    move-exception p1

    monitor-exit v2
    :try_end_2f
    .catchall {:try_start_e .. :try_end_2f} :catchall_2d

    throw p1
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, LC/s;->a:I

    check-cast p1, Lg1/b;

    packed-switch v0, :pswitch_data_20

    iget-object v0, p0, LC/s;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, LC/s;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/media3/common/b;

    invoke-interface {p1, v0, v1}, Lg1/b;->i(Lg1/a;Landroidx/media3/common/b;)V

    return-void

    :pswitch_13
    iget-object v0, p0, LC/s;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, LC/s;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/media3/exoplayer/f;

    invoke-interface {p1, v0, v1}, Lg1/b;->p(Lg1/a;Landroidx/media3/exoplayer/f;)V

    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x4
        :pswitch_13
    .end packed-switch
.end method

.method public n(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .registers 11

    iget v0, p0, LC/s;->a:I

    packed-switch v0, :pswitch_data_5a

    iget-object v0, p0, LC/s;->c:Ljava/lang/Object;

    check-cast v0, LM/e;

    iget-object v1, p0, LC/s;->b:Ljava/lang/Object;

    check-cast v1, LC/v;

    iget-object v0, v0, LM/e;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_10
    sget-object v2, LG/j;->b:LG/j;

    invoke-static {v2}, LG/e;->a(Ln8/r;)LG/e;

    move-result-object v2

    new-instance v3, LB/a;

    const/4 v4, 0x2

    invoke-direct {v3, v4, v1}, LB/a;-><init>(ILjava/lang/Object;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v4

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v3, v4}, LG/g;->h(Ln8/r;LG/a;Ljava/util/concurrent/Executor;)LG/c;

    move-result-object v2

    new-instance v3, LB5/a;

    const/4 v4, 0x6

    invoke-direct {v3, v4, p1, v1}, LB5/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object p1

    invoke-static {v2, v3, p1}, LG/g;->a(Ln8/r;LG/d;Ljava/util/concurrent/Executor;)V

    monitor-exit v0
    :try_end_35
    .catchall {:try_start_10 .. :try_end_35} :catchall_38

    const-string p1, "ProcessCameraProvider-initializeCameraX"

    return-object p1

    :catchall_38
    move-exception p1

    :try_start_39
    monitor-exit v0
    :try_end_3a
    .catchall {:try_start_39 .. :try_end_3a} :catchall_38

    throw p1

    :pswitch_3b
    iget-object v0, p0, LC/s;->b:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, LC/v;

    iget-object v0, v2, LC/v;->d:Ljava/util/concurrent/Executor;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    new-instance v8, LC/t;

    iget-object v1, p0, LC/s;->c:Ljava/lang/Object;

    move-object v3, v1

    check-cast v3, Landroid/content/Context;

    move-object v1, v8

    move-object v4, v0

    move-object v5, p1

    invoke-direct/range {v1 .. v7}, LC/t;-><init>(LC/v;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/k;J)V

    invoke-interface {v0, v8}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const-string p1, "CameraX initInternal"

    return-object p1

    nop

    :pswitch_data_5a
    .packed-switch 0x0
        :pswitch_3b
    .end packed-switch
.end method

.method public onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V
    .registers 4

    check-cast p2, Landroid/os/Bundle;

    sget v0, Lapp/notifee/core/BlockStateBroadcastReceiver;->a:I

    if-eqz p1, :cond_19

    const-string p2, "BlockState"

    const-string v0, "Failed getting channel or channel group bundle, received error: "

    invoke-static {p2, v0, p1}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-static {}, LN2/l;->a()LN2/k;

    move-result-object p1

    iget-object p2, p0, LC/s;->b:Ljava/lang/Object;

    check-cast p2, Landroidx/concurrent/futures/k;

    invoke-virtual {p2, p1}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    goto :goto_20

    :cond_19
    iget-object p1, p0, LC/s;->c:Ljava/lang/Object;

    check-cast p1, Lb3/a;

    invoke-virtual {p1, p2}, Lb3/a;->a(Ljava/lang/Object;)V

    :goto_20
    return-void
.end method

.method public onComplete(Lv7/i;)V
    .registers 4

    iget-object v0, p0, LC/s;->b:Ljava/lang/Object;

    check-cast v0, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;

    iget-object v1, p0, LC/s;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/bridge/Promise;

    invoke-static {v0, v1, p1}, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;->d(Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;Lcom/facebook/react/bridge/Promise;Lv7/i;)V

    return-void
.end method
