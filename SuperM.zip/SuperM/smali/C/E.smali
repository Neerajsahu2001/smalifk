.class public final LC/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:LC/f;


# direct methods
.method public constructor <init>(ILC/f;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_a

    iput p1, p0, LC/e;->a:I

    iput-object p2, p0, LC/e;->b:LC/f;

    return-void

    :cond_a
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null type"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LC/e;

    const/4 v2, 0x0

    if-eqz v1, :cond_27

    check-cast p1, LC/e;

    iget v1, p1, LC/e;->a:I

    iget v3, p0, LC/e;->a:I

    invoke-static {v3, v1}, Lw/q;->b(II)Z

    move-result v1

    if-eqz v1, :cond_25

    iget-object p1, p1, LC/e;->b:LC/f;

    iget-object v1, p0, LC/e;->b:LC/f;

    if-nez v1, :cond_1e

    if-nez p1, :cond_25

    goto :goto_26

    :cond_1e
    invoke-virtual {v1, p1}, LC/f;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_25

    goto :goto_26

    :cond_25
    move v0, v2

    :goto_26
    return v0

    :cond_27
    return v2
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, LC/e;->a:I

    invoke-static {v0}, Lw/q;->c(I)I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int/2addr v0, v1

    iget-object v1, p0, LC/e;->b:LC/f;

    if-nez v1, :cond_11

    const/4 v1, 0x0

    goto :goto_15

    :cond_11
    invoke-virtual {v1}, LC/f;->hashCode()I

    move-result v1

    :goto_15
    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "CameraState{type="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, LC/e;->a:I

    const/4 v2, 0x1

    if-eq v1, v2, :cond_27

    const/4 v2, 0x2

    if-eq v1, v2, :cond_24

    const/4 v2, 0x3

    if-eq v1, v2, :cond_21

    const/4 v2, 0x4

    if-eq v1, v2, :cond_1e

    const/4 v2, 0x5

    if-eq v1, v2, :cond_1b

    const-string v1, "null"

    goto :goto_29

    :cond_1b
    const-string v1, "CLOSED"

    goto :goto_29

    :cond_1e
    const-string v1, "CLOSING"

    goto :goto_29

    :cond_21
    const-string v1, "OPEN"

    goto :goto_29

    :cond_24
    const-string v1, "OPENING"

    goto :goto_29

    :cond_27
    const-string v1, "PENDING_OPEN"

    :goto_29
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", error="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LC/e;->b:LC/f;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
