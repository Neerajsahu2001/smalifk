.class public final LC/v0;
.super LC/R0;
.source "SourceFile"


# static fields
.field public static final q:LC/t0;

.field public static final r:LF/f;


# instance fields
.field public l:LC/u0;

.field public m:Ljava/util/concurrent/Executor;

.field public n:LD/F;

.field public o:LC/P0;

.field public p:Landroid/util/Size;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LC/t0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LC/v0;->q:LC/t0;

    invoke-static {}, Lcom/bumptech/glide/c;->e()LF/f;

    move-result-object v0

    sput-object v0, LC/v0;->r:LF/f;

    return-void
.end method


# virtual methods
.method public final d(ZLD/v0;)LD/t0;
    .registers 5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-interface {p2, v0, v1}, LD/v0;->a(II)LD/B;

    move-result-object p2

    if-eqz p1, :cond_13

    sget-object p1, LC/v0;->q:LC/t0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, LC/t0;->a:LD/e0;

    invoke-static {p2, p1}, LD/B;->w(LD/B;LD/B;)LD/c0;

    move-result-object p2

    :cond_13
    if-nez p2, :cond_17

    const/4 p1, 0x0

    goto :goto_29

    :cond_17
    invoke-virtual {p0, p2}, LC/v0;->f(LD/B;)LD/s0;

    move-result-object p1

    check-cast p1, LC/s0;

    new-instance p2, LD/e0;

    iget-object p1, p1, LC/s0;->a:LD/Z;

    invoke-static {p1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object p1

    invoke-direct {p2, p1}, LD/e0;-><init>(LD/c0;)V

    move-object p1, p2

    :goto_29
    return-object p1
.end method

.method public final f(LD/B;)LD/s0;
    .registers 3

    new-instance v0, LC/s0;

    invoke-static {p1}, LD/Z;->k(LD/B;)LD/Z;

    move-result-object p1

    invoke-direct {v0, p1}, LC/s0;-><init>(LD/Z;)V

    return-object v0
.end method

.method public final o()V
    .registers 3

    iget-object v0, p0, LC/v0;->n:LD/F;

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    invoke-virtual {v0}, LD/F;->a()V

    iput-object v1, p0, LC/v0;->n:LD/F;

    :cond_a
    iput-object v1, p0, LC/v0;->o:LC/P0;

    return-void
.end method

.method public final p(Lw/u;LD/s0;)LD/t0;
    .registers 5

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/e0;->c:LD/c;

    check-cast p1, LD/c0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_b
    invoke-virtual {p1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object p1
    :try_end_f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b .. :try_end_f} :catch_10

    goto :goto_11

    :catch_10
    const/4 p1, 0x0

    :goto_11
    if-eqz p1, :cond_25

    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/N;->f0:LD/c;

    const/16 v1, 0x23

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_36

    :cond_25
    invoke-interface {p2}, LC/D;->b()LD/Y;

    move-result-object p1

    sget-object v0, LD/N;->f0:LD/c;

    const/16 v1, 0x22

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, LD/Z;

    invoke-virtual {p1, v0, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    :goto_36
    invoke-interface {p2}, LD/s0;->d()LD/t0;

    move-result-object p1

    return-object p1
.end method

.method public final r(Landroid/util/Size;)Landroid/util/Size;
    .registers 5

    iput-object p1, p0, LC/v0;->p:Landroid/util/Size;

    invoke-virtual {p0}, LC/R0;->c()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, LC/R0;->f:LD/t0;

    check-cast v1, LD/e0;

    iget-object v2, p0, LC/v0;->p:Landroid/util/Size;

    invoke-virtual {p0, v0, v1, v2}, LC/v0;->w(Ljava/lang/String;LD/e0;Landroid/util/Size;)LD/k0;

    move-result-object v0

    invoke-virtual {v0}, LD/k0;->c()LD/n0;

    move-result-object v0

    invoke-virtual {p0, v0}, LC/R0;->v(LD/n0;)V

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    invoke-virtual {p0}, LC/R0;->e()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Preview:"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final u(Landroid/graphics/Rect;)V
    .registers 2

    iput-object p1, p0, LC/R0;->i:Landroid/graphics/Rect;

    invoke-virtual {p0}, LC/v0;->x()V

    return-void
.end method

.method public final w(Ljava/lang/String;LD/e0;Landroid/util/Size;)LD/k0;
    .registers 20

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    move-object/from16 v2, p3

    invoke-static {}, Lc8/c;->a()V

    invoke-static/range {p2 .. p2}, LD/k0;->d(LD/t0;)LD/k0;

    move-result-object v3

    sget-object v4, LD/e0;->c:LD/c;

    const/4 v5, 0x0

    invoke-interface {v0, v4, v5}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    move-object v12, v4

    check-cast v12, LD/y;

    iget-object v4, v1, LC/v0;->n:LD/F;

    if-eqz v4, :cond_20

    invoke-virtual {v4}, LD/F;->a()V

    iput-object v5, v1, LC/v0;->n:LD/F;

    :cond_20
    iput-object v5, v1, LC/v0;->o:LC/P0;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v6, LD/e0;->d:LD/c;

    invoke-interface {v0, v6, v4}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    new-instance v6, LC/P0;

    invoke-virtual/range {p0 .. p0}, LC/R0;->a()Lw/s;

    move-result-object v7

    invoke-direct {v6, v2, v7, v4}, LC/P0;-><init>(Landroid/util/Size;Lw/s;Z)V

    iput-object v6, v1, LC/v0;->o:LC/P0;

    iget-object v4, v1, LC/v0;->l:LC/u0;

    if-eqz v4, :cond_55

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v1, LC/v0;->o:LC/P0;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v8, v1, LC/v0;->m:Ljava/util/concurrent/Executor;

    new-instance v9, LB1/J;

    const/4 v10, 0x1

    invoke-direct {v9, v10, v4, v7}, LB1/J;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v8, v9}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    invoke-virtual/range {p0 .. p0}, LC/v0;->x()V

    :cond_55
    if-eqz v12, :cond_cc

    new-instance v11, LD/z;

    invoke-direct {v11}, LD/z;-><init>()V

    new-instance v4, Landroid/os/HandlerThread;

    const-string v5, "CameraX-preview_processing"

    invoke-direct {v4, v5}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    invoke-virtual {v11}, Ljava/lang/Object;->hashCode()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v5

    new-instance v15, LC/D0;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    move-result v7

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    move-result v8

    invoke-virtual/range {p2 .. p2}, LD/e0;->q()I

    move-result v9

    new-instance v10, Landroid/os/Handler;

    invoke-virtual {v4}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v13

    invoke-direct {v10, v13}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iget-object v6, v6, LC/P0;->i:Ljava/lang/Object;

    move-object v13, v6

    check-cast v13, LC/M0;

    move-object v6, v15

    move-object v14, v5

    invoke-direct/range {v6 .. v14}, LC/D0;-><init>(IIILandroid/os/Handler;LD/z;LD/y;LC/M0;Ljava/lang/String;)V

    iget-object v7, v15, LC/D0;->k:Ljava/lang/Object;

    monitor-enter v7

    :try_start_92
    iget-boolean v6, v15, LC/D0;->l:Z

    if-nez v6, :cond_c2

    iget-object v6, v15, LC/D0;->q:LC/n0;

    monitor-exit v7
    :try_end_99
    .catchall {:try_start_92 .. :try_end_99} :catchall_c0

    invoke-virtual {v3, v6}, LD/k0;->a(LD/i;)V

    iget-object v6, v15, LD/F;->e:Landroidx/concurrent/futures/n;

    invoke-static {v6}, LG/g;->f(Ln8/r;)Ln8/r;

    move-result-object v6

    new-instance v7, LC/q0;

    const/4 v8, 0x0

    invoke-direct {v7, v8, v4}, LC/q0;-><init>(ILjava/lang/Object;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v4

    invoke-interface {v6, v7, v4}, Ln8/r;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    iput-object v15, v1, LC/v0;->n:LD/F;

    const/4 v4, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget-object v6, v3, LD/j0;->b:LD/w;

    iget-object v6, v6, LD/w;->f:LD/a0;

    iget-object v6, v6, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v6, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_db

    :catchall_c0
    move-exception v0

    goto :goto_ca

    :cond_c2
    :try_start_c2
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "ProcessingSurface already released!"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_ca
    monitor-exit v7
    :try_end_cb
    .catchall {:try_start_c2 .. :try_end_cb} :catchall_c0

    throw v0

    :cond_cc
    sget-object v4, LD/e0;->b:LD/c;

    invoke-interface {v0, v4, v5}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Le/b;->p(Ljava/lang/Object;)V

    iget-object v4, v6, LC/P0;->i:Ljava/lang/Object;

    check-cast v4, LC/M0;

    iput-object v4, v1, LC/v0;->n:LD/F;

    :goto_db
    iget-object v4, v1, LC/v0;->l:LC/u0;

    if-eqz v4, :cond_e4

    iget-object v4, v1, LC/v0;->n:LD/F;

    invoke-virtual {v3, v4}, LD/k0;->b(LD/F;)V

    :cond_e4
    new-instance v4, LC/r0;

    move-object/from16 v5, p1

    invoke-direct {v4, v1, v5, v0, v2}, LC/r0;-><init>(LC/v0;Ljava/lang/String;LD/e0;Landroid/util/Size;)V

    iget-object v0, v3, LD/j0;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v3
.end method

.method public final x()V
    .registers 7

    invoke-virtual {p0}, LC/R0;->a()Lw/s;

    move-result-object v0

    iget-object v1, p0, LC/v0;->l:LC/u0;

    iget-object v2, p0, LC/v0;->p:Landroid/util/Size;

    iget-object v3, p0, LC/R0;->i:Landroid/graphics/Rect;

    const/4 v4, 0x0

    if-eqz v3, :cond_e

    goto :goto_1f

    :cond_e
    if-eqz v2, :cond_1e

    new-instance v3, Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/util/Size;->getWidth()I

    move-result v5

    invoke-virtual {v2}, Landroid/util/Size;->getHeight()I

    move-result v2

    invoke-direct {v3, v4, v4, v5, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    goto :goto_1f

    :cond_1e
    const/4 v3, 0x0

    :goto_1f
    iget-object v2, p0, LC/v0;->o:LC/P0;

    if-eqz v0, :cond_54

    if-eqz v1, :cond_54

    if-eqz v3, :cond_54

    if-eqz v2, :cond_54

    iget-object v1, p0, LC/R0;->f:LD/t0;

    check-cast v1, LD/P;

    invoke-interface {v1, v4}, LD/P;->D(I)I

    move-result v1

    iget-object v0, v0, Lw/s;->h:Lw/u;

    invoke-virtual {v0, v1}, Lw/u;->b(I)I

    move-result v0

    iget-object v1, p0, LC/R0;->f:LD/t0;

    check-cast v1, LD/P;

    const/4 v4, -0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    sget-object v5, LD/P;->i0:LD/c;

    invoke-interface {v1, v5, v4}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    new-instance v4, LC/i;

    invoke-direct {v4, v3, v0, v1}, LC/i;-><init>(Landroid/graphics/Rect;II)V

    invoke-virtual {v2, v4}, LC/P0;->i(LC/i;)V

    :cond_54
    return-void
.end method

.method public final y(LC/u0;)V
    .registers 4

    invoke-static {}, Lc8/c;->a()V

    if-nez p1, :cond_f

    const/4 p1, 0x0

    iput-object p1, p0, LC/v0;->l:LC/u0;

    const/4 p1, 0x2

    iput p1, p0, LC/R0;->c:I

    invoke-virtual {p0}, LC/R0;->j()V

    goto :goto_37

    :cond_f
    iput-object p1, p0, LC/v0;->l:LC/u0;

    sget-object p1, LC/v0;->r:LF/f;

    iput-object p1, p0, LC/v0;->m:Ljava/util/concurrent/Executor;

    const/4 p1, 0x1

    iput p1, p0, LC/R0;->c:I

    invoke-virtual {p0}, LC/R0;->j()V

    iget-object p1, p0, LC/R0;->g:Landroid/util/Size;

    if-eqz p1, :cond_37

    invoke-virtual {p0}, LC/R0;->c()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, LC/R0;->f:LD/t0;

    check-cast v0, LD/e0;

    iget-object v1, p0, LC/R0;->g:Landroid/util/Size;

    invoke-virtual {p0, p1, v0, v1}, LC/v0;->w(Ljava/lang/String;LD/e0;Landroid/util/Size;)LD/k0;

    move-result-object p1

    invoke-virtual {p1}, LD/k0;->c()LD/n0;

    move-result-object p1

    invoke-virtual {p0, p1}, LC/R0;->v(LD/n0;)V

    invoke-virtual {p0}, LC/R0;->i()V

    :cond_37
    :goto_37
    return-void
.end method
