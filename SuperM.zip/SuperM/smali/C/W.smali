.class public final LC/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC/D;


# instance fields
.field public final a:LD/Z;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object v0

    iput-object v0, p0, LC/w;->a:LD/Z;

    return-void
.end method

.method public constructor <init>(LD/Z;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/w;->a:LD/Z;

    sget-object v0, LH/j;->y0:LD/c;

    const/4 v1, 0x0

    :try_start_8
    invoke-virtual {p1, v0}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object p1
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_e

    :catch_d
    move-object p1, v1

    :goto_e
    check-cast p1, Ljava/lang/Class;

    const-class v0, LC/v;

    if-eqz p1, :cond_37

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1b

    goto :goto_37

    :cond_1b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid target class configuration for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_37
    :goto_37
    sget-object p1, LH/j;->y0:LD/c;

    iget-object v2, p0, LC/w;->a:LD/Z;

    invoke-virtual {v2, p1, v0}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object p1, LH/j;->x0:LD/c;

    :try_start_40
    invoke-virtual {v2, p1}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v1
    :try_end_44
    .catch Ljava/lang/IllegalArgumentException; {:try_start_40 .. :try_end_44} :catch_44

    :catch_44
    if-nez v1, :cond_67

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "-"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object v0, LH/j;->x0:LD/c;

    invoke-virtual {v2, v0, p1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    :cond_67
    return-void
.end method


# virtual methods
.method public a()Lv/a;
    .registers 4

    new-instance v0, Lv/a;

    iget-object v1, p0, LC/w;->a:LD/Z;

    invoke-static {v1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v1

    const/4 v2, 0x1

    invoke-direct {v0, v2, v1}, LA/d;-><init>(ILjava/lang/Object;)V

    return-object v0
.end method

.method public b()LD/Y;
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public c(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V
    .registers 4

    invoke-static {p1}, Lv/a;->a0(Landroid/hardware/camera2/CaptureRequest$Key;)LD/c;

    move-result-object p1

    iget-object v0, p0, LC/w;->a:LD/Z;

    invoke-virtual {v0, p1, p2}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    return-void
.end method
