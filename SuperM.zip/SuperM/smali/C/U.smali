.class public final synthetic LC/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:LC/v;

.field public final synthetic b:Ljava/util/concurrent/Executor;

.field public final synthetic c:J

.field public final synthetic d:Landroidx/concurrent/futures/k;


# direct methods
.method public synthetic constructor <init>(LC/v;Ljava/util/concurrent/Executor;JLandroidx/concurrent/futures/k;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC/u;->a:LC/v;

    iput-object p2, p0, LC/u;->b:Ljava/util/concurrent/Executor;

    iput-wide p3, p0, LC/u;->c:J

    iput-object p5, p0, LC/u;->d:Landroidx/concurrent/futures/k;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    iget-object v1, p0, LC/u;->a:LC/v;

    iget-object v2, v1, LC/v;->i:Landroid/content/Context;

    new-instance v7, LC/t;

    iget-object v8, p0, LC/u;->b:Ljava/util/concurrent/Executor;

    iget-object v4, p0, LC/u;->d:Landroidx/concurrent/futures/k;

    iget-wide v5, p0, LC/u;->c:J

    move-object v0, v7

    move-object v3, v8

    invoke-direct/range {v0 .. v6}, LC/t;-><init>(LC/v;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/k;J)V

    invoke-interface {v8, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
