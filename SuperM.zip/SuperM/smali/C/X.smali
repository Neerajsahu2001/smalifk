.class public interface abstract LC/x;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getCameraXConfig()LC/y;
.end method
