.class public abstract LD/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public a()V
    .registers 1

    return-void
.end method

.method public b(LD/n;)V
    .registers 2

    return-void
.end method

.method public c(LD/j;)V
    .registers 2

    return-void
.end method
