.class public interface abstract LD/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public a(LE/j;)V
    .registers 6

    invoke-interface {p0}, LD/n;->e()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_8

    goto :goto_59

    :cond_8
    invoke-static {v0}, Lw/q;->c(I)I

    move-result v2

    if-eq v2, v1, :cond_3e

    const/4 v3, 0x2

    if-eq v2, v3, :cond_3c

    const/4 v3, 0x3

    if-eq v2, v3, :cond_3a

    const/4 p1, 0x1

    if-eq v0, p1, :cond_2c

    const/4 p1, 0x2

    if-eq v0, p1, :cond_29

    const/4 p1, 0x3

    if-eq v0, p1, :cond_26

    const/4 p1, 0x4

    if-eq v0, p1, :cond_23

    const-string p1, "null"

    goto :goto_2e

    :cond_23
    const-string p1, "FIRED"

    goto :goto_2e

    :cond_26
    const-string p1, "READY"

    goto :goto_2e

    :cond_29
    const-string p1, "NONE"

    goto :goto_2e

    :cond_2c
    const-string p1, "UNKNOWN"

    :goto_2e
    const-string v0, "Unknown flash state: "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "ExifData"

    invoke-static {v0, p1}, LHe/b;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_59

    :cond_3a
    move v0, v1

    goto :goto_40

    :cond_3c
    const/4 v0, 0x0

    goto :goto_40

    :cond_3e
    const/16 v0, 0x20

    :goto_40
    and-int/lit8 v2, v0, 0x1

    iget-object v3, p1, LE/j;->a:Ljava/util/ArrayList;

    if-ne v2, v1, :cond_50

    const/4 v1, 0x4

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "LightSource"

    invoke-virtual {p1, v2, v1, v3}, LE/j;->c(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    :cond_50
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "Flash"

    invoke-virtual {p1, v1, v0, v3}, LE/j;->c(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    :goto_59
    return-void
.end method

.method public abstract b()LD/q0;
.end method

.method public abstract c()J
.end method

.method public abstract d()LD/m;
.end method

.method public abstract e()I
.end method

.method public abstract f()LD/k;
.end method

.method public abstract g()Landroid/hardware/camera2/CaptureResult;
.end method

.method public abstract h()LD/l;
.end method
