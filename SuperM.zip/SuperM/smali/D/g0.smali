.class public interface abstract LD/g0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/B;


# virtual methods
.method public a(LD/c;)Ljava/util/Set;
    .registers 3

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0, p1}, LD/B;->a(LD/c;)Ljava/util/Set;

    move-result-object p1

    return-object p1
.end method

.method public b(LB/h;)V
    .registers 3

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0, p1}, LD/B;->b(LB/h;)V

    return-void
.end method

.method public d()Ljava/util/Set;
    .registers 2

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0}, LD/B;->d()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public e(LD/c;LD/A;)Ljava/lang/Object;
    .registers 4

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0, p1, p2}, LD/B;->e(LD/c;LD/A;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public f(LD/c;)Ljava/lang/Object;
    .registers 3

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0, p1}, LD/B;->f(LD/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0, p1, p2}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public h(LD/c;)LD/A;
    .registers 3

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0, p1}, LD/B;->h(LD/c;)LD/A;

    move-result-object p1

    return-object p1
.end method

.method public j(LD/c;)Z
    .registers 3

    invoke-interface {p0}, LD/g0;->p()LD/B;

    move-result-object v0

    invoke-interface {v0, p1}, LD/B;->j(LD/c;)Z

    move-result p1

    return p1
.end method

.method public abstract p()LD/B;
.end method
