.class public final LD/x;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final h:LD/c;

.field public static final i:LD/c;


# instance fields
.field public final a:Ljava/util/List;

.field public final b:LD/B;

.field public final c:I

.field public final d:Ljava/util/List;

.field public final e:Z

.field public final f:LD/q0;

.field public final g:LD/n;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.captureConfig.rotation"

    const/4 v3, 0x0

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/x;->h:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.captureConfig.jpegQuality"

    const-class v2, Ljava/lang/Integer;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/x;->i:LD/c;

    return-void
.end method

.method public constructor <init>(Ljava/util/ArrayList;LD/c0;ILjava/util/List;ZLD/q0;LD/n;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/x;->a:Ljava/util/List;

    iput-object p2, p0, LD/x;->b:LD/B;

    iput p3, p0, LD/x;->c:I

    invoke-static {p4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LD/x;->d:Ljava/util/List;

    iput-boolean p5, p0, LD/x;->e:Z

    iput-object p6, p0, LD/x;->f:LD/q0;

    iput-object p7, p0, LD/x;->g:LD/n;

    return-void
.end method
