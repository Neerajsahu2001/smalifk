.class public final synthetic LD/b0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, LD/b0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 9

    iget v0, p0, LD/b0;->a:I

    packed-switch v0, :pswitch_data_b2

    check-cast p1, Lx1/q;

    check-cast p2, Lx1/q;

    iget-boolean v0, p1, Lx1/q;->e:Z

    if-eqz v0, :cond_14

    iget-boolean v0, p1, Lx1/q;->h:Z

    if-eqz v0, :cond_14

    sget-object v0, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->k:Lj8/p0;

    goto :goto_1a

    :cond_14
    sget-object v0, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->k:Lj8/p0;

    invoke-virtual {v0}, Lj8/p0;->a()Lj8/p0;

    move-result-object v0

    :goto_1a
    sget-object v1, Lj8/J;->a:Lj8/H;

    iget-object v2, p1, Lx1/q;->f:Lx1/k;

    iget-boolean v2, v2, LW0/Z;->y:Z

    iget v3, p1, Lx1/q;->j:I

    if-eqz v2, :cond_38

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v4, p2, Lx1/q;->j:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    sget-object v5, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;->k:Lj8/p0;

    invoke-virtual {v5}, Lj8/p0;->a()Lj8/p0;

    move-result-object v5

    invoke-virtual {v1, v2, v4, v5}, Lj8/H;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lj8/J;

    move-result-object v1

    :cond_38
    iget p1, p1, Lx1/q;->k:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget v2, p2, Lx1/q;->k:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, p1, v2, v0}, Lj8/J;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lj8/J;

    move-result-object p1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget p2, p2, Lx1/q;->j:I

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {p1, v1, p2, v0}, Lj8/J;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lj8/J;

    move-result-object p1

    invoke-virtual {p1}, Lj8/J;->e()I

    move-result p1

    return p1

    :pswitch_5b
    check-cast p1, Ljava/util/List;

    check-cast p2, Ljava/util/List;

    invoke-static {p1}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lx1/h;

    invoke-static {p2}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lx1/h;

    invoke-virtual {p1, p2}, Lx1/h;->c(Lx1/h;)I

    move-result p1

    return p1

    :pswitch_70
    check-cast p1, Li2/d;

    check-cast p2, Li2/d;

    iget-object p1, p1, Li2/d;->a:Li2/e;

    iget p1, p1, Li2/e;->b:I

    iget-object p2, p2, Li2/d;->a:Li2/e;

    iget p2, p2, Li2/e;->b:I

    invoke-static {p1, p2}, Ljava/lang/Integer;->compare(II)I

    move-result p1

    return p1

    :pswitch_81
    check-cast p1, Landroidx/media3/ui/L;

    check-cast p2, Landroidx/media3/ui/L;

    iget v0, p2, Landroidx/media3/ui/L;->a:I

    iget v1, p1, Landroidx/media3/ui/L;->a:I

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    if-eqz v0, :cond_90

    goto :goto_a3

    :cond_90
    iget-object v0, p2, Landroidx/media3/ui/L;->c:Ljava/lang/String;

    iget-object v1, p1, Landroidx/media3/ui/L;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_9b

    goto :goto_a3

    :cond_9b
    iget-object p2, p2, Landroidx/media3/ui/L;->d:Ljava/lang/String;

    iget-object p1, p1, Landroidx/media3/ui/L;->d:Ljava/lang/String;

    invoke-virtual {p2, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v0

    :goto_a3
    return v0

    :pswitch_a4
    check-cast p1, LD/c;

    check-cast p2, LD/c;

    iget-object p1, p1, LD/c;->a:Ljava/lang/String;

    iget-object p2, p2, LD/c;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    return p1

    nop

    :pswitch_data_b2
    .packed-switch 0x0
        :pswitch_a4
        :pswitch_81
        :pswitch_70
        :pswitch_5b
    .end packed-switch
.end method
