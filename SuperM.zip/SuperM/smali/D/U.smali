.class public final LD/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/core/view/d;


# instance fields
.field public a:I

.field public b:I

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Cloneable;


# virtual methods
.method public a()Landroidx/core/view/g;
    .registers 3

    new-instance v0, Landroidx/core/view/g;

    new-instance v1, Landroidx/core/view/f;

    invoke-direct {v1, p0}, Landroidx/core/view/f;-><init>(LD/u;)V

    invoke-direct {v0, v1}, Landroidx/core/view/g;-><init>(Landroidx/core/view/e;)V

    return-object v0
.end method

.method public b()V
    .registers 13

    const-string v0, "CameraStateRegistry"

    const/4 v1, 0x3

    invoke-static {v1, v0}, LHe/b;->h(ILjava/lang/String;)Z

    move-result v2

    const-string v3, "-------------------------------------------------------------------\n"

    const-string v4, "%-45s%-22s\n"

    const/4 v5, 0x0

    iget-object v6, p0, LD/u;->c:Ljava/lang/Object;

    check-cast v6, Ljava/lang/StringBuilder;

    if-eqz v2, :cond_2e

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    const-string v2, "Recalculating open cameras:\n"

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v7, "Camera"

    const-string v8, "State"

    filled-new-array {v7, v8}, [Ljava/lang/Object;

    move-result-object v7

    invoke-static {v2, v4, v7}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2e
    iget-object v2, p0, LD/u;->e:Ljava/lang/Cloneable;

    check-cast v2, Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move v7, v5

    :cond_3b
    :goto_3b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_8e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/Map$Entry;

    invoke-static {v1, v0}, LHe/b;->h(ILjava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_7d

    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LD/s;

    iget-object v9, v9, LD/s;->a:LD/r;

    if-eqz v9, :cond_64

    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LD/s;

    iget-object v9, v9, LD/s;->a:LD/r;

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    goto :goto_66

    :cond_64
    const-string v9, "UNKNOWN"

    :goto_66
    sget-object v10, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, LC/j;

    invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v11

    filled-new-array {v11, v9}, [Ljava/lang/Object;

    move-result-object v9

    invoke-static {v10, v4, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7d
    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LD/s;

    iget-object v8, v8, LD/s;->a:LD/r;

    if-eqz v8, :cond_3b

    iget-boolean v8, v8, LD/r;->a:Z

    if-eqz v8, :cond_3b

    add-int/lit8 v7, v7, 0x1

    goto :goto_3b

    :cond_8e
    invoke-static {v1, v0}, LHe/b;->h(ILjava/lang/String;)Z

    move-result v1

    iget v2, p0, LD/u;->a:I

    if-eqz v1, :cond_c0

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "Open count: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " (Max allowed: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_c0
    sub-int/2addr v2, v7

    invoke-static {v2, v5}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, LD/u;->b:I

    return-void
.end method

.method public c(Landroid/os/Bundle;)V
    .registers 2

    iput-object p1, p0, LD/u;->e:Ljava/lang/Cloneable;

    return-void
.end method

.method public d(LC/j;)Z
    .registers 14

    const-string v0, " --> "

    iget-object v1, p0, LD/u;->d:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    iget-object v2, p0, LD/u;->e:Ljava/lang/Cloneable;

    check-cast v2, Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LD/s;

    const-string v3, "Camera must first be registered with registerCamera()"

    invoke-static {v2, v3}, Ll7/C5;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CameraStateRegistry"

    const/4 v4, 0x3

    invoke-static {v4, v3}, LHe/b;->h(ILjava/lang/String;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v3, :cond_53

    iget-object v3, p0, LD/u;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v3, p0, LD/u;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/StringBuilder;

    sget-object v7, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v8, "tryOpenCamera(%s) [Available Cameras: %d, Already Open: %b (Previous state: %s)]"

    iget v9, p0, LD/u;->b:I

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    iget-object v10, v2, LD/s;->a:LD/r;

    if-eqz v10, :cond_3e

    iget-boolean v10, v10, LD/r;->a:Z

    if-eqz v10, :cond_3e

    move v10, v5

    goto :goto_3f

    :cond_3e
    move v10, v6

    :goto_3f
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v10

    iget-object v11, v2, LD/s;->a:LD/r;

    filled-new-array {p1, v9, v10, v11}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {v7, v8, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_53

    :catchall_51
    move-exception p1

    goto :goto_96

    :cond_53
    :goto_53
    iget p1, p0, LD/u;->b:I

    if-gtz p1, :cond_62

    iget-object p1, v2, LD/s;->a:LD/r;

    if-eqz p1, :cond_60

    iget-boolean p1, p1, LD/r;->a:Z

    if-eqz p1, :cond_60

    goto :goto_62

    :cond_60
    move v5, v6

    goto :goto_66

    :cond_62
    :goto_62
    sget-object p1, LD/r;->c:LD/r;

    iput-object p1, v2, LD/s;->a:LD/r;

    :goto_66
    const-string p1, "CameraStateRegistry"

    invoke-static {v4, p1}, LHe/b;->h(ILjava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_8f

    iget-object p1, p0, LD/u;->c:Ljava/lang/Object;

    check-cast p1, Ljava/lang/StringBuilder;

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    if-eqz v5, :cond_79

    const-string v2, "SUCCESS"

    goto :goto_7b

    :cond_79
    const-string v2, "FAIL"

    :goto_7b
    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "CameraStateRegistry"

    iget-object v0, p0, LD/u;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8f
    if-eqz v5, :cond_94

    invoke-virtual {p0}, LD/u;->b()V

    :cond_94
    monitor-exit v1

    return v5

    :goto_96
    monitor-exit v1
    :try_end_97
    .catchall {:try_start_5 .. :try_end_97} :catchall_51

    throw p1
.end method

.method public f(Landroid/net/Uri;)V
    .registers 2

    iput-object p1, p0, LD/u;->d:Ljava/lang/Object;

    return-void
.end method

.method public m(I)V
    .registers 2

    iput p1, p0, LD/u;->b:I

    return-void
.end method
