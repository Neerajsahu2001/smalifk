.class public interface abstract LD/h0;
.super Ljava/lang/Object;
.source "SourceFile"
