.class public interface abstract LD/q;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e0:Lm7/X4;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lm7/X4;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lm7/X4;-><init>(I)V

    sput-object v0, LD/q;->e0:Lm7/X4;

    return-void
.end method


# virtual methods
.method public abstract a(LD/k0;)V
.end method

.method public abstract d(I)V
.end method
