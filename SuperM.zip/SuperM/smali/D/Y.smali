.class public interface abstract LD/y;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(ILandroid/view/Surface;)V
.end method

.method public abstract b()Ln8/r;
.end method

.method public abstract c(Landroid/util/Size;)V
.end method

.method public abstract close()V
.end method

.method public abstract d(LD/Q;)V
.end method
