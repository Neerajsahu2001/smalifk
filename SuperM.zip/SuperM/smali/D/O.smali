.class public interface abstract LD/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/g0;


# static fields
.field public static final b0:LD/c;

.field public static final c0:LD/c;

.field public static final d0:LD/c;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, LD/c;

    const-string v1, "camerax.core.camera.useCaseConfigFactory"

    const-class v2, LD/v0;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/o;->b0:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.camera.useCaseCombinationRequiredRule"

    const-class v2, Ljava/lang/Integer;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/o;->c0:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.camera.SessionProcessor"

    const-class v2, Landroidx/camera/extensions/internal/sessionprocessor/a;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/o;->d0:LD/c;

    return-void
.end method
