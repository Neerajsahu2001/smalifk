.class public final LD/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LD/F;

.field public final b:Ljava/util/List;

.field public final c:Ljava/lang/String;

.field public final d:I


# direct methods
.method public constructor <init>(LD/F;Ljava/util/List;Ljava/lang/String;I)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/f;->a:LD/F;

    iput-object p2, p0, LD/f;->b:Ljava/util/List;

    iput-object p3, p0, LD/f;->c:Ljava/lang/String;

    iput p4, p0, LD/f;->d:I

    return-void
.end method

.method public static a(LD/F;)LW2/l;
    .registers 2

    new-instance v0, LW2/l;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    if-eqz p0, :cond_24

    iput-object p0, v0, LW2/l;->a:Ljava/lang/Object;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0

    if-eqz p0, :cond_1c

    iput-object p0, v0, LW2/l;->b:Ljava/lang/Object;

    const/4 p0, 0x0

    iput-object p0, v0, LW2/l;->c:Ljava/lang/Object;

    const/4 p0, -0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    iput-object p0, v0, LW2/l;->d:Ljava/lang/Object;

    return-object v0

    :cond_1c
    new-instance p0, Ljava/lang/NullPointerException;

    const-string v0, "Null sharedSurfaces"

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_24
    new-instance p0, Ljava/lang/NullPointerException;

    const-string v0, "Null surface"

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LD/f;

    const/4 v2, 0x0

    if-eqz v1, :cond_37

    check-cast p1, LD/f;

    iget-object v1, p1, LD/f;->a:LD/F;

    iget-object v3, p0, LD/f;->a:LD/F;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_35

    iget-object v1, p0, LD/f;->b:Ljava/util/List;

    iget-object v3, p1, LD/f;->b:Ljava/util/List;

    invoke-interface {v1, v3}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_35

    iget-object v1, p1, LD/f;->c:Ljava/lang/String;

    iget-object v3, p0, LD/f;->c:Ljava/lang/String;

    if-nez v3, :cond_28

    if-nez v1, :cond_35

    goto :goto_2e

    :cond_28
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_35

    :goto_2e
    iget v1, p0, LD/f;->d:I

    iget p1, p1, LD/f;->d:I

    if-ne v1, p1, :cond_35

    goto :goto_36

    :cond_35
    move v0, v2

    :goto_36
    return v0

    :cond_37
    return v2
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, LD/f;->a:LD/F;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int/2addr v0, v1

    iget-object v2, p0, LD/f;->b:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->hashCode()I

    move-result v2

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, LD/f;->c:Ljava/lang/String;

    if-nez v2, :cond_19

    const/4 v2, 0x0

    goto :goto_1d

    :cond_19
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_1d
    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget v1, p0, LD/f;->d:I

    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "OutputConfig{surface="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LD/f;->a:LD/F;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", sharedSurfaces="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LD/f;->b:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", physicalCameraId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LD/f;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", surfaceGroupId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LD/f;->d:I

    const-string v2, "}"

    invoke-static {v0, v1, v2}, LB4/d;->j(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
