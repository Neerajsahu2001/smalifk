.class public final LD/a0;
.super LD/q0;
.source "SourceFile"


# direct methods
.method public static a()LD/a0;
    .registers 2

    new-instance v0, LD/a0;

    new-instance v1, Landroid/util/ArrayMap;

    invoke-direct {v1}, Landroid/util/ArrayMap;-><init>()V

    invoke-direct {v0, v1}, LD/q0;-><init>(Landroid/util/ArrayMap;)V

    return-object v0
.end method
