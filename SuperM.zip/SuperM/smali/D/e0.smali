.class public final LD/e0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/t0;
.implements LD/P;
.implements LH/k;


# static fields
.field public static final b:LD/c;

.field public static final c:LD/c;

.field public static final d:LD/c;


# instance fields
.field public final a:LD/c0;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, LD/c;

    const-string v1, "camerax.core.preview.imageInfoProcessor"

    const-class v2, LD/M;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/e0;->b:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.preview.captureProcessor"

    const-class v2, LD/y;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/e0;->c:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.preview.isRgba8888SurfaceRequired"

    const-class v2, Ljava/lang/Boolean;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/e0;->d:LD/c;

    return-void
.end method

.method public constructor <init>(LD/c0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/e0;->a:LD/c0;

    return-void
.end method


# virtual methods
.method public final p()LD/B;
    .registers 2

    iget-object v0, p0, LD/e0;->a:LD/c0;

    return-object v0
.end method

.method public final q()I
    .registers 2

    sget-object v0, LD/N;->f0:LD/c;

    invoke-interface {p0, v0}, LD/g0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0
.end method
