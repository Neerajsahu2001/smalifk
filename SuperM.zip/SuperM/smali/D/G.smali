.class public final LD/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I


# direct methods
.method public constructor <init>(II)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_14

    iput p1, p0, LD/g;->a:I

    if-eqz p2, :cond_c

    iput p2, p0, LD/g;->b:I

    return-void

    :cond_c
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null configSize"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_14
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null configType"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static a(ILandroid/util/Size;LD/h;)LD/g;
    .registers 8

    const/16 v0, 0x23

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ne p0, v0, :cond_a

    move p0, v4

    goto :goto_17

    :cond_a
    const/16 v0, 0x100

    if-ne p0, v0, :cond_10

    move p0, v3

    goto :goto_17

    :cond_10
    const/16 v0, 0x20

    if-ne p0, v0, :cond_16

    move p0, v2

    goto :goto_17

    :cond_16
    move p0, v1

    :goto_17
    invoke-static {p1}, LL/a;->a(Landroid/util/Size;)I

    move-result p1

    iget-object v0, p2, LD/h;->a:Landroid/util/Size;

    invoke-static {v0}, LL/a;->a(Landroid/util/Size;)I

    move-result v0

    if-gt p1, v0, :cond_24

    goto :goto_39

    :cond_24
    iget-object v0, p2, LD/h;->b:Landroid/util/Size;

    invoke-static {v0}, LL/a;->a(Landroid/util/Size;)I

    move-result v0

    if-gt p1, v0, :cond_2e

    move v1, v4

    goto :goto_39

    :cond_2e
    iget-object p2, p2, LD/h;->c:Landroid/util/Size;

    invoke-static {p2}, LL/a;->a(Landroid/util/Size;)I

    move-result p2

    if-gt p1, p2, :cond_38

    move v1, v3

    goto :goto_39

    :cond_38
    move v1, v2

    :goto_39
    new-instance p1, LD/g;

    invoke-direct {p1, p0, v1}, LD/g;-><init>(II)V

    return-object p1
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LD/g;

    const/4 v2, 0x0

    if-eqz v1, :cond_22

    check-cast p1, LD/g;

    iget v1, p1, LD/g;->a:I

    iget v3, p0, LD/g;->a:I

    invoke-static {v3, v1}, Lw/q;->b(II)Z

    move-result v1

    if-eqz v1, :cond_20

    iget v1, p0, LD/g;->b:I

    iget p1, p1, LD/g;->b:I

    invoke-static {v1, p1}, Lw/q;->b(II)Z

    move-result p1

    if-eqz p1, :cond_20

    goto :goto_21

    :cond_20
    move v0, v2

    :goto_21
    return v0

    :cond_22
    return v2
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, LD/g;->a:I

    invoke-static {v0}, Lw/q;->c(I)I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int/2addr v0, v1

    iget v1, p0, LD/g;->b:I

    invoke-static {v1}, Lw/q;->c(I)I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "SurfaceConfig{configType="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, LD/g;->a:I

    const/4 v2, 0x1

    if-eq v1, v2, :cond_21

    const/4 v2, 0x2

    if-eq v1, v2, :cond_1e

    const/4 v2, 0x3

    if-eq v1, v2, :cond_1b

    const/4 v2, 0x4

    if-eq v1, v2, :cond_18

    const-string v1, "null"

    goto :goto_23

    :cond_18
    const-string v1, "RAW"

    goto :goto_23

    :cond_1b
    const-string v1, "JPEG"

    goto :goto_23

    :cond_1e
    const-string v1, "YUV"

    goto :goto_23

    :cond_21
    const-string v1, "PRIV"

    :goto_23
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", configSize="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LD/g;->b:I

    const/4 v2, 0x1

    if-eq v1, v2, :cond_4b

    const/4 v2, 0x2

    if-eq v1, v2, :cond_48

    const/4 v2, 0x3

    if-eq v1, v2, :cond_45

    const/4 v2, 0x4

    if-eq v1, v2, :cond_42

    const/4 v2, 0x5

    if-eq v1, v2, :cond_3f

    const-string v1, "null"

    goto :goto_4d

    :cond_3f
    const-string v1, "NOT_SUPPORT"

    goto :goto_4d

    :cond_42
    const-string v1, "MAXIMUM"

    goto :goto_4d

    :cond_45
    const-string v1, "RECORD"

    goto :goto_4d

    :cond_48
    const-string v1, "PREVIEW"

    goto :goto_4d

    :cond_4b
    const-string v1, "VGA"

    :goto_4d
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
