.class public final LD/k0;
.super LD/j0;
.source "SourceFile"


# direct methods
.method public static d(LD/t0;)LD/k0;
    .registers 12

    sget-object v0, LD/t0;->p0:LD/c;

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lw/A;

    if-eqz v0, :cond_125

    new-instance v0, LD/k0;

    invoke-direct {v0}, LD/j0;-><init>()V

    sget-object v2, LD/t0;->n0:LD/c;

    invoke-interface {p0, v2, v1}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LD/n0;

    sget-object v3, LD/c0;->c:LD/c0;

    invoke-static {}, LD/n0;->a()LD/n0;

    move-result-object v4

    iget-object v4, v4, LD/n0;->f:LD/x;

    iget v4, v4, LD/x;->c:I

    iget-object v5, v0, LD/j0;->d:Ljava/util/ArrayList;

    iget-object v6, v0, LD/j0;->c:Ljava/util/ArrayList;

    iget-object v7, v0, LD/j0;->b:LD/w;

    if-eqz v2, :cond_6f

    iget-object v3, v2, LD/n0;->f:LD/x;

    iget v4, v3, LD/x;->c:I

    iget-object v8, v2, LD/n0;->b:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_34
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_4b

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/hardware/camera2/CameraDevice$StateCallback;

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_47

    goto :goto_34

    :cond_47
    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_34

    :cond_4b
    iget-object v2, v2, LD/n0;->c:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_51
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_68

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_64

    goto :goto_51

    :cond_64
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_51

    :cond_68
    iget-object v2, v3, LD/x;->d:Ljava/util/List;

    invoke-virtual {v7, v2}, LD/w;->a(Ljava/util/Collection;)V

    iget-object v3, v3, LD/x;->b:LD/B;

    :cond_6f
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3}, LD/Z;->k(LD/B;)LD/Z;

    move-result-object v2

    iput-object v2, v7, LD/w;->b:LD/Z;

    new-instance v2, Lv/a;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    sget-object v3, Lv/a;->c:LD/c;

    invoke-interface {p0, v3, v2}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iput v2, v7, LD/w;->c:I

    new-instance v2, Lw/F;

    invoke-direct {v2}, Landroid/hardware/camera2/CameraDevice$StateCallback;-><init>()V

    sget-object v3, Lv/a;->e:LD/c;

    invoke-interface {p0, v3, v2}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/hardware/camera2/CameraDevice$StateCallback;

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a0

    goto :goto_a3

    :cond_a0
    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_a3
    new-instance v2, Lw/D;

    invoke-direct {v2}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;-><init>()V

    sget-object v3, Lv/a;->f:LD/c;

    invoke-interface {p0, v3, v2}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_b7

    goto :goto_ba

    :cond_b7
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_ba
    new-instance v2, Lw/w;

    invoke-direct {v2}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;-><init>()V

    sget-object v3, Lv/a;->g:LD/c;

    invoke-interface {p0, v3, v2}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    new-instance v3, Lw/H;

    invoke-direct {v3, v2}, Lw/H;-><init>(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)V

    invoke-virtual {v0, v3}, LD/k0;->a(LD/i;)V

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object v2

    sget-object v3, Lv/a;->h:LD/c;

    invoke-static {}, Lv/b;->a()Lv/b;

    move-result-object v4

    invoke-interface {p0, v3, v4}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lv/b;

    invoke-virtual {v2, v3, v4}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object v3, Lv/a;->j:LD/c;

    invoke-interface {p0, v3, v1}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v2, v3, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    sget-object v1, Lv/a;->d:LD/c;

    const-wide/16 v3, -0x1

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-interface {p0, v1, v3}, LD/B;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2, v1, v3}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    invoke-virtual {v7, v2}, LD/w;->c(LD/B;)V

    new-instance v1, LC5/p;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, LC5/p;-><init>(I)V

    new-instance v2, LB/h;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v1, p0}, LB/h;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {p0, v2}, LD/B;->b(LB/h;)V

    new-instance p0, LA/d;

    iget-object v1, v1, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, LD/Z;

    invoke-static {v1}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v1

    const/4 v2, 0x1

    invoke-direct {p0, v2, v1}, LA/d;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v7, p0}, LD/w;->c(LD/B;)V

    return-object v0

    :cond_125
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Implementation is missing option unpacker for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v3, LH/j;->x0:LD/c;

    invoke-interface {p0, v3, v2}, LD/g0;->g(LD/c;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public final a(LD/i;)V
    .registers 4

    iget-object v0, p0, LD/j0;->b:LD/w;

    invoke-virtual {v0, p1}, LD/w;->b(LD/i;)V

    iget-object v0, p0, LD/j0;->f:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_10
    return-void
.end method

.method public final b(LD/F;)V
    .registers 4

    invoke-static {p1}, LD/f;->a(LD/F;)LW2/l;

    move-result-object v0

    invoke-virtual {v0}, LW2/l;->c()LD/f;

    move-result-object v0

    iget-object v1, p0, LD/j0;->a:Ljava/util/LinkedHashSet;

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, LD/j0;->b:LD/w;

    iget-object v0, v0, LD/w;->a:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final c()LD/n0;
    .registers 10

    new-instance v8, LD/n0;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v0, p0, LD/j0;->a:Ljava/util/LinkedHashSet;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v2, p0, LD/j0;->c:Ljava/util/ArrayList;

    iget-object v3, p0, LD/j0;->d:Ljava/util/ArrayList;

    iget-object v4, p0, LD/j0;->f:Ljava/util/ArrayList;

    iget-object v5, p0, LD/j0;->e:Ljava/util/ArrayList;

    iget-object v0, p0, LD/j0;->b:LD/w;

    invoke-virtual {v0}, LD/w;->d()LD/x;

    move-result-object v6

    iget-object v7, p0, LD/j0;->g:Landroid/hardware/camera2/params/InputConfiguration;

    move-object v0, v8

    invoke-direct/range {v0 .. v7}, LD/n0;-><init>(Ljava/util/ArrayList;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;LD/x;Landroid/hardware/camera2/params/InputConfiguration;)V

    return-object v8
.end method
