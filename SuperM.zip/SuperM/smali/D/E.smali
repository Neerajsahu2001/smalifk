.class public abstract LD/e;
.super LD/d0;
.source "SourceFile"
