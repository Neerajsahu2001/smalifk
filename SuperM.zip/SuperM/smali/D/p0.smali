.class public final LD/p0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LD/p0;->a:Ljava/util/ArrayList;

    return-void
.end method

.method public static b(Ljava/util/ArrayList;I[II)V
    .registers 8

    array-length v0, p2

    if-lt p3, v0, :cond_d

    invoke-virtual {p2}, [I->clone()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [I

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_d
    const/4 v0, 0x0

    move v1, v0

    :goto_f
    if-ge v1, p1, :cond_26

    move v2, v0

    :goto_12
    if-ge v2, p3, :cond_1c

    aget v3, p2, v2

    if-ne v1, v3, :cond_19

    goto :goto_23

    :cond_19
    add-int/lit8 v2, v2, 0x1

    goto :goto_12

    :cond_1c
    aput v1, p2, p3

    add-int/lit8 v2, p3, 0x1

    invoke-static {p0, p1, p2, v2}, LD/p0;->b(Ljava/util/ArrayList;I[II)V

    :goto_23
    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_26
    return-void
.end method


# virtual methods
.method public final a(LD/g;)V
    .registers 3

    iget-object v0, p0, LD/p0;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method
