.class public final LD/m0;
.super LD/j0;
.source "SourceFile"


# static fields
.field public static final k:Ljava/util/List;


# instance fields
.field public final h:LA/e;

.field public i:Z

.field public j:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v1, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v0, v1, v2}, [Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, LD/m0;->k:Ljava/util/List;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, LD/j0;-><init>()V

    new-instance v0, LA/e;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, LA/e;-><init>(I)V

    iput-object v0, p0, LD/m0;->h:LA/e;

    const/4 v0, 0x1

    iput-boolean v0, p0, LD/m0;->i:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, LD/m0;->j:Z

    return-void
.end method


# virtual methods
.method public final a(LD/n0;)V
    .registers 9

    iget-object v0, p1, LD/n0;->f:LD/x;

    iget v1, v0, LD/x;->c:I

    const/4 v2, -0x1

    iget-object v3, p0, LD/j0;->b:LD/w;

    if-eq v1, v2, :cond_26

    const/4 v2, 0x1

    iput-boolean v2, p0, LD/m0;->j:Z

    iget v2, v3, LD/w;->c:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    sget-object v5, LD/m0;->k:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v5

    if-lt v4, v5, :cond_23

    goto :goto_24

    :cond_23
    move v1, v2

    :goto_24
    iput v1, v3, LD/w;->c:I

    :cond_26
    iget-object v1, p1, LD/n0;->f:LD/x;

    iget-object v2, v1, LD/x;->f:LD/q0;

    iget-object v4, v3, LD/w;->f:LD/a0;

    iget-object v4, v4, LD/q0;->a:Ljava/util/Map;

    if-eqz v4, :cond_37

    iget-object v2, v2, LD/q0;->a:Ljava/util/Map;

    if-eqz v2, :cond_37

    invoke-interface {v4, v2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    :cond_37
    iget-object v2, p0, LD/j0;->c:Ljava/util/ArrayList;

    iget-object v4, p1, LD/n0;->b:Ljava/util/List;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v2, p0, LD/j0;->d:Ljava/util/ArrayList;

    iget-object v4, p1, LD/n0;->c:Ljava/util/List;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v1, v1, LD/x;->d:Ljava/util/List;

    invoke-virtual {v3, v1}, LD/w;->a(Ljava/util/Collection;)V

    iget-object v1, p0, LD/j0;->f:Ljava/util/ArrayList;

    iget-object v2, p1, LD/n0;->d:Ljava/util/List;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, LD/j0;->e:Ljava/util/ArrayList;

    iget-object v2, p1, LD/n0;->e:Ljava/util/List;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p1, LD/n0;->g:Landroid/hardware/camera2/params/InputConfiguration;

    if-eqz v1, :cond_5e

    iput-object v1, p0, LD/j0;->g:Landroid/hardware/camera2/params/InputConfiguration;

    :cond_5e
    iget-object v1, p0, LD/j0;->a:Ljava/util/LinkedHashSet;

    iget-object p1, p1, LD/n0;->a:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    iget-object p1, v3, LD/w;->a:Ljava/util/HashSet;

    iget-object v2, v0, LD/x;->a:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    invoke-interface {p1, v2}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_79
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_a0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LD/f;

    iget-object v5, v4, LD/f;->a:LD/F;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v4, v4, LD/f;->b:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_90
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_79

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LD/F;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_90

    :cond_a0
    invoke-interface {v2, p1}, Ljava/util/List;->containsAll(Ljava/util/Collection;)Z

    move-result p1

    if-nez p1, :cond_b0

    const-string p1, "Invalid configuration due to capture request surfaces are not a subset of surfaces"

    const-string v1, "ValidatingBuilder"

    invoke-static {v1, p1}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, LD/m0;->i:Z

    :cond_b0
    iget-object p1, v0, LD/x;->b:LD/B;

    invoke-virtual {v3, p1}, LD/w;->c(LD/B;)V

    return-void
.end method

.method public final b()LD/n0;
    .registers 10

    iget-boolean v0, p0, LD/m0;->i:Z

    if-eqz v0, :cond_31

    new-instance v2, Ljava/util/ArrayList;

    iget-object v0, p0, LD/j0;->a:Ljava/util/LinkedHashSet;

    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v0, p0, LD/m0;->h:LA/e;

    iget-boolean v1, v0, LA/e;->a:Z

    if-nez v1, :cond_12

    goto :goto_1a

    :cond_12
    new-instance v1, LK/a;

    invoke-direct {v1, v0}, LK/a;-><init>(LA/e;)V

    invoke-static {v2, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_1a
    new-instance v0, LD/n0;

    iget-object v3, p0, LD/j0;->c:Ljava/util/ArrayList;

    iget-object v4, p0, LD/j0;->d:Ljava/util/ArrayList;

    iget-object v5, p0, LD/j0;->f:Ljava/util/ArrayList;

    iget-object v6, p0, LD/j0;->e:Ljava/util/ArrayList;

    iget-object v1, p0, LD/j0;->b:LD/w;

    invoke-virtual {v1}, LD/w;->d()LD/x;

    move-result-object v7

    iget-object v8, p0, LD/j0;->g:Landroid/hardware/camera2/params/InputConfiguration;

    move-object v1, v0

    invoke-direct/range {v1 .. v8}, LD/n0;-><init>(Ljava/util/ArrayList;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;LD/x;Landroid/hardware/camera2/params/InputConfiguration;)V

    return-object v0

    :cond_31
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Unsupported session configuration combination"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
