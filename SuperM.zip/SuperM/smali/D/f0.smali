.class public interface abstract LD/f0;
.super Ljava/lang/Object;
.source "SourceFile"
