.class public interface abstract LD/s0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC/D;


# virtual methods
.method public abstract d()LD/t0;
.end method
