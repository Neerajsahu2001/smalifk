.class public final LD/u0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/v0;


# virtual methods
.method public final a(II)LD/B;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method
