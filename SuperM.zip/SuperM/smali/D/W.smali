.class public final LD/w;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/HashSet;

.field public b:LD/Z;

.field public c:I

.field public final d:Ljava/util/ArrayList;

.field public e:Z

.field public final f:LD/a0;

.field public g:LD/n;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, LD/w;->a:Ljava/util/HashSet;

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object v0

    iput-object v0, p0, LD/w;->b:LD/Z;

    const/4 v0, -0x1

    iput v0, p0, LD/w;->c:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LD/w;->d:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, LD/w;->e:Z

    invoke-static {}, LD/a0;->a()LD/a0;

    move-result-object v0

    iput-object v0, p0, LD/w;->f:LD/a0;

    return-void
.end method

.method public constructor <init>(LD/x;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, LD/w;->a:Ljava/util/HashSet;

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object v1

    iput-object v1, p0, LD/w;->b:LD/Z;

    const/4 v1, -0x1

    iput v1, p0, LD/w;->c:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, LD/w;->d:Ljava/util/ArrayList;

    const/4 v2, 0x0

    iput-boolean v2, p0, LD/w;->e:Z

    invoke-static {}, LD/a0;->a()LD/a0;

    move-result-object v2

    iput-object v2, p0, LD/w;->f:LD/a0;

    iget-object v2, p1, LD/x;->a:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p1, LD/x;->b:LD/B;

    invoke-static {v0}, LD/Z;->k(LD/B;)LD/Z;

    move-result-object v0

    iput-object v0, p0, LD/w;->b:LD/Z;

    iget v0, p1, LD/x;->c:I

    iput v0, p0, LD/w;->c:I

    iget-object v0, p1, LD/x;->d:Ljava/util/List;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-boolean v0, p1, LD/x;->e:Z

    iput-boolean v0, p0, LD/w;->e:Z

    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iget-object p1, p1, LD/x;->f:LD/q0;

    iget-object v1, p1, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_4e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_64

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v3, p1, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4e

    :cond_64
    new-instance p1, LD/a0;

    invoke-direct {p1, v0}, LD/q0;-><init>(Landroid/util/ArrayMap;)V

    iput-object p1, p0, LD/w;->f:LD/a0;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/Collection;)V
    .registers 3

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_14

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LD/i;

    invoke-virtual {p0, v0}, LD/w;->b(LD/i;)V

    goto :goto_4

    :cond_14
    return-void
.end method

.method public final b(LD/i;)V
    .registers 4

    iget-object v0, p0, LD/w;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    return-void

    :cond_9
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final c(LD/B;)V
    .registers 7

    invoke-interface {p1}, LD/B;->d()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_67

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LD/c;

    iget-object v2, p0, LD/w;->b:LD/Z;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_19
    invoke-virtual {v2, v1}, LD/c0;->f(LD/c;)Ljava/lang/Object;

    move-result-object v2
    :try_end_1d
    .catch Ljava/lang/IllegalArgumentException; {:try_start_19 .. :try_end_1d} :catch_1e

    goto :goto_1f

    :catch_1e
    const/4 v2, 0x0

    :goto_1f
    invoke-interface {p1, v1}, LD/B;->f(LD/c;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v2, Lv/b;

    if-eqz v4, :cond_3f

    check-cast v2, Lv/b;

    check-cast v3, Lv/b;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v3, v3, Lv/b;->a:Ljava/util/HashSet;

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    iget-object v2, v2, Lv/b;->a:Ljava/util/HashSet;

    invoke-interface {v2, v1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    goto :goto_8

    :cond_3f
    instance-of v2, v3, Lv/b;

    if-eqz v2, :cond_5d

    check-cast v3, Lv/b;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lv/b;->a()Lv/b;

    move-result-object v2

    new-instance v4, Ljava/util/ArrayList;

    iget-object v3, v3, Lv/b;->a:Ljava/util/HashSet;

    invoke-direct {v4, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v3

    iget-object v4, v2, Lv/b;->a:Ljava/util/HashSet;

    invoke-interface {v4, v3}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    move-object v3, v2

    :cond_5d
    iget-object v2, p0, LD/w;->b:LD/Z;

    invoke-interface {p1, v1}, LD/B;->h(LD/c;)LD/A;

    move-result-object v4

    invoke-virtual {v2, v1, v4, v3}, LD/Z;->l(LD/c;LD/A;Ljava/lang/Object;)V

    goto :goto_8

    :cond_67
    return-void
.end method

.method public final d()LD/x;
    .registers 11

    new-instance v8, LD/x;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v0, p0, LD/w;->a:Ljava/util/HashSet;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v0, p0, LD/w;->b:LD/Z;

    invoke-static {v0}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object v2

    iget v3, p0, LD/w;->c:I

    iget-boolean v5, p0, LD/w;->e:Z

    sget-object v0, LD/q0;->b:LD/q0;

    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iget-object v4, p0, LD/w;->f:LD/a0;

    iget-object v6, v4, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v6}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_26
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_3c

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    iget-object v9, v4, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v9, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v0, v7, v9}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_26

    :cond_3c
    new-instance v6, LD/q0;

    invoke-direct {v6, v0}, LD/q0;-><init>(Landroid/util/ArrayMap;)V

    iget-object v7, p0, LD/w;->g:LD/n;

    iget-object v4, p0, LD/w;->d:Ljava/util/ArrayList;

    move-object v0, v8

    invoke-direct/range {v0 .. v7}, LD/x;-><init>(Ljava/util/ArrayList;LD/c0;ILjava/util/List;ZLD/q0;LD/n;)V

    return-object v8
.end method
