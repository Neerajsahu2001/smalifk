.class public abstract LD/p;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LA0/x;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LA0/x;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, LA0/x;-><init>(I)V

    sput-object v0, LD/p;->a:LA0/x;

    return-void
.end method
