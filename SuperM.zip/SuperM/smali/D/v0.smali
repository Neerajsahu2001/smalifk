.class public interface abstract LD/v0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LD/u0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LD/u0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LD/v0;->a:LD/u0;

    return-void
.end method


# virtual methods
.method public abstract a(II)LD/B;
.end method
