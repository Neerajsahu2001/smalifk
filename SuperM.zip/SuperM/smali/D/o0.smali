.class public interface abstract LD/o0;
.super Ljava/lang/Object;
.source "SourceFile"
