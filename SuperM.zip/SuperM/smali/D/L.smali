.class public final enum LD/l;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum a:LD/l;

.field public static final enum b:LD/l;

.field public static final enum c:LD/l;

.field public static final enum d:LD/l;

.field public static final enum e:LD/l;

.field public static final enum f:LD/l;

.field public static final enum g:LD/l;

.field public static final synthetic h:[LD/l;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    new-instance v0, LD/l;

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, LD/l;->a:LD/l;

    new-instance v1, LD/l;

    const-string v2, "INACTIVE"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, LD/l;->b:LD/l;

    new-instance v2, LD/l;

    const-string v3, "SCANNING"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, LD/l;->c:LD/l;

    new-instance v3, LD/l;

    const-string v4, "PASSIVE_FOCUSED"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LD/l;->d:LD/l;

    new-instance v4, LD/l;

    const-string v5, "PASSIVE_NOT_FOCUSED"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, LD/l;->e:LD/l;

    new-instance v5, LD/l;

    const-string v6, "LOCKED_FOCUSED"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LD/l;->f:LD/l;

    new-instance v6, LD/l;

    const-string v7, "LOCKED_NOT_FOCUSED"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, LD/l;->g:LD/l;

    filled-new-array/range {v0 .. v6}, [LD/l;

    move-result-object v0

    sput-object v0, LD/l;->h:[LD/l;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LD/l;
    .registers 2

    const-class v0, LD/l;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LD/l;

    return-object p0
.end method

.method public static values()[LD/l;
    .registers 1

    sget-object v0, LD/l;->h:[LD/l;

    invoke-virtual {v0}, [LD/l;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LD/l;

    return-object v0
.end method
