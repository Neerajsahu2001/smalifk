.class public final LD/s;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:LD/r;

.field public final b:Ljava/util/concurrent/Executor;

.field public final c:LD/t;


# direct methods
.method public constructor <init>(LF/m;Lw/p;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, LD/s;->a:LD/r;

    iput-object p1, p0, LD/s;->b:Ljava/util/concurrent/Executor;

    iput-object p2, p0, LD/s;->c:LD/t;

    return-void
.end method
