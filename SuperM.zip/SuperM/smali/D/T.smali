.class public interface abstract LD/t;
.super Ljava/lang/Object;
.source "SourceFile"
