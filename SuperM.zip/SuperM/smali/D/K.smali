.class public final enum LD/k;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum a:LD/k;

.field public static final enum b:LD/k;

.field public static final enum c:LD/k;

.field public static final enum d:LD/k;

.field public static final enum e:LD/k;

.field public static final enum f:LD/k;

.field public static final synthetic g:[LD/k;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    new-instance v0, LD/k;

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, LD/k;->a:LD/k;

    new-instance v1, LD/k;

    const-string v2, "INACTIVE"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, LD/k;->b:LD/k;

    new-instance v2, LD/k;

    const-string v3, "SEARCHING"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, LD/k;->c:LD/k;

    new-instance v3, LD/k;

    const-string v4, "FLASH_REQUIRED"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LD/k;->d:LD/k;

    new-instance v4, LD/k;

    const-string v5, "CONVERGED"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, LD/k;->e:LD/k;

    new-instance v5, LD/k;

    const-string v6, "LOCKED"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LD/k;->f:LD/k;

    filled-new-array/range {v0 .. v5}, [LD/k;

    move-result-object v0

    sput-object v0, LD/k;->g:[LD/k;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LD/k;
    .registers 2

    const-class v0, LD/k;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LD/k;

    return-object p0
.end method

.method public static values()[LD/k;
    .registers 1

    sget-object v0, LD/k;->g:[LD/k;

    invoke-virtual {v0}, [LD/k;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LD/k;

    return-object v0
.end method
