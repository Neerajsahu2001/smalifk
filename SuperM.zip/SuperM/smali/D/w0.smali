.class public final LD/w0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/t0;
.implements LD/P;
.implements LH/k;


# static fields
.field public static final b:LD/c;

.field public static final c:LD/c;

.field public static final d:LD/c;

.field public static final e:LD/c;

.field public static final f:LD/c;

.field public static final g:LD/c;

.field public static final h:LD/c;


# instance fields
.field public final a:LD/c0;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.videoCapture.recordingFrameRate"

    const/4 v3, 0x0

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/w0;->b:LD/c;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.videoCapture.bitRate"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/w0;->c:LD/c;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.videoCapture.intraFrameInterval"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/w0;->d:LD/c;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.videoCapture.audioBitRate"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/w0;->e:LD/c;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.videoCapture.audioSampleRate"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/w0;->f:LD/c;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.videoCapture.audioChannelCount"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/w0;->g:LD/c;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.videoCapture.audioMinBufferSize"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/w0;->h:LD/c;

    return-void
.end method

.method public constructor <init>(LD/c0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/w0;->a:LD/c0;

    return-void
.end method


# virtual methods
.method public final p()LD/B;
    .registers 2

    iget-object v0, p0, LD/w0;->a:LD/c0;

    return-object v0
.end method

.method public final q()I
    .registers 2

    const/16 v0, 0x22

    return v0
.end method
