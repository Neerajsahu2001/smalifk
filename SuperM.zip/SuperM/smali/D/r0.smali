.class public final LD/r0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LD/n0;

.field public final b:LD/t0;

.field public c:Z

.field public d:Z


# direct methods
.method public constructor <init>(LD/n0;LD/t0;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, LD/r0;->c:Z

    iput-boolean v0, p0, LD/r0;->d:Z

    iput-object p1, p0, LD/r0;->a:LD/n0;

    iput-object p2, p0, LD/r0;->b:LD/t0;

    return-void
.end method
