.class public final enum LD/r;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum b:LD/r;

.field public static final enum c:LD/r;

.field public static final enum d:LD/r;

.field public static final enum e:LD/r;

.field public static final enum f:LD/r;

.field public static final enum g:LD/r;

.field public static final enum h:LD/r;

.field public static final synthetic i:[LD/r;


# instance fields
.field public final a:Z


# direct methods
.method static constructor <clinit>()V
    .registers 10

    new-instance v0, LD/r;

    const-string v1, "PENDING_OPEN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, LD/r;-><init>(Ljava/lang/String;IZ)V

    sput-object v0, LD/r;->b:LD/r;

    new-instance v1, LD/r;

    const-string v3, "OPENING"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, LD/r;-><init>(Ljava/lang/String;IZ)V

    sput-object v1, LD/r;->c:LD/r;

    new-instance v3, LD/r;

    const-string v5, "OPEN"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v4}, LD/r;-><init>(Ljava/lang/String;IZ)V

    sput-object v3, LD/r;->d:LD/r;

    new-instance v5, LD/r;

    const-string v6, "CLOSING"

    const/4 v7, 0x3

    invoke-direct {v5, v6, v7, v4}, LD/r;-><init>(Ljava/lang/String;IZ)V

    sput-object v5, LD/r;->e:LD/r;

    new-instance v6, LD/r;

    const-string v7, "CLOSED"

    const/4 v8, 0x4

    invoke-direct {v6, v7, v8, v2}, LD/r;-><init>(Ljava/lang/String;IZ)V

    sput-object v6, LD/r;->f:LD/r;

    new-instance v7, LD/r;

    const-string v8, "RELEASING"

    const/4 v9, 0x5

    invoke-direct {v7, v8, v9, v4}, LD/r;-><init>(Ljava/lang/String;IZ)V

    sput-object v7, LD/r;->g:LD/r;

    new-instance v8, LD/r;

    const-string v4, "RELEASED"

    const/4 v9, 0x6

    invoke-direct {v8, v4, v9, v2}, LD/r;-><init>(Ljava/lang/String;IZ)V

    sput-object v8, LD/r;->h:LD/r;

    move-object v2, v3

    move-object v3, v5

    move-object v4, v6

    move-object v5, v7

    move-object v6, v8

    filled-new-array/range {v0 .. v6}, [LD/r;

    move-result-object v0

    sput-object v0, LD/r;->i:[LD/r;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;IZ)V
    .registers 4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-boolean p3, p0, LD/r;->a:Z

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LD/r;
    .registers 2

    const-class v0, LD/r;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LD/r;

    return-object p0
.end method

.method public static values()[LD/r;
    .registers 1

    sget-object v0, LD/r;->i:[LD/r;

    invoke-virtual {v0}, [LD/r;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LD/r;

    return-object v0
.end method
