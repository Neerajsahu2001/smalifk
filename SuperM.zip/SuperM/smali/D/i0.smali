.class public interface abstract LD/i0;
.super Ljava/lang/Object;
.source "SourceFile"
