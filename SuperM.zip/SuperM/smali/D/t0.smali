.class public interface abstract LD/t0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LH/j;
.implements LH/l;
.implements LD/N;


# static fields
.field public static final n0:LD/c;

.field public static final o0:LD/c;

.field public static final p0:LD/c;

.field public static final q0:LD/c;

.field public static final r0:LD/c;

.field public static final s0:LD/c;

.field public static final t0:LD/c;

.field public static final u0:LD/c;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, LD/c;

    const-string v1, "camerax.core.useCase.defaultSessionConfig"

    const-class v2, LD/n0;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/t0;->n0:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.useCase.defaultCaptureConfig"

    const-class v2, LD/x;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/t0;->o0:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.useCase.sessionConfigUnpacker"

    const-class v2, Lw/A;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/t0;->p0:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.useCase.captureConfigUnpacker"

    const-class v2, Lw/x;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/t0;->q0:LD/c;

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.useCase.surfaceOccupancyPriority"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/t0;->r0:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.useCase.cameraSelector"

    const-class v2, LC/q;

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/t0;->s0:LD/c;

    new-instance v0, LD/c;

    const-string v1, "camerax.core.useCase.targetFrameRate"

    invoke-direct {v0, v3, v2, v1}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v0, LD/t0;->t0:LD/c;

    sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    new-instance v1, LD/c;

    const-string v2, "camerax.core.useCase.zslDisabled"

    invoke-direct {v1, v3, v0, v2}, LD/c;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    sput-object v1, LD/t0;->u0:LD/c;

    return-void
.end method
