.class public final Lc4/d;
.super Lkotlin/jvm/internal/m;
.source "SourceFile"

# interfaces
.implements LHc/b;


# static fields
.field public static final a:Lc4/d;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lc4/d;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/m;-><init>(I)V

    sput-object v0, Lc4/d;->a:Lc4/d;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Lb4/A;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lb4/A;->y()V

    :cond_7
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
