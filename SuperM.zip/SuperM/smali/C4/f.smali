.class public final Lc4/f;
.super Lkotlin/jvm/internal/m;
.source "SourceFile"

# interfaces
.implements LHc/b;


# instance fields
.field public final synthetic a:F


# direct methods
.method public constructor <init>(F)V
    .registers 2

    iput p1, p0, Lc4/f;->a:F

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/m;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    check-cast p1, Lb4/A;

    if-eqz p1, :cond_1a

    iget v0, p0, Lc4/f;->a:F

    const/high16 v1, 0x447a0000    # 1000.0f

    mul-float/2addr v0, v1

    invoke-static {v0}, Ll7/H4;->c(F)I

    move-result v0

    int-to-long v0, v0

    iget-object p1, p1, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    if-eqz p1, :cond_1a

    invoke-virtual {p1}, Landroidx/media3/exoplayer/L;->t()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {p1, v2, v0, v1, v3}, Landroidx/media3/exoplayer/L;->i(IJZ)V

    :cond_1a
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
