.class public final LC4/h;
.super LC4/b;
.source "SourceFile"


# static fields
.field public static final e:Landroid/os/Handler;


# instance fields
.field public final d:Lcom/bumptech/glide/u;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    new-instance v2, LC4/g;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0, v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    sput-object v0, LC4/h;->e:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>(Lcom/bumptech/glide/u;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, v0}, LC4/b;-><init>(I)V

    iput-object p1, p0, LC4/h;->d:Lcom/bumptech/glide/u;

    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;)V
    .registers 3

    iget-object p1, p0, LC4/b;->c:LB4/c;

    if-eqz p1, :cond_14

    invoke-interface {p1}, LB4/c;->j()Z

    move-result p1

    if-eqz p1, :cond_14

    sget-object p1, LC4/h;->e:Landroid/os/Handler;

    const/4 v0, 0x1

    invoke-virtual {p1, v0, p0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    :cond_14
    return-void
.end method

.method public final i(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    return-void
.end method
