.class public final LC4/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Handler$Callback;


# virtual methods
.method public final handleMessage(Landroid/os/Message;)Z
    .registers 4

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_f

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, LC4/h;

    iget-object v0, p1, LC4/h;->d:Lcom/bumptech/glide/u;

    invoke-virtual {v0, p1}, Lcom/bumptech/glide/u;->p(LC4/j;)V

    return v1

    :cond_f
    const/4 p1, 0x0

    return p1
.end method
