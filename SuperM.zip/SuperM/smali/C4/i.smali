.class public interface abstract LC4/i;
.super Ljava/lang/Object;
.source "SourceFile"
