.class public interface abstract LC4/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly4/i;


# virtual methods
.method public abstract a(LC4/i;)V
.end method

.method public abstract b(Ljava/lang/Object;)V
.end method

.method public abstract d(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract f(LB4/c;)V
.end method

.method public abstract g(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract h()LB4/c;
.end method

.method public abstract i(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract k(LC4/i;)V
.end method
