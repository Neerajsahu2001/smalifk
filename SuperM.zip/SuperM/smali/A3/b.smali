.class public abstract La3/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "DiagnosticsWrkr"

    invoke-static {v0}, LN2/n;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "tagWithPrefix(\"DiagnosticsWrkr\")"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, La3/b;->a:Ljava/lang/String;

    return-void
.end method

.method public static final a(LW2/p;LW2/D;LW2/l;Ljava/util/ArrayList;)Ljava/lang/String;
    .registers 21

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\n Id \t Class Name\t Job Id\t State\t Unique Name\t Tags\t"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface/range {p3 .. p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_e3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LW2/w;

    invoke-static {v2}, Lm7/G2;->b(LW2/w;)LW2/m;

    move-result-object v3

    move-object/from16 v4, p2

    invoke-virtual {v4, v3}, LW2/l;->f(LW2/m;)LW2/h;

    move-result-object v3

    const/4 v5, 0x0

    if-eqz v3, :cond_2b

    iget v3, v3, LW2/h;->c:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_2c

    :cond_2b
    move-object v3, v5

    :goto_2c
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "SELECT name FROM workname WHERE work_spec_id=?"

    const/4 v7, 0x1

    invoke-static {v7, v6}, Ls2/m;->i(ILjava/lang/String;)Ls2/m;

    move-result-object v6

    iget-object v8, v2, LW2/w;->a:Ljava/lang/String;

    if-nez v8, :cond_40

    invoke-virtual {v6, v7}, Ls2/m;->S(I)V

    :goto_3d
    move-object/from16 v7, p0

    goto :goto_44

    :cond_40
    invoke-virtual {v6, v7, v8}, Ls2/m;->o(ILjava/lang/String;)V

    goto :goto_3d

    :goto_44
    iget-object v9, v7, LW2/p;->b:Ljava/lang/Object;

    check-cast v9, Ls2/k;

    invoke-virtual {v9}, Ls2/k;->b()V

    invoke-virtual {v9, v6, v5}, Ls2/k;->m(Ly2/e;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v9

    :try_start_4f
    new-instance v10, Ljava/util/ArrayList;

    invoke-interface {v9}, Landroid/database/Cursor;->getCount()I

    move-result v11

    invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(I)V

    :goto_58
    invoke-interface {v9}, Landroid/database/Cursor;->moveToNext()Z

    move-result v11

    if-eqz v11, :cond_71

    const/4 v11, 0x0

    invoke-interface {v9, v11}, Landroid/database/Cursor;->isNull(I)Z

    move-result v12

    if-eqz v12, :cond_67

    move-object v11, v5

    goto :goto_6b

    :cond_67
    invoke-interface {v9, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v11

    :goto_6b
    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_6e
    .catchall {:try_start_4f .. :try_end_6e} :catchall_6f

    goto :goto_58

    :catchall_6f
    move-exception v0

    goto :goto_dc

    :cond_71
    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    invoke-virtual {v6}, Ls2/m;->l()V

    const/4 v13, 0x0

    const/16 v15, 0x3e

    const-string v11, ","

    const/4 v12, 0x0

    const/4 v14, 0x0

    invoke-static/range {v10 .. v15}, Lvc/l;->F(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LHc/b;I)Ljava/lang/String;

    move-result-object v5

    move-object/from16 v10, p1

    invoke-virtual {v10, v8}, LW2/D;->p(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v11

    const/16 v16, 0x3e

    const-string v12, ","

    const/4 v15, 0x0

    invoke-static/range {v11 .. v16}, Lvc/l;->F(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LHc/b;I)Ljava/lang/String;

    move-result-object v6

    const-string v9, "\n"

    const-string v11, "\t "

    invoke-static {v9, v8, v11}, Le/b;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-object v9, v2, LW2/w;->c:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v2, LW2/w;->b:I

    packed-switch v2, :pswitch_data_ee

    const/4 v0, 0x0

    throw v0

    :pswitch_ae
    const-string v2, "CANCELLED"

    goto :goto_bf

    :pswitch_b1
    const-string v2, "BLOCKED"

    goto :goto_bf

    :pswitch_b4
    const-string v2, "FAILED"

    goto :goto_bf

    :pswitch_b7
    const-string v2, "SUCCEEDED"

    goto :goto_bf

    :pswitch_ba
    const-string v2, "RUNNING"

    goto :goto_bf

    :pswitch_bd
    const-string v2, "ENQUEUED"

    :goto_bf
    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x9

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_b

    :goto_dc
    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    invoke-virtual {v6}, Ls2/m;->l()V

    throw v0

    :cond_e3
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "StringBuilder().apply(builderAction).toString()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    nop

    :pswitch_data_ee
    .packed-switch 0x1
        :pswitch_bd
        :pswitch_ba
        :pswitch_b7
        :pswitch_b4
        :pswitch_b1
        :pswitch_ae
    .end packed-switch
.end method
