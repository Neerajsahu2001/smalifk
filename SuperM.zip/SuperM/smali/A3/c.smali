.class public LA3/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LK0/t;
.implements Lv7/b;
.implements LN2/u;
.implements Lee/h;
.implements La2/l;
.implements Lio/sentry/ILogger;
.implements LD1/k;
.implements Ln4/c;
.implements Ly1/C;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 2

    sparse-switch p1, :sswitch_data_3a

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, LA3/b;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    const/4 p1, 0x0

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    return-void

    :sswitch_11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, LZ0/w;

    invoke-direct {p1}, LZ0/w;-><init>()V

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    new-instance p1, Li2/a;

    invoke-direct {p1}, Li2/a;-><init>()V

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    return-void

    :sswitch_23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Landroidx/lifecycle/J;

    invoke-direct {p1}, Landroidx/lifecycle/G;-><init>()V

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    new-instance p1, LY2/k;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    sget-object p1, LN2/u;->D0:LN2/s;

    invoke-virtual {p0, p1}, LA3/c;->C(Ll7/n1;)V

    return-void

    :sswitch_data_3a
    .sparse-switch
        0x9 -> :sswitch_23
        0xd -> :sswitch_11
    .end sparse-switch
.end method

.method public constructor <init>(LD1/r;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LJd/x;Ljava/lang/Class;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p1, LJd/x;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_30

    const-class v0, Ljava/lang/Void;

    invoke-virtual {v0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1a

    goto :goto_30

    :cond_1a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p2

    const-string v1, "Given internalKeyMananger "

    const-string v2, " does not support primitive class "

    invoke-static {v1, p1, v2, p2}, Lcom/horcrux/svg/H0;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_30
    :goto_30
    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    iput-object p2, p0, LA3/c;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LN9/b;LN9/a;)V
    .registers 4

    const-string v0, "request"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    iput-object p2, p0, LA3/c;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LXc/F;LO6/f;)V
    .registers 4

    const-string v0, "module"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "notFoundClasses"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    iput-object p2, p0, LA3/c;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/app/job/JobParameters;Lu9/b;)V
    .registers 4

    const-string v0, "jobParameters"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "jobCompleteListener"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    iput-object p2, p0, LA3/c;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lio/sentry/util/b;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    iput-object p2, p0, LA3/c;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ll7/g5;Lda/a;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    iput-object p2, p0, LA3/c;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ln3/C;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LA3/b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public A()Z
    .registers 3

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    const/4 v1, 0x1

    if-eqz v0, :cond_13

    invoke-static {v0}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    xor-int/2addr v0, v1

    if-nez v0, :cond_20

    :cond_13
    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    xor-int/2addr v0, v1

    if-eqz v0, :cond_1f

    goto :goto_20

    :cond_1f
    const/4 v1, 0x0

    :cond_20
    :goto_20
    return v1
.end method

.method public B(LD9/j;)Lorg/json/JSONObject;
    .registers 9

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    iget-object v1, p1, LD9/a;->b:LM4/a;

    iget-object v1, v1, LM4/a;->a:Ljava/lang/Object;

    check-cast v1, Lorg/json/JSONObject;

    const-string v2, "value"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "query_params"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    iget-object p1, p1, LD9/j;->g:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_20
    :goto_20
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_84

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC9/a;

    :try_start_2c
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const-string v4, "msg"

    iget-object v5, v2, LC9/a;->c:LC9/b;

    iget-object v6, v5, LC9/b;->b:Ljava/lang/String;

    invoke-virtual {v3, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_3a
    .catchall {:try_start_2c .. :try_end_3a} :catchall_4b

    iget-object v4, v5, LC9/b;->c:Ljava/lang/String;

    if-eqz v4, :cond_4d

    :try_start_3e
    invoke-static {v4}, LZd/q;->o(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_45

    goto :goto_4d

    :cond_45
    const-string v5, "trace"

    invoke-virtual {v3, v5, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_4d

    :catchall_4b
    move-exception v2

    goto :goto_66

    :cond_4d
    :goto_4d
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const-string v5, "log_type"

    iget-object v6, v2, LC9/a;->a:Ljava/lang/String;

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "sent_time"

    iget-object v2, v2, LC9/a;->b:Ljava/lang/String;

    invoke-virtual {v4, v5, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "lake_fields"

    invoke-virtual {v4, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_65
    .catchall {:try_start_3e .. :try_end_65} :catchall_4b

    goto :goto_78

    :goto_66
    iget-object v3, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v3, Lx9/o;

    iget-object v3, v3, Lx9/o;->d:Lw9/g;

    new-instance v4, LAa/r;

    const/16 v5, 0xe

    invoke-direct {v4, v5, p0}, LAa/r;-><init>(ILjava/lang/Object;)V

    const/4 v5, 0x1

    invoke-virtual {v3, v5, v2, v4}, Lw9/g;->a(ILjava/lang/Throwable;LHc/a;)V

    const/4 v4, 0x0

    :goto_78
    if-eqz v4, :cond_20

    invoke-virtual {v4}, Lorg/json/JSONObject;->length()I

    move-result v2

    if-eqz v2, :cond_20

    invoke-virtual {v1, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_20

    :cond_84
    const-string p1, "logs"

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    return-object v0
.end method

.method public C(Ll7/n1;)V
    .registers 4

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/J;

    invoke-virtual {v0, p1}, Landroidx/lifecycle/J;->k(Ljava/lang/Object;)V

    instance-of v0, p1, LN2/t;

    iget-object v1, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v1, LY2/k;

    if-eqz v0, :cond_15

    check-cast p1, LN2/t;

    invoke-virtual {v1, p1}, LY2/k;->i(Ljava/lang/Object;)Z

    goto :goto_20

    :cond_15
    instance-of v0, p1, LN2/r;

    if-eqz v0, :cond_20

    check-cast p1, LN2/r;

    iget-object p1, p1, LN2/r;->a:Ljava/lang/Throwable;

    invoke-virtual {v1, p1}, LY2/k;->j(Ljava/lang/Throwable;)Z

    :cond_20
    :goto_20
    return-void
.end method

.method public D(Lcom/google/crypto/tink/shaded/protobuf/i;)Lx8/B0;
    .registers 7

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, LJd/x;

    :try_start_4
    invoke-virtual {v0}, LJd/x;->e()LHd/a;

    move-result-object v1

    invoke-virtual {v1, p1}, LHd/a;->c(Lcom/google/crypto/tink/shaded/protobuf/i;)Lcom/google/crypto/tink/shaded/protobuf/a;

    move-result-object p1

    invoke-virtual {v1, p1}, LHd/a;->d(Lcom/google/crypto/tink/shaded/protobuf/a;)V

    invoke-virtual {v1, p1}, LHd/a;->b(Lcom/google/crypto/tink/shaded/protobuf/a;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/google/crypto/tink/shaded/protobuf/a;

    invoke-static {}, Lx8/B0;->t()Lx8/z0;

    move-result-object v1

    invoke-virtual {v0}, LJd/x;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/v;->c()V

    iget-object v3, v1, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast v3, Lx8/B0;

    invoke-static {v3, v2}, Lx8/B0;->m(Lx8/B0;Ljava/lang/String;)V
    :try_end_27
    .catch Lcom/google/crypto/tink/shaded/protobuf/D; {:try_start_4 .. :try_end_27} :catch_60

    :try_start_27
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/a;->a()I

    move-result v2

    new-array v3, v2, [B

    new-instance v4, Lcom/google/crypto/tink/shaded/protobuf/k;

    invoke-direct {v4, v3, v2}, Lcom/google/crypto/tink/shaded/protobuf/k;-><init>([BI)V

    invoke-virtual {p1, v4}, Lcom/google/crypto/tink/shaded/protobuf/a;->d(Lcom/google/crypto/tink/shaded/protobuf/k;)V

    iget v2, v4, Lcom/google/crypto/tink/shaded/protobuf/k;->c:I

    iget v4, v4, Lcom/google/crypto/tink/shaded/protobuf/k;->d:I

    sub-int/2addr v2, v4

    if-nez v2, :cond_62

    new-instance v2, Lcom/google/crypto/tink/shaded/protobuf/h;

    invoke-direct {v2, v3}, Lcom/google/crypto/tink/shaded/protobuf/h;-><init>([B)V
    :try_end_41
    .catch Ljava/io/IOException; {:try_start_27 .. :try_end_41} :catch_6a

    :try_start_41
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/v;->c()V

    iget-object p1, v1, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast p1, Lx8/B0;

    invoke-static {p1, v2}, Lx8/B0;->n(Lx8/B0;Lcom/google/crypto/tink/shaded/protobuf/h;)V

    invoke-virtual {v0}, LJd/x;->f()Lx8/A0;

    move-result-object p1

    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/v;->c()V

    iget-object v0, v1, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast v0, Lx8/B0;

    invoke-static {v0, p1}, Lx8/B0;->o(Lx8/B0;Lx8/A0;)V

    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/v;->a()Lcom/google/crypto/tink/shaded/protobuf/x;

    move-result-object p1

    check-cast p1, Lx8/B0;
    :try_end_5f
    .catch Lcom/google/crypto/tink/shaded/protobuf/D; {:try_start_41 .. :try_end_5f} :catch_60

    return-object p1

    :catch_60
    move-exception p1

    goto :goto_77

    :cond_62
    :try_start_62
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Did not write as much data as expected."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_6a
    .catch Ljava/io/IOException; {:try_start_62 .. :try_end_6a} :catch_6a

    :catch_6a
    move-exception v0

    :try_start_6b
    new-instance v1, Ljava/lang/RuntimeException;

    const-string v2, "ByteString"

    invoke-virtual {p1, v2}, Lcom/google/crypto/tink/shaded/protobuf/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
    :try_end_77
    .catch Lcom/google/crypto/tink/shaded/protobuf/D; {:try_start_6b .. :try_end_77} :catch_60

    :goto_77
    new-instance v0, Ljava/security/GeneralSecurityException;

    const-string v1, "Unexpected proto"

    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public E(Ljava/lang/Throwable;)V
    .registers 9

    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, Lr7/M0;

    invoke-virtual {v0}, Lr7/u;->x0()V

    const/4 v1, 0x0

    iput-boolean v1, v0, Lr7/M0;->j:Z

    iget-object v2, v0, LJ1/e;->b:Ljava/lang/Object;

    check-cast v2, Lr7/j0;

    iget-object v3, v2, Lr7/j0;->g:Lr7/d;

    sget-object v4, Lr7/s;->M0:Lr7/w;

    const/4 v5, 0x0

    invoke-virtual {v3, v5, v4}, Lr7/d;->I0(Ljava/lang/String;Lr7/w;)Z

    move-result v3

    if-nez v3, :cond_28

    invoke-virtual {v0}, Lr7/M0;->d1()V

    invoke-virtual {v0}, LJ1/e;->zzj()Lr7/I;

    move-result-object v0

    const-string v1, "registerTriggerAsync failed with throwable"

    iget-object v0, v0, Lr7/I;->g:Lr7/K;

    invoke-virtual {v0, p1, v1}, Lr7/K;->a(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :cond_28
    iget-object v3, v2, Lr7/j0;->g:Lr7/d;

    sget-object v4, Lr7/s;->K0:Lr7/w;

    invoke-virtual {v3, v5, v4}, Lr7/d;->I0(Ljava/lang/String;Lr7/w;)Z

    move-result v3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v3, :cond_73

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    iput-boolean v1, v0, Lr7/M0;->n:Z

    if-eqz v3, :cond_73

    instance-of v1, p1, Ljava/lang/IllegalStateException;

    if-nez v1, :cond_67

    const-string v1, "garbage collected"

    invoke-virtual {v3, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_67

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    const-string v6, "ServiceUnavailableException"

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_59

    goto :goto_67

    :cond_59
    instance-of v1, p1, Ljava/lang/SecurityException;

    if-eqz v1, :cond_73

    const-string v1, "READ_DEVICE_CONFIG"

    invoke-virtual {v3, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_73

    const/4 v1, 0x3

    goto :goto_74

    :cond_67
    :goto_67
    const-string v1, "Background"

    invoke-virtual {v3, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_71

    iput-boolean v5, v0, Lr7/M0;->n:Z

    :cond_71
    move v1, v5

    goto :goto_74

    :cond_73
    move v1, v4

    :goto_74
    sub-int/2addr v1, v5

    iget-object v3, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v3, Lcom/google/android/gms/measurement/internal/zzno;

    if-eqz v1, :cond_12a

    if-eq v1, v5, :cond_b7

    if-eq v1, v4, :cond_80

    goto :goto_b6

    :cond_80
    invoke-virtual {v0}, LJ1/e;->zzj()Lr7/I;

    move-result-object v1

    invoke-virtual {v2}, Lr7/j0;->k()Lr7/B;

    move-result-object v2

    invoke-virtual {v2}, Lr7/B;->E0()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object v2

    iget-object v1, v1, Lr7/I;->g:Lr7/K;

    const-string v4, "registerTriggerAsync failed. Dropping URI. App ID, Throwable"

    invoke-virtual {v1, v2, v4, p1}, Lr7/K;->b(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v0}, LJ1/e;->v0()Lr7/U;

    move-result-object p1

    invoke-virtual {p1}, Lr7/U;->H0()Landroid/util/SparseArray;

    move-result-object p1

    iget v1, v3, Lcom/google/android/gms/measurement/internal/zzno;->c:I

    iget-wide v2, v3, Lcom/google/android/gms/measurement/internal/zzno;->b:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    invoke-virtual {v0}, LJ1/e;->v0()Lr7/U;

    move-result-object v1

    invoke-virtual {v1, p1}, Lr7/U;->B0(Landroid/util/SparseArray;)V

    iput v5, v0, Lr7/M0;->k:I

    invoke-virtual {v0}, Lr7/M0;->d1()V

    :goto_b6
    return-void

    :cond_b7
    invoke-virtual {v0}, Lr7/M0;->Y0()Ljava/util/PriorityQueue;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    iget v1, v0, Lr7/M0;->k:I

    const/16 v3, 0x20

    if-le v1, v3, :cond_e6

    iput v5, v0, Lr7/M0;->k:I

    invoke-virtual {v0}, LJ1/e;->zzj()Lr7/I;

    move-result-object v0

    invoke-virtual {v2}, Lr7/j0;->k()Lr7/B;

    move-result-object v1

    invoke-virtual {v1}, Lr7/B;->E0()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object p1

    iget-object v0, v0, Lr7/I;->j:Lr7/K;

    const-string v2, "registerTriggerAsync failed. May try later. App ID, throwable"

    invoke-virtual {v0, v1, v2, p1}, Lr7/K;->b(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)V

    return-void

    :cond_e6
    invoke-virtual {v0}, LJ1/e;->zzj()Lr7/I;

    move-result-object v1

    invoke-virtual {v2}, Lr7/j0;->k()Lr7/B;

    move-result-object v3

    invoke-virtual {v3}, Lr7/B;->E0()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object v3

    iget v4, v0, Lr7/M0;->k:I

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object v4

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object p1

    iget-object v1, v1, Lr7/I;->j:Lr7/K;

    const-string v6, "registerTriggerAsync failed. App ID, delay in seconds, throwable"

    invoke-virtual {v1, v6, v3, v4, p1}, Lr7/K;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iget p1, v0, Lr7/M0;->k:I

    iget-object v1, v0, Lr7/M0;->l:Lr7/T0;

    if-nez v1, :cond_11c

    new-instance v1, Lr7/T0;

    invoke-direct {v1, v0, v2}, Lr7/T0;-><init>(Lr7/M0;Lr7/z0;)V

    iput-object v1, v0, Lr7/M0;->l:Lr7/T0;

    :cond_11c
    iget-object v1, v0, Lr7/M0;->l:Lr7/T0;

    mul-int/lit16 p1, p1, 0x3e8

    int-to-long v2, p1

    invoke-virtual {v1, v2, v3}, Lr7/l;->b(J)V

    iget p1, v0, Lr7/M0;->k:I

    shl-int/2addr p1, v5

    iput p1, v0, Lr7/M0;->k:I

    return-void

    :cond_12a
    invoke-virtual {v0}, LJ1/e;->zzj()Lr7/I;

    move-result-object v1

    invoke-virtual {v2}, Lr7/j0;->k()Lr7/B;

    move-result-object v2

    invoke-virtual {v2}, Lr7/B;->E0()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lr7/I;->D0(Ljava/lang/String;)Lr7/J;

    move-result-object p1

    iget-object v1, v1, Lr7/I;->j:Lr7/K;

    const-string v4, "registerTriggerAsync failed with retriable error. Will try later. App ID, throwable"

    invoke-virtual {v1, v2, v4, p1}, Lr7/K;->b(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)V

    iput v5, v0, Lr7/M0;->k:I

    invoke-virtual {v0}, Lr7/M0;->Y0()Ljava/util/PriorityQueue;

    move-result-object p1

    invoke-virtual {p1, v3}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public F(Ln0/g;)V
    .registers 7

    iget v0, p1, Ln0/g;->b:I

    iget-object v1, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v1, Landroid/os/Handler;

    iget-object v2, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v2, LA/d;

    if-nez v0, :cond_19

    new-instance v0, LN6/A;

    iget-object p1, p1, Ln0/g;->a:Landroid/graphics/Typeface;

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v0, v2, p1, v3, v4}, LN6/A;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_21

    :cond_19
    new-instance p1, Ln0/a;

    invoke-direct {p1, v2, v0}, Ln0/a;-><init>(LA/d;I)V

    invoke-virtual {v1, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_21
    return-void
.end method

.method public declared-synchronized G()LIe/j;
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, LIe/j;

    if-eqz v0, :cond_13

    iget-object v1, v0, LIe/j;->c:LIe/j;

    iput-object v1, p0, LA3/c;->a:Ljava/lang/Object;

    if-nez v1, :cond_13

    const/4 v1, 0x0

    iput-object v1, p0, LA3/c;->b:Ljava/lang/Object;
    :try_end_10
    .catchall {:try_start_1 .. :try_end_10} :catchall_11

    goto :goto_13

    :catchall_11
    move-exception v0

    goto :goto_15

    :cond_13
    :goto_13
    monitor-exit p0

    return-object v0

    :goto_15
    monitor-exit p0

    throw v0
.end method

.method public H(LNd/F;Lrd/g;Ltd/f;)LBd/g;
    .registers 8

    const-string v0, "value"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Ltd/e;->L:Ltd/b;

    iget v1, p2, Lrd/g;->m:I

    invoke-virtual {v0, v1}, Ltd/b;->c(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iget-object v1, p2, Lrd/g;->c:Lrd/f;

    if-nez v1, :cond_1c

    const/4 v1, -0x1

    goto :goto_24

    :cond_1c
    sget-object v2, LJd/b;->a:[I

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v1, v2, v1

    :goto_24
    packed-switch v1, :pswitch_data_156

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "Unsupported annotation argument type: "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p2, p2, Lrd/g;->c:Lrd/f;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " (expected "

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :pswitch_4e
    iget-object p2, p2, Lrd/g;->k:Ljava/util/List;

    const-string v0, "value.arrayElementList"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {p2, v1}, Lvc/n;->j(Ljava/lang/Iterable;I)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_66
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_90

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lrd/g;

    iget-object v2, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v2, LXc/F;

    invoke-interface {v2}, LXc/F;->e()LUc/j;

    move-result-object v2

    invoke-virtual {v2}, LUc/j;->e()LNd/M;

    move-result-object v2

    const-string v3, "builtIns.anyType"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "it"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v2, v1, p3}, LA3/c;->H(LNd/F;Lrd/g;Ltd/f;)LBd/g;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_66

    :cond_90
    new-instance p2, LBd/b;

    new-instance p3, LBd/h;

    const/4 v1, 0x0

    invoke-direct {p3, v1, p1}, LBd/h;-><init>(ILjava/lang/Object;)V

    invoke-direct {p2, v0, p3}, LBd/b;-><init>(Ljava/util/List;LHc/b;)V

    goto/16 :goto_155

    :pswitch_9d
    new-instance p1, LBd/a;

    iget-object p2, p2, Lrd/g;->j:Lrd/j;

    const-string v0, "value.annotation"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p2, p3}, LA3/c;->s(Lrd/j;Ltd/f;)LYc/c;

    move-result-object p2

    invoke-direct {p1, p2}, LBd/g;-><init>(Ljava/lang/Object;)V

    :goto_ad
    move-object p2, p1

    goto/16 :goto_155

    :pswitch_b0
    new-instance p1, LBd/k;

    iget v0, p2, Lrd/g;->h:I

    invoke-static {p3, v0}, Ll7/X4;->b(Ltd/f;I)Lwd/a;

    move-result-object v0

    iget p2, p2, Lrd/g;->i:I

    invoke-static {p3, p2}, Ll7/X4;->c(Ltd/f;I)Lwd/e;

    move-result-object p2

    invoke-direct {p1, v0, p2}, LBd/k;-><init>(Lwd/a;Lwd/e;)V

    goto :goto_ad

    :pswitch_c2
    new-instance p1, LBd/u;

    iget v0, p2, Lrd/g;->h:I

    invoke-static {p3, v0}, Ll7/X4;->b(Ltd/f;I)Lwd/a;

    move-result-object p3

    iget p2, p2, Lrd/g;->l:I

    invoke-direct {p1, p3, p2}, LBd/u;-><init>(Lwd/a;I)V

    goto :goto_ad

    :pswitch_d0
    new-instance p1, LBd/y;

    iget p2, p2, Lrd/g;->g:I

    invoke-interface {p3, p2}, Ltd/f;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, LBd/g;-><init>(Ljava/lang/Object;)V

    goto :goto_ad

    :pswitch_dc
    new-instance p1, LBd/c;

    iget-wide p2, p2, Lrd/g;->d:J

    const-wide/16 v0, 0x0

    cmp-long p2, p2, v0

    if-eqz p2, :cond_e8

    const/4 p2, 0x1

    goto :goto_e9

    :cond_e8
    const/4 p2, 0x0

    :goto_e9
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-direct {p1, p2}, LBd/g;-><init>(Ljava/lang/Object;)V

    goto :goto_ad

    :pswitch_f1
    new-instance p1, LBd/j;

    iget-wide p2, p2, Lrd/g;->f:D

    invoke-direct {p1, p2, p3}, LBd/j;-><init>(D)V

    goto :goto_ad

    :pswitch_f9
    new-instance p1, LBd/m;

    iget p2, p2, Lrd/g;->e:F

    invoke-direct {p1, p2}, LBd/m;-><init>(F)V

    goto :goto_ad

    :pswitch_101
    iget-wide p1, p2, Lrd/g;->d:J

    if-eqz v0, :cond_10c

    new-instance p3, LBd/B;

    invoke-direct {p3, p1, p2}, LBd/B;-><init>(J)V

    :goto_10a
    move-object p2, p3

    goto :goto_155

    :cond_10c
    new-instance p3, LBd/v;

    invoke-direct {p3, p1, p2}, LBd/v;-><init>(J)V

    goto :goto_10a

    :pswitch_112
    iget-wide p1, p2, Lrd/g;->d:J

    long-to-int p1, p1

    if-eqz v0, :cond_11d

    new-instance p2, LBd/A;

    invoke-direct {p2, p1}, LBd/A;-><init>(I)V

    goto :goto_155

    :cond_11d
    new-instance p2, LBd/n;

    invoke-direct {p2, p1}, LBd/n;-><init>(I)V

    goto :goto_155

    :pswitch_123
    iget-wide p1, p2, Lrd/g;->d:J

    long-to-int p1, p1

    int-to-short p1, p1

    if-eqz v0, :cond_12f

    new-instance p2, LBd/C;

    invoke-direct {p2, p1}, LBd/C;-><init>(S)V

    goto :goto_155

    :cond_12f
    new-instance p2, LBd/x;

    invoke-direct {p2, p1}, LBd/x;-><init>(S)V

    goto :goto_155

    :pswitch_135
    new-instance p1, LBd/e;

    iget-wide p2, p2, Lrd/g;->d:J

    long-to-int p2, p2

    int-to-char p2, p2

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    invoke-direct {p1, p2}, LBd/g;-><init>(Ljava/lang/Object;)V

    goto/16 :goto_ad

    :pswitch_144
    iget-wide p1, p2, Lrd/g;->d:J

    long-to-int p1, p1

    int-to-byte p1, p1

    if-eqz v0, :cond_150

    new-instance p2, LBd/z;

    invoke-direct {p2, p1}, LBd/z;-><init>(B)V

    goto :goto_155

    :cond_150
    new-instance p2, LBd/d;

    invoke-direct {p2, p1}, LBd/d;-><init>(B)V

    :goto_155
    return-object p2

    :pswitch_data_156
    .packed-switch 0x1
        :pswitch_144
        :pswitch_135
        :pswitch_123
        :pswitch_112
        :pswitch_101
        :pswitch_f9
        :pswitch_f1
        :pswitch_dc
        :pswitch_d0
        :pswitch_c2
        :pswitch_b0
        :pswitch_9d
        :pswitch_4e
    .end packed-switch
.end method

.method public a()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, LK0/E;

    return-object v0
.end method

.method public c(Ljava/lang/CharSequence;IILK0/B;)Z
    .registers 8

    iget v0, p4, LK0/B;->c:I

    and-int/lit8 v0, v0, 0x4

    const/4 v1, 0x1

    if-lez v0, :cond_8

    return v1

    :cond_8
    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, LK0/E;

    if-nez v0, :cond_22

    new-instance v0, LK0/E;

    instance-of v2, p1, Landroid/text/Spannable;

    if-eqz v2, :cond_17

    check-cast p1, Landroid/text/Spannable;

    goto :goto_1d

    :cond_17
    new-instance v2, Landroid/text/SpannableString;

    invoke-direct {v2, p1}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    move-object p1, v2

    :goto_1d
    invoke-direct {v0, p1}, LK0/E;-><init>(Landroid/text/Spannable;)V

    iput-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    :cond_22
    iget-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast p1, LO4/c;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p1, LK0/C;

    invoke-direct {p1, p4}, LK0/C;-><init>(LK0/B;)V

    iget-object p4, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast p4, LK0/E;

    const/16 v0, 0x21

    invoke-virtual {p4, p1, p2, p3, v0}, LK0/E;->setSpan(Ljava/lang/Object;III)V

    return v1
.end method

.method public collect(Lee/i;Lyc/d;)Ljava/lang/Object;
    .registers 8

    instance-of v0, p2, Lee/x;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lee/x;

    iget v1, v0, Lee/x;->b:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lee/x;->b:I

    goto :goto_18

    :cond_13
    new-instance v0, Lee/x;

    invoke-direct {v0, p0, p2}, Lee/x;-><init>(LA3/c;Lyc/d;)V

    :goto_18
    iget-object p2, v0, Lee/x;->a:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, Lee/x;->b:I

    const/4 v3, 0x1

    if-eqz v2, :cond_33

    if-ne v2, v3, :cond_2b

    iget-object p1, v0, Lee/x;->d:Lee/z;

    :try_start_25
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_28
    .catch Lfe/a; {:try_start_25 .. :try_end_28} :catch_29

    goto :goto_54

    :catch_29
    move-exception p2

    goto :goto_50

    :cond_2b
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_33
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p2, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast p2, Lee/h;

    new-instance v2, Lee/z;

    iget-object v4, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v4, LHc/c;

    invoke-direct {v2, v4, p1}, Lee/z;-><init>(LHc/c;Lee/i;)V

    :try_start_43
    iput-object v2, v0, Lee/x;->d:Lee/z;

    iput v3, v0, Lee/x;->b:I

    invoke-interface {p2, v2, v0}, Lee/h;->collect(Lee/i;Lyc/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_4b
    .catch Lfe/a; {:try_start_43 .. :try_end_4b} :catch_4e

    if-ne p1, v1, :cond_54

    return-object v1

    :catch_4e
    move-exception p2

    move-object p1, v2

    :goto_50
    iget-object v0, p2, Lfe/a;->a:Ljava/lang/Object;

    if-ne v0, p1, :cond_57

    :cond_54
    :goto_54
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :cond_57
    throw p2
.end method

.method public d([BIILa2/k;LZ0/e;)V
    .registers 25

    move-object/from16 v1, p0

    move/from16 v0, p2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v4, -0x1

    const/4 v5, 0x1

    add-int v6, v0, p3

    iget-object v7, v1, LA3/c;->a:Ljava/lang/Object;

    check-cast v7, LZ0/w;

    move-object/from16 v8, p1

    invoke-virtual {v7, v6, v8}, LZ0/w;->E(I[B)V

    invoke-virtual {v7, v0}, LZ0/w;->G(I)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :try_start_1b
    invoke-static {v7}, Li2/i;->d(LZ0/w;)V
    :try_end_1e
    .catch LW0/J; {:try_start_1b .. :try_end_1e} :catch_40c

    :goto_1e
    sget-object v6, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v7, v6}, LZ0/w;->h(Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_2b

    goto :goto_1e

    :cond_2b
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    :cond_30
    :goto_30
    move v9, v3

    move v8, v4

    :goto_32
    if-ne v8, v4, :cond_56

    iget v9, v7, LZ0/w;->b:I

    sget-object v8, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v7, v8}, LZ0/w;->h(Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_40

    move v8, v3

    goto :goto_32

    :cond_40
    const-string v11, "STYLE"

    invoke-virtual {v11, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_4a

    move v8, v2

    goto :goto_32

    :cond_4a
    const-string v11, "NOTE"

    invoke-virtual {v8, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_54

    move v8, v5

    goto :goto_32

    :cond_54
    const/4 v8, 0x3

    goto :goto_32

    :cond_56
    invoke-virtual {v7, v9}, LZ0/w;->G(I)V

    if-eqz v8, :cond_3ff

    if-ne v8, v5, :cond_6a

    :goto_5d
    sget-object v8, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v7, v8}, LZ0/w;->h(Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_30

    goto :goto_5d

    :cond_6a
    const/4 v9, 0x0

    if-ne v8, v2, :cond_3bc

    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_3b4

    sget-object v8, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v7, v8}, LZ0/w;->h(Ljava/nio/charset/Charset;)Ljava/lang/String;

    iget-object v8, v1, LA3/c;->b:Ljava/lang/Object;

    check-cast v8, Li2/a;

    iget-object v11, v8, Li2/a;->b:Ljava/lang/StringBuilder;

    invoke-virtual {v11, v3}, Ljava/lang/StringBuilder;->setLength(I)V

    iget v12, v7, LZ0/w;->b:I

    :goto_83
    sget-object v13, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v7, v13}, LZ0/w;->h(Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_3b0

    iget-object v13, v7, LZ0/w;->a:[B

    iget v14, v7, LZ0/w;->b:I

    iget-object v8, v8, Li2/a;->a:LZ0/w;

    invoke-virtual {v8, v14, v13}, LZ0/w;->E(I[B)V

    invoke-virtual {v8, v12}, LZ0/w;->G(I)V

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    :goto_a0
    invoke-static {v8}, Li2/a;->c(LZ0/w;)V

    invoke-virtual {v8}, LZ0/w;->a()I

    move-result v13

    const-string v14, "{"

    const-string v15, ""

    const/4 v10, 0x5

    if-ge v13, v10, :cond_b1

    :goto_ae
    move-object v2, v9

    goto/16 :goto_117

    :cond_b1
    sget-object v13, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v8, v10, v13}, LZ0/w;->s(ILjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v10

    const-string v13, "::cue"

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_c0

    goto :goto_ae

    :cond_c0
    iget v10, v8, LZ0/w;->b:I

    invoke-static {v8, v11}, Li2/a;->b(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_c9

    goto :goto_ae

    :cond_c9
    invoke-virtual {v14, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_d4

    invoke-virtual {v8, v10}, LZ0/w;->G(I)V

    move-object v2, v15

    goto :goto_117

    :cond_d4
    const-string v10, "("

    invoke-virtual {v10, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_109

    iget v10, v8, LZ0/w;->b:I

    iget v13, v8, LZ0/w;->c:I

    move/from16 v16, v3

    :goto_e2
    if-ge v10, v13, :cond_fa

    if-nez v16, :cond_fa

    iget-object v2, v8, LZ0/w;->a:[B

    add-int/lit8 v17, v10, 0x1

    aget-byte v2, v2, v10

    int-to-char v2, v2

    const/16 v10, 0x29

    if-ne v2, v10, :cond_f3

    move v2, v5

    goto :goto_f4

    :cond_f3
    move v2, v3

    :goto_f4
    move/from16 v16, v2

    move/from16 v10, v17

    const/4 v2, 0x2

    goto :goto_e2

    :cond_fa
    add-int/2addr v10, v4

    iget v2, v8, LZ0/w;->b:I

    sub-int/2addr v10, v2

    sget-object v2, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v8, v10, v2}, LZ0/w;->s(ILjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    goto :goto_10a

    :cond_109
    move-object v2, v9

    :goto_10a
    invoke-static {v8, v11}, Li2/a;->b(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v10

    const-string v13, ")"

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_117

    goto :goto_ae

    :cond_117
    :goto_117
    if-eqz v2, :cond_123

    invoke-static {v8, v11}, Li2/a;->b(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v14, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_127

    :cond_123
    move v1, v5

    const/4 v3, 0x2

    goto/16 :goto_3a5

    :cond_127
    new-instance v10, Li2/b;

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    iput-object v15, v10, Li2/b;->a:Ljava/lang/String;

    iput-object v15, v10, Li2/b;->b:Ljava/lang/String;

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v13

    iput-object v13, v10, Li2/b;->c:Ljava/util/Set;

    iput-object v15, v10, Li2/b;->d:Ljava/lang/String;

    iput-object v9, v10, Li2/b;->e:Ljava/lang/String;

    iput-boolean v3, v10, Li2/b;->g:Z

    iput-boolean v3, v10, Li2/b;->i:Z

    iput v4, v10, Li2/b;->j:I

    iput v4, v10, Li2/b;->k:I

    iput v4, v10, Li2/b;->l:I

    iput v4, v10, Li2/b;->m:I

    iput v4, v10, Li2/b;->n:I

    iput v4, v10, Li2/b;->p:I

    iput-boolean v3, v10, Li2/b;->q:Z

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_153

    goto :goto_1b8

    :cond_153
    const/16 v13, 0x5b

    invoke-virtual {v2, v13}, Ljava/lang/String;->indexOf(I)I

    move-result v13

    if-eq v13, v4, :cond_178

    sget-object v14, Li2/a;->c:Ljava/util/regex/Pattern;

    invoke-virtual {v2, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v9}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/regex/Matcher;->matches()Z

    move-result v14

    if-eqz v14, :cond_174

    invoke-virtual {v9, v5}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v9, v10, Li2/b;->d:Ljava/lang/String;

    :cond_174
    invoke-virtual {v2, v3, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    :cond_178
    sget v9, LZ0/F;->a:I

    const-string v9, "\\."

    invoke-virtual {v2, v9, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v2

    aget-object v9, v2, v3

    const/16 v13, 0x23

    invoke-virtual {v9, v13}, Ljava/lang/String;->indexOf(I)I

    move-result v13

    if-eq v13, v4, :cond_198

    invoke-virtual {v9, v3, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v14

    iput-object v14, v10, Li2/b;->b:Ljava/lang/String;

    add-int/2addr v13, v5

    invoke-virtual {v9, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v9

    iput-object v9, v10, Li2/b;->a:Ljava/lang/String;

    goto :goto_19a

    :cond_198
    iput-object v9, v10, Li2/b;->b:Ljava/lang/String;

    :goto_19a
    array-length v9, v2

    if-le v9, v5, :cond_1b8

    array-length v9, v2

    array-length v13, v2

    if-gt v9, v13, :cond_1a3

    move v13, v5

    goto :goto_1a4

    :cond_1a3
    move v13, v3

    :goto_1a4
    invoke-static {v13}, Lm7/u;->a(Z)V

    invoke-static {v2, v5, v9}, Ljava/util/Arrays;->copyOfRange([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    new-instance v9, Ljava/util/HashSet;

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-direct {v9, v2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    iput-object v9, v10, Li2/b;->c:Ljava/util/Set;

    :cond_1b8
    :goto_1b8
    move v2, v3

    const/4 v9, 0x0

    :goto_1ba
    const-string v13, "}"

    if-nez v2, :cond_391

    iget v2, v8, LZ0/w;->b:I

    invoke-static {v8, v11}, Li2/a;->b(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_1cf

    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_1cd

    goto :goto_1cf

    :cond_1cd
    move v14, v3

    goto :goto_1d0

    :cond_1cf
    :goto_1cf
    move v14, v5

    :goto_1d0
    if-nez v14, :cond_387

    invoke-virtual {v8, v2}, LZ0/w;->G(I)V

    invoke-static {v8}, Li2/a;->c(LZ0/w;)V

    invoke-static {v8, v11}, Li2/a;->a(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_1e4

    goto/16 :goto_387

    :cond_1e4
    const-string v3, ":"

    invoke-static {v8, v11}, Li2/a;->b(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1f2

    goto/16 :goto_387

    :cond_1f2
    invoke-static {v8}, Li2/a;->c(LZ0/w;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    :goto_1fb
    const-string v5, ";"

    if-nez v4, :cond_227

    iget v1, v8, LZ0/w;->b:I

    move/from16 p3, v4

    invoke-static {v8, v11}, Li2/a;->b(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_20b

    const/4 v1, 0x0

    goto :goto_22b

    :cond_20b
    invoke-virtual {v13, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v18

    if-nez v18, :cond_220

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_218

    goto :goto_220

    :cond_218
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v1, p0

    move/from16 v4, p3

    goto :goto_1fb

    :cond_220
    :goto_220
    invoke-virtual {v8, v1}, LZ0/w;->G(I)V

    const/4 v4, 0x1

    move-object/from16 v1, p0

    goto :goto_1fb

    :cond_227
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_22b
    if-eqz v1, :cond_32e

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_235

    goto/16 :goto_32e

    :cond_235
    iget v3, v8, LZ0/w;->b:I

    invoke-static {v8, v11}, Li2/a;->b(LZ0/w;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_242

    goto :goto_24b

    :cond_242
    invoke-virtual {v13, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_32e

    invoke-virtual {v8, v3}, LZ0/w;->G(I)V

    :goto_24b
    const-string v3, "color"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_25f

    const/4 v3, 0x1

    invoke-static {v1, v3}, LZ0/c;->a(Ljava/lang/String;Z)I

    move-result v1

    iput v1, v10, Li2/b;->f:I

    iput-boolean v3, v10, Li2/b;->g:Z

    :cond_25c
    :goto_25c
    move v1, v3

    goto/16 :goto_388

    :cond_25f
    const/4 v3, 0x1

    const-string v4, "background-color"

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_271

    invoke-static {v1, v3}, LZ0/c;->a(Ljava/lang/String;Z)I

    move-result v1

    iput v1, v10, Li2/b;->h:I

    iput-boolean v3, v10, Li2/b;->i:Z

    goto :goto_25c

    :cond_271
    const-string v4, "ruby-position"

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_292

    const-string v2, "over"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_285

    iput v3, v10, Li2/b;->p:I

    goto/16 :goto_32e

    :cond_285
    const-string v2, "under"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_32e

    const/4 v1, 0x2

    iput v1, v10, Li2/b;->p:I

    goto/16 :goto_32e

    :cond_292
    const-string v3, "text-combine-upright"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2b2

    const-string v2, "all"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2ad

    const-string v2, "digits"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2ab

    goto :goto_2ad

    :cond_2ab
    const/4 v1, 0x0

    goto :goto_2ae

    :cond_2ad
    :goto_2ad
    const/4 v1, 0x1

    :goto_2ae
    iput-boolean v1, v10, Li2/b;->q:Z

    goto/16 :goto_32e

    :cond_2b2
    const-string v3, "text-decoration"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2c6

    const-string v2, "underline"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_32e

    const/4 v1, 0x1

    iput v1, v10, Li2/b;->k:I

    goto :goto_32e

    :cond_2c6
    const-string v3, "font-family"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2d5

    invoke-static {v1}, Ll7/O4;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v10, Li2/b;->e:Ljava/lang/String;

    goto :goto_32e

    :cond_2d5
    const-string v3, "font-weight"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2ea

    const-string v2, "bold"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_32e

    const/4 v3, 0x1

    iput v3, v10, Li2/b;->l:I

    goto/16 :goto_25c

    :cond_2ea
    const/4 v3, 0x1

    const-string v4, "font-style"

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2fe

    const-string v2, "italic"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25c

    iput v3, v10, Li2/b;->m:I

    goto :goto_32e

    :cond_2fe
    const-string v3, "font-size"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_32e

    invoke-static {v1}, Ll7/O4;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Li2/a;->d:Ljava/util/regex/Pattern;

    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->matches()Z

    move-result v3

    if-nez v3, :cond_330

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Invalid font-size: \'"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\'."

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "WebvttCssParser"

    invoke-static {v2, v1}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_32e
    :goto_32e
    const/4 v1, 0x1

    goto :goto_388

    :cond_330
    const/4 v1, 0x2

    invoke-virtual {v2, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_414

    :goto_33f
    const/4 v3, -0x1

    goto :goto_361

    :sswitch_341
    const-string v1, "px"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_34a

    goto :goto_33f

    :cond_34a
    const/4 v3, 0x2

    goto :goto_361

    :sswitch_34c
    const-string v1, "em"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_355

    goto :goto_33f

    :cond_355
    const/4 v3, 0x1

    goto :goto_361

    :sswitch_357
    const-string v1, "%"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_360

    goto :goto_33f

    :cond_360
    const/4 v3, 0x0

    :goto_361
    packed-switch v3, :pswitch_data_422

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0

    :pswitch_36a
    const/4 v1, 0x1

    iput v1, v10, Li2/b;->n:I

    const/4 v3, 0x2

    goto :goto_379

    :pswitch_36f
    const/4 v1, 0x1

    const/4 v3, 0x2

    iput v3, v10, Li2/b;->n:I

    goto :goto_379

    :pswitch_374
    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v4, v10, Li2/b;->n:I

    :goto_379
    invoke-virtual {v2, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    iput v2, v10, Li2/b;->o:F

    goto :goto_389

    :cond_387
    :goto_387
    move v1, v5

    :goto_388
    const/4 v3, 0x2

    :goto_389
    move v5, v1

    move v2, v14

    const/4 v3, 0x0

    const/4 v4, -0x1

    move-object/from16 v1, p0

    goto/16 :goto_1ba

    :cond_391
    move v1, v5

    const/4 v3, 0x2

    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_39c

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_39c
    move v5, v1

    move v2, v3

    const/4 v3, 0x0

    const/4 v4, -0x1

    const/4 v9, 0x0

    move-object/from16 v1, p0

    goto/16 :goto_a0

    :goto_3a5
    invoke-virtual {v0, v12}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_3a8
    :goto_3a8
    move v5, v1

    move v2, v3

    const/4 v3, 0x0

    const/4 v4, -0x1

    move-object/from16 v1, p0

    goto/16 :goto_30

    :cond_3b0
    move-object/from16 v1, p0

    goto/16 :goto_83

    :cond_3b4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "A style block was found after the first cue."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3bc
    move v3, v2

    move v1, v5

    const/4 v2, 0x3

    if-ne v8, v2, :cond_3a8

    sget-object v2, Li2/h;->a:Ljava/util/regex/Pattern;

    sget-object v2, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v7, v2}, LZ0/w;->h(Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_3cd

    const/4 v9, 0x0

    goto :goto_3f9

    :cond_3cd
    sget-object v5, Li2/h;->a:Ljava/util/regex/Pattern;

    invoke-virtual {v5, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/regex/Matcher;->matches()Z

    move-result v9

    if-eqz v9, :cond_3df

    const/4 v9, 0x0

    invoke-static {v9, v8, v7, v0}, Li2/h;->d(Ljava/lang/String;Ljava/util/regex/Matcher;LZ0/w;Ljava/util/ArrayList;)Li2/c;

    move-result-object v9

    goto :goto_3f9

    :cond_3df
    const/4 v9, 0x0

    invoke-virtual {v7, v2}, LZ0/w;->h(Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3e7

    goto :goto_3f9

    :cond_3e7
    invoke-virtual {v5, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->matches()Z

    move-result v5

    if-eqz v5, :cond_3f9

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v2, v7, v0}, Li2/h;->d(Ljava/lang/String;Ljava/util/regex/Matcher;LZ0/w;Ljava/util/ArrayList;)Li2/c;

    move-result-object v9

    :cond_3f9
    :goto_3f9
    if-eqz v9, :cond_3a8

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3a8

    :cond_3ff
    new-instance v0, LA8/s;

    invoke-direct {v0, v6}, LA8/s;-><init>(Ljava/util/ArrayList;)V

    move-object/from16 v1, p4

    move-object/from16 v2, p5

    invoke-static {v0, v1, v2}, Lm7/G;->c(La2/d;La2/k;LZ0/e;)V

    return-void

    :catch_40c
    move-exception v0

    move-object v1, v0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :sswitch_data_414
    .sparse-switch
        0x25 -> :sswitch_357
        0xca8 -> :sswitch_34c
        0xe08 -> :sswitch_341
    .end sparse-switch

    :pswitch_data_422
    .packed-switch 0x0
        :pswitch_374
        :pswitch_36f
        :pswitch_36a
    .end packed-switch
.end method

.method public e()V
    .registers 4

    sget-object v0, LZ0/F;->f:[B

    iget-object v1, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v1, LZ0/w;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v2, v0

    invoke-virtual {v1, v2, v0}, LZ0/w;->E(I[B)V

    return-void
.end method

.method public f(Lv7/i;)Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/cloudmessaging/Rpc;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v1

    if-nez v1, :cond_e

    goto :goto_2e

    :cond_e
    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    if-eqz v1, :cond_2e

    const-string v2, "google.messenger"

    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2e

    iget-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast p1, Landroid/os/Bundle;

    invoke-virtual {v0, p1}, Lcom/google/android/gms/cloudmessaging/Rpc;->a(Landroid/os/Bundle;)Lv7/v;

    move-result-object p1

    sget-object v0, LK6/s;->a:LK6/s;

    sget-object v1, LK6/r;->a:LK6/r;

    invoke-virtual {p1, v0, v1}, Lv7/v;->m(Ljava/util/concurrent/Executor;Lv7/h;)Lv7/v;

    move-result-object p1

    :cond_2e
    :goto_2e
    return-object p1
.end method

.method public varargs h(Lio/sentry/y1;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V
    .registers 7

    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/ILogger;

    if-eqz v0, :cond_f

    invoke-virtual {p0, p1}, LA3/c;->m(Lio/sentry/y1;)Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-interface {v0, p1, p2, p3, p4}, Lio/sentry/ILogger;->h(Lio/sentry/y1;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_f
    return-void
.end method

.method public j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V
    .registers 6

    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/ILogger;

    if-eqz v0, :cond_f

    invoke-virtual {p0, p1}, LA3/c;->m(Lio/sentry/y1;)Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-interface {v0, p1, p2, p3}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_f
    return-void
.end method

.method public varargs k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V
    .registers 6

    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/ILogger;

    if-eqz v0, :cond_f

    invoke-virtual {p0, p1}, LA3/c;->m(Lio/sentry/y1;)Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-interface {v0, p1, p2, p3}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_f
    return-void
.end method

.method public m(Lio/sentry/y1;)Z
    .registers 5

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, Lio/sentry/M1;

    invoke-virtual {v0}, Lio/sentry/M1;->getDiagnosticLevel()Lio/sentry/y1;

    move-result-object v1

    const/4 v2, 0x0

    if-nez p1, :cond_c

    return v2

    :cond_c
    invoke-virtual {v0}, Lio/sentry/M1;->isDebug()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    if-lt p1, v0, :cond_1d

    const/4 v2, 0x1

    :cond_1d
    return v2
.end method

.method public o()Ljava/io/File;
    .registers 5

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v1

    iget-object v2, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    if-nez v1, :cond_10

    const/4 v1, 0x0

    goto :goto_18

    :cond_10
    if-eqz v2, :cond_18

    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v1, v3

    :cond_18
    :goto_18
    if-eqz v1, :cond_21

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_21

    return-object v1

    :cond_21
    invoke-virtual {v0}, Landroid/content/Context;->getExternalCacheDir()Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_37

    invoke-virtual {v0}, Ljava/io/File;->canWrite()Z

    move-result v3

    if-nez v3, :cond_2e

    goto :goto_37

    :cond_2e
    if-eqz v2, :cond_36

    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v1

    :cond_36
    return-object v0

    :cond_37
    :goto_37
    return-object v1
.end method

.method public p(LD1/o;J)LD1/j;
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-wide v5, v1, LD1/o;->d:J

    iget-wide v2, v1, LD1/o;->c:J

    sub-long/2addr v2, v5

    const-wide/16 v7, 0x4e20

    invoke-static {v7, v8, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    long-to-int v2, v2

    iget-object v3, v0, LA3/c;->b:Ljava/lang/Object;

    check-cast v3, LZ0/w;

    invoke-virtual {v3, v2}, LZ0/w;->D(I)V

    iget-object v4, v3, LZ0/w;->a:[B

    const/4 v7, 0x0

    invoke-virtual {v1, v4, v7, v2, v7}, LD1/o;->d([BIIZ)Z

    const/4 v1, -0x1

    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    move v2, v1

    move-wide v11, v7

    :goto_25
    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v4

    const/4 v9, 0x4

    if-lt v4, v9, :cond_120

    iget-object v4, v3, LZ0/w;->a:[B

    iget v10, v3, LZ0/w;->b:I

    invoke-static {v10, v4}, Lj2/A;->d(I[B)I

    move-result v4

    const/4 v10, 0x1

    const/16 v13, 0x1ba

    if-eq v4, v13, :cond_3d

    invoke-virtual {v3, v10}, LZ0/w;->H(I)V

    goto :goto_25

    :cond_3d
    invoke-virtual {v3, v9}, LZ0/w;->H(I)V

    invoke-static {v3}, Lj2/B;->c(LZ0/w;)J

    move-result-wide v14

    cmp-long v1, v14, v7

    if-eqz v1, :cond_92

    iget-object v1, v0, LA3/c;->a:Ljava/lang/Object;

    check-cast v1, LZ0/C;

    invoke-virtual {v1, v14, v15}, LZ0/C;->b(J)J

    move-result-wide v14

    cmp-long v1, v14, p2

    if-lez v1, :cond_74

    cmp-long v1, v11, v7

    if-nez v1, :cond_62

    new-instance v7, LD1/j;

    const/4 v2, -0x1

    move-object v1, v7

    move-wide v3, v14

    invoke-direct/range {v1 .. v6}, LD1/j;-><init>(IJJ)V

    goto/16 :goto_131

    :cond_62
    int-to-long v1, v2

    add-long v11, v5, v1

    new-instance v1, LD1/j;

    const/4 v8, 0x0

    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    move-object v7, v1

    invoke-direct/range {v7 .. v12}, LD1/j;-><init>(IJJ)V

    :goto_71
    move-object v7, v1

    goto/16 :goto_131

    :cond_74
    const-wide/32 v1, 0x186a0

    add-long/2addr v1, v14

    cmp-long v1, v1, p2

    if-lez v1, :cond_8e

    iget v1, v3, LZ0/w;->b:I

    int-to-long v1, v1

    add-long v11, v5, v1

    new-instance v1, LD1/j;

    const/4 v8, 0x0

    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    move-object v7, v1

    invoke-direct/range {v7 .. v12}, LD1/j;-><init>(IJJ)V

    goto :goto_71

    :cond_8e
    iget v1, v3, LZ0/w;->b:I

    move v2, v1

    move-wide v11, v14

    :cond_92
    iget v1, v3, LZ0/w;->c:I

    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v4

    const/16 v14, 0xa

    if-ge v4, v14, :cond_a1

    invoke-virtual {v3, v1}, LZ0/w;->G(I)V

    goto/16 :goto_11c

    :cond_a1
    const/16 v4, 0x9

    invoke-virtual {v3, v4}, LZ0/w;->H(I)V

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v4

    and-int/lit8 v4, v4, 0x7

    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v14

    if-ge v14, v4, :cond_b6

    invoke-virtual {v3, v1}, LZ0/w;->G(I)V

    goto :goto_11c

    :cond_b6
    invoke-virtual {v3, v4}, LZ0/w;->H(I)V

    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v4

    if-ge v4, v9, :cond_c3

    invoke-virtual {v3, v1}, LZ0/w;->G(I)V

    goto :goto_11c

    :cond_c3
    iget-object v4, v3, LZ0/w;->a:[B

    iget v14, v3, LZ0/w;->b:I

    invoke-static {v14, v4}, Lj2/A;->d(I[B)I

    move-result v4

    const/16 v14, 0x1bb

    if-ne v4, v14, :cond_e3

    invoke-virtual {v3, v9}, LZ0/w;->H(I)V

    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v4

    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v14

    if-ge v14, v4, :cond_e0

    invoke-virtual {v3, v1}, LZ0/w;->G(I)V

    goto :goto_11c

    :cond_e0
    invoke-virtual {v3, v4}, LZ0/w;->H(I)V

    :cond_e3
    :goto_e3
    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v4

    if-lt v4, v9, :cond_11c

    iget-object v4, v3, LZ0/w;->a:[B

    iget v14, v3, LZ0/w;->b:I

    invoke-static {v14, v4}, Lj2/A;->d(I[B)I

    move-result v4

    if-eq v4, v13, :cond_11c

    const/16 v14, 0x1b9

    if-ne v4, v14, :cond_f8

    goto :goto_11c

    :cond_f8
    ushr-int/lit8 v4, v4, 0x8

    if-eq v4, v10, :cond_fd

    goto :goto_11c

    :cond_fd
    invoke-virtual {v3, v9}, LZ0/w;->H(I)V

    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v4

    const/4 v14, 0x2

    if-ge v4, v14, :cond_10b

    invoke-virtual {v3, v1}, LZ0/w;->G(I)V

    goto :goto_11c

    :cond_10b
    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v4

    iget v14, v3, LZ0/w;->c:I

    iget v15, v3, LZ0/w;->b:I

    add-int/2addr v15, v4

    invoke-static {v14, v15}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual {v3, v4}, LZ0/w;->G(I)V

    goto :goto_e3

    :cond_11c
    :goto_11c
    iget v1, v3, LZ0/w;->b:I

    goto/16 :goto_25

    :cond_120
    cmp-long v2, v11, v7

    if-eqz v2, :cond_12f

    int-to-long v1, v1

    add-long v13, v5, v1

    new-instance v7, LD1/j;

    const/4 v10, -0x2

    move-object v9, v7

    invoke-direct/range {v9 .. v14}, LD1/j;-><init>(IJJ)V

    goto :goto_131

    :cond_12f
    sget-object v7, LD1/j;->d:LD1/j;

    :goto_131
    return-object v7
.end method

.method public q(Ljava/lang/String;)V
    .registers 4

    const-string v0, "log"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :goto_c
    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result p1

    const/16 v1, 0xa

    if-le p1, v1, :cond_1c

    invoke-static {v0}, Lvc/l;->x(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object p1

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    goto :goto_c

    :cond_1c
    return-void
.end method

.method public r(I)Z
    .registers 3

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, LW0/n;

    iget-object v0, v0, LW0/n;->a:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result p1

    return p1
.end method

.method public s(Lrd/j;Ltd/f;)LYc/c;
    .registers 13

    const-string v0, "proto"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget v0, p1, Lrd/j;->c:I

    invoke-static {p2, v0}, Ll7/X4;->b(Ltd/f;I)Lwd/a;

    move-result-object v0

    iget-object v1, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v1, LXc/F;

    iget-object v2, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v2, LO6/f;

    invoke-static {v1, v0, v2}, Ll7/Y6;->d(LXc/F;Lwd/a;LO6/f;)LXc/f;

    move-result-object v0

    sget-object v1, Lvc/v;->a:Lvc/v;

    iget-object v2, p1, Lrd/j;->d:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-eqz v2, :cond_10c

    invoke-static {v0}, LNd/y;->g(LXc/k;)Z

    move-result v2

    if-nez v2, :cond_10c

    const/4 v2, 0x5

    invoke-static {v0, v2}, Lzd/e;->n(LXc/k;I)Z

    move-result v2

    if-eqz v2, :cond_10c

    invoke-interface {v0}, LXc/f;->r()Ljava/util/Collection;

    move-result-object v2

    const-string v3, "annotationClass.constructors"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lvc/l;->Q(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LXc/e;

    if-eqz v2, :cond_10c

    check-cast v2, Lad/z;

    invoke-virtual {v2}, Lad/z;->O()Ljava/util/List;

    move-result-object v1

    const-string v2, "constructor.valueParameters"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    const/16 v2, 0xa

    invoke-static {v1, v2}, Lvc/n;->j(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-static {v2}, Lvc/A;->d(I)I

    move-result v2

    const/16 v3, 0x10

    if-ge v2, v3, :cond_62

    move v2, v3

    :cond_62
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_6b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_82

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Lad/T;

    check-cast v4, Lad/p;

    invoke-virtual {v4}, Lad/p;->getName()Lwd/e;

    move-result-object v4

    invoke-interface {v3, v4, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6b

    :cond_82
    iget-object p1, p1, Lrd/j;->d:Ljava/util/List;

    const-string v1, "proto.argumentList"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_94
    :goto_94
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_108

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lrd/h;

    const-string v4, "it"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget v4, v2, Lrd/h;->c:I

    invoke-static {p2, v4}, Ll7/X4;->c(Ltd/f;I)Lwd/e;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lad/T;

    const/4 v5, 0x0

    if-nez v4, :cond_b5

    goto :goto_102

    :cond_b5
    new-instance v6, Luc/h;

    iget v7, v2, Lrd/h;->c:I

    invoke-static {p2, v7}, Ll7/X4;->c(Ltd/f;I)Lwd/e;

    move-result-object v7

    check-cast v4, Lad/U;

    invoke-virtual {v4}, Lad/U;->getType()LNd/F;

    move-result-object v4

    const-string v8, "parameter.type"

    invoke-static {v4, v8}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v2, Lrd/h;->d:Lrd/g;

    const-string v8, "proto.value"

    invoke-static {v2, v8}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v4, v2, p2}, LA3/c;->H(LNd/F;Lrd/g;Ltd/f;)LBd/g;

    move-result-object v8

    invoke-virtual {p0, v8, v4, v2}, LA3/c;->t(LBd/g;LNd/F;Lrd/g;)Z

    move-result v9

    if-eqz v9, :cond_da

    move-object v5, v8

    :cond_da
    if-nez v5, :cond_fe

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "Unexpected argument value: actual type "

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v2, Lrd/g;->c:Lrd/f;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " != expected type "

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v4, "message"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v5, LBd/l;

    invoke-direct {v5, v2}, LBd/l;-><init>(Ljava/lang/String;)V

    :cond_fe
    invoke-direct {v6, v7, v5}, Luc/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v5, v6

    :goto_102
    if-eqz v5, :cond_94

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_94

    :cond_108
    invoke-static {v1}, Lvc/A;->i(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v1

    :cond_10c
    new-instance p1, LYc/c;

    invoke-interface {v0}, LXc/f;->j()LNd/M;

    move-result-object p2

    sget-object v0, LXc/V;->a:LXc/U;

    invoke-direct {p1, p2, v1, v0}, LYc/c;-><init>(LNd/M;Ljava/util/Map;LXc/V;)V

    return-object p1
.end method

.method public t(LBd/g;LNd/F;Lrd/g;)Z
    .registers 10

    iget-object v0, p3, Lrd/g;->c:Lrd/f;

    if-nez v0, :cond_6

    const/4 v0, -0x1

    goto :goto_e

    :cond_6
    sget-object v1, LJd/b;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    :goto_e
    const/16 v1, 0xa

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v0, v1, :cond_a3

    const/16 v1, 0xd

    iget-object v4, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v4, LXc/F;

    if-eq v0, v1, :cond_26

    invoke-virtual {p1, v4}, LBd/g;->a(LXc/F;)LNd/F;

    move-result-object p1

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    goto/16 :goto_bf

    :cond_26
    instance-of v0, p1, LBd/b;

    if-eqz v0, :cond_93

    move-object v0, p1

    check-cast v0, LBd/b;

    iget-object v0, v0, LBd/g;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    iget-object v1, p3, Lrd/g;->k:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ne v0, v1, :cond_93

    invoke-interface {v4}, LXc/F;->e()LUc/j;

    move-result-object v0

    invoke-virtual {v0, p2}, LUc/j;->f(LNd/F;)LNd/F;

    move-result-object p2

    check-cast p1, LBd/b;

    iget-object v0, p1, LBd/g;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/Collection;

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, LNc/f;

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-direct {v1, v3, v0, v2}, LNc/d;-><init>(III)V

    instance-of v0, v1, Ljava/util/Collection;

    if-eqz v0, :cond_68

    move-object v0, v1

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_68

    goto :goto_bf

    :cond_68
    invoke-virtual {v1}, LNc/d;->f()LNc/e;

    move-result-object v0

    :cond_6c
    iget-boolean v1, v0, LNc/e;->c:Z

    if-eqz v1, :cond_bf

    invoke-virtual {v0}, LNc/e;->a()I

    move-result v1

    iget-object v4, p1, LBd/g;->a:Ljava/lang/Object;

    check-cast v4, Ljava/util/List;

    invoke-interface {v4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LBd/g;

    iget-object v5, p3, Lrd/g;->k:Ljava/util/List;

    invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lrd/g;

    const-string v5, "value.getArrayElement(i)"

    invoke-static {v1, v5}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v4, p2, v1}, LA3/c;->t(LBd/g;LNd/F;Lrd/g;)Z

    move-result v1

    if-nez v1, :cond_6c

    :cond_91
    move v2, v3

    goto :goto_bf

    :cond_93
    const-string p2, "Deserialized ArrayValue should have the same number of elements as the original array value: "

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l;->k(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_a3
    invoke-virtual {p2}, LNd/F;->N()LNd/T;

    move-result-object p1

    invoke-interface {p1}, LNd/T;->f()LXc/h;

    move-result-object p1

    instance-of p2, p1, LXc/f;

    if-eqz p2, :cond_b2

    check-cast p1, LXc/f;

    goto :goto_b3

    :cond_b2
    const/4 p1, 0x0

    :goto_b3
    if-eqz p1, :cond_bf

    sget-object p2, LUc/j;->e:Lwd/e;

    sget-object p2, LUc/m;->W:Lwd/d;

    invoke-static {p1, p2}, LUc/j;->b(LXc/h;Lwd/d;)Z

    move-result p1

    if-eqz p1, :cond_91

    :cond_bf
    :goto_bf
    return v2
.end method

.method public declared-synchronized u(LIe/j;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, LIe/j;

    if-eqz v0, :cond_e

    iput-object p1, v0, LIe/j;->c:LIe/j;

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    goto :goto_18

    :catchall_c
    move-exception p1

    goto :goto_25

    :cond_e
    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, LIe/j;

    if-nez v0, :cond_1d

    iput-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    iput-object p1, p0, LA3/c;->a:Ljava/lang/Object;

    :goto_18
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_1b
    .catchall {:try_start_1 .. :try_end_1b} :catchall_c

    monitor-exit p0

    return-void

    :cond_1d
    :try_start_1d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Head present, but no tail"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_25
    .catchall {:try_start_1d .. :try_end_25} :catchall_c

    :goto_25
    monitor-exit p0

    throw p1
.end method

.method public v(Landroid/net/Uri;Lc1/i;)Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, Ly1/C;

    invoke-interface {v0, p1, p2}, Ly1/C;->v(Landroid/net/Uri;Lc1/i;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lq1/a;

    iget-object p2, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast p2, Ljava/util/List;

    if-eqz p2, :cond_1d

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_17

    goto :goto_1d

    :cond_17
    invoke-interface {p1, p2}, Lq1/a;->a(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lq1/a;

    :cond_1d
    :goto_1d
    return-object p1
.end method

.method public w()I
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public varargs x([Ljava/lang/Object;)LD1/w;
    .registers 6

    iget-object v0, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    monitor-enter v0

    :try_start_5
    iget-object v1, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_15

    monitor-exit v0
    :try_end_11
    .catchall {:try_start_5 .. :try_end_11} :catchall_13

    :goto_11
    move-object v1, v2

    goto :goto_32

    :catchall_13
    move-exception p1

    goto :goto_45

    :cond_15
    :try_start_15
    iget-object v1, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v1, LD1/r;

    invoke-interface {v1}, LD1/r;->c()Ljava/lang/reflect/Constructor;

    move-result-object v1
    :try_end_1d
    .catch Ljava/lang/ClassNotFoundException; {:try_start_15 .. :try_end_1d} :catch_28
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_1d} :catch_1f
    .catchall {:try_start_15 .. :try_end_1d} :catchall_13

    :try_start_1d
    monitor-exit v0

    goto :goto_32

    :catch_1f
    move-exception p1

    new-instance v1, Ljava/lang/RuntimeException;

    const-string v2, "Error instantiating extension"

    invoke-direct {v1, v2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :catch_28
    iget-object v1, p0, LA3/c;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    monitor-exit v0
    :try_end_31
    .catchall {:try_start_1d .. :try_end_31} :catchall_13

    goto :goto_11

    :goto_32
    if-nez v1, :cond_35

    return-object v2

    :cond_35
    :try_start_35
    invoke-virtual {v1, p1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LD1/w;
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_3b} :catch_3c

    return-object p1

    :catch_3c
    move-exception p1

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Unexpected error creating extractor"

    invoke-direct {v0, v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :goto_45
    :try_start_45
    monitor-exit v0
    :try_end_46
    .catchall {:try_start_45 .. :try_end_46} :catchall_13

    throw p1
.end method

.method public y(LA3/b;)Ljava/lang/Object;
    .registers 2

    iget-object p1, p0, LA3/c;->b:Ljava/lang/Object;

    return-object p1
.end method

.method public z(FFLjava/lang/Object;Ljava/lang/Object;FFF)Ljava/lang/Object;
    .registers 9

    iget-object v0, p0, LA3/c;->a:Ljava/lang/Object;

    check-cast v0, LA3/b;

    iput p1, v0, LA3/b;->a:F

    iput p2, v0, LA3/b;->b:F

    iput-object p3, v0, LA3/b;->c:Ljava/lang/Object;

    iput-object p4, v0, LA3/b;->d:Ljava/lang/Object;

    iput p5, v0, LA3/b;->e:F

    iput p6, v0, LA3/b;->f:F

    iput p7, v0, LA3/b;->g:F

    invoke-virtual {p0, v0}, LA3/c;->y(LA3/b;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
