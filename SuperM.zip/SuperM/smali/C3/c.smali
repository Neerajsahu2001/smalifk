.class public final synthetic Lc3/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:Lapp/notifee/core/database/a;

.field public final synthetic b:Ljava/lang/Boolean;


# direct methods
.method public synthetic constructor <init>(Lapp/notifee/core/database/a;)V
    .registers 3

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc3/c;->a:Lapp/notifee/core/database/a;

    iput-object v0, p0, Lc3/c;->b:Ljava/lang/Boolean;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 15

    iget-object v0, p0, Lc3/c;->a:Lapp/notifee/core/database/a;

    iget-object v0, v0, Lapp/notifee/core/database/a;->a:Lte/o;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "SELECT * FROM work_data WHERE with_alarm_manager = ?"

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ls2/m;->i(ILjava/lang/String;)Ls2/m;

    move-result-object v1

    const/4 v3, 0x0

    iget-object v4, p0, Lc3/c;->b:Ljava/lang/Boolean;

    if-nez v4, :cond_15

    move-object v4, v3

    goto :goto_1d

    :cond_15
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    :goto_1d
    if-nez v4, :cond_23

    invoke-virtual {v1, v2}, Ls2/m;->S(I)V

    goto :goto_2b

    :cond_23
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    int-to-long v4, v4

    invoke-virtual {v1, v2, v4, v5}, Ls2/m;->E(IJ)V

    :goto_2b
    iget-object v0, v0, Lte/o;->a:Ljava/lang/Object;

    check-cast v0, Ls2/k;

    invoke-virtual {v0}, Ls2/k;->b()V

    invoke-virtual {v0, v1, v3}, Ls2/k;->m(Ly2/e;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v0

    :try_start_36
    const-string v4, "id"

    invoke-static {v0, v4}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v5, "notification"

    invoke-static {v0, v5}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v5

    const-string v6, "trigger"

    invoke-static {v0, v6}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v6

    const-string v7, "with_alarm_manager"

    invoke-static {v0, v7}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    new-instance v8, Ljava/util/ArrayList;

    invoke-interface {v0}, Landroid/database/Cursor;->getCount()I

    move-result v9

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    :goto_57
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v9

    if-eqz v9, :cond_ad

    invoke-interface {v0, v4}, Landroid/database/Cursor;->isNull(I)Z

    move-result v9

    if-eqz v9, :cond_65

    move-object v9, v3

    goto :goto_69

    :cond_65
    invoke-interface {v0, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v9

    :goto_69
    invoke-interface {v0, v5}, Landroid/database/Cursor;->isNull(I)Z

    move-result v10

    if-eqz v10, :cond_71

    move-object v10, v3

    goto :goto_75

    :cond_71
    invoke-interface {v0, v5}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v10

    :goto_75
    invoke-interface {v0, v6}, Landroid/database/Cursor;->isNull(I)Z

    move-result v11

    if-eqz v11, :cond_7d

    move-object v11, v3

    goto :goto_81

    :cond_7d
    invoke-interface {v0, v6}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v11

    :goto_81
    invoke-interface {v0, v7}, Landroid/database/Cursor;->isNull(I)Z

    move-result v12

    if-eqz v12, :cond_89

    move-object v12, v3

    goto :goto_91

    :cond_89
    invoke-interface {v0, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v12

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    :goto_91
    if-nez v12, :cond_95

    move-object v12, v3

    goto :goto_a2

    :cond_95
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-eqz v12, :cond_9d

    move v12, v2

    goto :goto_9e

    :cond_9d
    const/4 v12, 0x0

    :goto_9e
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    :goto_a2
    new-instance v13, Lte/p;

    invoke-direct {v13, v9, v10, v11, v12}, Lte/p;-><init>(Ljava/lang/String;[B[BLjava/lang/Boolean;)V

    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_aa
    .catchall {:try_start_36 .. :try_end_aa} :catchall_ab

    goto :goto_57

    :catchall_ab
    move-exception v2

    goto :goto_b4

    :cond_ad
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    invoke-virtual {v1}, Ls2/m;->l()V

    return-object v8

    :goto_b4
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    invoke-virtual {v1}, Ls2/m;->l()V

    throw v2
.end method
