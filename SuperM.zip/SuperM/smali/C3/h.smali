.class public final LC3/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:Z

.field public final d:Z

.field public final e:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LC3/h;

    const/4 v1, 0x1

    invoke-direct {v0, v1, v1, v1, v1}, LC3/h;-><init>(ZZZZ)V

    new-instance v0, LC3/h;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1, v1, v1}, LC3/h;-><init>(ZZZZ)V

    return-void
.end method

.method public constructor <init>(ZZZZ)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, LC3/h;->a:Z

    iput-boolean p2, p0, LC3/h;->b:Z

    iput-boolean p3, p0, LC3/h;->c:Z

    iput-boolean p4, p0, LC3/h;->d:Z

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LC3/h;->e:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/LinkedHashSet;
    .registers 3

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-boolean v1, p0, LC3/h;->a:Z

    if-eqz v1, :cond_e

    sget-object v1, LC3/f;->a:LC3/f;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_e
    iget-boolean v1, p0, LC3/h;->b:Z

    if-eqz v1, :cond_17

    sget-object v1, LC3/f;->b:LC3/f;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_17
    iget-boolean v1, p0, LC3/h;->c:Z

    if-eqz v1, :cond_20

    sget-object v1, LC3/f;->c:LC3/f;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_20
    iget-boolean v1, p0, LC3/h;->d:Z

    if-eqz v1, :cond_29

    sget-object v1, LC3/f;->d:LC3/f;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_29
    return-object v0
.end method
