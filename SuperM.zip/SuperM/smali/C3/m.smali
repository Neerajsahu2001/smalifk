.class public final LC3/m;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field public final synthetic b:LC3/n;

.field public c:I


# direct methods
.method public constructor <init>(LC3/n;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LC3/m;->b:LC3/n;

    invoke-direct {p0, p2}, LAc/c;-><init>(Lyc/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iput-object p1, p0, LC3/m;->a:Ljava/lang/Object;

    iget p1, p0, LC3/m;->c:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LC3/m;->c:I

    iget-object p1, p0, LC3/m;->b:LC3/n;

    const-wide/16 v0, 0x0

    invoke-virtual {p1, v0, v1, p0}, LC3/n;->g0(JLyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
