.class public final enum LC3/f;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum a:LC3/f;

.field public static final enum b:LC3/f;

.field public static final enum c:LC3/f;

.field public static final enum d:LC3/f;

.field public static final enum e:LC3/f;

.field public static final synthetic f:[LC3/f;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    new-instance v0, LC3/f;

    const-string v1, "SESSIONS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, LC3/f;->a:LC3/f;

    new-instance v1, LC3/f;

    const-string v2, "APP_LIFECYCLES"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, LC3/f;->b:LC3/f;

    new-instance v2, LC3/f;

    const-string v3, "DEEP_LINKS"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, LC3/f;->c:LC3/f;

    new-instance v3, LC3/f;

    const-string v4, "SCREEN_VIEWS"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LC3/f;->d:LC3/f;

    new-instance v4, LC3/f;

    const-string v5, "ELEMENT_INTERACTIONS"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, LC3/f;->e:LC3/f;

    filled-new-array {v0, v1, v2, v3, v4}, [LC3/f;

    move-result-object v0

    sput-object v0, LC3/f;->f:[LC3/f;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LC3/f;
    .registers 2

    const-class v0, LC3/f;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LC3/f;

    return-object p0
.end method

.method public static values()[LC3/f;
    .registers 1

    sget-object v0, LC3/f;->f:[LC3/f;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LC3/f;

    return-object v0
.end method
