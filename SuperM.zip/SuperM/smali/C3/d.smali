.class public final LC3/d;
.super Ljava/lang/Thread;
.source "SourceFile"


# instance fields
.field public final synthetic a:LC3/e;


# direct methods
.method public constructor <init>(LC3/e;)V
    .registers 2

    iput-object p1, p0, LC3/d;->a:LC3/e;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, LC3/d;->a:LC3/e;

    iget-object v0, v0, LC3/e;->h:LC3/n;

    const-string v1, "null cannot be cast to non-null type com.amplitude.android.Timeline"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x0

    iget-object v0, v0, LC3/n;->e:Lde/c;

    invoke-virtual {v0, v1}, Lde/c;->f(Ljava/util/concurrent/CancellationException;)V

    return-void
.end method
