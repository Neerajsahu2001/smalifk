.class public final LC3/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final A:Lk7/B;

.field public final B:Z

.field public C:Ljava/lang/Boolean;

.field public final D:Ljava/lang/String;

.field public final E:Ljava/lang/Long;

.field public F:Ljava/util/Set;

.field public final G:I

.field public final a:Ljava/lang/String;

.field public final b:Landroid/content/Context;

.field public final c:I

.field public final d:I

.field public final e:Ljava/lang/String;

.field public final f:Z

.field public final g:LU7/e;

.field public final h:Lcom/android/installreferrer/api/d;

.field public final i:Ljava/lang/Integer;

.field public final j:Ljava/lang/String;

.field public final k:LHc/d;

.field public final l:I

.field public final m:Z

.field public final n:Ljava/lang/String;

.field public final o:LB0/o;

.field public final p:LP3/b;

.field public final q:Z

.field public final r:Z

.field public final s:Z

.field public final t:LC3/o;

.field public final u:Z

.field public final v:Z

.field public final w:Z

.field public final x:J

.field public final y:J

.field public final z:LU7/e;


# direct methods
.method public constructor <init>(Landroid/content/Context;LC3/h;)V
    .registers 13

    new-instance v0, LU7/e;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, LU7/e;-><init>(I)V

    new-instance v1, Lcom/android/installreferrer/api/d;

    const/4 v2, 0x6

    invoke-direct {v1, v2}, Lcom/android/installreferrer/api/d;-><init>(I)V

    new-instance v2, LC3/o;

    invoke-direct {v2}, LC3/o;-><init>()V

    new-instance v3, LU7/e;

    const/4 v4, 0x5

    invoke-direct {v3, v4}, LU7/e;-><init>(I)V

    new-instance v4, Lk7/B;

    const/4 v5, 0x5

    invoke-direct {v4, v5}, Lk7/B;-><init>(I)V

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const-string v6, "context"

    invoke-static {p1, v6}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "serverZone"

    const/4 v7, 0x1

    invoke-static {v7, v6}, Le/b;->o(ILjava/lang/String;)V

    invoke-virtual {p2}, LC3/h;->a()Ljava/util/LinkedHashSet;

    move-result-object v6

    const-string v8, "$default_instance"

    const-string v9, "serverZone"

    invoke-static {v7, v9}, Le/b;->o(ILjava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v9, "fcc24cd8e725572e8604d30fb4440353"

    iput-object v9, p0, LC3/g;->a:Ljava/lang/String;

    iput-object p1, p0, LC3/g;->b:Landroid/content/Context;

    const/16 p1, 0x1e

    iput p1, p0, LC3/g;->c:I

    const/16 p1, 0x7530

    iput p1, p0, LC3/g;->d:I

    iput-object v8, p0, LC3/g;->e:Ljava/lang/String;

    const/4 p1, 0x0

    iput-boolean p1, p0, LC3/g;->f:Z

    iput-object v0, p0, LC3/g;->g:LU7/e;

    iput-object v1, p0, LC3/g;->h:Lcom/android/installreferrer/api/d;

    const/4 v0, 0x0

    iput-object v0, p0, LC3/g;->i:Ljava/lang/Integer;

    iput-object v0, p0, LC3/g;->j:Ljava/lang/String;

    iput-object v0, p0, LC3/g;->k:LHc/d;

    const/4 v1, 0x5

    iput v1, p0, LC3/g;->l:I

    iput-boolean p1, p0, LC3/g;->m:Z

    iput v7, p0, LC3/g;->G:I

    iput-object v0, p0, LC3/g;->n:Ljava/lang/String;

    iput-object v0, p0, LC3/g;->o:LB0/o;

    iput-object v0, p0, LC3/g;->p:LP3/b;

    iput-boolean p1, p0, LC3/g;->q:Z

    iput-boolean p1, p0, LC3/g;->r:Z

    iput-boolean p1, p0, LC3/g;->s:Z

    iput-object v2, p0, LC3/g;->t:LC3/o;

    iput-boolean p1, p0, LC3/g;->u:Z

    const/4 p1, 0x1

    iput-boolean p1, p0, LC3/g;->v:Z

    iput-boolean p1, p0, LC3/g;->w:Z

    const-wide/32 v1, 0x493e0

    iput-wide v1, p0, LC3/g;->x:J

    const-wide/16 v1, 0x7530

    iput-wide v1, p0, LC3/g;->y:J

    iput-object v3, p0, LC3/g;->z:LU7/e;

    iput-object v4, p0, LC3/g;->A:Lk7/B;

    iput-boolean p1, p0, LC3/g;->B:Z

    iput-object v5, p0, LC3/g;->C:Ljava/lang/Boolean;

    iput-object v0, p0, LC3/g;->D:Ljava/lang/String;

    iput-object v0, p0, LC3/g;->E:Ljava/lang/Long;

    invoke-static {v6}, Lvc/l;->Z(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    iput-object p1, p0, LC3/g;->F:Ljava/util/Set;

    new-instance p1, LC3/h;

    new-instance v0, LBd/h;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0}, LBd/h;-><init>(ILjava/lang/Object;)V

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1, v1, v2, v2, v2}, LC3/h;-><init>(ZZZZ)V

    iget-object p1, p1, LC3/h;->e:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p2, LC3/h;->e:Ljava/util/ArrayList;

    invoke-virtual {p2}, LC3/h;->a()Ljava/util/LinkedHashSet;

    move-result-object p2

    iput-object p2, p0, LC3/g;->F:Ljava/util/Set;

    new-instance p2, LBd/i;

    const/4 v0, 0x1

    invoke-direct {p2, v0, p0}, LBd/i;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method
