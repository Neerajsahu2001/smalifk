.class public final LC3/n;
.super Lfc/l;
.source "SourceFile"


# instance fields
.field public final d:Ljava/lang/Long;

.field public final e:Lde/c;

.field public final f:Ljava/util/concurrent/atomic/AtomicLong;

.field public g:Z

.field public h:J

.field public i:J


# direct methods
.method public constructor <init>(Ljava/lang/Long;)V
    .registers 7

    const/16 v0, 0xa

    invoke-direct {p0, v0}, Lfc/l;-><init>(I)V

    iput-object p1, p0, LC3/n;->d:Ljava/lang/Long;

    const/4 v0, 0x6

    const v1, 0x7fffffff

    const/4 v2, 0x0

    invoke-static {v1, v0, v2}, Lm7/B4;->a(IILde/a;)Lde/c;

    move-result-object v0

    iput-object v0, p0, LC3/n;->e:Lde/c;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 v1, -0x1

    if-eqz p1, :cond_1d

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    goto :goto_1e

    :cond_1d
    move-wide v3, v1

    :goto_1e
    invoke-direct {v0, v3, v4}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    iput-object v0, p0, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    iput-wide v1, p0, LC3/n;->i:J

    return-void
.end method

.method public static final c0(LC3/n;LC3/i;Lyc/d;)Ljava/lang/Object;
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v2, v1, LC3/j;

    if-eqz v2, :cond_1a

    move-object v2, v1

    check-cast v2, LC3/j;

    iget v3, v2, LC3/j;->h:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_1a

    sub-int/2addr v3, v4

    iput v3, v2, LC3/j;->h:I

    goto :goto_1f

    :cond_1a
    new-instance v2, LC3/j;

    invoke-direct {v2, v0, v1}, LC3/j;-><init>(LC3/n;Lyc/d;)V

    :goto_1f
    iget-object v1, v2, LC3/j;->f:Ljava/lang/Object;

    sget-object v3, Lzc/a;->a:Lzc/a;

    iget v4, v2, LC3/j;->h:I

    sget-object v5, Luc/z;->a:Luc/z;

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    packed-switch v4, :pswitch_data_202

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_35
    iget v0, v2, LC3/j;->e:I

    iget-object v3, v2, LC3/j;->c:Ljava/lang/Iterable;

    check-cast v3, Ljava/lang/Iterable;

    iget-object v4, v2, LC3/j;->b:LP3/a;

    iget-object v2, v2, LC3/j;->a:LC3/n;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto/16 :goto_1e1

    :pswitch_44
    iget v6, v2, LC3/j;->e:I

    iget-object v0, v2, LC3/j;->b:LP3/a;

    iget-object v4, v2, LC3/j;->a:LC3/n;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object v1, v0

    move-object v0, v4

    goto/16 :goto_156

    :pswitch_51
    iget v6, v2, LC3/j;->e:I

    iget-object v0, v2, LC3/j;->b:LP3/a;

    iget-object v4, v2, LC3/j;->a:LC3/n;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object/from16 v16, v1

    move-object v1, v0

    move-object v0, v4

    move-object/from16 v4, v16

    goto/16 :goto_153

    :pswitch_62
    iget v7, v2, LC3/j;->e:I

    iget-object v0, v2, LC3/j;->b:LP3/a;

    iget-object v4, v2, LC3/j;->a:LC3/n;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object v1, v0

    move-object v0, v4

    goto/16 :goto_139

    :pswitch_6f
    iget v0, v2, LC3/j;->e:I

    iget-object v4, v2, LC3/j;->b:LP3/a;

    iget-object v6, v2, LC3/j;->a:LC3/n;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object/from16 v16, v6

    move v6, v0

    move-object/from16 v0, v16

    goto/16 :goto_117

    :pswitch_7f
    iget v0, v2, LC3/j;->e:I

    iget-object v4, v2, LC3/j;->b:LP3/a;

    iget-object v6, v2, LC3/j;->a:LC3/n;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object/from16 v16, v6

    move v6, v0

    move-object/from16 v0, v16

    goto/16 :goto_168

    :pswitch_8f
    iget v6, v2, LC3/j;->e:I

    iget-wide v9, v2, LC3/j;->d:J

    iget-object v0, v2, LC3/j;->b:LP3/a;

    iget-object v4, v2, LC3/j;->a:LC3/n;

    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object/from16 v16, v4

    move-object v4, v0

    move-object/from16 v0, v16

    goto :goto_d8

    :pswitch_a0
    invoke-static {v1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object/from16 v1, p1

    iget-object v1, v1, LC3/i;->a:LP3/a;

    iget-object v4, v1, LP3/a;->c:Ljava/lang/Long;

    invoke-static {v4}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    iget-object v4, v1, LP3/a;->e:Ljava/lang/Long;

    invoke-virtual {v1}, LP3/a;->a()Ljava/lang/String;

    move-result-object v11

    const-string v12, "session_start"

    invoke-virtual {v11, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_e8

    if-eqz v4, :cond_c5

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v11

    goto :goto_c6

    :cond_c5
    move-wide v11, v9

    :goto_c6
    iput-object v0, v2, LC3/j;->a:LC3/n;

    iput-object v1, v2, LC3/j;->b:LP3/a;

    iput-wide v9, v2, LC3/j;->d:J

    iput v6, v2, LC3/j;->e:I

    iput v7, v2, LC3/j;->h:I

    invoke-virtual {v0, v11, v12, v2}, LC3/n;->e0(JLAc/c;)V

    if-ne v5, v3, :cond_d7

    goto/16 :goto_200

    :cond_d7
    move-object v4, v1

    :goto_d8
    iput-object v0, v2, LC3/j;->a:LC3/n;

    iput-object v4, v2, LC3/j;->b:LP3/a;

    iput v6, v2, LC3/j;->e:I

    const/4 v1, 0x2

    iput v1, v2, LC3/j;->h:I

    invoke-virtual {v0, v9, v10, v2}, LC3/n;->d0(JLAc/c;)Luc/z;

    if-ne v5, v3, :cond_168

    goto/16 :goto_200

    :cond_e8
    invoke-virtual {v1}, LP3/a;->a()Ljava/lang/String;

    move-result-object v4

    const-string v11, "session_end"

    invoke-virtual {v4, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_156

    invoke-virtual {v1}, LP3/a;->a()Ljava/lang/String;

    move-result-object v4

    const-string v11, "dummy_enter_foreground"

    invoke-virtual {v4, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_11d

    iput-object v0, v2, LC3/j;->a:LC3/n;

    iput-object v1, v2, LC3/j;->b:LP3/a;

    iput v7, v2, LC3/j;->e:I

    const/4 v4, 0x3

    iput v4, v2, LC3/j;->h:I

    invoke-virtual {v0, v9, v10, v2}, LC3/n;->g0(JLyc/d;)Ljava/lang/Object;

    move-result-object v4

    if-ne v4, v3, :cond_111

    goto/16 :goto_200

    :cond_111
    move v6, v7

    move-object/from16 v16, v4

    move-object v4, v1

    move-object/from16 v1, v16

    :goto_117
    move-object v8, v1

    check-cast v8, Ljava/lang/Iterable;

    iput-boolean v7, v0, LC3/n;->g:Z

    goto :goto_168

    :cond_11d
    invoke-virtual {v1}, LP3/a;->a()Ljava/lang/String;

    move-result-object v4

    const-string v11, "dummy_exit_foreground"

    invoke-virtual {v4, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_13e

    iput-object v0, v2, LC3/j;->a:LC3/n;

    iput-object v1, v2, LC3/j;->b:LP3/a;

    iput v7, v2, LC3/j;->e:I

    const/4 v4, 0x4

    iput v4, v2, LC3/j;->h:I

    invoke-virtual {v0, v9, v10, v2}, LC3/n;->d0(JLAc/c;)Luc/z;

    if-ne v5, v3, :cond_139

    goto/16 :goto_200

    :cond_139
    :goto_139
    iput-boolean v6, v0, LC3/n;->g:Z

    move-object v4, v1

    move v6, v7

    goto :goto_168

    :cond_13e
    iget-boolean v4, v0, LC3/n;->g:Z

    if-nez v4, :cond_158

    iput-object v0, v2, LC3/j;->a:LC3/n;

    iput-object v1, v2, LC3/j;->b:LP3/a;

    iput v6, v2, LC3/j;->e:I

    const/4 v4, 0x5

    iput v4, v2, LC3/j;->h:I

    invoke-virtual {v0, v9, v10, v2}, LC3/n;->g0(JLyc/d;)Ljava/lang/Object;

    move-result-object v4

    if-ne v4, v3, :cond_153

    goto/16 :goto_200

    :cond_153
    :goto_153
    move-object v8, v4

    check-cast v8, Ljava/lang/Iterable;

    :cond_156
    :goto_156
    move-object v4, v1

    goto :goto_168

    :cond_158
    iput-object v0, v2, LC3/j;->a:LC3/n;

    iput-object v1, v2, LC3/j;->b:LP3/a;

    iput v6, v2, LC3/j;->e:I

    const/4 v4, 0x6

    iput v4, v2, LC3/j;->h:I

    invoke-virtual {v0, v9, v10, v2}, LC3/n;->d0(JLAc/c;)Luc/z;

    if-ne v5, v3, :cond_156

    goto/16 :goto_200

    :cond_168
    :goto_168
    if-nez v6, :cond_17b

    iget-object v1, v4, LP3/a;->e:Ljava/lang/Long;

    if-nez v1, :cond_17b

    iget-object v1, v0, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v9

    new-instance v1, Ljava/lang/Long;

    invoke-direct {v1, v9, v10}, Ljava/lang/Long;-><init>(J)V

    iput-object v1, v4, LP3/a;->e:Ljava/lang/Long;

    :cond_17b
    iget-wide v9, v0, LC3/n;->h:J

    const-wide/16 v11, 0x1

    if-eqz v8, :cond_1a2

    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_185
    :goto_185
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1a2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LP3/a;

    iget-object v13, v7, LP3/a;->d:Ljava/lang/Long;

    if-nez v13, :cond_185

    iget-wide v13, v0, LC3/n;->h:J

    add-long/2addr v13, v11

    new-instance v15, Ljava/lang/Long;

    invoke-direct {v15, v13, v14}, Ljava/lang/Long;-><init>(J)V

    iput-object v15, v7, LP3/a;->d:Ljava/lang/Long;

    iput-wide v13, v0, LC3/n;->h:J

    goto :goto_185

    :cond_1a2
    if-nez v6, :cond_1b4

    iget-object v1, v4, LP3/a;->d:Ljava/lang/Long;

    if-nez v1, :cond_1b4

    iget-wide v13, v0, LC3/n;->h:J

    add-long/2addr v13, v11

    new-instance v1, Ljava/lang/Long;

    invoke-direct {v1, v13, v14}, Ljava/lang/Long;-><init>(J)V

    iput-object v1, v4, LP3/a;->d:Ljava/lang/Long;

    iput-wide v13, v0, LC3/n;->h:J

    :cond_1b4
    iget-wide v11, v0, LC3/n;->h:J

    cmp-long v1, v11, v9

    if-lez v1, :cond_1e4

    invoke-virtual {v0}, Lfc/l;->x()LC3/e;

    move-result-object v1

    invoke-virtual {v1}, LC3/e;->d()LK3/d;

    move-result-object v1

    sget-object v7, LO3/b;->b:LO3/b;

    iget-wide v9, v0, LC3/n;->h:J

    invoke-static {v9, v10}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v9

    iput-object v0, v2, LC3/j;->a:LC3/n;

    iput-object v4, v2, LC3/j;->b:LP3/a;

    move-object v10, v8

    check-cast v10, Ljava/lang/Iterable;

    iput-object v10, v2, LC3/j;->c:Ljava/lang/Iterable;

    iput v6, v2, LC3/j;->e:I

    const/4 v10, 0x7

    iput v10, v2, LC3/j;->h:I

    invoke-virtual {v1, v7, v9}, LK3/d;->e(LO3/b;Ljava/lang/String;)V

    if-ne v5, v3, :cond_1de

    goto :goto_200

    :cond_1de
    move-object v2, v0

    move v0, v6

    move-object v3, v8

    :goto_1e1
    move v6, v0

    move-object v0, v2

    move-object v8, v3

    :cond_1e4
    if-eqz v8, :cond_1fa

    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1ea
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1fa

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LP3/a;

    invoke-super {v0, v2}, Lfc/l;->L(LP3/a;)V

    goto :goto_1ea

    :cond_1fa
    if-nez v6, :cond_1ff

    invoke-super {v0, v4}, Lfc/l;->L(LP3/a;)V

    :cond_1ff
    move-object v3, v5

    :goto_200
    return-object v3

    nop

    :pswitch_data_202
    .packed-switch 0x0
        :pswitch_a0
        :pswitch_8f
        :pswitch_7f
        :pswitch_6f
        :pswitch_62
        :pswitch_51
        :pswitch_44
        :pswitch_35
    .end packed-switch
.end method


# virtual methods
.method public final L(LP3/a;)V
    .registers 4

    iget-object v0, p1, LP3/a;->c:Ljava/lang/Long;

    if-nez v0, :cond_e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iput-object v0, p1, LP3/a;->c:Ljava/lang/Long;

    :cond_e
    new-instance v0, LC3/i;

    invoke-direct {v0, p1}, LC3/i;-><init>(LP3/a;)V

    iget-object p1, p0, LC3/n;->e:Lde/c;

    invoke-interface {p1, v0}, Lde/t;->d(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final d0(JLAc/c;)Luc/z;
    .registers 8

    iget-object p3, p0, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p3}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long p3, v0, v2

    if-ltz p3, :cond_e

    const/4 p3, 0x1

    goto :goto_f

    :cond_e
    const/4 p3, 0x0

    :goto_f
    sget-object v0, Luc/z;->a:Luc/z;

    if-nez p3, :cond_14

    return-object v0

    :cond_14
    iput-wide p1, p0, LC3/n;->i:J

    invoke-virtual {p0}, Lfc/l;->x()LC3/e;

    move-result-object p1

    invoke-virtual {p1}, LC3/e;->d()LK3/d;

    move-result-object p1

    sget-object p2, LO3/b;->d:LO3/b;

    iget-wide v1, p0, LC3/n;->i:J

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, LK3/d;->e(LO3/b;Ljava/lang/String;)V

    sget-object p1, Lzc/a;->a:Lzc/a;

    return-object v0
.end method

.method public final e0(JLAc/c;)V
    .registers 6

    iget-object p3, p0, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    invoke-virtual {p0}, Lfc/l;->x()LC3/e;

    move-result-object p1

    invoke-virtual {p1}, LC3/e;->d()LK3/d;

    move-result-object p1

    sget-object p2, LO3/b;->c:LO3/b;

    invoke-virtual {p3}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, LK3/d;->e(LO3/b;Ljava/lang/String;)V

    sget-object p1, Lzc/a;->a:Lzc/a;

    return-void
.end method

.method public final f0(JLyc/d;)Ljava/lang/Object;
    .registers 21

    move-object/from16 v0, p0

    move-wide/from16 v1, p1

    move-object/from16 v3, p3

    instance-of v4, v3, LC3/l;

    if-eqz v4, :cond_19

    move-object v4, v3

    check-cast v4, LC3/l;

    iget v5, v4, LC3/l;->g:I

    const/high16 v6, -0x80000000

    and-int v7, v5, v6

    if-eqz v7, :cond_19

    sub-int/2addr v5, v6

    iput v5, v4, LC3/l;->g:I

    goto :goto_1e

    :cond_19
    new-instance v4, LC3/l;

    invoke-direct {v4, v0, v3}, LC3/l;-><init>(LC3/n;Lyc/d;)V

    :goto_1e
    iget-object v3, v4, LC3/l;->e:Ljava/lang/Object;

    sget-object v5, Lzc/a;->a:Lzc/a;

    iget v6, v4, LC3/l;->g:I

    sget-object v7, Luc/z;->a:Luc/z;

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz v6, :cond_57

    if-eq v6, v9, :cond_45

    if-ne v6, v8, :cond_3d

    iget-boolean v1, v4, LC3/l;->d:Z

    iget-wide v5, v4, LC3/l;->c:J

    iget-object v2, v4, LC3/l;->b:Ljava/util/List;

    check-cast v2, Ljava/util/List;

    iget-object v4, v4, LC3/l;->a:LC3/n;

    invoke-static {v3}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto/16 :goto_d1

    :cond_3d
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_45
    iget-boolean v1, v4, LC3/l;->d:Z

    iget-wide v9, v4, LC3/l;->c:J

    iget-object v2, v4, LC3/l;->b:Ljava/util/List;

    check-cast v2, Ljava/util/List;

    iget-object v6, v4, LC3/l;->a:LC3/n;

    invoke-static {v3}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object v3, v2

    move-object v8, v6

    move v6, v1

    move-wide v1, v9

    goto :goto_b8

    :cond_57
    invoke-static {v3}, Ll7/C6;->j(Ljava/lang/Object;)V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual/range {p0 .. p0}, Lfc/l;->x()LC3/e;

    move-result-object v6

    iget-object v6, v6, LC3/e;->a:LC3/g;

    const-string v10, "null cannot be cast to non-null type com.amplitude.android.Configuration"

    invoke-static {v6, v10}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v6, v6, LC3/g;->F:Ljava/util/Set;

    sget-object v10, LC3/f;->a:LC3/f;

    invoke-interface {v6, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_a6

    iget-object v10, v0, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v11

    const-wide/16 v13, 0x0

    cmp-long v11, v11, v13

    if-ltz v11, :cond_a6

    new-instance v11, LP3/a;

    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    const-string v12, "session_end"

    iput-object v12, v11, LP3/a;->L:Ljava/lang/String;

    iget-wide v8, v0, LC3/n;->i:J

    cmp-long v13, v8, v13

    if-lez v13, :cond_95

    new-instance v13, Ljava/lang/Long;

    invoke-direct {v13, v8, v9}, Ljava/lang/Long;-><init>(J)V

    goto :goto_96

    :cond_95
    const/4 v13, 0x0

    :goto_96
    iput-object v13, v11, LP3/a;->c:Ljava/lang/Long;

    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v8

    new-instance v10, Ljava/lang/Long;

    invoke-direct {v10, v8, v9}, Ljava/lang/Long;-><init>(J)V

    iput-object v10, v11, LP3/a;->e:Ljava/lang/Long;

    invoke-virtual {v3, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a6
    iput-object v0, v4, LC3/l;->a:LC3/n;

    iput-object v3, v4, LC3/l;->b:Ljava/util/List;

    iput-wide v1, v4, LC3/l;->c:J

    iput-boolean v6, v4, LC3/l;->d:Z

    const/4 v8, 0x1

    iput v8, v4, LC3/l;->g:I

    invoke-virtual {v0, v1, v2, v4}, LC3/n;->e0(JLAc/c;)V

    if-ne v7, v5, :cond_b7

    return-object v5

    :cond_b7
    move-object v8, v0

    :goto_b8
    iput-object v8, v4, LC3/l;->a:LC3/n;

    move-object v9, v3

    check-cast v9, Ljava/util/List;

    iput-object v9, v4, LC3/l;->b:Ljava/util/List;

    iput-wide v1, v4, LC3/l;->c:J

    iput-boolean v6, v4, LC3/l;->d:Z

    const/4 v9, 0x2

    iput v9, v4, LC3/l;->g:I

    invoke-virtual {v8, v1, v2, v4}, LC3/n;->d0(JLAc/c;)Luc/z;

    if-ne v7, v5, :cond_cc

    return-object v5

    :cond_cc
    move-object v4, v8

    move-wide v15, v1

    move-object v2, v3

    move v1, v6

    move-wide v5, v15

    :goto_d1
    if-eqz v1, :cond_f3

    new-instance v1, LP3/a;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const-string v3, "session_start"

    iput-object v3, v1, LP3/a;->L:Ljava/lang/String;

    new-instance v3, Ljava/lang/Long;

    invoke-direct {v3, v5, v6}, Ljava/lang/Long;-><init>(J)V

    iput-object v3, v1, LP3/a;->c:Ljava/lang/Long;

    iget-object v3, v4, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v3

    new-instance v5, Ljava/lang/Long;

    invoke-direct {v5, v3, v4}, Ljava/lang/Long;-><init>(J)V

    iput-object v5, v1, LP3/a;->e:Ljava/lang/Long;

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_f3
    return-object v2
.end method

.method public final g0(JLyc/d;)Ljava/lang/Object;
    .registers 13

    instance-of v0, p3, LC3/m;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, LC3/m;

    iget v1, v0, LC3/m;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LC3/m;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, LC3/m;

    invoke-direct {v0, p0, p3}, LC3/m;-><init>(LC3/n;Lyc/d;)V

    :goto_18
    iget-object p3, v0, LC3/m;->a:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, LC3/m;->c:I

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_36

    if-eq v2, v4, :cond_32

    if-ne v2, v3, :cond_2a

    invoke-static {p3}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_6f

    :cond_2a
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_32
    invoke-static {p3}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_64

    :cond_36
    invoke-static {p3}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p3, p0, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p3}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v5

    const-wide/16 v7, 0x0

    cmp-long p3, v5, v7

    if-ltz p3, :cond_66

    invoke-virtual {p0}, Lfc/l;->x()LC3/e;

    move-result-object p3

    const-string v2, "null cannot be cast to non-null type com.amplitude.android.Configuration"

    iget-object p3, p3, LC3/e;->a:LC3/g;

    invoke-static {p3, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    iget-wide v5, p0, LC3/n;->i:J

    sub-long v5, p1, v5

    iget-wide v7, p3, LC3/g;->x:J

    cmp-long p3, v5, v7

    if-gez p3, :cond_66

    iput v4, v0, LC3/m;->c:I

    invoke-virtual {p0, p1, p2, v0}, LC3/n;->d0(JLAc/c;)Luc/z;

    sget-object p1, Luc/z;->a:Luc/z;

    if-ne p1, v1, :cond_64

    return-object v1

    :cond_64
    :goto_64
    const/4 p1, 0x0

    return-object p1

    :cond_66
    iput v3, v0, LC3/m;->c:I

    invoke-virtual {p0, p1, p2, v0}, LC3/n;->f0(JLyc/d;)Ljava/lang/Object;

    move-result-object p3

    if-ne p3, v1, :cond_6f

    return-object v1

    :cond_6f
    :goto_6f
    return-object p3
.end method
