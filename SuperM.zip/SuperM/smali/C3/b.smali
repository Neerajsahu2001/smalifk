.class public final Lc3/b;
.super LX1/c;
.source "SourceFile"


# instance fields
.field public final synthetic c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;


# direct methods
.method public constructor <init>(Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;)V
    .registers 3

    iput-object p1, p0, Lc3/b;->c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;

    const/4 p1, 0x2

    const/4 v0, 0x2

    invoke-direct {p0, p1, v0}, LX1/c;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final c(Lz2/d;)V
    .registers 5

    instance-of v0, p1, Landroid/database/sqlite/SQLiteDatabase;

    const-string v1, "CREATE TABLE IF NOT EXISTS `work_data` (`id` TEXT NOT NULL, `notification` BLOB, `trigger` BLOB, `with_alarm_manager` INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(`id`))"

    if-nez v0, :cond_a

    invoke-virtual {p1, v1}, Lz2/d;->p(Ljava/lang/String;)V

    goto :goto_10

    :cond_a
    move-object v2, p1

    check-cast v2, Landroid/database/sqlite/SQLiteDatabase;

    invoke-static {v2, v1}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->execSQL(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V

    :goto_10
    const-string v1, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"

    if-nez v0, :cond_18

    invoke-virtual {p1, v1}, Lz2/d;->p(Ljava/lang/String;)V

    goto :goto_1e

    :cond_18
    move-object v2, p1

    check-cast v2, Landroid/database/sqlite/SQLiteDatabase;

    invoke-static {v2, v1}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->execSQL(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V

    :goto_1e
    const-string v1, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \'24b2477514809255df232947ce7928c4\')"

    if-nez v0, :cond_26

    invoke-virtual {p1, v1}, Lz2/d;->p(Ljava/lang/String;)V

    goto :goto_2b

    :cond_26
    check-cast p1, Landroid/database/sqlite/SQLiteDatabase;

    invoke-static {p1, v1}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->execSQL(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V

    :goto_2b
    return-void
.end method

.method public final d(Lz2/d;)V
    .registers 5

    instance-of v0, p1, Landroid/database/sqlite/SQLiteDatabase;

    const-string v1, "DROP TABLE IF EXISTS `work_data`"

    if-nez v0, :cond_a

    invoke-virtual {p1, v1}, Lz2/d;->p(Ljava/lang/String;)V

    goto :goto_f

    :cond_a
    check-cast p1, Landroid/database/sqlite/SQLiteDatabase;

    invoke-static {p1, v1}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->execSQL(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V

    :goto_f
    sget p1, Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;->o:I

    iget-object p1, p0, Lc3/b;->c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;

    iget-object v0, p1, Ls2/k;->f:Ljava/util/List;

    if-eqz v0, :cond_2c

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_1c
    if-ge v1, v0, :cond_2c

    iget-object v2, p1, Ls2/k;->f:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LO2/b;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v1, v1, 0x1

    goto :goto_1c

    :cond_2c
    return-void
.end method

.method public final g(Lz2/d;)V
    .registers 5

    sget p1, Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;->o:I

    iget-object p1, p0, Lc3/b;->c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;

    iget-object v0, p1, Ls2/k;->f:Ljava/util/List;

    if-eqz v0, :cond_1d

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_d
    if-ge v1, v0, :cond_1d

    iget-object v2, p1, Ls2/k;->f:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LO2/b;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_1d
    return-void
.end method

.method public final i(Lz2/d;)V
    .registers 5

    iget-object v0, p0, Lc3/b;->c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;

    sget v1, Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;->o:I

    iput-object p1, v0, Ls2/k;->a:Lz2/d;

    iget-object v0, p0, Lc3/b;->c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;

    invoke-virtual {v0, p1}, Ls2/k;->k(Lz2/d;)V

    iget-object v0, p0, Lc3/b;->c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;

    iget-object v0, v0, Ls2/k;->f:Ljava/util/List;

    if-eqz v0, :cond_28

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_16
    if-ge v1, v0, :cond_28

    iget-object v2, p0, Lc3/b;->c:Lapp/notifee/core/database/NotifeeCoreDatabase_Impl;

    iget-object v2, v2, Ls2/k;->f:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LO2/b;

    invoke-virtual {v2, p1}, LO2/b;->a(Lz2/d;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_16

    :cond_28
    return-void
.end method

.method public final l(Lz2/d;)V
    .registers 2

    invoke-static {p1}, Lm7/J2;->b(Lz2/d;)V

    return-void
.end method

.method public final m(Lz2/d;)LD9/h;
    .registers 12

    new-instance v0, Ljava/util/HashMap;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    new-instance v1, Lu2/a;

    const/4 v8, 0x1

    const/4 v3, 0x1

    const-string v5, "id"

    const-string v6, "TEXT"

    const/4 v7, 0x0

    const/4 v4, 0x1

    move-object v2, v1

    invoke-direct/range {v2 .. v8}, Lu2/a;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v2, "id"

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lu2/a;

    const/4 v9, 0x0

    const/4 v4, 0x0

    const-string v6, "notification"

    const-string v7, "BLOB"

    const/4 v8, 0x0

    const/4 v5, 0x1

    move-object v3, v1

    invoke-direct/range {v3 .. v9}, Lu2/a;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v2, "notification"

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lu2/a;

    const-string v6, "trigger"

    const-string v7, "BLOB"

    move-object v3, v1

    invoke-direct/range {v3 .. v9}, Lu2/a;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v2, "trigger"

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lu2/a;

    const/4 v9, 0x1

    const-string v6, "with_alarm_manager"

    const-string v7, "INTEGER"

    const-string v8, "0"

    move-object v3, v1

    invoke-direct/range {v3 .. v9}, Lu2/a;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v2, "with_alarm_manager"

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Ljava/util/HashSet;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Ljava/util/HashSet;-><init>(I)V

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3, v2}, Ljava/util/HashSet;-><init>(I)V

    new-instance v4, Lu2/e;

    const-string v5, "work_data"

    invoke-direct {v4, v5, v0, v1, v3}, Lu2/e;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    invoke-static {p1, v5}, Lu2/e;->a(Lz2/d;Ljava/lang/String;)Lu2/e;

    move-result-object p1

    invoke-virtual {v4, p1}, Lu2/e;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_86

    new-instance v0, LD9/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "work_data(app.notifee.core.database.WorkDataEntity).\n Expected:\n"

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, "\n Found:\n"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x2

    invoke-direct {v0, v1, p1, v2}, LD9/h;-><init>(ILjava/lang/Object;Z)V

    return-object v0

    :cond_86
    new-instance p1, LD9/h;

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1, v2, v1, v0}, LD9/h;-><init>(ILjava/lang/Object;Z)V

    return-object p1
.end method
