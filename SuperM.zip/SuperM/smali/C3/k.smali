.class public final LC3/k;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public a:Lde/b;

.field public b:I

.field public final synthetic c:LC3/n;


# direct methods
.method public constructor <init>(LC3/n;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LC3/k;->c:LC3/n;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 4

    new-instance p1, LC3/k;

    iget-object v0, p0, LC3/k;->c:LC3/n;

    invoke-direct {p1, v0, p2}, LC3/k;-><init>(LC3/n;Lyc/d;)V

    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lbe/A;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LC3/k;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LC3/k;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LC3/k;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LC3/k;->b:I

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v5, p0, LC3/k;->c:LC3/n;

    if-eqz v1, :cond_2b

    if-eq v1, v4, :cond_27

    if-eq v1, v3, :cond_20

    if-ne v1, v2, :cond_18

    iget-object v1, p0, LC3/k;->a:Lde/b;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto/16 :goto_a9

    :cond_18
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_20
    iget-object v1, p0, LC3/k;->a:Lde/b;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto/16 :goto_b4

    :cond_27
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_3d

    :cond_2b
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    invoke-virtual {v5}, Lfc/l;->x()LC3/e;

    move-result-object p1

    iput v4, p0, LC3/k;->b:I

    iget-object p1, p1, LC3/e;->n:Lbe/H;

    invoke-virtual {p1, p0}, Lbe/n0;->r(Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3d

    return-object v0

    :cond_3d
    :goto_3d
    iget-object p1, v5, LC3/n;->d:Ljava/lang/Long;

    const-wide/16 v6, -0x1

    if-nez p1, :cond_64

    iget-object p1, v5, LC3/n;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v5}, Lfc/l;->x()LC3/e;

    move-result-object v1

    invoke-virtual {v1}, LC3/e;->d()LK3/d;

    move-result-object v1

    sget-object v4, LO3/b;->c:LO3/b;

    invoke-virtual {v1, v4}, LK3/d;->a(LO3/b;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_60

    invoke-static {v1}, LZd/p;->j(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    if-eqz v1, :cond_60

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    goto :goto_61

    :cond_60
    move-wide v8, v6

    :goto_61
    invoke-virtual {p1, v8, v9}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    :cond_64
    invoke-virtual {v5}, Lfc/l;->x()LC3/e;

    move-result-object p1

    invoke-virtual {p1}, LC3/e;->d()LK3/d;

    move-result-object p1

    sget-object v1, LO3/b;->b:LO3/b;

    invoke-virtual {p1, v1}, LK3/d;->a(LO3/b;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_7f

    invoke-static {p1}, LZd/p;->j(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    if-eqz p1, :cond_7f

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    goto :goto_81

    :cond_7f
    const-wide/16 v8, 0x0

    :goto_81
    iput-wide v8, v5, LC3/n;->h:J

    invoke-virtual {v5}, Lfc/l;->x()LC3/e;

    move-result-object p1

    invoke-virtual {p1}, LC3/e;->d()LK3/d;

    move-result-object p1

    sget-object v1, LO3/b;->d:LO3/b;

    invoke-virtual {p1, v1}, LK3/d;->a(LO3/b;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_9d

    invoke-static {p1}, LZd/p;->j(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    if-eqz p1, :cond_9d

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    :cond_9d
    iput-wide v6, v5, LC3/n;->i:J

    iget-object p1, v5, LC3/n;->e:Lde/c;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lde/b;

    invoke-direct {v1, p1}, Lde/b;-><init>(Lde/c;)V

    :cond_a9
    :goto_a9
    iput-object v1, p0, LC3/k;->a:Lde/b;

    iput v3, p0, LC3/k;->b:I

    invoke-virtual {v1, p0}, Lde/b;->b(Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_b4

    return-object v0

    :cond_b4
    :goto_b4
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_cd

    invoke-virtual {v1}, Lde/b;->c()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LC3/i;

    iput-object v1, p0, LC3/k;->a:Lde/b;

    iput v2, p0, LC3/k;->b:I

    invoke-static {v5, p1, p0}, LC3/n;->c0(LC3/n;LC3/i;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_a9

    return-object v0

    :cond_cd
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
