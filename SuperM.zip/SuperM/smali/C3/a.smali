.class public final Lc3/a;
.super Lt2/a;
.source "SourceFile"


# virtual methods
.method public final a(Lz2/d;)V
    .registers 4

    instance-of v0, p1, Landroid/database/sqlite/SQLiteDatabase;

    const-string v1, "ALTER TABLE work_data ADD COLUMN with_alarm_manager INTEGER NOT NULL DEFAULT 0"

    if-nez v0, :cond_a

    invoke-virtual {p1, v1}, Lz2/d;->p(Ljava/lang/String;)V

    goto :goto_f

    :cond_a
    check-cast p1, Landroid/database/sqlite/SQLiteDatabase;

    invoke-static {p1, v1}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->execSQL(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)V

    :goto_f
    return-void
.end method
