.class public final LC3/j;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public a:LC3/n;

.field public b:LP3/a;

.field public c:Ljava/lang/Iterable;

.field public d:J

.field public e:I

.field public synthetic f:Ljava/lang/Object;

.field public final synthetic g:LC3/n;

.field public h:I


# direct methods
.method public constructor <init>(LC3/n;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LC3/j;->g:LC3/n;

    invoke-direct {p0, p2}, LAc/c;-><init>(Lyc/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LC3/j;->f:Ljava/lang/Object;

    iget p1, p0, LC3/j;->h:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LC3/j;->h:I

    iget-object p1, p0, LC3/j;->g:LC3/n;

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, LC3/n;->c0(LC3/n;LC3/i;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
