.class public final synthetic Lc6/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# instance fields
.field public final synthetic a:Lcom/facebook/react/modules/network/NetworkingModule;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcom/facebook/react/bridge/ReactApplicationContext;

.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Lcom/facebook/react/modules/network/NetworkingModule;Ljava/lang/String;Lcom/facebook/react/bridge/ReactApplicationContext;I)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc6/b;->a:Lcom/facebook/react/modules/network/NetworkingModule;

    iput-object p2, p0, Lc6/b;->b:Ljava/lang/String;

    iput-object p3, p0, Lc6/b;->c:Lcom/facebook/react/bridge/ReactApplicationContext;

    iput p4, p0, Lc6/b;->d:I

    return-void
.end method


# virtual methods
.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;
    .registers 6

    iget-object v0, p0, Lc6/b;->c:Lcom/facebook/react/bridge/ReactApplicationContext;

    iget v1, p0, Lc6/b;->d:I

    iget-object v2, p0, Lc6/b;->a:Lcom/facebook/react/modules/network/NetworkingModule;

    iget-object v3, p0, Lc6/b;->b:Ljava/lang/String;

    invoke-static {v2, v3, v0, v1, p1}, Lcom/facebook/react/modules/network/NetworkingModule;->a(Lcom/facebook/react/modules/network/NetworkingModule;Ljava/lang/String;Lcom/facebook/react/bridge/ReactApplicationContext;ILokhttp3/Interceptor$Chain;)Lokhttp3/Response;

    move-result-object p1

    return-object p1
.end method
