.class public final Ld0/l0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/CharSequence;

.field public final c:[Ljava/lang/CharSequence;

.field public final d:Z

.field public final e:I

.field public final f:Landroid/os/Bundle;

.field public final g:Ljava/util/Set;


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;[Ljava/lang/CharSequence;ZILandroid/os/Bundle;Ljava/util/HashSet;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "app.notifee.core.ReceiverService.REMOTE_INPUT_RECEIVER_KEY"

    iput-object v0, p0, Ld0/l0;->a:Ljava/lang/String;

    iput-object p1, p0, Ld0/l0;->b:Ljava/lang/CharSequence;

    iput-object p2, p0, Ld0/l0;->c:[Ljava/lang/CharSequence;

    iput-boolean p3, p0, Ld0/l0;->d:Z

    iput p4, p0, Ld0/l0;->e:I

    iput-object p5, p0, Ld0/l0;->f:Landroid/os/Bundle;

    iput-object p6, p0, Ld0/l0;->g:Ljava/util/Set;

    const/4 p1, 0x2

    if-ne p4, p1, :cond_21

    if-eqz p3, :cond_19

    goto :goto_21

    :cond_19
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "setEditChoicesBeforeSending requires setAllowFreeFormInput"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_21
    :goto_21
    return-void
.end method

.method public static a(Ld0/l0;)Landroid/app/RemoteInput;
    .registers 5

    new-instance v0, Landroid/app/RemoteInput$Builder;

    iget-object v1, p0, Ld0/l0;->a:Ljava/lang/String;

    invoke-direct {v0, v1}, Landroid/app/RemoteInput$Builder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Ld0/l0;->b:Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->setLabel(Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    iget-object v1, p0, Ld0/l0;->c:[Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->setChoices([Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    iget-boolean v1, p0, Ld0/l0;->d:Z

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->setAllowFreeFormInput(Z)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    iget-object v1, p0, Ld0/l0;->f:Landroid/os/Bundle;

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    iget-object v1, p0, Ld0/l0;->g:Ljava/util/Set;

    if-eqz v1, :cond_38

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_27
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_38

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const/4 v3, 0x1

    invoke-static {v0, v2, v3}, Ld0/j0;->d(Landroid/app/RemoteInput$Builder;Ljava/lang/String;Z)Landroid/app/RemoteInput$Builder;

    goto :goto_27

    :cond_38
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1d

    if-lt v1, v2, :cond_43

    iget p0, p0, Ld0/l0;->e:I

    invoke-static {v0, p0}, Ld0/k0;->b(Landroid/app/RemoteInput$Builder;I)Landroid/app/RemoteInput$Builder;

    :cond_43
    invoke-virtual {v0}, Landroid/app/RemoteInput$Builder;->build()Landroid/app/RemoteInput;

    move-result-object p0

    return-object p0
.end method
