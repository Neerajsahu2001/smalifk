.class public abstract Ld0/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/Class;

.field public static final b:Ljava/lang/reflect/Field;

.field public static final c:Ljava/lang/reflect/Field;

.field public static final d:Ljava/lang/reflect/Method;

.field public static final e:Ljava/lang/reflect/Method;

.field public static final f:Ljava/lang/reflect/Method;

.field public static final g:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .registers 13

    const-class v0, Landroid/app/Activity;

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v1, Ld0/i;->g:Landroid/os/Handler;

    const/4 v1, 0x0

    :try_start_e
    const-string v2, "android.app.ActivityThread"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2
    :try_end_14
    .catchall {:try_start_e .. :try_end_14} :catchall_15

    goto :goto_16

    :catchall_15
    move-object v2, v1

    :goto_16
    sput-object v2, Ld0/i;->a:Ljava/lang/Class;

    const/4 v2, 0x1

    :try_start_19
    const-string v3, "mMainThread"

    invoke-virtual {v0, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_22
    .catchall {:try_start_19 .. :try_end_22} :catchall_23

    goto :goto_24

    :catchall_23
    move-object v3, v1

    :goto_24
    sput-object v3, Ld0/i;->b:Ljava/lang/reflect/Field;

    :try_start_26
    const-string v3, "mToken"

    invoke-virtual {v0, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_2f
    .catchall {:try_start_26 .. :try_end_2f} :catchall_30

    goto :goto_31

    :catchall_30
    move-object v0, v1

    :goto_31
    sput-object v0, Ld0/i;->c:Ljava/lang/reflect/Field;

    sget-object v0, Ld0/i;->a:Ljava/lang/Class;

    const-class v3, Landroid/os/IBinder;

    const-string v4, "performStopActivity"

    if-nez v0, :cond_3d

    :catchall_3b
    move-object v0, v1

    goto :goto_4c

    :cond_3d
    :try_start_3d
    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const-class v6, Ljava/lang/String;

    filled-new-array {v3, v5, v6}, [Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v0, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_4c
    .catchall {:try_start_3d .. :try_end_4c} :catchall_3b

    :goto_4c
    sput-object v0, Ld0/i;->d:Ljava/lang/reflect/Method;

    sget-object v0, Ld0/i;->a:Ljava/lang/Class;

    if-nez v0, :cond_54

    :catchall_52
    move-object v0, v1

    goto :goto_61

    :cond_54
    :try_start_54
    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    filled-new-array {v3, v5}, [Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v0, v4, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_61
    .catchall {:try_start_54 .. :try_end_61} :catchall_52

    :goto_61
    sput-object v0, Ld0/i;->e:Ljava/lang/reflect/Method;

    sget-object v0, Ld0/i;->a:Ljava/lang/Class;

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    if-eq v3, v4, :cond_6f

    const/16 v4, 0x1b

    if-ne v3, v4, :cond_90

    :cond_6f
    if-nez v0, :cond_72

    goto :goto_90

    :cond_72
    :try_start_72
    const-string v3, "requestRelaunchActivity"

    const-class v4, Landroid/os/IBinder;

    const-class v5, Ljava/util/List;

    const-class v6, Ljava/util/List;

    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    sget-object v12, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const-class v9, Landroid/content/res/Configuration;

    const-class v10, Landroid/content/res/Configuration;

    move-object v8, v12

    move-object v11, v12

    filled-new-array/range {v4 .. v12}, [Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_8f
    .catchall {:try_start_72 .. :try_end_8f} :catchall_90

    move-object v1, v0

    :catchall_90
    :cond_90
    :goto_90
    sput-object v1, Ld0/i;->f:Ljava/lang/reflect/Method;

    return-void
.end method
