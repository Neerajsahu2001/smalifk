.class public final Ld0/c0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final c:Ljava/lang/Object;

.field public static d:Ljava/lang/String;

.field public static e:Ljava/util/HashSet;

.field public static final f:Ljava/lang/Object;

.field public static g:Ld0/b0;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Landroid/app/NotificationManager;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Ld0/c0;->c:Ljava/lang/Object;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Ld0/c0;->e:Ljava/util/HashSet;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Ld0/c0;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld0/c0;->a:Landroid/content/Context;

    const-string v0, "notification"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/app/NotificationManager;

    iput-object p1, p0, Ld0/c0;->b:Landroid/app/NotificationManager;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;ILandroid/app/Notification;)V
    .registers 8

    iget-object v0, p3, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    iget-object v1, p0, Ld0/c0;->b:Landroid/app/NotificationManager;

    if-eqz v0, :cond_43

    const-string v2, "android.support.useSideChannel"

    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_43

    new-instance v0, Ld0/Y;

    iget-object v2, p0, Ld0/c0;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2, p2, p1, p3}, Ld0/Y;-><init>(Ljava/lang/String;ILjava/lang/String;Landroid/app/Notification;)V

    sget-object v2, Ld0/c0;->f:Ljava/lang/Object;

    monitor-enter v2

    :try_start_1c
    sget-object p3, Ld0/c0;->g:Ld0/b0;

    if-nez p3, :cond_30

    new-instance p3, Ld0/b0;

    iget-object v3, p0, Ld0/c0;->a:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {p3, v3}, Ld0/b0;-><init>(Landroid/content/Context;)V

    sput-object p3, Ld0/c0;->g:Ld0/b0;

    goto :goto_30

    :catchall_2e
    move-exception p1

    goto :goto_41

    :cond_30
    :goto_30
    sget-object p3, Ld0/c0;->g:Ld0/b0;

    iget-object p3, p3, Ld0/b0;->b:Landroid/os/Handler;

    const/4 v3, 0x0

    invoke-virtual {p3, v3, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p3

    invoke-virtual {p3}, Landroid/os/Message;->sendToTarget()V

    monitor-exit v2
    :try_end_3d
    .catchall {:try_start_1c .. :try_end_3d} :catchall_2e

    invoke-virtual {v1, p1, p2}, Landroid/app/NotificationManager;->cancel(Ljava/lang/String;I)V

    goto :goto_46

    :goto_41
    :try_start_41
    monitor-exit v2
    :try_end_42
    .catchall {:try_start_41 .. :try_end_42} :catchall_2e

    throw p1

    :cond_43
    invoke-virtual {v1, p1, p2, p3}, Landroid/app/NotificationManager;->notify(Ljava/lang/String;ILandroid/app/Notification;)V

    :goto_46
    return-void
.end method
