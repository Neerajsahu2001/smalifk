.class public final Ld0/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Landroid/app/Activity;

.field public final c:I

.field public d:Z

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Ld0/h;->d:Z

    iput-boolean v0, p0, Ld0/h;->e:Z

    iput-boolean v0, p0, Ld0/h;->f:Z

    iput-object p1, p0, Ld0/h;->b:Landroid/app/Activity;

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    iput p1, p0, Ld0/h;->c:I

    return-void
.end method


# virtual methods
.method public final onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    return-void
.end method

.method public final onActivityDestroyed(Landroid/app/Activity;)V
    .registers 3

    iget-object v0, p0, Ld0/h;->b:Landroid/app/Activity;

    if-ne v0, p1, :cond_a

    const/4 p1, 0x0

    iput-object p1, p0, Ld0/h;->b:Landroid/app/Activity;

    const/4 p1, 0x1

    iput-boolean p1, p0, Ld0/h;->e:Z

    :cond_a
    return-void
.end method

.method public final onActivityPaused(Landroid/app/Activity;)V
    .registers 7

    iget-boolean v0, p0, Ld0/h;->e:Z

    if-eqz v0, :cond_40

    iget-boolean v0, p0, Ld0/h;->f:Z

    if-nez v0, :cond_40

    iget-boolean v0, p0, Ld0/h;->d:Z

    if-nez v0, :cond_40

    iget-object v0, p0, Ld0/h;->a:Ljava/lang/Object;

    :try_start_e
    sget-object v1, Ld0/i;->c:Ljava/lang/reflect/Field;

    invoke-virtual {v1, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_40

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v0
    :try_end_1a
    .catchall {:try_start_e .. :try_end_1a} :catchall_38

    iget v2, p0, Ld0/h;->c:I

    if-eq v0, v2, :cond_1f

    goto :goto_40

    :cond_1f
    :try_start_1f
    sget-object v0, Ld0/i;->b:Ljava/lang/reflect/Field;

    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    sget-object v0, Ld0/i;->g:Landroid/os/Handler;

    new-instance v2, LN6/A;

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v2, p1, v1, v3, v4}, LN6/A;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z
    :try_end_31
    .catchall {:try_start_1f .. :try_end_31} :catchall_38

    const/4 p1, 0x1

    iput-boolean p1, p0, Ld0/h;->f:Z

    const/4 p1, 0x0

    iput-object p1, p0, Ld0/h;->a:Ljava/lang/Object;

    goto :goto_40

    :catchall_38
    move-exception p1

    const-string v0, "ActivityRecreator"

    const-string v1, "Exception while fetching field values"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_40
    :goto_40
    return-void
.end method

.method public final onActivityResumed(Landroid/app/Activity;)V
    .registers 2

    return-void
.end method

.method public final onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    return-void
.end method

.method public final onActivityStarted(Landroid/app/Activity;)V
    .registers 3

    iget-object v0, p0, Ld0/h;->b:Landroid/app/Activity;

    if-ne v0, p1, :cond_7

    const/4 p1, 0x1

    iput-boolean p1, p0, Ld0/h;->d:Z

    :cond_7
    return-void
.end method

.method public final onActivityStopped(Landroid/app/Activity;)V
    .registers 2

    return-void
.end method
