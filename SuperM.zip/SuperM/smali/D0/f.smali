.class public interface abstract Ld0/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract validateRequestPermissionsRequestCode(I)V
.end method
