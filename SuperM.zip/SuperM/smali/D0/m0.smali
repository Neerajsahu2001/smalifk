.class public abstract Ld0/m0;
.super Ljava/lang/Object;
.source "SourceFile"
