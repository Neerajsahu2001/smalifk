.class public final Ld0/u;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/os/Bundle;

.field public b:Landroidx/core/graphics/drawable/IconCompat;

.field public final c:[Ld0/l0;

.field public final d:Z

.field public final e:Z

.field public final f:I

.field public final g:Z

.field public final h:I

.field public final i:Ljava/lang/CharSequence;

.field public final j:Landroid/app/PendingIntent;

.field public final k:Z


# direct methods
.method public constructor <init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V
    .registers 14

    const/4 v0, 0x0

    if-nez p1, :cond_5

    :goto_3
    move-object v2, v0

    goto :goto_c

    :cond_5
    const-string v1, ""

    invoke-static {v0, v1, p1}, Landroidx/core/graphics/drawable/IconCompat;->a(Landroid/content/res/Resources;Ljava/lang/String;I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    goto :goto_3

    :goto_c
    new-instance v5, Landroid/os/Bundle;

    invoke-direct {v5}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v6, 0x0

    const/4 v9, 0x1

    move-object v1, p0

    move-object v3, p2

    move-object v4, p3

    invoke-direct/range {v1 .. v9}, Ld0/u;-><init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Ld0/l0;[Ld0/l0;ZZ)V

    return-void
.end method

.method public constructor <init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Ld0/l0;[Ld0/l0;ZZ)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p6, 0x1

    iput-boolean p6, p0, Ld0/u;->e:Z

    iput-object p1, p0, Ld0/u;->b:Landroidx/core/graphics/drawable/IconCompat;

    if-eqz p1, :cond_1e

    iget p6, p1, Landroidx/core/graphics/drawable/IconCompat;->a:I

    const/4 v0, -0x1

    if-ne p6, v0, :cond_15

    iget-object p6, p1, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    invoke-static {p6}, Li0/c;->c(Ljava/lang/Object;)I

    move-result p6

    :cond_15
    const/4 v0, 0x2

    if-ne p6, v0, :cond_1e

    invoke-virtual {p1}, Landroidx/core/graphics/drawable/IconCompat;->b()I

    move-result p1

    iput p1, p0, Ld0/u;->h:I

    :cond_1e
    invoke-static {p2}, Landroidx/core/app/NotificationCompat$Builder;->b(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    iput-object p1, p0, Ld0/u;->i:Ljava/lang/CharSequence;

    iput-object p3, p0, Ld0/u;->j:Landroid/app/PendingIntent;

    if-eqz p4, :cond_29

    goto :goto_2e

    :cond_29
    new-instance p4, Landroid/os/Bundle;

    invoke-direct {p4}, Landroid/os/Bundle;-><init>()V

    :goto_2e
    iput-object p4, p0, Ld0/u;->a:Landroid/os/Bundle;

    iput-object p5, p0, Ld0/u;->c:[Ld0/l0;

    iput-boolean p7, p0, Ld0/u;->d:Z

    const/4 p1, 0x0

    iput p1, p0, Ld0/u;->f:I

    iput-boolean p8, p0, Ld0/u;->e:Z

    iput-boolean p1, p0, Ld0/u;->g:Z

    iput-boolean p1, p0, Ld0/u;->k:Z

    return-void
.end method


# virtual methods
.method public final a()Landroidx/core/graphics/drawable/IconCompat;
    .registers 4

    iget-object v0, p0, Ld0/u;->b:Landroidx/core/graphics/drawable/IconCompat;

    if-nez v0, :cond_11

    iget v0, p0, Ld0/u;->h:I

    if-eqz v0, :cond_11

    const/4 v1, 0x0

    const-string v2, ""

    invoke-static {v1, v2, v0}, Landroidx/core/graphics/drawable/IconCompat;->a(Landroid/content/res/Resources;Ljava/lang/String;I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    iput-object v0, p0, Ld0/u;->b:Landroidx/core/graphics/drawable/IconCompat;

    :cond_11
    iget-object v0, p0, Ld0/u;->b:Landroidx/core/graphics/drawable/IconCompat;

    return-object v0
.end method
