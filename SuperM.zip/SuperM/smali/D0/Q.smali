.class public final Ld0/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/Window$OnFrameMetricsAvailableListener;


# instance fields
.field public final synthetic a:Ld0/r;


# direct methods
.method public constructor <init>(Ld0/r;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld0/q;->a:Ld0/r;

    return-void
.end method


# virtual methods
.method public final onFrameMetricsAvailable(Landroid/view/Window;Landroid/view/FrameMetrics;I)V
    .registers 12

    iget-object p1, p0, Ld0/q;->a:Ld0/r;

    iget p3, p1, Ld0/r;->a:I

    const/4 v0, 0x1

    and-int/2addr p3, v0

    const/4 v1, 0x0

    const/16 v2, 0x8

    if-eqz p3, :cond_16

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v1

    invoke-virtual {p2, v2}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v3

    invoke-static {p3, v3, v4}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_16
    iget p3, p1, Ld0/r;->a:I

    const/4 v3, 0x2

    and-int/2addr p3, v3

    if-eqz p3, :cond_27

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v0

    invoke-virtual {p2, v0}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v4

    invoke-static {p3, v4, v5}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_27
    iget p3, p1, Ld0/r;->a:I

    const/4 v0, 0x4

    and-int/2addr p3, v0

    const/4 v4, 0x3

    if-eqz p3, :cond_39

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v3

    invoke-virtual {p2, v4}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v5

    invoke-static {p3, v5, v6}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_39
    iget p3, p1, Ld0/r;->a:I

    and-int/2addr p3, v2

    if-eqz p3, :cond_49

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v4

    invoke-virtual {p2, v0}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v4

    invoke-static {p3, v4, v5}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_49
    iget p3, p1, Ld0/r;->a:I

    and-int/lit8 p3, p3, 0x10

    const/4 v4, 0x5

    if-eqz p3, :cond_5b

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v0

    invoke-virtual {p2, v4}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v5

    invoke-static {p3, v5, v6}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_5b
    iget p3, p1, Ld0/r;->a:I

    and-int/lit8 p3, p3, 0x40

    const/4 v0, 0x7

    const/4 v5, 0x6

    if-eqz p3, :cond_6e

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v5

    invoke-virtual {p2, v0}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v6

    invoke-static {p3, v6, v7}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_6e
    iget p3, p1, Ld0/r;->a:I

    and-int/lit8 p3, p3, 0x20

    if-eqz p3, :cond_7f

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v4

    invoke-virtual {p2, v5}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v4

    invoke-static {p3, v4, v5}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_7f
    iget p3, p1, Ld0/r;->a:I

    and-int/lit16 p3, p3, 0x80

    if-eqz p3, :cond_90

    iget-object p3, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p3, p3, v0

    invoke-virtual {p2, v1}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v0

    invoke-static {p3, v0, v1}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_90
    iget p3, p1, Ld0/r;->a:I

    and-int/lit16 p3, p3, 0x100

    if-eqz p3, :cond_a1

    iget-object p1, p1, Ld0/r;->b:[Landroid/util/SparseIntArray;

    aget-object p1, p1, v2

    invoke-virtual {p2, v3}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide p2

    invoke-static {p1, p2, p3}, Ld0/r;->a(Landroid/util/SparseIntArray;J)V

    :cond_a1
    return-void
.end method
