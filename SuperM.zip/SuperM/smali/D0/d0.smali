.class public interface abstract Ld0/d0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract addOnMultiWindowModeChangedListener(Lq0/a;)V
.end method

.method public abstract removeOnMultiWindowModeChangedListener(Lq0/a;)V
.end method
