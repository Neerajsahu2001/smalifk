.class public final Ld0/r;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static e:Landroid/os/HandlerThread;

.field public static f:Landroid/os/Handler;


# instance fields
.field public final a:I

.field public b:[Landroid/util/SparseIntArray;

.field public final c:Ljava/util/ArrayList;

.field public final d:Ld0/q;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x9

    new-array v0, v0, [Landroid/util/SparseIntArray;

    iput-object v0, p0, Ld0/r;->b:[Landroid/util/SparseIntArray;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ld0/r;->c:Ljava/util/ArrayList;

    new-instance v0, Ld0/q;

    invoke-direct {v0, p0}, Ld0/q;-><init>(Ld0/r;)V

    iput-object v0, p0, Ld0/r;->d:Ld0/q;

    iput p1, p0, Ld0/r;->a:I

    return-void
.end method

.method public static a(Landroid/util/SparseIntArray;J)V
    .registers 7

    if-eqz p0, :cond_1a

    const-wide/32 v0, 0x7a120

    add-long/2addr v0, p1

    const-wide/32 v2, 0xf4240

    div-long/2addr v0, v2

    long-to-int v0, v0

    const-wide/16 v1, 0x0

    cmp-long p1, p1, v1

    if-ltz p1, :cond_1a

    invoke-virtual {p0, v0}, Landroid/util/SparseIntArray;->get(I)I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    invoke-virtual {p0, v0, p1}, Landroid/util/SparseIntArray;->put(II)V

    :cond_1a
    return-void
.end method
