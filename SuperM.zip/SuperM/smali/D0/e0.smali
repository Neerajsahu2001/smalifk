.class public interface abstract Ld0/e0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract addOnPictureInPictureModeChangedListener(Lq0/a;)V
.end method

.method public abstract removeOnPictureInPictureModeChangedListener(Lq0/a;)V
.end method
