.class public interface abstract Ld0/n0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getSupportParentActivityIntent()Landroid/content/Intent;
.end method
