.class public final Ld0/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroidx/core/graphics/drawable/IconCompat;

.field public final b:Ljava/lang/CharSequence;

.field public final c:Landroid/app/PendingIntent;

.field public d:Z

.field public final e:Landroid/os/Bundle;

.field public f:Ljava/util/ArrayList;

.field public final g:Z


# direct methods
.method public constructor <init>(Landroidx/core/graphics/drawable/IconCompat;Landroid/text/Spanned;Landroid/app/PendingIntent;)V
    .registers 6

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    iput-boolean v1, p0, Ld0/t;->d:Z

    iput-boolean v1, p0, Ld0/t;->g:Z

    iput-object p1, p0, Ld0/t;->a:Landroidx/core/graphics/drawable/IconCompat;

    invoke-static {p2}, Landroidx/core/app/NotificationCompat$Builder;->b(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    iput-object p1, p0, Ld0/t;->b:Ljava/lang/CharSequence;

    iput-object p3, p0, Ld0/t;->c:Landroid/app/PendingIntent;

    iput-object v0, p0, Ld0/t;->e:Landroid/os/Bundle;

    const/4 p1, 0x0

    iput-object p1, p0, Ld0/t;->f:Ljava/util/ArrayList;

    iput-boolean v1, p0, Ld0/t;->d:Z

    iput-boolean v1, p0, Ld0/t;->g:Z

    return-void
.end method
