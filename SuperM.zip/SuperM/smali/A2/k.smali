.class public final La2/k;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final c:La2/k;


# instance fields
.field public final a:J

.field public final b:Z


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, La2/k;

    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2, v3}, La2/k;-><init>(JZ)V

    sput-object v0, La2/k;->c:La2/k;

    return-void
.end method

.method public constructor <init>(JZ)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, La2/k;->a:J

    iput-boolean p3, p0, La2/k;->b:Z

    return-void
.end method
