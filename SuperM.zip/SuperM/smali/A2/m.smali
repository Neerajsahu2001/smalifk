.class public final La2/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD1/w;


# instance fields
.field public final a:LD1/w;

.field public final b:La2/j;

.field public c:LD9/f;


# direct methods
.method public constructor <init>(LD1/w;La2/j;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La2/m;->a:LD1/w;

    iput-object p2, p0, La2/m;->b:La2/j;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 2

    iget-object v0, p0, La2/m;->a:LD1/w;

    invoke-interface {v0}, LD1/w;->a()V

    return-void
.end method

.method public final c()LD1/w;
    .registers 2

    iget-object v0, p0, La2/m;->a:LD1/w;

    return-object v0
.end method

.method public final d(LD1/x;LD1/A;)I
    .registers 4

    iget-object v0, p0, La2/m;->a:LD1/w;

    invoke-interface {v0, p1, p2}, LD1/w;->d(LD1/x;LD1/A;)I

    move-result p1

    return p1
.end method

.method public final f(LD1/y;)V
    .registers 4

    new-instance v0, LD9/f;

    iget-object v1, p0, La2/m;->b:La2/j;

    invoke-direct {v0, p1, v1}, LD9/f;-><init>(LD1/y;La2/j;)V

    iput-object v0, p0, La2/m;->c:LD9/f;

    iget-object p1, p0, La2/m;->a:LD1/w;

    invoke-interface {p1, v0}, LD1/w;->f(LD1/y;)V

    return-void
.end method

.method public final h(LD1/x;)Z
    .registers 3

    iget-object v0, p0, La2/m;->a:LD1/w;

    invoke-interface {v0, p1}, LD1/w;->h(LD1/x;)Z

    move-result p1

    return p1
.end method

.method public final i(JJ)V
    .registers 9

    iget-object v0, p0, La2/m;->c:LD9/f;

    if-eqz v0, :cond_1f

    const/4 v1, 0x0

    :goto_5
    iget-object v2, v0, LD9/f;->c:Ljava/lang/Object;

    check-cast v2, Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v1, v3, :cond_1f

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La2/o;

    iget-object v2, v2, La2/o;->h:La2/l;

    if-eqz v2, :cond_1c

    invoke-interface {v2}, La2/l;->b()V

    :cond_1c
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_1f
    iget-object v0, p0, La2/m;->a:LD1/w;

    invoke-interface {v0, p1, p2, p3, p4}, LD1/w;->i(JJ)V

    return-void
.end method
