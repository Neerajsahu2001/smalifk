.class public final La2/c;
.super Lf1/g;
.source "SourceFile"

# interfaces
.implements La2/d;


# instance fields
.field public e:La2/d;

.field public f:J

.field public final synthetic g:I

.field public h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    iput v0, p0, La2/c;->g:I

    invoke-direct {p0}, LX1/c;-><init>()V

    return-void
.end method

.method public constructor <init>(Ln1/b;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, La2/c;->g:I

    invoke-direct {p0}, LX1/c;-><init>()V

    iput-object p1, p0, La2/c;->h:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(J)I
    .registers 6

    iget-object v0, p0, La2/c;->e:La2/d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v1, p0, La2/c;->f:J

    sub-long/2addr p1, v1

    invoke-interface {v0, p1, p2}, La2/d;->a(J)I

    move-result p1

    return p1
.end method

.method public final h(I)J
    .registers 6

    iget-object v0, p0, La2/c;->e:La2/d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0, p1}, La2/d;->h(I)J

    move-result-wide v0

    iget-wide v2, p0, La2/c;->f:J

    add-long/2addr v0, v2

    return-wide v0
.end method

.method public final j(J)Ljava/util/List;
    .registers 6

    iget-object v0, p0, La2/c;->e:La2/d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v1, p0, La2/c;->f:J

    sub-long/2addr p1, v1

    invoke-interface {v0, p1, p2}, La2/d;->j(J)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public final k()I
    .registers 2

    iget-object v0, p0, La2/c;->e:La2/d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0}, La2/d;->k()I

    move-result v0

    return v0
.end method

.method public final o()V
    .registers 2

    invoke-super {p0}, Lf1/g;->o()V

    const/4 v0, 0x0

    iput-object v0, p0, La2/c;->e:La2/d;

    return-void
.end method

.method public final p()V
    .registers 2

    iget v0, p0, La2/c;->g:I

    packed-switch v0, :pswitch_data_24

    iget-object v0, p0, La2/c;->h:Ljava/lang/Object;

    check-cast v0, LI1/a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, LI1/a;->b:Ljava/lang/Object;

    check-cast v0, Lb2/j;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, La2/c;->o()V

    iget-object v0, v0, Lb2/j;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v0, p0}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_1c
    iget-object v0, p0, La2/c;->h:Ljava/lang/Object;

    check-cast v0, Ln1/b;

    invoke-virtual {v0, p0}, Ln1/b;->n(Lf1/g;)V

    return-void

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_1c
    .end packed-switch
.end method
