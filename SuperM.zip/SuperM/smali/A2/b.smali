.class public final La2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/d;


# static fields
.field public static final c:Lj8/v;


# instance fields
.field public final a:Lj8/T;

.field public final b:[J


# direct methods
.method static constructor <clinit>()V
    .registers 3

    sget-object v0, Lj8/o0;->a:Lj8/o0;

    new-instance v1, LMa/g;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, LMa/g;-><init>(I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lj8/v;

    invoke-direct {v2, v1, v0}, Lj8/v;-><init>(Li8/f;Lj8/p0;)V

    sput-object v2, La2/b;->c:Lj8/v;

    return-void
.end method

.method public constructor <init>(Lj8/q0;)V
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual/range {p1 .. p1}, Lj8/q0;->size()I

    move-result v4

    const/4 v7, 0x1

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    if-ne v4, v7, :cond_93

    invoke-virtual {v1, v3}, Lj8/T;->z(I)Lj8/Q;

    move-result-object v1

    invoke-virtual {v1}, Lj8/a;->next()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1}, Lj8/a;->hasNext()Z

    move-result v10

    if-nez v10, :cond_58

    check-cast v4, La2/a;

    iget-wide v10, v4, La2/a;->b:J

    cmp-long v1, v10, v8

    if-nez v1, :cond_2e

    const-wide/16 v5, 0x0

    goto :goto_2f

    :cond_2e
    move-wide v5, v10

    :goto_2f
    iget-wide v10, v4, La2/a;->c:J

    cmp-long v1, v10, v8

    iget-object v4, v4, La2/a;->a:Lj8/T;

    if-nez v1, :cond_44

    invoke-static {v4}, Lj8/T;->C(Ljava/lang/Object;)Lj8/q0;

    move-result-object v1

    iput-object v1, v0, La2/b;->a:Lj8/T;

    new-array v1, v7, [J

    aput-wide v5, v1, v3

    iput-object v1, v0, La2/b;->b:[J

    goto :goto_57

    :cond_44
    invoke-static {}, Lj8/T;->A()Lj8/q0;

    move-result-object v1

    invoke-static {v4, v1}, Lj8/T;->D(Ljava/lang/Object;Ljava/lang/Object;)Lj8/q0;

    move-result-object v1

    iput-object v1, v0, La2/b;->a:Lj8/T;

    add-long/2addr v10, v5

    new-array v1, v2, [J

    aput-wide v5, v1, v3

    aput-wide v10, v1, v7

    iput-object v1, v0, La2/b;->b:[J

    :goto_57
    return-void

    :cond_58
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v5, "expected one element but was: <"

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_62
    const/4 v4, 0x4

    if-ge v3, v4, :cond_79

    invoke-virtual {v1}, Lj8/a;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_79

    const-string v4, ", "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Lj8/a;->next()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    add-int/2addr v3, v7

    goto :goto_62

    :cond_79
    invoke-virtual {v1}, Lj8/a;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_84

    const-string v1, ", ..."

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_84
    const/16 v1, 0x3e

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_93
    invoke-virtual/range {p1 .. p1}, Lj8/q0;->size()I

    move-result v4

    mul-int/2addr v4, v2

    new-array v2, v4, [J

    iput-object v2, v0, La2/b;->b:[J

    const-wide v10, 0x7fffffffffffffffL

    invoke-static {v2, v10, v11}, Ljava/util/Arrays;->fill([JJ)V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    sget-object v4, La2/b;->c:Lj8/v;

    invoke-static {v4, v1}, Lj8/T;->E(Lj8/p0;Ljava/util/Collection;)Lj8/q0;

    move-result-object v1

    move v4, v3

    :goto_b0
    invoke-virtual {v1}, Lj8/q0;->size()I

    move-result v10

    if-ge v3, v10, :cond_11d

    invoke-virtual {v1, v3}, Lj8/q0;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La2/a;

    iget-wide v11, v10, La2/a;->b:J

    cmp-long v13, v11, v8

    if-nez v13, :cond_c4

    const-wide/16 v11, 0x0

    :cond_c4
    iget-wide v13, v10, La2/a;->c:J

    add-long v15, v11, v13

    iget-object v10, v10, La2/a;->a:Lj8/T;

    if-eqz v4, :cond_fd

    iget-object v5, v0, La2/b;->b:[J

    add-int/lit8 v6, v4, -0x1

    aget-wide v17, v5, v6

    cmp-long v5, v17, v11

    if-gez v5, :cond_d7

    goto :goto_fd

    :cond_d7
    if-nez v5, :cond_e9

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lj8/T;

    invoke-virtual {v5}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_e9

    invoke-virtual {v2, v6, v10}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    goto :goto_f7

    :cond_e9
    const-string v5, "CuesWithTimingSubtitle"

    const-string v8, "Truncating unsupported overlapping cues."

    invoke-static {v5, v8}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v5, v0, La2/b;->b:[J

    aput-wide v11, v5, v6

    invoke-virtual {v2, v6, v10}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :goto_f7
    const-wide v5, -0x7fffffffffffffffL    # -4.9E-324

    goto :goto_108

    :cond_fd
    :goto_fd
    iget-object v5, v0, La2/b;->b:[J

    add-int/lit8 v6, v4, 0x1

    aput-wide v11, v5, v4

    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v4, v6

    goto :goto_f7

    :goto_108
    cmp-long v8, v13, v5

    if-eqz v8, :cond_11a

    iget-object v8, v0, La2/b;->b:[J

    add-int/lit8 v9, v4, 0x1

    aput-wide v15, v8, v4

    invoke-static {}, Lj8/T;->A()Lj8/q0;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v4, v9

    :cond_11a
    add-int/2addr v3, v7

    move-wide v8, v5

    goto :goto_b0

    :cond_11d
    invoke-static {v2}, Lj8/T;->x(Ljava/util/Collection;)Lj8/T;

    move-result-object v1

    iput-object v1, v0, La2/b;->a:Lj8/T;

    return-void
.end method


# virtual methods
.method public final a(J)I
    .registers 5

    iget-object v0, p0, La2/b;->b:[J

    const/4 v1, 0x0

    invoke-static {v0, p1, p2, v1}, LZ0/F;->b([JJZ)I

    move-result p1

    iget-object p2, p0, La2/b;->a:Lj8/T;

    invoke-virtual {p2}, Ljava/util/AbstractCollection;->size()I

    move-result p2

    if-ge p1, p2, :cond_10

    goto :goto_11

    :cond_10
    const/4 p1, -0x1

    :goto_11
    return p1
.end method

.method public final h(I)J
    .registers 5

    iget-object v0, p0, La2/b;->a:Lj8/T;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    if-ge p1, v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    invoke-static {v0}, Lm7/u;->a(Z)V

    iget-object v0, p0, La2/b;->b:[J

    aget-wide v1, v0, p1

    return-wide v1
.end method

.method public final j(J)Ljava/util/List;
    .registers 5

    const/4 v0, 0x0

    iget-object v1, p0, La2/b;->b:[J

    invoke-static {v1, p1, p2, v0}, LZ0/F;->f([JJZ)I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_f

    invoke-static {}, Lj8/T;->A()Lj8/q0;

    move-result-object p1

    goto :goto_17

    :cond_f
    iget-object p2, p0, La2/b;->a:Lj8/T;

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lj8/T;

    :goto_17
    return-object p1
.end method

.method public final k()I
    .registers 2

    iget-object v0, p0, La2/b;->a:Lj8/T;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    return v0
.end method
