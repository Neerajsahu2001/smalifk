.class public final La2/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD1/w;


# instance fields
.field public final a:La2/l;

.field public final b:Lb7/e;

.field public final c:Landroidx/media3/common/b;

.field public final d:Ljava/util/ArrayList;

.field public final e:LZ0/w;

.field public f:[B

.field public g:LD1/P;

.field public h:I

.field public i:I

.field public j:[J

.field public k:J


# direct methods
.method public constructor <init>(La2/l;Landroidx/media3/common/b;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La2/h;->a:La2/l;

    new-instance v0, Lb7/e;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lb7/e;-><init>(I)V

    iput-object v0, p0, La2/h;->b:Lb7/e;

    sget-object v0, LZ0/F;->f:[B

    iput-object v0, p0, La2/h;->f:[B

    new-instance v0, LZ0/w;

    invoke-direct {v0}, LZ0/w;-><init>()V

    iput-object v0, p0, La2/h;->e:LZ0/w;

    invoke-virtual {p2}, Landroidx/media3/common/b;->a()LW0/o;

    move-result-object v0

    const-string v1, "application/x-media3-cues"

    invoke-static {v1}, LW0/I;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, LW0/o;->m:Ljava/lang/String;

    iget-object p2, p2, Landroidx/media3/common/b;->n:Ljava/lang/String;

    iput-object p2, v0, LW0/o;->i:Ljava/lang/String;

    invoke-interface {p1}, La2/l;->w()I

    move-result p1

    iput p1, v0, LW0/o;->G:I

    new-instance p1, Landroidx/media3/common/b;

    invoke-direct {p1, v0}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    iput-object p1, p0, La2/h;->c:Landroidx/media3/common/b;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La2/h;->d:Ljava/util/ArrayList;

    const/4 p1, 0x0

    iput p1, p0, La2/h;->i:I

    sget-object p1, LZ0/F;->g:[J

    iput-object p1, p0, La2/h;->j:[J

    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide p1, p0, La2/h;->k:J

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    iget v0, p0, La2/h;->i:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_6

    return-void

    :cond_6
    iget-object v0, p0, La2/h;->a:La2/l;

    invoke-interface {v0}, La2/l;->b()V

    iput v1, p0, La2/h;->i:I

    return-void
.end method

.method public final b(La2/g;)V
    .registers 10

    iget-object v0, p0, La2/h;->g:LD1/P;

    invoke-static {v0}, Lm7/u;->g(Ljava/lang/Object;)V

    iget-object v0, p1, La2/g;->b:[B

    array-length v5, v0

    iget-object v1, p0, La2/h;->e:LZ0/w;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v2, v0

    invoke-virtual {v1, v2, v0}, LZ0/w;->E(I[B)V

    iget-object v0, p0, La2/h;->g:LD1/P;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v5, v2}, LD1/P;->e(LZ0/w;II)V

    iget-object v1, p0, La2/h;->g:LD1/P;

    iget-wide v2, p1, La2/g;->a:J

    const/4 v4, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface/range {v1 .. v7}, LD1/P;->a(JIIILD1/O;)V

    return-void
.end method

.method public final d(LD1/x;LD1/A;)I
    .registers 24

    move-object/from16 v1, p0

    iget v0, v1, La2/h;->i:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_d

    const/4 v4, 0x5

    if-eq v0, v4, :cond_d

    move v0, v3

    goto :goto_e

    :cond_d
    move v0, v2

    :goto_e
    invoke-static {v0}, Lm7/u;->e(Z)V

    iget v0, v1, La2/h;->i:I

    const/4 v4, 0x2

    const/16 v5, 0x400

    const-wide/16 v6, -0x1

    if-ne v0, v3, :cond_3d

    move-object/from16 v0, p1

    check-cast v0, LD1/o;

    iget-wide v8, v0, LD1/o;->c:J

    cmp-long v0, v8, v6

    if-eqz v0, :cond_2f

    move-object/from16 v0, p1

    check-cast v0, LD1/o;

    iget-wide v8, v0, LD1/o;->c:J

    invoke-static {v8, v9}, Ll7/O6;->b(J)I

    move-result v0

    goto :goto_30

    :cond_2f
    move v0, v5

    :goto_30
    iget-object v8, v1, La2/h;->f:[B

    array-length v8, v8

    if-le v0, v8, :cond_39

    new-array v0, v0, [B

    iput-object v0, v1, La2/h;->f:[B

    :cond_39
    iput v2, v1, La2/h;->h:I

    iput v4, v1, La2/h;->i:I

    :cond_3d
    iget v0, v1, La2/h;->i:I

    iget-object v8, v1, La2/h;->d:Ljava/util/ArrayList;

    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v11, 0x4

    const/4 v12, -0x1

    if-ne v0, v4, :cond_d7

    iget-object v0, v1, La2/h;->f:[B

    array-length v4, v0

    iget v13, v1, La2/h;->h:I

    if-ne v4, v13, :cond_59

    array-length v4, v0

    add-int/2addr v4, v5

    invoke-static {v0, v4}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    iput-object v0, v1, La2/h;->f:[B

    :cond_59
    iget-object v0, v1, La2/h;->f:[B

    iget v4, v1, La2/h;->h:I

    array-length v13, v0

    sub-int/2addr v13, v4

    move-object/from16 v14, p1

    check-cast v14, LD1/o;

    invoke-virtual {v14, v0, v4, v13}, LD1/o;->l([BII)I

    move-result v0

    if-eq v0, v12, :cond_6e

    iget v4, v1, La2/h;->h:I

    add-int/2addr v4, v0

    iput v4, v1, La2/h;->h:I

    :cond_6e
    iget-wide v13, v14, LD1/o;->c:J

    cmp-long v4, v13, v6

    if-eqz v4, :cond_7b

    iget v4, v1, La2/h;->h:I

    int-to-long v5, v4

    cmp-long v4, v5, v13

    if-eqz v4, :cond_7d

    :cond_7b
    if-ne v0, v12, :cond_d7

    :cond_7d
    :try_start_7d
    iget-wide v4, v1, La2/h;->k:J

    cmp-long v0, v4, v9

    if-eqz v0, :cond_8b

    new-instance v0, La2/k;

    invoke-direct {v0, v4, v5, v3}, La2/k;-><init>(JZ)V

    :goto_88
    move-object/from16 v19, v0

    goto :goto_8e

    :cond_8b
    sget-object v0, La2/k;->c:La2/k;

    goto :goto_88

    :goto_8e
    iget-object v0, v1, La2/h;->a:La2/l;

    iget-object v4, v1, La2/h;->f:[B

    iget v5, v1, La2/h;->h:I

    new-instance v6, LA/h;

    const/4 v7, 0x5

    invoke-direct {v6, v7, v1}, LA/h;-><init>(ILjava/lang/Object;)V

    const/16 v17, 0x0

    move-object v15, v0

    move-object/from16 v16, v4

    move/from16 v18, v5

    move-object/from16 v20, v6

    invoke-interface/range {v15 .. v20}, La2/l;->d([BIILa2/k;LZ0/e;)V

    invoke-static {v8}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v0

    new-array v0, v0, [J

    iput-object v0, v1, La2/h;->j:[J

    move v0, v2

    :goto_b2
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v0, v4, :cond_c9

    iget-object v4, v1, La2/h;->j:[J

    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La2/g;

    iget-wide v5, v5, La2/g;->a:J

    aput-wide v5, v4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_b2

    :catch_c7
    move-exception v0

    goto :goto_d0

    :cond_c9
    sget-object v0, LZ0/F;->f:[B

    iput-object v0, v1, La2/h;->f:[B
    :try_end_cd
    .catch Ljava/lang/RuntimeException; {:try_start_7d .. :try_end_cd} :catch_c7

    iput v11, v1, La2/h;->i:I

    goto :goto_d7

    :goto_d0
    const-string v2, "SubtitleParser failed."

    invoke-static {v0, v2}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object v0

    throw v0

    :cond_d7
    :goto_d7
    iget v0, v1, La2/h;->i:I

    const/4 v4, 0x3

    if-ne v0, v4, :cond_121

    move-object/from16 v0, p1

    check-cast v0, LD1/o;

    iget-wide v4, v0, LD1/o;->c:J

    const-wide/16 v6, -0x1

    cmp-long v0, v4, v6

    if-eqz v0, :cond_f3

    move-object/from16 v0, p1

    check-cast v0, LD1/o;

    iget-wide v4, v0, LD1/o;->c:J

    invoke-static {v4, v5}, Ll7/O6;->b(J)I

    move-result v5

    goto :goto_f5

    :cond_f3
    const/16 v5, 0x400

    :goto_f5
    move-object/from16 v0, p1

    check-cast v0, LD1/o;

    invoke-virtual {v0, v5}, LD1/o;->r(I)I

    move-result v0

    if-ne v0, v12, :cond_121

    iget-wide v4, v1, La2/h;->k:J

    cmp-long v0, v4, v9

    if-nez v0, :cond_107

    move v0, v2

    goto :goto_10d

    :cond_107
    iget-object v0, v1, La2/h;->j:[J

    invoke-static {v0, v4, v5, v3}, LZ0/F;->f([JJZ)I

    move-result v0

    :goto_10d
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_11f

    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La2/g;

    invoke-virtual {v1, v3}, La2/h;->b(La2/g;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_10d

    :cond_11f
    iput v11, v1, La2/h;->i:I

    :cond_121
    iget v0, v1, La2/h;->i:I

    if-ne v0, v11, :cond_126

    return v12

    :cond_126
    return v2
.end method

.method public final f(LD1/y;)V
    .registers 9

    iget v0, p0, La2/h;->i:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_8

    move v0, v2

    goto :goto_9

    :cond_8
    move v0, v1

    :goto_9
    invoke-static {v0}, Lm7/u;->e(Z)V

    const/4 v0, 0x3

    invoke-interface {p1, v1, v0}, LD1/y;->u(II)LD1/P;

    move-result-object v0

    iput-object v0, p0, La2/h;->g:LD1/P;

    iget-object v3, p0, La2/h;->c:Landroidx/media3/common/b;

    invoke-interface {v0, v3}, LD1/P;->c(Landroidx/media3/common/b;)V

    invoke-interface {p1}, LD1/y;->n()V

    new-instance v0, LD1/G;

    const-wide/16 v3, 0x0

    new-array v5, v2, [J

    aput-wide v3, v5, v1

    new-array v6, v2, [J

    aput-wide v3, v6, v1

    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    invoke-direct {v0, v3, v4, v5, v6}, LD1/G;-><init>(J[J[J)V

    invoke-interface {p1, v0}, LD1/y;->o(LD1/J;)V

    iput v2, p0, La2/h;->i:I

    return-void
.end method

.method public final h(LD1/x;)Z
    .registers 2

    const/4 p1, 0x1

    return p1
.end method

.method public final i(JJ)V
    .registers 6

    iget p1, p0, La2/h;->i:I

    const/4 p2, 0x1

    if-eqz p1, :cond_a

    const/4 v0, 0x5

    if-eq p1, v0, :cond_a

    move p1, p2

    goto :goto_b

    :cond_a
    const/4 p1, 0x0

    :goto_b
    invoke-static {p1}, Lm7/u;->e(Z)V

    iput-wide p3, p0, La2/h;->k:J

    iget p1, p0, La2/h;->i:I

    const/4 p3, 0x2

    if-ne p1, p3, :cond_17

    iput p2, p0, La2/h;->i:I

    :cond_17
    iget p1, p0, La2/h;->i:I

    const/4 p2, 0x4

    if-ne p1, p2, :cond_1f

    const/4 p1, 0x3

    iput p1, p0, La2/h;->i:I

    :cond_1f
    return-void
.end method
