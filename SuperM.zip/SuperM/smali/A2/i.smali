.class public La2/i;
.super Lf1/f;
.source "SourceFile"


# instance fields
.field public k:J
