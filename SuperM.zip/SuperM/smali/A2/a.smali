.class public final La2/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lj8/T;

.field public final b:J

.field public final c:J

.field public final d:J


# direct methods
.method public constructor <init>(Ljava/util/List;JJ)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lj8/T;->x(Ljava/util/Collection;)Lj8/T;

    move-result-object p1

    iput-object p1, p0, La2/a;->a:Lj8/T;

    iput-wide p2, p0, La2/a;->b:J

    iput-wide p4, p0, La2/a;->c:J

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long p1, p2, v0

    if-eqz p1, :cond_1d

    cmp-long p1, p4, v0

    if-nez p1, :cond_1b

    goto :goto_1d

    :cond_1b
    add-long v0, p2, p4

    :cond_1d
    :goto_1d
    iput-wide v0, p0, La2/a;->d:J

    return-void
.end method
