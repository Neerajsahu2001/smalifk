.class public interface abstract La2/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public b()V
    .registers 1

    return-void
.end method

.method public abstract d([BIILa2/k;LZ0/e;)V
.end method

.method public n(II[B)La2/d;
    .registers 11

    invoke-static {}, Lj8/T;->w()Lj8/P;

    move-result-object v0

    sget-object v5, La2/k;->c:La2/k;

    new-instance v6, LC/C0;

    const/4 v1, 0x1

    invoke-direct {v6, v1, v0}, LC/C0;-><init>(ILjava/lang/Object;)V

    move-object v1, p0

    move-object v2, p3

    move v3, p1

    move v4, p2

    invoke-interface/range {v1 .. v6}, La2/l;->d([BIILa2/k;LZ0/e;)V

    new-instance p1, La2/b;

    invoke-virtual {v0}, Lj8/P;->i()Lj8/q0;

    move-result-object p2

    invoke-direct {p1, p2}, La2/b;-><init>(Lj8/q0;)V

    return-object p1
.end method

.method public abstract w()I
.end method
