.class public interface abstract La2/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(J)I
.end method

.method public abstract h(I)J
.end method

.method public abstract j(J)Ljava/util/List;
.end method

.method public abstract k()I
.end method
