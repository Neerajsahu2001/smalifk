.class public final La2/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD1/P;


# instance fields
.field public final a:LD1/P;

.field public final b:La2/j;

.field public final c:Lb7/e;

.field public final d:LZ0/w;

.field public e:I

.field public f:I

.field public g:[B

.field public h:La2/l;

.field public i:Landroidx/media3/common/b;


# direct methods
.method public constructor <init>(LD1/P;La2/j;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La2/o;->a:LD1/P;

    iput-object p2, p0, La2/o;->b:La2/j;

    new-instance p1, Lb7/e;

    const/4 p2, 0x7

    invoke-direct {p1, p2}, Lb7/e;-><init>(I)V

    iput-object p1, p0, La2/o;->c:Lb7/e;

    const/4 p1, 0x0

    iput p1, p0, La2/o;->e:I

    iput p1, p0, La2/o;->f:I

    sget-object p1, LZ0/F;->f:[B

    iput-object p1, p0, La2/o;->g:[B

    new-instance p1, LZ0/w;

    invoke-direct {p1}, LZ0/w;-><init>()V

    iput-object p1, p0, La2/o;->d:LZ0/w;

    return-void
.end method


# virtual methods
.method public final a(JIIILD1/O;)V
    .registers 15

    iget-object v0, p0, La2/o;->h:La2/l;

    if-nez v0, :cond_f

    iget-object v1, p0, La2/o;->a:LD1/P;

    move-wide v2, p1

    move v4, p3

    move v5, p4

    move v6, p5

    move-object v7, p6

    invoke-interface/range {v1 .. v7}, LD1/P;->a(JIIILD1/O;)V

    return-void

    :cond_f
    const/4 v0, 0x0

    if-nez p6, :cond_14

    const/4 p6, 0x1

    goto :goto_15

    :cond_14
    move p6, v0

    :goto_15
    const-string v1, "DRM on subtitles is not supported"

    invoke-static {p6, v1}, Lm7/u;->b(ZLjava/lang/String;)V

    iget p6, p0, La2/o;->f:I

    sub-int/2addr p6, p5

    sub-int/2addr p6, p4

    iget-object v1, p0, La2/o;->h:La2/l;

    iget-object v2, p0, La2/o;->g:[B

    sget-object v5, La2/k;->c:La2/k;

    new-instance v6, La2/n;

    invoke-direct {v6, p0, p1, p2, p3}, La2/n;-><init>(La2/o;JI)V

    move v3, p6

    move v4, p4

    invoke-interface/range {v1 .. v6}, La2/l;->d([BIILa2/k;LZ0/e;)V

    add-int/2addr p6, p4

    iput p6, p0, La2/o;->e:I

    iget p1, p0, La2/o;->f:I

    if-ne p6, p1, :cond_39

    iput v0, p0, La2/o;->e:I

    iput v0, p0, La2/o;->f:I

    :cond_39
    return-void
.end method

.method public final b(LW0/k;IZ)I
    .registers 6

    iget-object v0, p0, La2/o;->h:La2/l;

    if-nez v0, :cond_b

    iget-object v0, p0, La2/o;->a:LD1/P;

    invoke-interface {v0, p1, p2, p3}, LD1/P;->b(LW0/k;IZ)I

    move-result p1

    return p1

    :cond_b
    invoke-virtual {p0, p2}, La2/o;->f(I)V

    iget-object v0, p0, La2/o;->g:[B

    iget v1, p0, La2/o;->f:I

    invoke-interface {p1, v0, v1, p2}, LW0/k;->l([BII)I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_22

    if-eqz p3, :cond_1c

    return p2

    :cond_1c
    new-instance p1, Ljava/io/EOFException;

    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    throw p1

    :cond_22
    iget p2, p0, La2/o;->f:I

    add-int/2addr p2, p1

    iput p2, p0, La2/o;->f:I

    return p1
.end method

.method public final c(Landroidx/media3/common/b;)V
    .registers 8

    iget-object v0, p1, Landroidx/media3/common/b;->n:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Landroidx/media3/common/b;->n:Ljava/lang/String;

    invoke-static {v0}, LW0/I;->h(Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_10

    const/4 v1, 0x1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    invoke-static {v1}, Lm7/u;->a(Z)V

    iget-object v1, p0, La2/o;->i:Landroidx/media3/common/b;

    invoke-virtual {p1, v1}, Landroidx/media3/common/b;->equals(Ljava/lang/Object;)Z

    move-result v1

    iget-object v2, p0, La2/o;->b:La2/j;

    if-nez v1, :cond_2e

    iput-object p1, p0, La2/o;->i:Landroidx/media3/common/b;

    invoke-interface {v2, p1}, La2/j;->p(Landroidx/media3/common/b;)Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-interface {v2, p1}, La2/j;->l(Landroidx/media3/common/b;)La2/l;

    move-result-object v1

    goto :goto_2c

    :cond_2b
    const/4 v1, 0x0

    :goto_2c
    iput-object v1, p0, La2/o;->h:La2/l;

    :cond_2e
    iget-object v1, p0, La2/o;->h:La2/l;

    iget-object v3, p0, La2/o;->a:LD1/P;

    if-nez v1, :cond_38

    invoke-interface {v3, p1}, LD1/P;->c(Landroidx/media3/common/b;)V

    goto :goto_5b

    :cond_38
    invoke-virtual {p1}, Landroidx/media3/common/b;->a()LW0/o;

    move-result-object v1

    const-string v4, "application/x-media3-cues"

    invoke-static {v4}, LW0/I;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v1, LW0/o;->m:Ljava/lang/String;

    iput-object v0, v1, LW0/o;->i:Ljava/lang/String;

    const-wide v4, 0x7fffffffffffffffL

    iput-wide v4, v1, LW0/o;->r:J

    invoke-interface {v2, p1}, La2/j;->e(Landroidx/media3/common/b;)I

    move-result p1

    iput p1, v1, LW0/o;->G:I

    new-instance p1, Landroidx/media3/common/b;

    invoke-direct {p1, v1}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    invoke-interface {v3, p1}, LD1/P;->c(Landroidx/media3/common/b;)V

    :goto_5b
    return-void
.end method

.method public final e(LZ0/w;II)V
    .registers 5

    iget-object v0, p0, La2/o;->h:La2/l;

    if-nez v0, :cond_a

    iget-object v0, p0, La2/o;->a:LD1/P;

    invoke-interface {v0, p1, p2, p3}, LD1/P;->e(LZ0/w;II)V

    return-void

    :cond_a
    invoke-virtual {p0, p2}, La2/o;->f(I)V

    iget-object p3, p0, La2/o;->g:[B

    iget v0, p0, La2/o;->f:I

    invoke-virtual {p1, v0, p2, p3}, LZ0/w;->e(II[B)V

    iget p1, p0, La2/o;->f:I

    add-int/2addr p1, p2

    iput p1, p0, La2/o;->f:I

    return-void
.end method

.method public final f(I)V
    .registers 6

    iget-object v0, p0, La2/o;->g:[B

    array-length v0, v0

    iget v1, p0, La2/o;->f:I

    sub-int/2addr v0, v1

    if-lt v0, p1, :cond_9

    return-void

    :cond_9
    iget v0, p0, La2/o;->e:I

    sub-int/2addr v1, v0

    mul-int/lit8 v0, v1, 0x2

    add-int/2addr p1, v1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iget-object v0, p0, La2/o;->g:[B

    array-length v2, v0

    if-gt p1, v2, :cond_1a

    move-object p1, v0

    goto :goto_1c

    :cond_1a
    new-array p1, p1, [B

    :goto_1c
    iget v2, p0, La2/o;->e:I

    const/4 v3, 0x0

    invoke-static {v0, v2, p1, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput v3, p0, La2/o;->e:I

    iput v1, p0, La2/o;->f:I

    iput-object p1, p0, La2/o;->g:[B

    return-void
.end method
