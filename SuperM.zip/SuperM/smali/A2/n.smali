.class public final synthetic La2/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LZ0/e;


# instance fields
.field public final synthetic a:La2/o;

.field public final synthetic b:J

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(La2/o;JI)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La2/n;->a:La2/o;

    iput-wide p2, p0, La2/n;->b:J

    iput p4, p0, La2/n;->c:I

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .registers 13

    check-cast p1, La2/a;

    iget-object v0, p0, La2/n;->a:La2/o;

    iget-object v1, v0, La2/o;->i:Landroidx/media3/common/b;

    invoke-static {v1}, Lm7/u;->g(Ljava/lang/Object;)V

    iget-object v1, p1, La2/a;->a:Lj8/T;

    iget-object v2, v0, La2/o;->c:Lb7/e;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v2, p1, La2/a;->c:J

    invoke-static {v2, v3, v1}, Lb7/e;->a(JLjava/util/List;)[B

    move-result-object v1

    iget-object v2, v0, La2/o;->d:LZ0/w;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v3, v1

    invoke-virtual {v2, v3, v1}, LZ0/w;->E(I[B)V

    array-length v3, v1

    iget-object v4, v0, La2/o;->a:LD1/P;

    const/4 v5, 0x0

    invoke-interface {v4, v2, v3, v5}, LD1/P;->e(LZ0/w;II)V

    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    iget-wide v6, p1, La2/a;->b:J

    cmp-long p1, v6, v2

    iget-wide v2, p0, La2/n;->b:J

    const-wide v8, 0x7fffffffffffffffL

    if-nez p1, :cond_46

    iget-object p1, v0, La2/o;->i:Landroidx/media3/common/b;

    iget-wide v6, p1, Landroidx/media3/common/b;->s:J

    cmp-long p1, v6, v8

    if-nez p1, :cond_41

    const/4 v5, 0x1

    :cond_41
    invoke-static {v5}, Lm7/u;->e(Z)V

    :goto_44
    move-wide v5, v2

    goto :goto_53

    :cond_46
    iget-object p1, v0, La2/o;->i:Landroidx/media3/common/b;

    iget-wide v4, p1, Landroidx/media3/common/b;->s:J

    cmp-long p1, v4, v8

    if-nez p1, :cond_50

    add-long/2addr v2, v6

    goto :goto_44

    :cond_50
    add-long v2, v6, v4

    goto :goto_44

    :goto_53
    array-length v8, v1

    iget-object v4, v0, La2/o;->a:LD1/P;

    iget v7, p0, La2/n;->c:I

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-interface/range {v4 .. v10}, LD1/P;->a(JIIILD1/O;)V

    return-void
.end method
