.class public interface abstract La2/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lf1/c;


# virtual methods
.method public abstract c(J)V
.end method
