.class public final synthetic LA/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/concurrent/futures/l;
.implements LD/S;
.implements Ly2/b;
.implements LZ0/e;
.implements LZ0/m;
.implements Lk1/v;
.implements Lv7/f;
.implements LC/J;
.implements Lcom/facebook/react/uimanager/UIBlock;
.implements Lv7/e;
.implements Lio/sentry/Z;
.implements Lio/sentry/R0;
.implements Lg/a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LA/h;->a:I

    iput-object p2, p0, LA/h;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .registers 12

    check-cast p1, Lwe/S0;

    instance-of v0, p1, Lwe/R0;

    const/4 v1, 0x0

    iget-object v2, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v2, Lwe/X;

    const-string v3, "publishEventHandler"

    if-eqz v0, :cond_4f

    check-cast p1, Lwe/R0;

    iget-object v0, p1, Lwe/R0;->a:Ljava/lang/Object;

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    iget-object v0, v2, Lwe/X;->Q:LW2/u;

    if-eqz v0, :cond_4b

    iget-object p1, p1, Lwe/R0;->a:Ljava/lang/Object;

    check-cast p1, Lwe/W0;

    iget-boolean v8, v2, Lwe/X;->V0:Z

    iget-object v5, p1, Lwe/W0;->b:Ljava/lang/String;

    new-instance v1, Lwe/o0;

    const-string v4, "SUCCESS"

    iget-object v6, p1, Lwe/W0;->c:Ljava/lang/String;

    iget-object v7, p1, Lwe/W0;->d:Ljava/lang/String;

    iget-object v9, p1, Lwe/W0;->a:Ljava/lang/String;

    move-object v3, v1

    invoke-direct/range {v3 .. v9}, Lwe/o0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    iget-object p1, v0, LW2/u;->c:Ljava/lang/Object;

    check-cast p1, Lcom/google/gson/k;

    instance-of v3, p1, Lcom/google/gson/k;

    if-nez v3, :cond_3b

    invoke-virtual {p1, v1}, Lcom/google/gson/k;->h(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    goto :goto_3f

    :cond_3b
    invoke-static {p1, v1}, Lcom/newrelic/agent/android/instrumentation/GsonInstrumentation;->toJson(Lcom/google/gson/k;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    :goto_3f
    invoke-virtual {v0}, LW2/u;->b()Lwe/b;

    move-result-object v0

    const/4 v1, 0x5

    invoke-virtual {v0, v1, p1}, Lwe/b;->a(ILjava/lang/String;)V

    const/4 p1, 0x0

    iput-boolean p1, v2, Lwe/X;->V0:Z

    goto :goto_82

    :cond_4b
    invoke-static {v3}, Lkotlin/jvm/internal/l;->m(Ljava/lang/String;)V

    throw v1

    :cond_4f
    instance-of v0, p1, Lwe/Q0;

    if-eqz v0, :cond_82

    check-cast p1, Lwe/Q0;

    iget-object v0, p1, Lwe/Q0;->a:Lwe/d1;

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    iget-object p1, p1, Lwe/Q0;->a:Lwe/d1;

    iget-object v0, p1, Lwe/d1;->b:Ljava/lang/String;

    const-string v4, "DB009"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_76

    iget-object p1, v2, Lwe/X;->g1:Lg/b;

    iget-object v0, v2, Lwe/X;->U0:Lwe/g1;

    if-eqz v0, :cond_70

    invoke-virtual {p1, v0}, Lg/b;->a(Ljava/lang/Object;)V

    goto :goto_82

    :cond_70
    const-string p1, "mYesBankRequestDataWrapper"

    invoke-static {p1}, Lkotlin/jvm/internal/l;->m(Ljava/lang/String;)V

    throw v1

    :cond_76
    iget-object v0, v2, Lwe/X;->Q:LW2/u;

    if-eqz v0, :cond_7e

    invoke-virtual {v0, p1}, LW2/u;->d(Lwe/d1;)V

    goto :goto_82

    :cond_7e
    invoke-static {v3}, Lkotlin/jvm/internal/l;->m(Ljava/lang/String;)V

    throw v1

    :cond_82
    :goto_82
    return-void
.end method

.method public accept(Ljava/lang/Object;)V
    .registers 9

    check-cast p1, La2/a;

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, La2/h;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, La2/g;

    iget-wide v2, p1, La2/a;->b:J

    iget-object v4, v0, La2/h;->b:Lb7/e;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v4, p1, La2/a;->a:Lj8/T;

    iget-wide v5, p1, La2/a;->c:J

    invoke-static {v5, v6, v4}, Lb7/e;->a(JLjava/util/List;)[B

    move-result-object v4

    invoke-direct {v1, v2, v3, v4}, La2/g;-><init>(J[B)V

    iget-object v2, v0, La2/h;->d:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-wide v2, v0, La2/h;->k:J

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v4, v2, v4

    if-eqz v4, :cond_33

    iget-wide v4, p1, La2/a;->b:J

    cmp-long p1, v4, v2

    if-ltz p1, :cond_36

    :cond_33
    invoke-virtual {v0, v1}, La2/h;->b(La2/g;)V

    :cond_36
    return-void
.end method

.method public c(LC/G0;)V
    .registers 3

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;

    invoke-static {v0, p1}, Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;->h(Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;LC/G0;)V

    return-void
.end method

.method public d(Ly2/a;)Ly2/c;
    .registers 9

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    const-string v1, "$context"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;

    invoke-direct {v1, v0}, Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;-><init>(Landroid/content/Context;)V

    iget-object v0, p1, Ly2/a;->b:Ljava/lang/String;

    iput-object v0, v1, Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;->b:Ljava/lang/String;

    const-string v0, "callback"

    iget-object p1, p1, Ly2/a;->c:Ls2/l;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, v1, Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;->c:Ls2/l;

    const/4 p1, 0x1

    iput-boolean p1, v1, Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;->d:Z

    iput-boolean p1, v1, Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;->e:Z

    invoke-virtual {v1}, Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;->a()Ly2/a;

    move-result-object p1

    new-instance v6, Lz2/h;

    iget-boolean v4, p1, Ly2/a;->d:Z

    iget-boolean v5, p1, Ly2/a;->e:Z

    iget-object v1, p1, Ly2/a;->a:Landroid/content/Context;

    iget-object v2, p1, Ly2/a;->b:Ljava/lang/String;

    iget-object v3, p1, Ly2/a;->c:Ls2/l;

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lz2/h;-><init>(Landroid/content/Context;Ljava/lang/String;Ls2/l;ZZ)V

    return-object v6
.end method

.method public e(Lio/sentry/Q0;)V
    .registers 4

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, Lkotlin/jvm/internal/z;

    const-string v1, "$screen"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "it"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p1, Lio/sentry/Q0;->e:Ljava/lang/String;

    if-eqz p1, :cond_19

    const/16 v1, 0x2e

    invoke-static {v1, p1, p1}, LZd/i;->V(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_1a

    :cond_19
    const/4 p1, 0x0

    :goto_1a
    iput-object p1, v0, Lkotlin/jvm/internal/z;->a:Ljava/lang/Object;

    return-void
.end method

.method public execute(Lcom/facebook/react/uimanager/NativeViewHierarchyManager;)V
    .registers 4

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/swmansion/rnscreens/I;

    const-string v1, "this$0"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "nativeViewHierarchyManager"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/facebook/react/uimanager/ReactShadowNodeImpl;->getReactTag()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/facebook/react/uimanager/NativeViewHierarchyManager;->resolveView(I)Landroid/view/View;

    move-result-object p1

    instance-of v0, p1, Lcom/swmansion/rnscreens/ScreenContainer;

    if-eqz v0, :cond_1f

    check-cast p1, Lcom/swmansion/rnscreens/ScreenContainer;

    invoke-virtual {p1}, Lcom/swmansion/rnscreens/ScreenContainer;->h()V

    :cond_1f
    return-void
.end method

.method public h()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/g0;

    iget-object v0, v0, Lio/sentry/g0;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->j0()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 3

    iget v0, p0, LA/h;->a:I

    check-cast p1, LW0/O;

    packed-switch v0, :pswitch_data_1a

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, LY0/c;

    invoke-interface {p1, v0}, LW0/O;->s(LY0/c;)V

    return-void

    :pswitch_f
    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/L;

    iget-object v0, v0, Landroidx/media3/exoplayer/L;->N:LW0/M;

    invoke-interface {p1, v0}, LW0/O;->J(LW0/M;)V

    return-void

    nop

    :pswitch_data_1a
    .packed-switch 0x6
        :pswitch_f
    .end packed-switch
.end method

.method public j(Ljava/util/UUID;)Lk1/x;
    .registers 2

    iget-object p1, p0, LA/h;->b:Ljava/lang/Object;

    check-cast p1, Lk1/B;

    return-object p1
.end method

.method public k(LD/T;)V
    .registers 5

    iget v0, p0, LA/h;->a:I

    packed-switch v0, :pswitch_data_2a

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, LC/D0;

    iget-object v1, v0, LC/D0;->k:Ljava/lang/Object;

    monitor-enter v1

    :try_start_c
    invoke-virtual {v0, p1}, LC/D0;->g(LD/T;)V

    monitor-exit v1

    return-void

    :catchall_11
    move-exception p1

    monitor-exit v1
    :try_end_13
    .catchall {:try_start_c .. :try_end_13} :catchall_11

    throw p1

    :pswitch_14
    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, LC/o0;

    iget-object v1, v0, LC/o0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_1b
    iget v2, v0, LC/o0;->c:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v0, LC/o0;->c:I

    monitor-exit v1
    :try_end_22
    .catchall {:try_start_1b .. :try_end_22} :catchall_26

    invoke-virtual {v0, p1}, LC/o0;->k(LD/T;)V

    return-void

    :catchall_26
    move-exception p1

    :try_start_27
    monitor-exit v1
    :try_end_28
    .catchall {:try_start_27 .. :try_end_28} :catchall_26

    throw p1

    nop

    :pswitch_data_2a
    .packed-switch 0x2
        :pswitch_14
    .end packed-switch
.end method

.method public n(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .registers 4

    iget v0, p0, LA/h;->a:I

    packed-switch v0, :pswitch_data_30

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, LC/C;

    iget-object v1, v0, LC/C;->h:Ljava/lang/Object;

    monitor-enter v1

    :try_start_c
    iput-object p1, v0, LC/C;->k:Landroidx/concurrent/futures/k;

    monitor-exit v1
    :try_end_f
    .catchall {:try_start_c .. :try_end_f} :catchall_12

    const-string p1, "CaptureProcessorPipeline-close"

    return-object p1

    :catchall_12
    move-exception p1

    :try_start_13
    monitor-exit v1
    :try_end_14
    .catchall {:try_start_13 .. :try_end_14} :catchall_12

    throw p1

    :pswitch_15
    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, LA/k;

    iput-object p1, v0, LA/k;->d:Landroidx/concurrent/futures/k;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "WaitForRepeatingRequestStart["

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "]"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_15
    .end packed-switch
.end method

.method public onFailure(Ljava/lang/Exception;)V
    .registers 3

    iget-object p1, p0, LA/h;->b:Ljava/lang/Object;

    check-cast p1, Lgb/d;

    const-string v0, "this$0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p1, Lgb/d;->c:Lgb/e;

    if-eqz v0, :cond_10

    invoke-interface {v0}, Lgb/e;->onFailureOtpAutoCapture()V

    :cond_10
    invoke-virtual {p1}, Lgb/d;->unRegisterReceiver()V

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, LA/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/perf/config/RemoteConfigManager;

    check-cast p1, Ljava/lang/Boolean;

    invoke-static {v0, p1}, Lcom/google/firebase/perf/config/RemoteConfigManager;->b(Lcom/google/firebase/perf/config/RemoteConfigManager;Ljava/lang/Boolean;)V

    return-void
.end method
