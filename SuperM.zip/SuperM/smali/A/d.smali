.class public LA/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/g0;
.implements LG/d;
.implements LD/S;
.implements LC5/n;
.implements Landroidx/concurrent/futures/l;
.implements LH5/b;
.implements Lr0/t;
.implements LK5/k;
.implements LM2/g;
.implements LR7/a;
.implements Ll7/o7;
.implements Landroidx/core/view/e;
.implements Lcom/bumptech/glide/integration/webp/c;
.implements Lcom/google/gson/internal/p;
.implements Lio/sentry/V0;
.implements Landroidx/core/view/z;
.implements Lv7/d;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    iput p1, p0, LA/d;->a:I

    sparse-switch p1, :sswitch_data_42

    sget-object p1, Lz/j;->a:LI6/l;

    const-class v0, Lz/l;

    invoke-virtual {p1, v0}, LI6/l;->u(Ljava/lang/Class;)LD/f0;

    move-result-object p1

    check-cast p1, Lz/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/d;->b:Ljava/lang/Object;

    return-void

    :sswitch_15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, LA/d;->b:Ljava/lang/Object;

    return-void

    :sswitch_20
    new-instance p1, LO8/c;

    sget-object v0, Lio/sentry/r0;->a:Lio/sentry/r0;

    invoke-direct {p1, v0}, LO8/c;-><init>(Lio/sentry/ILogger;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/d;->b:Ljava/lang/Object;

    return-void

    :sswitch_2d
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/IdentityHashMap;

    invoke-direct {p1}, Ljava/util/IdentityHashMap;-><init>()V

    invoke-static {p1}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object p1

    const-string v0, "newIdentityHashSet()"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LA/d;->b:Ljava/lang/Object;

    return-void

    nop

    :sswitch_data_42
    .sparse-switch
        0xb -> :sswitch_2d
        0x1a -> :sswitch_20
        0x1d -> :sswitch_15
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LA/d;->a:I

    iput-object p2, p0, LA/d;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    iput p1, p0, LA/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/view/ContentInfo;)V
    .registers 3

    const/16 v0, 0x11

    iput v0, p0, LA/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, LZ0/r;->p(Ljava/lang/Object;)Landroid/view/ContentInfo;

    move-result-object p1

    iput-object p1, p0, LA/d;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/google/protobuf/u;)V
    .registers 3

    const/16 v0, 0x15

    iput v0, p0, LA/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "output"

    invoke-static {p1, v0}, Lcom/google/protobuf/Y;->a(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LA/d;->b:Ljava/lang/Object;

    iput-object p0, p1, Lcom/google/protobuf/u;->a:LA/d;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    const/16 v0, 0x17

    iput v0, p0, LA/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, LA/d;->b:Ljava/lang/Object;

    return-void
.end method

.method public static H(Ljava/lang/Throwable;Lio/sentry/protocol/o;Ljava/lang/Long;Ljava/util/List;Z)Lio/sentry/protocol/x;
    .registers 10

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lio/sentry/protocol/x;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    if-eqz v0, :cond_36

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Package;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v1, v3, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    :cond_36
    if-eqz v0, :cond_3d

    invoke-virtual {v0}, Ljava/lang/Package;->getName()Ljava/lang/String;

    move-result-object v0

    goto :goto_3e

    :cond_3d
    const/4 v0, 0x0

    :goto_3e
    if-eqz p3, :cond_53

    invoke-interface {p3}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_53

    new-instance v3, Lio/sentry/protocol/D;

    invoke-direct {v3, p3}, Lio/sentry/protocol/D;-><init>(Ljava/util/List;)V

    if-eqz p4, :cond_51

    sget-object p3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object p3, v3, Lio/sentry/protocol/D;->c:Ljava/lang/Boolean;

    :cond_51
    iput-object v3, v2, Lio/sentry/protocol/x;->e:Lio/sentry/protocol/D;

    :cond_53
    iput-object p2, v2, Lio/sentry/protocol/x;->d:Ljava/lang/Long;

    iput-object v1, v2, Lio/sentry/protocol/x;->a:Ljava/lang/String;

    iput-object p1, v2, Lio/sentry/protocol/x;->f:Lio/sentry/protocol/o;

    iput-object v0, v2, Lio/sentry/protocol/x;->c:Ljava/lang/String;

    iput-object p0, v2, Lio/sentry/protocol/x;->b:Ljava/lang/String;

    return-object v2
.end method


# virtual methods
.method public A()Landroid/view/ContentInfo;
    .registers 2

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    return-object v0
.end method

.method public C()I
    .registers 2

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    return v0
.end method

.method public E()J
    .registers 10

    const-wide/16 v0, 0x4

    move-wide v2, v0

    :goto_3
    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-lez v6, :cond_23

    iget-object v6, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v6, Ljava/io/InputStream;

    invoke-virtual {v6, v2, v3}, Ljava/io/InputStream;->skip(J)J

    move-result-wide v7

    cmp-long v4, v7, v4

    if-lez v4, :cond_17

    sub-long/2addr v2, v7

    goto :goto_3

    :cond_17
    invoke-virtual {v6}, Ljava/io/InputStream;->read()I

    move-result v4

    const/4 v5, -0x1

    if-ne v4, v5, :cond_1f

    goto :goto_23

    :cond_1f
    const-wide/16 v4, 0x1

    sub-long/2addr v2, v4

    goto :goto_3

    :cond_23
    :goto_23
    sub-long/2addr v0, v2

    return-wide v0
.end method

.method public F(Ljava/lang/StringBuilder;Ljava/util/Iterator;)V
    .registers 5

    :try_start_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3e

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/CharSequence;

    if-eqz v1, :cond_14

    check-cast v0, Ljava/lang/CharSequence;

    goto :goto_18

    :cond_14
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_18
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    :goto_1b
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3e

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/CharSequence;

    if-eqz v1, :cond_36

    check-cast v0, Ljava/lang/CharSequence;

    goto :goto_3a

    :cond_36
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_3a
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    :try_end_3d
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_3d} :catch_3f

    goto :goto_1b

    :cond_3e
    return-void

    :catch_3f
    move-exception p1

    new-instance p2, Ljava/lang/AssertionError;

    invoke-direct {p2, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p2
.end method

.method public G(Landroid/content/ContentProvider;)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, LO8/c;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-gt v0, v1, :cond_2a

    invoke-virtual {p1}, Landroid/content/ContentProvider;->getCallingPackage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    if-eqz v0, :cond_22

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_22

    return-void

    :cond_22
    new-instance p1, Ljava/lang/SecurityException;

    const-string v0, "Provider does not allow for granting of Uri permissions"

    invoke-direct {p1, v0}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2a
    return-void
.end method

.method public I(Ldd/q;)LXc/f;
    .registers 6

    const-string v0, "javaClass"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Ldd/q;->d()Lwd/b;

    move-result-object v0

    iget-object v1, p1, Ldd/q;->a:Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_14

    move-object v3, v2

    goto :goto_19

    :cond_14
    new-instance v3, Ldd/q;

    invoke-direct {v3, v1}, Ldd/q;-><init>(Ljava/lang/Class;)V

    :goto_19
    if-nez v3, :cond_45

    invoke-virtual {v0}, Lwd/b;->e()Lwd/b;

    move-result-object v0

    const-string v1, "fqName.parent()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v1, Ljd/d;

    invoke-virtual {v1, v0}, Ljd/d;->b(Lwd/b;)Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Lvc/l;->A(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkd/n;

    if-nez v0, :cond_35

    goto :goto_44

    :cond_35
    iget-object v0, v0, Lkd/n;->j:Lkd/d;

    iget-object v0, v0, Lkd/d;->d:Lkd/s;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ldd/q;->getName()Lwd/e;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lkd/s;->v(Lwd/e;Ldd/q;)LXc/f;

    move-result-object v2

    :goto_44
    return-object v2

    :cond_45
    invoke-virtual {p0, v3}, LA/d;->I(Ldd/q;)LXc/f;

    move-result-object v0

    if-nez v0, :cond_4d

    move-object v0, v2

    goto :goto_51

    :cond_4d
    invoke-interface {v0}, LXc/f;->h0()LGd/o;

    move-result-object v0

    :goto_51
    if-nez v0, :cond_55

    move-object p1, v2

    goto :goto_5f

    :cond_55
    invoke-virtual {p1}, Ldd/q;->getName()Lwd/e;

    move-result-object p1

    sget-object v1, Lfd/b;->i:Lfd/b;

    invoke-interface {v0, p1, v1}, LGd/q;->a(Lwd/e;Lfd/b;)LXc/h;

    move-result-object p1

    :goto_5f
    instance-of v0, p1, LXc/f;

    if-eqz v0, :cond_66

    move-object v2, p1

    check-cast v2, LXc/f;

    :cond_66
    return-object v2
.end method

.method public J(IZ)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->A(IZ)V

    return-void
.end method

.method public K(ILcom/google/protobuf/l;)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->C(ILcom/google/protobuf/l;)V

    return-void
.end method

.method public L(ID)V
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p2, p3}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide p2

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/u;->G(IJ)V

    return-void
.end method

.method public M(II)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->I(II)V

    return-void
.end method

.method public N(II)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->E(II)V

    return-void
.end method

.method public O(IJ)V
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/u;->G(IJ)V

    return-void
.end method

.method public P(FI)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    invoke-virtual {v0, p2, p1}, Lcom/google/protobuf/u;->E(II)V

    return-void
.end method

.method public Q(ILjava/lang/Object;Lcom/google/protobuf/D0;)V
    .registers 6

    check-cast p2, Lcom/google/protobuf/r0;

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    const/4 v1, 0x3

    invoke-virtual {v0, p1, v1}, Lcom/google/protobuf/u;->O(II)V

    iget-object v1, v0, Lcom/google/protobuf/u;->a:LA/d;

    invoke-interface {p3, p2, v1}, Lcom/google/protobuf/D0;->j(Ljava/lang/Object;LA/d;)V

    const/4 p2, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->O(II)V

    return-void
.end method

.method public R(II)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->I(II)V

    return-void
.end method

.method public S(IJ)V
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/u;->R(IJ)V

    return-void
.end method

.method public T(ILjava/lang/Object;Lcom/google/protobuf/D0;)V
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    check-cast p2, Lcom/google/protobuf/r0;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/u;->K(ILcom/google/protobuf/r0;Lcom/google/protobuf/D0;)V

    return-void
.end method

.method public U(II)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->E(II)V

    return-void
.end method

.method public V(IJ)V
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/u;->G(IJ)V

    return-void
.end method

.method public W(II)V
    .registers 4

    shl-int/lit8 v0, p2, 0x1

    shr-int/lit8 p2, p2, 0x1f

    xor-int/2addr p2, v0

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->P(II)V

    return-void
.end method

.method public X(IJ)V
    .registers 7

    const/4 v0, 0x1

    shl-long v0, p2, v0

    const/16 v2, 0x3f

    shr-long/2addr p2, v2

    xor-long/2addr p2, v0

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/u;->R(IJ)V

    return-void
.end method

.method public Y(II)V
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/u;->P(II)V

    return-void
.end method

.method public Z(IJ)V
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/protobuf/u;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/u;->R(IJ)V

    return-void
.end method

.method public c()I
    .registers 4

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v1

    shl-int/lit8 v1, v1, 0x8

    const v2, 0xff00

    and-int/2addr v1, v2

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr v0, v1

    return v0
.end method

.method public construct()Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/reflect/Type;

    instance-of v1, v0, Ljava/lang/reflect/ParameterizedType;

    const-string v2, "Invalid EnumSet type: "

    if-eqz v1, :cond_35

    move-object v1, v0

    check-cast v1, Ljava/lang/reflect/ParameterizedType;

    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v3, 0x0

    aget-object v1, v1, v3

    instance-of v3, v1, Ljava/lang/Class;

    if-eqz v3, :cond_1f

    check-cast v1, Ljava/lang/Class;

    invoke-static {v1}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;

    move-result-object v0

    return-object v0

    :cond_1f
    new-instance v1, Lcom/google/gson/q;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_35
    new-instance v1, Lcom/google/gson/q;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public createWebView(Landroid/webkit/WebView;)Lorg/chromium/support_lib_boundary/WebViewProviderBoundaryInterface;
    .registers 3

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;

    invoke-interface {v0, p1}, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;->createWebView(Landroid/webkit/WebView;)Ljava/lang/reflect/InvocationHandler;

    move-result-object p1

    const-class v0, Lorg/chromium/support_lib_boundary/WebViewProviderBoundaryInterface;

    invoke-static {v0, p1}, LHe/b;->a(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lorg/chromium/support_lib_boundary/WebViewProviderBoundaryInterface;

    return-object p1
.end method

.method public get(I)Ljava/lang/Object;
    .registers 6

    int-to-double v0, p1

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    div-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v0

    double-to-int p1, v0

    sget-object v0, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    const/4 v1, 0x1

    invoke-static {v1, p1, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p1

    const-string v0, "createBitmap(\n          \u2026   Bitmap.Config.RGB_565)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-object p1
.end method

.method public getSource()I
    .registers 2

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    invoke-static {v0}, LO6/H;->b(Landroid/view/ContentInfo;)I

    move-result v0

    return v0
.end method

.method public getWebkitToCompatConverter()Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;
    .registers 3

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;

    invoke-interface {v0}, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;->getWebkitToCompatConverter()Ljava/lang/reflect/InvocationHandler;

    move-result-object v0

    const-class v1, Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;

    invoke-static {v1, v0}, LHe/b;->a(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;

    return-object v0
.end method

.method public i()Landroid/content/ClipData;
    .registers 2

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    invoke-static {v0}, LZ0/r;->b(Landroid/view/ContentInfo;)Landroid/content/ClipData;

    move-result-object v0

    return-object v0
.end method

.method public k(LD/T;)V
    .registers 5

    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, LC/B0;

    iget-object p1, p1, LC/B0;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_7
    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, LC/B0;

    iget-object v1, v0, LC/B0;->i:LD/S;

    iget-object v2, v0, LC/B0;->j:Ljava/util/concurrent/Executor;

    iget-object v0, v0, LC/B0;->q:LC/I0;

    invoke-virtual {v0}, LC/I0;->e()V

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, LC/B0;

    invoke-virtual {v0}, LC/B0;->k()V

    monitor-exit p1
    :try_end_1c
    .catchall {:try_start_7 .. :try_end_1c} :catchall_32

    if-eqz v1, :cond_31

    if-eqz v2, :cond_2a

    new-instance p1, LB1/G;

    const/4 v0, 0x1

    invoke-direct {p1, v0, p0, v1}, LB1/G;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v2, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_31

    :cond_2a
    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, LC/B0;

    invoke-interface {v1, p1}, LD/S;->k(LD/T;)V

    :cond_31
    :goto_31
    return-void

    :catchall_32
    move-exception v0

    :try_start_33
    monitor-exit p1
    :try_end_34
    .catchall {:try_start_33 .. :try_end_34} :catchall_32

    throw v0
.end method

.method public l(Landroid/view/View;)Z
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/drawerlayout/widget/DrawerLayout;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Landroidx/drawerlayout/widget/DrawerLayout;->isDrawerOpen(Landroid/view/View;)Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-virtual {v0, p1}, Landroidx/drawerlayout/widget/DrawerLayout;->getDrawerLockMode(Landroid/view/View;)I

    move-result v1

    const/4 v2, 0x2

    if-eq v1, v2, :cond_19

    invoke-virtual {v0, p1}, Landroidx/drawerlayout/widget/DrawerLayout;->closeDrawer(Landroid/view/View;)V

    const/4 p1, 0x1

    return p1

    :cond_19
    const/4 p1, 0x0

    return p1
.end method

.method public m(LI5/d;ILI5/h;LD5/c;)LI5/a;
    .registers 9

    invoke-virtual {p1}, LI5/d;->j0()V

    iget-object v0, p1, LI5/d;->c:Lz5/c;

    iget-object v1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v1, LB5/a;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Lz5/b;->a:Lz5/c;

    if-ne v0, v3, :cond_4e

    iget-object p4, p4, LD5/c;->a:Landroid/graphics/Bitmap$Config;

    iget-object v0, v1, LB5/a;->b:Ljava/lang/Object;

    check-cast v0, LL5/c;

    const/4 v1, 0x0

    invoke-interface {v0, p1, p4, p2, v1}, LL5/c;->b(LI5/d;Landroid/graphics/Bitmap$Config;ILandroid/graphics/ColorSpace;)LX4/b;

    move-result-object p2

    :try_start_20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, LI5/d;->j0()V

    iget p4, p1, LI5/d;->d:I

    invoke-virtual {p1}, LI5/d;->j0()V

    iget p1, p1, LI5/d;->e:I

    sget v0, LI5/c;->i:I

    new-instance v0, LI5/c;

    invoke-direct {v0, p2, p3, p4, p1}, LI5/c;-><init>(LX4/b;LI5/h;II)V

    sget-object p1, LI5/c;->h:Ljava/util/HashSet;

    const-string p3, "is_rounded"

    invoke-virtual {p1, p3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_46

    iget-object p1, v0, LI5/c;->a:Ljava/util/HashMap;

    invoke-virtual {p1, p3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_43
    .catchall {:try_start_20 .. :try_end_43} :catchall_44

    goto :goto_46

    :catchall_44
    move-exception p1

    goto :goto_4a

    :cond_46
    :goto_46
    invoke-static {p2}, LX4/b;->l(LX4/b;)V

    return-object v0

    :goto_4a
    invoke-static {p2}, LX4/b;->l(LX4/b;)V

    throw p1

    :cond_4e
    sget-object p2, Lz5/b;->c:Lz5/c;

    if-ne v0, p2, :cond_71

    invoke-virtual {p1}, LI5/d;->j0()V

    iget p2, p1, LI5/d;->f:I

    const/4 p3, -0x1

    if-eq p2, p3, :cond_69

    invoke-virtual {p1}, LI5/d;->j0()V

    iget p2, p1, LI5/d;->g:I

    if-eq p2, p3, :cond_69

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, p1, p4}, LB5/a;->l(LI5/d;LD5/c;)LI5/c;

    move-result-object p1

    return-object p1

    :cond_69
    new-instance p2, LH5/a;

    const-string p3, "image width or height is incorrect"

    invoke-direct {p2, p3, p1}, LH5/a;-><init>(Ljava/lang/String;LI5/d;)V

    throw p2

    :cond_71
    sget-object p2, Lz5/b;->j:Lz5/c;

    if-ne v0, p2, :cond_7d

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, p1, p4}, LB5/a;->l(LI5/d;LD5/c;)LI5/c;

    move-result-object p1

    return-object p1

    :cond_7d
    sget-object p2, Lz5/c;->c:Lz5/c;

    if-eq v0, p2, :cond_86

    invoke-virtual {v1, p1, p4}, LB5/a;->l(LI5/d;LD5/c;)LI5/c;

    move-result-object p1

    return-object p1

    :cond_86
    new-instance p2, LH5/a;

    const-string p3, "unknown image format"

    invoke-direct {p2, p3, p1}, LH5/a;-><init>(Ljava/lang/String;LI5/d;)V

    throw p2
.end method

.method public n(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, LG/n;

    iget-object v1, v0, LG/n;->f:Landroidx/concurrent/futures/k;

    if-nez v1, :cond_a

    const/4 v1, 0x1

    goto :goto_b

    :cond_a
    const/4 v1, 0x0

    :goto_b
    const-string v2, "The result can only set once!"

    invoke-static {v1, v2}, Ll7/C5;->f(ZLjava/lang/String;)V

    iput-object p1, v0, LG/n;->f:Landroidx/concurrent/futures/k;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "ListFuture["

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "]"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public o(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, LO4/a;

    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, LC5/o;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public onComplete(Lv7/i;)V
    .registers 3

    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object v0

    if-nez v0, :cond_22

    move-object v0, p1

    check-cast v0, Lv7/v;

    iget-boolean v0, v0, Lv7/v;->d:Z

    if-eqz v0, :cond_16

    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, Lbe/g;

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Lbe/g;->h(Ljava/lang/Throwable;)Z

    goto :goto_2d

    :cond_16
    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lbe/g;

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    invoke-interface {v0, p1}, Lyc/d;->resumeWith(Ljava/lang/Object;)V

    goto :goto_2d

    :cond_22
    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, Lbe/g;

    invoke-static {v0}, Ll7/C6;->b(Ljava/lang/Throwable;)Luc/i;

    move-result-object v0

    invoke-interface {p1, v0}, Lyc/d;->resumeWith(Ljava/lang/Object;)V

    :goto_2d
    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .registers 5

    iget v0, p0, LA/d;->a:I

    packed-switch v0, :pswitch_data_20

    check-cast p1, Landroid/view/Surface;

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, LC/D0;

    iget-object v0, v0, LC/D0;->k:Ljava/lang/Object;

    monitor-enter v0

    :try_start_e
    iget-object v1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v1, LC/D0;

    iget-object v1, v1, LC/D0;->p:LD/y;

    const/4 v2, 0x1

    invoke-interface {v1, v2, p1}, LD/y;->a(ILandroid/view/Surface;)V

    monitor-exit v0

    return-void

    :catchall_1a
    move-exception p1

    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_e .. :try_end_1c} :catchall_1a

    throw p1

    :pswitch_1d
    check-cast p1, Ljava/lang/Void;

    return-void

    :pswitch_data_20
    .packed-switch 0x3
        :pswitch_1d
    .end packed-switch
.end method

.method public p()LD/B;
    .registers 2

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, LD/B;

    return-object v0
.end method

.method public r(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, LO4/a;

    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, LC5/o;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public release(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Landroid/graphics/Bitmap;

    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    return-void
.end method

.method public s(Landroid/graphics/Typeface;)V
    .registers 3

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, LM7/c;

    invoke-virtual {v0, p1}, LM7/c;->m(Landroid/graphics/Typeface;)Z

    move-result p1

    if-eqz p1, :cond_e

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, LM7/c;->j(Z)V

    :cond_e
    return-void
.end method

.method public t()[Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;

    invoke-interface {v0}, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;->getSupportedFeatures()[Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    iget v0, p0, LA/d;->a:I

    packed-switch v0, :pswitch_data_22

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ContentInfoCompat{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v1, Landroid/view/ContentInfo;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_data_22
    .packed-switch 0x11
        :pswitch_a
    .end packed-switch
.end method

.method public u(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, LO4/a;

    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, LC5/o;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public v(Ljava/lang/Throwable;)V
    .registers 4

    iget v0, p0, LA/d;->a:I

    packed-switch v0, :pswitch_data_16

    const-string v0, "ProcessingSurfaceTextur"

    const-string v1, "Failed to extract Listenable<Surface>."

    invoke-static {v0, v1, p1}, LHe/b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void

    :pswitch_d
    iget-object p1, p0, LA/d;->b:Ljava/lang/Object;

    check-cast p1, LC/k0;

    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    return-void

    nop

    :pswitch_data_16
    .packed-switch 0x3
        :pswitch_d
    .end packed-switch
.end method

.method public x(Landroid/view/View;Landroidx/core/view/Q0;)Landroidx/core/view/Q0;
    .registers 19

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->d()I

    move-result v1

    move-object/from16 v2, p0

    iget-object v0, v2, LA/d;->b:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lj/B;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->d()I

    move-result v4

    iget-object v0, v3, Lj/B;->v:Landroidx/appcompat/widget/ActionBarContextView;

    const/4 v5, 0x0

    const/16 v6, 0x8

    if-eqz v0, :cond_16a

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v0, :cond_16a

    iget-object v0, v3, Lj/B;->v:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Landroid/view/ViewGroup$MarginLayoutParams;

    iget-object v0, v3, Lj/B;->v:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    const/4 v8, 0x1

    if-eqz v0, :cond_158

    iget-object v0, v3, Lj/B;->V0:Landroid/graphics/Rect;

    if-nez v0, :cond_45

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, v3, Lj/B;->V0:Landroid/graphics/Rect;

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, v3, Lj/B;->W0:Landroid/graphics/Rect;

    :cond_45
    iget-object v9, v3, Lj/B;->V0:Landroid/graphics/Rect;

    iget-object v0, v3, Lj/B;->W0:Landroid/graphics/Rect;

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->b()I

    move-result v10

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->d()I

    move-result v11

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->c()I

    move-result v12

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->a()I

    move-result v13

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/graphics/Rect;->set(IIII)V

    iget-object v10, v3, Lj/B;->A:Landroid/view/ViewGroup;

    const-class v11, Landroid/graphics/Rect;

    sget v12, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v13, 0x1d

    if-lt v12, v13, :cond_6c

    sget-boolean v11, Landroidx/appcompat/widget/o1;->a:Z

    invoke-static {v10, v9, v0}, Landroidx/appcompat/widget/n1;->a(Landroid/view/View;Landroid/graphics/Rect;Landroid/graphics/Rect;)V

    goto :goto_a5

    :cond_6c
    sget-boolean v12, Landroidx/appcompat/widget/o1;->a:Z

    const-string v13, "ViewUtils"

    if-nez v12, :cond_93

    sput-boolean v8, Landroidx/appcompat/widget/o1;->a:Z

    :try_start_74
    const-class v12, Landroid/view/View;

    const-string v14, "computeFitSystemWindows"

    filled-new-array {v11, v11}, [Ljava/lang/Class;

    move-result-object v11

    invoke-virtual {v12, v14, v11}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v11

    sput-object v11, Landroidx/appcompat/widget/o1;->b:Ljava/lang/reflect/Method;

    invoke-virtual {v11}, Ljava/lang/reflect/AccessibleObject;->isAccessible()Z

    move-result v11

    if-nez v11, :cond_93

    sget-object v11, Landroidx/appcompat/widget/o1;->b:Ljava/lang/reflect/Method;

    invoke-virtual {v11, v8}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_8d
    .catch Ljava/lang/NoSuchMethodException; {:try_start_74 .. :try_end_8d} :catch_8e

    goto :goto_93

    :catch_8e
    const-string v11, "Could not find method computeFitSystemWindows. Oh well."

    invoke-static {v13, v11}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_93
    :goto_93
    sget-object v11, Landroidx/appcompat/widget/o1;->b:Ljava/lang/reflect/Method;

    if-eqz v11, :cond_a5

    :try_start_97
    filled-new-array {v9, v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v11, v10, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_9e
    .catch Ljava/lang/Exception; {:try_start_97 .. :try_end_9e} :catch_9f

    goto :goto_a5

    :catch_9f
    move-exception v0

    const-string v10, "Could not invoke computeFitSystemWindows"

    invoke-static {v13, v10, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_a5
    :goto_a5
    iget v0, v9, Landroid/graphics/Rect;->top:I

    iget v10, v9, Landroid/graphics/Rect;->left:I

    iget v9, v9, Landroid/graphics/Rect;->right:I

    iget-object v11, v3, Lj/B;->A:Landroid/view/ViewGroup;

    sget-object v12, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    invoke-static {v11}, Landroidx/core/view/V;->a(Landroid/view/View;)Landroidx/core/view/Q0;

    move-result-object v11

    if-nez v11, :cond_b7

    move v12, v5

    goto :goto_bb

    :cond_b7
    invoke-virtual {v11}, Landroidx/core/view/Q0;->b()I

    move-result v12

    :goto_bb
    if-nez v11, :cond_bf

    move v11, v5

    goto :goto_c3

    :cond_bf
    invoke-virtual {v11}, Landroidx/core/view/Q0;->c()I

    move-result v11

    :goto_c3
    iget v13, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-ne v13, v0, :cond_d2

    iget v13, v7, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    if-ne v13, v10, :cond_d2

    iget v13, v7, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    if-eq v13, v9, :cond_d0

    goto :goto_d2

    :cond_d0
    move v9, v5

    goto :goto_d9

    :cond_d2
    :goto_d2
    iput v0, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v10, v7, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iput v9, v7, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    move v9, v8

    :goto_d9
    iget-object v10, v3, Lj/B;->k:Landroid/content/Context;

    if-lez v0, :cond_101

    iget-object v0, v3, Lj/B;->C:Landroid/view/View;

    if-nez v0, :cond_101

    new-instance v0, Landroid/view/View;

    invoke-direct {v0, v10}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v0, v3, Lj/B;->C:Landroid/view/View;

    invoke-virtual {v0, v6}, Landroid/view/View;->setVisibility(I)V

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    iget v13, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/16 v14, 0x33

    const/4 v15, -0x1

    invoke-direct {v0, v15, v13, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    iput v12, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput v11, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    iget-object v11, v3, Lj/B;->A:Landroid/view/ViewGroup;

    iget-object v12, v3, Lj/B;->C:Landroid/view/View;

    invoke-virtual {v11, v12, v15, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    goto :goto_124

    :cond_101
    iget-object v0, v3, Lj/B;->C:Landroid/view/View;

    if-eqz v0, :cond_124

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    iget v13, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    iget v14, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-ne v13, v14, :cond_119

    iget v13, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    if-ne v13, v12, :cond_119

    iget v13, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    if-eq v13, v11, :cond_124

    :cond_119
    iput v14, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    iput v12, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iput v11, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    iget-object v11, v3, Lj/B;->C:Landroid/view/View;

    invoke-virtual {v11, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_124
    :goto_124
    iget-object v0, v3, Lj/B;->C:Landroid/view/View;

    if-eqz v0, :cond_129

    goto :goto_12a

    :cond_129
    move v8, v5

    :goto_12a
    if-eqz v8, :cond_14e

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_14e

    iget-object v0, v3, Lj/B;->C:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWindowSystemUiVisibility()I

    move-result v11

    and-int/lit16 v11, v11, 0x2000

    if-eqz v11, :cond_144

    const v11, 0x7f060006

    invoke-static {v10, v11}, Le0/b;->a(Landroid/content/Context;I)I

    move-result v10

    goto :goto_14b

    :cond_144
    const v11, 0x7f060005

    invoke-static {v10, v11}, Le0/b;->a(Landroid/content/Context;I)I

    move-result v10

    :goto_14b
    invoke-virtual {v0, v10}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_14e
    iget-boolean v0, v3, Lj/B;->H:Z

    if-nez v0, :cond_155

    if-eqz v8, :cond_155

    move v4, v5

    :cond_155
    move v0, v8

    move v8, v9

    goto :goto_162

    :cond_158
    iget v0, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-eqz v0, :cond_160

    iput v5, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    move v0, v5

    goto :goto_162

    :cond_160
    move v0, v5

    move v8, v0

    :goto_162
    if-eqz v8, :cond_16b

    iget-object v8, v3, Lj/B;->v:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v8, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_16b

    :cond_16a
    move v0, v5

    :cond_16b
    :goto_16b
    iget-object v3, v3, Lj/B;->C:Landroid/view/View;

    if-eqz v3, :cond_176

    if-eqz v0, :cond_172

    goto :goto_173

    :cond_172
    move v5, v6

    :goto_173
    invoke-virtual {v3, v5}, Landroid/view/View;->setVisibility(I)V

    :cond_176
    if-eq v1, v4, :cond_18d

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->b()I

    move-result v0

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->c()I

    move-result v1

    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/Q0;->a()I

    move-result v3

    move-object/from16 v5, p2

    invoke-virtual {v5, v0, v4, v1, v3}, Landroidx/core/view/Q0;->f(IIII)Landroidx/core/view/Q0;

    move-result-object v0

    move-object/from16 v1, p1

    goto :goto_192

    :cond_18d
    move-object/from16 v5, p2

    move-object/from16 v1, p1

    move-object v0, v5

    :goto_192
    invoke-static {v1, v0}, Landroidx/core/view/g0;->i(Landroid/view/View;Landroidx/core/view/Q0;)Landroidx/core/view/Q0;

    move-result-object v0

    return-object v0
.end method

.method public y(Lio/sentry/G;Lio/sentry/M1;)Lio/sentry/U0;
    .registers 12

    const-string v0, "Hub is required"

    invoke-static {p1, v0}, Lio/sentry/config/b;->b(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "SentryOptions is required"

    invoke-static {p2, v0}, Lio/sentry/config/b;->b(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/T0;

    invoke-interface {v0}, Lio/sentry/T0;->b()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_45

    invoke-virtual {p2}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object v1

    invoke-static {v0, v1}, Lio/sentry/V0;->B(Ljava/lang/String;Lio/sentry/ILogger;)Z

    move-result v1

    if-nez v1, :cond_1f

    goto :goto_45

    :cond_1f
    new-instance v1, Lio/sentry/q;

    invoke-virtual {p2}, Lio/sentry/M1;->getSerializer()Lio/sentry/O;

    move-result-object v4

    invoke-virtual {p2}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object v5

    invoke-virtual {p2}, Lio/sentry/M1;->getFlushTimeoutMillis()J

    move-result-wide v6

    invoke-virtual {p2}, Lio/sentry/M1;->getMaxQueueSize()I

    move-result v8

    move-object v2, v1

    move-object v3, p1

    invoke-direct/range {v2 .. v8}, Lio/sentry/q;-><init>(Lio/sentry/G;Lio/sentry/O;Lio/sentry/ILogger;JI)V

    invoke-virtual {p2}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object p1

    new-instance p2, Ljava/io/File;

    invoke-direct {p2, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    new-instance v2, Lio/sentry/U0;

    invoke-direct {v2, p1, v0, v1, p2}, Lio/sentry/U0;-><init>(Lio/sentry/ILogger;Ljava/lang/String;Lio/sentry/n;Ljava/io/File;)V

    return-object v2

    :cond_45
    :goto_45
    invoke-virtual {p2}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object p1

    sget-object p2, Lio/sentry/y1;->ERROR:Lio/sentry/y1;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "No cache dir path is defined in options."

    invoke-interface {p1, p2, v1, v0}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public z()I
    .registers 2

    iget-object v0, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    invoke-static {v0}, LHa/i;->b(Landroid/view/ContentInfo;)I

    move-result v0

    return v0
.end method

.method public zza()Ll7/r7;
    .registers 5

    new-instance v0, Ll4/q;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, LU8/b;->c()Z

    move-result v1

    if-eqz v1, :cond_e

    sget-object v1, Ll7/t5;->c:Ll7/t5;

    goto :goto_10

    :cond_e
    sget-object v1, Ll7/t5;->b:Ll7/t5;

    :goto_10
    iput-object v1, v0, Ll4/q;->c:Ljava/lang/Object;

    new-instance v1, LA0/x;

    const/16 v2, 0x19

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3}, LA0/x;-><init>(IZ)V

    iget-object v2, p0, LA/d;->b:Ljava/lang/Object;

    check-cast v2, Ll7/u5;

    iput-object v2, v1, LA0/x;->b:Ljava/lang/Object;

    new-instance v2, Ll7/H5;

    invoke-direct {v2, v1}, Ll7/H5;-><init>(LA0/x;)V

    iput-object v2, v0, Ll4/q;->e:Ljava/lang/Object;

    new-instance v1, Ll7/r7;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Ll7/r7;-><init>(Ll4/q;I)V

    return-object v1
.end method
