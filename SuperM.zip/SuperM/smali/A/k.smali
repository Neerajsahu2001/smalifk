.class public final LA/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Ljava/lang/Object;

.field public final c:Ln8/r;

.field public d:Landroidx/concurrent/futures/k;

.field public e:Z

.field public final f:LA/j;


# direct methods
.method public constructor <init>(LI6/l;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LA/k;->b:Ljava/lang/Object;

    new-instance v0, LA/j;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p0}, LA/j;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, LA/k;->f:LA/j;

    const-class v0, Lz/g;

    invoke-virtual {p1, v0}, LI6/l;->t(Ljava/lang/Class;)Z

    move-result p1

    iput-boolean p1, p0, LA/k;->a:Z

    if-eqz p1, :cond_29

    new-instance p1, LA/h;

    const/4 v0, 0x0

    invoke-direct {p1, v0, p0}, LA/h;-><init>(ILjava/lang/Object;)V

    invoke-static {p1}, Lm7/U3;->a(Landroidx/concurrent/futures/l;)Landroidx/concurrent/futures/n;

    move-result-object p1

    iput-object p1, p0, LA/k;->c:Ln8/r;

    goto :goto_2d

    :cond_29
    sget-object p1, LG/j;->b:LG/j;

    iput-object p1, p0, LA/k;->c:Ln8/r;

    :goto_2d
    return-void
.end method

.method public static a(Landroid/hardware/camera2/CameraDevice;Ly/l;Ljava/util/List;Ljava/util/ArrayList;LI1/a;)LG/e;
    .registers 8

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_9
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1d

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lw/e0;

    invoke-virtual {v1}, Lw/e0;->k()Ln8/r;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_9

    :cond_1d
    new-instance p3, LG/n;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v0

    const/4 v2, 0x0

    invoke-direct {p3, v1, v2, v0}, LG/n;-><init>(Ljava/util/ArrayList;ZLF/a;)V

    invoke-static {p3}, LG/e;->a(Ln8/r;)LG/e;

    move-result-object p3

    new-instance v0, LA/i;

    invoke-direct {v0, p4, p0, p1, p2}, LA/i;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object p0

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p3, v0, p0}, LG/g;->h(Ln8/r;LG/a;Ljava/util/concurrent/Executor;)LG/c;

    move-result-object p0

    return-object p0
.end method
