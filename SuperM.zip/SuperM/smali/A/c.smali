.class public final LA/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:Z


# direct methods
.method public constructor <init>(LI6/l;LI6/l;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-class v0, Lz/A;

    invoke-virtual {p2, v0}, LI6/l;->t(Ljava/lang/Class;)Z

    move-result p2

    iput-boolean p2, p0, LA/c;->a:Z

    const-class p2, Lz/w;

    invoke-virtual {p1, p2}, LI6/l;->t(Ljava/lang/Class;)Z

    move-result p2

    iput-boolean p2, p0, LA/c;->b:Z

    const-class p2, Lz/h;

    invoke-virtual {p1, p2}, LI6/l;->t(Ljava/lang/Class;)Z

    move-result p1

    iput-boolean p1, p0, LA/c;->c:Z

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;)V
    .registers 3

    iget-boolean v0, p0, LA/c;->a:Z

    if-nez v0, :cond_c

    iget-boolean v0, p0, LA/c;->b:Z

    if-nez v0, :cond_c

    iget-boolean v0, p0, LA/c;->c:Z

    if-eqz v0, :cond_29

    :cond_c
    if-eqz p1, :cond_29

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_12
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_22

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LD/F;

    invoke-virtual {v0}, LD/F;->a()V

    goto :goto_12

    :cond_22
    const-string p1, "ForceCloseDeferrableSurface"

    const-string v0, "deferrableSurface closed"

    invoke-static {p1, v0}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_29
    return-void
.end method
