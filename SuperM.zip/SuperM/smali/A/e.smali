.class public final LA/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z


# direct methods
.method public constructor <init>(I)V
    .registers 3

    packed-switch p1, :pswitch_data_2c

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object p1, Lz/j;->a:LI6/l;

    const-class v0, Lz/z;

    invoke-virtual {p1, v0}, LI6/l;->u(Ljava/lang/Class;)LD/f0;

    move-result-object p1

    check-cast p1, Lz/z;

    if-eqz p1, :cond_14

    const/4 p1, 0x1

    goto :goto_15

    :cond_14
    const/4 p1, 0x0

    :goto_15
    iput-boolean p1, p0, LA/e;->a:Z

    return-void

    :pswitch_18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object p1, LJ/a;->a:LI6/l;

    const-class v0, LJ/d;

    invoke-virtual {p1, v0}, LI6/l;->u(Ljava/lang/Class;)LD/f0;

    move-result-object p1

    if-eqz p1, :cond_27

    const/4 p1, 0x1

    goto :goto_28

    :cond_27
    const/4 p1, 0x0

    :goto_28
    iput-boolean p1, p0, LA/e;->a:Z

    return-void

    nop

    :pswitch_data_2c
    .packed-switch 0x2
        :pswitch_18
    .end packed-switch
.end method


# virtual methods
.method public a(Landroid/content/Context;Z)V
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "disableTracking context: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " disableTracking: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, " callback: null"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ll7/R5;->i(Ljava/lang/String;)V

    iget-boolean v0, p0, LA/e;->a:Z

    if-ne v0, p2, :cond_23

    return-void

    :cond_23
    iput-boolean p2, p0, LA/e;->a:Z

    invoke-static {p1}, Ljc/v;->f(Landroid/content/Context;)Ljc/v;

    move-result-object v0

    iget-object v0, v0, Ljc/v;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences$Editor;

    const-string v1, "bnc_tracking_state"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-eqz p2, :cond_a7

    const-string p2, "Tracking disabled. Clearing all pending requests"

    invoke-static {p2}, Ll7/R5;->i(Ljava/lang/String;)V

    invoke-static {}, Ljc/m;->i()Ljc/m;

    move-result-object p2

    iget-object p2, p2, Ljc/m;->f:Ljc/E;

    invoke-virtual {p2}, Ljc/E;->c()V

    invoke-static {p1}, Ljc/v;->f(Landroid/content/Context;)Ljc/v;

    move-result-object p1

    const-string p2, "bnc_session_id"

    const-string v0, "bnc_no_value"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljc/v;->p(Ljava/lang/String;)V

    const-string p2, "bnc_link_click_identifier"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    const-string p2, "bnc_app_link"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    const-string p2, "bnc_install_referrer"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    const-string p2, "bnc_google_play_install_referrer_extras"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_73

    const-string p2, "bnc_app_store_source"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    :cond_73
    const-string p2, "bnc_google_search_install_identifier"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    const-string p2, "bnc_initial_referrer"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    const-string p2, "bnc_external_intent_uri"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    const-string p2, "bnc_external_intent_extra"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljc/v;->s(Ljava/lang/String;)V

    const-string p2, "bnc_anon_id"

    invoke-virtual {p1, p2, v0}, Ljc/v;->t(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {p1, p2}, Ljc/v;->r(Lorg/json/JSONObject;)V

    invoke-static {}, Ljc/m;->i()Ljc/m;

    move-result-object p1

    iget-object p1, p1, Ljc/m;->b:Ljc/v;

    iget-object p1, p1, Ljc/v;->e:Ljava/lang/Object;

    check-cast p1, Ljc/q;

    iget-object p1, p1, Ljc/q;->a:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p1}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    goto :goto_d3

    :cond_a7
    const-string p1, "Tracking enabled. Registering app init"

    invoke-static {p1}, Ll7/R5;->i(Ljava/lang/String;)V

    new-instance p1, LE5/b;

    const/16 p2, 0xc

    invoke-direct {p1, p2}, LE5/b;-><init>(I)V

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "onTrackingEnabled callback: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Ll7/R5;->i(Ljava/lang/String;)V

    invoke-static {}, Ljc/m;->i()Ljc/m;

    move-result-object p2

    if-eqz p2, :cond_d3

    const/4 v0, 0x1

    invoke-virtual {p2, p1, v0}, Ljc/m;->h(Ljc/i;Z)Ljc/B;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {p2, p1, v0}, Ljc/m;->o(Ljc/B;Z)V

    :cond_d3
    :goto_d3
    return-void
.end method

.method public b(Ljava/util/ArrayList;Z)Z
    .registers 5

    iget-boolean v0, p0, LA/e;->a:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_2c

    if-nez p2, :cond_8

    goto :goto_2c

    :cond_8
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_c
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_2c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/hardware/camera2/CaptureRequest;

    sget-object v0, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {p2, v0}, Landroid/hardware/camera2/CaptureRequest;->get(Landroid/hardware/camera2/CaptureRequest$Key;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v0, 0x2

    if-eq p2, v0, :cond_2a

    const/4 v0, 0x3

    if-ne p2, v0, :cond_c

    :cond_2a
    const/4 p1, 0x1

    return p1

    :cond_2c
    :goto_2c
    return v1
.end method
