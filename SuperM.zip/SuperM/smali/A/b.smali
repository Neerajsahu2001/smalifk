.class public final LA/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Z


# direct methods
.method public constructor <init>(LI6/l;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-class v0, Lz/p;

    invoke-virtual {p1, v0}, LI6/l;->t(Ljava/lang/Class;)Z

    move-result p1

    iput-boolean p1, p0, LA/b;->a:Z

    sget-object p1, Lz/j;->a:LI6/l;

    const-class v0, Lz/i;

    invoke-virtual {p1, v0}, LI6/l;->u(Ljava/lang/Class;)LD/f0;

    move-result-object p1

    if-eqz p1, :cond_17

    const/4 p1, 0x1

    goto :goto_18

    :cond_17
    const/4 p1, 0x0

    :goto_18
    iput-boolean p1, p0, LA/b;->b:Z

    return-void
.end method

.method public constructor <init>(ZZZ)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p2, p0, LA/b;->a:Z

    iput-boolean p3, p0, LA/b;->b:Z

    return-void
.end method
