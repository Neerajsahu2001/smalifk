.class public LA/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z


# direct methods
.method public constructor <init>(I)V
    .registers 3

    packed-switch p1, :pswitch_data_1e

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object p1, Lz/j;->a:LI6/l;

    const-class v0, Lz/B;

    invoke-virtual {p1, v0}, LI6/l;->u(Ljava/lang/Class;)LD/f0;

    move-result-object p1

    if-eqz p1, :cond_12

    const/4 p1, 0x1

    goto :goto_13

    :cond_12
    const/4 p1, 0x0

    :goto_13
    iput-boolean p1, p0, LA/g;->a:Z

    return-void

    :pswitch_16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, LA/g;->a:Z

    return-void

    nop

    :pswitch_data_1e
    .packed-switch 0x2
        :pswitch_16
    .end packed-switch
.end method

.method public constructor <init>(Z)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, LA/g;->a:Z

    return-void
.end method

.method public static a(LD/x;)LD/x;
    .registers 5

    new-instance v0, LD/w;

    invoke-direct {v0}, LD/w;-><init>()V

    iget v1, p0, LD/x;->c:I

    iput v1, v0, LD/w;->c:I

    iget-object v1, p0, LD/x;->a:Ljava/util/List;

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_25

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LD/F;

    iget-object v3, v0, LD/w;->a:Ljava/util/HashSet;

    invoke-virtual {v3, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_13

    :cond_25
    iget-object p0, p0, LD/x;->b:LD/B;

    invoke-virtual {v0, p0}, LD/w;->c(LD/B;)V

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object p0

    sget-object v1, Landroid/hardware/camera2/CaptureRequest;->FLASH_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1}, Lv/a;->a0(Landroid/hardware/camera2/CaptureRequest$Key;)LD/c;

    move-result-object v1

    invoke-virtual {p0, v1, v2}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    new-instance v1, Lv/a;

    invoke-static {p0}, LD/c0;->c(LD/B;)LD/c0;

    move-result-object p0

    const/4 v2, 0x1

    invoke-direct {v1, v2, p0}, LA/d;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, v1}, LD/w;->c(LD/B;)V

    invoke-virtual {v0}, LD/w;->d()LD/x;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public b(Ljava/util/ArrayList;Z)Z
    .registers 4

    iget-boolean v0, p0, LA/g;->a:Z

    if-eqz v0, :cond_29

    if-eqz p2, :cond_29

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_a
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_29

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/hardware/camera2/CaptureRequest;

    sget-object v0, Landroid/hardware/camera2/CaptureRequest;->FLASH_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {p2, v0}, Landroid/hardware/camera2/CaptureRequest;->get(Landroid/hardware/camera2/CaptureRequest$Key;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    if-eqz p2, :cond_a

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v0, 0x2

    if-ne p2, v0, :cond_a

    const/4 p1, 0x1

    return p1

    :cond_29
    const/4 p1, 0x0

    return p1
.end method
