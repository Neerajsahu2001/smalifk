.class public final synthetic LA/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/a;
.implements Lv7/d;
.implements Landroidx/concurrent/futures/l;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    iput-object p1, p0, LA/i;->a:Ljava/lang/Object;

    iput-object p2, p0, LA/i;->b:Ljava/lang/Object;

    iput-object p3, p0, LA/i;->c:Ljava/lang/Object;

    iput-object p4, p0, LA/i;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lw/e0;Ljava/util/List;Ll4/p;Ly/l;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/i;->a:Ljava/lang/Object;

    iput-object p2, p0, LA/i;->d:Ljava/lang/Object;

    iput-object p3, p0, LA/i;->b:Ljava/lang/Object;

    iput-object p4, p0, LA/i;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ln8/r;
    .registers 5

    check-cast p1, Ljava/util/List;

    iget-object p1, p0, LA/i;->a:Ljava/lang/Object;

    check-cast p1, LI1/a;

    iget-object p1, p1, LI1/a;->b:Ljava/lang/Object;

    check-cast p1, Lw/f0;

    iget-object v0, p0, LA/i;->c:Ljava/lang/Object;

    check-cast v0, Ly/l;

    iget-object v1, p0, LA/i;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    iget-object v2, p0, LA/i;->b:Ljava/lang/Object;

    check-cast v2, Landroid/hardware/camera2/CameraDevice;

    invoke-static {p1, v2, v0, v1}, Lw/f0;->t(Lw/f0;Landroid/hardware/camera2/CameraDevice;Ly/l;Ljava/util/List;)Ln8/r;

    move-result-object p1

    return-object p1
.end method

.method public n(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .registers 13

    iget-object v0, p0, LA/i;->a:Ljava/lang/Object;

    check-cast v0, Lw/e0;

    iget-object v1, p0, LA/i;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    iget-object v2, p0, LA/i;->b:Ljava/lang/Object;

    check-cast v2, Ll4/p;

    iget-object v3, p0, LA/i;->c:Ljava/lang/Object;

    check-cast v3, Ly/l;

    const-string v4, "openCaptureSession[session="

    iget-object v5, v0, Lw/e0;->a:Ljava/lang/Object;

    monitor-enter v5

    :try_start_15
    iget-object v6, v0, Lw/e0;->a:Ljava/lang/Object;

    monitor-enter v6
    :try_end_18
    .catchall {:try_start_15 .. :try_end_18} :catchall_70

    :try_start_18
    invoke-virtual {v0}, Lw/e0;->m()V

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v7
    :try_end_1f
    .catchall {:try_start_18 .. :try_end_1f} :catchall_72

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v7, :cond_47

    move v7, v8

    :cond_24
    :try_start_24
    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LD/F;

    invoke-virtual {v10}, LD/F;->d()V

    add-int/lit8 v7, v7, 0x1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v10
    :try_end_33
    .catch LD/D; {:try_start_24 .. :try_end_33} :catch_36
    .catchall {:try_start_24 .. :try_end_33} :catchall_72

    if-lt v7, v10, :cond_24

    goto :goto_47

    :catch_36
    move-exception p1

    sub-int/2addr v7, v9

    :goto_38
    if-ltz v7, :cond_46

    :try_start_3a
    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LD/F;

    invoke-virtual {v0}, LD/F;->b()V

    add-int/lit8 v7, v7, -0x1

    goto :goto_38

    :cond_46
    throw p1

    :cond_47
    :goto_47
    iput-object v1, v0, Lw/e0;->k:Ljava/util/List;

    monitor-exit v6
    :try_end_4a
    .catchall {:try_start_3a .. :try_end_4a} :catchall_72

    :try_start_4a
    iget-object v1, v0, Lw/e0;->i:Landroidx/concurrent/futures/k;

    if-nez v1, :cond_4f

    move v8, v9

    :cond_4f
    const-string v1, "The openCaptureSessionCompleter can only set once!"

    invoke-static {v8, v1}, Ll7/C5;->f(ZLjava/lang/String;)V

    iput-object p1, v0, Lw/e0;->i:Landroidx/concurrent/futures/k;

    iget-object p1, v2, Ll4/p;->a:Ljava/lang/Object;

    check-cast p1, Lx/p;

    invoke-virtual {p1, v3}, Lx/p;->a(Ly/l;)V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "]"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    monitor-exit v5
    :try_end_6f
    .catchall {:try_start_4a .. :try_end_6f} :catchall_70

    return-object p1

    :catchall_70
    move-exception p1

    goto :goto_75

    :catchall_72
    move-exception p1

    :try_start_73
    monitor-exit v6
    :try_end_74
    .catchall {:try_start_73 .. :try_end_74} :catchall_72

    :try_start_74
    throw p1

    :goto_75
    monitor-exit v5
    :try_end_76
    .catchall {:try_start_74 .. :try_end_76} :catchall_70

    throw p1
.end method

.method public onComplete(Lv7/i;)V
    .registers 6

    iget-object v0, p0, LA/i;->a:Ljava/lang/Object;

    check-cast v0, Lf8/b;

    const-string v1, "$reviewManager"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LA/i;->b:Ljava/lang/Object;

    check-cast v1, Landroid/app/Activity;

    const-string v2, "$activity"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "it"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v2

    iget-object v3, p0, LA/i;->c:Ljava/lang/Object;

    check-cast v3, LHc/b;

    if-eqz v2, :cond_47

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/google/android/play/core/review/ReviewInfo;

    invoke-interface {v0, v1, p1}, Lf8/b;->a(Landroid/app/Activity;Lcom/google/android/play/core/review/ReviewInfo;)Lv7/v;

    move-result-object p1

    const-string v0, "launchReviewFlow(...)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/supermoney/payments/camera/b;

    iget-object v1, p0, LA/i;->d:Ljava/lang/Object;

    check-cast v1, LHc/b;

    invoke-direct {v0, v1}, Lcom/supermoney/payments/camera/b;-><init>(LHc/b;)V

    invoke-virtual {p1, v0}, Lv7/v;->c(Lv7/d;)Lv7/v;

    new-instance v0, LB/a;

    const/16 v1, 0x12

    invoke-direct {v0, v1, v3}, LB/a;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p1, v0}, Lv7/v;->e(Lv7/e;)Lv7/v;

    goto :goto_73

    :cond_47
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object v0

    if-eqz v0, :cond_52

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    goto :goto_53

    :cond_52
    const/4 v0, 0x0

    :goto_53
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object v1

    instance-of v1, v1, Lf8/a;

    if-eqz v1, :cond_6e

    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    const-string v0, "null cannot be cast to non-null type com.google.android.play.core.review.ReviewException"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lf8/a;

    iget-object p1, p1, LM6/d;->a:Lcom/google/android/gms/common/api/Status;

    iget p1, p1, Lcom/google/android/gms/common/api/Status;->a:I

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    :cond_6e
    if-eqz v3, :cond_73

    invoke-interface {v3, v0}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_73
    :goto_73
    return-void
.end method

.method public unwrap(Lcom/facebook/react/runtime/internal/bolts/Task;Ljava/lang/String;)Lcom/facebook/react/runtime/ReactInstance;
    .registers 10

    iget-object v0, p0, LA/i;->a:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lcom/facebook/react/runtime/ReactHostImpl;

    iget-object v0, p0, LA/i;->b:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    iget-object v0, p0, LA/i;->c:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Ljava/lang/String;

    iget-object v0, p0, LA/i;->d:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Ljava/lang/String;

    move-object v5, p1

    move-object v6, p2

    invoke-static/range {v1 .. v6}, Lcom/facebook/react/runtime/ReactHostImpl;->f(Lcom/facebook/react/runtime/ReactHostImpl;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/react/runtime/internal/bolts/Task;Ljava/lang/String;)Lcom/facebook/react/runtime/ReactInstance;

    move-result-object p1

    return-object p1
.end method
