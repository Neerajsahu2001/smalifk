.class public final LA/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:Landroid/util/Size;

.field public static final c:LE/d;


# instance fields
.field public final a:Lz/y;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Landroid/util/Size;

    const/16 v1, 0x140

    const/16 v2, 0xf0

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    sput-object v0, LA/f;->b:Landroid/util/Size;

    new-instance v0, LE/d;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LE/d;-><init>(Z)V

    sput-object v0, LA/f;->c:LE/d;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lz/j;->a:LI6/l;

    const-class v1, Lz/y;

    invoke-virtual {v0, v1}, LI6/l;->u(Ljava/lang/Class;)LD/f0;

    move-result-object v0

    check-cast v0, Lz/y;

    iput-object v0, p0, LA/f;->a:Lz/y;

    return-void
.end method
