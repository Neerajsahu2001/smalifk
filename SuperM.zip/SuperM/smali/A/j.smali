.class public final LA/j;
.super Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LA/j;->a:I

    iput-object p2, p0, LA/j;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onCaptureCompleted(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/TotalCaptureResult;)V
    .registers 5

    iget v0, p0, LA/j;->a:I

    packed-switch v0, :pswitch_data_3e

    invoke-super {p0, p1, p2, p3}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureCompleted(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/TotalCaptureResult;)V

    return-void

    :pswitch_9
    iget-object p1, p0, LA/j;->b:Ljava/lang/Object;

    check-cast p1, Lw/K;

    iget-object p1, p1, Lw/K;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_10
    iget-object p2, p0, LA/j;->b:Ljava/lang/Object;

    check-cast p2, Lw/K;

    iget-object p2, p2, Lw/K;->g:LD/n0;

    if-nez p2, :cond_1c

    monitor-exit p1

    goto :goto_3a

    :catchall_1a
    move-exception p2

    goto :goto_3b

    :cond_1c
    iget-object p2, p2, LD/n0;->f:LD/x;

    const-string p3, "CaptureSession"

    const-string v0, "Submit FLASH_MODE_OFF request"

    invoke-static {p3, v0}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p3, p0, LA/j;->b:Ljava/lang/Object;

    check-cast p3, Lw/K;

    iget-object v0, p3, Lw/K;->p:LA/g;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p2}, LA/g;->a(LD/x;)LD/x;

    move-result-object p2

    invoke-static {p2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    invoke-virtual {p3, p2}, Lw/K;->f(Ljava/util/List;)V

    monitor-exit p1

    :goto_3a
    return-void

    :goto_3b
    monitor-exit p1
    :try_end_3c
    .catchall {:try_start_10 .. :try_end_3c} :catchall_1a

    throw p2

    nop

    :pswitch_data_3e
    .packed-switch 0x1
        :pswitch_9
    .end packed-switch
.end method

.method public onCaptureSequenceAborted(Landroid/hardware/camera2/CameraCaptureSession;I)V
    .registers 6

    iget v0, p0, LA/j;->a:I

    packed-switch v0, :pswitch_data_2a

    invoke-super {p0, p1, p2}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureSequenceAborted(Landroid/hardware/camera2/CameraCaptureSession;I)V

    return-void

    :pswitch_9
    iget-object p1, p0, LA/j;->b:Ljava/lang/Object;

    check-cast p1, LA/k;

    iget-object p2, p1, LA/k;->d:Landroidx/concurrent/futures/k;

    if-eqz p2, :cond_29

    const/4 v0, 0x1

    iput-boolean v0, p2, Landroidx/concurrent/futures/k;->d:Z

    iget-object v1, p2, Landroidx/concurrent/futures/k;->b:Landroidx/concurrent/futures/n;

    const/4 v2, 0x0

    if-eqz v1, :cond_27

    iget-object v1, v1, Landroidx/concurrent/futures/n;->b:Landroidx/concurrent/futures/m;

    invoke-virtual {v1, v0}, Landroidx/concurrent/futures/j;->cancel(Z)Z

    move-result v0

    if-eqz v0, :cond_27

    iput-object v2, p2, Landroidx/concurrent/futures/k;->a:Ljava/lang/Object;

    iput-object v2, p2, Landroidx/concurrent/futures/k;->b:Landroidx/concurrent/futures/n;

    iput-object v2, p2, Landroidx/concurrent/futures/k;->c:Landroidx/concurrent/futures/p;

    :cond_27
    iput-object v2, p1, LA/k;->d:Landroidx/concurrent/futures/k;

    :cond_29
    return-void

    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_9
    .end packed-switch
.end method

.method public onCaptureStarted(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;JJ)V
    .registers 8

    iget v0, p0, LA/j;->a:I

    packed-switch v0, :pswitch_data_18

    invoke-super/range {p0 .. p6}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureStarted(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;JJ)V

    return-void

    :pswitch_9
    iget-object p1, p0, LA/j;->b:Ljava/lang/Object;

    check-cast p1, LA/k;

    iget-object p2, p1, LA/k;->d:Landroidx/concurrent/futures/k;

    if-eqz p2, :cond_17

    const/4 p3, 0x0

    invoke-virtual {p2, p3}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    iput-object p3, p1, LA/k;->d:Landroidx/concurrent/futures/k;

    :cond_17
    return-void

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_9
    .end packed-switch
.end method
