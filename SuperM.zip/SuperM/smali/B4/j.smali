.class public final synthetic Lb4/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lb4/A;LY3/j;Lb4/A;Landroid/app/Activity;)V
    .registers 6

    const/4 v0, 0x0

    iput v0, p0, Lb4/j;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/j;->b:Ljava/lang/Object;

    iput-object p2, p0, Lb4/j;->d:Ljava/lang/Object;

    iput-object p3, p0, Lb4/j;->c:Ljava/lang/Object;

    iput-object p4, p0, Lb4/j;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 6

    iput p5, p0, Lb4/j;->a:I

    iput-object p1, p0, Lb4/j;->b:Ljava/lang/Object;

    iput-object p2, p0, Lb4/j;->c:Ljava/lang/Object;

    iput-object p3, p0, Lb4/j;->d:Ljava/lang/Object;

    iput-object p4, p0, Lb4/j;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 15

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object v2, p0, Lb4/j;->e:Ljava/lang/Object;

    iget-object v3, p0, Lb4/j;->d:Ljava/lang/Object;

    iget-object v4, p0, Lb4/j;->c:Ljava/lang/Object;

    iget-object v5, p0, Lb4/j;->b:Ljava/lang/Object;

    iget v6, p0, Lb4/j;->a:I

    packed-switch v6, :pswitch_data_13e

    check-cast v5, Lw/j;

    iget-object v0, v5, Lw/j;->c:Ljava/lang/Object;

    check-cast v0, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    check-cast v4, Landroid/hardware/camera2/CameraCaptureSession;

    check-cast v3, Landroid/hardware/camera2/CaptureRequest;

    check-cast v2, Landroid/hardware/camera2/CaptureFailure;

    invoke-virtual {v0, v4, v3, v2}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureFailed(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CaptureFailure;)V

    return-void

    :pswitch_1f
    check-cast v5, Lw/s;

    iget-object v6, v5, Lw/s;->o:Ljava/util/HashSet;

    check-cast v4, Lw/K;

    invoke-virtual {v6, v4}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v5, v4}, Lw/s;->p(Lw/K;)Ln8/r;

    move-result-object v4

    check-cast v3, LD/F;

    invoke-virtual {v3}, LD/F;->a()V

    iget-object v3, v3, LD/F;->e:Landroidx/concurrent/futures/n;

    invoke-static {v3}, LG/g;->f(Ln8/r;)Ln8/r;

    move-result-object v3

    const/4 v5, 0x2

    new-array v5, v5, [Ln8/r;

    aput-object v4, v5, v1

    aput-object v3, v5, v0

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v3, LG/n;

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v0

    invoke-direct {v3, v4, v1, v0}, LG/n;-><init>(Ljava/util/ArrayList;ZLF/a;)V

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v0

    check-cast v2, Ljava/lang/Runnable;

    invoke-virtual {v3, v2, v0}, LG/n;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void

    :pswitch_5a
    check-cast v5, Ll7/r7;

    iget v0, v5, Ll7/r7;->a:I

    iget-object v1, v5, Ll7/r7;->b:Ljava/lang/Object;

    check-cast v1, Lt1/E;

    check-cast v4, Lt1/J;

    check-cast v3, Lt1/v;

    check-cast v2, Lt1/A;

    invoke-interface {v4, v0, v1, v3, v2}, Lt1/J;->t(ILt1/E;Lt1/v;Lt1/A;)V

    return-void

    :pswitch_6c
    check-cast v3, Lcom/facebook/react/uimanager/ViewGroupManager;

    check-cast v2, Landroid/view/ViewGroup;

    check-cast v5, Ljava/util/ArrayList;

    check-cast v4, Landroid/view/View;

    invoke-static {v5, v4, v3, v2}, Lcom/swmansion/reanimated/layoutReanimation/ReanimatedNativeHierarchyManager;->b(Ljava/util/ArrayList;Landroid/view/View;Lcom/facebook/react/uimanager/ViewGroupManager;Landroid/view/ViewGroup;)V

    return-void

    :pswitch_78
    check-cast v4, Lb4/A;

    move-object v9, v2

    check-cast v9, Landroid/app/Activity;

    check-cast v5, Lb4/A;

    iget-boolean v2, v5, Lb4/A;->k1:Z

    move-object v8, v3

    check-cast v8, LY3/j;

    if-eqz v2, :cond_8c

    iget-object v2, v5, Lb4/A;->P:LY3/j;

    if-ne v8, v2, :cond_8c

    goto/16 :goto_13d

    :cond_8c
    :try_start_8c
    iget-object v2, v8, LY3/j;->b:Landroid/net/Uri;

    if-nez v2, :cond_92

    goto/16 :goto_13d

    :cond_92
    iget-object v2, v5, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    if-nez v2, :cond_9d

    invoke-virtual {v5, v4}, Lb4/A;->W(Lb4/A;)V

    goto :goto_9d

    :catch_9a
    move-exception v1

    goto/16 :goto_11d

    :cond_9d
    :goto_9d
    iget-object v2, v5, Lb4/A;->P:LY3/j;

    iget-boolean v3, v2, LY3/j;->c:Z

    if-nez v3, :cond_e8

    iget-boolean v3, v2, LY3/j;->d:Z

    if-nez v3, :cond_e8

    iget-object v2, v2, LY3/j;->p:LY3/b;

    iget v2, v2, LY3/b;->a:I

    if-lez v2, :cond_e8

    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, v5, Lb4/A;->P:LY3/j;

    iget-object v2, v2, LY3/j;->p:LY3/b;

    iget v2, v2, LY3/b;->a:I

    const-string v3, "context"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v3, Lm7/U2;->a:Ld1/u;

    if-nez v3, :cond_e5

    if-gtz v2, :cond_c3

    goto :goto_e5

    :cond_c3
    new-instance v3, Ld1/u;

    new-instance v6, Ljava/io/File;

    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v7

    const-string v10, "RNVCache"

    invoke-direct {v6, v7, v10}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v7, Ld1/r;

    int-to-long v10, v2

    const/16 v2, 0x400

    int-to-long v12, v2

    mul-long/2addr v10, v12

    mul-long/2addr v10, v12

    invoke-direct {v7, v10, v11}, Ld1/r;-><init>(J)V

    new-instance v2, Landroidx/media3/database/StandaloneDatabaseProvider;

    invoke-direct {v2, v1}, Landroidx/media3/database/StandaloneDatabaseProvider;-><init>(Landroid/content/Context;)V

    invoke-direct {v3, v6, v7, v2}, Ld1/u;-><init>(Ljava/io/File;Ld1/r;Landroidx/media3/database/StandaloneDatabaseProvider;)V

    sput-object v3, Lm7/U2;->a:Ld1/u;

    :cond_e5
    :goto_e5
    iput-boolean v0, v5, Lb4/A;->K:Z

    goto :goto_ea

    :cond_e8
    iput-boolean v1, v5, Lb4/A;->K:Z

    :goto_ea
    iget-boolean v1, v5, Lb4/A;->l:Z

    if-eqz v1, :cond_115

    iget-object v1, v5, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v1}, Lcom/brentvatne/exoplayer/ExoPlayerView;->d()V

    iget-object v1, v5, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    iget-object v1, v1, Lcom/brentvatne/exoplayer/ExoPlayerView;->e:Lcom/brentvatne/exoplayer/AspectRatioFrameLayout;

    iget v2, v1, Lcom/brentvatne/exoplayer/AspectRatioFrameLayout;->a:F

    const/4 v3, 0x0

    cmpg-float v2, v3, v2

    if-nez v2, :cond_ff

    goto :goto_104

    :cond_ff
    iput v3, v1, Lcom/brentvatne/exoplayer/AspectRatioFrameLayout;->a:F

    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    :goto_104
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    new-instance v2, LY5/a;

    const/4 v11, 0x1

    move-object v6, v2

    move-object v7, v5

    move-object v10, v4

    invoke-direct/range {v6 .. v11}, LY5/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_13d

    :cond_115
    iget-object v1, v5, Lb4/A;->P:LY3/j;

    if-ne v8, v1, :cond_13d

    invoke-virtual {v5, v8}, Lb4/A;->X(LY3/j;)V
    :try_end_11c
    .catch Ljava/lang/Exception; {:try_start_8c .. :try_end_11c} :catch_9a

    goto :goto_13d

    :goto_11d
    iput-boolean v0, v4, Lb4/A;->l:Z

    const-string v0, "ReactExoplayerView"

    const-string v2, "Failed to initialize Player! 2"

    invoke-static {v0, v2}, Lm7/L3;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lm7/L3;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object v0, v5, Lb4/A;->a:LZ3/E;

    iget-object v0, v0, LZ3/E;->c:LHc/d;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "1001"

    invoke-interface {v0, v2, v1, v3}, LHc/d;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_13d
    :goto_13d
    return-void

    :pswitch_data_13e
    .packed-switch 0x0
        :pswitch_78
        :pswitch_6c
        :pswitch_5a
        :pswitch_1f
    .end packed-switch
.end method
