.class public final Lb4/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final a:Lc1/f;

.field public final b:Landroid/net/Uri;

.field public final c:J

.field public final synthetic d:Lb4/A;


# direct methods
.method public constructor <init>(Lb4/A;Lc1/f;Landroid/net/Uri;J)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/w;->d:Lb4/A;

    iput-object p2, p0, Lb4/w;->a:Lc1/f;

    iput-object p3, p0, Lb4/w;->b:Landroid/net/Uri;

    const-wide/16 p1, 0x3e8

    mul-long/2addr p4, p1

    iput-wide p4, p0, Lb4/w;->c:J

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 18

    move-object/from16 v1, p0

    iget-object v0, v1, Lb4/w;->d:Lb4/A;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    :try_start_9
    iget-object v3, v1, Lb4/w;->a:Lc1/f;

    iget-object v4, v1, Lb4/w;->b:Landroid/net/Uri;

    invoke-static {v3, v4}, Ll7/T0;->b(Lc1/f;Landroid/net/Uri;)Lj1/c;

    move-result-object v3

    iget-object v4, v3, Lj1/c;->m:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v6, 0x0

    :goto_18
    if-ge v6, v4, :cond_95

    invoke-virtual {v3, v6}, Lj1/c;->b(I)Lj1/h;

    move-result-object v7

    const/4 v8, 0x0

    :goto_1f
    iget-object v9, v7, Lj1/h;->c:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    if-ge v8, v9, :cond_79

    iget-object v9, v7, Lj1/h;->c:Ljava/util/List;

    invoke-interface {v9, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lj1/a;

    iget v10, v9, Lj1/a;->b:I
    :try_end_31
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_31} :catch_66

    iget-object v9, v9, Lj1/a;->c:Ljava/util/List;

    const/4 v11, 0x2

    if-eq v10, v11, :cond_39

    move/from16 v16, v6

    goto :goto_74

    :cond_39
    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_3b
    :try_start_3b
    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v12

    if-ge v10, v12, :cond_6f

    invoke-interface {v9, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lj1/m;

    iget-object v13, v12, Lj1/m;->a:Landroidx/media3/common/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v13}, Lb4/A;->Y(Landroidx/media3/common/b;)Z

    move-result v14

    if-eqz v14, :cond_68

    iget-wide v14, v12, Lj1/m;->c:J

    move/from16 v16, v6

    iget-wide v5, v1, Lb4/w;->c:J

    cmp-long v5, v14, v5

    if-gtz v5, :cond_5d

    goto :goto_71

    :cond_5d
    invoke-static {v13, v10}, Lb4/A;->P(Landroidx/media3/common/b;I)LY3/n;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_64
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_64} :catch_66

    const/4 v11, 0x1

    goto :goto_6a

    :catch_66
    move-exception v0

    goto :goto_7e

    :cond_68
    move/from16 v16, v6

    :goto_6a
    add-int/lit8 v10, v10, 0x1

    move/from16 v6, v16

    goto :goto_3b

    :cond_6f
    move/from16 v16, v6

    :goto_71
    if-eqz v11, :cond_74

    goto :goto_96

    :cond_74
    :goto_74
    add-int/lit8 v8, v8, 0x1

    move/from16 v6, v16

    goto :goto_1f

    :cond_79
    move/from16 v16, v6

    add-int/lit8 v6, v16, 0x1

    goto :goto_18

    :goto_7e
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "error in getVideoTrackInfoFromManifest:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "ReactExoplayerView"

    invoke-static {v2, v0}, Lm7/L3;->o(Ljava/lang/String;Ljava/lang/String;)V

    :cond_95
    const/4 v2, 0x0

    :goto_96
    return-object v2
.end method
