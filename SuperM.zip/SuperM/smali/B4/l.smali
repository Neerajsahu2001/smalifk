.class public final synthetic Lb4/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lb4/l;->a:I

    iput-object p2, p0, Lb4/l;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 7

    const/4 p1, 0x0

    iget-object v0, p0, Lb4/l;->b:Ljava/lang/Object;

    iget v1, p0, Lb4/l;->a:I

    packed-switch v1, :pswitch_data_8e

    sget p1, Lone/upswing/sdk/ui/UpswingActivity;->X0:I

    check-cast v0, Lone/upswing/sdk/ui/UpswingActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    return-void

    :pswitch_10
    check-cast v0, LHc/a;

    invoke-interface {v0}, LHc/a;->invoke()Ljava/lang/Object;

    return-void

    :pswitch_16
    sget p1, Lio/branch/referral/validators/LinkingValidatorDialogRowItem;->l:I

    check-cast v0, Lio/branch/referral/validators/LinkingValidatorDialogRowItem;

    invoke-virtual {v0}, Lio/branch/referral/validators/LinkingValidatorDialogRowItem;->a()V

    return-void

    :pswitch_1e
    sget v1, Lio/branch/referral/validators/IntegrationValidatorDialog;->i:I

    sget-object v1, LA0/x;->c:LA0/x;

    if-nez v1, :cond_2d

    new-instance v1, LA0/x;

    const/16 v2, 0x15

    invoke-direct {v1, v2, p1}, LA0/x;-><init>(IZ)V

    sput-object v1, LA0/x;->c:LA0/x;

    :cond_2d
    sget-object p1, LA0/x;->c:LA0/x;

    new-instance v1, Lio/branch/referral/validators/LinkingValidatorDialog;

    check-cast v0, Landroid/content/Context;

    invoke-direct {v1, v0}, Lio/branch/referral/validators/LinkingValidatorDialog;-><init>(Landroid/content/Context;)V

    iput-object v1, p1, LA0/x;->b:Ljava/lang/Object;

    sget-object p1, LA0/x;->c:LA0/x;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p1, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {p1}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    sget-object v0, LA0/x;->c:LA0/x;

    iget-object v0, v0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lio/branch/referral/validators/LinkingValidatorDialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/WindowManager$LayoutParams;->copyFrom(Landroid/view/WindowManager$LayoutParams;)I

    const/4 v0, -0x1

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->width:I

    const/16 v0, 0x7d0

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->height:I

    sget-object v0, LA0/x;->c:LA0/x;

    iget-object v0, v0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lio/branch/referral/validators/LinkingValidatorDialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    sget-object v0, LA0/x;->c:LA0/x;

    iget-object v0, v0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lio/branch/referral/validators/LinkingValidatorDialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    return-void

    :pswitch_74
    check-cast v0, Lb4/A;

    iget-object v1, v0, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    invoke-virtual {v1}, Landroidx/media3/exoplayer/L;->v()J

    move-result-wide v1

    iget-object v3, v0, Lb4/A;->L:LY3/f;

    iget v3, v3, LY3/f;->n:I

    int-to-long v3, v3

    add-long/2addr v1, v3

    iget-object v0, v0, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    if-eqz v0, :cond_8d

    invoke-virtual {v0}, Landroidx/media3/exoplayer/L;->t()I

    move-result v3

    invoke-virtual {v0, v3, v1, v2, p1}, Landroidx/media3/exoplayer/L;->i(IJZ)V

    :cond_8d
    return-void

    :pswitch_data_8e
    .packed-switch 0x0
        :pswitch_74
        :pswitch_1e
        :pswitch_16
        :pswitch_10
    .end packed-switch
.end method
