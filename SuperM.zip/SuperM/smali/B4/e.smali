.class public final Lb4/e;
.super Lkotlin/jvm/internal/m;
.source "SourceFile"

# interfaces
.implements LHc/b;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, Lb4/e;->a:I

    iput-object p2, p0, Lb4/e;->b:Ljava/lang/Object;

    iput-object p3, p0, Lb4/e;->c:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/m;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    iget v0, p0, Lb4/e;->a:I

    packed-switch v0, :pswitch_data_276

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    iget-object v0, p0, Lb4/e;->b:Ljava/lang/Object;

    check-cast v0, Lod/D;

    iget-object v0, v0, Lod/D;->a:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lod/f;

    if-nez v0, :cond_2c

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-object v0, p0, Lb4/e;->c:Ljava/lang/Object;

    check-cast v0, LHc/b;

    invoke-interface {v0, p1}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    move-object v0, p1

    check-cast v0, Lod/f;

    :cond_2c
    return-object v0

    :pswitch_2d
    check-cast p1, Lod/B;

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lod/s;->a:Lod/f;

    filled-new-array {v0}, [Lod/f;

    move-result-object v0

    iget-object v1, p0, Lb4/e;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p1, v1, v0}, Lod/B;->a(Ljava/lang/String;[Lod/f;)V

    sget-object v0, Lod/s;->b:Lod/f;

    sget-object v1, Lod/s;->c:Lod/f;

    filled-new-array {v0, v1}, [Lod/f;

    move-result-object v0

    iget-object v1, p0, Lb4/e;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p1, v1, v0}, Lod/B;->c(Ljava/lang/String;[Lod/f;)V

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :pswitch_53
    check-cast p1, Ljava/lang/Throwable;

    iget-object v0, p0, Lb4/e;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/concurrent/futures/k;

    if-eqz p1, :cond_7a

    instance-of v1, p1, Ljava/util/concurrent/CancellationException;

    if-eqz v1, :cond_76

    const/4 p1, 0x1

    iput-boolean p1, v0, Landroidx/concurrent/futures/k;->d:Z

    iget-object v1, v0, Landroidx/concurrent/futures/k;->b:Landroidx/concurrent/futures/n;

    if-eqz v1, :cond_85

    iget-object v1, v1, Landroidx/concurrent/futures/n;->b:Landroidx/concurrent/futures/m;

    invoke-virtual {v1, p1}, Landroidx/concurrent/futures/j;->cancel(Z)Z

    move-result p1

    if-eqz p1, :cond_85

    const/4 p1, 0x0

    iput-object p1, v0, Landroidx/concurrent/futures/k;->a:Ljava/lang/Object;

    iput-object p1, v0, Landroidx/concurrent/futures/k;->b:Landroidx/concurrent/futures/n;

    iput-object p1, v0, Landroidx/concurrent/futures/k;->c:Landroidx/concurrent/futures/p;

    goto :goto_85

    :cond_76
    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Throwable;)Z

    goto :goto_85

    :cond_7a
    iget-object p1, p0, Lb4/e;->c:Ljava/lang/Object;

    check-cast p1, Lbe/G;

    invoke-interface {p1}, Lbe/G;->l()Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    :cond_85
    :goto_85
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :pswitch_88
    move-object v2, p1

    check-cast v2, Lwd/e;

    const-string p1, "name"

    invoke-static {v2, p1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Lb4/e;->b:Ljava/lang/Object;

    check-cast p1, Lkd/m;

    iget-object v0, p1, Lkd/m;->r:LMd/j;

    invoke-virtual {v0}, LMd/j;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    iget-object v1, p0, Lb4/e;->c:Ljava/lang/Object;

    check-cast v1, Ljc/v;

    const/4 v3, 0x0

    if-nez v0, :cond_e8

    iget-object v0, p1, Lkd/m;->s:LMd/j;

    invoke-virtual {v0}, LMd/j;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldd/w;

    if-eqz v0, :cond_157

    iget-object v3, v1, Ljc/v;->a:Ljava/lang/Object;

    check-cast v3, Ljd/a;

    iget-object v3, v3, Ljd/a;->a:LMd/r;

    new-instance v4, Lh9/b;

    const/4 v5, 0x4

    invoke-direct {v4, v5, p1}, Lh9/b;-><init>(ILjava/lang/Object;)V

    check-cast v3, LMd/o;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v5, LMd/j;

    invoke-direct {v5, v3, v4}, LMd/i;-><init>(LMd/o;LHc/a;)V

    iget-object v3, v1, Ljc/v;->a:Ljava/lang/Object;

    check-cast v3, Ljd/a;

    iget-object v4, v3, Ljd/a;->a:LMd/r;

    invoke-static {v1, v0}, Ll7/U5;->b(Ljc/v;Lnd/b;)Ljd/c;

    move-result-object v6

    iget-object v1, v3, Ljd/a;->j:Lcd/g;

    invoke-virtual {v1, v0}, Lcd/g;->a(Lnd/c;)Lcd/f;

    move-result-object v7

    iget-object v1, p1, Lkd/m;->n:LXc/f;

    move-object v0, v4

    move-object v3, v5

    move-object v4, v6

    move-object v5, v7

    invoke-static/range {v0 .. v5}, Lad/w;->z(LMd/r;LXc/f;Lwd/e;LMd/p;LYc/h;LXc/V;)Lad/w;

    move-result-object v3

    goto :goto_157

    :cond_e8
    iget-object v0, v1, Ljc/v;->a:Ljava/lang/Object;

    check-cast v0, Ljd/a;

    iget-object v0, v0, Ljd/a;->b:LA/a;

    iget-object p1, p1, Lkd/m;->n:LXc/f;

    invoke-static {p1}, LDd/f;->g(LXc/h;)Lwd/a;

    move-result-object v4

    invoke-static {v4}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    invoke-virtual {v4, v2}, Lwd/a;->d(Lwd/e;)Lwd/a;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Lwd/a;->g()Lwd/b;

    move-result-object v4

    const-string v5, "classId.packageFqName"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, Lwd/a;->h()Lwd/b;

    move-result-object v2

    invoke-virtual {v2}, Lwd/b;->b()Ljava/lang/String;

    move-result-object v2

    const/16 v5, 0x2e

    const/16 v6, 0x24

    invoke-static {v2, v5, v6}, LZd/q;->r(Ljava/lang/String;CC)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4}, Lwd/b;->d()Z

    move-result v6

    if-eqz v6, :cond_11e

    goto :goto_134

    :cond_11e
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4}, Lwd/b;->b()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_134
    iget-object v0, v0, LA/a;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/ClassLoader;

    invoke-static {v0, v2}, Lm7/a3;->a(Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    if-eqz v0, :cond_144

    new-instance v2, Ldd/q;

    invoke-direct {v2, v0}, Ldd/q;-><init>(Ljava/lang/Class;)V

    goto :goto_145

    :cond_144
    move-object v2, v3

    :goto_145
    if-nez v2, :cond_148

    goto :goto_157

    :cond_148
    new-instance v0, Lkd/j;

    invoke-direct {v0, v1, p1, v2, v3}, Lkd/j;-><init>(Ljc/v;LXc/k;Ldd/q;LXc/f;)V

    iget-object p1, v1, Ljc/v;->a:Ljava/lang/Object;

    check-cast p1, Ljd/a;

    iget-object p1, p1, Ljd/a;->s:Lgd/s;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v3, v0

    :cond_157
    :goto_157
    return-object v3

    :pswitch_158
    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, Lb4/e;->c:Ljava/lang/Object;

    check-cast p1, Lje/b;

    iget-object p1, p1, Lje/b;->b:Ljava/lang/Object;

    iget-object v0, p0, Lb4/e;->b:Ljava/lang/Object;

    check-cast v0, Lje/c;

    invoke-virtual {v0, p1}, Lje/c;->f(Ljava/lang/Object;)V

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :pswitch_16a
    check-cast p1, Lio/sentry/android/replay/capture/p;

    const-string v0, "segment"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p1, Lio/sentry/android/replay/capture/n;

    if-eqz v0, :cond_180

    check-cast p1, Lio/sentry/android/replay/capture/n;

    iget-object v0, p0, Lb4/e;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/replay/capture/t;

    iget-object v0, v0, Lio/sentry/android/replay/capture/t;->t:Lio/sentry/G;

    invoke-static {p1, v0}, Lio/sentry/android/replay/capture/n;->a(Lio/sentry/android/replay/capture/n;Lio/sentry/G;)V

    :cond_180
    iget-object p1, p0, Lb4/e;->c:Ljava/lang/Object;

    check-cast p1, Ljava/io/File;

    invoke-static {p1}, Ll7/l5;->b(Ljava/io/File;)Z

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :pswitch_18a
    check-cast p1, Ld0/h0;

    const-string v0, "info"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lb4/e;->b:Ljava/lang/Object;

    check-cast v0, Lb4/A;

    iget-object v1, v0, Lb4/A;->a:LZ3/E;

    iget-object v1, v1, LZ3/E;->z:LHc/b;

    iget-boolean p1, p1, Ld0/h0;->a:Z

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-interface {v1, v2}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, v0, Lb4/A;->h:Lb4/d;

    const/16 v2, 0x8

    const/4 v3, 0x0

    if-eqz v1, :cond_1cd

    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-eqz v1, :cond_1cd

    if-eqz p1, :cond_259

    iget-object v1, v0, Lb4/A;->h:Lb4/d;

    iget-object v4, v1, Lb4/d;->g:Landroid/widget/FrameLayout;

    invoke-virtual {v4}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v5

    :goto_1b9
    if-ge v3, v5, :cond_259

    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    iget-object v7, v1, Lb4/d;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    if-eq v6, v7, :cond_1ca

    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_1ca
    add-int/lit8 v3, v3, 0x1

    goto :goto_1b9

    :cond_1cd
    iget-object v1, v0, Lb4/A;->c1:Lcom/facebook/react/uimanager/ThemedReactContext;

    invoke-virtual {v1}, Lcom/facebook/react/uimanager/ThemedReactContext;->getCurrentActivity()Landroid/app/Activity;

    move-result-object v1

    if-nez v1, :cond_1d7

    goto/16 :goto_259

    :cond_1d7
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const v4, 0x1020002

    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x1

    invoke-direct {v4, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    iget-object v5, v0, Lb4/A;->M:Ljava/util/ArrayList;

    if-eqz p1, :cond_22e

    iget-object v6, v0, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v6}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v6

    check-cast v6, Landroid/view/ViewGroup;

    if-eqz v6, :cond_201

    iget-object v7, v0, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_201
    :goto_201
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v6

    if-ge v3, v6, :cond_228

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    iget-object v7, v0, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    if-eq v6, v7, :cond_225

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_225
    add-int/lit8 v3, v3, 0x1

    goto :goto_201

    :cond_228
    iget-object v2, v0, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v1, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_259

    :cond_22e
    iget-object v2, v0, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_259

    move v2, v3

    :goto_23a
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v6

    if-ge v2, v6, :cond_254

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_23a

    :cond_254
    iget-object v1, v0, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v0, v1, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    :cond_259
    :goto_259
    if-nez p1, :cond_273

    iget-object p1, p0, Lb4/e;->c:Ljava/lang/Object;

    check-cast p1, Le/t;

    invoke-virtual {p1}, Le/t;->getLifecycle()Landroidx/lifecycle/r;

    move-result-object p1

    check-cast p1, Landroidx/lifecycle/A;

    iget-object p1, p1, Landroidx/lifecycle/A;->d:Landroidx/lifecycle/q;

    sget-object v1, Landroidx/lifecycle/q;->c:Landroidx/lifecycle/q;

    if-ne p1, v1, :cond_273

    iget-boolean p1, v0, Lb4/A;->Y0:Z

    if-nez p1, :cond_273

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Lb4/A;->g0(Z)V

    :cond_273
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :pswitch_data_276
    .packed-switch 0x0
        :pswitch_18a
        :pswitch_16a
        :pswitch_158
        :pswitch_88
        :pswitch_53
        :pswitch_2d
    .end packed-switch
.end method
