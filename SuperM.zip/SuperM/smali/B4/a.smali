.class public final enum Lb4/a;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final c:Lda/a;

.field public static final enum d:Lb4/a;

.field public static final synthetic e:[Lb4/a;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, Lb4/a;

    const-string v1, "SPEAKER"

    const/4 v2, 0x0

    const-string v3, "speaker"

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2, v3, v4}, Lb4/a;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    sput-object v0, Lb4/a;->d:Lb4/a;

    new-instance v1, Lb4/a;

    const-string v3, "earpiece"

    const-string v4, "EARPIECE"

    const/4 v5, 0x1

    invoke-direct {v1, v4, v5, v3, v2}, Lb4/a;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    filled-new-array {v0, v1}, [Lb4/a;

    move-result-object v0

    sput-object v0, Lb4/a;->e:[Lb4/a;

    invoke-static {v0}, Landroid/support/v4/media/session/b;->b([Ljava/lang/Enum;)LBc/a;

    new-instance v0, Lda/a;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, Lda/a;-><init>(I)V

    sput-object v0, Lb4/a;->c:Lda/a;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;I)V
    .registers 5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lb4/a;->a:Ljava/lang/String;

    iput p4, p0, Lb4/a;->b:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lb4/a;
    .registers 2

    const-class v0, Lb4/a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lb4/a;

    return-object p0
.end method

.method public static values()[Lb4/a;
    .registers 1

    sget-object v0, Lb4/a;->e:[Lb4/a;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lb4/a;

    return-object v0
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    const-class v0, Lb4/a;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "("

    invoke-static {v0, v1}, LA8/z;->l(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lb4/a;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lb4/a;->b:I

    const-string v2, ")"

    invoke-static {v0, v1, v2}, LB4/d;->j(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
