.class public final synthetic Lb4/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lb4/A;


# direct methods
.method public synthetic constructor <init>(Lb4/A;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/q;->a:Lb4/A;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    iget-object p1, p0, Lb4/q;->a:Lb4/A;

    iput p2, p1, Lb4/A;->l1:I

    if-eqz p2, :cond_15

    const/4 v0, 0x2

    if-eq p2, v0, :cond_12

    const/4 v0, 0x3

    if-eq p2, v0, :cond_f

    const/high16 p2, 0x3f800000    # 1.0f

    goto :goto_17

    :cond_f
    const/high16 p2, 0x40000000    # 2.0f

    goto :goto_17

    :cond_12
    const/high16 p2, 0x3fc00000    # 1.5f

    goto :goto_17

    :cond_15
    const/high16 p2, 0x3f000000    # 0.5f

    :goto_17
    invoke-virtual {p1, p2}, Lb4/A;->i0(F)V

    return-void
.end method
