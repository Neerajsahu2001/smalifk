.class public final Lb4/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/media/AudioManager$OnAudioFocusChangeListener;


# instance fields
.field public final a:Lb4/A;

.field public final b:Lcom/facebook/react/uimanager/ThemedReactContext;


# direct methods
.method public constructor <init>(Lcom/facebook/react/uimanager/ThemedReactContext;Lb4/A;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lb4/y;->a:Lb4/A;

    iput-object p1, p0, Lb4/y;->b:Lcom/facebook/react/uimanager/ThemedReactContext;

    return-void
.end method


# virtual methods
.method public final onAudioFocusChange(I)V
    .registers 7

    iget-object v0, p0, Lb4/y;->b:Lcom/facebook/react/uimanager/ThemedReactContext;

    invoke-virtual {v0}, Lcom/facebook/react/uimanager/ThemedReactContext;->getCurrentActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v1, -0x2

    const/4 v2, 0x1

    iget-object v3, p0, Lb4/y;->a:Lb4/A;

    if-eq p1, v1, :cond_3b

    const/4 v1, -0x1

    if-eq p1, v1, :cond_1e

    if-eq p1, v2, :cond_12

    goto :goto_44

    :cond_12
    iput-boolean v2, v3, Lb4/A;->z:Z

    iget-object v1, v3, Lb4/A;->a:LZ3/E;

    iget-object v1, v1, LZ3/E;->s:LHc/b;

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {v1, v4}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_44

    :cond_1e
    const/4 v1, 0x0

    iput-boolean v1, v3, Lb4/A;->z:Z

    iget-object v1, v3, Lb4/A;->a:LZ3/E;

    iget-object v1, v1, LZ3/E;->s:LHc/b;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v1, v4}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    if-eqz v0, :cond_35

    new-instance v1, LLa/h;

    const/4 v4, 0x5

    invoke-direct {v1, v4, v3}, LLa/h;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_35
    iget-object v1, v3, Lb4/A;->d1:Landroid/media/AudioManager;

    invoke-virtual {v1, p0}, Landroid/media/AudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;)I

    goto :goto_44

    :cond_3b
    iget-object v1, v3, Lb4/A;->a:LZ3/E;

    iget-object v1, v1, LZ3/E;->s:LHc/b;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v1, v4}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_44
    iget-object v1, v3, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    if-eqz v1, :cond_6b

    if-eqz v0, :cond_6b

    const/4 v1, -0x3

    if-ne p1, v1, :cond_5c

    iget-boolean p1, v3, Lb4/A;->w:Z

    if-nez p1, :cond_6b

    new-instance p1, LC/A;

    const/16 v1, 0x8

    invoke-direct {p1, v1, p0}, LC/A;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_6b

    :cond_5c
    if-ne p1, v2, :cond_6b

    iget-boolean p1, v3, Lb4/A;->w:Z

    if-nez p1, :cond_6b

    new-instance p1, LC/U0;

    const/4 v1, 0x7

    invoke-direct {p1, v1, p0}, LC/U0;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_6b
    :goto_6b
    return-void
.end method
