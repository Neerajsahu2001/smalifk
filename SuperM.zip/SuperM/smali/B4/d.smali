.class public final Lb4/d;
.super Landroid/app/Dialog;
.source "SourceFile"


# instance fields
.field public final a:Lcom/brentvatne/exoplayer/ExoPlayerView;

.field public final b:Lb4/A;

.field public final c:Landroidx/media3/ui/LegacyPlayerControlView;

.field public final d:Le/v;

.field public final e:LY3/f;

.field public f:Landroid/view/ViewGroup;

.field public final g:Landroid/widget/FrameLayout;

.field public final h:Landroid/os/Handler;

.field public final i:LF/d;

.field public final j:Ljava/lang/Integer;

.field public final k:Ljava/lang/Boolean;

.field public final l:Ljava/lang/Boolean;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/brentvatne/exoplayer/ExoPlayerView;Lb4/A;Landroidx/media3/ui/LegacyPlayerControlView;Lb4/x;LY3/f;)V
    .registers 8

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "exoPlayerView"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "reactExoplayerView"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "controlsConfig"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const v0, 0x1030009

    invoke-direct {p0, p1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    iput-object p2, p0, Lb4/d;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    iput-object p3, p0, Lb4/d;->b:Lb4/A;

    iput-object p4, p0, Lb4/d;->c:Landroidx/media3/ui/LegacyPlayerControlView;

    iput-object p5, p0, Lb4/d;->d:Le/v;

    iput-object p6, p0, Lb4/d;->e:LY3/f;

    new-instance p2, Landroid/widget/FrameLayout;

    invoke-direct {p2, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lb4/d;->g:Landroid/widget/FrameLayout;

    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p3

    invoke-direct {p1, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lb4/d;->h:Landroid/os/Handler;

    new-instance p1, LF/d;

    invoke-direct {p1, p0}, LF/d;-><init>(Lb4/d;)V

    iput-object p1, p0, Lb4/d;->i:LF/d;

    invoke-static {}, Lb4/d;->a()Landroid/widget/FrameLayout$LayoutParams;

    move-result-object p1

    invoke-virtual {p0, p2, p1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    if-eqz p1, :cond_a7

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p2

    new-instance p3, LA0/x;

    invoke-direct {p3, p2}, LA0/x;-><init>(Landroid/view/View;)V

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p4, 0x1e

    if-lt p2, p4, :cond_5f

    new-instance p2, Landroidx/core/view/S0;

    invoke-direct {p2, p1, p3}, Landroidx/core/view/S0;-><init>(Landroid/view/Window;LA0/x;)V

    goto :goto_64

    :cond_5f
    new-instance p2, Landroidx/core/view/R0;

    invoke-direct {p2, p1, p3}, Landroidx/core/view/R0;-><init>(Landroid/view/Window;LA0/x;)V

    :goto_64
    invoke-virtual {p2}, Lm7/E2;->i()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    iput-object p2, p0, Lb4/d;->j:Ljava/lang/Integer;

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p2

    sget-object p3, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    invoke-static {p2}, Landroidx/core/view/V;->a(Landroid/view/View;)Landroidx/core/view/Q0;

    move-result-object p2

    const/4 p3, 0x0

    const/4 p4, 0x1

    if-eqz p2, :cond_87

    iget-object p2, p2, Landroidx/core/view/Q0;->a:Landroidx/core/view/O0;

    const/4 p5, 0x2

    invoke-virtual {p2, p5}, Landroidx/core/view/O0;->o(I)Z

    move-result p2

    if-ne p2, p4, :cond_87

    move p2, p4

    goto :goto_88

    :cond_87
    move p2, p3

    :goto_88
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    iput-object p2, p0, Lb4/d;->k:Ljava/lang/Boolean;

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    invoke-static {p1}, Landroidx/core/view/V;->a(Landroid/view/View;)Landroidx/core/view/Q0;

    move-result-object p1

    if-eqz p1, :cond_a1

    iget-object p1, p1, Landroidx/core/view/Q0;->a:Landroidx/core/view/O0;

    invoke-virtual {p1, p4}, Landroidx/core/view/O0;->o(I)Z

    move-result p1

    if-ne p1, p4, :cond_a1

    move p3, p4

    :cond_a1
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iput-object p1, p0, Lb4/d;->l:Ljava/lang/Boolean;

    :cond_a7
    return-void
.end method

.method public static a()Landroid/widget/FrameLayout$LayoutParams;
    .registers 2

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {v0, v1, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1, v1, v1, v1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    return-object v0
.end method

.method public static b(LA1/b;ILjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V
    .registers 5

    if-eqz p2, :cond_28

    invoke-virtual {p2, p3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p3

    xor-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_b

    goto :goto_c

    :cond_b
    const/4 p2, 0x0

    :goto_c
    if-eqz p2, :cond_28

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    iget-object p0, p0, LA1/b;->b:Ljava/lang/Object;

    check-cast p0, Lm7/E2;

    if-eqz p2, :cond_25

    invoke-virtual {p0, p1}, Lm7/E2;->j(I)V

    if-eqz p4, :cond_28

    invoke-virtual {p4}, Ljava/lang/Number;->intValue()I

    move-result p1

    invoke-virtual {p0, p1}, Lm7/E2;->n(I)V

    goto :goto_28

    :cond_25
    invoke-virtual {p0, p1}, Lm7/E2;->o(I)V

    :cond_28
    :goto_28
    return-void
.end method


# virtual methods
.method public final c(Landroidx/media3/ui/LegacyPlayerControlView;Z)V
    .registers 5

    const v0, 0x7f0a0126

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageButton;

    if-eqz p1, :cond_36

    if-eqz p2, :cond_11

    const v0, 0x7f0800ed

    goto :goto_14

    :cond_11
    const v0, 0x7f0800ec

    :goto_14
    if-eqz p2, :cond_22

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p2

    const v1, 0x7f1200b6

    invoke-virtual {p2, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    goto :goto_2d

    :cond_22
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p2

    const v1, 0x7f1200b5

    invoke-virtual {p2, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    :goto_2d
    invoke-static {p2}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_36
    return-void
.end method

.method public final onAttachedToWindow()V
    .registers 3

    invoke-super {p0}, Landroid/app/Dialog;->onAttachedToWindow()V

    iget-object v0, p0, Lb4/d;->b:Lb4/A;

    iget-boolean v0, v0, Lb4/A;->W0:Z

    if-eqz v0, :cond_10

    iget-object v0, p0, Lb4/d;->h:Landroid/os/Handler;

    iget-object v1, p0, Lb4/d;->i:LF/d;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_10
    return-void
.end method

.method public final onStart()V
    .registers 12

    invoke-super {p0}, Landroid/app/Dialog;->onStart()V

    iget-object v0, p0, Lb4/d;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    iput-object v1, p0, Lb4/d;->f:Landroid/view/ViewGroup;

    if-eqz v1, :cond_12

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_12
    iget-object v1, p0, Lb4/d;->g:Landroid/widget/FrameLayout;

    invoke-static {}, Lb4/d;->a()Landroid/widget/FrameLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v1, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x1

    iget-object v2, p0, Lb4/d;->c:Landroidx/media3/ui/LegacyPlayerControlView;

    if-eqz v2, :cond_31

    invoke-virtual {p0, v2, v0}, Lb4/d;->c(Landroidx/media3/ui/LegacyPlayerControlView;Z)V

    iget-object v3, p0, Lb4/d;->f:Landroid/view/ViewGroup;

    if-eqz v3, :cond_2a

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_2a
    invoke-static {}, Lb4/d;->a()Landroid/widget/FrameLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_31
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v3, 0x0

    iget-object v4, p0, Lb4/d;->e:LY3/f;

    if-eqz v1, :cond_5e

    iget-boolean v5, v4, LY3/f;->j:Z

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    iget-boolean v6, v4, LY3/f;->k:Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    const/4 v7, 0x2

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    new-instance v9, LA1/b;

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v10

    invoke-direct {v9, v1, v10}, LA1/b;-><init>(Landroid/view/Window;Landroid/view/View;)V

    iget-object v1, p0, Lb4/d;->k:Ljava/lang/Boolean;

    invoke-static {v9, v7, v5, v1, v8}, Lb4/d;->b(LA1/b;ILjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    iget-object v1, p0, Lb4/d;->l:Ljava/lang/Boolean;

    invoke-static {v9, v0, v6, v1, v3}, Lb4/d;->b(LA1/b;ILjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    :cond_5e
    iget-boolean v0, v4, LY3/f;->k:Z

    if-eqz v0, :cond_82

    if-eqz v2, :cond_6e

    const v0, 0x7f0a0129

    invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Landroid/widget/LinearLayout;

    :cond_6e
    if-eqz v3, :cond_82

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x28

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_82
    return-void
.end method

.method public final onStop()V
    .registers 8

    invoke-super {p0}, Landroid/app/Dialog;->onStop()V

    iget-object v0, p0, Lb4/d;->h:Landroid/os/Handler;

    iget-object v1, p0, Lb4/d;->i:LF/d;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lb4/d;->g:Landroid/widget/FrameLayout;

    iget-object v1, p0, Lb4/d;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v2, p0, Lb4/d;->f:Landroid/view/ViewGroup;

    if-eqz v2, :cond_1c

    invoke-static {}, Lb4/d;->a()Landroid/widget/FrameLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_1c
    iget-object v1, p0, Lb4/d;->c:Landroidx/media3/ui/LegacyPlayerControlView;

    if-eqz v1, :cond_32

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Lb4/d;->c(Landroidx/media3/ui/LegacyPlayerControlView;Z)V

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v0, p0, Lb4/d;->f:Landroid/view/ViewGroup;

    if-eqz v0, :cond_32

    invoke-static {}, Lb4/d;->a()Landroid/widget/FrameLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_32
    iget-object v0, p0, Lb4/d;->f:Landroid/view/ViewGroup;

    if-eqz v0, :cond_39

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    :cond_39
    const/4 v0, 0x0

    iput-object v0, p0, Lb4/d;->f:Landroid/view/ViewGroup;

    iget-object v1, p0, Lb4/d;->d:Le/v;

    invoke-virtual {v1}, Le/v;->a()V

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_62

    iget-object v2, p0, Lb4/d;->j:Ljava/lang/Integer;

    iget-object v3, p0, Lb4/d;->k:Ljava/lang/Boolean;

    iget-object v4, p0, Lb4/d;->l:Ljava/lang/Boolean;

    new-instance v5, LA1/b;

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v6

    invoke-direct {v5, v1, v6}, LA1/b;-><init>(Landroid/view/Window;Landroid/view/View;)V

    const/4 v1, 0x2

    iget-object v6, p0, Lb4/d;->k:Ljava/lang/Boolean;

    invoke-static {v5, v1, v3, v6, v2}, Lb4/d;->b(LA1/b;ILjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    iget-object v1, p0, Lb4/d;->l:Ljava/lang/Boolean;

    const/4 v2, 0x1

    invoke-static {v5, v2, v4, v1, v0}, Lb4/d;->b(LA1/b;ILjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    :cond_62
    return-void
.end method
