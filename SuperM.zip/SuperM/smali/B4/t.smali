.class public final Lb4/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lb4/A;


# direct methods
.method public constructor <init>(Lb4/A;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/t;->a:Lb4/A;

    return-void
.end method
