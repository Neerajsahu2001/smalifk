.class public abstract Lb4/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Landroidx/media3/datasource/DefaultDataSource$Factory;

.field public static b:Le1/a;

.field public static c:Ljava/lang/String;


# direct methods
.method public static a(Lcom/facebook/react/bridge/ReactContext;Ly1/r;Ljava/util/HashMap;)Le1/a;
    .registers 7

    invoke-static {}, Lcom/facebook/react/modules/network/OkHttpClientProvider;->getOkHttpClient()Lokhttp3/OkHttpClient;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/OkHttpClient;->cookieJar()Lokhttp3/CookieJar;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type com.facebook.react.modules.network.CookieJarContainer"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lcom/facebook/react/modules/network/CookieJarContainer;

    new-instance v2, Lcom/facebook/react/modules/network/ForwardingCookieHandler;

    invoke-direct {v2}, Ljava/net/CookieHandler;-><init>()V

    new-instance v3, Lokhttp3/JavaNetCookieJar;

    invoke-direct {v3, v2}, Lokhttp3/JavaNetCookieJar;-><init>(Ljava/net/CookieHandler;)V

    check-cast v1, Lcom/facebook/react/modules/network/ReactCookieJarContainer;

    invoke-virtual {v1, v3}, Lcom/facebook/react/modules/network/ReactCookieJarContainer;->setCookieJar(Lokhttp3/JavaNetCookieJar;)V

    new-instance v1, Le1/a;

    invoke-direct {v1, v0}, Le1/a;-><init>(Lokhttp3/OkHttpClient;)V

    iput-object p1, v1, Le1/a;->d:Lc1/E;

    if-eqz p2, :cond_4e

    iget-object p1, v1, Le1/a;->a:LW2/c;

    monitor-enter p1

    const/4 v0, 0x0

    :try_start_2b
    iput-object v0, p1, LW2/c;->b:Ljava/lang/Object;

    iget-object v0, p1, LW2/c;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p1, LW2/c;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p2}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V
    :try_end_3b
    .catchall {:try_start_2b .. :try_end_3b} :catchall_4b

    monitor-exit p1

    const-string p1, "User-Agent"

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_54

    invoke-static {p0}, Lb4/b;->c(Lcom/facebook/react/bridge/ReactContext;)Ljava/lang/String;

    move-result-object p0

    iput-object p0, v1, Le1/a;->c:Ljava/lang/String;

    goto :goto_54

    :catchall_4b
    move-exception p0

    monitor-exit p1

    throw p0

    :cond_4e
    invoke-static {p0}, Lb4/b;->c(Lcom/facebook/react/bridge/ReactContext;)Ljava/lang/String;

    move-result-object p0

    iput-object p0, v1, Le1/a;->c:Ljava/lang/String;

    :cond_54
    :goto_54
    return-object v1
.end method

.method public static final b(Lcom/facebook/react/bridge/ReactContext;Ly1/r;Ljava/util/HashMap;)Lc1/e;
    .registers 4

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lb4/b;->a:Landroidx/media3/datasource/DefaultDataSource$Factory;

    if-eqz v0, :cond_12

    if-eqz p2, :cond_1d

    invoke-virtual {p2}, Ljava/util/HashMap;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_12

    goto :goto_1d

    :cond_12
    new-instance v0, Landroidx/media3/datasource/DefaultDataSource$Factory;

    invoke-static {p0, p1, p2}, Lb4/b;->a(Lcom/facebook/react/bridge/ReactContext;Ly1/r;Ljava/util/HashMap;)Le1/a;

    move-result-object p1

    invoke-direct {v0, p0, p1}, Landroidx/media3/datasource/DefaultDataSource$Factory;-><init>(Landroid/content/Context;Lc1/v;)V

    sput-object v0, Lb4/b;->a:Landroidx/media3/datasource/DefaultDataSource$Factory;

    :cond_1d
    :goto_1d
    sget-object p0, Lb4/b;->a:Landroidx/media3/datasource/DefaultDataSource$Factory;

    const-string p1, "null cannot be cast to non-null type androidx.media3.datasource.DataSource.Factory"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static c(Lcom/facebook/react/bridge/ReactContext;)Ljava/lang/String;
    .registers 4

    sget-object v0, Lb4/b;->c:Ljava/lang/String;

    if-nez v0, :cond_3b

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    sget v1, LZ0/F;->a:I

    :try_start_a
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_19
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_a .. :try_end_19} :catch_1a

    goto :goto_1c

    :catch_1a
    const-string p0, "?"

    :goto_1c
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "/"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " (Linux;Android "

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const-string v0, ") AndroidXMedia3/1.4.1"

    invoke-static {v1, p0, v0}, LA8/z;->h(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sput-object p0, Lb4/b;->c:Ljava/lang/String;

    :cond_3b
    sget-object p0, Lb4/b;->c:Ljava/lang/String;

    const-string v0, "null cannot be cast to non-null type kotlin.String"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method
