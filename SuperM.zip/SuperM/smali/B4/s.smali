.class public final Lb4/s;
.super Landroid/os/Handler;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lb4/A;


# direct methods
.method public constructor <init>(Lb4/A;Landroid/os/Looper;)V
    .registers 3

    iput-object p1, p0, Lb4/s;->a:Lb4/A;

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .registers 5

    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v0, 0x1

    if-ne p1, v0, :cond_18

    iget-object p1, p0, Lb4/s;->a:Lb4/A;

    invoke-virtual {p1}, Lb4/A;->p0()V

    invoke-virtual {p0, v0}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    iget p1, p1, Lb4/A;->X0:F

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    int-to-long v1, p1

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    :cond_18
    return-void
.end method
