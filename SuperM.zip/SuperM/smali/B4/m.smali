.class public final synthetic Lb4/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;I)V
    .registers 3

    iput p2, p0, Lb4/m;->a:I

    iput-object p1, p0, Lb4/m;->b:Landroid/view/KeyEvent$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    iget v0, p0, Lb4/m;->a:I

    packed-switch v0, :pswitch_data_4a

    iget-object v0, p0, Lb4/m;->b:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lorg/npci/upi/security/pinactivitycomponent/GetCredential;

    invoke-static {v0, p1}, Lorg/npci/upi/security/pinactivitycomponent/GetCredential;->u(Lorg/npci/upi/security/pinactivitycomponent/GetCredential;Landroid/view/View;)V

    return-void

    :pswitch_d
    const-string p1, "this$0"

    iget-object v0, p0, Lb4/m;->b:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lcom/swmansion/rnscreens/S;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p1, LRb/e;

    invoke-virtual {v0}, Landroid/view/View;->getId()I

    move-result v1

    iget v2, v0, Lcom/swmansion/rnscreens/S;->m:I

    const/4 v3, 0x1

    invoke-direct {p1, v2, v1, v3}, LRb/e;-><init>(III)V

    invoke-virtual {v0, p1}, Lcom/swmansion/rnscreens/S;->d(Lcom/facebook/react/uimanager/events/Event;)V

    const/16 p1, 0x8

    invoke-virtual {v0, p1}, Lcom/swmansion/rnscreens/S;->f(I)V

    return-void

    :pswitch_2b
    const-string v0, "this$0"

    iget-object v1, p0, Lb4/m;->b:Landroid/view/KeyEvent$Callback;

    check-cast v1, Lcom/swmansion/rnscreens/b;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v1, Lcom/swmansion/rnscreens/b;->W:Landroid/view/View$OnClickListener;

    if-eqz v0, :cond_3b

    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    :cond_3b
    iget-object p1, v1, Lcom/swmansion/rnscreens/b;->T0:Lcom/swmansion/rnscreens/d;

    invoke-virtual {p1}, Lcom/swmansion/rnscreens/d;->a()V

    return-void

    :pswitch_41
    const/4 p1, 0x1

    iget-object v0, p0, Lb4/m;->b:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lb4/A;

    invoke-virtual {v0, p1}, Lb4/A;->g0(Z)V

    return-void

    :pswitch_data_4a
    .packed-switch 0x0
        :pswitch_41
        :pswitch_2b
        :pswitch_d
    .end packed-switch
.end method
