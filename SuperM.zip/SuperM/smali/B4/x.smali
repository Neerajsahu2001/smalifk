.class public final Lb4/x;
.super Le/v;
.source "SourceFile"


# instance fields
.field public final synthetic d:Lb4/A;


# direct methods
.method public constructor <init>(Lb4/A;)V
    .registers 2

    iput-object p1, p0, Lb4/x;->d:Lb4/A;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Le/v;-><init>(Z)V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    iget-object v0, p0, Lb4/x;->d:Lb4/A;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lb4/A;->f0(Z)V

    return-void
.end method
