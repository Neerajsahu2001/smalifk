.class public final Lb4/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LW0/O;


# instance fields
.field public final synthetic a:Lcom/brentvatne/exoplayer/ExoPlayerView;


# direct methods
.method public constructor <init>(Lcom/brentvatne/exoplayer/ExoPlayerView;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/c;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    return-void
.end method


# virtual methods
.method public final B(Ljava/util/List;)V
    .registers 3

    const-string v0, "cues"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lb4/c;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    iget-object v0, v0, Lcom/brentvatne/exoplayer/ExoPlayerView;->d:Landroidx/media3/ui/SubtitleView;

    iput-object p1, v0, Landroidx/media3/ui/SubtitleView;->a:Ljava/util/List;

    invoke-virtual {v0}, Landroidx/media3/ui/SubtitleView;->c()V

    return-void
.end method

.method public final H(LW0/e0;)V
    .registers 3

    const-string v0, "videoSize"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget v0, p1, LW0/e0;->b:I

    if-eqz v0, :cond_22

    iget p1, p1, LW0/e0;->a:I

    if-nez p1, :cond_e

    goto :goto_22

    :cond_e
    iget-object p1, p0, Lb4/c;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    iget-object v0, p1, Lcom/brentvatne/exoplayer/ExoPlayerView;->g:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_22

    check-cast v0, Landroidx/media3/exoplayer/L;

    invoke-virtual {v0}, Landroidx/media3/exoplayer/L;->b0()V

    iget-object v0, v0, Landroidx/media3/exoplayer/L;->j0:Landroidx/media3/exoplayer/l0;

    iget-object v0, v0, Landroidx/media3/exoplayer/l0;->i:Lx1/x;

    iget-object v0, v0, Lx1/x;->d:LW0/b0;

    invoke-static {p1, v0}, Lcom/brentvatne/exoplayer/ExoPlayerView;->a(Lcom/brentvatne/exoplayer/ExoPlayerView;LW0/b0;)V

    :cond_22
    :goto_22
    return-void
.end method

.method public final K(LW0/b0;)V
    .registers 3

    const-string v0, "tracks"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lb4/c;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    invoke-static {v0, p1}, Lcom/brentvatne/exoplayer/ExoPlayerView;->a(Lcom/brentvatne/exoplayer/ExoPlayerView;LW0/b0;)V

    return-void
.end method

.method public final z()V
    .registers 3

    iget-object v0, p0, Lb4/c;->a:Lcom/brentvatne/exoplayer/ExoPlayerView;

    iget-object v0, v0, Lcom/brentvatne/exoplayer/ExoPlayerView;->c:Landroid/view/View;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method
