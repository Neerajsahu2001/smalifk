.class public final synthetic Lb4/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# instance fields
.field public final synthetic a:Lb4/A;


# direct methods
.method public synthetic constructor <init>(Lb4/A;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/r;->a:Lb4/A;

    return-void
.end method


# virtual methods
.method public final onLayoutChange(Landroid/view/View;IIIIIIII)V
    .registers 10

    iget-object p1, p0, Lb4/r;->a:Lb4/A;

    iget-object p2, p1, Lb4/A;->y:Landroid/app/PictureInPictureParams$Builder;

    iget-object p3, p1, Lb4/A;->g:Lcom/brentvatne/exoplayer/ExoPlayerView;

    iget-object p1, p1, Lb4/A;->c1:Lcom/facebook/react/uimanager/ThemedReactContext;

    const-string p4, "context"

    invoke-static {p1, p4}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p4, "playerView"

    invoke-static {p3, p4}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p2, :cond_46

    new-instance p4, Landroid/graphics/Rect;

    invoke-direct {p4}, Landroid/graphics/Rect;-><init>()V

    iget-object p5, p3, Lcom/brentvatne/exoplayer/ExoPlayerView;->b:Landroid/view/View;

    if-eqz p5, :cond_20

    invoke-virtual {p5, p4}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    :cond_20
    const/4 p5, 0x2

    new-array p5, p5, [I

    iget-object p3, p3, Lcom/brentvatne/exoplayer/ExoPlayerView;->b:Landroid/view/View;

    if-eqz p3, :cond_2a

    invoke-virtual {p3, p5}, Landroid/view/View;->getLocationOnScreen([I)V

    :cond_2a
    iget p3, p4, Landroid/graphics/Rect;->bottom:I

    iget p6, p4, Landroid/graphics/Rect;->top:I

    sub-int/2addr p3, p6

    const/4 p6, 0x1

    aget p5, p5, p6

    iput p5, p4, Landroid/graphics/Rect;->top:I

    add-int/2addr p5, p3

    iput p5, p4, Landroid/graphics/Rect;->bottom:I

    invoke-virtual {p2, p4}, Landroid/app/PictureInPictureParams$Builder;->setSourceRectHint(Landroid/graphics/Rect;)Landroid/app/PictureInPictureParams$Builder;

    invoke-virtual {p2}, Landroid/app/PictureInPictureParams$Builder;->build()Landroid/app/PictureInPictureParams;

    move-result-object p2

    const-string p3, "build(...)"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1, p2}, Lm7/D4;->d(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/app/PictureInPictureParams;)V

    :cond_46
    return-void
.end method
