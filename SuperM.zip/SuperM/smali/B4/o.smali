.class public final synthetic Lb4/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lb4/A;

.field public final synthetic b:J

.field public final synthetic c:J

.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:Ljava/util/ArrayList;

.field public final synthetic g:Ljava/util/ArrayList;

.field public final synthetic h:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lb4/A;JJIILjava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/String;)V
    .registers 11

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/o;->a:Lb4/A;

    iput-wide p2, p0, Lb4/o;->b:J

    iput-wide p4, p0, Lb4/o;->c:J

    iput p6, p0, Lb4/o;->d:I

    iput p7, p0, Lb4/o;->e:I

    iput-object p8, p0, Lb4/o;->f:Ljava/util/ArrayList;

    iput-object p9, p0, Lb4/o;->g:Ljava/util/ArrayList;

    iput-object p10, p0, Lb4/o;->h:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 12

    iget-object v0, p0, Lb4/o;->a:Lb4/A;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lb4/A;->V(I)Ljava/util/ArrayList;

    move-result-object v9

    if-eqz v9, :cond_c

    const/4 v1, 0x1

    iput-boolean v1, v0, Lb4/A;->F:Z

    :cond_c
    iget-object v0, v0, Lb4/A;->a:LZ3/E;

    iget-object v2, v0, LZ3/E;->b:LHc/f;

    iget-wide v0, p0, Lb4/o;->b:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    iget-wide v0, p0, Lb4/o;->c:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    iget v0, p0, Lb4/o;->d:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget v0, p0, Lb4/o;->e:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget-object v8, p0, Lb4/o;->g:Ljava/util/ArrayList;

    iget-object v10, p0, Lb4/o;->h:Ljava/lang/String;

    iget-object v7, p0, Lb4/o;->f:Ljava/util/ArrayList;

    invoke-interface/range {v2 .. v10}, LHc/f;->e(Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
