.class public final synthetic Lb4/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lb4/A;


# direct methods
.method public synthetic constructor <init>(Lb4/A;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/p;->a:Lb4/A;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    iget-object p1, p0, Lb4/p;->a:Lb4/A;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez p2, :cond_2d

    const-string p2, "0.5x"

    const-string v0, "1.0x"

    const-string v1, "1.5x"

    const-string v2, "2.0x"

    filled-new-array {p2, v0, v1, v2}, [Ljava/lang/String;

    move-result-object p2

    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p1, Lb4/A;->c1:Lcom/facebook/react/uimanager/ThemedReactContext;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v1, 0x7f12025b

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    iget v1, p1, Lb4/A;->l1:I

    new-instance v2, Lb4/q;

    invoke-direct {v2, p1}, Lb4/q;-><init>(Lb4/A;)V

    invoke-virtual {v0, p2, v1, v2}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    :cond_2d
    return-void
.end method
