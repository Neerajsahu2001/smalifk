.class public final synthetic Lb4/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq0/a;
.implements Lkotlin/jvm/internal/h;


# instance fields
.field public final synthetic a:LHc/b;


# direct methods
.method public constructor <init>(Lb4/e;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/f;->a:LHc/b;

    return-void
.end method


# virtual methods
.method public final synthetic accept(Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, Lb4/f;->a:LHc/b;

    invoke-interface {v0, p1}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Lq0/a;

    const/4 v1, 0x0

    if-eqz v0, :cond_15

    instance-of v0, p1, Lkotlin/jvm/internal/h;

    if-eqz v0, :cond_15

    check-cast p1, Lkotlin/jvm/internal/h;

    invoke-interface {p1}, Lkotlin/jvm/internal/h;->getFunctionDelegate()Luc/c;

    move-result-object p1

    iget-object v0, p0, Lb4/f;->a:LHc/b;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    :cond_15
    return v1
.end method

.method public final getFunctionDelegate()Luc/c;
    .registers 2

    iget-object v0, p0, Lb4/f;->a:LHc/b;

    return-object v0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lb4/f;->a:LHc/b;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
