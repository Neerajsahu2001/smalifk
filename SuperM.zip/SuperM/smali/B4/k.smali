.class public final synthetic Lb4/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;I)V
    .registers 3

    iput p2, p0, Lb4/k;->a:I

    iput-object p1, p0, Lb4/k;->b:Landroid/view/KeyEvent$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 8

    const/4 p1, 0x1

    const/4 v0, 0x0

    iget-object v1, p0, Lb4/k;->b:Landroid/view/KeyEvent$Callback;

    iget v2, p0, Lb4/k;->a:I

    packed-switch v2, :pswitch_data_98

    sget v2, Lone/upswing/sdk/ui/UpswingActivity;->X0:I

    const-string v2, "connectivity"

    check-cast v1, Lone/upswing/sdk/ui/UpswingActivity;

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const-string v3, "null cannot be cast to non-null type android.net.ConnectivityManager"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/net/ConnectivityManager;

    invoke-virtual {v2}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v3

    if-nez v3, :cond_21

    goto :goto_45

    :cond_21
    invoke-virtual {v2, v3}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v2

    if-nez v2, :cond_28

    goto :goto_45

    :cond_28
    invoke-virtual {v2, p1}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result p1

    if-nez p1, :cond_3b

    invoke-virtual {v2, v0}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result p1

    if-nez p1, :cond_3b

    const/4 p1, 0x3

    invoke-virtual {v2, p1}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result p1

    if-eqz p1, :cond_45

    :cond_3b
    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {v1}, Landroid/app/Activity;->finish()V

    invoke-virtual {v1, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_45
    :goto_45
    return-void

    :pswitch_46
    check-cast v1, Lio/branch/referral/validators/LinkingValidatorDialogRowItem;

    iget-object v0, v1, Lio/branch/referral/validators/LinkingValidatorDialogRowItem;->i:Landroid/content/Context;

    invoke-static {v0}, Lio/branch/referral/validators/LinkingValidatorDialogRowItem;->c(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/app/Activity;->moveTaskToBack(Z)Z

    invoke-virtual {v1}, Lio/branch/referral/validators/LinkingValidatorDialogRowItem;->a()V

    return-void

    :pswitch_55
    sget p1, Lcom/supermoney/payments/MainActivity;->o1:I

    check-cast v1, Lcom/supermoney/payments/MainActivity;

    const-string p1, "this$0"

    invoke-static {v1, p1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, v1, Lcom/supermoney/payments/MainActivity;->k1:Lge/f;

    invoke-static {p1}, Lbe/i;->e(Lbe/A;)Z

    move-result p1

    if-nez p1, :cond_79

    invoke-static {}, Lcom/supermoney/payments/MainActivity;->a0()Lge/f;

    move-result-object p1

    iput-object p1, v1, Lcom/supermoney/payments/MainActivity;->k1:Lge/f;

    iget-object p1, v1, Lcom/supermoney/payments/MainActivity;->l1:Luc/l;

    invoke-virtual {p1}, Luc/l;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lfb/d;

    iget-object v2, v1, Lcom/supermoney/payments/MainActivity;->k1:Lge/f;

    invoke-virtual {p1, v2}, Lfb/d;->updateScope(Lbe/A;)V

    :cond_79
    invoke-virtual {v1, v0}, Lcom/supermoney/payments/MainActivity;->authenticate(Z)V

    return-void

    :pswitch_7d
    check-cast v1, Lb4/A;

    iget-object p1, v1, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    invoke-virtual {p1}, Landroidx/media3/exoplayer/L;->v()J

    move-result-wide v2

    iget-object p1, v1, Lb4/A;->L:LY3/f;

    iget p1, p1, LY3/f;->n:I

    int-to-long v4, p1

    sub-long/2addr v2, v4

    iget-object p1, v1, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    if-eqz p1, :cond_96

    invoke-virtual {p1}, Landroidx/media3/exoplayer/L;->t()I

    move-result v1

    invoke-virtual {p1, v1, v2, v3, v0}, Landroidx/media3/exoplayer/L;->i(IJZ)V

    :cond_96
    return-void

    nop

    :pswitch_data_98
    .packed-switch 0x0
        :pswitch_7d
        :pswitch_55
        :pswitch_46
    .end packed-switch
.end method
