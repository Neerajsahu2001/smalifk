.class public final Lb4/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LW0/O;


# instance fields
.field public final synthetic a:Lb4/A;


# direct methods
.method public constructor <init>(Lb4/A;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/u;->a:Lb4/A;

    return-void
.end method


# virtual methods
.method public final h(IZ)V
    .registers 3

    iget-object p1, p0, Lb4/u;->a:Lb4/A;

    iget-object p2, p1, Lb4/A;->e:Landroid/view/View;

    invoke-virtual {p1, p2}, Lb4/A;->a0(Landroid/view/View;)V

    iget-object p2, p1, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    iget-object p1, p1, Lb4/A;->f:Lb4/u;

    invoke-virtual {p2, p1}, Landroidx/media3/exoplayer/L;->K(LW0/O;)V

    return-void
.end method

.method public final l(I)V
    .registers 7

    iget-object p1, p0, Lb4/u;->a:Lb4/A;

    iget-object v0, p1, Lb4/A;->d:Landroidx/media3/ui/LegacyPlayerControlView;

    const v1, 0x7f0a0134

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iget-object v1, p1, Lb4/A;->d:Landroidx/media3/ui/LegacyPlayerControlView;

    const v2, 0x7f0a0133

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/4 v2, 0x4

    const/16 v3, 0x8

    if-eqz v0, :cond_22

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v4

    if-ne v4, v3, :cond_22

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_22
    if-eqz v1, :cond_2d

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-ne v0, v3, :cond_2d

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_2d
    iget-object v0, p1, Lb4/A;->e:Landroid/view/View;

    invoke-virtual {p1, v0}, Lb4/A;->a0(Landroid/view/View;)V

    iget-object v0, p1, Lb4/A;->j:Landroidx/media3/exoplayer/L;

    iget-object p1, p1, Lb4/A;->f:Lb4/u;

    invoke-virtual {v0, p1}, Landroidx/media3/exoplayer/L;->K(LW0/O;)V

    return-void
.end method
