.class public final Lb4/i;
.super Ly1/s;
.source "SourceFile"


# instance fields
.field public final b:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    invoke-direct {p0, p1}, Ly1/s;-><init>(I)V

    iput p1, p0, Lb4/i;->b:I

    return-void
.end method


# virtual methods
.method public final b(I)I
    .registers 2

    const p1, 0x7fffffff

    return p1
.end method

.method public final c(Lx9/a;)J
    .registers 6

    iget-object v0, p1, Lx9/a;->b:Ljava/io/Serializable;

    check-cast v0, Ljava/io/IOException;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    instance-of v0, v0, Lc1/w;

    const-wide/16 v2, 0x3e8

    if-eqz v0, :cond_21

    if-eqz v1, :cond_21

    const-string v0, "Unable to connect"

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_37

    const-string v0, "Software caused connection abort"

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    goto :goto_37

    :cond_21
    iget v0, p0, Lb4/i;->b:I

    iget p1, p1, Lx9/a;->a:I

    if-ge p1, v0, :cond_32

    add-int/lit8 p1, p1, -0x1

    int-to-long v0, p1

    mul-long/2addr v0, v2

    const-wide/16 v2, 0x1388

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    goto :goto_37

    :cond_32
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    :cond_37
    :goto_37
    return-wide v2
.end method
