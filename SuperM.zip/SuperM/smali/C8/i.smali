.class public final Lc8/i;
.super Ld8/l;
.source "SourceFile"


# instance fields
.field public final synthetic b:Lv7/j;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lc8/m;


# direct methods
.method public constructor <init>(Lc8/m;Ljava/lang/String;Lv7/j;Lv7/j;)V
    .registers 5

    iput-object p1, p0, Lc8/i;->d:Lc8/m;

    iput-object p4, p0, Lc8/i;->b:Lv7/j;

    iput-object p2, p0, Lc8/i;->c:Ljava/lang/String;

    invoke-direct {p0, p3}, Ld8/l;-><init>(Lv7/j;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 10

    iget-object v0, p0, Lc8/i;->b:Lv7/j;

    iget-object v1, p0, Lc8/i;->d:Lc8/m;

    :try_start_4
    iget-object v2, v1, Lc8/m;->a:Ld8/r;

    iget-object v2, v2, Ld8/r;->m:Landroid/os/IInterface;

    iget-object v3, v1, Lc8/m;->b:Ljava/lang/String;

    invoke-static {}, Lc8/m;->b()Landroid/os/Bundle;

    move-result-object v4

    new-instance v5, Lc8/k;

    new-instance v6, LIa/j;

    const-string v7, "OnCompleteUpdateCallback"

    const/4 v8, 0x1

    invoke-direct {v6, v7, v8}, LIa/j;-><init>(Ljava/lang/String;I)V

    invoke-direct {v5, v1, v6, v0}, Lc8/j;-><init>(Lc8/m;LIa/j;Lv7/j;)V

    invoke-interface {v2, v3, v4, v5}, Ld8/h;->o(Ljava/lang/String;Landroid/os/Bundle;Lc8/k;)V
    :try_end_1e
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_1e} :catch_1f

    return-void

    :catch_1f
    move-exception v1

    sget-object v2, Lc8/m;->e:LIa/j;

    iget-object v3, p0, Lc8/i;->c:Ljava/lang/String;

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "completeUpdate(%s)"

    invoke-virtual {v2, v1, v4, v3}, LIa/j;->c(Landroid/os/RemoteException;Ljava/lang/String;[Ljava/lang/Object;)V

    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    invoke-virtual {v0, v2}, Lv7/j;->c(Ljava/lang/Exception;)Z

    return-void
.end method
