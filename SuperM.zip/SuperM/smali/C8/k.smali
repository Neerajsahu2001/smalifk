.class public final Lc8/k;
.super Lc8/j;
.source "SourceFile"


# virtual methods
.method public final y(Landroid/os/Bundle;)V
    .registers 6

    invoke-super {p0, p1}, Lc8/j;->y(Landroid/os/Bundle;)V

    const-string v0, "error.code"

    const/4 v1, -0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v2

    iget-object v3, p0, Lc8/j;->b:Lv7/j;

    if-eqz v2, :cond_1b

    new-instance v2, Lcom/google/android/play/core/install/a;

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result p1

    invoke-direct {v2, p1}, Lcom/google/android/play/core/install/a;-><init>(I)V

    invoke-virtual {v3, v2}, Lv7/j;->c(Ljava/lang/Exception;)Z

    return-void

    :cond_1b
    const/4 p1, 0x0

    invoke-virtual {v3, p1}, Lv7/j;->d(Ljava/lang/Object;)V

    return-void
.end method
