.class public final Lc8/h;
.super Ld8/l;
.source "SourceFile"


# instance fields
.field public final synthetic b:I

.field public final synthetic c:Lv7/j;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lc8/m;Ljava/lang/String;Lv7/j;Lv7/j;)V
    .registers 6

    const/4 v0, 0x0

    iput v0, p0, Lc8/h;->b:I

    iput-object p1, p0, Lc8/h;->e:Ljava/lang/Object;

    iput-object p2, p0, Lc8/h;->d:Ljava/lang/Object;

    iput-object p4, p0, Lc8/h;->c:Lv7/j;

    invoke-direct {p0, p3}, Ld8/l;-><init>(Lv7/j;)V

    return-void
.end method

.method public constructor <init>(Ld8/r;Lv7/j;Lv7/j;Ld8/l;)V
    .registers 6

    const/4 v0, 0x1

    iput v0, p0, Lc8/h;->b:I

    iput-object p1, p0, Lc8/h;->e:Ljava/lang/Object;

    iput-object p3, p0, Lc8/h;->c:Lv7/j;

    iput-object p4, p0, Lc8/h;->d:Ljava/lang/Object;

    invoke-direct {p0, p2}, Ld8/l;-><init>(Lv7/j;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 8

    iget v0, p0, Lc8/h;->b:I

    packed-switch v0, :pswitch_data_80

    iget-object v0, p0, Lc8/h;->e:Ljava/lang/Object;

    check-cast v0, Ld8/r;

    iget-object v0, v0, Ld8/r;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_c
    iget-object v1, p0, Lc8/h;->e:Ljava/lang/Object;

    check-cast v1, Ld8/r;

    iget-object v2, p0, Lc8/h;->c:Lv7/j;

    iget-object v3, v1, Ld8/r;->e:Ljava/util/HashSet;

    invoke-virtual {v3, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iget-object v3, v2, Lv7/j;->a:Lv7/v;

    new-instance v4, Lio/sentry/internal/debugmeta/c;

    invoke-direct {v4, v1, v2}, Lio/sentry/internal/debugmeta/c;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v4}, Lv7/v;->c(Lv7/d;)Lv7/v;

    iget-object v1, p0, Lc8/h;->e:Ljava/lang/Object;

    check-cast v1, Ld8/r;

    iget-object v1, v1, Ld8/r;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v1

    if-lez v1, :cond_3e

    iget-object v1, p0, Lc8/h;->e:Ljava/lang/Object;

    check-cast v1, Ld8/r;

    iget-object v1, v1, Ld8/r;->b:LIa/j;

    const-string v2, "Already connected to the service."

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-virtual {v1, v2, v3}, LIa/j;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_3e

    :catchall_3c
    move-exception v1

    goto :goto_4b

    :cond_3e
    :goto_3e
    iget-object v1, p0, Lc8/h;->e:Ljava/lang/Object;

    check-cast v1, Ld8/r;

    iget-object v2, p0, Lc8/h;->d:Ljava/lang/Object;

    check-cast v2, Ld8/l;

    invoke-static {v1, v2}, Ld8/r;->b(Ld8/r;Ld8/l;)V

    monitor-exit v0

    return-void

    :goto_4b
    monitor-exit v0
    :try_end_4c
    .catchall {:try_start_c .. :try_end_4c} :catchall_3c

    throw v1

    :pswitch_4d
    iget-object v0, p0, Lc8/h;->c:Lv7/j;

    iget-object v1, p0, Lc8/h;->e:Ljava/lang/Object;

    check-cast v1, Lc8/m;

    iget-object v2, p0, Lc8/h;->d:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    :try_start_57
    iget-object v3, v1, Lc8/m;->a:Ld8/r;

    iget-object v3, v3, Ld8/r;->m:Landroid/os/IInterface;

    iget-object v4, v1, Lc8/m;->b:Ljava/lang/String;

    invoke-static {v1, v2}, Lc8/m;->a(Lc8/m;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v5

    new-instance v6, Lc8/l;

    invoke-direct {v6, v1, v0, v2}, Lc8/l;-><init>(Lc8/m;Lv7/j;Ljava/lang/String;)V

    invoke-interface {v3, v4, v5, v6}, Ld8/h;->x(Ljava/lang/String;Landroid/os/Bundle;Lc8/l;)V
    :try_end_69
    .catch Landroid/os/RemoteException; {:try_start_57 .. :try_end_69} :catch_6a

    goto :goto_7e

    :catch_6a
    move-exception v1

    sget-object v3, Lc8/m;->e:LIa/j;

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v4, "requestUpdateInfo(%s)"

    invoke-virtual {v3, v1, v4, v2}, LIa/j;->c(Landroid/os/RemoteException;Ljava/lang/String;[Ljava/lang/Object;)V

    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    invoke-virtual {v0, v2}, Lv7/j;->c(Ljava/lang/Exception;)Z

    :goto_7e
    return-void

    nop

    :pswitch_data_80
    .packed-switch 0x0
        :pswitch_4d
    .end packed-switch
.end method
