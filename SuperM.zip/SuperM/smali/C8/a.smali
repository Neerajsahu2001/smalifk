.class public final Lc8/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Ljava/lang/Integer;

.field public final c:J

.field public final d:J

.field public final e:Landroid/app/PendingIntent;

.field public final f:Landroid/app/PendingIntent;

.field public final g:Landroid/app/PendingIntent;

.field public final h:Landroid/app/PendingIntent;

.field public i:Z


# direct methods
.method public constructor <init>(ILjava/lang/Integer;JJLandroid/app/PendingIntent;Landroid/app/PendingIntent;Landroid/app/PendingIntent;Landroid/app/PendingIntent;)V
    .registers 12

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc8/a;->i:Z

    iput p1, p0, Lc8/a;->a:I

    iput-object p2, p0, Lc8/a;->b:Ljava/lang/Integer;

    iput-wide p3, p0, Lc8/a;->c:J

    iput-wide p5, p0, Lc8/a;->d:J

    iput-object p7, p0, Lc8/a;->e:Landroid/app/PendingIntent;

    iput-object p8, p0, Lc8/a;->f:Landroid/app/PendingIntent;

    iput-object p9, p0, Lc8/a;->g:Landroid/app/PendingIntent;

    iput-object p10, p0, Lc8/a;->h:Landroid/app/PendingIntent;

    return-void
.end method


# virtual methods
.method public final a(Lc8/o;)Landroid/app/PendingIntent;
    .registers 9

    iget-wide v0, p0, Lc8/a;->d:J

    iget-wide v2, p0, Lc8/a;->c:J

    iget-boolean v4, p1, Lc8/o;->b:Z

    iget p1, p1, Lc8/o;->a:I

    const/4 v5, 0x0

    if-nez p1, :cond_1a

    iget-object p1, p0, Lc8/a;->f:Landroid/app/PendingIntent;

    if-eqz p1, :cond_10

    return-object p1

    :cond_10
    if-eqz v4, :cond_19

    cmp-long p1, v2, v0

    if-gtz p1, :cond_19

    iget-object p1, p0, Lc8/a;->h:Landroid/app/PendingIntent;

    return-object p1

    :cond_19
    return-object v5

    :cond_1a
    const/4 v6, 0x1

    if-ne p1, v6, :cond_2b

    iget-object p1, p0, Lc8/a;->e:Landroid/app/PendingIntent;

    if-eqz p1, :cond_22

    return-object p1

    :cond_22
    if-eqz v4, :cond_2b

    cmp-long p1, v2, v0

    if-gtz p1, :cond_2b

    iget-object p1, p0, Lc8/a;->g:Landroid/app/PendingIntent;

    return-object p1

    :cond_2b
    return-object v5
.end method
