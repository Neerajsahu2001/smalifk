.class public final Lc8/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld8/c;


# instance fields
.field public final synthetic a:I

.field public final b:Ld8/c;


# direct methods
.method public synthetic constructor <init>(Lc8/g;I)V
    .registers 3

    iput p2, p0, Lc8/d;->a:I

    iput-object p1, p0, Lc8/d;->b:Ld8/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final zza()Ljava/lang/Object;
    .registers 3

    iget v0, p0, Lc8/d;->a:I

    packed-switch v0, :pswitch_data_36

    iget-object v0, p0, Lc8/d;->b:Ld8/c;

    check-cast v0, Lc8/g;

    iget-object v0, v0, Lc8/g;->a:Lc8/f;

    iget-object v0, v0, Lc8/f;->a:Landroid/content/Context;

    if-eqz v0, :cond_15

    new-instance v1, Lc8/n;

    invoke-direct {v1, v0}, Lc8/n;-><init>(Landroid/content/Context;)V

    return-object v1

    :cond_15
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "Cannot return null from a non-@Nullable @Provides method"

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_1d
    iget-object v0, p0, Lc8/d;->b:Ld8/c;

    check-cast v0, Lc8/g;

    iget-object v0, v0, Lc8/g;->a:Lc8/f;

    iget-object v0, v0, Lc8/f;->a:Landroid/content/Context;

    if-eqz v0, :cond_2d

    new-instance v1, Lcom/google/android/play/core/appupdate/zzc;

    invoke-direct {v1, v0}, Lcom/google/android/play/core/appupdate/zzc;-><init>(Landroid/content/Context;)V

    return-object v1

    :cond_2d
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "Cannot return null from a non-@Nullable @Provides method"

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0

    nop

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_1d
    .end packed-switch
.end method
