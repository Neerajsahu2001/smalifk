.class public final Lc8/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld8/c;


# instance fields
.field public final a:Lc8/f;


# direct methods
.method public constructor <init>(Lc8/f;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc8/g;->a:Lc8/f;

    return-void
.end method


# virtual methods
.method public final zza()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lc8/g;->a:Lc8/f;

    iget-object v0, v0, Lc8/f;->a:Landroid/content/Context;

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "Cannot return null from a non-@Nullable @Provides method"

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
