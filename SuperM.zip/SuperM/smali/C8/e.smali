.class public final Lc8/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc8/b;


# instance fields
.field public final a:Lc8/m;

.field public final b:Lcom/google/android/play/core/appupdate/zzc;

.field public final c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Lc8/m;Lcom/google/android/play/core/appupdate/zzc;Landroid/content/Context;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lc8/e;->a:Lc8/m;

    iput-object p2, p0, Lc8/e;->b:Lcom/google/android/play/core/appupdate/zzc;

    iput-object p3, p0, Lc8/e;->c:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final a()Lv7/v;
    .registers 7

    iget-object v0, p0, Lc8/e;->c:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc8/e;->a:Lc8/m;

    iget-object v2, v1, Lc8/m;->a:Ld8/r;

    if-nez v2, :cond_39

    const/16 v0, -0x9

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    sget-object v2, Lc8/m;->e:LIa/j;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v3, "PlayCore"

    const/4 v4, 0x6

    invoke-static {v3, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v4

    if-eqz v4, :cond_2f

    iget-object v2, v2, LIa/j;->b:Ljava/lang/String;

    const-string v4, "onError(%d)"

    invoke-static {v2, v4, v1}, LIa/j;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/newrelic/agent/android/instrumentation/LogInstrumentation;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2f
    new-instance v1, Lcom/google/android/play/core/install/a;

    invoke-direct {v1, v0}, Lcom/google/android/play/core/install/a;-><init>(I)V

    invoke-static {v1}, Lv7/l;->d(Ljava/lang/Exception;)Lv7/v;

    move-result-object v0

    goto :goto_5c

    :cond_39
    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "completeUpdate(%s)"

    sget-object v5, Lc8/m;->e:LIa/j;

    invoke-virtual {v5, v4, v3}, LIa/j;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    new-instance v3, Lv7/j;

    invoke-direct {v3}, Lv7/j;-><init>()V

    new-instance v4, Lc8/i;

    invoke-direct {v4, v1, v0, v3, v3}, Lc8/i;-><init>(Lc8/m;Ljava/lang/String;Lv7/j;Lv7/j;)V

    new-instance v0, Lc8/h;

    invoke-direct {v0, v2, v3, v3, v4}, Lc8/h;-><init>(Ld8/r;Lv7/j;Lv7/j;Ld8/l;)V

    invoke-virtual {v2}, Ld8/r;->a()Landroid/os/Handler;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-object v0, v3, Lv7/j;->a:Lv7/v;

    :goto_5c
    return-object v0
.end method

.method public final b()Lv7/v;
    .registers 7

    iget-object v0, p0, Lc8/e;->c:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc8/e;->a:Lc8/m;

    iget-object v2, v1, Lc8/m;->a:Ld8/r;

    if-nez v2, :cond_39

    const/16 v0, -0x9

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    sget-object v2, Lc8/m;->e:LIa/j;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v3, "PlayCore"

    const/4 v4, 0x6

    invoke-static {v3, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v4

    if-eqz v4, :cond_2f

    iget-object v2, v2, LIa/j;->b:Ljava/lang/String;

    const-string v4, "onError(%d)"

    invoke-static {v2, v4, v1}, LIa/j;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/newrelic/agent/android/instrumentation/LogInstrumentation;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2f
    new-instance v1, Lcom/google/android/play/core/install/a;

    invoke-direct {v1, v0}, Lcom/google/android/play/core/install/a;-><init>(I)V

    invoke-static {v1}, Lv7/l;->d(Ljava/lang/Exception;)Lv7/v;

    move-result-object v0

    goto :goto_5c

    :cond_39
    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "requestUpdateInfo(%s)"

    sget-object v5, Lc8/m;->e:LIa/j;

    invoke-virtual {v5, v4, v3}, LIa/j;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    new-instance v3, Lv7/j;

    invoke-direct {v3}, Lv7/j;-><init>()V

    new-instance v4, Lc8/h;

    invoke-direct {v4, v1, v0, v3, v3}, Lc8/h;-><init>(Lc8/m;Ljava/lang/String;Lv7/j;Lv7/j;)V

    new-instance v0, Lc8/h;

    invoke-direct {v0, v2, v3, v3, v4}, Lc8/h;-><init>(Ld8/r;Lv7/j;Lv7/j;Ld8/l;)V

    invoke-virtual {v2}, Ld8/r;->a()Landroid/os/Handler;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-object v0, v3, Lv7/j;->a:Lv7/v;

    :goto_5c
    return-object v0
.end method

.method public final declared-synchronized c(Lcom/google/android/play/core/install/b;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lc8/e;->b:Lcom/google/android/play/core/appupdate/zzc;

    invoke-virtual {v0, p1}, Lcom/google/android/play/core/appupdate/zzc;->a(Lcom/google/android/play/core/install/b;)V
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_8

    monitor-exit p0

    return-void

    :catchall_8
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final d(Lc8/a;Lg/b;Lc8/o;)Z
    .registers 7

    const/4 v0, 0x0

    if-eqz p1, :cond_2a

    if-eqz p2, :cond_2a

    invoke-virtual {p1, p3}, Lc8/a;->a(Lc8/o;)Landroid/app/PendingIntent;

    move-result-object v1

    if-eqz v1, :cond_2a

    iget-boolean v1, p1, Lc8/a;->i:Z

    if-eqz v1, :cond_10

    goto :goto_2a

    :cond_10
    const/4 v1, 0x1

    iput-boolean v1, p1, Lc8/a;->i:Z

    invoke-virtual {p1, p3}, Lc8/a;->a(Lc8/o;)Landroid/app/PendingIntent;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const-string p3, "intentSender"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p3, Landroidx/activity/result/IntentSenderRequest;

    const/4 v2, 0x0

    invoke-direct {p3, p1, v2, v0, v0}, Landroidx/activity/result/IntentSenderRequest;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    invoke-virtual {p2, p3}, Lg/b;->a(Ljava/lang/Object;)V

    return v1

    :cond_2a
    :goto_2a
    return v0
.end method

.method public final declared-synchronized e(Lcom/google/android/play/core/install/b;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lc8/e;->b:Lcom/google/android/play/core/appupdate/zzc;

    invoke-virtual {v0, p1}, Lcom/google/android/play/core/appupdate/zzc;->b(Lcom/google/android/play/core/install/b;)V
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_8

    monitor-exit p0

    return-void

    :catchall_8
    move-exception p1

    monitor-exit p0

    throw p1
.end method
