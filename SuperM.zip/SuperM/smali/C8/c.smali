.class public abstract Lc8/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:LA0/x;


# direct methods
.method public static a()V
    .registers 2

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    if-ne v0, v1, :cond_10

    const/4 v0, 0x1

    goto :goto_11

    :cond_10
    const/4 v0, 0x0

    :goto_11
    const-string v1, "Not in application\'s main thread"

    invoke-static {v0, v1}, Ll7/C5;->f(ZLjava/lang/String;)V

    return-void
.end method

.method public static b(Lio/sentry/a1;Ljava/lang/String;Lio/sentry/g0;Lio/sentry/ILogger;)Z
    .registers 10

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, -0x1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v5

    sparse-switch v5, :sswitch_data_156

    goto/16 :goto_b9

    :sswitch_e
    const-string v5, "platform"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_18

    goto/16 :goto_b9

    :cond_18
    const/16 v4, 0xd

    goto/16 :goto_b9

    :sswitch_1c
    const-string v5, "request"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_26

    goto/16 :goto_b9

    :cond_26
    const/16 v4, 0xc

    goto/16 :goto_b9

    :sswitch_2a
    const-string v5, "release"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_34

    goto/16 :goto_b9

    :cond_34
    const/16 v4, 0xb

    goto/16 :goto_b9

    :sswitch_38
    const-string v5, "event_id"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_42

    goto/16 :goto_b9

    :cond_42
    const/16 v4, 0xa

    goto/16 :goto_b9

    :sswitch_46
    const-string v5, "extra"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_50

    goto/16 :goto_b9

    :cond_50
    const/16 v4, 0x9

    goto/16 :goto_b9

    :sswitch_54
    const-string v5, "user"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5e

    goto/16 :goto_b9

    :cond_5e
    const/16 v4, 0x8

    goto/16 :goto_b9

    :sswitch_62
    const-string v5, "tags"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6b

    goto :goto_b9

    :cond_6b
    const/4 v4, 0x7

    goto :goto_b9

    :sswitch_6d
    const-string v5, "dist"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_76

    goto :goto_b9

    :cond_76
    const/4 v4, 0x6

    goto :goto_b9

    :sswitch_78
    const-string v5, "sdk"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_81

    goto :goto_b9

    :cond_81
    const/4 v4, 0x5

    goto :goto_b9

    :sswitch_83
    const-string v5, "breadcrumbs"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_8c

    goto :goto_b9

    :cond_8c
    const/4 v4, 0x4

    goto :goto_b9

    :sswitch_8e
    const-string v5, "environment"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_97

    goto :goto_b9

    :cond_97
    move v4, v0

    goto :goto_b9

    :sswitch_99
    const-string v5, "contexts"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_a2

    goto :goto_b9

    :cond_a2
    move v4, v1

    goto :goto_b9

    :sswitch_a4
    const-string v5, "server_name"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_ad

    goto :goto_b9

    :cond_ad
    move v4, v3

    goto :goto_b9

    :sswitch_af
    const-string v5, "debug_meta"

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_b8

    goto :goto_b9

    :cond_b8
    move v4, v2

    :goto_b9
    packed-switch v4, :pswitch_data_190

    return v2

    :pswitch_bd
    invoke-virtual {p2}, Lio/sentry/g0;->u0()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->h:Ljava/lang/String;

    return v3

    :pswitch_c4
    new-instance p1, Lio/sentry/I0;

    invoke-direct {p1, v0}, Lio/sentry/I0;-><init>(I)V

    invoke-virtual {p2, p3, p1}, Lio/sentry/g0;->s0(Lio/sentry/ILogger;Lio/sentry/X;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lio/sentry/protocol/s;

    iput-object p1, p0, Lio/sentry/a1;->d:Lio/sentry/protocol/s;

    return v3

    :pswitch_d2
    invoke-virtual {p2}, Lio/sentry/g0;->u0()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->f:Ljava/lang/String;

    return v3

    :pswitch_d9
    new-instance p1, Lio/sentry/protocol/e;

    invoke-direct {p1, v1}, Lio/sentry/protocol/e;-><init>(I)V

    invoke-virtual {p2, p3, p1}, Lio/sentry/g0;->s0(Lio/sentry/ILogger;Lio/sentry/X;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lio/sentry/protocol/y;

    iput-object p1, p0, Lio/sentry/a1;->a:Lio/sentry/protocol/y;

    return v3

    :pswitch_e7
    invoke-virtual {p2}, Lio/sentry/g0;->r0()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    invoke-static {p1}, Ll7/N4;->b(Ljava/util/Map;)Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->o:Ljava/util/Map;

    return v3

    :pswitch_f4
    new-instance p1, Lio/sentry/protocol/e;

    invoke-direct {p1, v0}, Lio/sentry/protocol/e;-><init>(I)V

    invoke-virtual {p2, p3, p1}, Lio/sentry/g0;->s0(Lio/sentry/ILogger;Lio/sentry/X;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lio/sentry/protocol/I;

    iput-object p1, p0, Lio/sentry/a1;->i:Lio/sentry/protocol/I;

    return v3

    :pswitch_102
    invoke-virtual {p2}, Lio/sentry/g0;->r0()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    invoke-static {p1}, Ll7/N4;->b(Ljava/util/Map;)Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->e:Ljava/util/Map;

    return v3

    :pswitch_10f
    invoke-virtual {p2}, Lio/sentry/g0;->u0()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->l:Ljava/lang/String;

    return v3

    :pswitch_116
    new-instance p1, Lio/sentry/protocol/b;

    invoke-direct {p1, v1}, Lio/sentry/protocol/b;-><init>(I)V

    invoke-virtual {p2, p3, p1}, Lio/sentry/g0;->s0(Lio/sentry/ILogger;Lio/sentry/X;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lio/sentry/protocol/w;

    iput-object p1, p0, Lio/sentry/a1;->c:Lio/sentry/protocol/w;

    return v3

    :pswitch_124
    new-instance p1, Lio/sentry/c;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p2, p3, p1}, Lio/sentry/g0;->k0(Lio/sentry/ILogger;Lio/sentry/X;)Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->m:Ljava/util/List;

    return v3

    :pswitch_130
    invoke-virtual {p2}, Lio/sentry/g0;->u0()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->g:Ljava/lang/String;

    return v3

    :pswitch_137
    invoke-static {p2, p3}, Lio/sentry/clientreport/e;->b(Lio/sentry/g0;Lio/sentry/ILogger;)Lio/sentry/protocol/d;

    move-result-object p1

    iget-object p0, p0, Lio/sentry/a1;->b:Lio/sentry/protocol/d;

    invoke-virtual {p0, p1}, Ljava/util/AbstractMap;->putAll(Ljava/util/Map;)V

    return v3

    :pswitch_141
    invoke-virtual {p2}, Lio/sentry/g0;->u0()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lio/sentry/a1;->k:Ljava/lang/String;

    return v3

    :pswitch_148
    new-instance p1, Lio/sentry/protocol/f;

    invoke-direct {p1, v2}, Lio/sentry/protocol/f;-><init>(I)V

    invoke-virtual {p2, p3, p1}, Lio/sentry/g0;->s0(Lio/sentry/ILogger;Lio/sentry/X;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lio/sentry/protocol/g;

    iput-object p1, p0, Lio/sentry/a1;->n:Lio/sentry/protocol/g;

    return v3

    :sswitch_data_156
    .sparse-switch
        -0x6db2cb8f -> :sswitch_af
        -0x2d39e9f9 -> :sswitch_a4
        -0x21d07f5c -> :sswitch_99
        -0x51ecded -> :sswitch_8e
        -0x3112f30 -> :sswitch_83
        0x1bc3a -> :sswitch_78
        0x2f0da6 -> :sswitch_6d
        0x363419 -> :sswitch_62
        0x36ebcb -> :sswitch_54
        0x5c79410 -> :sswitch_46
        0x1093c0e0 -> :sswitch_38
        0x41012807 -> :sswitch_2a
        0x414ef28f -> :sswitch_1c
        0x6fbd6873 -> :sswitch_e
    .end sparse-switch

    :pswitch_data_190
    .packed-switch 0x0
        :pswitch_148
        :pswitch_141
        :pswitch_137
        :pswitch_130
        :pswitch_124
        :pswitch_116
        :pswitch_10f
        :pswitch_102
        :pswitch_f4
        :pswitch_e7
        :pswitch_d9
        :pswitch_d2
        :pswitch_c4
        :pswitch_bd
    .end packed-switch
.end method
