.class public final Lc8/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Z)V
    .registers 3

    iput-object p1, p0, Lc8/f;->a:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ls6/l;
    .registers 17

    move-object/from16 v0, p0

    iget-object v1, v0, Lc8/f;->a:Landroid/content/Context;

    if-eqz v1, :cond_9a

    new-instance v2, Ls6/l;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    sget-object v3, Ls6/o;->a:LP8/b;

    invoke-static {v3}, Lu6/a;->a(Ljavax/inject/Provider;)Ljavax/inject/Provider;

    move-result-object v3

    iput-object v3, v2, Ls6/l;->a:Ljavax/inject/Provider;

    new-instance v3, Ll9/C;

    invoke-direct {v3, v1}, Ll9/C;-><init>(Ljava/lang/Object;)V

    iput-object v3, v2, Ls6/l;->b:Ll9/C;

    new-instance v1, LA8/G;

    invoke-direct {v1, v3}, LA8/G;-><init>(Ll9/C;)V

    new-instance v4, LAa/t;

    const/16 v5, 0x10

    invoke-direct {v4, v5, v3, v1}, LAa/t;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v4}, Lu6/a;->a(Ljavax/inject/Provider;)Ljavax/inject/Provider;

    move-result-object v1

    iput-object v1, v2, Ls6/l;->c:Ljavax/inject/Provider;

    iget-object v1, v2, Ls6/l;->b:Ll9/C;

    new-instance v3, LAc/f;

    invoke-direct {v3, v1}, LAc/f;-><init>(Ll9/C;)V

    iput-object v3, v2, Ls6/l;->d:LAc/f;

    new-instance v3, LIe/i;

    const/16 v4, 0xa

    invoke-direct {v3, v4, v1}, LIe/i;-><init>(ILjava/lang/Object;)V

    invoke-static {v3}, Lu6/a;->a(Ljavax/inject/Provider;)Ljavax/inject/Provider;

    move-result-object v1

    iput-object v1, v2, Ls6/l;->e:Ljavax/inject/Provider;

    iget-object v3, v2, Ls6/l;->d:LAc/f;

    new-instance v4, Ljc/v;

    sget-object v5, LB6/b;->a:LQ8/a;

    sget-object v6, LB6/c;->a:LQ4/a;

    sget-object v7, Lz6/g;->a:LO4/d;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    iput-object v5, v4, Ljc/v;->a:Ljava/lang/Object;

    iput-object v6, v4, Ljc/v;->b:Ljava/lang/Object;

    iput-object v7, v4, Ljc/v;->c:Ljava/lang/Object;

    iput-object v3, v4, Ljc/v;->d:Ljava/lang/Object;

    iput-object v1, v4, Ljc/v;->e:Ljava/lang/Object;

    invoke-static {v4}, Lu6/a;->a(Ljavax/inject/Provider;)Ljavax/inject/Provider;

    move-result-object v1

    iput-object v1, v2, Ls6/l;->f:Ljavax/inject/Provider;

    new-instance v3, Ls4/K;

    const/4 v4, 0x2

    invoke-direct {v3, v4}, Ls4/K;-><init>(I)V

    iget-object v4, v2, Ls6/l;->b:Ll9/C;

    new-instance v5, LB0/o;

    invoke-direct {v5, v4, v1, v3}, LB0/o;-><init>(Ll9/C;Ljavax/inject/Provider;Ls4/K;)V

    iget-object v3, v2, Ls6/l;->a:Ljavax/inject/Provider;

    iget-object v6, v2, Ls6/l;->c:Ljavax/inject/Provider;

    new-instance v7, LEe/a;

    move-object v8, v7

    move-object v9, v3

    move-object v10, v6

    move-object v11, v5

    move-object v12, v1

    move-object v13, v1

    invoke-direct/range {v8 .. v13}, LEe/a;-><init>(Ljavax/inject/Provider;Ljavax/inject/Provider;LB0/o;Ljavax/inject/Provider;Ljavax/inject/Provider;)V

    new-instance v15, Ly6/g;

    move-object v8, v15

    move-object v9, v4

    move-object v10, v6

    move-object v11, v1

    move-object v12, v5

    move-object v13, v3

    move-object v14, v1

    move-object v4, v15

    move-object v15, v1

    invoke-direct/range {v8 .. v15}, Ly6/g;-><init>(Ll9/C;Ljavax/inject/Provider;Ljavax/inject/Provider;LB0/o;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V

    new-instance v6, Lw/M;

    invoke-direct {v6, v3, v1, v5, v1}, Lw/M;-><init>(Ljavax/inject/Provider;Ljavax/inject/Provider;LB0/o;Ljavax/inject/Provider;)V

    new-instance v1, LH4/b;

    invoke-direct {v1, v7, v4, v6}, LH4/b;-><init>(LEe/a;Ly6/g;Lw/M;)V

    invoke-static {v1}, Lu6/a;->a(Ljavax/inject/Provider;)Ljavax/inject/Provider;

    move-result-object v1

    iput-object v1, v2, Ls6/l;->g:Ljavax/inject/Provider;

    return-object v2

    :cond_9a
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-class v3, Landroid/content/Context;

    invoke-virtual {v3}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " must be set"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method
