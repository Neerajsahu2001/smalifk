.class public abstract Lc8/j;
.super Ld8/d;
.source "SourceFile"

# interfaces
.implements Ld8/i;


# instance fields
.field public final a:LIa/j;

.field public final b:Lv7/j;

.field public final synthetic g:Lc8/m;


# direct methods
.method public constructor <init>(Lc8/m;LIa/j;Lv7/j;)V
    .registers 4

    iput-object p1, p0, Lc8/j;->g:Lc8/m;

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const-string p1, "com.google.android.play.core.appupdate.protocol.IAppUpdateServiceCallback"

    invoke-virtual {p0, p0, p1}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    iput-object p2, p0, Lc8/j;->a:LIa/j;

    iput-object p3, p0, Lc8/j;->b:Lv7/j;

    return-void
.end method


# virtual methods
.method public t(Landroid/os/Bundle;)V
    .registers 4

    iget-object p1, p0, Lc8/j;->g:Lc8/m;

    iget-object p1, p1, Lc8/m;->a:Ld8/r;

    iget-object v0, p0, Lc8/j;->b:Lv7/j;

    invoke-virtual {p1, v0}, Ld8/r;->c(Lv7/j;)V

    const/4 p1, 0x0

    new-array p1, p1, [Ljava/lang/Object;

    iget-object v0, p0, Lc8/j;->a:LIa/j;

    const-string v1, "onRequestInfo"

    invoke-virtual {v0, v1, p1}, LIa/j;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method

.method public y(Landroid/os/Bundle;)V
    .registers 4

    iget-object p1, p0, Lc8/j;->g:Lc8/m;

    iget-object p1, p1, Lc8/m;->a:Ld8/r;

    iget-object v0, p0, Lc8/j;->b:Lv7/j;

    invoke-virtual {p1, v0}, Ld8/r;->c(Lv7/j;)V

    const/4 p1, 0x0

    new-array p1, p1, [Ljava/lang/Object;

    iget-object v0, p0, Lc8/j;->a:LIa/j;

    const-string v1, "onCompleteUpdate"

    invoke-virtual {v0, v1, p1}, LIa/j;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method
