.class public LC7/n;
.super Lj/D;
.source "SourceFile"

# interfaces
.implements Lcom/newrelic/agent/android/api/v2/TraceFieldInterface;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# instance fields
.field public _nr_trace:Lcom/newrelic/agent/android/tracing/Trace;

.field private waitingForDismissAllowingStateLoss:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lj/D;-><init>()V

    return-void
.end method

.method public static access$100(LC7/n;)V
    .registers 2

    iget-boolean v0, p0, LC7/n;->waitingForDismissAllowingStateLoss:Z

    if-eqz v0, :cond_8

    invoke-super {p0}, Landroidx/fragment/app/s;->dismissAllowingStateLoss()V

    goto :goto_b

    :cond_8
    invoke-super {p0}, Landroidx/fragment/app/s;->dismiss()V

    :goto_b
    return-void
.end method


# virtual methods
.method public dismiss()V
    .registers 3

    invoke-virtual {p0}, Landroidx/fragment/app/s;->getDialog()Landroid/app/Dialog;

    move-result-object v0

    instance-of v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    if-eqz v1, :cond_15

    check-cast v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    iget-object v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->f:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    if-nez v1, :cond_11

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->g()V

    :cond_11
    iget-object v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->f:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget-boolean v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->G:Z

    :cond_15
    invoke-super {p0}, Landroidx/fragment/app/s;->dismiss()V

    return-void
.end method

.method public dismissAllowingStateLoss()V
    .registers 3

    invoke-virtual {p0}, Landroidx/fragment/app/s;->getDialog()Landroid/app/Dialog;

    move-result-object v0

    instance-of v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    if-eqz v1, :cond_15

    check-cast v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    iget-object v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->f:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    if-nez v1, :cond_11

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->g()V

    :cond_11
    iget-object v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->f:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget-boolean v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->G:Z

    :cond_15
    invoke-super {p0}, Landroidx/fragment/app/s;->dismissAllowingStateLoss()V

    return-void
.end method

.method public onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
    .registers 4

    new-instance p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/C;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/fragment/app/s;->getTheme()I

    move-result v1

    invoke-direct {p1, v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;-><init>(Landroid/content/Context;I)V

    return-object p1
.end method

.method public onStart()V
    .registers 1

    invoke-super {p0}, Landroidx/fragment/app/s;->onStart()V

    return-void
.end method

.method public onStop()V
    .registers 1

    invoke-super {p0}, Landroidx/fragment/app/s;->onStop()V

    return-void
.end method
