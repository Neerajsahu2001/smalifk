.class public abstract LC7/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public onLayout(Landroid/view/View;)V
    .registers 2

    return-void
.end method

.method public abstract onSlide(Landroid/view/View;F)V
.end method

.method public abstract onStateChanged(Landroid/view/View;I)V
.end method
