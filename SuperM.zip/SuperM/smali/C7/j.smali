.class public LC7/j;
.super Landroidx/core/view/b;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:Landroid/view/KeyEvent$Callback;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetDialog;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, LC7/j;->a:I

    iput-object p1, p0, LC7/j;->b:Landroid/view/KeyEvent$Callback;

    invoke-direct {p0}, Landroidx/core/view/b;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/textfield/TextInputLayout;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, LC7/j;->a:I

    invoke-direct {p0}, Landroidx/core/view/b;-><init>()V

    iput-object p1, p0, LC7/j;->b:Landroid/view/KeyEvent$Callback;

    return-void
.end method


# virtual methods
.method public onInitializeAccessibilityNodeInfo(Landroid/view/View;Lr0/k;)V
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iget v2, v0, LC7/j;->a:I

    packed-switch v2, :pswitch_data_f8

    invoke-super/range {p0 .. p2}, Landroidx/core/view/b;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Lr0/k;)V

    iget-object v2, v0, LC7/j;->b:Landroid/view/KeyEvent$Callback;

    check-cast v2, Lcom/google/android/material/textfield/TextInputLayout;

    iget-object v3, v2, Lcom/google/android/material/textfield/TextInputLayout;->e:Landroid/widget/EditText;

    const/4 v4, 0x0

    if-eqz v3, :cond_1a

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    goto :goto_1b

    :cond_1a
    move-object v3, v4

    :goto_1b
    invoke-virtual {v2}, Lcom/google/android/material/textfield/TextInputLayout;->f()Ljava/lang/CharSequence;

    move-result-object v5

    iget-object v6, v2, Lcom/google/android/material/textfield/TextInputLayout;->k:LY7/v;

    iget-boolean v7, v6, LY7/v;->k:Z

    if-eqz v7, :cond_28

    iget-object v7, v6, LY7/v;->j:Ljava/lang/CharSequence;

    goto :goto_29

    :cond_28
    move-object v7, v4

    :goto_29
    iget-boolean v8, v2, Lcom/google/android/material/textfield/TextInputLayout;->s:Z

    if-eqz v8, :cond_30

    iget-object v8, v2, Lcom/google/android/material/textfield/TextInputLayout;->r:Ljava/lang/CharSequence;

    goto :goto_31

    :cond_30
    move-object v8, v4

    :goto_31
    iget v9, v2, Lcom/google/android/material/textfield/TextInputLayout;->m:I

    iget-boolean v10, v2, Lcom/google/android/material/textfield/TextInputLayout;->l:Z

    if-eqz v10, :cond_43

    iget-boolean v10, v2, Lcom/google/android/material/textfield/TextInputLayout;->n:Z

    if-eqz v10, :cond_43

    iget-object v10, v2, Lcom/google/android/material/textfield/TextInputLayout;->o:Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v10, :cond_43

    invoke-virtual {v10}, Landroid/view/View;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v4

    :cond_43
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10

    xor-int/lit8 v11, v10, 0x1

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    const/4 v13, 0x1

    xor-int/2addr v12, v13

    iget-boolean v14, v2, Lcom/google/android/material/textfield/TextInputLayout;->s1:Z

    xor-int/2addr v14, v13

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v15

    xor-int/2addr v15, v13

    if-nez v15, :cond_61

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v16

    if-nez v16, :cond_60

    goto :goto_61

    :cond_60
    const/4 v13, 0x0

    :cond_61
    :goto_61
    if-eqz v12, :cond_68

    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_6a

    :cond_68
    const-string v5, ""

    :goto_6a
    iget-object v2, v2, Lcom/google/android/material/textfield/TextInputLayout;->b:LY7/C;

    iget-object v12, v2, LY7/C;->b:Landroidx/appcompat/widget/AppCompatTextView;

    invoke-virtual {v12}, Landroid/view/View;->getVisibility()I

    move-result v16

    iget-object v1, v1, Lr0/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-nez v16, :cond_7d

    invoke-virtual {v1, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLabelFor(Landroid/view/View;)V

    invoke-virtual {v1, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->setTraversalAfter(Landroid/view/View;)V

    goto :goto_82

    :cond_7d
    iget-object v2, v2, LY7/C;->d:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setTraversalAfter(Landroid/view/View;)V

    :goto_82
    if-eqz v11, :cond_88

    invoke-virtual {v1, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V

    goto :goto_b2

    :cond_88
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_ad

    invoke-virtual {v1, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V

    if-eqz v14, :cond_b2

    if-eqz v8, :cond_b2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v11, ", "

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V

    goto :goto_b2

    :cond_ad
    if-eqz v8, :cond_b2

    invoke-virtual {v1, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V

    :cond_b2
    :goto_b2
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_be

    invoke-virtual {v1, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setHintText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->setShowingHintText(Z)V

    :cond_be
    if-eqz v3, :cond_c7

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-ne v2, v9, :cond_c7

    goto :goto_c8

    :cond_c7
    const/4 v9, -0x1

    :goto_c8
    invoke-virtual {v1, v9}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMaxTextLength(I)V

    if-eqz v13, :cond_d4

    if-eqz v15, :cond_d0

    goto :goto_d1

    :cond_d0
    move-object v7, v4

    :goto_d1
    invoke-virtual {v1, v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->setError(Ljava/lang/CharSequence;)V

    :cond_d4
    iget-object v2, v6, LY7/v;->r:Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v2, :cond_db

    invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLabelFor(Landroid/view/View;)V

    :cond_db
    return-void

    :pswitch_dc
    invoke-super/range {p0 .. p2}, Landroidx/core/view/b;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Lr0/k;)V

    iget-object v2, v0, LC7/j;->b:Landroid/view/KeyEvent$Callback;

    check-cast v2, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    iget-boolean v2, v2, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->j:Z

    iget-object v3, v1, Lr0/k;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v2, :cond_f3

    const/high16 v2, 0x100000

    invoke-virtual {v1, v2}, Lr0/k;->a(I)V

    const/4 v1, 0x1

    invoke-virtual {v3, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setDismissable(Z)V

    goto :goto_f7

    :cond_f3
    const/4 v1, 0x0

    invoke-virtual {v3, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setDismissable(Z)V

    :goto_f7
    return-void

    :pswitch_data_f8
    .packed-switch 0x0
        :pswitch_dc
    .end packed-switch
.end method

.method public performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .registers 6

    iget v0, p0, LC7/j;->a:I

    packed-switch v0, :pswitch_data_20

    invoke-super {p0, p1, p2, p3}, Landroidx/core/view/b;->performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p1

    return p1

    :pswitch_a
    const/high16 v0, 0x100000

    if-ne p2, v0, :cond_1b

    iget-object v0, p0, LC7/j;->b:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    iget-boolean v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->j:Z

    if-eqz v1, :cond_1b

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->cancel()V

    const/4 p1, 0x1

    goto :goto_1f

    :cond_1b
    invoke-super {p0, p1, p2, p3}, Landroidx/core/view/b;->performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p1

    :goto_1f
    return p1

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method
