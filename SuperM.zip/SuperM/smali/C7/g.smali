.class public final LC7/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    const/16 v0, 0xd

    iput v0, p0, LC7/g;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC7/g;->a:I

    iput-object p2, p0, LC7/g;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lr7/Q;Z)V
    .registers 3

    const/16 p2, 0xc

    iput p2, p0, LC7/g;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC7/g;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a()V
    .registers 11

    const/4 v0, 0x0

    move v1, v0

    :goto_2
    :try_start_2
    iget-object v2, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v2, LF/m;

    iget-object v2, v2, LF/m;->a:Ljava/util/ArrayDeque;

    monitor-enter v2
    :try_end_9
    .catchall {:try_start_2 .. :try_end_9} :catchall_55

    const/4 v3, 0x1

    if-nez v0, :cond_2c

    :try_start_c
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, LF/m;

    iget v4, v0, LF/m;->d:I

    const/4 v5, 0x4

    if-ne v4, v5, :cond_22

    monitor-exit v2
    :try_end_16
    .catchall {:try_start_c .. :try_end_16} :catchall_20

    if-eqz v1, :cond_1f

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    :cond_1f
    return-void

    :catchall_20
    move-exception v0

    goto :goto_6f

    :cond_22
    :try_start_22
    iget-wide v6, v0, LF/m;->e:J

    const-wide/16 v8, 0x1

    add-long/2addr v6, v8

    iput-wide v6, v0, LF/m;->e:J

    iput v5, v0, LF/m;->d:I

    move v0, v3

    :cond_2c
    iget-object v4, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v4, LF/m;

    iget-object v4, v4, LF/m;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v4}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Runnable;

    if-nez v4, :cond_4b

    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, LF/m;

    iput v3, v0, LF/m;->d:I

    monitor-exit v2
    :try_end_41
    .catchall {:try_start_22 .. :try_end_41} :catchall_20

    if-eqz v1, :cond_4a

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    :cond_4a
    return-void

    :cond_4b
    :try_start_4b
    monitor-exit v2
    :try_end_4c
    .catchall {:try_start_4b .. :try_end_4c} :catchall_20

    :try_start_4c
    invoke-static {}, Ljava/lang/Thread;->interrupted()Z

    move-result v2
    :try_end_50
    .catchall {:try_start_4c .. :try_end_50} :catchall_55

    or-int/2addr v1, v2

    :try_start_51
    invoke-interface {v4}, Ljava/lang/Runnable;->run()V
    :try_end_54
    .catch Ljava/lang/RuntimeException; {:try_start_51 .. :try_end_54} :catch_57
    .catchall {:try_start_51 .. :try_end_54} :catchall_55

    goto :goto_2

    :catchall_55
    move-exception v0

    goto :goto_71

    :catch_57
    move-exception v2

    :try_start_58
    const-string v3, "SequentialExecutor"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Exception while executing runnable "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4, v2}, LHe/b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_6e
    .catchall {:try_start_58 .. :try_end_6e} :catchall_55

    goto :goto_2

    :goto_6f
    :try_start_6f
    monitor-exit v2
    :try_end_70
    .catchall {:try_start_6f .. :try_end_70} :catchall_20

    :try_start_70
    throw v0
    :try_end_71
    .catchall {:try_start_70 .. :try_end_71} :catchall_55

    :goto_71
    if-eqz v1, :cond_7a

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    :cond_7a
    throw v0
.end method

.method public final run()V
    .registers 9

    iget v0, p0, LC7/g;->a:I

    packed-switch v0, :pswitch_data_288

    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Lr7/A1;

    iget-object v1, v0, Lr7/A1;->c:Lr7/q1;

    new-instance v2, Landroid/content/ComponentName;

    iget-object v0, v0, Lr7/A1;->c:Lr7/q1;

    iget-object v0, v0, LJ1/e;->b:Ljava/lang/Object;

    check-cast v0, Lr7/j0;

    iget-object v0, v0, Lr7/j0;->a:Landroid/content/Context;

    const-string v3, "com.google.android.gms.measurement.AppMeasurementService"

    invoke-direct {v2, v0, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v1}, Lr7/u;->x0()V

    iget-object v0, v1, Lr7/q1;->e:Lr7/y;

    if-eqz v0, :cond_35

    const/4 v0, 0x0

    iput-object v0, v1, Lr7/q1;->e:Lr7/y;

    invoke-virtual {v1}, LJ1/e;->zzj()Lr7/I;

    move-result-object v0

    const-string v3, "Disconnected from device MeasurementService"

    iget-object v0, v0, Lr7/I;->o:Lr7/K;

    invoke-virtual {v0, v2, v3}, Lr7/K;->a(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Lr7/u;->x0()V

    invoke-virtual {v1}, Lr7/q1;->J0()V

    :cond_35
    return-void

    :pswitch_36
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Lr7/q1;

    iget-object v1, v0, Lr7/q1;->e:Lr7/y;

    if-nez v1, :cond_4a

    invoke-virtual {v0}, LJ1/e;->zzj()Lr7/I;

    move-result-object v0

    const-string v1, "Failed to send Dma consent settings to service"

    iget-object v0, v0, Lr7/I;->g:Lr7/K;

    invoke-virtual {v0, v1}, Lr7/K;->c(Ljava/lang/String;)V

    goto :goto_62

    :cond_4a
    const/4 v2, 0x0

    :try_start_4b
    invoke-virtual {v0, v2}, Lr7/q1;->Q0(Z)Lcom/google/android/gms/measurement/internal/zzo;

    move-result-object v2

    invoke-interface {v1, v2}, Lr7/y;->C(Lcom/google/android/gms/measurement/internal/zzo;)V

    invoke-virtual {v0}, Lr7/q1;->P0()V
    :try_end_55
    .catch Landroid/os/RemoteException; {:try_start_4b .. :try_end_55} :catch_56

    goto :goto_62

    :catch_56
    move-exception v1

    invoke-virtual {v0}, LJ1/e;->zzj()Lr7/I;

    move-result-object v0

    const-string v2, "Failed to send Dma consent settings to the service"

    iget-object v0, v0, Lr7/I;->g:Lr7/K;

    invoke-virtual {v0, v1, v2}, Lr7/K;->a(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_62
    return-void

    :pswitch_63
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Lr7/Q;

    iget-object v0, v0, Lr7/Q;->a:Lr7/O1;

    invoke-virtual {v0}, Lr7/O1;->B()V

    return-void

    :pswitch_6d
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, LAa/s;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_74
    :try_start_74
    iget-object v1, v0, LAa/s;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/ref/ReferenceQueue;

    invoke-virtual {v1}, Ljava/lang/ref/ReferenceQueue;->remove()Ljava/lang/ref/Reference;

    move-result-object v1

    check-cast v1, Ll4/b;

    invoke-virtual {v0, v1}, LAa/s;->y(Ll4/b;)V
    :try_end_81
    .catch Ljava/lang/InterruptedException; {:try_start_74 .. :try_end_81} :catch_82

    goto :goto_74

    :catch_82
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    goto :goto_74

    :pswitch_8a
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, LHc/a;

    invoke-interface {v0}, LHc/a;->invoke()Ljava/lang/Object;

    return-void

    :pswitch_92
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Transformation "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v2, Lcom/freshchat/consumer/sdk/util/am;

    invoke-virtual {v2}, Lcom/freshchat/consumer/sdk/util/am;->key()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " returned input Bitmap but recycled it."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_b3
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/G;

    iget-object v0, v0, Landroidx/lifecycle/G;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_ba
    iget-object v1, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/lifecycle/G;

    iget-object v1, v1, Landroidx/lifecycle/G;->f:Ljava/lang/Object;

    iget-object v2, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v2, Landroidx/lifecycle/G;

    sget-object v3, Landroidx/lifecycle/G;->k:Ljava/lang/Object;

    iput-object v3, v2, Landroidx/lifecycle/G;->f:Ljava/lang/Object;

    monitor-exit v0
    :try_end_c9
    .catchall {:try_start_ba .. :try_end_c9} :catchall_d1

    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/G;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/G;->j(Ljava/lang/Object;)V

    return-void

    :catchall_d1
    move-exception v1

    :try_start_d2
    monitor-exit v0
    :try_end_d3
    .catchall {:try_start_d2 .. :try_end_d3} :catchall_d1

    throw v1

    :pswitch_d4
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/appcompat/widget/SearchView;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_dc
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/appcompat/widget/ListPopupWindow;

    iget-object v1, v0, Landroidx/appcompat/widget/ListPopupWindow;->c:Landroidx/appcompat/widget/n0;

    if-eqz v1, :cond_10b

    invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_10b

    iget-object v1, v0, Landroidx/appcompat/widget/ListPopupWindow;->c:Landroidx/appcompat/widget/n0;

    invoke-virtual {v1}, Landroid/widget/AdapterView;->getCount()I

    move-result v1

    iget-object v2, v0, Landroidx/appcompat/widget/ListPopupWindow;->c:Landroidx/appcompat/widget/n0;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    if-le v1, v2, :cond_10b

    iget-object v1, v0, Landroidx/appcompat/widget/ListPopupWindow;->c:Landroidx/appcompat/widget/n0;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    iget v2, v0, Landroidx/appcompat/widget/ListPopupWindow;->m:I

    if-gt v1, v2, :cond_10b

    iget-object v1, v0, Landroidx/appcompat/widget/ListPopupWindow;->y:Landroid/widget/PopupWindow;

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    invoke-virtual {v0}, Landroidx/appcompat/widget/ListPopupWindow;->show()V

    :cond_10b
    return-void

    :pswitch_10c
    const/4 v0, 0x0

    iget-object v1, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/appcompat/widget/n0;

    iput-object v0, v1, Landroidx/appcompat/widget/n0;->l:LC7/g;

    invoke-virtual {v1}, Landroidx/appcompat/widget/n0;->drawableStateChanged()V

    return-void

    :pswitch_117
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;

    iget-object v1, v0, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->T0:Ljava/lang/String;

    const-string v2, ""

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v3, "DB011"

    const-string v4, "Unknown Error"

    if-nez v1, :cond_165

    iget-object v1, v0, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->H:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_161

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lwe/g;

    invoke-direct {v1, v0}, Lwe/g;-><init>(Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;)V

    iget-boolean v2, v1, Lwe/g;->c:Z

    if-eqz v2, :cond_15d

    iget-object v2, v1, Lwe/g;->d:Landroid/location/Location;

    if-eqz v2, :cond_147

    invoke-virtual {v2}, Landroid/location/Location;->getLatitude()D

    move-result-wide v2

    iput-wide v2, v1, Lwe/g;->e:D

    :cond_147
    iget-wide v2, v1, Lwe/g;->e:D

    iput-wide v2, v0, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->W0:D

    iget-object v2, v1, Lwe/g;->d:Landroid/location/Location;

    if-eqz v2, :cond_155

    invoke-virtual {v2}, Landroid/location/Location;->getLongitude()D

    move-result-wide v2

    iput-wide v2, v1, Lwe/g;->f:D

    :cond_155
    iget-wide v1, v1, Lwe/g;->f:D

    iput-wide v1, v0, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->X0:D

    invoke-virtual {v0, v0}, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->b0(Landroid/content/Context;)V

    goto :goto_168

    :cond_15d
    invoke-virtual {v0, v0}, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->b0(Landroid/content/Context;)V

    goto :goto_168

    :cond_161
    invoke-virtual {v0, v4, v3}, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->f0(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_168

    :cond_165
    invoke-virtual {v0, v4, v3}, Lcom/ybl/ypp/sdk/SendOutwardSMSActivity;->f0(Ljava/lang/String;Ljava/lang/String;)V

    :goto_168
    return-void

    :pswitch_169
    sget-object v0, LP8/i;->b:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Deque;

    invoke-static {v0}, LO6/A;->i(Ljava/lang/Object;)V

    iget-object v1, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Runnable;

    invoke-interface {v0, v1}, Ljava/util/Deque;->add(Ljava/lang/Object;)Z

    invoke-interface {v0}, Ljava/util/Deque;->size()I

    move-result v2

    const/4 v3, 0x1

    if-gt v2, v3, :cond_190

    :cond_182
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    invoke-interface {v0}, Ljava/util/Deque;->removeFirst()Ljava/lang/Object;

    invoke-interface {v0}, Ljava/util/Deque;->peekFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Runnable;

    if-nez v1, :cond_182

    :cond_190
    return-void

    :goto_191
    :pswitch_191
    iget-object v0, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v0, LK6/l;

    monitor-enter v0

    :try_start_196
    iget v1, v0, LK6/l;->a:I

    const/4 v2, 0x2

    if-eq v1, v2, :cond_1a0

    monitor-exit v0

    goto :goto_1ac

    :catchall_19d
    move-exception v1

    goto/16 :goto_24a

    :cond_1a0
    iget-object v1, v0, LK6/l;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1ad

    invoke-virtual {v0}, LK6/l;->c()V

    monitor-exit v0

    :goto_1ac
    return-void

    :cond_1ad
    iget-object v1, v0, LK6/l;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LK6/n;

    iget-object v3, v0, LK6/l;->e:Landroid/util/SparseArray;

    iget v4, v1, LK6/n;->a:I

    invoke-virtual {v3, v4, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iget-object v3, v0, LK6/l;->f:LK6/q;

    iget-object v3, v3, LK6/q;->b:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v4, LK6/k;

    const/4 v5, 0x0

    invoke-direct {v4, v5, v0, v1}, LK6/k;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v6, 0x1e

    invoke-interface {v3, v4, v6, v7, v5}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    monitor-exit v0
    :try_end_1ce
    .catchall {:try_start_196 .. :try_end_1ce} :catchall_19d

    const-string v3, "MessengerIpcClient"

    const/4 v4, 0x3

    invoke-static {v3, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v3

    if-eqz v3, :cond_1e6

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "Sending "

    const-string v5, "MessengerIpcClient"

    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Lcom/newrelic/agent/android/instrumentation/LogInstrumentation;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1e6
    iget-object v3, v0, LK6/l;->f:LK6/q;

    iget-object v4, v0, LK6/l;->b:Landroid/os/Messenger;

    iget v5, v1, LK6/n;->c:I

    iget-object v3, v3, LK6/q;->a:Landroid/content/Context;

    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v6

    iput v5, v6, Landroid/os/Message;->what:I

    iget v5, v1, LK6/n;->a:I

    iput v5, v6, Landroid/os/Message;->arg1:I

    iput-object v4, v6, Landroid/os/Message;->replyTo:Landroid/os/Messenger;

    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {v1}, LK6/n;->b()Z

    move-result v5

    const-string v7, "oneWay"

    invoke-virtual {v4, v7, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const-string v5, "pkg"

    invoke-virtual {v4, v5, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, v1, LK6/n;->d:Landroid/os/Bundle;

    const-string v3, "data"

    invoke-virtual {v4, v3, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    invoke-virtual {v6, v4}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    :try_start_21b
    iget-object v1, v0, LK6/l;->c:LAa/t;

    iget-object v3, v1, LAa/t;->b:Ljava/lang/Object;

    check-cast v3, Landroid/os/Messenger;

    if-eqz v3, :cond_228

    invoke-virtual {v3, v6}, Landroid/os/Messenger;->send(Landroid/os/Message;)V

    goto/16 :goto_191

    :cond_228
    iget-object v1, v1, LAa/t;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/cloudmessaging/zzd;

    if-eqz v1, :cond_238

    iget-object v1, v1, Lcom/google/android/gms/cloudmessaging/zzd;->a:Landroid/os/Messenger;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v6}, Landroid/os/Messenger;->send(Landroid/os/Message;)V

    goto/16 :goto_191

    :cond_238
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v3, "Both messengers are null"

    invoke-direct {v1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_240
    .catch Landroid/os/RemoteException; {:try_start_21b .. :try_end_240} :catch_240

    :catch_240
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v2, v1}, LK6/l;->a(ILjava/lang/String;)V

    goto/16 :goto_191

    :goto_24a
    :try_start_24a
    monitor-exit v0
    :try_end_24b
    .catchall {:try_start_24a .. :try_end_24b} :catchall_19d

    throw v1

    :pswitch_24c
    :try_start_24c
    invoke-virtual {p0}, LC7/g;->a()V
    :try_end_24f
    .catch Ljava/lang/Error; {:try_start_24c .. :try_end_24f} :catch_250

    return-void

    :catch_250
    move-exception v0

    iget-object v1, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v1, LF/m;

    iget-object v1, v1, LF/m;->a:Ljava/util/ArrayDeque;

    monitor-enter v1

    :try_start_258
    iget-object v2, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v2, LF/m;

    const/4 v3, 0x1

    iput v3, v2, LF/m;->d:I

    monitor-exit v1
    :try_end_260
    .catchall {:try_start_258 .. :try_end_260} :catchall_261

    throw v0

    :catchall_261
    move-exception v0

    :try_start_262
    monitor-exit v1
    :try_end_263
    .catchall {:try_start_262 .. :try_end_263} :catchall_261

    throw v0

    :pswitch_264
    const/4 v0, 0x0

    iget-object v1, p0, LC7/g;->b:Ljava/lang/Object;

    check-cast v1, LC7/h;

    iput-boolean v0, v1, LC7/h;->b:Z

    iget-object v0, v1, LC7/h;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget-object v2, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:Lz0/c;

    if-eqz v2, :cond_27d

    invoke-virtual {v2}, Lz0/c;->h()Z

    move-result v2

    if-eqz v2, :cond_27d

    iget v0, v1, LC7/h;->a:I

    invoke-virtual {v1, v0}, LC7/h;->a(I)V

    goto :goto_287

    :cond_27d
    iget v2, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:I

    const/4 v3, 0x2

    if-ne v2, v3, :cond_287

    iget v1, v1, LC7/h;->a:I

    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D(I)V

    :cond_287
    :goto_287
    return-void

    :pswitch_data_288
    .packed-switch 0x0
        :pswitch_264
        :pswitch_24c
        :pswitch_191
        :pswitch_169
        :pswitch_117
        :pswitch_10c
        :pswitch_dc
        :pswitch_d4
        :pswitch_b3
        :pswitch_92
        :pswitch_8a
        :pswitch_6d
        :pswitch_63
        :pswitch_36
    .end packed-switch
.end method
