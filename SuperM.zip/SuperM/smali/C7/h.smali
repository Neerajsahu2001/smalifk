.class public final LC7/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:Z

.field public final c:LC7/g;

.field public final synthetic d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC7/h;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    new-instance p1, LC7/g;

    const/4 v0, 0x0

    invoke-direct {p1, v0, p0}, LC7/g;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LC7/h;->c:LC7/g;

    return-void
.end method


# virtual methods
.method public final a(I)V
    .registers 4

    iget-object v0, p0, LC7/h;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget-object v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    if-eqz v1, :cond_25

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_d

    goto :goto_25

    :cond_d
    iput p1, p0, LC7/h;->a:I

    iget-boolean p1, p0, LC7/h;->b:Z

    if-nez p1, :cond_25

    iget-object p1, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    sget-object v0, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    iget-object v0, p0, LC7/h;->c:LC7/g;

    invoke-virtual {p1, v0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, LC7/h;->b:Z

    :cond_25
    :goto_25
    return-void
.end method
