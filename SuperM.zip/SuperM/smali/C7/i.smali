.class public final LC7/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC7/i;->a:I

    iput-object p2, p0, LC7/i;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 9

    iget v0, p0, LC7/i;->a:I

    packed-switch v0, :pswitch_data_a2

    iget-object v0, p0, LC7/i;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/ui/TrackSelectionView;

    iget-object v1, v0, Landroidx/media3/ui/TrackSelectionView;->b:Landroid/widget/CheckedTextView;

    iget-object v2, v0, Landroidx/media3/ui/TrackSelectionView;->c:Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v6, v0, Landroidx/media3/ui/TrackSelectionView;->a:Landroid/widget/CheckedTextView;

    if-ne p1, v6, :cond_1a

    iput-boolean v4, v0, Landroidx/media3/ui/TrackSelectionView;->d:Z

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    goto :goto_21

    :cond_1a
    if-ne p1, v1, :cond_36

    iput-boolean v5, v0, Landroidx/media3/ui/TrackSelectionView;->d:Z

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    :goto_21
    iget-boolean p1, v0, Landroidx/media3/ui/TrackSelectionView;->d:Z

    invoke-virtual {v6, p1}, Landroid/widget/CheckedTextView;->setChecked(Z)V

    iget-boolean p1, v0, Landroidx/media3/ui/TrackSelectionView;->d:Z

    if-nez p1, :cond_31

    invoke-virtual {v2}, Ljava/util/HashMap;->size()I

    move-result p1

    if-nez p1, :cond_31

    goto :goto_32

    :cond_31
    move v4, v5

    :goto_32
    invoke-virtual {v1, v4}, Landroid/widget/CheckedTextView;->setChecked(Z)V

    throw v3

    :cond_36
    iput-boolean v5, v0, Landroidx/media3/ui/TrackSelectionView;->d:Z

    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, LA8/v;->p(Ljava/lang/Object;)V

    throw v3

    :pswitch_43
    iget-object p1, p0, LC7/i;->b:Ljava/lang/Object;

    check-cast p1, LY7/f;

    iget-object v0, p1, LY7/s;->a:Lcom/google/android/material/textfield/TextInputLayout;

    iget-object v0, v0, Lcom/google/android/material/textfield/TextInputLayout;->e:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    if-eqz v0, :cond_54

    invoke-interface {v0}, Landroid/text/Editable;->clear()V

    :cond_54
    iget-object p1, p1, LY7/s;->a:Lcom/google/android/material/textfield/TextInputLayout;

    iget-object v0, p1, Lcom/google/android/material/textfield/TextInputLayout;->W0:Lcom/google/android/material/internal/CheckableImageButton;

    iget-object v1, p1, Lcom/google/android/material/textfield/TextInputLayout;->Y0:Landroid/content/res/ColorStateList;

    invoke-static {p1, v0, v1}, Lm7/j;->b(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V

    return-void

    :pswitch_5e
    iget-object p1, p0, LC7/i;->b:Ljava/lang/Object;

    check-cast p1, Landroidx/viewpager/widget/PagerTabStrip;

    iget-object p1, p1, Landroidx/viewpager/widget/PagerTitleStrip;->a:Landroidx/viewpager/widget/ViewPager;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/viewpager/widget/ViewPager;->l(Z)V

    return-void

    :pswitch_6c
    iget-object p1, p0, LC7/i;->b:Ljava/lang/Object;

    check-cast p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;

    iget-boolean v0, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->j:Z

    if-eqz v0, :cond_a1

    invoke-virtual {p1}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_a1

    iget-boolean v0, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->l:Z

    if-nez v0, :cond_9a

    invoke-virtual {p1}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x101035b

    filled-new-array {v1}, [I

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->k:Z

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    iput-boolean v2, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->l:Z

    :cond_9a
    iget-boolean v0, p1, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->k:Z

    if-eqz v0, :cond_a1

    invoke-virtual {p1}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->cancel()V

    :cond_a1
    return-void

    :pswitch_data_a2
    .packed-switch 0x0
        :pswitch_6c
        :pswitch_5e
        :pswitch_43
    .end packed-switch
.end method
