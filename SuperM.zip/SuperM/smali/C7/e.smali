.class public final LC7/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr0/t;


# instance fields
.field public a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LZ0/w;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, LZ0/w;-><init>(I)V

    iput-object v0, p0, LC7/e;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, LC7/e;->b:Ljava/lang/Object;

    iput p1, p0, LC7/e;->a:I

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC7/e;->b:Ljava/lang/Object;

    iput p2, p0, LC7/e;->a:I

    return-void
.end method

.method public constructor <init>(Ll7/J0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC7/e;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    iput p1, p0, LC7/e;->a:I

    return-void
.end method


# virtual methods
.method public a()Lj8/m0;
    .registers 4

    iget-object v0, p0, LC7/e;->b:Ljava/lang/Object;

    check-cast v0, Ll7/J0;

    invoke-virtual {v0}, Ll7/J0;->f()Ljava/util/Map;

    move-result-object v0

    new-instance v1, Lj8/l0;

    iget v2, p0, LC7/e;->a:I

    invoke-direct {v1, v2}, Lj8/l0;-><init>(I)V

    new-instance v2, Lj8/m0;

    invoke-direct {v2, v0}, Lj8/c;-><init>(Ljava/util/Map;)V

    iput-object v1, v2, Lj8/m0;->f:Li8/l;

    return-object v2
.end method

.method public b(Ljava/util/Map;Lio/sentry/ILogger;)Ljava/util/HashMap;
    .registers 7

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_32

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {p1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_29

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, p2, v3}, LC7/e;->d(Lio/sentry/ILogger;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_d

    :cond_29
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_d

    :cond_32
    return-object v0
.end method

.method public c(LD1/o;)J
    .registers 9

    iget-object v0, p0, LC7/e;->b:Ljava/lang/Object;

    check-cast v0, LZ0/w;

    iget-object v1, v0, LZ0/w;->a:[B

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v1, v2, v3, v2}, LD1/o;->d([BIIZ)Z

    iget-object v1, v0, LZ0/w;->a:[B

    aget-byte v1, v1, v2

    and-int/lit16 v1, v1, 0xff

    if-nez v1, :cond_16

    const-wide/high16 v0, -0x8000000000000000L

    return-wide v0

    :cond_16
    const/16 v4, 0x80

    move v5, v2

    :goto_19
    and-int v6, v1, v4

    if-nez v6, :cond_22

    shr-int/lit8 v4, v4, 0x1

    add-int/lit8 v5, v5, 0x1

    goto :goto_19

    :cond_22
    not-int v4, v4

    and-int/2addr v1, v4

    iget-object v4, v0, LZ0/w;->a:[B

    invoke-virtual {p1, v4, v3, v5, v2}, LD1/o;->d([BIIZ)Z

    :goto_29
    if-ge v2, v5, :cond_37

    shl-int/lit8 p1, v1, 0x8

    iget-object v1, v0, LZ0/w;->a:[B

    add-int/lit8 v2, v2, 0x1

    aget-byte v1, v1, v2

    and-int/lit16 v1, v1, 0xff

    add-int/2addr v1, p1

    goto :goto_29

    :cond_37
    iget p1, p0, LC7/e;->a:I

    add-int/2addr v5, v3

    add-int/2addr v5, p1

    iput v5, p0, LC7/e;->a:I

    int-to-long v0, v1

    return-wide v0
.end method

.method public d(Lio/sentry/ILogger;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    const/4 v0, 0x0

    if-nez p2, :cond_4

    return-object v0

    :cond_4
    instance-of v1, p2, Ljava/lang/Character;

    if-eqz v1, :cond_d

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_d
    instance-of v1, p2, Ljava/lang/Number;

    if-eqz v1, :cond_12

    return-object p2

    :cond_12
    instance-of v1, p2, Ljava/lang/Boolean;

    if-eqz v1, :cond_17

    return-object p2

    :cond_17
    instance-of v1, p2, Ljava/lang/String;

    if-eqz v1, :cond_1c

    return-object p2

    :cond_1c
    instance-of v1, p2, Ljava/util/Locale;

    if-eqz v1, :cond_25

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_25
    instance-of v1, p2, Ljava/util/concurrent/atomic/AtomicIntegerArray;

    const/4 v2, 0x0

    if-eqz v1, :cond_48

    check-cast p2, Ljava/util/concurrent/atomic/AtomicIntegerArray;

    sget-object p1, Lio/sentry/util/a;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicIntegerArray;->length()I

    move-result p1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_37
    if-ge v2, p1, :cond_47

    invoke-virtual {p2, v2}, Ljava/util/concurrent/atomic/AtomicIntegerArray;->get(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_37

    :cond_47
    return-object v0

    :cond_48
    instance-of v1, p2, Ljava/util/concurrent/atomic/AtomicBoolean;

    if-eqz v1, :cond_57

    check-cast p2, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    :cond_57
    instance-of v1, p2, Ljava/net/URI;

    if-eqz v1, :cond_60

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_60
    instance-of v1, p2, Ljava/net/InetAddress;

    if-eqz v1, :cond_69

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_69
    instance-of v1, p2, Ljava/util/UUID;

    if-eqz v1, :cond_72

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_72
    instance-of v1, p2, Ljava/util/Currency;

    if-eqz v1, :cond_7b

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_7b
    instance-of v1, p2, Ljava/util/Calendar;

    if-eqz v1, :cond_86

    check-cast p2, Ljava/util/Calendar;

    invoke-static {p2}, Lio/sentry/util/a;->a(Ljava/util/Calendar;)Ljava/util/HashMap;

    move-result-object p1

    return-object p1

    :cond_86
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->isEnum()Z

    move-result v1

    if-eqz v1, :cond_95

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_95
    iget-object v1, p0, LC7/e;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashSet;

    invoke-virtual {v1, p2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_ad

    sget-object v0, Lio/sentry/y1;->INFO:Lio/sentry/y1;

    const-string v1, "Cyclic reference detected. Calling toString() on object."

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {p1, v0, v1, v2}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_ad
    invoke-virtual {v1, p2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result v3

    iget v4, p0, LC7/e;->a:I

    if-le v3, v4, :cond_c9

    invoke-virtual {v1, p2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    sget-object v0, Lio/sentry/y1;->INFO:Lio/sentry/y1;

    const-string v1, "Max depth exceeded. Calling toString() on object."

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {p1, v0, v1, v2}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_c9
    :try_start_c9
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->isArray()Z

    move-result v3

    if-eqz v3, :cond_f0

    move-object v3, p2

    check-cast v3, [Ljava/lang/Object;

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    array-length v5, v3

    :goto_dc
    if-ge v2, v5, :cond_ea

    aget-object v6, v3, v2

    invoke-virtual {p0, p1, v6}, LC7/e;->d(Lio/sentry/ILogger;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_dc

    :cond_ea
    move-object v0, v4

    goto :goto_131

    :catchall_ec
    move-exception p1

    goto :goto_13e

    :catch_ee
    move-exception v2

    goto :goto_135

    :cond_f0
    instance-of v2, p2, Ljava/util/Collection;

    if-eqz v2, :cond_114

    move-object v2, p2

    check-cast v2, Ljava/util/Collection;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_100
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_112

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {p0, p1, v4}, LC7/e;->d(Lio/sentry/ILogger;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_100

    :cond_112
    move-object v0, v3

    goto :goto_131

    :cond_114
    instance-of v2, p2, Ljava/util/Map;

    if-eqz v2, :cond_121

    move-object v2, p2

    check-cast v2, Ljava/util/Map;

    invoke-virtual {p0, v2, p1}, LC7/e;->b(Ljava/util/Map;Lio/sentry/ILogger;)Ljava/util/HashMap;

    move-result-object p1

    :goto_11f
    move-object v0, p1

    goto :goto_131

    :cond_121
    invoke-virtual {p0, p1, p2}, LC7/e;->e(Lio/sentry/ILogger;Ljava/lang/Object;)Ljava/util/HashMap;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/HashMap;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_130

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_12f
    .catch Ljava/lang/Exception; {:try_start_c9 .. :try_end_12f} :catch_ee
    .catchall {:try_start_c9 .. :try_end_12f} :catchall_ec

    goto :goto_11f

    :cond_130
    move-object v0, v2

    :goto_131
    invoke-virtual {v1, p2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    goto :goto_13d

    :goto_135
    :try_start_135
    sget-object v3, Lio/sentry/y1;->INFO:Lio/sentry/y1;

    const-string v4, "Not serializing object due to throwing sub-path."

    invoke-interface {p1, v3, v4, v2}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_13c
    .catchall {:try_start_135 .. :try_end_13c} :catchall_ec

    goto :goto_131

    :goto_13d
    return-object v0

    :goto_13e
    invoke-virtual {v1, p2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    throw p1
.end method

.method public e(Lio/sentry/ILogger;Ljava/lang/Object;)Ljava/util/HashMap;
    .registers 12

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v0

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    array-length v2, v0

    const/4 v3, 0x0

    move v4, v3

    :goto_10
    if-ge v4, v2, :cond_53

    aget-object v5, v0, v4

    invoke-virtual {v5}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v6

    invoke-static {v6}, Ljava/lang/reflect/Modifier;->isTransient(I)Z

    move-result v6

    if-eqz v6, :cond_1f

    goto :goto_50

    :cond_1f
    invoke-virtual {v5}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v6

    invoke-static {v6}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v6

    if-eqz v6, :cond_2a

    goto :goto_50

    :cond_2a
    invoke-virtual {v5}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    :try_start_2f
    invoke-virtual {v5, v7}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v5, p2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {p0, p1, v7}, LC7/e;->d(Lio/sentry/ILogger;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v1, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v5, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_40
    .catch Ljava/lang/Exception; {:try_start_2f .. :try_end_40} :catch_41

    goto :goto_50

    :catch_41
    sget-object v5, Lio/sentry/y1;->INFO:Lio/sentry/y1;

    const-string v7, "Cannot access field "

    const-string v8, "."

    invoke-static {v7, v6, v8}, Le/b;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v7, v3, [Ljava/lang/Object;

    invoke-interface {p1, v5, v6, v7}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_50
    add-int/lit8 v4, v4, 0x1

    goto :goto_10

    :cond_53
    return-object v1
.end method

.method public l(Landroid/view/View;)Z
    .registers 3

    iget-object p1, p0, LC7/e;->b:Ljava/lang/Object;

    check-cast p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget v0, p0, LC7/e;->a:I

    invoke-virtual {p1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C(I)V

    const/4 p1, 0x1

    return p1
.end method
