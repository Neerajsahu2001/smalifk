.class public final LC7/m;
.super LC7/f;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:Landroidx/core/view/Q0;


# direct methods
.method public constructor <init>(Landroid/view/View;Landroidx/core/view/Q0;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LC7/m;->c:Landroidx/core/view/Q0;

    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result p2

    and-int/lit16 p2, p2, 0x2000

    if-eqz p2, :cond_f

    const/4 p2, 0x1

    goto :goto_10

    :cond_f
    const/4 p2, 0x0

    :goto_10
    iput-boolean p2, p0, LC7/m;->b:Z

    invoke-static {p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w(Landroid/view/View;)Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v0

    iget-object v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->h:Lcom/google/android/material/shape/MaterialShapeDrawable;

    if-eqz v0, :cond_1f

    iget-object v0, v0, Lcom/google/android/material/shape/MaterialShapeDrawable;->a:LU7/g;

    iget-object v0, v0, LU7/g;->c:Landroid/content/res/ColorStateList;

    goto :goto_25

    :cond_1f
    sget-object v0, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    invoke-static {p1}, Landroidx/core/view/U;->g(Landroid/view/View;)Landroid/content/res/ColorStateList;

    move-result-object v0

    :goto_25
    if-eqz v0, :cond_32

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result p1

    invoke-static {p1}, Ll7/L4;->d(I)Z

    move-result p1

    iput-boolean p1, p0, LC7/m;->a:Z

    goto :goto_4d

    :cond_32
    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v0, v0, Landroid/graphics/drawable/ColorDrawable;

    if-eqz v0, :cond_4b

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    check-cast p1, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {p1}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result p1

    invoke-static {p1}, Ll7/L4;->d(I)Z

    move-result p1

    iput-boolean p1, p0, LC7/m;->a:Z

    goto :goto_4d

    :cond_4b
    iput-boolean p2, p0, LC7/m;->a:Z

    :goto_4d
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;)V
    .registers 6

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    iget-object v1, p0, LC7/m;->c:Landroidx/core/view/Q0;

    invoke-virtual {v1}, Landroidx/core/view/Q0;->d()I

    move-result v2

    if-ge v0, v2, :cond_37

    sget v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->p:I

    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v0

    iget-boolean v2, p0, LC7/m;->a:Z

    if-eqz v2, :cond_19

    or-int/lit16 v0, v0, 0x2000

    goto :goto_1b

    :cond_19
    and-int/lit16 v0, v0, -0x2001

    :goto_1b
    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    invoke-virtual {v1}, Landroidx/core/view/Q0;->d()I

    move-result v1

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v2

    sub-int/2addr v1, v2

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/view/View;->setPadding(IIII)V

    goto :goto_5f

    :cond_37
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    if-eqz v0, :cond_5f

    sget v0, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->p:I

    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v0

    iget-boolean v1, p0, LC7/m;->b:Z

    if-eqz v1, :cond_4a

    or-int/lit16 v0, v0, 0x2000

    goto :goto_4c

    :cond_4a
    and-int/lit16 v0, v0, -0x2001

    :goto_4c
    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result v1

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v3, v1, v2}, Landroid/view/View;->setPadding(IIII)V

    :cond_5f
    :goto_5f
    return-void
.end method

.method public final onLayout(Landroid/view/View;)V
    .registers 2

    invoke-virtual {p0, p1}, LC7/m;->a(Landroid/view/View;)V

    return-void
.end method

.method public final onSlide(Landroid/view/View;F)V
    .registers 3

    invoke-virtual {p0, p1}, LC7/m;->a(Landroid/view/View;)V

    return-void
.end method

.method public final onStateChanged(Landroid/view/View;I)V
    .registers 3

    invoke-virtual {p0, p1}, LC7/m;->a(Landroid/view/View;)V

    return-void
.end method
