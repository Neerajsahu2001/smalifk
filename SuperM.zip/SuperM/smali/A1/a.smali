.class public final La1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Z

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I

.field public final g:[I

.field public final h:I

.field public final i:I

.field public final j:I

.field public final k:F

.field public final l:I

.field public final m:I

.field public final n:I

.field public final o:I


# direct methods
.method public constructor <init>(IZIIII[IIIIFIIII)V
    .registers 16

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La1/a;->a:I

    iput-boolean p2, p0, La1/a;->b:Z

    iput p3, p0, La1/a;->c:I

    iput p4, p0, La1/a;->d:I

    iput p5, p0, La1/a;->e:I

    iput p6, p0, La1/a;->f:I

    iput-object p7, p0, La1/a;->g:[I

    iput p8, p0, La1/a;->h:I

    iput p9, p0, La1/a;->i:I

    iput p10, p0, La1/a;->j:I

    iput p11, p0, La1/a;->k:F

    iput p12, p0, La1/a;->l:I

    iput p13, p0, La1/a;->m:I

    iput p14, p0, La1/a;->n:I

    iput p15, p0, La1/a;->o:I

    return-void
.end method
