.class public abstract La1/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[B

.field public static final b:[F

.field public static final c:Ljava/lang/Object;

.field public static d:[I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_20

    sput-object v0, La1/d;->a:[B

    const/16 v0, 0x11

    new-array v0, v0, [F

    fill-array-data v0, :array_26

    sput-object v0, La1/d;->b:[F

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La1/d;->c:Ljava/lang/Object;

    const/16 v0, 0xa

    new-array v0, v0, [I

    sput-object v0, La1/d;->d:[I

    return-void

    nop

    :array_20
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x1t
    .end array-data

    :array_26
    .array-data 4
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f8ba2e9
        0x3f68ba2f
        0x3fba2e8c
        0x3f9b26ca
        0x400ba2e9
        0x3fe8ba2f
        0x403a2e8c
        0x401b26ca
        0x3fd1745d
        0x3fae8ba3
        0x3ff83e10
        0x3fcede62
        0x3faaaaab
        0x3fc00000    # 1.5f
        0x40000000    # 2.0f
    .end array-data
.end method

.method public static a([Z)V
    .registers 3

    const/4 v0, 0x0

    aput-boolean v0, p0, v0

    const/4 v1, 0x1

    aput-boolean v0, p0, v1

    const/4 v1, 0x2

    aput-boolean v0, p0, v1

    return-void
.end method

.method public static b([BII[Z)I
    .registers 12

    sub-int v0, p2, p1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ltz v0, :cond_8

    move v3, v2

    goto :goto_9

    :cond_8
    move v3, v1

    :goto_9
    invoke-static {v3}, Lm7/u;->e(Z)V

    if-nez v0, :cond_f

    return p2

    :cond_f
    aget-boolean v3, p3, v1

    if-eqz v3, :cond_19

    invoke-static {p3}, La1/d;->a([Z)V

    add-int/lit8 p1, p1, -0x3

    return p1

    :cond_19
    const/4 v3, 0x2

    if-le v0, v2, :cond_29

    aget-boolean v4, p3, v2

    if-eqz v4, :cond_29

    aget-byte v4, p0, p1

    if-ne v4, v2, :cond_29

    invoke-static {p3}, La1/d;->a([Z)V

    sub-int/2addr p1, v3

    return p1

    :cond_29
    if-le v0, v3, :cond_3e

    aget-boolean v4, p3, v3

    if-eqz v4, :cond_3e

    aget-byte v4, p0, p1

    if-nez v4, :cond_3e

    add-int/lit8 v4, p1, 0x1

    aget-byte v4, p0, v4

    if-ne v4, v2, :cond_3e

    invoke-static {p3}, La1/d;->a([Z)V

    sub-int/2addr p1, v2

    return p1

    :cond_3e
    add-int/lit8 v4, p2, -0x1

    add-int/2addr p1, v3

    :goto_41
    if-ge p1, v4, :cond_61

    aget-byte v5, p0, p1

    and-int/lit16 v6, v5, 0xfe

    if-eqz v6, :cond_4a

    goto :goto_5e

    :cond_4a
    add-int/lit8 v6, p1, -0x2

    aget-byte v7, p0, v6

    if-nez v7, :cond_5c

    add-int/lit8 v7, p1, -0x1

    aget-byte v7, p0, v7

    if-nez v7, :cond_5c

    if-ne v5, v2, :cond_5c

    invoke-static {p3}, La1/d;->a([Z)V

    return v6

    :cond_5c
    add-int/lit8 p1, p1, -0x2

    :goto_5e
    add-int/lit8 p1, p1, 0x3

    goto :goto_41

    :cond_61
    if-le v0, v3, :cond_77

    add-int/lit8 p1, p2, -0x3

    aget-byte p1, p0, p1

    if-nez p1, :cond_75

    add-int/lit8 p1, p2, -0x2

    aget-byte p1, p0, p1

    if-nez p1, :cond_75

    aget-byte p1, p0, v4

    if-ne p1, v2, :cond_75

    :goto_73
    move p1, v2

    goto :goto_91

    :cond_75
    move p1, v1

    goto :goto_91

    :cond_77
    if-ne v0, v3, :cond_88

    aget-boolean p1, p3, v3

    if-eqz p1, :cond_75

    add-int/lit8 p1, p2, -0x2

    aget-byte p1, p0, p1

    if-nez p1, :cond_75

    aget-byte p1, p0, v4

    if-ne p1, v2, :cond_75

    goto :goto_73

    :cond_88
    aget-boolean p1, p3, v2

    if-eqz p1, :cond_75

    aget-byte p1, p0, v4

    if-ne p1, v2, :cond_75

    goto :goto_73

    :goto_91
    aput-boolean p1, p3, v1

    if-le v0, v2, :cond_a3

    add-int/lit8 p1, p2, -0x2

    aget-byte p1, p0, p1

    if-nez p1, :cond_a1

    aget-byte p1, p0, v4

    if-nez p1, :cond_a1

    :goto_9f
    move p1, v2

    goto :goto_ac

    :cond_a1
    move p1, v1

    goto :goto_ac

    :cond_a3
    aget-boolean p1, p3, v3

    if-eqz p1, :cond_a1

    aget-byte p1, p0, v4

    if-nez p1, :cond_a1

    goto :goto_9f

    :goto_ac
    aput-boolean p1, p3, v2

    aget-byte p0, p0, v4

    if-nez p0, :cond_b3

    move v1, v2

    :cond_b3
    aput-boolean v1, p3, v3

    return p2
.end method

.method public static c(II[B)La1/a;
    .registers 37

    const/4 v0, 0x2

    add-int/lit8 v1, p0, 0x2

    new-instance v2, La1/e;

    const/4 v3, 0x0

    move/from16 v4, p1

    move-object/from16 v5, p2

    invoke-direct {v2, v1, v5, v4, v3}, La1/e;-><init>(I[BII)V

    const/4 v1, 0x4

    invoke-virtual {v2, v1}, La1/e;->k(I)V

    const/4 v3, 0x3

    invoke-virtual {v2, v3}, La1/e;->f(I)I

    move-result v4

    invoke-virtual {v2}, La1/e;->j()V

    invoke-virtual {v2, v0}, La1/e;->f(I)I

    move-result v6

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v7

    const/4 v5, 0x5

    invoke-virtual {v2, v5}, La1/e;->f(I)I

    move-result v8

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_28
    const/16 v12, 0x20

    const/4 v13, 0x1

    if-ge v11, v12, :cond_39

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v12

    if-eqz v12, :cond_36

    shl-int v12, v13, v11

    or-int/2addr v10, v12

    :cond_36
    add-int/lit8 v11, v11, 0x1

    goto :goto_28

    :cond_39
    const/4 v11, 0x6

    new-array v12, v11, [I

    const/4 v14, 0x0

    :goto_3d
    const/16 v15, 0x8

    if-ge v14, v11, :cond_4a

    invoke-virtual {v2, v15}, La1/e;->f(I)I

    move-result v15

    aput v15, v12, v14

    add-int/lit8 v14, v14, 0x1

    goto :goto_3d

    :cond_4a
    invoke-virtual {v2, v15}, La1/e;->f(I)I

    move-result v14

    const/4 v5, 0x0

    const/4 v9, 0x0

    :goto_50
    if-ge v5, v4, :cond_65

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v16

    if-eqz v16, :cond_5a

    add-int/lit8 v9, v9, 0x59

    :cond_5a
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v16

    if-eqz v16, :cond_62

    add-int/lit8 v9, v9, 0x8

    :cond_62
    add-int/lit8 v5, v5, 0x1

    goto :goto_50

    :cond_65
    invoke-virtual {v2, v9}, La1/e;->k(I)V

    if-lez v4, :cond_70

    rsub-int/lit8 v5, v4, 0x8

    mul-int/2addr v5, v0

    invoke-virtual {v2, v5}, La1/e;->k(I)V

    :cond_70
    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    move-result v5

    if-ne v5, v3, :cond_7c

    invoke-virtual {v2}, La1/e;->j()V

    :cond_7c
    invoke-virtual {v2}, La1/e;->g()I

    move-result v9

    invoke-virtual {v2}, La1/e;->g()I

    move-result v16

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v17

    if-eqz v17, :cond_b5

    invoke-virtual {v2}, La1/e;->g()I

    move-result v17

    invoke-virtual {v2}, La1/e;->g()I

    move-result v18

    invoke-virtual {v2}, La1/e;->g()I

    move-result v19

    invoke-virtual {v2}, La1/e;->g()I

    move-result v20

    if-eq v5, v13, :cond_a2

    if-ne v5, v0, :cond_9f

    goto :goto_a2

    :cond_9f
    move/from16 v21, v13

    goto :goto_a4

    :cond_a2
    :goto_a2
    move/from16 v21, v0

    :goto_a4
    if-ne v5, v13, :cond_a8

    move v5, v0

    goto :goto_a9

    :cond_a8
    move v5, v13

    :goto_a9
    add-int v17, v17, v18

    mul-int v17, v17, v21

    sub-int v9, v9, v17

    add-int v19, v19, v20

    mul-int v19, v19, v5

    sub-int v16, v16, v19

    :cond_b5
    move/from16 v5, v16

    move/from16 v16, v9

    invoke-virtual {v2}, La1/e;->g()I

    move-result v17

    invoke-virtual {v2}, La1/e;->g()I

    move-result v18

    invoke-virtual {v2}, La1/e;->g()I

    move-result v9

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v19

    if-eqz v19, :cond_ce

    const/16 v19, 0x0

    goto :goto_d0

    :cond_ce
    move/from16 v19, v4

    :goto_d0
    const/16 v20, -0x1

    move/from16 v0, v19

    move/from16 v15, v20

    :goto_d6
    if-gt v0, v4, :cond_ea

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    move-result v3

    invoke-static {v3, v15}, Ljava/lang/Math;->max(II)I

    move-result v15

    invoke-virtual {v2}, La1/e;->g()I

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    goto :goto_d6

    :cond_ea
    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_13e

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_13e

    const/4 v0, 0x0

    :goto_109
    if-ge v0, v1, :cond_13e

    const/4 v3, 0x0

    :goto_10c
    if-ge v3, v11, :cond_13a

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v4

    if-nez v4, :cond_119

    invoke-virtual {v2}, La1/e;->g()I

    :cond_117
    const/4 v1, 0x3

    goto :goto_132

    :cond_119
    shl-int/lit8 v4, v0, 0x1

    add-int/2addr v4, v1

    shl-int v4, v13, v4

    const/16 v1, 0x40

    invoke-static {v1, v4}, Ljava/lang/Math;->min(II)I

    move-result v1

    if-le v0, v13, :cond_129

    invoke-virtual {v2}, La1/e;->h()I

    :cond_129
    const/4 v4, 0x0

    :goto_12a
    if-ge v4, v1, :cond_117

    invoke-virtual {v2}, La1/e;->h()I

    add-int/lit8 v4, v4, 0x1

    goto :goto_12a

    :goto_132
    if-ne v0, v1, :cond_136

    const/4 v1, 0x3

    goto :goto_137

    :cond_136
    move v1, v13

    :goto_137
    add-int/2addr v3, v1

    const/4 v1, 0x4

    goto :goto_10c

    :cond_13a
    add-int/lit8 v0, v0, 0x1

    const/4 v1, 0x4

    goto :goto_109

    :cond_13e
    const/4 v0, 0x2

    invoke-virtual {v2, v0}, La1/e;->k(I)V

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_156

    const/16 v0, 0x8

    invoke-virtual {v2, v0}, La1/e;->k(I)V

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->j()V

    :cond_156
    invoke-virtual {v2}, La1/e;->g()I

    move-result v0

    const/4 v1, 0x0

    new-array v3, v1, [I

    new-array v4, v1, [I

    move v11, v1

    move/from16 v1, v20

    move v13, v1

    :goto_163
    if-ge v11, v0, :cond_29c

    if-eqz v11, :cond_239

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v23

    if-eqz v23, :cond_239

    move/from16 v23, v0

    add-int v0, v1, v13

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v24

    invoke-virtual {v2}, La1/e;->g()I

    move-result v25

    const/16 v22, 0x1

    add-int/lit8 v25, v25, 0x1

    const/16 v19, 0x2

    mul-int/lit8 v24, v24, 0x2

    rsub-int/lit8 v24, v24, 0x1

    mul-int v24, v24, v25

    move/from16 v25, v15

    add-int/lit8 v15, v0, 0x1

    move/from16 v26, v14

    new-array v14, v15, [Z

    move-object/from16 v27, v12

    const/4 v12, 0x0

    :goto_190
    if-gt v12, v0, :cond_1a6

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v28

    if-nez v28, :cond_19f

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v28

    aput-boolean v28, v14, v12

    goto :goto_1a3

    :cond_19f
    const/16 v22, 0x1

    aput-boolean v22, v14, v12

    :goto_1a3
    add-int/lit8 v12, v12, 0x1

    goto :goto_190

    :cond_1a6
    new-array v12, v15, [I

    new-array v15, v15, [I

    add-int/lit8 v28, v13, -0x1

    const/16 v29, 0x0

    :goto_1ae
    if-ltz v28, :cond_1c5

    aget v30, v4, v28

    add-int v30, v30, v24

    if-gez v30, :cond_1c2

    add-int v31, v1, v28

    aget-boolean v31, v14, v31

    if-eqz v31, :cond_1c2

    add-int/lit8 v31, v29, 0x1

    aput v30, v12, v29

    move/from16 v29, v31

    :cond_1c2
    add-int/lit8 v28, v28, -0x1

    goto :goto_1ae

    :cond_1c5
    if-gez v24, :cond_1d1

    aget-boolean v28, v14, v0

    if-eqz v28, :cond_1d1

    add-int/lit8 v28, v29, 0x1

    aput v24, v12, v29

    move/from16 v29, v28

    :cond_1d1
    move/from16 v28, v10

    move/from16 v10, v29

    move/from16 v29, v8

    const/4 v8, 0x0

    :goto_1d8
    if-ge v8, v1, :cond_1ed

    aget v30, v3, v8

    add-int v30, v30, v24

    if-gez v30, :cond_1ea

    aget-boolean v31, v14, v8

    if-eqz v31, :cond_1ea

    add-int/lit8 v31, v10, 0x1

    aput v30, v12, v10

    move/from16 v10, v31

    :cond_1ea
    add-int/lit8 v8, v8, 0x1

    goto :goto_1d8

    :cond_1ed
    invoke-static {v12, v10}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v8

    add-int/lit8 v12, v1, -0x1

    const/16 v30, 0x0

    :goto_1f5
    if-ltz v12, :cond_20a

    aget v31, v3, v12

    add-int v31, v31, v24

    if-lez v31, :cond_207

    aget-boolean v32, v14, v12

    if-eqz v32, :cond_207

    add-int/lit8 v32, v30, 0x1

    aput v31, v15, v30

    move/from16 v30, v32

    :cond_207
    add-int/lit8 v12, v12, -0x1

    goto :goto_1f5

    :cond_20a
    if-lez v24, :cond_216

    aget-boolean v0, v14, v0

    if-eqz v0, :cond_216

    add-int/lit8 v0, v30, 0x1

    aput v24, v15, v30

    move/from16 v30, v0

    :cond_216
    move/from16 v0, v30

    const/4 v3, 0x0

    :goto_219
    if-ge v3, v13, :cond_230

    aget v12, v4, v3

    add-int v12, v12, v24

    if-lez v12, :cond_22d

    add-int v30, v1, v3

    aget-boolean v30, v14, v30

    if-eqz v30, :cond_22d

    add-int/lit8 v30, v0, 0x1

    aput v12, v15, v0

    move/from16 v0, v30

    :cond_22d
    add-int/lit8 v3, v3, 0x1

    goto :goto_219

    :cond_230
    invoke-static {v15, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v1

    move-object v4, v1

    move-object v3, v8

    move v1, v10

    const/4 v13, 0x1

    goto :goto_28b

    :cond_239
    move/from16 v23, v0

    move/from16 v29, v8

    move/from16 v28, v10

    move-object/from16 v27, v12

    move/from16 v26, v14

    move/from16 v25, v15

    invoke-virtual {v2}, La1/e;->g()I

    move-result v0

    invoke-virtual {v2}, La1/e;->g()I

    move-result v1

    new-array v3, v0, [I

    const/4 v4, 0x0

    :goto_250
    if-ge v4, v0, :cond_269

    if-lez v4, :cond_259

    add-int/lit8 v8, v4, -0x1

    aget v8, v3, v8

    goto :goto_25a

    :cond_259
    const/4 v8, 0x0

    :goto_25a
    invoke-virtual {v2}, La1/e;->g()I

    move-result v10

    const/4 v12, 0x1

    add-int/2addr v10, v12

    sub-int/2addr v8, v10

    aput v8, v3, v4

    invoke-virtual {v2}, La1/e;->j()V

    add-int/lit8 v4, v4, 0x1

    goto :goto_250

    :cond_269
    new-array v4, v1, [I

    const/4 v8, 0x0

    :goto_26c
    if-ge v8, v1, :cond_285

    if-lez v8, :cond_275

    add-int/lit8 v10, v8, -0x1

    aget v10, v4, v10

    goto :goto_276

    :cond_275
    const/4 v10, 0x0

    :goto_276
    invoke-virtual {v2}, La1/e;->g()I

    move-result v12

    const/4 v13, 0x1

    add-int/2addr v12, v13

    add-int/2addr v12, v10

    aput v12, v4, v8

    invoke-virtual {v2}, La1/e;->j()V

    add-int/lit8 v8, v8, 0x1

    goto :goto_26c

    :cond_285
    const/4 v13, 0x1

    move/from16 v33, v1

    move v1, v0

    move/from16 v0, v33

    :goto_28b
    add-int/lit8 v11, v11, 0x1

    move v13, v0

    move/from16 v0, v23

    move/from16 v15, v25

    move/from16 v14, v26

    move-object/from16 v12, v27

    move/from16 v10, v28

    move/from16 v8, v29

    goto/16 :goto_163

    :cond_29c
    move/from16 v29, v8

    move/from16 v28, v10

    move-object/from16 v27, v12

    move/from16 v26, v14

    move/from16 v25, v15

    const/4 v13, 0x1

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_2bd

    invoke-virtual {v2}, La1/e;->g()I

    move-result v0

    const/4 v1, 0x0

    :goto_2b2
    if-ge v1, v0, :cond_2bd

    const/4 v3, 0x5

    add-int/lit8 v4, v9, 0x5

    invoke-virtual {v2, v4}, La1/e;->k(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2b2

    :cond_2bd
    const/4 v0, 0x2

    invoke-virtual {v2, v0}, La1/e;->k(I)V

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v1

    const/high16 v3, 0x3f800000    # 1.0f

    if-eqz v1, :cond_352

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v1

    if-eqz v1, :cond_2fb

    const/16 v1, 0x8

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v4

    const/16 v1, 0xff

    if-ne v4, v1, :cond_2eb

    const/16 v1, 0x10

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v4

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v1

    if-eqz v4, :cond_2fb

    if-eqz v1, :cond_2fb

    int-to-float v3, v4

    int-to-float v1, v1

    div-float/2addr v3, v1

    goto :goto_2fb

    :cond_2eb
    const/16 v1, 0x11

    if-ge v4, v1, :cond_2f4

    sget-object v1, La1/d;->b:[F

    aget v3, v1, v4

    goto :goto_2fb

    :cond_2f4
    const-string v1, "Unexpected aspect_ratio_idc value: "

    const-string v8, "NalUnitUtil"

    invoke-static {v4, v1, v8}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    :cond_2fb
    :goto_2fb
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v1

    if-eqz v1, :cond_304

    invoke-virtual {v2}, La1/e;->j()V

    :cond_304
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v1

    if-eqz v1, :cond_334

    const/4 v1, 0x3

    invoke-virtual {v2, v1}, La1/e;->k(I)V

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v1

    if-eqz v1, :cond_315

    move v0, v13

    :cond_315
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v1

    if-eqz v1, :cond_331

    const/16 v1, 0x8

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v4

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v8

    invoke-virtual {v2, v1}, La1/e;->k(I)V

    invoke-static {v4}, LW0/j;->f(I)I

    move-result v20

    invoke-static {v8}, LW0/j;->g(I)I

    move-result v1

    goto :goto_337

    :cond_331
    move/from16 v1, v20

    goto :goto_337

    :cond_334
    move/from16 v0, v20

    move v1, v0

    :goto_337
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v4

    if-eqz v4, :cond_343

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    :cond_343
    invoke-virtual {v2}, La1/e;->j()V

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v2

    if-eqz v2, :cond_34e

    mul-int/lit8 v5, v5, 0x2

    :cond_34e
    move/from16 v19, v0

    move v15, v5

    goto :goto_357

    :cond_352
    move v15, v5

    move/from16 v1, v20

    move/from16 v19, v1

    :goto_357
    new-instance v0, La1/a;

    move-object v5, v0

    move/from16 v8, v29

    move/from16 v9, v28

    move/from16 v10, v17

    move/from16 v11, v18

    move-object/from16 v12, v27

    move/from16 v13, v26

    move/from16 v14, v16

    move/from16 v2, v25

    move/from16 v16, v3

    move/from16 v17, v2

    move/from16 v18, v20

    move/from16 v20, v1

    invoke-direct/range {v5 .. v20}, La1/a;-><init>(IZIIII[IIIIFIIII)V

    return-object v0
.end method

.method public static d(II[B)La1/c;
    .registers 33

    const/4 v0, 0x1

    add-int/lit8 v1, p0, 0x1

    new-instance v2, La1/e;

    const/4 v3, 0x0

    move/from16 v4, p1

    move-object/from16 v5, p2

    invoke-direct {v2, v1, v5, v4, v3}, La1/e;-><init>(I[BII)V

    const/16 v1, 0x8

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v4

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v5

    invoke-virtual {v2, v1}, La1/e;->f(I)I

    move-result v6

    invoke-virtual {v2}, La1/e;->g()I

    move-result v7

    const/16 v3, 0x10

    const/16 v8, 0x56

    const/16 v9, 0x2c

    const/16 v10, 0xf4

    const/16 v11, 0x7a

    const/16 v12, 0x6e

    const/16 v13, 0x64

    const/4 v14, 0x3

    if-eq v4, v13, :cond_51

    if-eq v4, v12, :cond_51

    if-eq v4, v11, :cond_51

    if-eq v4, v10, :cond_51

    if-eq v4, v9, :cond_51

    const/16 v15, 0x53

    if-eq v4, v15, :cond_51

    if-eq v4, v8, :cond_51

    const/16 v15, 0x76

    if-eq v4, v15, :cond_51

    const/16 v15, 0x80

    if-eq v4, v15, :cond_51

    const/16 v15, 0x8a

    if-ne v4, v15, :cond_4b

    goto :goto_51

    :cond_4b
    move v15, v0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    goto/16 :goto_b4

    :cond_51
    :goto_51
    invoke-virtual {v2}, La1/e;->g()I

    move-result v15

    if-ne v15, v14, :cond_5c

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v16

    goto :goto_5e

    :cond_5c
    const/16 v16, 0x0

    :goto_5e
    invoke-virtual {v2}, La1/e;->g()I

    move-result v17

    invoke-virtual {v2}, La1/e;->g()I

    move-result v18

    invoke-virtual {v2}, La1/e;->j()V

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v19

    if-eqz v19, :cond_ae

    if-eq v15, v14, :cond_72

    goto :goto_76

    :cond_72
    const/16 v19, 0xc

    move/from16 v1, v19

    :goto_76
    const/4 v10, 0x0

    :goto_77
    if-ge v10, v1, :cond_ae

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v19

    if-eqz v19, :cond_a5

    const/4 v11, 0x6

    if-ge v10, v11, :cond_84

    move v11, v3

    goto :goto_86

    :cond_84
    const/16 v11, 0x40

    :goto_86
    const/4 v12, 0x0

    const/16 v20, 0x8

    const/16 v21, 0x8

    :goto_8b
    if-ge v12, v11, :cond_a5

    if-eqz v20, :cond_9b

    invoke-virtual {v2}, La1/e;->h()I

    move-result v20

    add-int v13, v20, v21

    add-int/lit16 v13, v13, 0x100

    rem-int/lit16 v13, v13, 0x100

    move/from16 v20, v13

    :cond_9b
    if-nez v20, :cond_9e

    goto :goto_a0

    :cond_9e
    move/from16 v21, v20

    :goto_a0
    add-int/lit8 v12, v12, 0x1

    const/16 v13, 0x64

    goto :goto_8b

    :cond_a5
    add-int/lit8 v10, v10, 0x1

    const/16 v11, 0x7a

    const/16 v12, 0x6e

    const/16 v13, 0x64

    goto :goto_77

    :cond_ae
    move/from16 v13, v16

    move/from16 v11, v17

    move/from16 v12, v18

    :goto_b4
    invoke-virtual {v2}, La1/e;->g()I

    move-result v1

    add-int/lit8 v1, v1, 0x4

    invoke-virtual {v2}, La1/e;->g()I

    move-result v10

    if-nez v10, :cond_cf

    invoke-virtual {v2}, La1/e;->g()I

    move-result v16

    add-int/lit8 v16, v16, 0x4

    move/from16 v20, v10

    move/from16 v23, v15

    move/from16 v24, v16

    :goto_cc
    const/16 v25, 0x0

    goto :goto_fc

    :cond_cf
    if-ne v10, v0, :cond_f5

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v16

    invoke-virtual {v2}, La1/e;->h()I

    invoke-virtual {v2}, La1/e;->h()I

    invoke-virtual {v2}, La1/e;->g()I

    move-result v8

    move/from16 v20, v10

    int-to-long v9, v8

    move/from16 v23, v15

    const/4 v8, 0x0

    :goto_e5
    int-to-long v14, v8

    cmp-long v14, v14, v9

    if-gez v14, :cond_f0

    invoke-virtual {v2}, La1/e;->g()I

    add-int/lit8 v8, v8, 0x1

    goto :goto_e5

    :cond_f0
    move/from16 v25, v16

    const/16 v24, 0x0

    goto :goto_fc

    :cond_f5
    move/from16 v20, v10

    move/from16 v23, v15

    const/16 v24, 0x0

    goto :goto_cc

    :goto_fc
    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->j()V

    invoke-virtual {v2}, La1/e;->g()I

    move-result v8

    add-int/2addr v8, v0

    invoke-virtual {v2}, La1/e;->g()I

    move-result v9

    add-int/2addr v9, v0

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v14

    rsub-int/lit8 v10, v14, 0x2

    mul-int/2addr v9, v10

    if-nez v14, :cond_118

    invoke-virtual {v2}, La1/e;->j()V

    :cond_118
    invoke-virtual {v2}, La1/e;->j()V

    mul-int/2addr v8, v3

    mul-int/2addr v9, v3

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v15

    const/16 v16, 0x2

    if-eqz v15, :cond_15c

    invoke-virtual {v2}, La1/e;->g()I

    move-result v15

    invoke-virtual {v2}, La1/e;->g()I

    move-result v26

    invoke-virtual {v2}, La1/e;->g()I

    move-result v27

    invoke-virtual {v2}, La1/e;->g()I

    move-result v28

    if-nez v23, :cond_13b

    move v3, v0

    move/from16 v29, v3

    goto :goto_14e

    :cond_13b
    move/from16 v0, v23

    const/4 v3, 0x3

    if-ne v0, v3, :cond_144

    const/4 v3, 0x1

    const/16 v29, 0x1

    goto :goto_147

    :cond_144
    move/from16 v29, v16

    const/4 v3, 0x1

    :goto_147
    if-ne v0, v3, :cond_14c

    move/from16 v0, v16

    goto :goto_14d

    :cond_14c
    move v0, v3

    :goto_14d
    mul-int/2addr v10, v0

    :goto_14e
    add-int v15, v15, v26

    mul-int v15, v15, v29

    sub-int/2addr v8, v15

    add-int v27, v27, v28

    mul-int v27, v27, v10

    sub-int v9, v9, v27

    :goto_159
    const/16 v0, 0x2c

    goto :goto_15e

    :cond_15c
    move v3, v0

    goto :goto_159

    :goto_15e
    if-eq v4, v0, :cond_174

    const/16 v0, 0x56

    if-eq v4, v0, :cond_174

    const/16 v0, 0x64

    if-eq v4, v0, :cond_174

    const/16 v0, 0x6e

    if-eq v4, v0, :cond_174

    const/16 v0, 0x7a

    if-eq v4, v0, :cond_174

    const/16 v0, 0xf4

    if-ne v4, v0, :cond_17a

    :cond_174
    and-int/lit8 v0, v5, 0x10

    if-eqz v0, :cond_17a

    const/4 v15, 0x0

    goto :goto_17c

    :cond_17a
    const/16 v15, 0x10

    :goto_17c
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    const/high16 v17, 0x3f800000    # 1.0f

    if-eqz v0, :cond_25c

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_1b7

    const/16 v0, 0x8

    invoke-virtual {v2, v0}, La1/e;->f(I)I

    move-result v3

    const/16 v0, 0xff

    if-ne v3, v0, :cond_1a7

    const/16 v0, 0x10

    invoke-virtual {v2, v0}, La1/e;->f(I)I

    move-result v3

    invoke-virtual {v2, v0}, La1/e;->f(I)I

    move-result v0

    if-eqz v3, :cond_1b7

    if-eqz v0, :cond_1b7

    int-to-float v3, v3

    int-to-float v0, v0

    div-float v17, v3, v0

    goto :goto_1b7

    :cond_1a7
    const/16 v0, 0x11

    if-ge v3, v0, :cond_1b0

    sget-object v0, La1/d;->b:[F

    aget v17, v0, v3

    goto :goto_1b7

    :cond_1b0
    const-string v0, "Unexpected aspect_ratio_idc value: "

    const-string v10, "NalUnitUtil"

    invoke-static {v3, v0, v10}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    :cond_1b7
    :goto_1b7
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_1c0

    invoke-virtual {v2}, La1/e;->j()V

    :cond_1c0
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_1f3

    const/4 v0, 0x3

    invoke-virtual {v2, v0}, La1/e;->k(I)V

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_1d2

    const/4 v0, 0x1

    goto :goto_1d4

    :cond_1d2
    move/from16 v0, v16

    :goto_1d4
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v3

    if-eqz v3, :cond_1f0

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, La1/e;->f(I)I

    move-result v10

    invoke-virtual {v2, v3}, La1/e;->f(I)I

    move-result v16

    invoke-virtual {v2, v3}, La1/e;->k(I)V

    invoke-static {v10}, LW0/j;->f(I)I

    move-result v10

    invoke-static/range {v16 .. v16}, LW0/j;->g(I)I

    move-result v3

    goto :goto_1f5

    :cond_1f0
    :goto_1f0
    const/4 v3, -0x1

    const/4 v10, -0x1

    goto :goto_1f5

    :cond_1f3
    const/4 v0, -0x1

    goto :goto_1f0

    :goto_1f5
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v16

    if-eqz v16, :cond_201

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    :cond_201
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v16

    move/from16 p0, v0

    if-eqz v16, :cond_20e

    const/16 v0, 0x41

    invoke-virtual {v2, v0}, La1/e;->k(I)V

    :cond_20e
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_217

    invoke-static {v2}, La1/d;->e(La1/e;)V

    :cond_217
    invoke-virtual {v2}, La1/e;->e()Z

    move-result v16

    if-eqz v16, :cond_220

    invoke-static {v2}, La1/d;->e(La1/e;)V

    :cond_220
    if-nez v0, :cond_224

    if-eqz v16, :cond_227

    :cond_224
    invoke-virtual {v2}, La1/e;->j()V

    :cond_227
    invoke-virtual {v2}, La1/e;->j()V

    invoke-virtual {v2}, La1/e;->e()Z

    move-result v0

    if-eqz v0, :cond_251

    invoke-virtual {v2}, La1/e;->j()V

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    invoke-virtual {v2}, La1/e;->g()I

    move-result v0

    invoke-virtual {v2}, La1/e;->g()I

    move/from16 v22, v0

    move/from16 v21, v3

    move/from16 v19, v10

    move/from16 v10, v17

    move/from16 v0, p0

    goto :goto_265

    :cond_251
    move/from16 v0, p0

    move/from16 v21, v3

    move/from16 v19, v10

    move/from16 v22, v15

    move/from16 v10, v17

    goto :goto_265

    :cond_25c
    move/from16 v22, v15

    move/from16 v10, v17

    const/4 v0, -0x1

    const/16 v19, -0x1

    const/16 v21, -0x1

    :goto_265
    new-instance v2, La1/c;

    move-object v3, v2

    move/from16 v16, v20

    move v15, v1

    move/from16 v17, v24

    move/from16 v18, v25

    move/from16 v20, v0

    invoke-direct/range {v3 .. v22}, La1/c;-><init>(IIIIIIFIIZZIIIZIIII)V

    return-object v2
.end method

.method public static e(La1/e;)V
    .registers 3

    invoke-virtual {p0}, La1/e;->g()I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    const/16 v1, 0x8

    invoke-virtual {p0, v1}, La1/e;->k(I)V

    const/4 v1, 0x0

    :goto_c
    if-ge v1, v0, :cond_1a

    invoke-virtual {p0}, La1/e;->g()I

    invoke-virtual {p0}, La1/e;->g()I

    invoke-virtual {p0}, La1/e;->j()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_c

    :cond_1a
    const/16 v0, 0x14

    invoke-virtual {p0, v0}, La1/e;->k(I)V

    return-void
.end method

.method public static f(I[B)I
    .registers 10

    sget-object v0, La1/d;->c:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    move v2, v1

    move v3, v2

    :cond_6
    :goto_6
    if-ge v2, p0, :cond_3f

    :goto_8
    add-int/lit8 v4, p0, -0x2

    if-ge v2, v4, :cond_21

    :try_start_c
    aget-byte v4, p1, v2

    if-nez v4, :cond_1e

    add-int/lit8 v4, v2, 0x1

    aget-byte v4, p1, v4

    if-nez v4, :cond_1e

    add-int/lit8 v4, v2, 0x2

    aget-byte v4, p1, v4

    const/4 v5, 0x3

    if-ne v4, v5, :cond_1e

    goto :goto_22

    :cond_1e
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    :cond_21
    move v2, p0

    :goto_22
    if-ge v2, p0, :cond_6

    sget-object v4, La1/d;->d:[I

    array-length v5, v4

    if-gt v5, v3, :cond_35

    array-length v5, v4

    mul-int/lit8 v5, v5, 0x2

    invoke-static {v4, v5}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v4

    sput-object v4, La1/d;->d:[I

    goto :goto_35

    :catchall_33
    move-exception p0

    goto :goto_63

    :cond_35
    :goto_35
    sget-object v4, La1/d;->d:[I

    add-int/lit8 v5, v3, 0x1

    aput v2, v4, v3

    add-int/lit8 v2, v2, 0x3

    move v3, v5

    goto :goto_6

    :cond_3f
    sub-int/2addr p0, v3

    move v2, v1

    move v4, v2

    move v5, v4

    :goto_43
    if-ge v2, v3, :cond_5c

    sget-object v6, La1/d;->d:[I

    aget v6, v6, v2

    sub-int/2addr v6, v5

    invoke-static {p1, v5, p1, v4, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr v4, v6

    add-int/lit8 v7, v4, 0x1

    aput-byte v1, p1, v4

    add-int/lit8 v4, v4, 0x2

    aput-byte v1, p1, v7

    add-int/lit8 v6, v6, 0x3

    add-int/2addr v5, v6

    add-int/lit8 v2, v2, 0x1

    goto :goto_43

    :cond_5c
    sub-int v1, p0, v4

    invoke-static {p1, v5, p1, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    monitor-exit v0

    return p0

    :goto_63
    monitor-exit v0
    :try_end_64
    .catchall {:try_start_c .. :try_end_64} :catchall_33

    throw p0
.end method
