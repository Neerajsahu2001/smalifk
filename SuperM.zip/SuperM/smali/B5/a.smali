.class public final Lb5/a;
.super Ljava/lang/Exception;
.source "SourceFile"


# virtual methods
.method public final declared-synchronized fillInStackTrace()Ljava/lang/Throwable;
    .registers 1

    monitor-enter p0

    monitor-exit p0

    return-object p0
.end method
