.class public LA5/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Callback;
.implements LOa/c;
.implements LW3/a;
.implements LKc/a;
.implements Lj2/E;
.implements Ls4/z;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x2

    iput v0, p0, LA5/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, LA5/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LD1/z;)V
    .registers 3

    const/16 v0, 0xc

    iput v0, p0, LA5/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LF4/o;Ljava/util/ArrayList;Lm4/h;)V
    .registers 5

    const/16 v0, 0xb

    iput v0, p0, LA5/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "Argument must not be null"

    invoke-static {p3, v0}, Ll7/d1;->c(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p3, p0, LA5/d;->c:Ljava/lang/Object;

    invoke-static {p2, v0}, Ll7/d1;->c(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p2, p0, LA5/d;->d:Ljava/lang/Object;

    new-instance p2, LA0/x;

    invoke-direct {p2, p1, p3}, LA0/x;-><init>(Ljava/io/InputStream;Lm4/h;)V

    iput-object p2, p0, LA5/d;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LK3/d;LL3/a;LC3/e;)V
    .registers 5

    const/4 v0, 0x4

    iput v0, p0, LA5/d;->a:I

    const-string v0, "logger"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "amplitude"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/d;->c:Ljava/lang/Object;

    iput-object p3, p0, LA5/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LXc/i;Ljava/util/List;LA5/d;)V
    .registers 5

    const/4 v0, 0x6

    iput v0, p0, LA5/d;->a:I

    const-string v0, "classifierDescriptor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "arguments"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/d;->c:Ljava/lang/Object;

    iput-object p3, p0, LA5/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lio/sentry/android/replay/capture/h;Lio/sentry/android/replay/capture/h;)V
    .registers 4

    const/4 v0, 0x7

    iput v0, p0, LA5/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/d;->c:Ljava/lang/Object;

    iput-object p2, p0, LA5/d;->d:Ljava/lang/Object;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    new-instance p1, LY8/c;

    invoke-direct {p1, p2}, LY8/c;-><init>(Lio/sentry/android/replay/capture/h;)V

    invoke-virtual {p0, p1}, LA5/d;->t(LHc/a;)V

    return-void
.end method

.method public constructor <init>(Ljava/io/File;Ljava/lang/String;LL3/a;)V
    .registers 6

    const/4 v0, 0x5

    iput v0, p0, LA5/d;->a:I

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Properties;

    invoke-direct {v0}, Ljava/util/Properties;-><init>()V

    iput-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    const-string v0, "amplitude-identity-"

    const-string v1, ".properties"

    invoke-static {v0, p2, v1}, Le/b;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    iput-object p3, p0, LA5/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    iput p4, p0, LA5/d;->a:I

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/d;->c:Ljava/lang/Object;

    iput-object p3, p0, LA5/d;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    const/16 v0, 0x8

    iput v0, p0, LA5/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LW0/o;

    invoke-direct {v0}, LW0/o;-><init>()V

    invoke-static {p1}, LW0/I;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, v0, LW0/o;->m:Ljava/lang/String;

    new-instance p1, Landroidx/media3/common/b;

    invoke-direct {p1, v0}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(LZ0/C;LD1/y;Lj2/L;)V
    .registers 4

    iput-object p1, p0, LA5/d;->c:Ljava/lang/Object;

    invoke-virtual {p3}, Lj2/L;->a()V

    invoke-virtual {p3}, Lj2/L;->b()V

    iget p1, p3, Lj2/L;->d:I

    const/4 p3, 0x5

    invoke-interface {p2, p1, p3}, LD1/y;->u(II)LD1/P;

    move-result-object p1

    iput-object p1, p0, LA5/d;->d:Ljava/lang/Object;

    iget-object p2, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast p2, Landroidx/media3/common/b;

    invoke-interface {p1, p2}, LD1/P;->c(Landroidx/media3/common/b;)V

    return-void
.end method

.method public b()Ljava/lang/Throwable;
    .registers 2

    iget-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Throwable;

    return-object v0
.end method

.method public c(LZ0/w;)V
    .registers 14

    iget-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LZ0/C;

    invoke-static {v0}, Lm7/u;->g(Ljava/lang/Object;)V

    sget v0, LZ0/F;->a:I

    iget-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LZ0/C;

    monitor-enter v0

    :try_start_e
    iget-wide v1, v0, LZ0/C;->c:J

    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v5, v1, v3

    if-eqz v5, :cond_20

    iget-wide v5, v0, LZ0/C;->b:J

    add-long/2addr v1, v5

    :goto_1c
    move-wide v6, v1

    goto :goto_25

    :catchall_1e
    move-exception p1

    goto :goto_70

    :cond_20
    invoke-virtual {v0}, LZ0/C;->d()J

    move-result-wide v1
    :try_end_24
    .catchall {:try_start_e .. :try_end_24} :catchall_1e

    goto :goto_1c

    :goto_25
    monitor-exit v0

    iget-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LZ0/C;

    monitor-enter v0

    :try_start_2b
    iget-wide v1, v0, LZ0/C;->b:J
    :try_end_2d
    .catchall {:try_start_2b .. :try_end_2d} :catchall_6d

    monitor-exit v0

    cmp-long v0, v6, v3

    if-eqz v0, :cond_6c

    cmp-long v0, v1, v3

    if-nez v0, :cond_37

    goto :goto_6c

    :cond_37
    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/common/b;

    iget-wide v3, v0, Landroidx/media3/common/b;->s:J

    cmp-long v3, v1, v3

    if-eqz v3, :cond_55

    invoke-virtual {v0}, Landroidx/media3/common/b;->a()LW0/o;

    move-result-object v0

    iput-wide v1, v0, LW0/o;->r:J

    new-instance v1, Landroidx/media3/common/b;

    invoke-direct {v1, v0}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    iput-object v1, p0, LA5/d;->b:Ljava/lang/Object;

    iget-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v0, LD1/P;

    invoke-interface {v0, v1}, LD1/P;->c(Landroidx/media3/common/b;)V

    :cond_55
    invoke-virtual {p1}, LZ0/w;->a()I

    move-result v9

    iget-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v0, LD1/P;

    const/4 v1, 0x0

    invoke-interface {v0, p1, v9, v1}, LD1/P;->e(LZ0/w;II)V

    iget-object p1, p0, LA5/d;->d:Ljava/lang/Object;

    move-object v5, p1

    check-cast v5, LD1/P;

    const/4 v11, 0x0

    const/4 v8, 0x1

    const/4 v10, 0x0

    invoke-interface/range {v5 .. v11}, LD1/P;->a(JIIILD1/O;)V

    :cond_6c
    :goto_6c
    return-void

    :catchall_6d
    move-exception p1

    monitor-exit v0

    throw p1

    :goto_70
    monitor-exit v0

    throw p1
.end method

.method public d(LOa/a;)V
    .registers 3

    new-instance p1, LNa/a;

    const-string v0, "Non-interactive decryption mode."

    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x0

    iput-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    iput-object p1, p0, LA5/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public e(LMa/b;Ljava/lang/Throwable;)V
    .registers 3

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public f()I
    .registers 4

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LA0/x;

    iget-object v0, v0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Ls4/D;

    invoke-virtual {v0}, Ls4/D;->reset()V

    iget-object v1, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v1, Lm4/h;

    iget-object v2, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    invoke-static {v2, v0, v1}, Ll7/B5;->f(Ljava/util/List;Ljava/io/InputStream;Lm4/h;)I

    move-result v0

    return v0
.end method

.method public g()LMa/c;
    .registers 2

    iget-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LMa/c;

    return-object v0
.end method

.method public getLong(Ljava/lang/String;J)J
    .registers 6

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Properties;

    const-string v1, ""

    invoke-virtual {v0, p1, v1}, Ljava/util/Properties;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "underlyingProperties.getProperty(key, \"\")"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, LZd/p;->j(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    if-eqz p1, :cond_1e

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p2

    :cond_1e
    return-wide p2
.end method

.method public h(LOc/u;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    const-string p2, "property"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast p1, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public i(Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    .registers 4

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LA0/x;

    iget-object v0, v0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Ls4/D;

    invoke-virtual {v0}, Ls4/D;->reset()V

    const/4 v1, 0x0

    invoke-static {v0, v1, p1}, Lcom/newrelic/agent/android/instrumentation/BitmapFactoryInstrumentation;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p1

    return-object p1
.end method

.method public j()V
    .registers 3

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LA0/x;

    iget-object v0, v0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Ls4/D;

    monitor-enter v0

    :try_start_9
    iget-object v1, v0, Ls4/D;->a:[B

    array-length v1, v1

    iput v1, v0, Ls4/D;->c:I
    :try_end_e
    .catchall {:try_start_9 .. :try_end_e} :catchall_10

    monitor-exit v0

    return-void

    :catchall_10
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public k()LMa/b;
    .registers 2

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LMa/b;

    return-object v0
.end method

.method public l()Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;
    .registers 4

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LA0/x;

    iget-object v0, v0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Ls4/D;

    invoke-virtual {v0}, Ls4/D;->reset()V

    iget-object v1, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v1, Lm4/h;

    iget-object v2, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    invoke-static {v2, v0, v1}, Ll7/B5;->g(Ljava/util/List;Ljava/io/InputStream;Lm4/h;)Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    move-result-object v0

    return-object v0
.end method

.method public m(LMa/c;Ljava/lang/Throwable;)V
    .registers 3

    iput-object p1, p0, LA5/d;->c:Ljava/lang/Object;

    iput-object p2, p0, LA5/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public n(Lyc/d;)Ljava/lang/Object;
    .registers 7

    instance-of v0, p1, LR3/a;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, LR3/a;

    iget v1, v0, LR3/a;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LR3/a;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, LR3/a;

    invoke-direct {v0, p0, p1}, LR3/a;-><init>(LA5/d;Lyc/d;)V

    :goto_18
    iget-object p1, v0, LR3/a;->b:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, LR3/a;->d:I

    sget-object v3, Luc/z;->a:Luc/z;

    const/4 v4, 0x1

    if-eqz v2, :cond_35

    if-ne v2, v4, :cond_2d

    iget-object v0, v0, LR3/a;->a:LA5/d;

    :try_start_27
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_2a
    .catch Ljava/io/FileNotFoundException; {:try_start_27 .. :try_end_2a} :catch_2b

    goto :goto_48

    :catch_2b
    move-exception p1

    goto :goto_75

    :cond_2d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_35
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    :try_start_38
    iget-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast p1, LK3/d;

    iput-object p0, v0, LR3/a;->a:LA5/d;

    iput v4, v0, LR3/a;->d:I

    invoke-virtual {p1, v0}, LK3/d;->d(Lyc/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_44
    .catch Ljava/io/FileNotFoundException; {:try_start_38 .. :try_end_44} :catch_73

    if-ne p1, v1, :cond_47

    return-object v1

    :cond_47
    move-object v0, p0

    :goto_48
    iget-object p1, v0, LA5/d;->b:Ljava/lang/Object;

    check-cast p1, LK3/d;

    invoke-virtual {p1}, LK3/d;->b()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_57

    return-object v3

    :cond_57
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_5b
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_70

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type kotlin.String"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, LA5/d;->s(Ljava/lang/String;)V

    goto :goto_5b

    :cond_70
    return-object v3

    :goto_71
    move-object v0, p0

    goto :goto_75

    :catch_73
    move-exception p1

    goto :goto_71

    :goto_75
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_88

    iget-object v0, v0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LL3/a;

    const-string v1, "Event storage file not found: "

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, LL3/a;->warn(Ljava/lang/String;)V

    :cond_88
    return-object v3
.end method

.method public o()J
    .registers 3

    iget-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v0, LD1/o;

    if-eqz v0, :cond_9

    iget-wide v0, v0, LD1/o;->d:J

    goto :goto_b

    :cond_9
    const-wide/16 v0, -0x1

    :goto_b
    return-wide v0
.end method

.method public onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    .registers 5

    const-string v0, "call"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "e"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LA5/e;

    iget-object v1, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v1, Lio/sentry/v1;

    invoke-static {v0, p1, p2, v1}, LA5/e;->access$handleException(LA5/e;Lokhttp3/Call;Ljava/lang/Exception;Lio/sentry/v1;)V

    return-void
.end method

.method public onResponse(Lokhttp3/Call;Lokhttp3/Response;)V
    .registers 13

    const-string v0, "Unexpected HTTP code "

    const-string v1, "call"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "response"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iget-object v3, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v3, LA5/a;

    iput-wide v1, v3, LA5/a;->g:J

    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v1

    const/4 v2, 0x0

    iget-object v4, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v4, Lio/sentry/v1;

    iget-object v5, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v5, LA5/e;

    if-eqz v1, :cond_8b

    :try_start_25
    invoke-virtual {p2}, Lokhttp3/Response;->isSuccessful()Z

    move-result v6

    if-nez v6, :cond_44

    new-instance v3, Ljava/io/IOException;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-static {v5, p1, v3, v4}, LA5/e;->access$handleException(LA5/e;Lokhttp3/Call;Ljava/lang/Exception;Lio/sentry/v1;)V

    goto :goto_7f

    :catchall_40
    move-exception p1

    goto :goto_85

    :catch_42
    move-exception v0

    goto :goto_7c

    :cond_44
    sget-object v0, LD5/b;->c:Luc/l;

    const-string v0, "Content-Range"

    invoke-virtual {p2, v0}, Lokhttp3/Response;->header(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LC5/o;->d(Ljava/lang/String;)LD5/b;

    move-result-object v0

    if-eqz v0, :cond_63

    iget v6, v0, LD5/b;->a:I

    if-nez v6, :cond_5d

    iget v6, v0, LD5/b;->b:I

    const v7, 0x7fffffff

    if-eq v6, v7, :cond_63

    :cond_5d
    iput-object v0, v3, Lcom/facebook/imagepipeline/producers/C;->e:LD5/b;

    const/16 v0, 0x8

    iput v0, v3, Lcom/facebook/imagepipeline/producers/C;->d:I

    :cond_63
    invoke-virtual {v1}, Lokhttp3/ResponseBody;->contentLength()J

    move-result-wide v6

    const-wide/16 v8, 0x0

    cmp-long v0, v6, v8

    if-gez v0, :cond_6f

    const/4 v0, 0x0

    goto :goto_74

    :cond_6f
    invoke-virtual {v1}, Lokhttp3/ResponseBody;->contentLength()J

    move-result-wide v6

    long-to-int v0, v6

    :goto_74
    invoke-virtual {v1}, Lokhttp3/ResponseBody;->byteStream()Ljava/io/InputStream;

    move-result-object v3

    invoke-virtual {v4, v3, v0}, Lio/sentry/v1;->m(Ljava/io/InputStream;I)V
    :try_end_7b
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_7b} :catch_42
    .catchall {:try_start_25 .. :try_end_7b} :catchall_40

    goto :goto_7f

    :goto_7c
    :try_start_7c
    invoke-static {v5, p1, v0, v4}, LA5/e;->access$handleException(LA5/e;Lokhttp3/Call;Ljava/lang/Exception;Lio/sentry/v1;)V
    :try_end_7f
    .catchall {:try_start_7c .. :try_end_7f} :catchall_40

    :goto_7f
    invoke-static {v1, v2}, Ll7/g1;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    sget-object v2, Luc/z;->a:Luc/z;

    goto :goto_8b

    :goto_85
    :try_start_85
    throw p1
    :try_end_86
    .catchall {:try_start_85 .. :try_end_86} :catchall_86

    :catchall_86
    move-exception p2

    invoke-static {v1, p1}, Ll7/g1;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2

    :cond_8b
    :goto_8b
    if-nez v2, :cond_a3

    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Response body null: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {v0, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-static {v5, p1, v0, v4}, LA5/e;->access$handleException(LA5/e;Lokhttp3/Call;Ljava/lang/Exception;Lio/sentry/v1;)V

    :cond_a3
    return-void
.end method

.method public p(Lyc/d;)Ljava/lang/Object;
    .registers 22

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    instance-of v2, v0, LR3/b;

    if-eqz v2, :cond_17

    move-object v2, v0

    check-cast v2, LR3/b;

    iget v3, v2, LR3/b;->h:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, LR3/b;->h:I

    goto :goto_1c

    :cond_17
    new-instance v2, LR3/b;

    invoke-direct {v2, v1, v0}, LR3/b;-><init>(LA5/d;Lyc/d;)V

    :goto_1c
    iget-object v0, v2, LR3/b;->f:Ljava/lang/Object;

    sget-object v3, Lzc/a;->a:Lzc/a;

    iget v4, v2, LR3/b;->h:I

    const-string v5, "null cannot be cast to non-null type kotlin.String"

    const/4 v6, 0x2

    const-string v7, "$set"

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v4, :cond_54

    if-eq v4, v8, :cond_4b

    if-ne v4, v6, :cond_43

    iget-object v4, v2, LR3/b;->e:Ljava/lang/Object;

    iget-object v10, v2, LR3/b;->d:Ljava/util/Iterator;

    iget-object v11, v2, LR3/b;->c:Ljava/util/Map;

    check-cast v11, Ljava/util/Map;

    iget-object v12, v2, LR3/b;->b:LP3/a;

    iget-object v13, v2, LR3/b;->a:LA5/d;

    :try_start_3b
    invoke-static {v0}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_3e} :catch_40

    goto/16 :goto_ad

    :catch_40
    move-exception v0

    goto/16 :goto_1bd

    :cond_43
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4b
    iget-object v4, v2, LR3/b;->a:LA5/d;

    :try_start_4d
    invoke-static {v0}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_50
    .catch Ljava/io/FileNotFoundException; {:try_start_4d .. :try_end_50} :catch_51

    goto :goto_67

    :catch_51
    move-exception v0

    goto/16 :goto_1ed

    :cond_54
    invoke-static {v0}, Ll7/C6;->j(Ljava/lang/Object;)V

    :try_start_57
    iget-object v0, v1, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LK3/d;

    iput-object v1, v2, LR3/b;->a:LA5/d;

    iput v8, v2, LR3/b;->h:I

    invoke-virtual {v0, v2}, LK3/d;->d(Lyc/d;)Ljava/lang/Object;

    move-result-object v0
    :try_end_63
    .catch Ljava/io/FileNotFoundException; {:try_start_57 .. :try_end_63} :catch_1eb

    if-ne v0, v3, :cond_66

    return-object v3

    :cond_66
    move-object v4, v1

    :goto_67
    iget-object v0, v4, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LK3/d;

    invoke-virtual {v0}, LK3/d;->b()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_76

    return-object v9

    :cond_76
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object v10, v0

    move-object v13, v4

    move-object v11, v9

    move-object v12, v11

    :goto_7e
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1df

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    :try_start_88
    iget-object v0, v13, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LK3/d;

    iput-object v13, v2, LR3/b;->a:LA5/d;

    iput-object v12, v2, LR3/b;->b:LP3/a;

    move-object v14, v11

    check-cast v14, Ljava/util/Map;

    iput-object v14, v2, LR3/b;->c:Ljava/util/Map;

    iput-object v10, v2, LR3/b;->d:Ljava/util/Iterator;

    iput-object v4, v2, LR3/b;->e:Ljava/lang/Object;

    iput v6, v2, LR3/b;->h:I

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v14, v4

    check-cast v14, Ljava/lang/String;

    iget-object v0, v0, LK3/d;->e:LT3/l;

    invoke-virtual {v0, v14, v2}, LT3/l;->e(Ljava/lang/String;Lyc/d;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v3, :cond_ad

    return-object v3

    :cond_ad
    :goto_ad
    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v14

    if-nez v14, :cond_bf

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v4

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v13, v0}, LA5/d;->s(Ljava/lang/String;)V

    goto :goto_7e

    :cond_bf
    new-instance v14, Lorg/json/JSONArray;

    invoke-direct {v14, v0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    invoke-static {v14}, Ll7/u6;->g(Lorg/json/JSONArray;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v14

    if-eqz v14, :cond_d8

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v4

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v13, v0}, LA5/d;->s(Ljava/lang/String;)V
    :try_end_d7
    .catch Ljava/lang/Exception; {:try_start_88 .. :try_end_d7} :catch_40

    goto :goto_7e

    :cond_d8
    const-string v14, "null cannot be cast to non-null type kotlin.collections.MutableMap<kotlin.String, kotlin.Any?>"

    if-nez v12, :cond_13c

    const/4 v15, 0x0

    :try_start_dd
    invoke-virtual {v0, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, LP3/a;
    :try_end_e3
    .catch Ljava/lang/Exception; {:try_start_dd .. :try_end_e3} :catch_40

    :try_start_e3
    iget-object v12, v15, LP3/a;->N:Ljava/util/Map;

    if-eqz v12, :cond_f0

    invoke-interface {v12, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    goto :goto_f1

    :catch_ec
    move-exception v0

    :goto_ed
    move-object v12, v15

    goto/16 :goto_1bd

    :cond_f0
    move-object v12, v9

    :goto_f1
    invoke-static {v12, v14}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v12}, Lkotlin/jvm/internal/C;->b(Ljava/lang/Object;)Ljava/util/Map;

    move-result-object v12

    const-string v6, "map"

    invoke-static {v12, v6}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-interface {v12}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v12

    invoke-interface {v12}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_10a
    :goto_10a
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v16
    :try_end_10e
    .catch Ljava/lang/Exception; {:try_start_e3 .. :try_end_10e} :catch_ec

    if-eqz v16, :cond_12a

    :try_start_110
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/util/Map$Entry;

    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v17

    if-eqz v17, :cond_10a

    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v6, v9, v8}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto :goto_10a

    :cond_12a
    invoke-static {v6}, Lvc/A;->k(Ljava/util/Map;)Ljava/util/LinkedHashMap;

    move-result-object v11

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v6
    :try_end_132
    .catch Ljava/lang/Exception; {:try_start_110 .. :try_end_132} :catch_139

    const/4 v8, 0x1

    :try_start_133
    invoke-virtual {v0, v8, v6}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v0
    :try_end_137
    .catch Ljava/lang/Exception; {:try_start_133 .. :try_end_137} :catch_ec

    move-object v12, v15

    goto :goto_13c

    :catch_139
    move-exception v0

    const/4 v8, 0x1

    goto :goto_ed

    :cond_13c
    :goto_13c
    :try_start_13c
    const-string v6, "events"

    invoke-static {v0, v6}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_14c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_1aa

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LP3/a;

    iget-object v9, v9, LP3/a;->N:Ljava/util/Map;

    invoke-static {v9}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    invoke-interface {v9, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9, v14}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Lkotlin/jvm/internal/C;->b(Ljava/lang/Object;)Ljava/util/Map;

    move-result-object v9

    const-string v15, "map"

    invoke-static {v9, v15}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v15, Ljava/util/LinkedHashMap;

    invoke-direct {v15}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-interface {v9}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_17a
    :goto_17a
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_19d

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/util/Map$Entry;

    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v18

    if-eqz v18, :cond_17a

    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v19, v0

    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v15, v8, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v0, v19

    const/4 v8, 0x1

    goto :goto_17a

    :cond_19d
    move-object/from16 v19, v0

    invoke-static {v15}, Lvc/A;->k(Ljava/util/Map;)Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-interface {v6, v0}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    move-object/from16 v0, v19

    const/4 v8, 0x1

    goto :goto_14c

    :cond_1aa
    if-eqz v11, :cond_1af

    invoke-interface {v11, v6}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    :cond_1af
    invoke-static {v4, v5}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v4

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v13, v0}, LA5/d;->s(Ljava/lang/String;)V
    :try_end_1b8
    .catch Ljava/lang/Exception; {:try_start_13c .. :try_end_1b8} :catch_40

    :goto_1b8
    const/4 v6, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto/16 :goto_7e

    :goto_1bd
    iget-object v6, v13, LA5/d;->c:Ljava/lang/Object;

    check-cast v6, LL3/a;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "Identify Merge error: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v6, v0}, LL3/a;->warn(Ljava/lang/String;)V

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v13, v4}, LA5/d;->s(Ljava/lang/String;)V

    goto :goto_1b8

    :cond_1df
    if-eqz v12, :cond_1e8

    iget-object v0, v12, LP3/a;->N:Ljava/util/Map;

    if-eqz v0, :cond_1e8

    invoke-interface {v0, v7, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1e8
    return-object v12

    :goto_1e9
    move-object v4, v1

    goto :goto_1ed

    :catch_1eb
    move-exception v0

    goto :goto_1e9

    :goto_1ed
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_200

    iget-object v2, v4, LA5/d;->c:Ljava/lang/Object;

    check-cast v2, LL3/a;

    const-string v3, "Event storage file not found: "

    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v0}, LL3/a;->warn(Ljava/lang/String;)V

    :cond_200
    const/4 v2, 0x0

    return-object v2
.end method

.method public putLong(Ljava/lang/String;J)Z
    .registers 5

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Properties;

    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    invoke-virtual {p0}, LA5/d;->u()V

    const/4 p1, 0x1

    return p1
.end method

.method public q(Lc1/f;Landroid/net/Uri;Ljava/util/Map;JJLD1/y;)V
    .registers 21

    move-object v1, p0

    const/4 v8, 0x1

    new-instance v9, LD1/o;

    move-object v2, v9

    move-object v3, p1

    move-wide/from16 v4, p4

    move-wide/from16 v6, p6

    invoke-direct/range {v2 .. v7}, LD1/o;-><init>(LW0/k;JJ)V

    iput-object v9, v1, LA5/d;->d:Ljava/lang/Object;

    iget-object v0, v1, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LD1/w;

    if-eqz v0, :cond_16

    return-void

    :cond_16
    iget-object v0, v1, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, LD1/z;

    move-object v2, p2

    move-object v3, p3

    invoke-interface {v0, p2, p3}, LD1/z;->i(Landroid/net/Uri;Ljava/util/Map;)[LD1/w;

    move-result-object v0

    array-length v3, v0

    sget-object v4, Lj8/T;->b:Lj8/Q;

    const-string v4, "expectedSize"

    invoke-static {v3, v4}, Lj8/w;->c(ILjava/lang/String;)V

    new-instance v4, Lj8/P;

    invoke-direct {v4, v3}, Lj8/M;-><init>(I)V

    array-length v3, v0

    const/4 v5, 0x0

    if-ne v3, v8, :cond_37

    aget-object v0, v0, v5

    iput-object v0, v1, LA5/d;->c:Ljava/lang/Object;

    goto/16 :goto_94

    :cond_37
    array-length v3, v0

    move v6, v5

    :goto_39
    if-ge v6, v3, :cond_8e

    aget-object v7, v0, v6

    :try_start_3d
    invoke-interface {v7, v9}, LD1/w;->h(LD1/x;)Z

    move-result v10

    if-eqz v10, :cond_4a

    iput-object v7, v1, LA5/d;->c:Ljava/lang/Object;
    :try_end_45
    .catch Ljava/io/EOFException; {:try_start_3d .. :try_end_45} :catch_7b
    .catchall {:try_start_3d .. :try_end_45} :catchall_48

    iput v5, v9, LD1/o;->f:I

    goto :goto_8e

    :catchall_48
    move-exception v0

    goto :goto_67

    :cond_4a
    :try_start_4a
    invoke-interface {v7}, LD1/w;->j()Ljava/util/List;

    move-result-object v7

    invoke-virtual {v4, v7}, Lj8/M;->e(Ljava/lang/Iterable;)V
    :try_end_51
    .catch Ljava/io/EOFException; {:try_start_4a .. :try_end_51} :catch_7b
    .catchall {:try_start_4a .. :try_end_51} :catchall_48

    iget-object v7, v1, LA5/d;->c:Ljava/lang/Object;

    check-cast v7, LD1/w;

    if-nez v7, :cond_60

    iget-wide v10, v9, LD1/o;->d:J

    cmp-long v7, v10, p4

    if-nez v7, :cond_5e

    goto :goto_60

    :cond_5e
    move v7, v5

    goto :goto_61

    :cond_60
    :goto_60
    move v7, v8

    :goto_61
    invoke-static {v7}, Lm7/u;->e(Z)V

    iput v5, v9, LD1/o;->f:I

    goto :goto_8c

    :goto_67
    iget-object v2, v1, LA5/d;->c:Ljava/lang/Object;

    check-cast v2, LD1/w;

    if-nez v2, :cond_75

    iget-wide v2, v9, LD1/o;->d:J

    cmp-long v2, v2, p4

    if-nez v2, :cond_74

    goto :goto_75

    :cond_74
    move v8, v5

    :cond_75
    :goto_75
    invoke-static {v8}, Lm7/u;->e(Z)V

    iput v5, v9, LD1/o;->f:I

    throw v0

    :catch_7b
    iget-object v7, v1, LA5/d;->c:Ljava/lang/Object;

    check-cast v7, LD1/w;

    if-nez v7, :cond_8a

    iget-wide v10, v9, LD1/o;->d:J

    cmp-long v7, v10, p4

    if-nez v7, :cond_88

    goto :goto_8a

    :cond_88
    move v7, v5

    goto :goto_61

    :cond_8a
    :goto_8a
    move v7, v8

    goto :goto_61

    :goto_8c
    add-int/2addr v6, v8

    goto :goto_39

    :cond_8e
    :goto_8e
    iget-object v3, v1, LA5/d;->c:Ljava/lang/Object;

    check-cast v3, LD1/w;

    if-eqz v3, :cond_9e

    :goto_94
    iget-object v0, v1, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, LD1/w;

    move-object/from16 v2, p8

    invoke-interface {v0, v2}, LD1/w;->f(LD1/y;)V

    return-void

    :cond_9e
    new-instance v3, Ls1/d;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "None of the available extractors ("

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v7, LA/d;

    const-string v9, ", "

    invoke-direct {v7, v9}, LA/d;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lj8/T;->y([Ljava/lang/Object;)Lj8/q0;

    move-result-object v0

    new-instance v9, LD1/p;

    const/16 v10, 0xf

    invoke-direct {v9, v10}, LD1/p;-><init>(I)V

    invoke-static {v0, v9}, Ll7/n5;->c(Ljava/util/List;Li8/f;)Ljava/util/AbstractList;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v9, v0}, LA/d;->F(Ljava/lang/StringBuilder;Ljava/util/Iterator;)V

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ") could read the stream."

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Lj8/P;->i()Lj8/q0;

    move-result-object v2

    const/4 v4, 0x0

    invoke-direct {v3, v0, v4, v5, v8}, LW0/J;-><init>(Ljava/lang/String;Ljava/lang/Exception;ZI)V

    invoke-static {v2}, Lj8/T;->x(Ljava/util/Collection;)Lj8/T;

    throw v3
.end method

.method public r(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    const-string v0, "value"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Properties;

    invoke-virtual {v0, p1, p2}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    invoke-virtual {p0}, LA5/d;->u()V

    return-void
.end method

.method public s(Ljava/lang/String;)V
    .registers 6

    iget-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v0, LC3/e;

    iget-object v1, v0, LC3/e;->c:Lbe/A;

    new-instance v2, LR3/c;

    const/4 v3, 0x0

    invoke-direct {v2, p0, p1, v3}, LR3/c;-><init>(LA5/d;Ljava/lang/String;Lyc/d;)V

    const/4 p1, 0x2

    iget-object v0, v0, LC3/e;->f:Lbe/y;

    invoke-static {v1, v0, v3, v2, p1}, Lm7/X2;->b(Lbe/A;Lyc/j;Lbe/B;LHc/c;I)Lbe/v0;

    return-void
.end method

.method public t(LHc/a;)V
    .registers 6

    iget-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/replay/capture/h;

    iget-object v1, v0, Lio/sentry/android/replay/capture/h;->a:Lio/sentry/M1;

    invoke-virtual {v1}, Lio/sentry/M1;->getMainThreadChecker()Lio/sentry/util/thread/a;

    move-result-object v1

    invoke-interface {v1}, Lio/sentry/util/thread/a;->a()Z

    move-result v1

    if-eqz v1, :cond_23

    invoke-virtual {v0}, Lio/sentry/android/replay/capture/h;->j()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    new-instance v2, LF/d;

    const/16 v3, 0xa

    invoke-direct {v2, v3, p1}, LF/d;-><init>(ILjava/lang/Object;)V

    const-string p1, "CaptureStrategy.runInBackground"

    iget-object v0, v0, Lio/sentry/android/replay/capture/h;->a:Lio/sentry/M1;

    invoke-static {v1, v0, p1, v2}, Lcom/bumptech/glide/c;->f(Ljava/util/concurrent/ScheduledExecutorService;Lio/sentry/M1;Ljava/lang/String;Ljava/lang/Runnable;)V

    goto :goto_26

    :cond_23
    invoke-interface {p1}, LHc/a;->invoke()Ljava/lang/Object;

    :goto_26
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    iget v0, p0, LA5/d;->a:I

    packed-switch v0, :pswitch_data_3a

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "CollapsedTemplate(type=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\', layoutStyle="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v1, LIa/l;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", cards="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_data_3a
    .packed-switch 0x1
        :pswitch_a
    .end packed-switch
.end method

.method public u()V
    .registers 6

    iget-object v0, p0, LA5/d;->c:Ljava/lang/Object;

    check-cast v0, Ljava/io/File;

    :try_start_4
    new-instance v1, Ljava/io/FileOutputStream;

    invoke-direct {v1, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_9
    .catchall {:try_start_4 .. :try_end_9} :catchall_15

    :try_start_9
    iget-object v2, p0, LA5/d;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/Properties;

    const/4 v3, 0x0

    invoke-virtual {v2, v1, v3}, Ljava/util/Properties;->store(Ljava/io/OutputStream;Ljava/lang/String;)V
    :try_end_11
    .catchall {:try_start_9 .. :try_end_11} :catchall_17

    :try_start_11
    invoke-static {v1, v3}, Ll7/g1;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_14
    .catchall {:try_start_11 .. :try_end_14} :catchall_15

    goto :goto_45

    :catchall_15
    move-exception v1

    goto :goto_1e

    :catchall_17
    move-exception v2

    :try_start_18
    throw v2
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_19

    :catchall_19
    move-exception v3

    :try_start_1a
    invoke-static {v1, v2}, Ll7/g1;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v3
    :try_end_1e
    .catchall {:try_start_1a .. :try_end_1e} :catchall_15

    :goto_1e
    iget-object v2, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v2, LL3/a;

    if-eqz v2, :cond_45

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Failed to save property file with path "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", error stacktrace: "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1}, Lm7/C2;->d(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v0}, LL3/a;->error(Ljava/lang/String;)V

    :cond_45
    :goto_45
    return-void
.end method

.method public v(Ljava/lang/String;)V
    .registers 7

    iput-object p1, p0, LA5/d;->c:Ljava/lang/Object;

    iget-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LJ3/a;

    iget-object v1, v1, LJ3/a;->a:LB3/a;

    if-eqz v1, :cond_40

    iget-object v1, v1, LB3/a;->a:LB3/c;

    iget-object v2, v1, LB3/c;->a:Ljava/lang/Object;

    check-cast v2, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    :try_start_27
    iget-object v3, v1, LB3/c;->b:Ljava/lang/Object;

    check-cast v3, LB3/b;
    :try_end_2b
    .catchall {:try_start_27 .. :try_end_2b} :catchall_3b

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    iget-object v2, v3, LB3/b;->a:Ljava/lang/String;

    new-instance v4, LB3/b;

    iget-object v3, v3, LB3/b;->c:Ljava/util/Map;

    invoke-direct {v4, v2, p1, v3}, LB3/b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    invoke-virtual {v1, v4}, LB3/c;->a(LB3/b;)V

    goto :goto_a

    :catchall_3b
    move-exception p1

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    throw p1

    :cond_40
    const-string p1, "connector"

    invoke-static {p1}, Lkotlin/jvm/internal/l;->m(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    :cond_47
    return-void
.end method

.method public w(Ljava/lang/String;)V
    .registers 7

    iput-object p1, p0, LA5/d;->b:Ljava/lang/Object;

    iget-object v0, p0, LA5/d;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_49

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LJ3/a;

    iget-object v1, v1, LJ3/a;->a:LB3/a;

    if-eqz v1, :cond_42

    iget-object v1, v1, LB3/a;->a:LB3/c;

    iget-object v2, v1, LB3/c;->a:Ljava/lang/Object;

    check-cast v2, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    :try_start_27
    iget-object v3, v1, LB3/c;->b:Ljava/lang/Object;

    check-cast v3, LB3/b;
    :try_end_2b
    .catchall {:try_start_27 .. :try_end_2b} :catchall_3d

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    iget-object v2, v3, LB3/b;->a:Ljava/lang/String;

    new-instance v2, LB3/b;

    iget-object v4, v3, LB3/b;->b:Ljava/lang/String;

    iget-object v3, v3, LB3/b;->c:Ljava/util/Map;

    invoke-direct {v2, p1, v4, v3}, LB3/b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    invoke-virtual {v1, v2}, LB3/c;->a(LB3/b;)V

    goto :goto_a

    :catchall_3d
    move-exception p1

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    throw p1

    :cond_42
    const-string p1, "connector"

    invoke-static {p1}, Lkotlin/jvm/internal/l;->m(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    :cond_49
    return-void
.end method
