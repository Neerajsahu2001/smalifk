.class public final La5/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La5/c;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, La5/c;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La5/c;->a:La5/c;

    return-void
.end method
