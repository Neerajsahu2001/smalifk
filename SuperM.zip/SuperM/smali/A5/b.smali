.class public interface abstract La5/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La5/a;


# virtual methods
.method public bridge synthetic now()J
    .registers 3
    .annotation build LT4/c;
    .end annotation

    invoke-super {p0}, La5/a;->now()J

    move-result-wide v0

    return-wide v0
.end method

.method public abstract synthetic nowNanos()J
    .annotation build LT4/c;
    .end annotation
.end method
