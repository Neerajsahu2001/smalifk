.class public LA5/e;
.super Lm7/C3;
.source "SourceFile"


# instance fields
.field private final cacheControl:Lokhttp3/CacheControl;

.field private final callFactory:Lokhttp3/Call$Factory;

.field private final cancellationExecutor:Ljava/util/concurrent/Executor;


# direct methods
.method public constructor <init>(Lokhttp3/OkHttpClient;)V
    .registers 4

    invoke-virtual {p1}, Lokhttp3/OkHttpClient;->dispatcher()Lokhttp3/Dispatcher;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Dispatcher;->executorService()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const-string v1, "okHttpClient.dispatcher().executorService()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->callFactory:Lokhttp3/Call$Factory;

    iput-object v0, p0, LA5/e;->cancellationExecutor:Ljava/util/concurrent/Executor;

    new-instance p1, Lokhttp3/CacheControl$Builder;

    invoke-direct {p1}, Lokhttp3/CacheControl$Builder;-><init>()V

    invoke-virtual {p1}, Lokhttp3/CacheControl$Builder;->noStore()Lokhttp3/CacheControl$Builder;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/CacheControl$Builder;->build()Lokhttp3/CacheControl;

    move-result-object p1

    iput-object p1, p0, LA5/e;->cacheControl:Lokhttp3/CacheControl;

    return-void
.end method

.method public static final synthetic access$getCancellationExecutor$p(LA5/e;)Ljava/util/concurrent/Executor;
    .registers 1

    iget-object p0, p0, LA5/e;->cancellationExecutor:Ljava/util/concurrent/Executor;

    return-object p0
.end method

.method public static final access$handleException(LA5/e;Lokhttp3/Call;Ljava/lang/Exception;Lio/sentry/v1;)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Lokhttp3/Call;->isCanceled()Z

    move-result p0

    if-eqz p0, :cond_25

    iget-object p0, p3, Lio/sentry/v1;->b:Ljava/lang/Object;

    check-cast p0, Lcom/facebook/imagepipeline/producers/i;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p3, Lio/sentry/v1;->a:Ljava/lang/Object;

    check-cast p0, Lcom/facebook/imagepipeline/producers/C;

    invoke-virtual {p0}, Lcom/facebook/imagepipeline/producers/C;->a()Lcom/facebook/imagepipeline/producers/j0;

    move-result-object p1

    iget-object p2, p0, Lcom/facebook/imagepipeline/producers/C;->b:Lcom/facebook/imagepipeline/producers/i0;

    const-string p3, "NetworkFetchProducer"

    invoke-interface {p1, p2, p3}, Lcom/facebook/imagepipeline/producers/j0;->f(Lcom/facebook/imagepipeline/producers/i0;Ljava/lang/String;)V

    iget-object p0, p0, Lcom/facebook/imagepipeline/producers/C;->a:Lcom/facebook/imagepipeline/producers/c;

    invoke-virtual {p0}, Lcom/facebook/imagepipeline/producers/c;->c()V

    goto :goto_28

    :cond_25
    invoke-virtual {p3, p2}, Lio/sentry/v1;->k(Ljava/lang/Throwable;)V

    :goto_28
    return-void
.end method


# virtual methods
.method public final createFetchState(Lcom/facebook/imagepipeline/producers/c;Lcom/facebook/imagepipeline/producers/i0;)Lcom/facebook/imagepipeline/producers/C;
    .registers 4

    const-string v0, "consumer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "context"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LA5/a;

    invoke-direct {v0, p1, p2}, Lcom/facebook/imagepipeline/producers/C;-><init>(Lcom/facebook/imagepipeline/producers/c;Lcom/facebook/imagepipeline/producers/i0;)V

    return-object v0
.end method

.method public fetch(LA5/a;Lio/sentry/v1;)V
    .registers 8

    const-string v0, "fetchState"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p1, LA5/a;->f:J

    iget-object v0, p1, Lcom/facebook/imagepipeline/producers/C;->b:Lcom/facebook/imagepipeline/producers/i0;

    move-object v1, v0

    check-cast v1, Lcom/facebook/imagepipeline/producers/d;

    iget-object v1, v1, Lcom/facebook/imagepipeline/producers/d;->a:LN5/d;

    invoke-virtual {v1}, LN5/d;->getSourceUri()Landroid/net/Uri;

    move-result-object v1

    const-string v2, "fetchState.uri"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_1b
    new-instance v2, Lokhttp3/Request$Builder;

    invoke-direct {v2}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/Request$Builder;->get()Lokhttp3/Request$Builder;

    move-result-object v1

    iget-object v2, p0, LA5/e;->cacheControl:Lokhttp3/CacheControl;

    if-eqz v2, :cond_3b

    const-string v3, "requestBuilder"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lokhttp3/Request$Builder;->cacheControl(Lokhttp3/CacheControl;)Lokhttp3/Request$Builder;

    goto :goto_3b

    :catch_39
    move-exception p1

    goto :goto_7e

    :cond_3b
    :goto_3b
    check-cast v0, Lcom/facebook/imagepipeline/producers/d;

    iget-object v0, v0, Lcom/facebook/imagepipeline/producers/d;->a:LN5/d;

    invoke-virtual {v0}, LN5/d;->getBytesRange()LD5/b;

    move-result-object v0

    if-eqz v0, :cond_68

    const-string v2, "Range"

    sget-object v3, LD5/b;->c:Luc/l;

    iget v3, v0, LD5/b;->a:I

    invoke-static {v3}, LC5/o;->c(I)Ljava/lang/String;

    move-result-object v3

    iget v0, v0, LD5/b;->b:I

    invoke-static {v0}, LC5/o;->c(I)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v3, v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    invoke-static {v0, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v3, "bytes=%s-%s"

    const/4 v4, 0x0

    invoke-static {v4, v3, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    :cond_68
    instance-of v0, v1, Lokhttp3/Request$Builder;

    if-nez v0, :cond_71

    invoke-virtual {v1}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    goto :goto_75

    :cond_71
    invoke-static {v1}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object v0

    :goto_75
    const-string v1, "requestBuilder.build()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2, v0}, LA5/e;->fetchWithRequest(LA5/a;Lio/sentry/v1;Lokhttp3/Request;)V
    :try_end_7d
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_7d} :catch_39

    goto :goto_81

    :goto_7e
    invoke-virtual {p2, p1}, Lio/sentry/v1;->k(Ljava/lang/Throwable;)V

    :goto_81
    return-void
.end method

.method public bridge synthetic fetch(Lcom/facebook/imagepipeline/producers/C;Lio/sentry/v1;)V
    .registers 3

    check-cast p1, LA5/a;

    invoke-virtual {p0, p1, p2}, LA5/e;->fetch(LA5/a;Lio/sentry/v1;)V

    return-void
.end method

.method public final fetchWithRequest(LA5/a;Lio/sentry/v1;Lokhttp3/Request;)V
    .registers 6

    const-string v0, "fetchState"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "request"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA5/e;->callFactory:Lokhttp3/Call$Factory;

    instance-of v1, v0, Lokhttp3/OkHttpClient;

    if-nez v1, :cond_15

    invoke-interface {v0, p3}, Lokhttp3/Call$Factory;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p3

    goto :goto_1b

    :cond_15
    check-cast v0, Lokhttp3/OkHttpClient;

    invoke-static {v0, p3}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->newCall(Lokhttp3/OkHttpClient;Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p3

    :goto_1b
    new-instance v0, LA5/c;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p3, p0}, LA5/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    iget-object v1, p1, Lcom/facebook/imagepipeline/producers/C;->b:Lcom/facebook/imagepipeline/producers/i0;

    check-cast v1, Lcom/facebook/imagepipeline/producers/d;

    invoke-virtual {v1, v0}, Lcom/facebook/imagepipeline/producers/d;->a(Lcom/facebook/imagepipeline/producers/e;)V

    new-instance v0, LA5/d;

    const/4 v1, 0x0

    invoke-direct {v0, p1, p0, p2, v1}, LA5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {p3, v0}, Lcom/google/firebase/perf/network/FirebasePerfOkHttpClient;->enqueue(Lokhttp3/Call;Lokhttp3/Callback;)V

    return-void
.end method

.method public final getExtraMap(Lcom/facebook/imagepipeline/producers/C;I)Ljava/util/Map;
    .registers 10

    check-cast p1, LA5/a;

    const-string v0, "fetchState"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-wide v0, p1, LA5/a;->g:J

    iget-wide v2, p1, LA5/a;->f:J

    sub-long/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Luc/h;

    const-string v2, "queue_time"

    invoke-direct {v1, v2, v0}, Luc/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iget-wide v2, p1, LA5/a;->h:J

    iget-wide v4, p1, LA5/a;->g:J

    sub-long/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Luc/h;

    const-string v3, "fetch_time"

    invoke-direct {v2, v3, v0}, Luc/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iget-wide v3, p1, LA5/a;->h:J

    iget-wide v5, p1, LA5/a;->f:J

    sub-long/2addr v3, v5

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p1

    new-instance v0, Luc/h;

    const-string v3, "total_time"

    invoke-direct {v0, v3, p1}, Luc/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Luc/h;

    const-string v3, "image_size"

    invoke-direct {p2, v3, p1}, Luc/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    filled-new-array {v1, v2, v0, p2}, [Luc/h;

    move-result-object p1

    invoke-static {p1}, Lvc/A;->f([Luc/h;)Ljava/util/Map;

    move-result-object p1

    return-object p1
.end method

.method public final onFetchCompletion(Lcom/facebook/imagepipeline/producers/C;)V
    .registers 4

    check-cast p1, LA5/a;

    const-string v0, "fetchState"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p1, LA5/a;->h:J

    return-void
.end method
