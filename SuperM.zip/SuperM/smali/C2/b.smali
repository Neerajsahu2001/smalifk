.class public final Lc2/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I


# direct methods
.method public constructor <init>(IIIIII)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc2/b;->a:I

    iput p2, p0, Lc2/b;->b:I

    iput p3, p0, Lc2/b;->c:I

    iput p4, p0, Lc2/b;->d:I

    iput p5, p0, Lc2/b;->e:I

    iput p6, p0, Lc2/b;->f:I

    return-void
.end method
