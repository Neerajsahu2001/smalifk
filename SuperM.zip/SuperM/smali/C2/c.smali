.class public final Lc2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Z

.field public final c:[B

.field public final d:[B


# direct methods
.method public constructor <init>(IZ[B[B)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc2/c;->a:I

    iput-boolean p2, p0, Lc2/c;->b:Z

    iput-object p3, p0, Lc2/c;->c:[B

    iput-object p4, p0, Lc2/c;->d:[B

    return-void
.end method
