.class public final Lc2/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/l;


# static fields
.field public static final h:[B

.field public static final i:[B

.field public static final j:[B


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/Paint;

.field public final c:Landroid/graphics/Canvas;

.field public final d:Lc2/b;

.field public final e:Lc2/a;

.field public final f:Lc2/g;

.field public g:Landroid/graphics/Bitmap;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/4 v0, 0x4

    new-array v1, v0, [B

    fill-array-data v1, :array_1a

    sput-object v1, Lc2/h;->h:[B

    new-array v0, v0, [B

    fill-array-data v0, :array_20

    sput-object v0, Lc2/h;->i:[B

    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_26

    sput-object v0, Lc2/h;->j:[B

    return-void

    nop

    :array_1a
    .array-data 1
        0x0t
        0x7t
        0x8t
        0xft
    .end array-data

    :array_20
    .array-data 1
        0x0t
        0x77t
        -0x78t
        -0x1t
    .end array-data

    :array_26
    .array-data 1
        0x0t
        0x11t
        0x22t
        0x33t
        0x44t
        0x55t
        0x66t
        0x77t
        -0x78t
        -0x67t
        -0x56t
        -0x45t
        -0x34t
        -0x23t
        -0x12t
        -0x1t
    .end array-data
.end method

.method public constructor <init>(Ljava/util/List;)V
    .registers 12

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LZ0/w;

    const/4 v1, 0x0

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [B

    invoke-direct {v0, p1}, LZ0/w;-><init>([B)V

    invoke-virtual {v0}, LZ0/w;->A()I

    move-result p1

    invoke-virtual {v0}, LZ0/w;->A()I

    move-result v0

    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    iput-object v2, p0, Lc2/h;->a:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    new-instance v3, Landroid/graphics/PorterDuffXfermode;

    sget-object v4, Landroid/graphics/PorterDuff$Mode;->SRC:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v3, v4}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    iput-object v2, p0, Lc2/h;->b:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    new-instance v4, Landroid/graphics/PorterDuffXfermode;

    sget-object v5, Landroid/graphics/PorterDuff$Mode;->DST_OVER:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v4, v5}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2}, Landroid/graphics/Canvas;-><init>()V

    iput-object v2, p0, Lc2/h;->c:Landroid/graphics/Canvas;

    new-instance v2, Lc2/b;

    const/4 v6, 0x0

    const/16 v7, 0x2cf

    const/16 v4, 0x2cf

    const/16 v5, 0x23f

    const/4 v8, 0x0

    const/16 v9, 0x23f

    move-object v3, v2

    invoke-direct/range {v3 .. v9}, Lc2/b;-><init>(IIIIII)V

    iput-object v2, p0, Lc2/h;->d:Lc2/b;

    new-instance v2, Lc2/a;

    const v3, -0x808081

    const/4 v4, -0x1

    const/high16 v5, -0x1000000

    filled-new-array {v1, v4, v5, v3}, [I

    move-result-object v3

    invoke-static {}, Lc2/h;->c()[I

    move-result-object v4

    invoke-static {}, Lc2/h;->e()[I

    move-result-object v5

    invoke-direct {v2, v1, v3, v4, v5}, Lc2/a;-><init>(I[I[I[I)V

    iput-object v2, p0, Lc2/h;->e:Lc2/a;

    new-instance v1, Lc2/g;

    invoke-direct {v1, p1, v0}, Lc2/g;-><init>(II)V

    iput-object v1, p0, Lc2/h;->f:Lc2/g;

    return-void
.end method

.method public static a(IILZ0/v;)[B
    .registers 6

    new-array v0, p0, [B

    const/4 v1, 0x0

    :goto_3
    if-ge v1, p0, :cond_f

    invoke-virtual {p2, p1}, LZ0/v;->i(I)I

    move-result v2

    int-to-byte v2, v2

    aput-byte v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_f
    return-object v0
.end method

.method public static c()[I
    .registers 9

    const/16 v0, 0x10

    new-array v1, v0, [I

    const/4 v2, 0x0

    aput v2, v1, v2

    const/4 v3, 0x1

    :goto_8
    if-ge v3, v0, :cond_4b

    const/16 v4, 0x8

    const/16 v5, 0xff

    if-ge v3, v4, :cond_2c

    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_16

    move v4, v5

    goto :goto_17

    :cond_16
    move v4, v2

    :goto_17
    and-int/lit8 v6, v3, 0x2

    if-eqz v6, :cond_1d

    move v6, v5

    goto :goto_1e

    :cond_1d
    move v6, v2

    :goto_1e
    and-int/lit8 v7, v3, 0x4

    if-eqz v7, :cond_24

    move v7, v5

    goto :goto_25

    :cond_24
    move v7, v2

    :goto_25
    invoke-static {v5, v4, v6, v7}, Lc2/h;->f(IIII)I

    move-result v4

    aput v4, v1, v3

    goto :goto_48

    :cond_2c
    and-int/lit8 v4, v3, 0x1

    const/16 v6, 0x7f

    if-eqz v4, :cond_34

    move v4, v6

    goto :goto_35

    :cond_34
    move v4, v2

    :goto_35
    and-int/lit8 v7, v3, 0x2

    if-eqz v7, :cond_3b

    move v7, v6

    goto :goto_3c

    :cond_3b
    move v7, v2

    :goto_3c
    and-int/lit8 v8, v3, 0x4

    if-eqz v8, :cond_41

    goto :goto_42

    :cond_41
    move v6, v2

    :goto_42
    invoke-static {v5, v4, v7, v6}, Lc2/h;->f(IIII)I

    move-result v4

    aput v4, v1, v3

    :goto_48
    add-int/lit8 v3, v3, 0x1

    goto :goto_8

    :cond_4b
    return-object v1
.end method

.method public static e()[I
    .registers 11

    const/16 v0, 0x100

    new-array v1, v0, [I

    const/4 v2, 0x0

    aput v2, v1, v2

    move v3, v2

    :goto_8
    if-ge v3, v0, :cond_116

    const/16 v4, 0x8

    const/16 v5, 0xff

    if-ge v3, v4, :cond_2e

    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_16

    move v4, v5

    goto :goto_17

    :cond_16
    move v4, v2

    :goto_17
    and-int/lit8 v6, v3, 0x2

    if-eqz v6, :cond_1d

    move v6, v5

    goto :goto_1e

    :cond_1d
    move v6, v2

    :goto_1e
    and-int/lit8 v7, v3, 0x4

    if-eqz v7, :cond_23

    goto :goto_24

    :cond_23
    move v5, v2

    :goto_24
    const/16 v7, 0x3f

    invoke-static {v7, v4, v6, v5}, Lc2/h;->f(IIII)I

    move-result v4

    aput v4, v1, v3

    goto/16 :goto_112

    :cond_2e
    and-int/lit16 v6, v3, 0x88

    const/16 v7, 0xaa

    const/16 v8, 0x55

    if-eqz v6, :cond_e1

    const/16 v9, 0x7f

    if-eq v6, v4, :cond_af

    const/16 v4, 0x80

    const/16 v7, 0x2b

    if-eq v6, v4, :cond_79

    const/16 v4, 0x88

    if-eq v6, v4, :cond_46

    goto/16 :goto_112

    :cond_46
    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_4c

    move v4, v7

    goto :goto_4d

    :cond_4c
    move v4, v2

    :goto_4d
    and-int/lit8 v6, v3, 0x10

    if-eqz v6, :cond_53

    move v6, v8

    goto :goto_54

    :cond_53
    move v6, v2

    :goto_54
    add-int/2addr v4, v6

    and-int/lit8 v6, v3, 0x2

    if-eqz v6, :cond_5b

    move v6, v7

    goto :goto_5c

    :cond_5b
    move v6, v2

    :goto_5c
    and-int/lit8 v9, v3, 0x20

    if-eqz v9, :cond_62

    move v9, v8

    goto :goto_63

    :cond_62
    move v9, v2

    :goto_63
    add-int/2addr v6, v9

    and-int/lit8 v9, v3, 0x4

    if-eqz v9, :cond_69

    goto :goto_6a

    :cond_69
    move v7, v2

    :goto_6a
    and-int/lit8 v9, v3, 0x40

    if-eqz v9, :cond_6f

    goto :goto_70

    :cond_6f
    move v8, v2

    :goto_70
    add-int/2addr v7, v8

    invoke-static {v5, v4, v6, v7}, Lc2/h;->f(IIII)I

    move-result v4

    aput v4, v1, v3

    goto/16 :goto_112

    :cond_79
    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_7f

    move v4, v7

    goto :goto_80

    :cond_7f
    move v4, v2

    :goto_80
    add-int/2addr v4, v9

    and-int/lit8 v6, v3, 0x10

    if-eqz v6, :cond_87

    move v6, v8

    goto :goto_88

    :cond_87
    move v6, v2

    :goto_88
    add-int/2addr v4, v6

    and-int/lit8 v6, v3, 0x2

    if-eqz v6, :cond_8f

    move v6, v7

    goto :goto_90

    :cond_8f
    move v6, v2

    :goto_90
    add-int/2addr v6, v9

    and-int/lit8 v10, v3, 0x20

    if-eqz v10, :cond_97

    move v10, v8

    goto :goto_98

    :cond_97
    move v10, v2

    :goto_98
    add-int/2addr v6, v10

    and-int/lit8 v10, v3, 0x4

    if-eqz v10, :cond_9e

    goto :goto_9f

    :cond_9e
    move v7, v2

    :goto_9f
    add-int/2addr v7, v9

    and-int/lit8 v9, v3, 0x40

    if-eqz v9, :cond_a5

    goto :goto_a6

    :cond_a5
    move v8, v2

    :goto_a6
    add-int/2addr v7, v8

    invoke-static {v5, v4, v6, v7}, Lc2/h;->f(IIII)I

    move-result v4

    aput v4, v1, v3

    goto/16 :goto_112

    :cond_af
    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_b5

    move v4, v8

    goto :goto_b6

    :cond_b5
    move v4, v2

    :goto_b6
    and-int/lit8 v5, v3, 0x10

    if-eqz v5, :cond_bc

    move v5, v7

    goto :goto_bd

    :cond_bc
    move v5, v2

    :goto_bd
    add-int/2addr v4, v5

    and-int/lit8 v5, v3, 0x2

    if-eqz v5, :cond_c4

    move v5, v8

    goto :goto_c5

    :cond_c4
    move v5, v2

    :goto_c5
    and-int/lit8 v6, v3, 0x20

    if-eqz v6, :cond_cb

    move v6, v7

    goto :goto_cc

    :cond_cb
    move v6, v2

    :goto_cc
    add-int/2addr v5, v6

    and-int/lit8 v6, v3, 0x4

    if-eqz v6, :cond_d2

    goto :goto_d3

    :cond_d2
    move v8, v2

    :goto_d3
    and-int/lit8 v6, v3, 0x40

    if-eqz v6, :cond_d8

    goto :goto_d9

    :cond_d8
    move v7, v2

    :goto_d9
    add-int/2addr v8, v7

    invoke-static {v9, v4, v5, v8}, Lc2/h;->f(IIII)I

    move-result v4

    aput v4, v1, v3

    goto :goto_112

    :cond_e1
    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_e7

    move v4, v8

    goto :goto_e8

    :cond_e7
    move v4, v2

    :goto_e8
    and-int/lit8 v6, v3, 0x10

    if-eqz v6, :cond_ee

    move v6, v7

    goto :goto_ef

    :cond_ee
    move v6, v2

    :goto_ef
    add-int/2addr v4, v6

    and-int/lit8 v6, v3, 0x2

    if-eqz v6, :cond_f6

    move v6, v8

    goto :goto_f7

    :cond_f6
    move v6, v2

    :goto_f7
    and-int/lit8 v9, v3, 0x20

    if-eqz v9, :cond_fd

    move v9, v7

    goto :goto_fe

    :cond_fd
    move v9, v2

    :goto_fe
    add-int/2addr v6, v9

    and-int/lit8 v9, v3, 0x4

    if-eqz v9, :cond_104

    goto :goto_105

    :cond_104
    move v8, v2

    :goto_105
    and-int/lit8 v9, v3, 0x40

    if-eqz v9, :cond_10a

    goto :goto_10b

    :cond_10a
    move v7, v2

    :goto_10b
    add-int/2addr v8, v7

    invoke-static {v5, v4, v6, v8}, Lc2/h;->f(IIII)I

    move-result v4

    aput v4, v1, v3

    :goto_112
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_8

    :cond_116
    return-object v1
.end method

.method public static f(IIII)I
    .registers 4

    shl-int/lit8 p0, p0, 0x18

    shl-int/lit8 p1, p1, 0x10

    or-int/2addr p0, p1

    shl-int/lit8 p1, p2, 0x8

    or-int/2addr p0, p1

    or-int/2addr p0, p3

    return p0
.end method

.method public static g([B[IIIILandroid/graphics/Paint;Landroid/graphics/Canvas;)V
    .registers 30

    move-object/from16 v0, p0

    move/from16 v1, p2

    move-object/from16 v8, p5

    new-instance v9, LZ0/v;

    array-length v2, v0

    invoke-direct {v9, v0, v2}, LZ0/v;-><init>([BI)V

    move/from16 v2, p3

    move/from16 v10, p4

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    :goto_13
    invoke-virtual {v9}, LZ0/v;->b()I

    move-result v3

    if-eqz v3, :cond_234

    const/16 v14, 0x8

    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v3

    const/16 v4, 0xf0

    if-eq v3, v4, :cond_22e

    const/4 v15, 0x1

    const/16 v16, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x2

    packed-switch v3, :pswitch_data_236

    packed-switch v3, :pswitch_data_240

    goto :goto_13

    :pswitch_30
    const/16 v3, 0x10

    invoke-static {v3, v14, v9}, Lc2/h;->a(IILZ0/v;)[B

    move-result-object v12

    goto :goto_13

    :pswitch_37
    invoke-static {v6, v14, v9}, Lc2/h;->a(IILZ0/v;)[B

    move-result-object v11

    goto :goto_13

    :pswitch_3c
    invoke-static {v6, v6, v9}, Lc2/h;->a(IILZ0/v;)[B

    move-result-object v13

    goto :goto_13

    :pswitch_41
    move v7, v2

    move/from16 v2, v16

    :goto_44
    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v3

    if-eqz v3, :cond_4f

    move/from16 v17, v2

    move/from16 v18, v15

    goto :goto_77

    :cond_4f
    invoke-virtual {v9}, LZ0/v;->h()Z

    move-result v3

    const/4 v4, 0x7

    if-nez v3, :cond_6a

    invoke-virtual {v9, v4}, LZ0/v;->i(I)I

    move-result v3

    if-eqz v3, :cond_63

    move/from16 v17, v2

    move/from16 v18, v3

    move/from16 v3, v16

    goto :goto_77

    :cond_63
    move/from16 v17, v15

    move/from16 v3, v16

    move/from16 v18, v3

    goto :goto_77

    :cond_6a
    invoke-virtual {v9, v4}, LZ0/v;->i(I)I

    move-result v3

    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v4

    move/from16 v17, v2

    move/from16 v18, v3

    move v3, v4

    :goto_77
    if-eqz v18, :cond_92

    if-eqz v8, :cond_92

    aget v2, p1, v3

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v3, v7

    int-to-float v4, v10

    add-int v2, v7, v18

    int-to-float v5, v2

    add-int/lit8 v2, v10, 0x1

    int-to-float v6, v2

    move-object/from16 v2, p6

    move/from16 v19, v7

    move-object/from16 v7, p5

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_94

    :cond_92
    move/from16 v19, v7

    :goto_94
    add-int v7, v19, v18

    if-eqz v17, :cond_9b

    :goto_98
    move v2, v7

    goto/16 :goto_13

    :cond_9b
    move/from16 v2, v17

    goto :goto_44

    :pswitch_9e
    if-ne v1, v7, :cond_a9

    if-nez v12, :cond_a5

    sget-object v3, Lc2/h;->j:[B

    goto :goto_a6

    :cond_a5
    move-object v3, v12

    :goto_a6
    move-object/from16 v17, v3

    goto :goto_ab

    :cond_a9
    const/16 v17, 0x0

    :goto_ab
    move v4, v2

    move/from16 v2, v16

    :goto_ae
    invoke-virtual {v9, v6}, LZ0/v;->i(I)I

    move-result v3

    if-eqz v3, :cond_ba

    move/from16 v18, v2

    move/from16 v19, v15

    goto/16 :goto_11b

    :cond_ba
    invoke-virtual {v9}, LZ0/v;->h()Z

    move-result v3

    if-nez v3, :cond_d6

    invoke-virtual {v9, v7}, LZ0/v;->i(I)I

    move-result v3

    if-eqz v3, :cond_cf

    add-int/lit8 v3, v3, 0x2

    move/from16 v18, v2

    move/from16 v19, v3

    :goto_cc
    move/from16 v3, v16

    goto :goto_11b

    :cond_cf
    move/from16 v18, v15

    :goto_d1
    move/from16 v3, v16

    move/from16 v19, v3

    goto :goto_11b

    :cond_d6
    invoke-virtual {v9}, LZ0/v;->h()Z

    move-result v3

    if-nez v3, :cond_ec

    invoke-virtual {v9, v5}, LZ0/v;->i(I)I

    move-result v3

    add-int/2addr v3, v6

    invoke-virtual {v9, v6}, LZ0/v;->i(I)I

    move-result v18

    :goto_e5
    move/from16 v19, v3

    move/from16 v3, v18

    move/from16 v18, v2

    goto :goto_11b

    :cond_ec
    invoke-virtual {v9, v5}, LZ0/v;->i(I)I

    move-result v3

    if-eqz v3, :cond_116

    if-eq v3, v15, :cond_111

    if-eq v3, v5, :cond_106

    if-eq v3, v7, :cond_fb

    move/from16 v18, v2

    goto :goto_d1

    :cond_fb
    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v3

    add-int/lit8 v3, v3, 0x19

    invoke-virtual {v9, v6}, LZ0/v;->i(I)I

    move-result v18

    goto :goto_e5

    :cond_106
    invoke-virtual {v9, v6}, LZ0/v;->i(I)I

    move-result v3

    add-int/lit8 v3, v3, 0x9

    invoke-virtual {v9, v6}, LZ0/v;->i(I)I

    move-result v18

    goto :goto_e5

    :cond_111
    move/from16 v18, v2

    move/from16 v19, v5

    goto :goto_cc

    :cond_116
    move/from16 v18, v2

    move/from16 v19, v15

    goto :goto_cc

    :goto_11b
    if-eqz v19, :cond_146

    if-eqz v8, :cond_146

    if-eqz v17, :cond_123

    aget-byte v3, v17, v3

    :cond_123
    aget v2, p1, v3

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v3, v4

    int-to-float v2, v10

    add-int v0, v4, v19

    int-to-float v0, v0

    add-int/lit8 v5, v10, 0x1

    int-to-float v5, v5

    move/from16 v20, v2

    move-object/from16 v2, p6

    move/from16 v21, v4

    move/from16 v4, v20

    move/from16 v22, v5

    const/4 v14, 0x2

    move v5, v0

    move v0, v6

    move/from16 v6, v22

    move v0, v7

    move-object/from16 v7, p5

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_14a

    :cond_146
    move/from16 v21, v4

    move v14, v5

    move v0, v7

    :goto_14a
    add-int v4, v21, v19

    if-eqz v18, :cond_154

    invoke-virtual {v9}, LZ0/v;->c()V

    move v2, v4

    goto/16 :goto_13

    :cond_154
    move v7, v0

    move v5, v14

    move/from16 v2, v18

    const/4 v6, 0x4

    const/16 v14, 0x8

    goto/16 :goto_ae

    :pswitch_15d
    move v14, v5

    move v0, v7

    if-ne v1, v0, :cond_16a

    if-nez v11, :cond_166

    sget-object v3, Lc2/h;->i:[B

    goto :goto_167

    :cond_166
    move-object v3, v11

    :goto_167
    move-object/from16 v17, v3

    goto :goto_175

    :cond_16a
    if-ne v1, v14, :cond_173

    if-nez v13, :cond_171

    sget-object v3, Lc2/h;->h:[B

    goto :goto_167

    :cond_171
    move-object v3, v13

    goto :goto_167

    :cond_173
    const/16 v17, 0x0

    :goto_175
    move v7, v2

    move/from16 v2, v16

    :goto_178
    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v3

    if-eqz v3, :cond_187

    move/from16 v18, v2

    move/from16 v19, v15

    :goto_182
    const/4 v5, 0x4

    const/16 v6, 0x8

    goto/16 :goto_1f4

    :cond_187
    invoke-virtual {v9}, LZ0/v;->h()Z

    move-result v3

    if-eqz v3, :cond_19c

    invoke-virtual {v9, v0}, LZ0/v;->i(I)I

    move-result v3

    add-int/lit8 v5, v3, 0x3

    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v3

    move/from16 v18, v2

    move/from16 v19, v5

    goto :goto_182

    :cond_19c
    invoke-virtual {v9}, LZ0/v;->h()Z

    move-result v3

    if-eqz v3, :cond_1a9

    move/from16 v18, v2

    move/from16 v19, v15

    move/from16 v3, v16

    goto :goto_182

    :cond_1a9
    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v3

    if-eqz v3, :cond_1eb

    if-eq v3, v15, :cond_1e1

    if-eq v3, v14, :cond_1ce

    if-eq v3, v0, :cond_1bc

    move/from16 v18, v2

    move/from16 v3, v16

    move/from16 v19, v3

    goto :goto_182

    :cond_1bc
    const/16 v6, 0x8

    invoke-virtual {v9, v6}, LZ0/v;->i(I)I

    move-result v3

    add-int/lit8 v5, v3, 0x1d

    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v3

    move/from16 v18, v2

    move/from16 v19, v5

    const/4 v5, 0x4

    goto :goto_1f4

    :cond_1ce
    const/4 v5, 0x4

    const/16 v6, 0x8

    invoke-virtual {v9, v5}, LZ0/v;->i(I)I

    move-result v3

    add-int/lit8 v3, v3, 0xc

    invoke-virtual {v9, v14}, LZ0/v;->i(I)I

    move-result v4

    move/from16 v18, v2

    move/from16 v19, v3

    move v3, v4

    goto :goto_1f4

    :cond_1e1
    const/4 v5, 0x4

    const/16 v6, 0x8

    move/from16 v18, v2

    move/from16 v19, v14

    move/from16 v3, v16

    goto :goto_1f4

    :cond_1eb
    const/4 v5, 0x4

    const/16 v6, 0x8

    move/from16 v18, v15

    move/from16 v3, v16

    move/from16 v19, v3

    :goto_1f4
    if-eqz v19, :cond_21b

    if-eqz v8, :cond_21b

    if-eqz v17, :cond_1fc

    aget-byte v3, v17, v3

    :cond_1fc
    aget v2, p1, v3

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v3, v7

    int-to-float v4, v10

    add-int v2, v7, v19

    int-to-float v2, v2

    add-int/lit8 v0, v10, 0x1

    int-to-float v0, v0

    move/from16 v21, v2

    move-object/from16 v2, p6

    move/from16 v22, v5

    move/from16 v5, v21

    move/from16 v21, v6

    move v6, v0

    move v0, v7

    move-object/from16 v7, p5

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_220

    :cond_21b
    move/from16 v22, v5

    move/from16 v21, v6

    move v0, v7

    :goto_220
    add-int v7, v0, v19

    if-eqz v18, :cond_229

    invoke-virtual {v9}, LZ0/v;->c()V

    goto/16 :goto_98

    :cond_229
    move/from16 v2, v18

    const/4 v0, 0x3

    goto/16 :goto_178

    :cond_22e
    add-int/lit8 v10, v10, 0x2

    move/from16 v2, p3

    goto/16 :goto_13

    :cond_234
    return-void

    nop

    :pswitch_data_236
    .packed-switch 0x10
        :pswitch_15d
        :pswitch_9e
        :pswitch_41
    .end packed-switch

    :pswitch_data_240
    .packed-switch 0x20
        :pswitch_3c
        :pswitch_37
        :pswitch_30
    .end packed-switch
.end method

.method public static h(LZ0/v;I)Lc2/a;
    .registers 26

    move-object/from16 v0, p0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, LZ0/v;->i(I)I

    move-result v2

    invoke-virtual {v0, v1}, LZ0/v;->h0(I)V

    const/4 v3, 0x2

    add-int/lit8 v4, p1, -0x2

    const v5, -0x808081

    const/4 v6, -0x1

    const/4 v7, 0x0

    const/high16 v8, -0x1000000

    filled-new-array {v7, v6, v8, v5}, [I

    move-result-object v5

    invoke-static {}, Lc2/h;->c()[I

    move-result-object v6

    invoke-static {}, Lc2/h;->e()[I

    move-result-object v8

    :goto_21
    if-lez v4, :cond_cd

    invoke-virtual {v0, v1}, LZ0/v;->i(I)I

    move-result v9

    invoke-virtual {v0, v1}, LZ0/v;->i(I)I

    move-result v10

    and-int/lit16 v11, v10, 0x80

    if-eqz v11, :cond_31

    move-object v11, v5

    goto :goto_38

    :cond_31
    and-int/lit8 v11, v10, 0x40

    if-eqz v11, :cond_37

    move-object v11, v6

    goto :goto_38

    :cond_37
    move-object v11, v8

    :goto_38
    and-int/lit8 v10, v10, 0x1

    if-eqz v10, :cond_4f

    invoke-virtual {v0, v1}, LZ0/v;->i(I)I

    move-result v10

    invoke-virtual {v0, v1}, LZ0/v;->i(I)I

    move-result v12

    invoke-virtual {v0, v1}, LZ0/v;->i(I)I

    move-result v13

    invoke-virtual {v0, v1}, LZ0/v;->i(I)I

    move-result v14

    add-int/lit8 v4, v4, -0x6

    goto :goto_6f

    :cond_4f
    const/4 v10, 0x6

    invoke-virtual {v0, v10}, LZ0/v;->i(I)I

    move-result v12

    shl-int/2addr v12, v3

    const/4 v13, 0x4

    invoke-virtual {v0, v13}, LZ0/v;->i(I)I

    move-result v14

    shl-int/2addr v14, v13

    invoke-virtual {v0, v13}, LZ0/v;->i(I)I

    move-result v15

    shl-int/lit8 v13, v15, 0x4

    invoke-virtual {v0, v3}, LZ0/v;->i(I)I

    move-result v15

    shl-int/lit8 v10, v15, 0x6

    add-int/lit8 v4, v4, -0x4

    move/from16 v23, v14

    move v14, v10

    move v10, v12

    move/from16 v12, v23

    :goto_6f
    const/16 v15, 0xff

    if-nez v10, :cond_76

    move v12, v7

    move v13, v12

    move v14, v15

    :cond_76
    and-int/2addr v14, v15

    rsub-int v14, v14, 0xff

    int-to-byte v14, v14

    move/from16 p1, v4

    int-to-double v3, v10

    add-int/lit8 v12, v12, -0x80

    move/from16 v16, v2

    int-to-double v1, v12

    const-wide v17, 0x3ff66e978d4fdf3bL    # 1.402

    mul-double v17, v17, v1

    move-object v12, v11

    add-double v10, v17, v3

    double-to-int v10, v10

    add-int/lit8 v13, v13, -0x80

    move-object/from16 v17, v8

    int-to-double v7, v13

    const-wide v19, 0x3fd60663c74fb54aL    # 0.34414

    mul-double v19, v19, v7

    sub-double v19, v3, v19

    const-wide v21, 0x3fe6da3c21187e7cL    # 0.71414

    mul-double v1, v1, v21

    sub-double v1, v19, v1

    double-to-int v1, v1

    const-wide v19, 0x3ffc5a1cac083127L    # 1.772

    mul-double v7, v7, v19

    add-double/2addr v7, v3

    double-to-int v2, v7

    const/4 v3, 0x0

    invoke-static {v10, v3, v15}, LZ0/F;->j(III)I

    move-result v4

    invoke-static {v1, v3, v15}, LZ0/F;->j(III)I

    move-result v1

    invoke-static {v2, v3, v15}, LZ0/F;->j(III)I

    move-result v2

    invoke-static {v14, v4, v1, v2}, Lc2/h;->f(IIII)I

    move-result v1

    aput v1, v12, v9

    move/from16 v4, p1

    move v7, v3

    move/from16 v2, v16

    move-object/from16 v8, v17

    const/16 v1, 0x8

    const/4 v3, 0x2

    goto/16 :goto_21

    :cond_cd
    move/from16 v16, v2

    move-object/from16 v17, v8

    new-instance v0, Lc2/a;

    move/from16 v1, v16

    move-object/from16 v2, v17

    invoke-direct {v0, v1, v5, v6, v2}, Lc2/a;-><init>(I[I[I[I)V

    return-object v0
.end method

.method public static i(LZ0/v;)Lc2/c;
    .registers 7

    const/16 v0, 0x10

    invoke-virtual {p0, v0}, LZ0/v;->i(I)I

    move-result v1

    const/4 v2, 0x4

    invoke-virtual {p0, v2}, LZ0/v;->h0(I)V

    const/4 v2, 0x2

    invoke-virtual {p0, v2}, LZ0/v;->i(I)I

    move-result v2

    invoke-virtual {p0}, LZ0/v;->h()Z

    move-result v3

    const/4 v4, 0x1

    invoke-virtual {p0, v4}, LZ0/v;->h0(I)V

    sget-object v5, LZ0/F;->f:[B

    if-ne v2, v4, :cond_26

    const/16 v2, 0x8

    invoke-virtual {p0, v2}, LZ0/v;->i(I)I

    move-result v2

    mul-int/2addr v2, v0

    invoke-virtual {p0, v2}, LZ0/v;->h0(I)V

    goto :goto_3f

    :cond_26
    if-nez v2, :cond_3f

    invoke-virtual {p0, v0}, LZ0/v;->i(I)I

    move-result v2

    invoke-virtual {p0, v0}, LZ0/v;->i(I)I

    move-result v0

    if-lez v2, :cond_37

    new-array v5, v2, [B

    invoke-virtual {p0, v2, v5}, LZ0/v;->o(I[B)V

    :cond_37
    if-lez v0, :cond_3f

    new-array v2, v0, [B

    invoke-virtual {p0, v0, v2}, LZ0/v;->o(I[B)V

    goto :goto_40

    :cond_3f
    :goto_3f
    move-object v2, v5

    :goto_40
    new-instance p0, Lc2/c;

    invoke-direct {p0, v1, v3, v5, v2}, Lc2/c;-><init>(IZ[B[B)V

    return-object p0
.end method


# virtual methods
.method public final b()V
    .registers 3

    iget-object v0, p0, Lc2/h;->f:Lc2/g;

    iget-object v1, v0, Lc2/g;->c:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    iget-object v1, v0, Lc2/g;->d:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    iget-object v1, v0, Lc2/g;->e:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    iget-object v1, v0, Lc2/g;->f:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    iget-object v1, v0, Lc2/g;->g:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    const/4 v1, 0x0

    iput-object v1, v0, Lc2/g;->h:Lc2/b;

    iput-object v1, v0, Lc2/g;->i:LF4/b;

    return-void
.end method

.method public final d([BIILa2/k;LZ0/e;)V
    .registers 49

    move-object/from16 v0, p0

    move/from16 v1, p2

    const/16 v2, 0x8

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v5, LZ0/v;

    add-int v6, v1, p3

    move-object/from16 v7, p1

    invoke-direct {v5, v7, v6}, LZ0/v;-><init>([BI)V

    invoke-virtual {v5, v1}, LZ0/v;->f0(I)V

    :goto_14
    invoke-virtual {v5}, LZ0/v;->b()I

    move-result v1

    const/16 v6, 0x30

    const/4 v7, 0x3

    iget-object v9, v0, Lc2/h;->f:Lc2/g;

    if-lt v1, v6, :cond_1f7

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    move-result v1

    const/16 v6, 0xf

    if-ne v1, v6, :cond_1f7

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    move-result v1

    const/16 v6, 0x10

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v10

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v11

    invoke-virtual {v5}, LZ0/v;->d()I

    move-result v12

    add-int/2addr v12, v11

    mul-int/lit8 v13, v11, 0x8

    invoke-virtual {v5}, LZ0/v;->b()I

    move-result v14

    if-le v13, v14, :cond_52

    const-string v1, "DvbParser"

    const-string v6, "Data field length exceeds limit"

    invoke-static {v1, v6}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5}, LZ0/v;->b()I

    move-result v1

    invoke-virtual {v5, v1}, LZ0/v;->h0(I)V

    goto/16 :goto_1f3

    :cond_52
    const/4 v13, 0x4

    packed-switch v1, :pswitch_data_408

    goto/16 :goto_1eb

    :pswitch_58
    iget v1, v9, Lc2/g;->a:I

    if-ne v10, v1, :cond_1eb

    invoke-virtual {v5, v13}, LZ0/v;->h0(I)V

    invoke-virtual {v5}, LZ0/v;->h()Z

    move-result v1

    invoke-virtual {v5, v7}, LZ0/v;->h0(I)V

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v14

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v15

    if-eqz v1, :cond_89

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v8

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v1

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v7

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v6

    move/from16 v17, v1

    move/from16 v19, v6

    move/from16 v18, v7

    move/from16 v16, v8

    goto :goto_91

    :cond_89
    move/from16 v17, v14

    move/from16 v19, v15

    const/16 v16, 0x0

    const/16 v18, 0x0

    :goto_91
    new-instance v1, Lc2/b;

    move-object v13, v1

    invoke-direct/range {v13 .. v19}, Lc2/b;-><init>(IIIIII)V

    iput-object v1, v9, Lc2/g;->h:Lc2/b;

    goto/16 :goto_1eb

    :pswitch_9b
    iget v1, v9, Lc2/g;->a:I

    if-ne v10, v1, :cond_ac

    invoke-static {v5}, Lc2/h;->i(LZ0/v;)Lc2/c;

    move-result-object v1

    iget-object v6, v9, Lc2/g;->e:Landroid/util/SparseArray;

    iget v7, v1, Lc2/c;->a:I

    invoke-virtual {v6, v7, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto/16 :goto_1eb

    :cond_ac
    iget v1, v9, Lc2/g;->b:I

    if-ne v10, v1, :cond_1eb

    invoke-static {v5}, Lc2/h;->i(LZ0/v;)Lc2/c;

    move-result-object v1

    iget-object v6, v9, Lc2/g;->g:Landroid/util/SparseArray;

    iget v7, v1, Lc2/c;->a:I

    invoke-virtual {v6, v7, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_bd
    iget v1, v9, Lc2/g;->a:I

    if-ne v10, v1, :cond_ce

    invoke-static {v5, v11}, Lc2/h;->h(LZ0/v;I)Lc2/a;

    move-result-object v1

    iget-object v6, v9, Lc2/g;->d:Landroid/util/SparseArray;

    iget v7, v1, Lc2/a;->a:I

    invoke-virtual {v6, v7, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto/16 :goto_1eb

    :cond_ce
    iget v1, v9, Lc2/g;->b:I

    if-ne v10, v1, :cond_1eb

    invoke-static {v5, v11}, Lc2/h;->h(LZ0/v;I)Lc2/a;

    move-result-object v1

    iget-object v6, v9, Lc2/g;->f:Landroid/util/SparseArray;

    iget v7, v1, Lc2/a;->a:I

    invoke-virtual {v6, v7, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_df
    iget-object v1, v9, Lc2/g;->i:LF4/b;

    iget v14, v9, Lc2/g;->a:I

    if-ne v10, v14, :cond_1eb

    if-eqz v1, :cond_1eb

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    move-result v10

    invoke-virtual {v5, v13}, LZ0/v;->h0(I)V

    invoke-virtual {v5}, LZ0/v;->h()Z

    move-result v17

    invoke-virtual {v5, v7}, LZ0/v;->h0(I)V

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v18

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v19

    invoke-virtual {v5, v7}, LZ0/v;->i(I)I

    invoke-virtual {v5, v7}, LZ0/v;->i(I)I

    move-result v20

    invoke-virtual {v5, v3}, LZ0/v;->h0(I)V

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    move-result v21

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    move-result v22

    invoke-virtual {v5, v13}, LZ0/v;->i(I)I

    move-result v23

    invoke-virtual {v5, v3}, LZ0/v;->i(I)I

    move-result v24

    invoke-virtual {v5, v3}, LZ0/v;->h0(I)V

    add-int/lit8 v11, v11, -0xa

    new-instance v7, Landroid/util/SparseArray;

    invoke-direct {v7}, Landroid/util/SparseArray;-><init>()V

    :goto_121
    if-lez v11, :cond_158

    invoke-virtual {v5, v6}, LZ0/v;->i(I)I

    move-result v14

    invoke-virtual {v5, v3}, LZ0/v;->i(I)I

    move-result v15

    invoke-virtual {v5, v3}, LZ0/v;->i(I)I

    const/16 v8, 0xc

    invoke-virtual {v5, v8}, LZ0/v;->i(I)I

    move-result v6

    invoke-virtual {v5, v13}, LZ0/v;->h0(I)V

    invoke-virtual {v5, v8}, LZ0/v;->i(I)I

    move-result v8

    add-int/lit8 v16, v11, -0x6

    if-eq v15, v4, :cond_145

    if-ne v15, v3, :cond_142

    goto :goto_145

    :cond_142
    move/from16 v11, v16

    goto :goto_14d

    :cond_145
    :goto_145
    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    add-int/lit8 v11, v11, -0x8

    :goto_14d
    new-instance v15, Lc2/f;

    invoke-direct {v15, v6, v8}, Lc2/f;-><init>(II)V

    invoke-virtual {v7, v14, v15}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/16 v6, 0x10

    goto :goto_121

    :cond_158
    new-instance v6, Lc2/e;

    move-object v15, v6

    move/from16 v16, v10

    move-object/from16 v25, v7

    invoke-direct/range {v15 .. v25}, Lc2/e;-><init>(IZIIIIIIILandroid/util/SparseArray;)V

    iget-object v7, v9, Lc2/g;->c:Landroid/util/SparseArray;

    iget v1, v1, LF4/b;->b:I

    if-nez v1, :cond_18a

    invoke-virtual {v7, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc2/e;

    if-eqz v1, :cond_18a

    const/4 v8, 0x0

    :goto_171
    iget-object v9, v1, Lc2/e;->j:Landroid/util/SparseArray;

    invoke-virtual {v9}, Landroid/util/SparseArray;->size()I

    move-result v10

    if-ge v8, v10, :cond_18a

    invoke-virtual {v9, v8}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v10

    invoke-virtual {v9, v8}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc2/f;

    iget-object v11, v6, Lc2/e;->j:Landroid/util/SparseArray;

    invoke-virtual {v11, v10, v9}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    add-int/2addr v8, v4

    goto :goto_171

    :cond_18a
    iget v1, v6, Lc2/e;->a:I

    invoke-virtual {v7, v1, v6}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto :goto_1eb

    :pswitch_190
    iget v1, v9, Lc2/g;->a:I

    if-ne v10, v1, :cond_1eb

    iget-object v1, v9, Lc2/g;->i:LF4/b;

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    invoke-virtual {v5, v13}, LZ0/v;->i(I)I

    move-result v6

    invoke-virtual {v5, v3}, LZ0/v;->i(I)I

    move-result v7

    invoke-virtual {v5, v3}, LZ0/v;->h0(I)V

    sub-int/2addr v11, v3

    new-instance v8, Landroid/util/SparseArray;

    invoke-direct {v8}, Landroid/util/SparseArray;-><init>()V

    :goto_1aa
    if-lez v11, :cond_1ca

    invoke-virtual {v5, v2}, LZ0/v;->i(I)I

    move-result v10

    invoke-virtual {v5, v2}, LZ0/v;->h0(I)V

    const/16 v13, 0x10

    invoke-virtual {v5, v13}, LZ0/v;->i(I)I

    move-result v14

    invoke-virtual {v5, v13}, LZ0/v;->i(I)I

    move-result v15

    add-int/lit8 v11, v11, -0x6

    new-instance v2, Lc2/d;

    invoke-direct {v2, v14, v15}, Lc2/d;-><init>(II)V

    invoke-virtual {v8, v10, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/16 v2, 0x8

    goto :goto_1aa

    :cond_1ca
    new-instance v2, LF4/b;

    invoke-direct {v2, v6, v7, v8}, LF4/b;-><init>(IILandroid/util/SparseArray;)V

    if-eqz v7, :cond_1e3

    iput-object v2, v9, Lc2/g;->i:LF4/b;

    iget-object v1, v9, Lc2/g;->c:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    iget-object v1, v9, Lc2/g;->d:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    iget-object v1, v9, Lc2/g;->e:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->clear()V

    goto :goto_1eb

    :cond_1e3
    if-eqz v1, :cond_1eb

    iget v1, v1, LF4/b;->a:I

    if-eq v1, v6, :cond_1eb

    iput-object v2, v9, Lc2/g;->i:LF4/b;

    :cond_1eb
    :goto_1eb
    invoke-virtual {v5}, LZ0/v;->d()I

    move-result v1

    sub-int/2addr v12, v1

    invoke-virtual {v5, v12}, LZ0/v;->i0(I)V

    :goto_1f3
    const/16 v2, 0x8

    goto/16 :goto_14

    :cond_1f7
    iget-object v1, v9, Lc2/g;->i:LF4/b;

    if-nez v1, :cond_213

    new-instance v1, La2/a;

    sget-object v2, Lj8/T;->b:Lj8/Q;

    sget-object v11, Lj8/q0;->e:Lj8/q0;

    const-wide v12, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v14, -0x7fffffffffffffffL    # -4.9E-324

    move-object v10, v1

    invoke-direct/range {v10 .. v15}, La2/a;-><init>(Ljava/util/List;JJ)V

    :goto_20f
    move-object/from16 v2, p5

    goto/16 :goto_404

    :cond_213
    iget-object v2, v9, Lc2/g;->h:Lc2/b;

    if-eqz v2, :cond_218

    goto :goto_21a

    :cond_218
    iget-object v2, v0, Lc2/h;->d:Lc2/b;

    :goto_21a
    iget-object v5, v0, Lc2/h;->g:Landroid/graphics/Bitmap;

    iget-object v6, v0, Lc2/h;->c:Landroid/graphics/Canvas;

    if-eqz v5, :cond_234

    iget v8, v2, Lc2/b;->a:I

    add-int/2addr v8, v4

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v5

    if-ne v8, v5, :cond_234

    iget v5, v2, Lc2/b;->b:I

    add-int/2addr v5, v4

    iget-object v8, v0, Lc2/h;->g:Landroid/graphics/Bitmap;

    invoke-virtual {v8}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v8

    if-eq v5, v8, :cond_245

    :cond_234
    iget v5, v2, Lc2/b;->a:I

    add-int/2addr v5, v4

    iget v8, v2, Lc2/b;->b:I

    add-int/2addr v8, v4

    sget-object v10, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v5, v8, v10}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v5

    iput-object v5, v0, Lc2/h;->g:Landroid/graphics/Bitmap;

    invoke-virtual {v6, v5}, Landroid/graphics/Canvas;->setBitmap(Landroid/graphics/Bitmap;)V

    :cond_245
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x0

    :goto_24b
    iget-object v10, v1, LF4/b;->c:Ljava/lang/Cloneable;

    check-cast v10, Landroid/util/SparseArray;

    invoke-virtual {v10}, Landroid/util/SparseArray;->size()I

    move-result v11

    if-ge v8, v11, :cond_3f0

    invoke-virtual {v6}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {v10, v8}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lc2/d;

    invoke-virtual {v10, v8}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v10

    iget-object v12, v9, Lc2/g;->c:Landroid/util/SparseArray;

    invoke-virtual {v12, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v10

    move-object v15, v10

    check-cast v15, Lc2/e;

    iget v10, v11, Lc2/d;->a:I

    iget v12, v2, Lc2/b;->c:I

    add-int v14, v10, v12

    iget v10, v11, Lc2/d;->b:I

    iget v11, v2, Lc2/b;->e:I

    add-int v13, v10, v11

    iget v10, v15, Lc2/e;->c:I

    add-int/2addr v10, v14

    iget v11, v2, Lc2/b;->d:I

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v10

    iget v12, v15, Lc2/e;->d:I

    add-int v11, v13, v12

    iget v4, v2, Lc2/b;->f:I

    invoke-static {v11, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual {v6, v14, v13, v10, v4}, Landroid/graphics/Canvas;->clipRect(IIII)Z

    iget-object v4, v9, Lc2/g;->d:Landroid/util/SparseArray;

    iget v10, v15, Lc2/e;->f:I

    invoke-virtual {v4, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc2/a;

    if-nez v4, :cond_2a5

    iget-object v4, v9, Lc2/g;->f:Landroid/util/SparseArray;

    invoke-virtual {v4, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc2/a;

    if-nez v4, :cond_2a5

    iget-object v4, v0, Lc2/h;->e:Lc2/a;

    :cond_2a5
    const/4 v10, 0x0

    :goto_2a6
    iget-object v3, v15, Lc2/e;->j:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v7

    if-ge v10, v7, :cond_348

    invoke-virtual {v3, v10}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v7

    invoke-virtual {v3, v10}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc2/f;

    move-object/from16 v18, v1

    iget-object v1, v9, Lc2/g;->e:Landroid/util/SparseArray;

    invoke-virtual {v1, v7}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc2/c;

    if-nez v1, :cond_2cc

    iget-object v1, v9, Lc2/g;->g:Landroid/util/SparseArray;

    invoke-virtual {v1, v7}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc2/c;

    :cond_2cc
    if-eqz v1, :cond_31e

    iget-boolean v7, v1, Lc2/c;->b:Z

    if-eqz v7, :cond_2d6

    const/4 v7, 0x0

    :goto_2d3
    move-object/from16 v19, v9

    goto :goto_2d9

    :cond_2d6
    iget-object v7, v0, Lc2/h;->a:Landroid/graphics/Paint;

    goto :goto_2d3

    :goto_2d9
    iget v9, v3, Lc2/f;->a:I

    add-int/2addr v9, v14

    iget v3, v3, Lc2/f;->b:I

    add-int/2addr v3, v13

    move/from16 v20, v8

    iget v8, v15, Lc2/e;->e:I

    move/from16 v16, v10

    const/4 v10, 0x3

    if-ne v8, v10, :cond_2ed

    iget-object v10, v4, Lc2/a;->d:[I

    :goto_2ea
    move-object/from16 v21, v10

    goto :goto_2f6

    :cond_2ed
    const/4 v10, 0x2

    if-ne v8, v10, :cond_2f3

    iget-object v10, v4, Lc2/a;->c:[I

    goto :goto_2ea

    :cond_2f3
    iget-object v10, v4, Lc2/a;->b:[I

    goto :goto_2ea

    :goto_2f6
    iget-object v10, v1, Lc2/c;->c:[B

    move/from16 v22, v16

    move-object/from16 p3, v5

    move v5, v11

    move-object/from16 v11, v21

    move-object/from16 v23, v2

    move v2, v12

    move v12, v8

    move/from16 v24, v2

    move v2, v13

    move v13, v9

    move/from16 v25, v5

    move v5, v14

    move v14, v3

    move/from16 v26, v2

    move-object v2, v15

    move-object v15, v7

    move-object/from16 v16, v6

    invoke-static/range {v10 .. v16}, Lc2/h;->g([B[IIIILandroid/graphics/Paint;Landroid/graphics/Canvas;)V

    const/4 v10, 0x1

    add-int/lit8 v14, v3, 0x1

    iget-object v10, v1, Lc2/c;->d:[B

    invoke-static/range {v10 .. v16}, Lc2/h;->g([B[IIIILandroid/graphics/Paint;Landroid/graphics/Canvas;)V

    :goto_31c
    const/4 v1, 0x1

    goto :goto_331

    :cond_31e
    move-object/from16 v23, v2

    move-object/from16 p3, v5

    move/from16 v20, v8

    move-object/from16 v19, v9

    move/from16 v22, v10

    move/from16 v25, v11

    move/from16 v24, v12

    move/from16 v26, v13

    move v5, v14

    move-object v2, v15

    goto :goto_31c

    :goto_331
    add-int/lit8 v10, v22, 0x1

    move-object v15, v2

    move v14, v5

    move-object/from16 v1, v18

    move-object/from16 v9, v19

    move/from16 v8, v20

    move-object/from16 v2, v23

    move/from16 v12, v24

    move/from16 v11, v25

    move/from16 v13, v26

    const/4 v7, 0x3

    move-object/from16 v5, p3

    goto/16 :goto_2a6

    :cond_348
    move-object/from16 v18, v1

    move-object/from16 v23, v2

    move-object/from16 p3, v5

    move/from16 v20, v8

    move-object/from16 v19, v9

    move/from16 v25, v11

    move/from16 v24, v12

    move/from16 v26, v13

    move v5, v14

    move-object v2, v15

    iget-boolean v1, v2, Lc2/e;->b:Z

    iget v3, v2, Lc2/e;->c:I

    if-eqz v1, :cond_391

    iget v1, v2, Lc2/e;->e:I

    const/4 v7, 0x3

    if-ne v1, v7, :cond_36d

    iget-object v1, v4, Lc2/a;->d:[I

    iget v2, v2, Lc2/e;->g:I

    aget v1, v1, v2

    const/4 v8, 0x2

    goto :goto_37d

    :cond_36d
    const/4 v8, 0x2

    if-ne v1, v8, :cond_377

    iget-object v1, v4, Lc2/a;->c:[I

    iget v2, v2, Lc2/e;->h:I

    aget v1, v1, v2

    goto :goto_37d

    :cond_377
    iget-object v1, v4, Lc2/a;->b:[I

    iget v2, v2, Lc2/e;->i:I

    aget v1, v1, v2

    :goto_37d
    iget-object v15, v0, Lc2/h;->b:Landroid/graphics/Paint;

    invoke-virtual {v15, v1}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v11, v5

    move/from16 v1, v26

    int-to-float v12, v1

    add-int v14, v5, v3

    int-to-float v13, v14

    move/from16 v2, v25

    int-to-float v14, v2

    move-object v10, v6

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_395

    :cond_391
    move/from16 v1, v26

    const/4 v7, 0x3

    const/4 v8, 0x2

    :goto_395
    iget-object v2, v0, Lc2/h;->g:Landroid/graphics/Bitmap;

    move/from16 v4, v24

    invoke-static {v2, v5, v1, v3, v4}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;

    move-result-object v28

    int-to-float v2, v5

    move-object/from16 v5, v23

    iget v9, v5, Lc2/b;->a:I

    int-to-float v9, v9

    div-float v32, v2, v9

    int-to-float v1, v1

    iget v2, v5, Lc2/b;->b:I

    int-to-float v2, v2

    div-float v29, v1, v2

    int-to-float v1, v3

    div-float v36, v1, v9

    int-to-float v1, v4

    div-float v37, v1, v2

    new-instance v1, LY0/b;

    move-object/from16 v24, v1

    const v35, -0x800001

    const/16 v38, 0x0

    const/16 v26, 0x0

    move-object/from16 v25, v26

    move-object/from16 v27, v26

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v33, 0x0

    const/high16 v40, -0x80000000

    move/from16 v34, v40

    const/high16 v39, -0x1000000

    const/16 v41, 0x0

    invoke-direct/range {v24 .. v41}, LY0/b;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFZIIF)V

    move-object/from16 v2, p3

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    const/4 v3, 0x0

    invoke-virtual {v6, v3, v1}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v6}, Landroid/graphics/Canvas;->restore()V

    const/4 v1, 0x1

    add-int/lit8 v4, v20, 0x1

    move v3, v8

    move-object/from16 v9, v19

    move v8, v4

    move v4, v1

    move-object/from16 v1, v18

    move-object/from16 v42, v5

    move-object v5, v2

    move-object/from16 v2, v42

    goto/16 :goto_24b

    :cond_3f0
    move-object v2, v5

    new-instance v1, La2/a;

    const-wide v12, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v14, -0x7fffffffffffffffL    # -4.9E-324

    move-object v10, v1

    move-object v11, v2

    invoke-direct/range {v10 .. v15}, La2/a;-><init>(Ljava/util/List;JJ)V

    goto/16 :goto_20f

    :goto_404
    invoke-interface {v2, v1}, LZ0/e;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_data_408
    .packed-switch 0x10
        :pswitch_190
        :pswitch_df
        :pswitch_bd
        :pswitch_9b
        :pswitch_58
    .end packed-switch
.end method

.method public final w()I
    .registers 2

    const/4 v0, 0x2

    return v0
.end method
