.class public final LB0/e;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/e;->c:Ljava/util/List;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 5

    new-instance v0, LB0/e;

    iget-object v1, p0, LB0/e;->c:Ljava/util/List;

    invoke-direct {v0, v1, p2}, LB0/e;-><init>(Ljava/util/List;Lyc/d;)V

    iput-object p1, v0, LB0/e;->b:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LB0/m;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/e;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/e;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/e;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_27

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/e;->b:Ljava/lang/Object;

    check-cast p1, LB0/m;

    iput v2, p0, LB0/e;->a:I

    iget-object v1, p0, LB0/e;->c:Ljava/util/List;

    invoke-static {v1, p1, p0}, Lk7/B;->d(Ljava/util/List;LB0/m;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_27

    return-object v0

    :cond_27
    :goto_27
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
