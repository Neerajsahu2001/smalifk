.class public final LB0/q;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/d;


# instance fields
.field public final synthetic a:Lbe/e0;


# direct methods
.method public constructor <init>(Lbe/e0;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/q;->a:Lbe/e0;

    const/4 p1, 0x3

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lee/i;

    check-cast p2, Ljava/lang/Throwable;

    check-cast p3, Lyc/d;

    new-instance p1, LB0/q;

    iget-object p2, p0, LB0/q;->a:Lbe/e0;

    invoke-direct {p1, p2, p3}, LB0/q;-><init>(Lbe/e0;Lyc/d;)V

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/q;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p2
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    sget-object v0, Lzc/a;->a:Lzc/a;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    const/4 p1, 0x0

    iget-object v0, p0, LB0/q;->a:Lbe/e0;

    invoke-interface {v0, p1}, Lbe/e0;->f(Ljava/util/concurrent/CancellationException;)V

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
