.class public final LB0/f0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lje/c;

.field public final b:Lcom/android/installreferrer/api/d;

.field public final c:LC/y0;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lje/d;->a()Lje/c;

    move-result-object p1

    iput-object p1, p0, LB0/f0;->a:Lje/c;

    new-instance p1, Lcom/android/installreferrer/api/d;

    const/4 v0, 0x2

    invoke-direct {p1, v0}, Lcom/android/installreferrer/api/d;-><init>(I)V

    iput-object p1, p0, LB0/f0;->b:Lcom/android/installreferrer/api/d;

    new-instance p1, LB0/e0;

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p1, v0, v1}, LAc/j;-><init>(ILyc/d;)V

    new-instance v0, LC/y0;

    const/16 v1, 0xf

    invoke-direct {v0, v1, p1}, LC/y0;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, LB0/f0;->c:LC/y0;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Integer;
    .registers 3

    iget-object v0, p0, LB0/f0;->b:Lcom/android/installreferrer/api/d;

    iget-object v0, v0, Lcom/android/installreferrer/api/d;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    new-instance v1, Ljava/lang/Integer;

    invoke-direct {v1, v0}, Ljava/lang/Integer;-><init>(I)V

    return-object v1
.end method

.method public final b(LHc/b;Lyc/d;)Ljava/lang/Object;
    .registers 10

    instance-of v0, p2, LB0/c0;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, LB0/c0;

    iget v1, v0, LB0/c0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LB0/c0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, LB0/c0;

    invoke-direct {v0, p0, p2}, LB0/c0;-><init>(LB0/f0;Lyc/d;)V

    :goto_18
    iget-object p2, v0, LB0/c0;->c:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, LB0/c0;->e:I

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_45

    if-eq v2, v4, :cond_39

    if-ne v2, v3, :cond_31

    iget-object p1, v0, LB0/c0;->a:Ljava/lang/Object;

    check-cast p1, Lje/a;

    :try_start_2b
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_2e
    .catchall {:try_start_2b .. :try_end_2e} :catchall_2f

    goto :goto_67

    :catchall_2f
    move-exception p2

    goto :goto_71

    :cond_31
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_39
    iget-object p1, v0, LB0/c0;->b:Lje/c;

    iget-object v2, v0, LB0/c0;->a:Ljava/lang/Object;

    check-cast v2, LHc/b;

    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object p2, p1

    move-object p1, v2

    goto :goto_57

    :cond_45
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V

    iput-object p1, v0, LB0/c0;->a:Ljava/lang/Object;

    iget-object p2, p0, LB0/f0;->a:Lje/c;

    iput-object p2, v0, LB0/c0;->b:Lje/c;

    iput v4, v0, LB0/c0;->e:I

    invoke-virtual {p2, v0}, Lje/c;->d(Lyc/d;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v1, :cond_57

    return-object v1

    :cond_57
    :goto_57
    :try_start_57
    iput-object p2, v0, LB0/c0;->a:Ljava/lang/Object;

    iput-object v5, v0, LB0/c0;->b:Lje/c;

    iput v3, v0, LB0/c0;->e:I

    invoke-interface {p1, v0}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_61
    .catchall {:try_start_57 .. :try_end_61} :catchall_6d

    if-ne p1, v1, :cond_64

    return-object v1

    :cond_64
    move-object v6, p2

    move-object p2, p1

    move-object p1, v6

    :goto_67
    check-cast p1, Lje/c;

    invoke-virtual {p1, v5}, Lje/c;->f(Ljava/lang/Object;)V

    return-object p2

    :catchall_6d
    move-exception p1

    move-object v6, p2

    move-object p2, p1

    move-object p1, v6

    :goto_71
    check-cast p1, Lje/c;

    invoke-virtual {p1, v5}, Lje/c;->f(Ljava/lang/Object;)V

    throw p2
.end method

.method public final c(LHc/c;Lyc/d;)Ljava/lang/Object;
    .registers 9

    instance-of v0, p2, LB0/d0;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, LB0/d0;

    iget v1, v0, LB0/d0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LB0/d0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, LB0/d0;

    invoke-direct {v0, p0, p2}, LB0/d0;-><init>(LB0/f0;Lyc/d;)V

    :goto_18
    iget-object p2, v0, LB0/d0;->c:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, LB0/d0;->e:I

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_36

    if-ne v2, v3, :cond_2e

    iget-boolean p1, v0, LB0/d0;->b:Z

    iget-object v0, v0, LB0/d0;->a:Lje/c;

    :try_start_28
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_2b
    .catchall {:try_start_28 .. :try_end_2b} :catchall_2c

    goto :goto_53

    :catchall_2c
    move-exception p2

    goto :goto_5d

    :cond_2e
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_36
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p2, p0, LB0/f0;->a:Lje/c;

    invoke-virtual {p2, v4}, Lje/c;->e(Ljava/lang/Object;)Z

    move-result v2

    :try_start_3f
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    iput-object p2, v0, LB0/d0;->a:Lje/c;

    iput-boolean v2, v0, LB0/d0;->b:Z

    iput v3, v0, LB0/d0;->e:I

    invoke-interface {p1, v5, v0}, LHc/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_4d
    .catchall {:try_start_3f .. :try_end_4d} :catchall_59

    if-ne p1, v1, :cond_50

    return-object v1

    :cond_50
    move-object v0, p2

    move-object p2, p1

    move p1, v2

    :goto_53
    if-eqz p1, :cond_58

    invoke-virtual {v0, v4}, Lje/c;->f(Ljava/lang/Object;)V

    :cond_58
    return-object p2

    :catchall_59
    move-exception p1

    move-object v0, p2

    move-object p2, p1

    move p1, v2

    :goto_5d
    if-eqz p1, :cond_62

    invoke-virtual {v0, v4}, Lje/c;->f(Ljava/lang/Object;)V

    :cond_62
    throw p2
.end method
