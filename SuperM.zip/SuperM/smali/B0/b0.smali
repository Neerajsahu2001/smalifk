.class public final LB0/b0;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public a:LHc/c;

.field public b:I

.field public final synthetic c:LAa/s;


# direct methods
.method public constructor <init>(LAa/s;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/b0;->c:LAa/s;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 4

    new-instance p1, LB0/b0;

    iget-object v0, p0, LB0/b0;->c:LAa/s;

    invoke-direct {p1, v0, p2}, LB0/b0;-><init>(LAa/s;Lyc/d;)V

    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lbe/A;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/b0;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/b0;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/b0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/b0;->b:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v4, p0, LB0/b0;->c:LAa/s;

    if-eqz v1, :cond_20

    if-eq v1, v3, :cond_1a

    if-ne v1, v2, :cond_12

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_5c

    :cond_12
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1a
    iget-object v1, p0, LB0/b0;->a:LHc/c;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_50

    :cond_20
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, v4, LAa/s;->d:Ljava/lang/Object;

    check-cast p1, Lcom/android/installreferrer/api/d;

    iget-object p1, p1, Lcom/android/installreferrer/api/d;->b:Ljava/lang/Object;

    check-cast p1, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p1

    if-lez p1, :cond_6d

    :cond_31
    iget-object p1, v4, LAa/s;->a:Ljava/lang/Object;

    check-cast p1, Lbe/A;

    invoke-interface {p1}, Lbe/A;->K()Lyc/j;

    move-result-object p1

    invoke-static {p1}, Lbe/i;->d(Lyc/j;)V

    iget-object p1, v4, LAa/s;->b:Ljava/lang/Object;

    move-object v1, p1

    check-cast v1, LHc/c;

    iput-object v1, p0, LB0/b0;->a:LHc/c;

    iput v3, p0, LB0/b0;->b:I

    iget-object p1, v4, LAa/s;->c:Ljava/lang/Object;

    check-cast p1, Lde/c;

    invoke-virtual {p1, p0}, Lde/c;->z(Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_50

    return-object v0

    :cond_50
    :goto_50
    const/4 v5, 0x0

    iput-object v5, p0, LB0/b0;->a:LHc/c;

    iput v2, p0, LB0/b0;->b:I

    invoke-interface {v1, p1, p0}, LHc/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_5c

    return-object v0

    :cond_5c
    :goto_5c
    iget-object p1, v4, LAa/s;->d:Ljava/lang/Object;

    check-cast p1, Lcom/android/installreferrer/api/d;

    iget-object p1, p1, Lcom/android/installreferrer/api/d;->b:Ljava/lang/Object;

    check-cast p1, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    if-nez p1, :cond_31

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :cond_6d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Check failed."

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
