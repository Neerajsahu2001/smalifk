.class public final LB0/k0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lyc/h;


# static fields
.field public static final a:LB0/k0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LB0/k0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LB0/k0;->a:LB0/k0;

    return-void
.end method
