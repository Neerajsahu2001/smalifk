.class public final LB0/v;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/b;


# instance fields
.field public a:I

.field public final synthetic b:LHc/b;


# direct methods
.method public constructor <init>(LB0/I;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/v;->b:LHc/b;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Lyc/d;)Lyc/d;
    .registers 4

    new-instance v0, LB0/v;

    iget-object v1, p0, LB0/v;->b:LHc/b;

    check-cast v1, LB0/I;

    invoke-direct {v0, v1, p1}, LB0/v;-><init>(LB0/I;Lyc/d;)V

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lyc/d;

    invoke-virtual {p0, p1}, LB0/v;->create(Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/v;

    sget-object v0, Luc/z;->a:Luc/z;

    invoke-virtual {p1, v0}, LB0/v;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/v;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_23

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iput v2, p0, LB0/v;->a:I

    iget-object p1, p0, LB0/v;->b:LHc/b;

    invoke-interface {p1, p0}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_23

    return-object v0

    :cond_23
    :goto_23
    return-object p1
.end method
