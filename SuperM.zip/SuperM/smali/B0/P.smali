.class public final LB0/p;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public final synthetic a:Lbe/e0;


# direct methods
.method public constructor <init>(Lbe/v0;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/p;->a:Lbe/e0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 4

    new-instance p1, LB0/p;

    iget-object v0, p0, LB0/p;->a:Lbe/e0;

    check-cast v0, Lbe/v0;

    invoke-direct {p1, v0, p2}, LB0/p;-><init>(Lbe/v0;Lyc/d;)V

    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lee/i;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/p;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/p;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/p;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p2
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    sget-object v0, Lzc/a;->a:Lzc/a;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/p;->a:Lbe/e0;

    check-cast p1, Lbe/n0;

    :goto_9
    invoke-virtual {p1}, Lbe/n0;->H()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Lbe/n0;->X(Ljava/lang/Object;)I

    move-result v0

    if-eqz v0, :cond_17

    const/4 v1, 0x1

    if-eq v0, v1, :cond_17

    goto :goto_9

    :cond_17
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
