.class public final LB0/h;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public a:Ljava/util/Iterator;

.field public b:LE0/d;

.field public c:Ljava/lang/Object;

.field public d:I

.field public synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/util/List;

.field public final synthetic g:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/util/ArrayList;Lyc/d;)V
    .registers 4

    iput-object p1, p0, LB0/h;->f:Ljava/util/List;

    iput-object p2, p0, LB0/h;->g:Ljava/util/List;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 6

    new-instance v0, LB0/h;

    iget-object v1, p0, LB0/h;->g:Ljava/util/List;

    check-cast v1, Ljava/util/ArrayList;

    iget-object v2, p0, LB0/h;->f:Ljava/util/List;

    invoke-direct {v0, v2, v1, p2}, LB0/h;-><init>(Ljava/util/List;Ljava/util/ArrayList;Lyc/d;)V

    iput-object p1, v0, LB0/h;->e:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/h;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/h;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/h;->d:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_2f

    if-eq v1, v3, :cond_1e

    if-ne v1, v2, :cond_16

    iget-object v1, p0, LB0/h;->a:Ljava/util/Iterator;

    iget-object v4, p0, LB0/h;->e:Ljava/lang/Object;

    check-cast v4, Ljava/util/List;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_3e

    :cond_16
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1e
    iget-object v1, p0, LB0/h;->c:Ljava/lang/Object;

    iget-object v4, p0, LB0/h;->b:LE0/d;

    iget-object v5, p0, LB0/h;->a:Ljava/util/Iterator;

    iget-object v6, p0, LB0/h;->e:Ljava/lang/Object;

    check-cast v6, Ljava/util/List;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object v9, v6

    move-object v6, v4

    move-object v4, v9

    goto :goto_60

    :cond_2f
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/h;->e:Ljava/lang/Object;

    iget-object v1, p0, LB0/h;->f:Ljava/util/List;

    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    iget-object v4, p0, LB0/h;->g:Ljava/util/List;

    :goto_3e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_97

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LE0/d;

    iput-object v4, p0, LB0/h;->e:Ljava/lang/Object;

    iput-object v1, p0, LB0/h;->a:Ljava/util/Iterator;

    iput-object v5, p0, LB0/h;->b:LE0/d;

    iput-object p1, p0, LB0/h;->c:Ljava/lang/Object;

    iput v3, p0, LB0/h;->d:I

    invoke-virtual {v5, p1, p0}, LE0/d;->a(Ljava/lang/Object;Lyc/d;)Ljava/lang/Object;

    move-result-object v6

    if-ne v6, v0, :cond_5b

    return-object v0

    :cond_5b
    move-object v9, v1

    move-object v1, p1

    move-object p1, v6

    move-object v6, v5

    move-object v5, v9

    :goto_60
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_95

    new-instance p1, LB0/g;

    const/4 v7, 0x0

    invoke-direct {p1, v6, v7}, LB0/g;-><init>(LE0/d;Lyc/d;)V

    invoke-interface {v4, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iput-object v4, p0, LB0/h;->e:Ljava/lang/Object;

    iput-object v5, p0, LB0/h;->a:Ljava/util/Iterator;

    iput-object v7, p0, LB0/h;->b:LE0/d;

    iput-object v7, p0, LB0/h;->c:Ljava/lang/Object;

    iput v2, p0, LB0/h;->d:I

    new-instance p1, LE0/f;

    iget-object v7, v6, LE0/d;->e:Luc/l;

    invoke-virtual {v7}, Luc/l;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/content/SharedPreferences;

    iget-object v8, v6, LE0/d;->f:Ljava/util/Set;

    invoke-direct {p1, v7, v8}, LE0/f;-><init>(Landroid/content/SharedPreferences;Ljava/util/Set;)V

    iget-object v6, v6, LE0/d;->b:LHc/d;

    invoke-interface {v6, p1, v1, p0}, LHc/d;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_93

    return-object v0

    :cond_93
    :goto_93
    move-object v1, v5

    goto :goto_3e

    :cond_95
    move-object p1, v1

    goto :goto_93

    :cond_97
    return-object p1
.end method
