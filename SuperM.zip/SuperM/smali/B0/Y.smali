.class public final LB0/y;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field public final synthetic b:LB0/g0;


# direct methods
.method public constructor <init>(LB0/g0;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/y;->b:LB0/g0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 5

    new-instance v0, LB0/y;

    iget-object v1, p0, LB0/y;->b:LB0/g0;

    invoke-direct {v0, v1, p2}, LB0/y;-><init>(LB0/g0;Lyc/d;)V

    iput-object p1, v0, LB0/y;->a:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LB0/g0;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/y;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/y;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/y;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    sget-object v0, Lzc/a;->a:Lzc/a;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/y;->a:Ljava/lang/Object;

    check-cast p1, LB0/g0;

    instance-of v0, p1, LB0/d;

    if-eqz v0, :cond_17

    iget p1, p1, LB0/g0;->a:I

    iget-object v0, p0, LB0/y;->b:LB0/g0;

    iget v0, v0, LB0/g0;->a:I

    if-gt p1, v0, :cond_17

    const/4 p1, 0x1

    goto :goto_18

    :cond_17
    const/4 p1, 0x0

    :goto_18
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
