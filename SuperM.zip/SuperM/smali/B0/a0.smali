.class public final LB0/a0;
.super Lkotlin/jvm/internal/m;
.source "SourceFile"

# interfaces
.implements LHc/b;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LHc/b;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LB0/P;LAa/s;)V
    .registers 4

    const/4 v0, 0x0

    iput v0, p0, LB0/a0;->a:I

    sget-object v0, LB0/Q;->a:LB0/Q;

    iput-object p1, p0, LB0/a0;->b:LHc/b;

    iput-object p2, p0, LB0/a0;->c:Ljava/lang/Object;

    iput-object v0, p0, LB0/a0;->d:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/m;-><init>(I)V

    return-void
.end method

.method public constructor <init>(LHc/b;Ljava/lang/Object;Lyc/j;)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, LB0/a0;->a:I

    iput-object p1, p0, LB0/a0;->b:LHc/b;

    iput-object p2, p0, LB0/a0;->c:Ljava/lang/Object;

    iput-object p3, p0, LB0/a0;->d:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/m;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    iget v0, p0, LB0/a0;->a:I

    packed-switch v0, :pswitch_data_4e

    check-cast p1, Ljava/lang/Throwable;

    const/4 p1, 0x0

    iget-object v0, p0, LB0/a0;->b:LHc/b;

    iget-object v1, p0, LB0/a0;->c:Ljava/lang/Object;

    invoke-static {v0, v1, p1}, Lge/A;->a(LHc/b;Ljava/lang/Object;Landroidx/media3/exoplayer/T;)Landroidx/media3/exoplayer/T;

    move-result-object p1

    if-eqz p1, :cond_19

    iget-object v0, p0, LB0/a0;->d:Ljava/lang/Object;

    check-cast v0, Lyc/j;

    invoke-static {p1, v0}, Lm7/c3;->a(Ljava/lang/Throwable;Lyc/j;)V

    :cond_19
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :pswitch_1c
    check-cast p1, Ljava/lang/Throwable;

    iget-object v0, p0, LB0/a0;->b:LHc/b;

    invoke-interface {v0, p1}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, LB0/a0;->c:Ljava/lang/Object;

    check-cast v0, LAa/s;

    iget-object v1, v0, LAa/s;->c:Ljava/lang/Object;

    check-cast v1, Lde/c;

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v2}, Lde/c;->k(Ljava/lang/Throwable;Z)Z

    :cond_2f
    iget-object v1, v0, LAa/s;->c:Ljava/lang/Object;

    check-cast v1, Lde/c;

    invoke-virtual {v1}, Lde/c;->B()Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Lde/i;

    const/4 v3, 0x0

    if-nez v2, :cond_3d

    goto :goto_3e

    :cond_3d
    move-object v1, v3

    :goto_3e
    sget-object v2, Luc/z;->a:Luc/z;

    if-eqz v1, :cond_4a

    iget-object v3, p0, LB0/a0;->d:Ljava/lang/Object;

    check-cast v3, LHc/c;

    invoke-interface {v3, v1, p1}, LHc/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v3, v2

    :cond_4a
    if-nez v3, :cond_2f

    return-object v2

    nop

    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_1c
    .end packed-switch
.end method
