.class public final LB0/l;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Lkotlin/jvm/internal/z;

.field public e:LB0/V;

.field public synthetic f:Ljava/lang/Object;

.field public final synthetic g:LB0/m;

.field public h:I


# direct methods
.method public constructor <init>(LB0/m;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/l;->g:LB0/m;

    invoke-direct {p0, p2}, LAc/c;-><init>(Lyc/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LB0/l;->f:Ljava/lang/Object;

    iget p1, p0, LB0/l;->h:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB0/l;->h:I

    iget-object p1, p0, LB0/l;->g:LB0/m;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, LB0/m;->a(LB0/h;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
