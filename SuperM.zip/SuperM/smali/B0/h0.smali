.class public interface abstract LB0/h0;
.super Ljava/lang/Object;
.source "SourceFile"
