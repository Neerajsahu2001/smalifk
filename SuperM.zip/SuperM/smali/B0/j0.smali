.class public final LB0/j0;
.super LB0/g0;
.source "SourceFile"


# static fields
.field public static final b:LB0/j0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LB0/j0;

    const/4 v1, -0x1

    invoke-direct {v0, v1}, LB0/g0;-><init>(I)V

    sput-object v0, LB0/j0;->b:LB0/j0;

    return-void
.end method
