.class public final LB0/m;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lje/a;

.field public final synthetic b:Lkotlin/jvm/internal/w;

.field public final synthetic c:Lkotlin/jvm/internal/z;

.field public final synthetic d:LB0/V;


# direct methods
.method public constructor <init>(Lje/a;Lkotlin/jvm/internal/w;Lkotlin/jvm/internal/z;LB0/V;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/m;->a:Lje/a;

    iput-object p2, p0, LB0/m;->b:Lkotlin/jvm/internal/w;

    iput-object p3, p0, LB0/m;->c:Lkotlin/jvm/internal/z;

    iput-object p4, p0, LB0/m;->d:LB0/V;

    return-void
.end method


# virtual methods
.method public final a(LB0/h;Lyc/d;)Ljava/lang/Object;
    .registers 13

    instance-of v0, p2, LB0/l;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, LB0/l;

    iget v1, v0, LB0/l;->h:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LB0/l;->h:I

    goto :goto_18

    :cond_13
    new-instance v0, LB0/l;

    invoke-direct {v0, p0, p2}, LB0/l;-><init>(LB0/m;Lyc/d;)V

    :goto_18
    iget-object p2, v0, LB0/l;->f:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, LB0/l;->h:I

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_6f

    if-eq v2, v5, :cond_58

    if-eq v2, v4, :cond_44

    if-ne v2, v3, :cond_3c

    iget-object p1, v0, LB0/l;->c:Ljava/lang/Object;

    iget-object v1, v0, LB0/l;->b:Ljava/lang/Object;

    check-cast v1, Lkotlin/jvm/internal/z;

    iget-object v0, v0, LB0/l;->a:Ljava/lang/Object;

    check-cast v0, Lje/a;

    :try_start_34
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_37
    .catchall {:try_start_34 .. :try_end_37} :catchall_39

    goto/16 :goto_c7

    :catchall_39
    move-exception p1

    goto/16 :goto_e3

    :cond_3c
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_44
    iget-object p1, v0, LB0/l;->c:Ljava/lang/Object;

    check-cast p1, LB0/V;

    iget-object v2, v0, LB0/l;->b:Ljava/lang/Object;

    check-cast v2, Lkotlin/jvm/internal/z;

    iget-object v4, v0, LB0/l;->a:Ljava/lang/Object;

    check-cast v4, Lje/a;

    :try_start_50
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_53
    .catchall {:try_start_50 .. :try_end_53} :catchall_54

    goto :goto_ac

    :catchall_54
    move-exception p1

    move-object v0, v4

    goto/16 :goto_e3

    :cond_58
    iget-object p1, v0, LB0/l;->e:LB0/V;

    iget-object v2, v0, LB0/l;->d:Lkotlin/jvm/internal/z;

    iget-object v7, v0, LB0/l;->c:Ljava/lang/Object;

    check-cast v7, Lkotlin/jvm/internal/w;

    iget-object v8, v0, LB0/l;->b:Ljava/lang/Object;

    check-cast v8, Lje/a;

    iget-object v9, v0, LB0/l;->a:Ljava/lang/Object;

    check-cast v9, LHc/c;

    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object p2, v8

    move-object v8, p1

    move-object p1, v9

    goto :goto_8f

    :cond_6f
    invoke-static {p2}, Ll7/C6;->j(Ljava/lang/Object;)V

    iput-object p1, v0, LB0/l;->a:Ljava/lang/Object;

    iget-object p2, p0, LB0/m;->a:Lje/a;

    iput-object p2, v0, LB0/l;->b:Ljava/lang/Object;

    iget-object v7, p0, LB0/m;->b:Lkotlin/jvm/internal/w;

    iput-object v7, v0, LB0/l;->c:Ljava/lang/Object;

    iget-object v2, p0, LB0/m;->c:Lkotlin/jvm/internal/z;

    iput-object v2, v0, LB0/l;->d:Lkotlin/jvm/internal/z;

    iget-object v8, p0, LB0/m;->d:LB0/V;

    iput-object v8, v0, LB0/l;->e:LB0/V;

    iput v5, v0, LB0/l;->h:I

    check-cast p2, Lje/c;

    invoke-virtual {p2, v0}, Lje/c;->d(Lyc/d;)Ljava/lang/Object;

    move-result-object v9

    if-ne v9, v1, :cond_8f

    return-object v1

    :cond_8f
    :goto_8f
    :try_start_8f
    iget-boolean v7, v7, Lkotlin/jvm/internal/w;->a:Z

    xor-int/2addr v5, v7

    if-eqz v5, :cond_d7

    iget-object v5, v2, Lkotlin/jvm/internal/z;->a:Ljava/lang/Object;

    iput-object p2, v0, LB0/l;->a:Ljava/lang/Object;

    iput-object v2, v0, LB0/l;->b:Ljava/lang/Object;

    iput-object v8, v0, LB0/l;->c:Ljava/lang/Object;

    iput-object v6, v0, LB0/l;->d:Lkotlin/jvm/internal/z;

    iput-object v6, v0, LB0/l;->e:LB0/V;

    iput v4, v0, LB0/l;->h:I

    invoke-interface {p1, v5, v0}, LHc/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_a6
    .catchall {:try_start_8f .. :try_end_a6} :catchall_d4

    if-ne p1, v1, :cond_a9

    return-object v1

    :cond_a9
    move-object v4, p2

    move-object p2, p1

    move-object p1, v8

    :goto_ac
    :try_start_ac
    iget-object v5, v2, Lkotlin/jvm/internal/z;->a:Ljava/lang/Object;

    invoke-static {p2, v5}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_cb

    iput-object v4, v0, LB0/l;->a:Ljava/lang/Object;

    iput-object v2, v0, LB0/l;->b:Ljava/lang/Object;

    iput-object p2, v0, LB0/l;->c:Ljava/lang/Object;

    iput v3, v0, LB0/l;->h:I

    const/4 v3, 0x0

    invoke-virtual {p1, p2, v3, v0}, LB0/V;->h(Ljava/lang/Object;ZLyc/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_c1
    .catchall {:try_start_ac .. :try_end_c1} :catchall_54

    if-ne p1, v1, :cond_c4

    return-object v1

    :cond_c4
    move-object p1, p2

    move-object v1, v2

    move-object v0, v4

    :goto_c7
    :try_start_c7
    iput-object p1, v1, Lkotlin/jvm/internal/z;->a:Ljava/lang/Object;

    move-object v2, v1

    goto :goto_cc

    :cond_cb
    move-object v0, v4

    :goto_cc
    iget-object p1, v2, Lkotlin/jvm/internal/z;->a:Ljava/lang/Object;
    :try_end_ce
    .catchall {:try_start_c7 .. :try_end_ce} :catchall_39

    check-cast v0, Lje/c;

    invoke-virtual {v0, v6}, Lje/c;->f(Ljava/lang/Object;)V

    return-object p1

    :catchall_d4
    move-exception p1

    move-object v0, p2

    goto :goto_e3

    :cond_d7
    :try_start_d7
    const-string p1, "InitializerApi.updateData should not be called after initialization is complete."

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_e3
    .catchall {:try_start_d7 .. :try_end_e3} :catchall_d4

    :goto_e3
    check-cast v0, Lje/c;

    invoke-virtual {v0, v6}, Lje/c;->f(Ljava/lang/Object;)V

    throw p1
.end method
