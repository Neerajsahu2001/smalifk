.class public final LB0/x;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public synthetic a:Ljava/lang/Object;


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 5

    new-instance v0, LB0/x;

    const/4 v1, 0x2

    invoke-direct {v0, v1, p2}, LAc/j;-><init>(ILyc/d;)V

    iput-object p1, v0, LB0/x;->a:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LB0/g0;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/x;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/x;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/x;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    sget-object v0, Lzc/a;->a:Lzc/a;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/x;->a:Ljava/lang/Object;

    check-cast p1, LB0/g0;

    instance-of p1, p1, LB0/W;

    xor-int/lit8 p1, p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
