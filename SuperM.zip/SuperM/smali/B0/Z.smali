.class public final LB0/z;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field public b:I

.field public final synthetic c:LB0/A;


# direct methods
.method public constructor <init>(LB0/A;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/z;->c:LB0/A;

    invoke-direct {p0, p2}, LAc/c;-><init>(Lyc/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LB0/z;->a:Ljava/lang/Object;

    iget p1, p0, LB0/z;->b:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB0/z;->b:I

    iget-object p1, p0, LB0/z;->c:LB0/A;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, LB0/A;->emit(Ljava/lang/Object;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
