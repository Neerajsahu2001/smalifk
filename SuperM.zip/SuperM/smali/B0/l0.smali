.class public final LB0/l0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lyc/g;


# instance fields
.field public final a:LB0/l0;

.field public final b:LB0/V;


# direct methods
.method public constructor <init>(LB0/l0;LB0/V;)V
    .registers 4

    const-string v0, "instance"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/l0;->a:LB0/l0;

    iput-object p2, p0, LB0/l0;->b:LB0/V;

    return-void
.end method


# virtual methods
.method public final V(Ljava/lang/Object;LHc/c;)Ljava/lang/Object;
    .registers 3

    invoke-interface {p2, p1, p0}, LHc/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final b(LB0/j;)V
    .registers 3

    const-string v0, "candidate"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LB0/l0;->b:LB0/V;

    if-eq v0, p1, :cond_11

    iget-object v0, p0, LB0/l0;->a:LB0/l0;

    if-eqz v0, :cond_10

    invoke-virtual {v0, p1}, LB0/l0;->b(LB0/j;)V

    :cond_10
    return-void

    :cond_11
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Calling updateData inside updateData on the same DataStore instance is not supported\nsince updates made in the parent updateData call will not be visible to the nested\nupdateData call. See https://issuetracker.google.com/issues/241760537 for details."

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final getKey()Lyc/h;
    .registers 2

    sget-object v0, LB0/k0;->a:LB0/k0;

    return-object v0
.end method

.method public final i(Lyc/h;)Lyc/g;
    .registers 2

    invoke-static {p0, p1}, Lm7/C;->c(Lyc/g;Lyc/h;)Lyc/g;

    move-result-object p1

    return-object p1
.end method

.method public final p(Lyc/h;)Lyc/j;
    .registers 2

    invoke-static {p0, p1}, Lm7/C;->e(Lyc/g;Lyc/h;)Lyc/j;

    move-result-object p1

    return-object p1
.end method

.method public final z(Lyc/j;)Lyc/j;
    .registers 2

    invoke-static {p0, p1}, Lm7/C;->f(Lyc/g;Lyc/j;)Lyc/j;

    move-result-object p1

    return-object p1
.end method
