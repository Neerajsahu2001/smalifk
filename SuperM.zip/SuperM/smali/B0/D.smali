.class public final LB0/d;
.super LB0/g0;
.source "SourceFile"


# instance fields
.field public final b:Ljava/lang/Object;

.field public final c:I


# direct methods
.method public constructor <init>(IILjava/lang/Object;)V
    .registers 4

    invoke-direct {p0, p2}, LB0/g0;-><init>(I)V

    iput-object p3, p0, LB0/d;->b:Ljava/lang/Object;

    iput p1, p0, LB0/d;->c:I

    return-void
.end method
