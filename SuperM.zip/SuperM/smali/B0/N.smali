.class public final LB0/n;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/b;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/io/Serializable;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/util/Iterator;

.field public f:I

.field public g:I

.field public final synthetic h:LB0/V;

.field public final synthetic i:LB0/o;


# direct methods
.method public constructor <init>(LB0/V;LB0/o;Lyc/d;)V
    .registers 4

    iput-object p1, p0, LB0/n;->h:LB0/V;

    iput-object p2, p0, LB0/n;->i:LB0/o;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p3}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Lyc/d;)Lyc/d;
    .registers 5

    new-instance v0, LB0/n;

    iget-object v1, p0, LB0/n;->h:LB0/V;

    iget-object v2, p0, LB0/n;->i:LB0/o;

    invoke-direct {v0, v1, v2, p1}, LB0/n;-><init>(LB0/V;LB0/o;Lyc/d;)V

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lyc/d;

    invoke-virtual {p0, p1}, LB0/n;->create(Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/n;

    sget-object v0, Luc/z;->a:Luc/z;

    invoke-virtual {p1, v0}, LB0/n;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/n;->g:I

    iget-object v2, p0, LB0/n;->i:LB0/o;

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v6, p0, LB0/n;->h:LB0/V;

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v1, :cond_63

    if-eq v1, v7, :cond_4f

    if-eq v1, v5, :cond_39

    if-eq v1, v4, :cond_28

    if-ne v1, v3, :cond_20

    iget v0, p0, LB0/n;->f:I

    iget-object v1, p0, LB0/n;->a:Ljava/lang/Object;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto/16 :goto_105

    :cond_20
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_28
    iget-object v1, p0, LB0/n;->c:Ljava/lang/Object;

    check-cast v1, Lje/a;

    iget-object v2, p0, LB0/n;->b:Ljava/io/Serializable;

    check-cast v2, Lkotlin/jvm/internal/z;

    iget-object v4, p0, LB0/n;->a:Ljava/lang/Object;

    check-cast v4, Lkotlin/jvm/internal/w;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto/16 :goto_dd

    :cond_39
    iget-object v1, p0, LB0/n;->e:Ljava/util/Iterator;

    iget-object v9, p0, LB0/n;->d:Ljava/lang/Object;

    check-cast v9, LB0/m;

    iget-object v10, p0, LB0/n;->c:Ljava/lang/Object;

    check-cast v10, Lkotlin/jvm/internal/z;

    iget-object v11, p0, LB0/n;->b:Ljava/io/Serializable;

    check-cast v11, Lkotlin/jvm/internal/w;

    iget-object v12, p0, LB0/n;->a:Ljava/lang/Object;

    check-cast v12, Lje/a;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_a1

    :cond_4f
    iget-object v1, p0, LB0/n;->d:Ljava/lang/Object;

    check-cast v1, Lkotlin/jvm/internal/z;

    iget-object v9, p0, LB0/n;->c:Ljava/lang/Object;

    check-cast v9, Lkotlin/jvm/internal/z;

    iget-object v10, p0, LB0/n;->b:Ljava/io/Serializable;

    check-cast v10, Lkotlin/jvm/internal/w;

    iget-object v11, p0, LB0/n;->a:Ljava/lang/Object;

    check-cast v11, Lje/a;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_86

    :cond_63
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    invoke-static {}, Lje/d;->a()Lje/c;

    move-result-object v11

    new-instance v10, Lkotlin/jvm/internal/w;

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    new-instance v1, Lkotlin/jvm/internal/z;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v11, p0, LB0/n;->a:Ljava/lang/Object;

    iput-object v10, p0, LB0/n;->b:Ljava/io/Serializable;

    iput-object v1, p0, LB0/n;->c:Ljava/lang/Object;

    iput-object v1, p0, LB0/n;->d:Ljava/lang/Object;

    iput v7, p0, LB0/n;->g:I

    invoke-static {v6, v7, p0}, LB0/V;->d(LB0/V;ZLyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_85

    return-object v0

    :cond_85
    move-object v9, v1

    :goto_86
    check-cast p1, LB0/d;

    iget-object p1, p1, LB0/d;->b:Ljava/lang/Object;

    iput-object p1, v1, Lkotlin/jvm/internal/z;->a:Ljava/lang/Object;

    new-instance p1, LB0/m;

    invoke-direct {p1, v11, v10, v9, v6}, LB0/m;-><init>(Lje/a;Lkotlin/jvm/internal/w;Lkotlin/jvm/internal/z;LB0/V;)V

    iget-object v1, v2, LB0/o;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    if-eqz v1, :cond_c3

    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move-object v12, v11

    move-object v11, v10

    move-object v10, v9

    move-object v9, p1

    :cond_a1
    :goto_a1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_c0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LHc/c;

    iput-object v12, p0, LB0/n;->a:Ljava/lang/Object;

    iput-object v11, p0, LB0/n;->b:Ljava/io/Serializable;

    iput-object v10, p0, LB0/n;->c:Ljava/lang/Object;

    iput-object v9, p0, LB0/n;->d:Ljava/lang/Object;

    iput-object v1, p0, LB0/n;->e:Ljava/util/Iterator;

    iput v5, p0, LB0/n;->g:I

    invoke-interface {p1, v9, p0}, LHc/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_a1

    return-object v0

    :cond_c0
    move-object v9, v10

    move-object v10, v11

    move-object v11, v12

    :cond_c3
    iput-object v8, v2, LB0/o;->c:Ljava/lang/Object;

    iput-object v10, p0, LB0/n;->a:Ljava/lang/Object;

    iput-object v9, p0, LB0/n;->b:Ljava/io/Serializable;

    iput-object v11, p0, LB0/n;->c:Ljava/lang/Object;

    iput-object v8, p0, LB0/n;->d:Ljava/lang/Object;

    iput-object v8, p0, LB0/n;->e:Ljava/util/Iterator;

    iput v4, p0, LB0/n;->g:I

    move-object v1, v11

    check-cast v1, Lje/c;

    invoke-virtual {v1, p0}, Lje/c;->d(Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_db

    return-object v0

    :cond_db
    move-object v2, v9

    move-object v4, v10

    :goto_dd
    :try_start_dd
    iput-boolean v7, v4, Lkotlin/jvm/internal/w;->a:Z
    :try_end_df
    .catchall {:try_start_dd .. :try_end_df} :catchall_111

    check-cast v1, Lje/c;

    invoke-virtual {v1, v8}, Lje/c;->f(Ljava/lang/Object;)V

    iget-object v1, v2, Lkotlin/jvm/internal/z;->a:Ljava/lang/Object;

    if-eqz v1, :cond_ed

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    goto :goto_ee

    :cond_ed
    const/4 p1, 0x0

    :goto_ee
    invoke-virtual {v6}, LB0/V;->e()LB0/f0;

    move-result-object v2

    iput-object v1, p0, LB0/n;->a:Ljava/lang/Object;

    iput-object v8, p0, LB0/n;->b:Ljava/io/Serializable;

    iput-object v8, p0, LB0/n;->c:Ljava/lang/Object;

    iput p1, p0, LB0/n;->f:I

    iput v3, p0, LB0/n;->g:I

    invoke-virtual {v2}, LB0/f0;->a()Ljava/lang/Integer;

    move-result-object v2

    if-ne v2, v0, :cond_103

    return-object v0

    :cond_103
    move v0, p1

    move-object p1, v2

    :goto_105
    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    new-instance v2, LB0/d;

    invoke-direct {v2, v0, p1, v1}, LB0/d;-><init>(IILjava/lang/Object;)V

    return-object v2

    :catchall_111
    move-exception p1

    check-cast v1, Lje/c;

    invoke-virtual {v1, v8}, Lje/c;->f(Ljava/lang/Object;)V

    throw p1
.end method
