.class public final LB0/t;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public a:I

.field public final synthetic b:LB0/V;


# direct methods
.method public constructor <init>(LB0/V;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/t;->b:LB0/V;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 4

    new-instance p1, LB0/t;

    iget-object v0, p0, LB0/t;->b:LB0/V;

    invoke-direct {p1, v0, p2}, LB0/t;-><init>(LB0/V;Lyc/d;)V

    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lbe/A;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/t;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/t;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/t;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lzc/a;->a:Lzc/a;

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/t;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-eq v1, v2, :cond_11

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_11
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_29

    :cond_15
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/t;->b:LB0/V;

    iget-object p1, p1, LB0/V;->d:Lee/M;

    sget-object v1, LB0/s;->a:LB0/s;

    iput v2, p0, LB0/t;->a:I

    iget-object p1, p1, Lee/M;->a:Lee/O;

    invoke-interface {p1, v1, p0}, Lee/h;->collect(Lee/i;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_29

    return-object v0

    :cond_29
    :goto_29
    new-instance p1, LD5/g;

    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    throw p1
.end method
