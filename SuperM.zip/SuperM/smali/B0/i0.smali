.class public final LB0/i0;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/d;


# instance fields
.field public a:I

.field public synthetic b:LD0/c;


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, LD0/c;

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p3, Lyc/d;

    new-instance p2, LB0/i0;

    const/4 v0, 0x3

    invoke-direct {p2, v0, p3}, LAc/j;-><init>(ILyc/d;)V

    iput-object p1, p2, LB0/i0;->b:LD0/c;

    sget-object p1, Luc/z;->a:Luc/z;

    invoke-virtual {p2, p1}, LB0/i0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/i0;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_26

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/i0;->b:LD0/c;

    iput v2, p0, LB0/i0;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p0}, LD0/c;->a(LD0/c;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_26

    return-object v0

    :cond_26
    :goto_26
    return-object p1
.end method
