.class public final LB0/e0;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 4

    new-instance p1, LB0/e0;

    const/4 v0, 0x2

    invoke-direct {p1, v0, p2}, LAc/j;-><init>(ILyc/d;)V

    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lee/i;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/e0;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/e0;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/e0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p2
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    sget-object v0, Lzc/a;->a:Lzc/a;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
