.class public final LB0/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lee/i;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LB0/r;->a:I

    iput-object p2, p0, LB0/r;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lyc/d;)Ljava/lang/Object;
    .registers 4

    iget v0, p0, LB0/r;->a:I

    packed-switch v0, :pswitch_data_32

    check-cast p1, Lwe/G0;

    instance-of p2, p1, Lwe/E0;

    if-eqz p2, :cond_c

    goto :goto_1b

    :cond_c
    instance-of p1, p1, Lwe/F0;

    if-eqz p1, :cond_1b

    iget-object p1, p0, LB0/r;->b:Ljava/lang/Object;

    check-cast p1, Lone/upswing/sdk/ui/UpswingActivity;

    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p2

    invoke-virtual {p1, p2}, Lone/upswing/sdk/ui/UpswingActivity;->a(Landroid/content/Intent;)V

    :cond_1b
    :goto_1b
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1

    :pswitch_1e
    iget-object v0, p0, LB0/r;->b:Ljava/lang/Object;

    check-cast v0, Lde/r;

    check-cast v0, Lde/q;

    iget-object v0, v0, Lde/q;->d:Lde/g;

    invoke-interface {v0, p1, p2}, Lde/t;->g(Ljava/lang/Object;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, Lzc/a;->a:Lzc/a;

    if-ne p1, p2, :cond_2f

    goto :goto_31

    :cond_2f
    sget-object p1, Luc/z;->a:Luc/z;

    :goto_31
    return-object p1

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_1e
    .end packed-switch
.end method
