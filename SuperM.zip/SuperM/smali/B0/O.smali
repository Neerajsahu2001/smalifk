.class public final LB0/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/l;
.implements Lt1/J;
.implements Lk1/l;
.implements Ljavax/inject/Provider;


# instance fields
.field public final a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LZ0/w;

    invoke-direct {v0}, LZ0/w;-><init>()V

    iput-object v0, p0, LB0/o;->a:Ljava/lang/Object;

    new-instance v0, LZ0/w;

    invoke-direct {v0}, LZ0/w;-><init>()V

    iput-object v0, p0, LB0/o;->b:Ljava/lang/Object;

    new-instance v0, Ld2/a;

    invoke-direct {v0}, Ld2/a;-><init>()V

    iput-object v0, p0, LB0/o;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LB0/V;Ljava/util/List;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/o;->d:Ljava/lang/Object;

    invoke-static {}, Lje/d;->a()Lje/c;

    move-result-object p1

    iput-object p1, p0, LB0/o;->a:Ljava/lang/Object;

    invoke-static {}, Lm7/Z2;->a()Lbe/p;

    move-result-object p1

    iput-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p2, Ljava/lang/Iterable;

    invoke-static {p2}, Lvc/l;->W(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;LIa/q;Lxa/b;Lx9/o;)V
    .registers 6

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "template"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "metaData"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sdkInstance"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/o;->a:Ljava/lang/Object;

    iput-object p2, p0, LB0/o;->b:Ljava/lang/Object;

    iput-object p3, p0, LB0/o;->c:Ljava/lang/Object;

    iput-object p4, p0, LB0/o;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/datastore/preferences/protobuf/D0;Landroidx/datastore/preferences/protobuf/F0;LF0/k;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/o;->a:Ljava/lang/Object;

    const-string p1, ""

    iput-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    iput-object p2, p0, LB0/o;->c:Ljava/lang/Object;

    iput-object p3, p0, LB0/o;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/o;->a:Ljava/lang/Object;

    iput-object p2, p0, LB0/o;->b:Ljava/lang/Object;

    iput-object p3, p0, LB0/o;->c:Ljava/lang/Object;

    iput-object p4, p0, LB0/o;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ll9/C;Ljavax/inject/Provider;Ls4/K;)V
    .registers 5

    sget-object v0, LB6/c;->a:LQ4/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/o;->a:Ljava/lang/Object;

    iput-object p2, p0, LB0/o;->b:Ljava/lang/Object;

    iput-object p3, p0, LB0/o;->c:Ljava/lang/Object;

    iput-object v0, p0, LB0/o;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt1/j;Ljava/lang/Object;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/o;->d:Ljava/lang/Object;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lt1/a;->a(Lt1/E;)Ll7/r7;

    move-result-object v1

    iput-object v1, p0, LB0/o;->b:Ljava/lang/Object;

    new-instance v1, Lk1/k;

    iget-object p1, p1, Lt1/a;->d:Lk1/k;

    iget-object p1, p1, Lk1/k;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v2, 0x0

    invoke-direct {v1, p1, v2, v0}, Lk1/k;-><init>(Ljava/util/concurrent/CopyOnWriteArrayList;ILt1/E;)V

    iput-object v1, p0, LB0/o;->c:Ljava/lang/Object;

    iput-object p2, p0, LB0/o;->a:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public C(ILt1/E;Lt1/v;Lt1/A;Ljava/io/IOException;Z)V
    .registers 7

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_11

    iget-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Ll7/r7;

    invoke-virtual {p0, p4, p2}, LB0/o;->j(Lt1/A;Lt1/E;)Lt1/A;

    move-result-object p2

    invoke-virtual {p1, p3, p2, p5, p6}, Ll7/r7;->k(Lt1/v;Lt1/A;Ljava/io/IOException;Z)V

    :cond_11
    return-void
.end method

.method public I(ILt1/E;Ljava/lang/Exception;)V
    .registers 4

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Lk1/k;

    invoke-virtual {p1, p3}, Lk1/k;->e(Ljava/lang/Exception;)V

    :cond_d
    return-void
.end method

.method public N(ILt1/E;I)V
    .registers 4

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Lk1/k;

    invoke-virtual {p1, p3}, Lk1/k;->d(I)V

    :cond_d
    return-void
.end method

.method public a(LAa/t;Landroid/widget/RemoteViews;Z)V
    .registers 10

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Lxa/b;

    iget-object v0, p1, Lxa/b;->a:LCa/b;

    iget-object v0, v0, LCa/b;->h:LCa/a;

    iget-boolean v0, v0, LCa/a;->e:Z

    iget-object v1, p0, LB0/o;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    const/4 v2, 0x0

    const-string v3, "darkGrey"

    iget-object v4, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast v4, LIa/q;

    if-eqz v0, :cond_37

    iget-object v0, v4, LIa/q;->f:Ljava/lang/String;

    const-string v5, "assetColor"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_28

    const v0, 0x7f080287

    goto :goto_2b

    :cond_28
    const v0, 0x7f08028b

    :goto_2b
    const v5, 0x7f0a00ba

    invoke-virtual {p2, v5, v0}, Landroid/widget/RemoteViews;->setImageViewResource(II)V

    invoke-virtual {p2, v5, v2}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    invoke-static {p2, v1, p1}, LAa/t;->c(Landroid/widget/RemoteViews;Landroid/content/Context;Lxa/b;)V

    :cond_37
    iget-object p1, v4, LIa/q;->h:LIa/j;

    if-nez p3, :cond_3c

    goto :goto_9f

    :cond_3c
    const p3, 0x7f0a0062

    invoke-virtual {p2, p3, v2}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    iget-object p3, p0, LB0/o;->d:Ljava/lang/Object;

    check-cast p3, Lx9/o;

    iget-object v0, p3, Lx9/o;->b:Lr9/a;

    iget-object v0, v0, Lr9/a;->d:La9/d;

    iget-object v0, v0, La9/d;->b:La9/c;

    iget v0, v0, La9/c;->a:I

    const v2, 0x7f0a03b8

    invoke-virtual {p2, v2, v0}, Landroid/widget/RemoteViews;->setImageViewResource(II)V

    const-string v0, "context"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p3, p3, Lx9/o;->b:Lr9/a;

    iget-object p3, p3, Lr9/a;->d:La9/d;

    iget-object p3, p3, La9/d;->b:La9/c;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p3

    invoke-virtual {p3}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p3

    const-string v0, "hh:mm aaa"

    invoke-static {v0, p3}, Landroid/text/format/DateFormat;->format(Ljava/lang/CharSequence;Ljava/util/Date;)Ljava/lang/CharSequence;

    move-result-object p3

    const-string v0, "null cannot be cast to non-null type kotlin.String"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p3, Ljava/lang/String;

    const v0, 0x7f0a0419

    invoke-virtual {p2, v0, p3}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-static {v1}, Lk7/z;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p3

    const v0, 0x7f0a0063

    invoke-virtual {p2, v0, p3}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-static {p2, p1}, LAa/t;->f0(Landroid/widget/RemoteViews;LIa/j;)V

    iget-object p1, v4, LIa/q;->f:Ljava/lang/String;

    invoke-static {p1, v3}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_96

    const p1, 0x7f080289

    goto :goto_99

    :cond_96
    const p1, 0x7f08028c

    :goto_99
    const p3, 0x7f0a03ac

    invoke-virtual {p2, p3, p1}, Landroid/widget/RemoteViews;->setImageViewResource(II)V

    :goto_9f
    return-void
.end method

.method public c(Lyc/d;)Ljava/lang/Object;
    .registers 8

    instance-of v0, p1, LB0/k;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, LB0/k;

    iget v1, v0, LB0/k;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LB0/k;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, LB0/k;

    invoke-direct {v0, p0, p1}, LB0/k;-><init>(LB0/o;Lyc/d;)V

    :goto_18
    iget-object p1, v0, LB0/k;->b:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, LB0/k;->d:I

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_3a

    if-eq v2, v4, :cond_34

    if-ne v2, v3, :cond_2c

    iget-object v0, v0, LB0/k;->a:LB0/o;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_64

    :cond_2c
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_34
    iget-object v0, v0, LB0/k;->a:LB0/o;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_74

    :cond_3a
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Ljava/util/List;

    iget-object v2, p0, LB0/o;->d:Ljava/lang/Object;

    check-cast v2, LB0/V;

    if-eqz p1, :cond_67

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_4e

    goto :goto_67

    :cond_4e
    invoke-virtual {v2}, LB0/V;->e()LB0/f0;

    move-result-object p1

    new-instance v4, LB0/n;

    const/4 v5, 0x0

    invoke-direct {v4, v2, p0, v5}, LB0/n;-><init>(LB0/V;LB0/o;Lyc/d;)V

    iput-object p0, v0, LB0/k;->a:LB0/o;

    iput v3, v0, LB0/k;->d:I

    invoke-virtual {p1, v4, v0}, LB0/f0;->b(LHc/b;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_63

    return-object v1

    :cond_63
    move-object v0, p0

    :goto_64
    check-cast p1, LB0/d;

    goto :goto_76

    :cond_67
    :goto_67
    iput-object p0, v0, LB0/k;->a:LB0/o;

    iput v4, v0, LB0/k;->d:I

    const/4 p1, 0x0

    invoke-static {v2, p1, v0}, LB0/V;->d(LB0/V;ZLyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_73

    return-object v1

    :cond_73
    move-object v0, p0

    :goto_74
    check-cast p1, LB0/d;

    :goto_76
    iget-object v0, v0, LB0/o;->d:Ljava/lang/Object;

    check-cast v0, LB0/V;

    iget-object v0, v0, LB0/V;->g:Ljc/u;

    invoke-virtual {v0, p1}, Ljc/u;->K(LB0/g0;)V

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method

.method public d([BIILa2/k;LZ0/e;)V
    .registers 43

    move-object/from16 v0, p0

    move/from16 v1, p2

    add-int v2, v1, p3

    iget-object v3, v0, LB0/o;->a:Ljava/lang/Object;

    check-cast v3, LZ0/w;

    move-object/from16 v4, p1

    invoke-virtual {v3, v2, v4}, LZ0/w;->E(I[B)V

    invoke-virtual {v3, v1}, LZ0/w;->G(I)V

    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v1

    const/16 v2, 0xff

    if-lez v1, :cond_47

    iget-object v1, v3, LZ0/w;->a:[B

    iget v4, v3, LZ0/w;->b:I

    aget-byte v1, v1, v4

    and-int/2addr v1, v2

    const/16 v4, 0x78

    if-ne v1, v4, :cond_47

    iget-object v1, v0, LB0/o;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/zip/Inflater;

    if-nez v1, :cond_32

    new-instance v1, Ljava/util/zip/Inflater;

    invoke-direct {v1}, Ljava/util/zip/Inflater;-><init>()V

    iput-object v1, v0, LB0/o;->d:Ljava/lang/Object;

    :cond_32
    iget-object v1, v0, LB0/o;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/zip/Inflater;

    iget-object v4, v0, LB0/o;->b:Ljava/lang/Object;

    check-cast v4, LZ0/w;

    invoke-static {v3, v4, v1}, LZ0/F;->K(LZ0/w;LZ0/w;Ljava/util/zip/Inflater;)Z

    move-result v1

    if-eqz v1, :cond_47

    iget-object v1, v4, LZ0/w;->a:[B

    iget v4, v4, LZ0/w;->c:I

    invoke-virtual {v3, v4, v1}, LZ0/w;->E(I[B)V

    :cond_47
    iget-object v1, v0, LB0/o;->c:Ljava/lang/Object;

    check-cast v1, Ld2/a;

    const/4 v4, 0x0

    iput v4, v1, Ld2/a;->d:I

    iput v4, v1, Ld2/a;->e:I

    iput v4, v1, Ld2/a;->f:I

    iput v4, v1, Ld2/a;->g:I

    iput v4, v1, Ld2/a;->h:I

    iput v4, v1, Ld2/a;->i:I

    iget-object v5, v1, Ld2/a;->a:LZ0/w;

    invoke-virtual {v5, v4}, LZ0/w;->D(I)V

    iput-boolean v4, v1, Ld2/a;->c:Z

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    :goto_64
    invoke-virtual {v3}, LZ0/w;->a()I

    move-result v6

    const/4 v8, 0x3

    if-lt v6, v8, :cond_277

    iget v6, v3, LZ0/w;->c:I

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v9

    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v10

    iget v11, v3, LZ0/w;->b:I

    add-int/2addr v11, v10

    if-le v11, v6, :cond_89

    invoke-virtual {v3, v6}, LZ0/w;->G(I)V

    move v6, v2

    move-object v2, v5

    move-object/from16 v17, v7

    const/4 v12, 0x0

    move/from16 v36, v4

    move-object v4, v3

    move/from16 v3, v36

    goto/16 :goto_266

    :cond_89
    const/16 v6, 0x80

    iget-object v13, v1, Ld2/a;->b:[I

    if-eq v9, v6, :cond_199

    packed-switch v9, :pswitch_data_28e

    :cond_92
    :goto_92
    move v6, v2

    move-object/from16 p3, v3

    move-object/from16 v16, v5

    move-object/from16 v17, v7

    goto/16 :goto_191

    :pswitch_9b
    const/16 v6, 0x13

    if-ge v10, v6, :cond_a0

    goto :goto_92

    :cond_a0
    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v6

    iput v6, v1, Ld2/a;->d:I

    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v6

    iput v6, v1, Ld2/a;->e:I

    const/16 v6, 0xb

    invoke-virtual {v3, v6}, LZ0/w;->H(I)V

    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v6

    iput v6, v1, Ld2/a;->f:I

    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v6

    iput v6, v1, Ld2/a;->g:I

    goto :goto_92

    :pswitch_be
    const/4 v9, 0x4

    if-ge v10, v9, :cond_c2

    goto :goto_92

    :cond_c2
    invoke-virtual {v3, v8}, LZ0/w;->H(I)V

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v8

    and-int/2addr v6, v8

    if-eqz v6, :cond_ce

    const/4 v14, 0x1

    goto :goto_cf

    :cond_ce
    move v14, v4

    :goto_cf
    add-int/lit8 v6, v10, -0x4

    if-eqz v14, :cond_f1

    const/4 v8, 0x7

    if-ge v6, v8, :cond_d7

    goto :goto_92

    :cond_d7
    invoke-virtual {v3}, LZ0/w;->x()I

    move-result v6

    if-ge v6, v9, :cond_de

    goto :goto_92

    :cond_de
    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v8

    iput v8, v1, Ld2/a;->h:I

    invoke-virtual {v3}, LZ0/w;->A()I

    move-result v8

    iput v8, v1, Ld2/a;->i:I

    add-int/lit8 v6, v6, -0x4

    invoke-virtual {v5, v6}, LZ0/w;->D(I)V

    add-int/lit8 v6, v10, -0xb

    :cond_f1
    iget v8, v5, LZ0/w;->b:I

    iget v9, v5, LZ0/w;->c:I

    if-ge v8, v9, :cond_92

    if-lez v6, :cond_92

    sub-int/2addr v9, v8

    invoke-static {v6, v9}, Ljava/lang/Math;->min(II)I

    move-result v6

    iget-object v9, v5, LZ0/w;->a:[B

    invoke-virtual {v3, v8, v6, v9}, LZ0/w;->e(II[B)V

    add-int/2addr v8, v6

    invoke-virtual {v5, v8}, LZ0/w;->G(I)V

    goto :goto_92

    :pswitch_108
    rem-int/lit8 v8, v10, 0x5

    const/4 v9, 0x2

    if-eq v8, v9, :cond_10e

    goto :goto_92

    :cond_10e
    invoke-virtual {v3, v9}, LZ0/w;->H(I)V

    invoke-static {v13, v4}, Ljava/util/Arrays;->fill([II)V

    div-int/lit8 v10, v10, 0x5

    move v8, v4

    :goto_117
    if-ge v8, v10, :cond_187

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v9

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v15

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v16

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v17

    invoke-virtual {v3}, LZ0/w;->u()I

    move-result v18

    int-to-double v14, v15

    add-int/lit8 v12, v16, -0x80

    move-object/from16 p3, v3

    int-to-double v2, v12

    const-wide v19, 0x3ff66e978d4fdf3bL    # 1.402

    mul-double v19, v19, v2

    move-object/from16 v16, v5

    add-double v4, v19, v14

    double-to-int v4, v4

    add-int/lit8 v5, v17, -0x80

    move-object/from16 v17, v7

    int-to-double v6, v5

    const-wide v20, 0x3fd60663c74fb54aL    # 0.34414

    mul-double v20, v20, v6

    sub-double v20, v14, v20

    const-wide v22, 0x3fe6da3c21187e7cL    # 0.71414

    mul-double v2, v2, v22

    sub-double v2, v20, v2

    double-to-int v2, v2

    const-wide v20, 0x3ffc5a1cac083127L    # 1.772

    mul-double v6, v6, v20

    add-double/2addr v6, v14

    double-to-int v3, v6

    shl-int/lit8 v5, v18, 0x18

    const/16 v6, 0xff

    const/4 v7, 0x0

    invoke-static {v4, v7, v6}, LZ0/F;->j(III)I

    move-result v4

    shl-int/lit8 v4, v4, 0x10

    or-int/2addr v4, v5

    invoke-static {v2, v7, v6}, LZ0/F;->j(III)I

    move-result v2

    shl-int/lit8 v2, v2, 0x8

    or-int/2addr v2, v4

    invoke-static {v3, v7, v6}, LZ0/F;->j(III)I

    move-result v3

    or-int/2addr v2, v3

    aput v2, v13, v9

    add-int/lit8 v8, v8, 0x1

    move-object/from16 v3, p3

    move v2, v6

    move-object/from16 v5, v16

    move-object/from16 v7, v17

    const/4 v4, 0x0

    const/16 v6, 0x80

    goto :goto_117

    :cond_187
    move v6, v2

    move-object/from16 p3, v3

    move-object/from16 v16, v5

    move-object/from16 v17, v7

    const/4 v2, 0x1

    iput-boolean v2, v1, Ld2/a;->c:Z

    :goto_191
    move-object/from16 v4, p3

    move-object/from16 v2, v16

    const/4 v3, 0x0

    const/4 v12, 0x0

    goto/16 :goto_263

    :cond_199
    move v6, v2

    move-object/from16 p3, v3

    move-object/from16 v16, v5

    move-object/from16 v17, v7

    iget v2, v1, Ld2/a;->d:I

    if-eqz v2, :cond_24c

    iget v2, v1, Ld2/a;->e:I

    if-eqz v2, :cond_24c

    iget v2, v1, Ld2/a;->h:I

    if-eqz v2, :cond_24c

    iget v2, v1, Ld2/a;->i:I

    if-eqz v2, :cond_24c

    move-object/from16 v2, v16

    iget v3, v2, LZ0/w;->c:I

    if-eqz v3, :cond_24e

    iget v4, v2, LZ0/w;->b:I

    if-ne v4, v3, :cond_24e

    iget-boolean v3, v1, Ld2/a;->c:Z

    if-nez v3, :cond_1c0

    goto/16 :goto_24e

    :cond_1c0
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, LZ0/w;->G(I)V

    iget v3, v1, Ld2/a;->h:I

    iget v4, v1, Ld2/a;->i:I

    mul-int/2addr v3, v4

    new-array v4, v3, [I

    const/4 v7, 0x0

    :cond_1cc
    :goto_1cc
    if-ge v7, v3, :cond_205

    invoke-virtual {v2}, LZ0/w;->u()I

    move-result v5

    if-eqz v5, :cond_1dc

    add-int/lit8 v8, v7, 0x1

    aget v5, v13, v5

    aput v5, v4, v7

    :goto_1da
    move v7, v8

    goto :goto_1cc

    :cond_1dc
    invoke-virtual {v2}, LZ0/w;->u()I

    move-result v5

    if-eqz v5, :cond_1cc

    and-int/lit8 v8, v5, 0x40

    if-nez v8, :cond_1e9

    and-int/lit8 v8, v5, 0x3f

    goto :goto_1f2

    :cond_1e9
    and-int/lit8 v8, v5, 0x3f

    shl-int/lit8 v8, v8, 0x8

    invoke-virtual {v2}, LZ0/w;->u()I

    move-result v9

    or-int/2addr v8, v9

    :goto_1f2
    and-int/lit16 v5, v5, 0x80

    if-nez v5, :cond_1fa

    const/4 v5, 0x0

    aget v9, v13, v5

    goto :goto_200

    :cond_1fa
    invoke-virtual {v2}, LZ0/w;->u()I

    move-result v5

    aget v9, v13, v5

    :goto_200
    add-int/2addr v8, v7

    invoke-static {v4, v7, v8, v9}, Ljava/util/Arrays;->fill([IIII)V

    goto :goto_1da

    :cond_205
    iget v3, v1, Ld2/a;->h:I

    iget v5, v1, Ld2/a;->i:I

    sget-object v7, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v4, v3, v5, v7}, Landroid/graphics/Bitmap;->createBitmap([IIILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v22

    iget v3, v1, Ld2/a;->f:I

    int-to-float v3, v3

    iget v4, v1, Ld2/a;->d:I

    int-to-float v4, v4

    div-float v26, v3, v4

    iget v3, v1, Ld2/a;->g:I

    int-to-float v3, v3

    iget v5, v1, Ld2/a;->e:I

    int-to-float v5, v5

    div-float v23, v3, v5

    iget v3, v1, Ld2/a;->h:I

    int-to-float v3, v3

    div-float v30, v3, v4

    iget v3, v1, Ld2/a;->i:I

    int-to-float v3, v3

    div-float v31, v3, v5

    new-instance v3, LY0/b;

    move-object/from16 v18, v3

    const/high16 v33, -0x1000000

    const/16 v35, 0x0

    const/16 v20, 0x0

    move-object/from16 v21, v20

    move-object/from16 v19, v20

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v27, 0x0

    const/high16 v34, -0x80000000

    move/from16 v28, v34

    const v29, -0x800001

    const/16 v32, 0x0

    invoke-direct/range {v18 .. v35}, LY0/b;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFZIIF)V

    move-object v12, v3

    const/4 v3, 0x0

    goto :goto_250

    :cond_24c
    move-object/from16 v2, v16

    :cond_24e
    :goto_24e
    const/4 v3, 0x0

    const/4 v12, 0x0

    :goto_250
    iput v3, v1, Ld2/a;->d:I

    iput v3, v1, Ld2/a;->e:I

    iput v3, v1, Ld2/a;->f:I

    iput v3, v1, Ld2/a;->g:I

    iput v3, v1, Ld2/a;->h:I

    iput v3, v1, Ld2/a;->i:I

    invoke-virtual {v2, v3}, LZ0/w;->D(I)V

    iput-boolean v3, v1, Ld2/a;->c:Z

    move-object/from16 v4, p3

    :goto_263
    invoke-virtual {v4, v11}, LZ0/w;->G(I)V

    :goto_266
    move-object/from16 v5, v17

    if-eqz v12, :cond_26d

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_26d
    move-object v7, v5

    move-object v5, v2

    move v2, v6

    move-object/from16 v36, v4

    move v4, v3

    move-object/from16 v3, v36

    goto/16 :goto_64

    :cond_277
    move-object v5, v7

    new-instance v1, La2/a;

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v10, -0x7fffffffffffffffL    # -4.9E-324

    move-object v6, v1

    invoke-direct/range {v6 .. v11}, La2/a;-><init>(Ljava/util/List;JJ)V

    move-object/from16 v2, p5

    invoke-interface {v2, v1}, LZ0/e;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_data_28e
    .packed-switch 0x14
        :pswitch_108
        :pswitch_be
        :pswitch_9b
    .end packed-switch
.end method

.method public e(ILt1/E;Lt1/A;)V
    .registers 4

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_11

    iget-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Ll7/r7;

    invoke-virtual {p0, p3, p2}, LB0/o;->j(Lt1/A;Lt1/E;)Lt1/A;

    move-result-object p2

    invoke-virtual {p1, p2}, Ll7/r7;->n(Lt1/A;)V

    :cond_11
    return-void
.end method

.method public f(ILt1/E;)V
    .registers 3

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Lk1/k;

    invoke-virtual {p1}, Lk1/k;->b()V

    :cond_d
    return-void
.end method

.method public g(ILt1/E;Lt1/A;)V
    .registers 4

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_11

    iget-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Ll7/r7;

    invoke-virtual {p0, p3, p2}, LB0/o;->j(Lt1/A;Lt1/E;)Lt1/A;

    move-result-object p2

    invoke-virtual {p1, p2}, Ll7/r7;->b(Lt1/A;)V

    :cond_11
    return-void
.end method

.method public get()Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, LB0/o;->a:Ljava/lang/Object;

    check-cast v0, Ljavax/inject/Provider;

    invoke-interface {v0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    iget-object v1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast v1, Ljavax/inject/Provider;

    invoke-interface {v1}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lz6/d;

    iget-object v2, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast v2, Ljavax/inject/Provider;

    invoke-interface {v2}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ly6/a;

    iget-object v3, p0, LB0/o;->d:Ljava/lang/Object;

    check-cast v3, Ljavax/inject/Provider;

    invoke-interface {v3}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LB6/a;

    new-instance v3, Ly6/c;

    invoke-direct {v3, v0, v1, v2}, Ly6/c;-><init>(Landroid/content/Context;Lz6/d;Ly6/a;)V

    return-object v3
.end method

.method public h(Z)I
    .registers 3

    iget-object v0, p0, LB0/o;->d:Ljava/lang/Object;

    check-cast v0, Lx9/o;

    if-eqz p1, :cond_14

    iget-object p1, v0, Lx9/o;->c:LJ9/a;

    invoke-static {p1}, Lk7/z;->h(LJ9/a;)Z

    move-result p1

    if-eqz p1, :cond_11

    const/16 p1, 0x64

    goto :goto_21

    :cond_11
    const/16 p1, 0x40

    goto :goto_21

    :cond_14
    iget-object p1, v0, Lx9/o;->c:LJ9/a;

    invoke-static {p1}, Lk7/z;->h(LJ9/a;)Z

    move-result p1

    if-eqz p1, :cond_1f

    const/16 p1, 0x11e

    goto :goto_21

    :cond_1f
    const/16 p1, 0x100

    :goto_21
    return p1
.end method

.method public i(ILt1/E;)Z
    .registers 6

    iget-object v0, p0, LB0/o;->a:Ljava/lang/Object;

    iget-object v1, p0, LB0/o;->d:Ljava/lang/Object;

    check-cast v1, Lt1/j;

    if-eqz p2, :cond_10

    invoke-virtual {v1, v0, p2}, Lt1/j;->v(Ljava/lang/Object;Lt1/E;)Lt1/E;

    move-result-object p2

    if-nez p2, :cond_11

    const/4 p1, 0x0

    return p1

    :cond_10
    const/4 p2, 0x0

    :cond_11
    invoke-virtual {v1, p1, v0}, Lt1/j;->y(ILjava/lang/Object;)I

    move-result p1

    iget-object v0, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast v0, Ll7/r7;

    iget v2, v0, Ll7/r7;->a:I

    if-ne v2, p1, :cond_27

    iget-object v0, v0, Ll7/r7;->b:Ljava/lang/Object;

    check-cast v0, Lt1/E;

    invoke-static {v0, p2}, LZ0/F;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_34

    :cond_27
    new-instance v0, Ll7/r7;

    iget-object v2, v1, Lt1/a;->c:Ll7/r7;

    iget-object v2, v2, Ll7/r7;->c:Ljava/lang/Object;

    check-cast v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0, v2, p1, p2}, Ll7/r7;-><init>(Ljava/util/concurrent/CopyOnWriteArrayList;ILt1/E;)V

    iput-object v0, p0, LB0/o;->b:Ljava/lang/Object;

    :cond_34
    iget-object v0, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast v0, Lk1/k;

    iget v2, v0, Lk1/k;->a:I

    if-ne v2, p1, :cond_44

    iget-object v0, v0, Lk1/k;->b:Lt1/E;

    invoke-static {v0, p2}, LZ0/F;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4f

    :cond_44
    new-instance v0, Lk1/k;

    iget-object v1, v1, Lt1/a;->d:Lk1/k;

    iget-object v1, v1, Lk1/k;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0, v1, p1, p2}, Lk1/k;-><init>(Ljava/util/concurrent/CopyOnWriteArrayList;ILt1/E;)V

    iput-object v0, p0, LB0/o;->c:Ljava/lang/Object;

    :cond_4f
    const/4 p1, 0x1

    return p1
.end method

.method public j(Lt1/A;Lt1/E;)Lt1/A;
    .registers 16

    iget-object p2, p0, LB0/o;->d:Ljava/lang/Object;

    check-cast p2, Lt1/j;

    iget-object v0, p0, LB0/o;->a:Ljava/lang/Object;

    iget-wide v1, p1, Lt1/A;->f:J

    invoke-virtual {p2, v0, v1, v2}, Lt1/j;->w(Ljava/lang/Object;J)J

    move-result-wide v9

    iget-wide v3, p1, Lt1/A;->g:J

    invoke-virtual {p2, v0, v3, v4}, Lt1/j;->w(Ljava/lang/Object;J)J

    move-result-wide v11

    cmp-long p2, v9, v1

    if-nez p2, :cond_1b

    cmp-long p2, v11, v3

    if-nez p2, :cond_1b

    return-object p1

    :cond_1b
    new-instance p2, Lt1/A;

    iget v5, p1, Lt1/A;->b:I

    iget-object v6, p1, Lt1/A;->c:Landroidx/media3/common/b;

    iget v4, p1, Lt1/A;->a:I

    iget v7, p1, Lt1/A;->d:I

    iget-object v8, p1, Lt1/A;->e:Ljava/lang/Object;

    move-object v3, p2

    invoke-direct/range {v3 .. v12}, Lt1/A;-><init>(IILandroidx/media3/common/b;ILjava/lang/Object;JJ)V

    return-object p2
.end method

.method public k(ILt1/E;)V
    .registers 3

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Lk1/k;

    invoke-virtual {p1}, Lk1/k;->a()V

    :cond_d
    return-void
.end method

.method public l(Lyc/d;)Ljava/lang/Object;
    .registers 10

    instance-of v0, p1, LB0/Z;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, LB0/Z;

    iget v1, v0, LB0/Z;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, LB0/Z;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, LB0/Z;

    invoke-direct {v0, p0, p1}, LB0/Z;-><init>(LB0/o;Lyc/d;)V

    :goto_18
    iget-object p1, v0, LB0/Z;->c:Ljava/lang/Object;

    sget-object v1, Lzc/a;->a:Lzc/a;

    iget v2, v0, LB0/Z;->e:I

    sget-object v3, Luc/z;->a:Luc/z;

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz v2, :cond_44

    if-eq v2, v4, :cond_3b

    if-ne v2, v5, :cond_33

    iget-object v1, v0, LB0/Z;->b:Lje/a;

    iget-object v0, v0, LB0/Z;->a:LB0/o;

    :try_start_2d
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V
    :try_end_30
    .catchall {:try_start_2d .. :try_end_30} :catchall_31

    goto :goto_89

    :catchall_31
    move-exception p1

    goto :goto_99

    :cond_33
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3b
    iget-object v2, v0, LB0/Z;->b:Lje/a;

    iget-object v7, v0, LB0/Z;->a:LB0/o;

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    move-object p1, v2

    goto :goto_67

    :cond_44
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Lbe/p;

    invoke-virtual {p1}, Lbe/n0;->H()Ljava/lang/Object;

    move-result-object p1

    instance-of p1, p1, Lbe/Y;

    xor-int/2addr p1, v4

    if-eqz p1, :cond_55

    return-object v3

    :cond_55
    iput-object p0, v0, LB0/Z;->a:LB0/o;

    iget-object p1, p0, LB0/o;->a:Ljava/lang/Object;

    check-cast p1, Lje/c;

    iput-object p1, v0, LB0/Z;->b:Lje/a;

    iput v4, v0, LB0/Z;->e:I

    invoke-virtual {p1, v0}, Lje/c;->d(Lyc/d;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v1, :cond_66

    return-object v1

    :cond_66
    move-object v7, p0

    :goto_67
    :try_start_67
    iget-object v2, v7, LB0/o;->b:Ljava/lang/Object;

    check-cast v2, Lbe/p;

    invoke-virtual {v2}, Lbe/n0;->H()Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Lbe/Y;
    :try_end_71
    .catchall {:try_start_67 .. :try_end_71} :catchall_96

    xor-int/2addr v2, v4

    if-eqz v2, :cond_7a

    check-cast p1, Lje/c;

    invoke-virtual {p1, v6}, Lje/c;->f(Ljava/lang/Object;)V

    return-object v3

    :cond_7a
    :try_start_7a
    iput-object v7, v0, LB0/Z;->a:LB0/o;

    iput-object p1, v0, LB0/Z;->b:Lje/a;

    iput v5, v0, LB0/Z;->e:I

    invoke-virtual {v7, v0}, LB0/o;->c(Lyc/d;)Ljava/lang/Object;

    move-result-object v0
    :try_end_84
    .catchall {:try_start_7a .. :try_end_84} :catchall_96

    if-ne v0, v1, :cond_87

    return-object v1

    :cond_87
    move-object v1, p1

    move-object v0, v7

    :goto_89
    :try_start_89
    iget-object p1, v0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Lbe/p;

    invoke-virtual {p1, v3}, Lbe/n0;->O(Ljava/lang/Object;)Z
    :try_end_90
    .catchall {:try_start_89 .. :try_end_90} :catchall_31

    check-cast v1, Lje/c;

    invoke-virtual {v1, v6}, Lje/c;->f(Ljava/lang/Object;)V

    return-object v3

    :catchall_96
    move-exception v0

    move-object v1, p1

    move-object p1, v0

    :goto_99
    check-cast v1, Lje/c;

    invoke-virtual {v1, v6}, Lje/c;->f(Ljava/lang/Object;)V

    throw p1
.end method

.method public m(ILt1/E;Lt1/v;Lt1/A;)V
    .registers 5

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_11

    iget-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Ll7/r7;

    invoke-virtual {p0, p4, p2}, LB0/o;->j(Lt1/A;Lt1/E;)Lt1/A;

    move-result-object p2

    invoke-virtual {p1, p3, p2}, Ll7/r7;->m(Lt1/v;Lt1/A;)V

    :cond_11
    return-void
.end method

.method public p(ILt1/E;)V
    .registers 3

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Lk1/k;

    invoke-virtual {p1}, Lk1/k;->f()V

    :cond_d
    return-void
.end method

.method public q(ILt1/E;)V
    .registers 3

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, LB0/o;->c:Ljava/lang/Object;

    check-cast p1, Lk1/k;

    invoke-virtual {p1}, Lk1/k;->c()V

    :cond_d
    return-void
.end method

.method public t(ILt1/E;Lt1/v;Lt1/A;)V
    .registers 5

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_11

    iget-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Ll7/r7;

    invoke-virtual {p0, p4, p2}, LB0/o;->j(Lt1/A;Lt1/E;)Lt1/A;

    move-result-object p2

    invoke-virtual {p1, p3, p2}, Ll7/r7;->e(Lt1/v;Lt1/A;)V

    :cond_11
    return-void
.end method

.method public w()I
    .registers 2

    const/4 v0, 0x2

    return v0
.end method

.method public y(ILt1/E;Lt1/v;Lt1/A;)V
    .registers 5

    invoke-virtual {p0, p1, p2}, LB0/o;->i(ILt1/E;)Z

    move-result p1

    if-eqz p1, :cond_11

    iget-object p1, p0, LB0/o;->b:Ljava/lang/Object;

    check-cast p1, Ll7/r7;

    invoke-virtual {p0, p4, p2}, LB0/o;->j(Lt1/A;Lt1/E;)Lt1/A;

    move-result-object p2

    invoke-virtual {p1, p3, p2}, Ll7/r7;->h(Lt1/v;Lt1/A;)V

    :cond_11
    return-void
.end method
