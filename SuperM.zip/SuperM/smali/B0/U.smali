.class public final LB0/u;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/c;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:LB0/V;


# direct methods
.method public constructor <init>(LB0/V;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/u;->c:LB0/V;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lyc/d;)Lyc/d;
    .registers 5

    new-instance v0, LB0/u;

    iget-object v1, p0, LB0/u;->c:LB0/V;

    invoke-direct {v0, v1, p2}, LB0/u;-><init>(LB0/V;Lyc/d;)V

    iput-object p1, v0, LB0/u;->b:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lde/r;

    check-cast p2, Lyc/d;

    invoke-virtual {p0, p1, p2}, LB0/u;->create(Ljava/lang/Object;Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/u;

    sget-object p2, Luc/z;->a:Luc/z;

    invoke-virtual {p1, p2}, LB0/u;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/u;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_51

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iget-object p1, p0, LB0/u;->b:Ljava/lang/Object;

    check-cast p1, Lde/r;

    sget-object v1, Lbe/B;->b:Lbe/B;

    new-instance v3, LB0/t;

    iget-object v4, p0, LB0/u;->c:LB0/V;

    const/4 v5, 0x0

    invoke-direct {v3, v4, v5}, LB0/t;-><init>(LB0/V;Lyc/d;)V

    invoke-static {p1, v5, v1, v3, v2}, Lm7/X2;->b(Lbe/A;Lyc/j;Lbe/B;LHc/c;I)Lbe/v0;

    move-result-object v1

    iget-object v3, v4, LB0/V;->e:LC/y0;

    new-instance v4, LB0/p;

    invoke-direct {v4, v1, v5}, LB0/p;-><init>(Lbe/v0;Lyc/d;)V

    new-instance v6, LW2/p;

    const/16 v7, 0x8

    invoke-direct {v6, v7, v4, v3}, LW2/p;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    new-instance v3, LB0/q;

    invoke-direct {v3, v1, v5}, LB0/q;-><init>(Lbe/e0;Lyc/d;)V

    new-instance v1, Lee/p;

    invoke-direct {v1, v6, v3}, Lee/p;-><init>(LW2/p;LB0/q;)V

    new-instance v3, LB0/r;

    const/4 v4, 0x0

    invoke-direct {v3, v4, p1}, LB0/r;-><init>(ILjava/lang/Object;)V

    iput v2, p0, LB0/u;->a:I

    invoke-virtual {v1, v3, p0}, Lee/p;->collect(Lee/i;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_51

    return-object v0

    :cond_51
    :goto_51
    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
