.class public final LB0/d0;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public a:Lje/c;

.field public b:Z

.field public synthetic c:Ljava/lang/Object;

.field public final synthetic d:LB0/f0;

.field public e:I


# direct methods
.method public constructor <init>(LB0/f0;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/d0;->d:LB0/f0;

    invoke-direct {p0, p2}, LAc/c;-><init>(Lyc/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LB0/d0;->c:Ljava/lang/Object;

    iget p1, p0, LB0/d0;->e:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB0/d0;->e:I

    iget-object p1, p0, LB0/d0;->d:LB0/f0;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, LB0/f0;->c(LHc/c;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
