.class public final LB0/k;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public a:LB0/o;

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:LB0/o;

.field public d:I


# direct methods
.method public constructor <init>(LB0/o;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/k;->c:LB0/o;

    invoke-direct {p0, p2}, LAc/c;-><init>(Lyc/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LB0/k;->b:Ljava/lang/Object;

    iget p1, p0, LB0/k;->d:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB0/k;->d:I

    iget-object p1, p0, LB0/k;->c:LB0/o;

    invoke-virtual {p1, p0}, LB0/o;->c(Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
