.class public interface abstract LB0/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LHc/c;Lyc/d;)Ljava/lang/Object;
.end method

.method public abstract getData()Lee/h;
.end method
