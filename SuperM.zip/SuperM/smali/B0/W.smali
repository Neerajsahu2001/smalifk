.class public final LB0/w;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:LB0/V;

.field public c:Lbe/o;

.field public synthetic d:Ljava/lang/Object;

.field public final synthetic e:LB0/V;

.field public f:I


# direct methods
.method public constructor <init>(LB0/V;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/w;->e:LB0/V;

    invoke-direct {p0, p2}, LAc/c;-><init>(Lyc/d;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LB0/w;->d:Ljava/lang/Object;

    iget p1, p0, LB0/w;->f:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB0/w;->f:I

    iget-object p1, p0, LB0/w;->e:LB0/V;

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, LB0/V;->b(LB0/V;LB0/X;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
