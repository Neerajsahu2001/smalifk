.class public abstract LB0/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lk7/B;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lk7/B;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lk7/B;-><init>(I)V

    sput-object v0, LB0/i;->a:Lk7/B;

    return-void
.end method
