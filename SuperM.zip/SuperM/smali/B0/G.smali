.class public final LB0/g;
.super LAc/j;
.source "SourceFile"

# interfaces
.implements LHc/b;


# instance fields
.field public a:I

.field public final synthetic b:LE0/d;


# direct methods
.method public constructor <init>(LE0/d;Lyc/d;)V
    .registers 3

    iput-object p1, p0, LB0/g;->b:LE0/d;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, LAc/j;-><init>(ILyc/d;)V

    return-void
.end method


# virtual methods
.method public final create(Lyc/d;)Lyc/d;
    .registers 4

    new-instance v0, LB0/g;

    iget-object v1, p0, LB0/g;->b:LE0/d;

    invoke-direct {v0, v1, p1}, LB0/g;-><init>(LE0/d;Lyc/d;)V

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lyc/d;

    invoke-virtual {p0, p1}, LB0/g;->create(Lyc/d;)Lyc/d;

    move-result-object p1

    check-cast p1, LB0/g;

    sget-object v0, Luc/z;->a:Luc/z;

    invoke-virtual {p1, v0}, LB0/g;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    sget-object v0, Lzc/a;->a:Lzc/a;

    iget v1, p0, LB0/g;->a:I

    sget-object v2, Luc/z;->a:Luc/z;

    const/4 v3, 0x1

    if-eqz v1, :cond_17

    if-ne v1, v3, :cond_f

    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    goto :goto_71

    :cond_f
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_17
    invoke-static {p1}, Ll7/C6;->j(Ljava/lang/Object;)V

    iput v3, p0, LB0/g;->a:I

    iget-object p1, p0, LB0/g;->b:LE0/d;

    iget-object v1, p1, LE0/d;->e:Luc/l;

    invoke-virtual {v1}, Luc/l;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    iget-object v3, p1, LE0/d;->f:Ljava/util/Set;

    if-nez v3, :cond_32

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    goto :goto_46

    :cond_32
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_36
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {v1, v5}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_36

    :cond_46
    :goto_46
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v1

    if-eqz v1, :cond_72

    iget-object v1, p1, LE0/d;->e:Luc/l;

    invoke-virtual {v1}, Luc/l;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_69

    iget-object v1, p1, LE0/d;->c:Landroid/content/Context;

    if-eqz v1, :cond_69

    iget-object p1, p1, LE0/d;->d:Ljava/lang/String;

    if-eqz p1, :cond_69

    invoke-static {v1, p1}, LE0/b;->a(Landroid/content/Context;Ljava/lang/String;)Z

    :cond_69
    if-eqz v3, :cond_6e

    invoke-interface {v3}, Ljava/util/Set;->clear()V

    :cond_6e
    if-ne v2, v0, :cond_71

    return-object v0

    :cond_71
    :goto_71
    return-object v2

    :cond_72
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Unable to delete migrated keys from SharedPreferences."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
