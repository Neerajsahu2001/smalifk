.class public final LB0/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lee/i;


# static fields
.field public static final a:LB0/s;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LB0/s;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LB0/s;->a:LB0/s;

    return-void
.end method


# virtual methods
.method public final bridge synthetic emit(Ljava/lang/Object;Lyc/d;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Luc/z;

    sget-object p1, Luc/z;->a:Luc/z;

    return-object p1
.end method
