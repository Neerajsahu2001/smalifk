.class public final LB0/f;
.super LAc/c;
.source "SourceFile"


# instance fields
.field public a:Ljava/io/Serializable;

.field public b:Ljava/util/Iterator;

.field public synthetic c:Ljava/lang/Object;

.field public d:I


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, LB0/f;->c:Ljava/lang/Object;

    iget p1, p0, LB0/f;->d:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB0/f;->d:I

    const/4 p1, 0x0

    invoke-static {p1, p1, p0}, Lk7/B;->d(Ljava/util/List;LB0/m;Lyc/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
