.class public abstract LA8/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp8/t;


# static fields
.field public static final a:LA8/r;

.field public static final b:LB5/a;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    new-instance v0, LA8/r;

    const/16 v1, 0xa

    new-array v2, v1, [J

    fill-array-data v2, :array_3c

    new-array v3, v1, [J

    fill-array-data v3, :array_68

    new-array v4, v1, [J

    fill-array-data v4, :array_94

    invoke-direct {v0, v2, v3, v4}, LA8/r;-><init>([J[J[J)V

    sput-object v0, LA8/t;->a:LA8/r;

    new-instance v0, LB5/a;

    new-instance v2, LA8/s;

    new-array v3, v1, [J

    fill-array-data v3, :array_c0

    new-array v4, v1, [J

    fill-array-data v4, :array_ec

    new-array v5, v1, [J

    fill-array-data v5, :array_118

    const/4 v6, 0x0

    invoke-direct {v2, v3, v4, v5, v6}, LA8/s;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    new-array v1, v1, [J

    fill-array-data v1, :array_144

    const/4 v3, 0x1

    invoke-direct {v0, v3, v2, v1}, LB5/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    sput-object v0, LA8/t;->b:LB5/a;

    return-void

    nop

    :array_3c
    .array-data 8
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_68
    .array-data 8
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_94
    .array-data 8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_c0
    .array-data 8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_ec
    .array-data 8
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_118
    .array-data 8
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_144
    .array-data 8
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public static a(LB5/a;Lfc/l;LA8/r;)V
    .registers 10

    const/16 v0, 0xa

    new-array v1, v0, [J

    iget-object v2, p0, LB5/a;->b:Ljava/lang/Object;

    check-cast v2, LA8/s;

    iget-object v3, v2, LA8/s;->b:Ljava/lang/Object;

    check-cast v3, [J

    iget-object v4, p1, Lfc/l;->b:Ljava/lang/Object;

    check-cast v4, LA8/s;

    iget-object v5, v4, LA8/s;->c:Ljava/lang/Object;

    check-cast v5, [J

    iget-object v6, v4, LA8/s;->b:Ljava/lang/Object;

    check-cast v6, [J

    invoke-static {v3, v5, v6}, LA8/A;->i([J[J[J)V

    iget-object v3, v2, LA8/s;->c:Ljava/lang/Object;

    check-cast v3, [J

    iget-object v5, v4, LA8/s;->c:Ljava/lang/Object;

    check-cast v5, [J

    iget-object v6, v4, LA8/s;->b:Ljava/lang/Object;

    check-cast v6, [J

    invoke-static {v3, v5, v6}, LA8/A;->h([J[J[J)V

    iget-object v3, p2, LA8/r;->b:[J

    iget-object v5, v2, LA8/s;->c:Ljava/lang/Object;

    check-cast v5, [J

    invoke-static {v5, v5, v3}, LA8/A;->e([J[J[J)V

    iget-object v3, p2, LA8/r;->a:[J

    iget-object v6, v2, LA8/s;->d:Ljava/lang/Object;

    check-cast v6, [J

    iget-object v2, v2, LA8/s;->b:Ljava/lang/Object;

    check-cast v2, [J

    invoke-static {v6, v2, v3}, LA8/A;->e([J[J[J)V

    iget-object p0, p0, LB5/a;->c:Ljava/lang/Object;

    check-cast p0, [J

    iget-object p1, p1, Lfc/l;->c:Ljava/lang/Object;

    check-cast p1, [J

    iget-object p2, p2, LA8/r;->c:[J

    invoke-static {p0, p1, p2}, LA8/A;->e([J[J[J)V

    const/4 p1, 0x0

    iget-object p2, v4, LA8/s;->d:Ljava/lang/Object;

    check-cast p2, [J

    invoke-static {p2, p1, v2, p1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-static {v1, v2, v2}, LA8/A;->i([J[J[J)V

    invoke-static {v2, v6, v5}, LA8/A;->h([J[J[J)V

    invoke-static {v5, v6, v5}, LA8/A;->i([J[J[J)V

    invoke-static {v6, v1, p0}, LA8/A;->i([J[J[J)V

    invoke-static {p0, v1, p0}, LA8/A;->h([J[J[J)V

    return-void
.end method

.method public static varargs b([[B)[B
    .registers 8

    array-length v0, p0

    const/4 v1, 0x0

    move v2, v1

    move v3, v2

    :goto_4
    if-ge v2, v0, :cond_1c

    aget-object v4, p0, v2

    array-length v5, v4

    const v6, 0x7fffffff

    sub-int/2addr v6, v5

    if-gt v3, v6, :cond_14

    array-length v4, v4

    add-int/2addr v3, v4

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_14
    new-instance p0, Ljava/security/GeneralSecurityException;

    const-string v0, "exceeded size limit"

    invoke-direct {p0, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1c
    new-array v0, v3, [B

    array-length v2, p0

    move v3, v1

    move v4, v3

    :goto_21
    if-ge v3, v2, :cond_2e

    aget-object v5, p0, v3

    array-length v6, v5

    invoke-static {v5, v1, v0, v4, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    array-length v5, v5

    add-int/2addr v4, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_21

    :cond_2e
    return-object v0
.end method

.method public static c(LA8/s;LB5/a;)V
    .registers 7

    const/16 v0, 0xa

    new-array v0, v0, [J

    iget-object v1, p1, LB5/a;->b:Ljava/lang/Object;

    check-cast v1, LA8/s;

    iget-object v2, v1, LA8/s;->b:Ljava/lang/Object;

    check-cast v2, [J

    iget-object v3, p0, LA8/s;->b:Ljava/lang/Object;

    check-cast v3, [J

    invoke-static {v2, v3}, LA8/A;->g([J[J)V

    iget-object v2, v1, LA8/s;->d:Ljava/lang/Object;

    check-cast v2, [J

    iget-object v4, p0, LA8/s;->c:Ljava/lang/Object;

    check-cast v4, [J

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    iget-object p1, p1, LB5/a;->c:Ljava/lang/Object;

    check-cast p1, [J

    iget-object p0, p0, LA8/s;->d:Ljava/lang/Object;

    check-cast p0, [J

    invoke-static {p1, p0}, LA8/A;->g([J[J)V

    invoke-static {p1, p1, p1}, LA8/A;->i([J[J[J)V

    iget-object p0, v1, LA8/s;->c:Ljava/lang/Object;

    check-cast p0, [J

    invoke-static {p0, v3, v4}, LA8/A;->i([J[J[J)V

    invoke-static {v0, p0}, LA8/A;->g([J[J)V

    iget-object v2, v1, LA8/s;->d:Ljava/lang/Object;

    check-cast v2, [J

    iget-object v1, v1, LA8/s;->b:Ljava/lang/Object;

    check-cast v1, [J

    invoke-static {p0, v2, v1}, LA8/A;->i([J[J[J)V

    invoke-static {v2, v2, v1}, LA8/A;->h([J[J[J)V

    invoke-static {v1, v0, p0}, LA8/A;->h([J[J[J)V

    invoke-static {p1, p1, v2}, LA8/A;->h([J[J[J)V

    return-void
.end method

.method public static d(II)I
    .registers 2

    xor-int/2addr p0, p1

    not-int p0, p0

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p1, p0, 0x4

    and-int/2addr p0, p1

    shl-int/lit8 p1, p0, 0x2

    and-int/2addr p0, p1

    shl-int/lit8 p1, p0, 0x1

    and-int/2addr p0, p1

    shr-int/lit8 p0, p0, 0x7

    and-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public static final e([B[B)Z
    .registers 7

    const/4 v0, 0x0

    if-eqz p0, :cond_1c

    if-nez p1, :cond_6

    goto :goto_1c

    :cond_6
    array-length v1, p0

    array-length v2, p1

    if-eq v1, v2, :cond_b

    return v0

    :cond_b
    move v1, v0

    move v2, v1

    :goto_d
    array-length v3, p0

    if-ge v1, v3, :cond_19

    aget-byte v3, p0, v1

    aget-byte v4, p1, v1

    xor-int/2addr v3, v4

    or-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_19
    if-nez v2, :cond_1c

    const/4 v0, 0x1

    :cond_1c
    :goto_1c
    return v0
.end method

.method public static f([B)[B
    .registers 4

    sget-object v0, LA8/x;->h:LA8/x;

    const-string v1, "SHA-512"

    invoke-virtual {v0, v1}, LA8/x;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/security/MessageDigest;

    const/16 v1, 0x20

    const/4 v2, 0x0

    invoke-virtual {v0, p0, v2, v1}, Ljava/security/MessageDigest;->update([BII)V

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    aget-byte v0, p0, v2

    and-int/lit16 v0, v0, 0xf8

    int-to-byte v0, v0

    aput-byte v0, p0, v2

    const/16 v0, 0x1f

    aget-byte v1, p0, v0

    and-int/lit8 v1, v1, 0x7f

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    or-int/lit8 v1, v1, 0x40

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    return-object p0
.end method

.method public static g([B)[B
    .registers 17

    const/16 v0, 0x40

    new-array v1, v0, [B

    const/4 v3, 0x0

    :goto_5
    const/16 v4, 0x20

    const/4 v5, 0x1

    if-ge v3, v4, :cond_22

    mul-int/lit8 v4, v3, 0x2

    aget-byte v6, p0, v3

    and-int/lit8 v6, v6, 0xf

    int-to-byte v6, v6

    aput-byte v6, v1, v4

    add-int/2addr v4, v5

    aget-byte v5, p0, v3

    and-int/lit16 v5, v5, 0xff

    shr-int/lit8 v5, v5, 0x4

    and-int/lit8 v5, v5, 0xf

    int-to-byte v5, v5

    aput-byte v5, v1, v4

    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    :cond_22
    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_24
    const/16 v6, 0x3f

    if-ge v3, v6, :cond_3c

    aget-byte v6, v1, v3

    add-int/2addr v6, v4

    int-to-byte v4, v6

    aput-byte v4, v1, v3

    add-int/lit8 v6, v4, 0x8

    shr-int/lit8 v6, v6, 0x4

    shl-int/lit8 v7, v6, 0x4

    sub-int/2addr v4, v7

    int-to-byte v4, v4

    aput-byte v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    move v4, v6

    goto :goto_24

    :cond_3c
    aget-byte v3, v1, v6

    add-int/2addr v3, v4

    int-to-byte v3, v3

    aput-byte v3, v1, v6

    new-instance v3, LB5/a;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, LB5/a;-><init>(I)V

    new-instance v4, Lfc/l;

    const/4 v6, 0x2

    invoke-direct {v4, v6}, Lfc/l;-><init>(I)V

    move v6, v5

    :goto_4f
    if-ge v6, v0, :cond_66

    new-instance v7, LA8/r;

    invoke-direct {v7}, LA8/r;-><init>()V

    div-int/lit8 v8, v6, 0x2

    aget-byte v9, v1, v6

    invoke-static {v7, v8, v9}, LA8/t;->h(LA8/r;IB)V

    invoke-static {v4, v3}, Lfc/l;->i(Lfc/l;LB5/a;)V

    invoke-static {v3, v4, v7}, LA8/t;->a(LB5/a;Lfc/l;LA8/r;)V

    add-int/lit8 v6, v6, 0x2

    goto :goto_4f

    :cond_66
    new-instance v6, LA8/s;

    const/4 v7, 0x0

    invoke-direct {v6, v7}, LA8/s;-><init>(I)V

    invoke-static {v6, v3}, LA8/s;->b(LA8/s;LB5/a;)V

    invoke-static {v6, v3}, LA8/t;->c(LA8/s;LB5/a;)V

    invoke-static {v6, v3}, LA8/s;->b(LA8/s;LB5/a;)V

    invoke-static {v6, v3}, LA8/t;->c(LA8/s;LB5/a;)V

    invoke-static {v6, v3}, LA8/s;->b(LA8/s;LB5/a;)V

    invoke-static {v6, v3}, LA8/t;->c(LA8/s;LB5/a;)V

    invoke-static {v6, v3}, LA8/s;->b(LA8/s;LB5/a;)V

    invoke-static {v6, v3}, LA8/t;->c(LA8/s;LB5/a;)V

    const/4 v6, 0x0

    :goto_85
    if-ge v6, v0, :cond_9c

    new-instance v7, LA8/r;

    invoke-direct {v7}, LA8/r;-><init>()V

    div-int/lit8 v8, v6, 0x2

    aget-byte v9, v1, v6

    invoke-static {v7, v8, v9}, LA8/t;->h(LA8/r;IB)V

    invoke-static {v4, v3}, Lfc/l;->i(Lfc/l;LB5/a;)V

    invoke-static {v3, v4, v7}, LA8/t;->a(LB5/a;Lfc/l;LA8/r;)V

    add-int/lit8 v6, v6, 0x2

    goto :goto_85

    :cond_9c
    const/16 v0, 0xa

    new-array v1, v0, [J

    new-array v4, v0, [J

    new-array v6, v0, [J

    iget-object v7, v3, LB5/a;->b:Ljava/lang/Object;

    check-cast v7, LA8/s;

    iget-object v8, v7, LA8/s;->b:Ljava/lang/Object;

    check-cast v8, [J

    iget-object v3, v3, LB5/a;->c:Ljava/lang/Object;

    check-cast v3, [J

    invoke-static {v1, v8, v3}, LA8/A;->e([J[J[J)V

    iget-object v8, v7, LA8/s;->c:Ljava/lang/Object;

    check-cast v8, [J

    iget-object v7, v7, LA8/s;->d:Ljava/lang/Object;

    check-cast v7, [J

    invoke-static {v4, v8, v7}, LA8/A;->e([J[J[J)V

    invoke-static {v6, v7, v3}, LA8/A;->e([J[J[J)V

    new-array v3, v0, [J

    invoke-static {v3, v1}, LA8/A;->g([J[J)V

    new-array v7, v0, [J

    invoke-static {v7, v4}, LA8/A;->g([J[J)V

    new-array v8, v0, [J

    invoke-static {v8, v6}, LA8/A;->g([J[J)V

    new-array v9, v0, [J

    invoke-static {v9, v8}, LA8/A;->g([J[J)V

    new-array v10, v0, [J

    invoke-static {v10, v7, v3}, LA8/A;->h([J[J[J)V

    invoke-static {v10, v10, v8}, LA8/A;->e([J[J[J)V

    new-array v8, v0, [J

    invoke-static {v8, v3, v7}, LA8/A;->e([J[J[J)V

    sget-object v3, LA8/u;->a:[J

    invoke-static {v8, v8, v3}, LA8/A;->e([J[J[J)V

    invoke-static {v8, v8, v9}, LA8/A;->i([J[J[J)V

    invoke-static {v8, v8}, LA8/A;->f([J[J)V

    invoke-static {v10}, LA8/A;->b([J)[B

    move-result-object v3

    invoke-static {v8}, LA8/A;->b([J)[B

    move-result-object v7

    invoke-static {v3, v7}, LA8/t;->e([B[B)Z

    move-result v3

    if-eqz v3, :cond_1f4

    new-array v3, v0, [J

    new-array v7, v0, [J

    new-array v8, v0, [J

    new-array v9, v0, [J

    new-array v10, v0, [J

    new-array v11, v0, [J

    new-array v12, v0, [J

    new-array v13, v0, [J

    new-array v14, v0, [J

    new-array v15, v0, [J

    new-array v5, v0, [J

    new-array v2, v0, [J

    move-object/from16 p0, v4

    new-array v4, v0, [J

    invoke-static {v9, v6}, LA8/A;->g([J[J)V

    invoke-static {v4, v9}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v10, v2, v6}, LA8/A;->e([J[J[J)V

    invoke-static {v11, v10, v9}, LA8/A;->e([J[J[J)V

    invoke-static {v2, v11}, LA8/A;->g([J[J)V

    invoke-static {v12, v2, v10}, LA8/A;->e([J[J[J)V

    invoke-static {v2, v12}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v13, v2, v12}, LA8/A;->e([J[J[J)V

    invoke-static {v2, v13}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    const/4 v6, 0x2

    move v9, v6

    :goto_146
    if-ge v9, v0, :cond_151

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    add-int/lit8 v9, v9, 0x2

    goto :goto_146

    :cond_151
    invoke-static {v14, v4, v13}, LA8/A;->e([J[J[J)V

    invoke-static {v2, v14}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    move v9, v6

    :goto_15b
    const/16 v10, 0x14

    if-ge v9, v10, :cond_168

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    add-int/lit8 v9, v9, 0x2

    goto :goto_15b

    :cond_168
    invoke-static {v2, v4, v14}, LA8/A;->e([J[J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    move v9, v6

    :goto_172
    if-ge v9, v0, :cond_17d

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    add-int/lit8 v9, v9, 0x2

    goto :goto_172

    :cond_17d
    invoke-static {v15, v2, v13}, LA8/A;->e([J[J[J)V

    invoke-static {v2, v15}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    move v0, v6

    :goto_187
    const/16 v9, 0x32

    if-ge v0, v9, :cond_194

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    add-int/lit8 v0, v0, 0x2

    goto :goto_187

    :cond_194
    invoke-static {v5, v4, v15}, LA8/A;->e([J[J[J)V

    invoke-static {v4, v5}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    move v0, v6

    :goto_19e
    const/16 v10, 0x64

    if-ge v0, v10, :cond_1ab

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    add-int/lit8 v0, v0, 0x2

    goto :goto_19e

    :cond_1ab
    invoke-static {v4, v2, v5}, LA8/A;->e([J[J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    :goto_1b4
    if-ge v6, v9, :cond_1bf

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    add-int/lit8 v6, v6, 0x2

    goto :goto_1b4

    :cond_1bf
    invoke-static {v2, v4, v15}, LA8/A;->e([J[J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v2, v4}, LA8/A;->g([J[J)V

    invoke-static {v4, v2}, LA8/A;->g([J[J)V

    invoke-static {v3, v4, v11}, LA8/A;->e([J[J[J)V

    invoke-static {v7, v1, v3}, LA8/A;->e([J[J[J)V

    move-object/from16 v0, p0

    invoke-static {v8, v0, v3}, LA8/A;->e([J[J[J)V

    invoke-static {v8}, LA8/A;->b([J)[B

    move-result-object v0

    const/16 v1, 0x1f

    aget-byte v2, v0, v1

    invoke-static {v7}, LA8/A;->b([J)[B

    move-result-object v3

    const/4 v4, 0x0

    aget-byte v3, v3, v4

    const/4 v4, 0x1

    and-int/2addr v3, v4

    shl-int/lit8 v3, v3, 0x7

    xor-int/2addr v2, v3

    int-to-byte v2, v2

    aput-byte v2, v0, v1

    return-object v0

    :cond_1f4
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "arithmetic error in scalar multiplication"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static h(LA8/r;IB)V
    .registers 11

    and-int/lit16 v0, p2, 0xff

    const/4 v1, 0x7

    shr-int/2addr v0, v1

    neg-int v2, v0

    and-int/2addr v2, p2

    const/4 v3, 0x1

    shl-int/2addr v2, v3

    sub-int/2addr p2, v2

    sget-object v2, LA8/u;->b:[[LA8/r;

    aget-object v4, v2, p1

    const/4 v5, 0x0

    aget-object v4, v4, v5

    invoke-static {p2, v3}, LA8/t;->d(II)I

    move-result v6

    invoke-virtual {p0, v4, v6}, LA8/r;->a(LA8/r;I)V

    aget-object v4, v2, p1

    aget-object v3, v4, v3

    const/4 v4, 0x2

    invoke-static {p2, v4}, LA8/t;->d(II)I

    move-result v6

    invoke-virtual {p0, v3, v6}, LA8/r;->a(LA8/r;I)V

    aget-object v3, v2, p1

    aget-object v3, v3, v4

    const/4 v4, 0x3

    invoke-static {p2, v4}, LA8/t;->d(II)I

    move-result v6

    invoke-virtual {p0, v3, v6}, LA8/r;->a(LA8/r;I)V

    aget-object v3, v2, p1

    aget-object v3, v3, v4

    const/4 v4, 0x4

    invoke-static {p2, v4}, LA8/t;->d(II)I

    move-result v6

    invoke-virtual {p0, v3, v6}, LA8/r;->a(LA8/r;I)V

    aget-object v3, v2, p1

    aget-object v3, v3, v4

    const/4 v4, 0x5

    invoke-static {p2, v4}, LA8/t;->d(II)I

    move-result v6

    invoke-virtual {p0, v3, v6}, LA8/r;->a(LA8/r;I)V

    aget-object v3, v2, p1

    aget-object v3, v3, v4

    const/4 v4, 0x6

    invoke-static {p2, v4}, LA8/t;->d(II)I

    move-result v6

    invoke-virtual {p0, v3, v6}, LA8/r;->a(LA8/r;I)V

    aget-object v3, v2, p1

    aget-object v3, v3, v4

    invoke-static {p2, v1}, LA8/t;->d(II)I

    move-result v4

    invoke-virtual {p0, v3, v4}, LA8/r;->a(LA8/r;I)V

    aget-object p1, v2, p1

    aget-object p1, p1, v1

    const/16 v1, 0x8

    invoke-static {p2, v1}, LA8/t;->d(II)I

    move-result p2

    invoke-virtual {p0, p1, p2}, LA8/r;->a(LA8/r;I)V

    iget-object p1, p0, LA8/r;->b:[J

    const/16 p2, 0xa

    invoke-static {p1, p2}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v1

    iget-object v2, p0, LA8/r;->a:[J

    invoke-static {v2, p2}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v3

    iget-object p0, p0, LA8/r;->c:[J

    invoke-static {p0, p2}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object p2

    :goto_7f
    array-length v4, p2

    if-ge v5, v4, :cond_8a

    aget-wide v6, p2, v5

    neg-long v6, v6

    aput-wide v6, p2, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_7f

    :cond_8a
    invoke-static {v2, v1, v0}, LO8/a;->a([J[JI)V

    invoke-static {p1, v3, v0}, LO8/a;->a([J[JI)V

    invoke-static {p0, p2, v0}, LO8/a;->a([J[JI)V

    return-void
.end method

.method public static final i(Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;I)V
    .registers 7

    if-ltz p3, :cond_28

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    if-lt v0, p3, :cond_28

    invoke-virtual {p2}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    if-lt v0, p3, :cond_28

    invoke-virtual {p0}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    if-lt v0, p3, :cond_28

    const/4 v0, 0x0

    :goto_15
    if-ge v0, p3, :cond_27

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v1

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->get()B

    move-result v2

    xor-int/2addr v1, v2

    int-to-byte v1, v1

    invoke-virtual {p0, v1}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    add-int/lit8 v0, v0, 0x1

    goto :goto_15

    :cond_27
    return-void

    :cond_28
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "That combination of buffers, offsets and length to xor result in out-of-bond accesses."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final j([BII[BI)[B
    .registers 9

    if-ltz p4, :cond_1f

    array-length v0, p0

    sub-int/2addr v0, p4

    if-lt v0, p1, :cond_1f

    array-length v0, p3

    sub-int/2addr v0, p4

    if-lt v0, p2, :cond_1f

    new-array v0, p4, [B

    const/4 v1, 0x0

    :goto_d
    if-ge v1, p4, :cond_1e

    add-int v2, v1, p1

    aget-byte v2, p0, v2

    add-int v3, v1, p2

    aget-byte v3, p3, v3

    xor-int/2addr v2, v3

    int-to-byte v2, v2

    aput-byte v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_1e
    return-object v0

    :cond_1f
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "That combination of buffers, offsets and length to xor result in out-of-bond accesses."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final k([B[B)[B
    .registers 4

    array-length v0, p0

    array-length v1, p1

    if-ne v0, v1, :cond_b

    array-length v0, p0

    const/4 v1, 0x0

    invoke-static {p0, v1, v1, p1, v0}, LA8/t;->j([BII[BI)[B

    move-result-object p0

    return-object p0

    :cond_b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "The lengths of x and y should match."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
