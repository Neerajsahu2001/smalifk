.class public final LA8/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA8/B;


# static fields
.field public static final d:LA8/c;


# instance fields
.field public final a:Ljavax/crypto/spec/SecretKeySpec;

.field public final b:I

.field public final c:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LA8/c;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LA8/c;-><init>(I)V

    sput-object v0, LA8/d;->d:LA8/c;

    return-void
.end method

.method public constructor <init>([BI)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    invoke-static {v0}, LA8/K;->a(I)V

    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    const-string v1, "AES"

    invoke-direct {v0, p1, v1}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    iput-object v0, p0, LA8/d;->a:Ljavax/crypto/spec/SecretKeySpec;

    sget-object p1, LA8/d;->d:LA8/c;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljavax/crypto/Cipher;

    invoke-virtual {p1}, Ljavax/crypto/Cipher;->getBlockSize()I

    move-result p1

    iput p1, p0, LA8/d;->c:I

    const/16 v0, 0xc

    if-lt p2, v0, :cond_27

    if-gt p2, p1, :cond_27

    iput p2, p0, LA8/d;->b:I

    return-void

    :cond_27
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string p2, "invalid IV size"

    invoke-direct {p1, p2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a([B)[B
    .registers 13

    array-length v0, p1

    const v1, 0x7fffffff

    iget v2, p0, LA8/d;->b:I

    sub-int/2addr v1, v2

    if-gt v0, v1, :cond_21

    array-length v0, p1

    add-int/2addr v0, v2

    new-array v0, v0, [B

    invoke-static {v2}, LA8/F;->a(I)[B

    move-result-object v9

    const/4 v1, 0x0

    invoke-static {v9, v1, v0, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    array-length v6, p1

    const/4 v10, 0x1

    const/4 v5, 0x0

    iget v8, p0, LA8/d;->b:I

    move-object v3, p0

    move-object v4, p1

    move-object v7, v0

    invoke-virtual/range {v3 .. v10}, LA8/d;->c([BII[BI[BZ)V

    return-object v0

    :cond_21
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "plaintext length can not exceed "

    invoke-static {v1, v0}, Le/b;->i(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b([B)[B
    .registers 12

    array-length v0, p1

    iget v1, p0, LA8/d;->b:I

    if-lt v0, v1, :cond_1d

    new-array v8, v1, [B

    const/4 v0, 0x0

    invoke-static {p1, v0, v8, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    array-length v0, p1

    iget v4, p0, LA8/d;->b:I

    sub-int/2addr v0, v4

    new-array v0, v0, [B

    array-length v1, p1

    sub-int v5, v1, v4

    const/4 v7, 0x0

    const/4 v9, 0x0

    move-object v2, p0

    move-object v3, p1

    move-object v6, v0

    invoke-virtual/range {v2 .. v9}, LA8/d;->c([BII[BI[BZ)V

    return-object v0

    :cond_1d
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "ciphertext too short"

    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c([BII[BI[BZ)V
    .registers 15

    sget-object v0, LA8/d;->d:LA8/c;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljavax/crypto/Cipher;

    iget v0, p0, LA8/d;->c:I

    new-array v0, v0, [B

    const/4 v2, 0x0

    iget v3, p0, LA8/d;->b:I

    invoke-static {p6, v2, v0, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance p6, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {p6, v0}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    iget-object v0, p0, LA8/d;->a:Ljavax/crypto/spec/SecretKeySpec;

    if-eqz p7, :cond_21

    const/4 p7, 0x1

    invoke-virtual {v1, p7, v0, p6}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    goto :goto_25

    :cond_21
    const/4 p7, 0x2

    invoke-virtual {v1, p7, v0, p6}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    :goto_25
    move-object v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move v6, p5

    invoke-virtual/range {v1 .. v6}, Ljavax/crypto/Cipher;->doFinal([BII[BI)I

    move-result p1

    if-ne p1, p3, :cond_31

    return-void

    :cond_31
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string p2, "stored output\'s length does not match input\'s length"

    invoke-direct {p1, p2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
