.class public final LA8/e;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, LA8/e;->a:I

    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method public final initialValue()Ljava/lang/Object;
    .registers 3

    iget v0, p0, LA8/e;->a:I

    packed-switch v0, :pswitch_data_20

    sget-object v0, LW4/a;->a:LA8/e;

    const/16 v0, 0x4000

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    return-object v0

    :pswitch_e
    :try_start_e
    sget-object v0, LA8/x;->e:LA8/x;

    const-string v1, "AES/ECB/NOPADDING"

    invoke-virtual {v0, v1}, LA8/x;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljavax/crypto/Cipher;
    :try_end_18
    .catch Ljava/security/GeneralSecurityException; {:try_start_e .. :try_end_18} :catch_19

    return-object v0

    :catch_19
    move-exception v0

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method
