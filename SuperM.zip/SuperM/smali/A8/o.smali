.class public final LA8/o;
.super LA8/p;
.source "SourceFile"


# virtual methods
.method public final d(I[I)[I
    .registers 8

    array-length v0, p2

    const/4 v1, 0x3

    if-ne v0, v1, :cond_22

    const/16 v0, 0x10

    new-array v0, v0, [I

    iget-object v1, p0, LA8/p;->a:[I

    sget-object v2, LA8/p;->c:[I

    array-length v3, v2

    const/4 v4, 0x0

    invoke-static {v2, v4, v0, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    array-length v2, v2

    const/16 v3, 0x8

    invoke-static {v1, v4, v0, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/16 v1, 0xc

    aput p1, v0, v1

    const/16 p1, 0xd

    array-length v1, p2

    invoke-static {p2, v4, v0, p1, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v0

    :cond_22
    new-instance p1, Ljava/lang/IllegalArgumentException;

    array-length p2, p2

    mul-int/lit8 p2, p2, 0x20

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    filled-new-array {p2}, [Ljava/lang/Object;

    move-result-object p2

    const-string v0, "ChaCha20 uses 96-bit nonces, but got a %d-bit nonce"

    invoke-static {v0, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final g()I
    .registers 2

    const/16 v0, 0xc

    return v0
.end method
