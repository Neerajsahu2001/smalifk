.class public final LA8/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:[J

.field public final b:[J

.field public final c:[J


# direct methods
.method public constructor <init>()V
    .registers 4

    sget-object v0, LA8/t;->a:LA8/r;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v1, v0, LA8/r;->a:[J

    const/16 v2, 0xa

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v1

    iput-object v1, p0, LA8/r;->a:[J

    iget-object v1, v0, LA8/r;->b:[J

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v1

    iput-object v1, p0, LA8/r;->b:[J

    iget-object v0, v0, LA8/r;->c:[J

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    iput-object v0, p0, LA8/r;->c:[J

    return-void
.end method

.method public constructor <init>([J[J[J)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA8/r;->a:[J

    iput-object p2, p0, LA8/r;->b:[J

    iput-object p3, p0, LA8/r;->c:[J

    return-void
.end method


# virtual methods
.method public final a(LA8/r;I)V
    .registers 5

    iget-object v0, p1, LA8/r;->a:[J

    iget-object v1, p0, LA8/r;->a:[J

    invoke-static {v1, v0, p2}, LO8/a;->a([J[JI)V

    iget-object v0, p0, LA8/r;->b:[J

    iget-object v1, p1, LA8/r;->b:[J

    invoke-static {v0, v1, p2}, LO8/a;->a([J[JI)V

    iget-object v0, p0, LA8/r;->c:[J

    iget-object p1, p1, LA8/r;->c:[J

    invoke-static {v0, p1, p2}, LO8/a;->a([J[JI)V

    return-void
.end method
