.class public final LA8/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/d;
.implements Lr7/O;
.implements Lx4/a;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 5

    iput p1, p0, LA8/s;->a:I

    packed-switch p1, :pswitch_data_22

    const/16 p1, 0xa

    new-array v0, p1, [J

    new-array v1, p1, [J

    new-array p1, p1, [J

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, p1, v2}, LA8/s;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    return-void

    :pswitch_12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LA8/s;->b:Ljava/lang/Object;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LA8/s;->c:Ljava/lang/Object;

    return-void

    :pswitch_data_22
    .packed-switch 0x1
        :pswitch_12
    .end packed-switch
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    iput p1, p0, LA8/s;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LA8/s;)V
    .registers 4

    const/4 v0, 0x0

    iput v0, p0, LA8/s;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p1, LA8/s;->b:Ljava/lang/Object;

    check-cast v0, [J

    const/16 v1, 0xa

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    iput-object v0, p0, LA8/s;->b:Ljava/lang/Object;

    iget-object v0, p1, LA8/s;->c:Ljava/lang/Object;

    check-cast v0, [J

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    iput-object v0, p0, LA8/s;->c:Ljava/lang/Object;

    iget-object p1, p1, LA8/s;->d:Ljava/lang/Object;

    check-cast p1, [J

    invoke-static {p1, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object p1

    iput-object p1, p0, LA8/s;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    iput p4, p0, LA8/s;->a:I

    iput-object p1, p0, LA8/s;->b:Ljava/lang/Object;

    iput-object p2, p0, LA8/s;->c:Ljava/lang/Object;

    iput-object p3, p0, LA8/s;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 12

    iput p2, p0, LA8/s;->a:I

    packed-switch p2, :pswitch_data_f4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p2, LB5/a;

    const/16 v0, 0x12

    const/4 v1, 0x0

    invoke-direct {p2, v0, v1}, LB5/a;-><init>(IZ)V

    iput-object p2, p0, LA8/s;->c:Ljava/lang/Object;

    iput-object p2, p0, LA8/s;->d:Ljava/lang/Object;

    iput-object p1, p0, LA8/s;->b:Ljava/lang/Object;

    return-void

    :pswitch_17
    const-string p2, "/"

    const-string v0, "Invalid DSN scheme: "

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    :try_start_1e
    const-string v1, "The DSN is required."

    invoke-static {p1, v1}, Lio/sentry/config/b;->b(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/net/URI;

    invoke-direct {v1, p1}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URI;->normalize()Ljava/net/URI;

    move-result-object p1

    invoke-virtual {p1}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v2

    const-string v1, "http"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_56

    const-string v1, "https"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_41

    goto :goto_56

    :cond_41
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_53
    move-exception p1

    goto/16 :goto_ee

    :cond_56
    :goto_56
    invoke-virtual {p1}, Ljava/net/URI;->getUserInfo()Ljava/lang/String;

    move-result-object v0
    :try_end_5a
    .catchall {:try_start_1e .. :try_end_5a} :catchall_53

    const-string v1, "Invalid DSN: No public key provided."

    if-eqz v0, :cond_e8

    :try_start_5e
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_e8

    const-string v3, ":"

    const/4 v4, -0x1

    invoke-virtual {v0, v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    aget-object v4, v0, v3

    iput-object v4, p0, LA8/s;->c:Ljava/lang/Object;

    if-eqz v4, :cond_e2

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_e2

    array-length v1, v0

    const/4 v4, 0x1

    if-le v1, v4, :cond_7f

    aget-object v0, v0, v4

    goto :goto_80

    :cond_7f
    const/4 v0, 0x0

    :goto_80
    iput-object v0, p0, LA8/s;->b:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/net/URI;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_95

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v4

    invoke-virtual {v0, v3, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :cond_95
    invoke-virtual {v0, p2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v1

    add-int/2addr v1, v4

    invoke-virtual {v0, v3, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_a8

    invoke-virtual {v3, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :cond_a8
    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_da

    new-instance v0, Ljava/net/URI;

    invoke-virtual {p1}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1}, Ljava/net/URI;->getPort()I

    move-result v5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "api/"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v8}, Ljava/net/URI;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    iput-object v0, p0, LA8/s;->d:Ljava/lang/Object;

    return-void

    :cond_da
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Invalid DSN: A Project Id is required."

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e8
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_ee
    .catchall {:try_start_5e .. :try_end_ee} :catchall_53

    :goto_ee
    new-instance p2, Ljava/lang/IllegalArgumentException;

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :pswitch_data_f4
    .packed-switch 0x5
        :pswitch_17
    .end packed-switch
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    const/4 v0, 0x6

    iput v0, p0, LA8/s;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA8/s;->b:Ljava/lang/Object;

    if-eqz p3, :cond_b

    goto :goto_d

    :cond_b
    const-string p3, ""

    :goto_d
    iput-object p3, p0, LA8/s;->c:Ljava/lang/Object;

    iput-object p2, p0, LA8/s;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/util/ArrayList;)V
    .registers 8

    const/4 v0, 0x3

    iput v0, p0, LA8/s;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LA8/s;->d:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    mul-int/lit8 v0, v0, 0x2

    new-array v0, v0, [J

    iput-object v0, p0, LA8/s;->b:Ljava/lang/Object;

    const/4 v0, 0x0

    :goto_1c
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3b

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Li2/c;

    mul-int/lit8 v2, v0, 0x2

    iget-object v3, p0, LA8/s;->b:Ljava/lang/Object;

    check-cast v3, [J

    iget-wide v4, v1, Li2/c;->b:J

    aput-wide v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    iget-wide v4, v1, Li2/c;->c:J

    aput-wide v4, v3, v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_1c

    :cond_3b
    iget-object p1, p0, LA8/s;->b:Ljava/lang/Object;

    check-cast p1, [J

    array-length v0, p1

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object p1

    iput-object p1, p0, LA8/s;->c:Ljava/lang/Object;

    invoke-static {p1}, Ljava/util/Arrays;->sort([J)V

    return-void
.end method

.method public constructor <init>(Lr7/O1;Ljava/lang/String;Ljava/util/ArrayList;)V
    .registers 5

    const/16 v0, 0x9

    iput v0, p0, LA8/s;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA8/s;->b:Ljava/lang/Object;

    iput-object p3, p0, LA8/s;->c:Ljava/lang/Object;

    iput-object p1, p0, LA8/s;->d:Ljava/lang/Object;

    return-void
.end method

.method public static b(LA8/s;LB5/a;)V
    .registers 5

    iget-object v0, p1, LB5/a;->b:Ljava/lang/Object;

    check-cast v0, LA8/s;

    iget-object v1, v0, LA8/s;->b:Ljava/lang/Object;

    check-cast v1, [J

    iget-object v2, p0, LA8/s;->b:Ljava/lang/Object;

    check-cast v2, [J

    iget-object p1, p1, LB5/a;->c:Ljava/lang/Object;

    check-cast p1, [J

    invoke-static {v2, v1, p1}, LA8/A;->e([J[J[J)V

    iget-object v1, v0, LA8/s;->c:Ljava/lang/Object;

    check-cast v1, [J

    iget-object v2, p0, LA8/s;->c:Ljava/lang/Object;

    check-cast v2, [J

    iget-object v0, v0, LA8/s;->d:Ljava/lang/Object;

    check-cast v0, [J

    invoke-static {v2, v1, v0}, LA8/A;->e([J[J[J)V

    iget-object p0, p0, LA8/s;->d:Ljava/lang/Object;

    check-cast p0, [J

    invoke-static {p0, v0, p1}, LA8/A;->e([J[J[J)V

    return-void
.end method

.method public static c()V
    .registers 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-ge v0, v1, :cond_7

    return-void

    :cond_7
    new-instance v0, Ljava/lang/UnsupportedClassVersionError;

    const-string v1, "This function can only be used for API Level < 29."

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedClassVersionError;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public a(J)I
    .registers 5

    iget-object v0, p0, LA8/s;->c:Ljava/lang/Object;

    check-cast v0, [J

    const/4 v1, 0x0

    invoke-static {v0, p1, p2, v1}, LZ0/F;->b([JJZ)I

    move-result p1

    array-length p2, v0

    if-ge p1, p2, :cond_d

    goto :goto_e

    :cond_d
    const/4 p1, -0x1

    :goto_e
    return p1
.end method

.method public d(Ll4/F;Lj4/h;)Ll4/F;
    .registers 5

    invoke-interface {p1}, Ll4/F;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/Drawable;

    instance-of v1, v0, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz v1, :cond_21

    check-cast v0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p1

    iget-object v0, p0, LA8/s;->b:Ljava/lang/Object;

    check-cast v0, Lm4/b;

    invoke-static {p1, v0}, Ls4/e;->b(Landroid/graphics/Bitmap;Lm4/b;)Ls4/e;

    move-result-object p1

    iget-object v0, p0, LA8/s;->c:Ljava/lang/Object;

    check-cast v0, Lx4/a;

    invoke-interface {v0, p1, p2}, Lx4/a;->d(Ll4/F;Lj4/h;)Ll4/F;

    move-result-object p1

    return-object p1

    :cond_21
    instance-of v0, v0, Lw4/b;

    if-eqz v0, :cond_2e

    iget-object v0, p0, LA8/s;->d:Ljava/lang/Object;

    check-cast v0, Lx4/a;

    invoke-interface {v0, p1, p2}, Lx4/a;->d(Ll4/F;Lj4/h;)Ll4/F;

    move-result-object p1

    return-object p1

    :cond_2e
    const/4 p1, 0x0

    return-object p1
.end method

.method public f(Ljava/lang/String;ILjava/io/IOException;[BLjava/util/Map;)V
    .registers 13

    iget-object p1, p0, LA8/s;->d:Ljava/lang/Object;

    move-object v0, p1

    check-cast v0, Lr7/O1;

    const/4 v1, 0x1

    iget-object p1, p0, LA8/s;->b:Ljava/lang/Object;

    move-object v5, p1

    check-cast v5, Ljava/lang/String;

    iget-object p1, p0, LA8/s;->c:Ljava/lang/Object;

    move-object v6, p1

    check-cast v6, Ljava/util/List;

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    invoke-virtual/range {v0 .. v6}, Lr7/O1;->v(ZILjava/io/IOException;[BLjava/lang/String;Ljava/util/List;)V

    return-void
.end method

.method public h(I)J
    .registers 6

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-ltz p1, :cond_6

    move v2, v1

    goto :goto_7

    :cond_6
    move v2, v0

    :goto_7
    invoke-static {v2}, Lm7/u;->a(Z)V

    iget-object v2, p0, LA8/s;->c:Ljava/lang/Object;

    check-cast v2, [J

    array-length v3, v2

    if-ge p1, v3, :cond_12

    move v0, v1

    :cond_12
    invoke-static {v0}, Lm7/u;->a(Z)V

    aget-wide v0, v2, p1

    return-wide v0
.end method

.method public j(J)Ljava/util/List;
    .registers 12

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    :goto_c
    iget-object v4, p0, LA8/s;->d:Ljava/lang/Object;

    check-cast v4, Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v5

    if-ge v3, v5, :cond_45

    mul-int/lit8 v5, v3, 0x2

    iget-object v6, p0, LA8/s;->b:Ljava/lang/Object;

    check-cast v6, [J

    aget-wide v7, v6, v5

    cmp-long v7, v7, p1

    if-gtz v7, :cond_42

    add-int/lit8 v5, v5, 0x1

    aget-wide v5, v6, v5

    cmp-long v5, p1, v5

    if-gez v5, :cond_42

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Li2/c;

    iget-object v5, v4, Li2/c;->a:LY0/b;

    iget v6, v5, LY0/b;->e:F

    const v7, -0x800001

    cmpl-float v6, v6, v7

    if-nez v6, :cond_3f

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_42

    :cond_3f
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_42
    :goto_42
    add-int/lit8 v3, v3, 0x1

    goto :goto_c

    :cond_45
    new-instance p1, Lb2/d;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Lb2/d;-><init>(I)V

    invoke-static {v1, p1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_4e
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v2, p1, :cond_72

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Li2/c;

    iget-object p1, p1, Li2/c;->a:LY0/b;

    invoke-virtual {p1}, LY0/b;->a()LY0/a;

    move-result-object p1

    rsub-int/lit8 p2, v2, -0x1

    int-to-float p2, p2

    iput p2, p1, LY0/a;->e:F

    const/4 p2, 0x1

    iput p2, p1, LY0/a;->f:I

    invoke-virtual {p1}, LY0/a;->a()LY0/b;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_4e

    :cond_72
    return-object v0
.end method

.method public k()I
    .registers 2

    iget-object v0, p0, LA8/s;->c:Ljava/lang/Object;

    check-cast v0, [J

    array-length v0, v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    iget v0, p0, LA8/s;->a:I

    packed-switch v0, :pswitch_data_60

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    iget-object v1, p0, LA8/s;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7b

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v1, p0, LA8/s;->c:Ljava/lang/Object;

    check-cast v1, LB5/a;

    iget-object v1, v1, LB5/a;->c:Ljava/lang/Object;

    check-cast v1, LB5/a;

    const-string v2, ""

    :goto_27
    if-eqz v1, :cond_56

    iget-object v3, v1, LB5/a;->b:Ljava/lang/Object;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v3, :cond_4c

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->isArray()Z

    move-result v2

    if-eqz v2, :cond_4c

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->deepToString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    invoke-virtual {v0, v2, v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    goto :goto_4f

    :cond_4c
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_4f
    iget-object v1, v1, LB5/a;->c:Ljava/lang/Object;

    check-cast v1, LB5/a;

    const-string v2, ", "

    goto :goto_27

    :cond_56
    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_data_60
    .packed-switch 0x4
        :pswitch_a
    .end packed-switch
.end method
