.class public abstract LA8/n;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/nio/charset/Charset;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "UTF-8"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    sput-object v0, LA8/n;->a:Ljava/nio/charset/Charset;

    return-void
.end method

.method public static a(Ljava/lang/String;)[B
    .registers 16

    sget-object v0, LA8/n;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    array-length v0, p0

    mul-int/lit8 v1, v0, 0x3

    const/4 v2, 0x4

    div-int/2addr v1, v2

    new-array v3, v1, [B

    sget-object v4, LA8/l;->c:[I

    const/4 v5, 0x0

    move v6, v5

    move v7, v6

    move v8, v7

    move v9, v8

    :goto_14
    const/4 v10, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    if-ge v6, v0, :cond_dc

    if-nez v7, :cond_61

    :goto_1b
    add-int/lit8 v13, v6, 0x4

    if-gt v13, v0, :cond_5d

    aget-byte v8, p0, v6

    and-int/lit16 v8, v8, 0xff

    aget v8, v4, v8

    shl-int/lit8 v8, v8, 0x12

    add-int/lit8 v14, v6, 0x1

    aget-byte v14, p0, v14

    and-int/lit16 v14, v14, 0xff

    aget v14, v4, v14

    shl-int/lit8 v14, v14, 0xc

    or-int/2addr v8, v14

    add-int/lit8 v14, v6, 0x2

    aget-byte v14, p0, v14

    and-int/lit16 v14, v14, 0xff

    aget v14, v4, v14

    shl-int/lit8 v14, v14, 0x6

    or-int/2addr v8, v14

    add-int/lit8 v14, v6, 0x3

    aget-byte v14, p0, v14

    and-int/lit16 v14, v14, 0xff

    aget v14, v4, v14

    or-int/2addr v8, v14

    if-ltz v8, :cond_5d

    add-int/lit8 v6, v9, 0x2

    int-to-byte v14, v8

    aput-byte v14, v3, v6

    add-int/lit8 v6, v9, 0x1

    shr-int/lit8 v14, v8, 0x8

    int-to-byte v14, v14

    aput-byte v14, v3, v6

    shr-int/lit8 v6, v8, 0x10

    int-to-byte v6, v6

    aput-byte v6, v3, v9

    add-int/lit8 v9, v9, 0x3

    move v6, v13

    goto :goto_1b

    :cond_5d
    if-lt v6, v0, :cond_61

    goto/16 :goto_dc

    :cond_61
    add-int/lit8 v13, v6, 0x1

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    aget v6, v4, v6

    const/4 v14, -0x1

    if-eqz v7, :cond_d4

    if-eq v7, v12, :cond_ce

    const/4 v12, -0x2

    if-eq v7, v11, :cond_b7

    const/4 v11, 0x5

    if-eq v7, v10, :cond_87

    if-eq v7, v2, :cond_7e

    if-eq v7, v11, :cond_7a

    goto/16 :goto_d9

    :cond_7a
    if-ne v6, v14, :cond_106

    goto/16 :goto_d9

    :cond_7e
    if-ne v6, v12, :cond_84

    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_d9

    :cond_84
    if-ne v6, v14, :cond_106

    goto :goto_d9

    :cond_87
    if-ltz v6, :cond_a2

    shl-int/lit8 v7, v8, 0x6

    or-int/2addr v6, v7

    add-int/lit8 v7, v9, 0x2

    int-to-byte v8, v6

    aput-byte v8, v3, v7

    add-int/lit8 v7, v9, 0x1

    shr-int/lit8 v8, v6, 0x8

    int-to-byte v8, v8

    aput-byte v8, v3, v7

    shr-int/lit8 v7, v6, 0x10

    int-to-byte v7, v7

    aput-byte v7, v3, v9

    add-int/lit8 v9, v9, 0x3

    move v7, v5

    :goto_a0
    move v8, v6

    goto :goto_d9

    :cond_a2
    if-ne v6, v12, :cond_b4

    add-int/lit8 v6, v9, 0x1

    shr-int/lit8 v7, v8, 0x2

    int-to-byte v7, v7

    aput-byte v7, v3, v6

    shr-int/lit8 v6, v8, 0xa

    int-to-byte v6, v6

    aput-byte v6, v3, v9

    add-int/lit8 v9, v9, 0x2

    move v7, v11

    goto :goto_d9

    :cond_b4
    if-ne v6, v14, :cond_106

    goto :goto_d9

    :cond_b7
    if-ltz v6, :cond_bf

    :goto_b9
    shl-int/lit8 v8, v8, 0x6

    or-int/2addr v6, v8

    :goto_bc
    add-int/lit8 v7, v7, 0x1

    goto :goto_a0

    :cond_bf
    if-ne v6, v12, :cond_cb

    add-int/lit8 v6, v9, 0x1

    shr-int/lit8 v7, v8, 0x4

    int-to-byte v7, v7

    aput-byte v7, v3, v9

    move v7, v2

    move v9, v6

    goto :goto_d9

    :cond_cb
    if-ne v6, v14, :cond_106

    goto :goto_d9

    :cond_ce
    if-ltz v6, :cond_d1

    goto :goto_b9

    :cond_d1
    if-ne v6, v14, :cond_106

    goto :goto_d9

    :cond_d4
    if-ltz v6, :cond_d7

    goto :goto_bc

    :cond_d7
    if-ne v6, v14, :cond_106

    :goto_d9
    move v6, v13

    goto/16 :goto_14

    :cond_dc
    :goto_dc
    if-eq v7, v12, :cond_106

    if-eq v7, v11, :cond_f4

    if-eq v7, v10, :cond_e5

    if-eq v7, v2, :cond_106

    goto :goto_fc

    :cond_e5
    add-int/lit8 p0, v9, 0x1

    shr-int/lit8 v0, v8, 0xa

    int-to-byte v0, v0

    aput-byte v0, v3, v9

    add-int/lit8 v9, v9, 0x2

    shr-int/lit8 v0, v8, 0x2

    int-to-byte v0, v0

    aput-byte v0, v3, p0

    goto :goto_fc

    :cond_f4
    add-int/lit8 p0, v9, 0x1

    shr-int/lit8 v0, v8, 0x4

    int-to-byte v0, v0

    aput-byte v0, v3, v9

    move v9, p0

    :goto_fc
    if-ne v9, v1, :cond_ff

    goto :goto_105

    :cond_ff
    new-array p0, v9, [B

    invoke-static {v3, v5, p0, v5, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v3, p0

    :goto_105
    return-object v3

    :cond_106
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "bad base-64"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static b([B)[B
    .registers 12

    array-length v0, p0

    sget-object v1, LA8/m;->c:[B

    div-int/lit8 v2, v0, 0x3

    mul-int/lit8 v2, v2, 0x4

    rem-int/lit8 v3, v0, 0x3

    if-lez v3, :cond_d

    add-int/lit8 v2, v2, 0x4

    :cond_d
    new-array v2, v2, [B

    const/4 v3, -0x1

    const/4 v4, 0x0

    move v6, v3

    move v5, v4

    :goto_13
    add-int/lit8 v7, v4, 0x3

    const/16 v8, 0xa

    if-gt v7, v0, :cond_62

    aget-byte v9, p0, v4

    and-int/lit16 v9, v9, 0xff

    shl-int/lit8 v9, v9, 0x10

    add-int/lit8 v10, v4, 0x1

    aget-byte v10, p0, v10

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x8

    or-int/2addr v9, v10

    add-int/lit8 v4, v4, 0x2

    aget-byte v4, p0, v4

    and-int/lit16 v4, v4, 0xff

    or-int/2addr v4, v9

    shr-int/lit8 v9, v4, 0x12

    and-int/lit8 v9, v9, 0x3f

    aget-byte v9, v1, v9

    aput-byte v9, v2, v5

    add-int/lit8 v9, v5, 0x1

    shr-int/lit8 v10, v4, 0xc

    and-int/lit8 v10, v10, 0x3f

    aget-byte v10, v1, v10

    aput-byte v10, v2, v9

    add-int/lit8 v9, v5, 0x2

    shr-int/lit8 v10, v4, 0x6

    and-int/lit8 v10, v10, 0x3f

    aget-byte v10, v1, v10

    aput-byte v10, v2, v9

    add-int/lit8 v9, v5, 0x3

    and-int/lit8 v4, v4, 0x3f

    aget-byte v4, v1, v4

    aput-byte v4, v2, v9

    add-int/lit8 v4, v5, 0x4

    add-int/2addr v6, v3

    if-nez v6, :cond_60

    add-int/lit8 v5, v5, 0x5

    aput-byte v8, v2, v4

    const/16 v6, 0x13

    :goto_5e
    move v4, v7

    goto :goto_13

    :cond_60
    move v5, v4

    goto :goto_5e

    :cond_62
    add-int/lit8 v3, v0, -0x1

    const/16 v6, 0x3d

    if-ne v4, v3, :cond_87

    aget-byte p0, p0, v4

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x4

    add-int/lit8 v0, v5, 0x1

    shr-int/lit8 v3, p0, 0x6

    and-int/lit8 v3, v3, 0x3f

    aget-byte v3, v1, v3

    aput-byte v3, v2, v5

    add-int/lit8 v3, v5, 0x2

    and-int/lit8 p0, p0, 0x3f

    aget-byte p0, v1, p0

    aput-byte p0, v2, v0

    add-int/lit8 v5, v5, 0x3

    aput-byte v6, v2, v3

    aput-byte v6, v2, v5

    goto :goto_b7

    :cond_87
    add-int/lit8 v0, v0, -0x2

    if-ne v4, v0, :cond_b7

    add-int/lit8 v0, v4, 0x1

    aget-byte v3, p0, v4

    and-int/lit16 v3, v3, 0xff

    shl-int/2addr v3, v8

    aget-byte p0, p0, v0

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x2

    or-int/2addr p0, v3

    add-int/lit8 v0, v5, 0x1

    shr-int/lit8 v3, p0, 0xc

    and-int/lit8 v3, v3, 0x3f

    aget-byte v3, v1, v3

    aput-byte v3, v2, v5

    add-int/lit8 v3, v5, 0x2

    shr-int/lit8 v4, p0, 0x6

    and-int/lit8 v4, v4, 0x3f

    aget-byte v4, v1, v4

    aput-byte v4, v2, v0

    add-int/lit8 v5, v5, 0x3

    and-int/lit8 p0, p0, 0x3f

    aget-byte p0, v1, p0

    aput-byte p0, v2, v3

    aput-byte v6, v2, v5

    :cond_b7
    :goto_b7
    return-object v2
.end method
