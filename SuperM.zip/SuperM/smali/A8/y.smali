.class public interface abstract LA8/y;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
.end method
