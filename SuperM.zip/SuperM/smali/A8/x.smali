.class public final LA8/x;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final c:Ljava/util/logging/Logger;

.field public static final d:Ljava/util/ArrayList;

.field public static final e:LA8/x;

.field public static final f:LA8/x;

.field public static final g:LA8/x;

.field public static final h:LA8/x;

.field public static final i:LA8/x;

.field public static final j:LA8/x;


# instance fields
.field public final a:LA8/y;

.field public final b:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    const/4 v0, 0x2

    const/4 v1, 0x1

    const-class v2, LA8/x;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v2

    sput-object v2, LA8/x;->c:Ljava/util/logging/Logger;

    :try_start_e
    const-string v2, "android.app.Application"

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v2, v4, v3}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_15} :catch_42

    const-string v2, "GmsCore_OpenSSL"

    const-string v3, "AndroidOpenSSL"

    filled-new-array {v2, v3}, [Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    :goto_22
    if-ge v4, v0, :cond_3f

    aget-object v5, v2, v4

    invoke-static {v5}, Ljava/security/Security;->getProvider(Ljava/lang/String;)Ljava/security/Provider;

    move-result-object v6

    if-eqz v6, :cond_30

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3d

    :cond_30
    const-string v6, "Provider "

    const-string v7, " not available"

    invoke-static {v6, v5, v7}, Le/b;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    sget-object v6, LA8/x;->c:Ljava/util/logging/Logger;

    invoke-virtual {v6, v5}, Ljava/util/logging/Logger;->info(Ljava/lang/String;)V

    :goto_3d
    add-int/2addr v4, v1

    goto :goto_22

    :cond_3f
    sput-object v3, LA8/x;->d:Ljava/util/ArrayList;

    goto :goto_49

    :catch_42
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    sput-object v2, LA8/x;->d:Ljava/util/ArrayList;

    :goto_49
    new-instance v2, LA8/x;

    new-instance v3, LN8/a;

    invoke-direct {v3, v0}, LN8/a;-><init>(I)V

    invoke-direct {v2, v3}, LA8/x;-><init>(LA8/y;)V

    sput-object v2, LA8/x;->e:LA8/x;

    new-instance v2, LA8/x;

    new-instance v3, Lb7/e;

    invoke-direct {v3, v1}, Lb7/e;-><init>(I)V

    invoke-direct {v2, v3}, LA8/x;-><init>(LA8/y;)V

    sput-object v2, LA8/x;->f:LA8/x;

    new-instance v2, LA8/x;

    new-instance v3, Lm7/X4;

    invoke-direct {v3, v1}, Lm7/X4;-><init>(I)V

    invoke-direct {v2, v3}, LA8/x;-><init>(LA8/y;)V

    sput-object v2, LA8/x;->g:LA8/x;

    new-instance v2, LA8/x;

    new-instance v3, Lio/sentry/hints/i;

    invoke-direct {v3, v1}, Lio/sentry/hints/i;-><init>(I)V

    invoke-direct {v2, v3}, LA8/x;-><init>(LA8/y;)V

    sput-object v2, LA8/x;->h:LA8/x;

    new-instance v2, LA8/x;

    new-instance v3, LO4/d;

    invoke-direct {v3, v1}, LO4/d;-><init>(I)V

    invoke-direct {v2, v3}, LA8/x;-><init>(LA8/y;)V

    sput-object v2, LA8/x;->i:LA8/x;

    new-instance v1, LA8/x;

    new-instance v2, LO4/c;

    invoke-direct {v2, v0}, LO4/c;-><init>(I)V

    invoke-direct {v1, v2}, LA8/x;-><init>(LA8/y;)V

    sput-object v1, LA8/x;->j:LA8/x;

    return-void
.end method

.method public constructor <init>(LA8/y;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA8/x;->a:LA8/y;

    sget-object p1, LA8/x;->d:Ljava/util/ArrayList;

    iput-object p1, p0, LA8/x;->b:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Ljava/lang/Object;
    .registers 7

    iget-object v0, p0, LA8/x;->b:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    :cond_8
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    iget-object v4, p0, LA8/x;->a:LA8/y;

    if-eqz v3, :cond_20

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/security/Provider;

    :try_start_16
    invoke-interface {v4, p1, v3}, LA8/y;->c(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_1a} :catch_1b

    return-object p1

    :catch_1b
    move-exception v3

    if-nez v2, :cond_8

    move-object v2, v3

    goto :goto_8

    :cond_20
    invoke-interface {v4, p1, v1}, LA8/y;->c(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
