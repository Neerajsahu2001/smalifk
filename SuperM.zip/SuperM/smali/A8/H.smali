.class public final LA8/h;
.super LA8/t;
.source "SourceFile"


# instance fields
.field public final c:I


# direct methods
.method public constructor <init>(II[B)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p3

    const/16 v1, 0x10

    if-lt v0, v1, :cond_23

    array-length v0, p3

    if-lt v0, p1, :cond_23

    invoke-static {p1}, LA8/K;->a(I)V

    iget v0, p0, LA8/h;->c:I

    add-int/lit8 v0, v0, 0x18

    if-le p2, v0, :cond_1b

    array-length p2, p3

    invoke-static {p3, p2}, Ljava/util/Arrays;->copyOf([BI)[B

    iput p1, p0, LA8/h;->c:I

    return-void

    :cond_1b
    new-instance p1, Ljava/security/InvalidAlgorithmParameterException;

    const-string p2, "ciphertextSegmentSize too small"

    invoke-direct {p1, p2}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_23
    new-instance p2, Ljava/security/InvalidAlgorithmParameterException;

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "ikm too short, must be >= "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    throw p2
.end method
