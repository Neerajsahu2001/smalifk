.class public final synthetic LB/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/concurrent/futures/l;
.implements Lcom/facebook/react/uimanager/UIBlock;
.implements LZ0/m;
.implements Lv7/d;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, LB/h;->a:I

    iput-object p2, p0, LB/h;->b:Ljava/lang/Object;

    iput-object p3, p0, LB/h;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public execute(Lcom/facebook/react/uimanager/NativeViewHierarchyManager;)V
    .registers 4

    iget-object v0, p0, LB/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/swmansion/reanimated/ReanimatedModule;

    iget-object v1, p0, LB/h;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    invoke-static {v0, v1, p1}, Lcom/swmansion/reanimated/ReanimatedModule;->a(Lcom/swmansion/reanimated/ReanimatedModule;Ljava/util/ArrayList;Lcom/facebook/react/uimanager/NativeViewHierarchyManager;)V

    return-void
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, LB/h;->a:I

    check-cast p1, Lg1/b;

    packed-switch v0, :pswitch_data_20

    iget-object v0, p0, LB/h;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, LB/h;->c:Ljava/lang/Object;

    check-cast v1, LW0/L;

    invoke-interface {p1, v0, v1}, Lg1/b;->f(Lg1/a;LW0/L;)V

    return-void

    :pswitch_13
    iget-object v0, p0, LB/h;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, LB/h;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/media3/common/Metadata;

    invoke-interface {p1, v0, v1}, Lg1/b;->A(Lg1/a;Landroidx/media3/common/Metadata;)V

    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x3
        :pswitch_13
    .end packed-switch
.end method

.method public n(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .registers 6

    iget-object v0, p0, LB/h;->b:Ljava/lang/Object;

    check-cast v0, LN/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "TextureViewImpl"

    const-string v2, "Surface set on Preview."

    invoke-static {v1, v2}, LHe/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, v0, LN/y;->h:LC/P0;

    invoke-static {}, Lcom/bumptech/glide/c;->a()LF/a;

    move-result-object v2

    new-instance v3, LN/w;

    invoke-direct {v3, p1}, LN/w;-><init>(Landroidx/concurrent/futures/k;)V

    iget-object p1, p0, LB/h;->c:Ljava/lang/Object;

    check-cast p1, Landroid/view/Surface;

    invoke-virtual {v1, p1, v2, v3}, LC/P0;->f(Landroid/view/Surface;Ljava/util/concurrent/Executor;Lq0/a;)V

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "provideSurface[request="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, LN/y;->h:LC/P0;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " surface="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, "]"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public onComplete(Lv7/i;)V
    .registers 4

    iget-object v0, p0, LB/h;->b:Ljava/lang/Object;

    check-cast v0, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;

    iget-object v1, p0, LB/h;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/bridge/Promise;

    invoke-static {v0, v1, p1}, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;->g(Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;Lcom/facebook/react/bridge/Promise;Lv7/i;)V

    return-void
.end method
