.class public final LB/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:Z

.field public final c:Lw/l;

.field public final d:Ljava/util/concurrent/Executor;

.field public final e:Ljava/lang/Object;

.field public f:LC/w;

.field public g:Landroidx/concurrent/futures/k;

.field public final h:LB/c;


# direct methods
.method public constructor <init>(Lw/l;LF/m;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, LB/g;->a:Z

    iput-boolean v0, p0, LB/g;->b:Z

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LB/g;->e:Ljava/lang/Object;

    new-instance v0, LC/w;

    invoke-direct {v0}, LC/w;-><init>()V

    iput-object v0, p0, LB/g;->f:LC/w;

    new-instance v0, LB/c;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p0}, LB/c;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, LB/g;->h:LB/c;

    iput-object p1, p0, LB/g;->c:Lw/l;

    iput-object p2, p0, LB/g;->d:Ljava/util/concurrent/Executor;

    return-void
.end method


# virtual methods
.method public final a()Lv/a;
    .registers 5

    iget-object v0, p0, LB/g;->e:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LB/g;->g:Landroidx/concurrent/futures/k;

    if-eqz v1, :cond_1b

    iget-object v2, p0, LB/g;->f:LC/w;

    iget-object v2, v2, LC/w;->a:LD/Z;

    sget-object v3, Lv/a;->i:LD/c;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v2, v3, v1}, LD/Z;->m(LD/c;Ljava/lang/Object;)V

    goto :goto_1b

    :catchall_19
    move-exception v1

    goto :goto_23

    :cond_1b
    :goto_1b
    iget-object v1, p0, LB/g;->f:LC/w;

    invoke-virtual {v1}, LC/w;->a()Lv/a;

    move-result-object v1

    monitor-exit v0

    return-object v1

    :goto_23
    monitor-exit v0
    :try_end_24
    .catchall {:try_start_3 .. :try_end_24} :catchall_19

    throw v1
.end method

.method public final b(Landroidx/concurrent/futures/k;)V
    .registers 5

    const/4 v0, 0x1

    iput-boolean v0, p0, LB/g;->b:Z

    iget-object v0, p0, LB/g;->g:Landroidx/concurrent/futures/k;

    if-eqz v0, :cond_8

    goto :goto_9

    :cond_8
    const/4 v0, 0x0

    :goto_9
    iput-object p1, p0, LB/g;->g:Landroidx/concurrent/futures/k;

    iget-boolean p1, p0, LB/g;->a:Z

    if-eqz p1, :cond_23

    iget-object p1, p0, LB/g;->c:Lw/l;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, LC/q0;

    const/16 v2, 0x12

    invoke-direct {v1, v2, p1}, LC/q0;-><init>(ILjava/lang/Object;)V

    iget-object p1, p1, Lw/l;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, LB/g;->b:Z

    :cond_23
    if-eqz v0, :cond_2f

    new-instance p1, LC/l;

    const-string v1, "Camera2CameraControl was updated with new options."

    invoke-direct {p1, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Throwable;)Z

    :cond_2f
    return-void
.end method
