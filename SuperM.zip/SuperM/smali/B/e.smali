.class public final synthetic LB/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, LB/e;->a:I

    iput-object p2, p0, LB/e;->b:Ljava/lang/Object;

    iput-object p3, p0, LB/e;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget v2, p0, LB/e;->a:I

    packed-switch v2, :pswitch_data_1e6

    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lx/o;

    iget-object v0, v0, Lx/o;->a:Landroid/hardware/camera2/CameraDevice$StateCallback;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Landroid/hardware/camera2/CameraDevice;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraDevice$StateCallback;->onClosed(Landroid/hardware/camera2/CameraDevice;)V

    return-void

    :pswitch_15
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lx/j;

    iget-object v0, v0, Lx/j;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Landroid/hardware/camera2/CameraCaptureSession;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onConfigured(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void

    :pswitch_23
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/Surface;

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    iget-object v0, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v0, Landroid/graphics/SurfaceTexture;

    invoke-virtual {v0}, Landroid/graphics/SurfaceTexture;->release()V

    return-void

    :pswitch_32
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, LD/i;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, LD/j;

    invoke-virtual {v0, v1}, LD/i;->c(LD/j;)V

    return-void

    :pswitch_3e
    iget-object v2, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v2, Lt1/T;

    iget-object v3, v2, Lt1/T;->s:Landroidx/media3/extractor/metadata/icy/IcyHeaders;

    iget-object v4, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v4, LD1/J;

    const-wide v5, -0x7fffffffffffffffL    # -4.9E-324

    if-nez v3, :cond_51

    move-object v3, v4

    goto :goto_56

    :cond_51
    new-instance v3, LD1/B;

    invoke-direct {v3, v5, v6}, LD1/B;-><init>(J)V

    :goto_56
    iput-object v3, v2, Lt1/T;->A:LD1/J;

    invoke-interface {v4}, LD1/J;->getDurationUs()J

    move-result-wide v7

    iput-wide v7, v2, Lt1/T;->B:J

    iget-boolean v3, v2, Lt1/T;->H:Z

    if-nez v3, :cond_6b

    invoke-interface {v4}, LD1/J;->getDurationUs()J

    move-result-wide v7

    cmp-long v3, v7, v5

    if-nez v3, :cond_6b

    move v0, v1

    :cond_6b
    iput-boolean v0, v2, Lt1/T;->C:Z

    if-eqz v0, :cond_70

    const/4 v1, 0x7

    :cond_70
    iput v1, v2, Lt1/T;->D:I

    iget-boolean v0, v2, Lt1/T;->w:Z

    if-eqz v0, :cond_84

    iget-wide v0, v2, Lt1/T;->B:J

    invoke-interface {v4}, LD1/J;->g()Z

    move-result v3

    iget-boolean v4, v2, Lt1/T;->C:Z

    iget-object v2, v2, Lt1/T;->g:Lt1/W;

    invoke-virtual {v2, v0, v1, v3, v4}, Lt1/W;->w(JZZ)V

    goto :goto_87

    :cond_84
    invoke-virtual {v2}, Lt1/T;->z()V

    :goto_87
    return-void

    :pswitch_88
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lqc/c;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Lqc/b;

    iget-object v2, v0, Lqc/c;->c:Ljava/util/HashMap;

    monitor-enter v2

    :try_start_93
    iget-object v3, v0, Lqc/c;->c:Ljava/util/HashMap;

    iget-object v4, v1, Lqc/b;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a6

    invoke-virtual {v0, v1}, Lqc/c;->a(Lqc/b;)Z

    move-result v3

    if-nez v3, :cond_ab

    goto :goto_a6

    :catchall_a4
    move-exception v0

    goto :goto_ad

    :cond_a6
    :goto_a6
    iget-object v0, v0, Lqc/c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_ab
    monitor-exit v2

    return-void

    :goto_ad
    monitor-exit v2
    :try_end_ae
    .catchall {:try_start_93 .. :try_end_ae} :catchall_a4

    throw v0

    :pswitch_af
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/cache/f;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    const-string v2, "transaction.json"

    if-nez v1, :cond_c3

    iget-object v0, v0, Lio/sentry/cache/f;->a:Lio/sentry/M1;

    const-string v1, ".scope-cache"

    invoke-static {v0, v1, v2}, Lio/sentry/cache/a;->a(Lio/sentry/M1;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_c6

    :cond_c3
    invoke-virtual {v0, v1, v2}, Lio/sentry/cache/f;->i(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_c6
    return-void

    :pswitch_c7
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lq5/b;

    iget-object v0, v0, Lq5/b;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/core/app/FrameMetricsAggregator;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Landroid/app/Activity;

    invoke-virtual {v0, v1}, Landroidx/core/app/FrameMetricsAggregator;->a(Landroid/app/Activity;)V

    return-void

    :pswitch_d7
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/internal/debugmeta/c;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v1, LZ0/F;->a:I

    iget-object v0, v0, Lio/sentry/internal/debugmeta/c;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/I;

    iget-object v0, v0, Landroidx/media3/exoplayer/I;->a:Landroidx/media3/exoplayer/L;

    iget-object v0, v0, Landroidx/media3/exoplayer/L;->r:Lg1/q;

    invoke-virtual {v0}, Lg1/q;->S()Lg1/a;

    move-result-object v1

    new-instance v2, LMa/n;

    iget-object v3, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Exception;

    invoke-direct {v2, v1, v3}, LMa/n;-><init>(Lg1/a;Ljava/lang/Exception;)V

    const/16 v3, 0x405

    invoke-virtual {v0, v1, v3, v2}, Lg1/q;->T(Lg1/a;ILZ0/m;)V

    return-void

    :pswitch_fb
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/perf/session/gauges/MemoryGaugeCollector;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/perf/util/Timer;

    invoke-static {v0, v1}, Lcom/google/firebase/perf/session/gauges/MemoryGaugeCollector;->b(Lcom/google/firebase/perf/session/gauges/MemoryGaugeCollector;Lcom/google/firebase/perf/util/Timer;)V

    return-void

    :pswitch_107
    iget-object v1, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    const-string v2, "$context"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v2, LIe/i;

    const-string v3, "this$0"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v2, LIe/i;->b:Ljava/lang/Object;

    check-cast v2, Lx9/o;

    const-string v3, "sdkInstance"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lm7/A;->u(Lx9/o;)Z

    invoke-static {v1, v2}, Lm7/A;->z(Landroid/content/Context;Lx9/o;)V

    invoke-static {v1, v2}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object v1

    invoke-virtual {v1, v0}, LK9/b;->N(Z)V

    return-void

    :pswitch_130
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, Lapp/notifee/core/database/a;

    iget-object v0, v0, Lapp/notifee/core/database/a;->a:Lte/o;

    iget-object v2, v0, Lte/o;->a:Ljava/lang/Object;

    check-cast v2, Ls2/k;

    invoke-virtual {v2}, Ls2/k;->b()V

    iget-object v0, v0, Lte/o;->e:Ljava/lang/Object;

    check-cast v0, Lte/n;

    invoke-virtual {v0}, LP8/f;->a()Lz2/j;

    move-result-object v3

    iget-object v4, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    if-nez v4, :cond_14f

    invoke-interface {v3, v1}, Ly2/d;->S(I)V

    goto :goto_152

    :cond_14f
    invoke-interface {v3, v1, v4}, Ly2/d;->o(ILjava/lang/String;)V

    :goto_152
    invoke-virtual {v2}, Ls2/k;->c()V

    :try_start_155
    invoke-virtual {v3}, Lz2/j;->f()I

    invoke-virtual {v2}, Ls2/k;->o()V
    :try_end_15b
    .catchall {:try_start_155 .. :try_end_15b} :catchall_162

    invoke-virtual {v2}, Ls2/k;->j()V

    invoke-virtual {v0, v3}, LP8/f;->d(Lz2/j;)V

    return-void

    :catchall_162
    move-exception v1

    invoke-virtual {v2}, Ls2/k;->j()V

    invoke-virtual {v0, v3}, LP8/f;->d(Lz2/j;)V

    throw v1

    :pswitch_16a
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, LZ0/u;

    invoke-virtual {v0}, LZ0/u;->c()I

    move-result v0

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Ly1/q;

    invoke-virtual {v1, v0}, Ly1/q;->a(I)V

    return-void

    :pswitch_17a
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, LFa/f;

    const-string v1, "$listener"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Lca/a;

    const-string v2, "$data"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v0, LFa/f;->b:Lcom/facebook/react/bridge/Promise;

    invoke-static {v0, v1}, Lcom/moengage/react/MoEReactBridge;->b(Lcom/facebook/react/bridge/Promise;Lca/a;)V

    return-void

    :pswitch_192
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, LO2/F;

    iget-object v2, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v2, Ln8/r;

    iget-object v0, v0, LO2/F;->q:LY2/k;

    iget-object v0, v0, LY2/i;->a:Ljava/lang/Object;

    instance-of v0, v0, LY2/a;

    if-eqz v0, :cond_1a5

    invoke-interface {v2, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_1a5
    return-void

    :pswitch_1a6
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, LC/F0;

    invoke-virtual {v0}, LC/F0;->e()V

    iget-object v0, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v0, LC/F0;

    if-eqz v0, :cond_1b6

    invoke-virtual {v0}, LC/F0;->e()V

    :cond_1b6
    return-void

    :pswitch_1b7
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, LW2/p;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v1, LZ0/F;->a:I

    iget-object v0, v0, LW2/p;->c:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/I;

    iget-object v0, v0, Landroidx/media3/exoplayer/I;->a:Landroidx/media3/exoplayer/L;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, LW0/e0;

    iput-object v1, v0, Landroidx/media3/exoplayer/L;->h0:LW0/e0;

    new-instance v2, LD/C;

    const/4 v3, 0x5

    invoke-direct {v2, v3, v1}, LD/C;-><init>(ILjava/lang/Object;)V

    const/16 v1, 0x19

    iget-object v0, v0, Landroidx/media3/exoplayer/L;->m:LZ0/p;

    invoke-virtual {v0, v1, v2}, LZ0/p;->f(ILZ0/m;)V

    return-void

    :pswitch_1da
    iget-object v0, p0, LB/e;->b:Ljava/lang/Object;

    check-cast v0, LB/g;

    iget-object v1, p0, LB/e;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/concurrent/futures/k;

    invoke-virtual {v0, v1}, LB/g;->b(Landroidx/concurrent/futures/k;)V

    return-void

    :pswitch_data_1e6
    .packed-switch 0x0
        :pswitch_1da
        :pswitch_1b7
        :pswitch_1a6
        :pswitch_192
        :pswitch_17a
        :pswitch_16a
        :pswitch_130
        :pswitch_107
        :pswitch_fb
        :pswitch_d7
        :pswitch_c7
        :pswitch_af
        :pswitch_88
        :pswitch_3e
        :pswitch_32
        :pswitch_23
        :pswitch_15
    .end packed-switch
.end method
