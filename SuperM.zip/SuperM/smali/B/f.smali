.class public final synthetic LB/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, LB/f;->a:I

    iput-object p2, p0, LB/f;->b:Ljava/lang/Object;

    iput-object p3, p0, LB/f;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LB1/i;LB1/L;LW0/e0;)V
    .registers 4

    const/4 p3, 0x1

    iput p3, p0, LB/f;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB/f;->b:Ljava/lang/Object;

    iput-object p2, p0, LB/f;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 18

    move-object/from16 v1, p0

    const/4 v0, 0x5

    const/4 v2, -0x1

    const/16 v3, 0xc

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget v8, v1, LB/f;->a:I

    packed-switch v8, :pswitch_data_3e8

    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lx/s;

    iget-object v0, v0, Lx/s;->b:Landroid/hardware/camera2/CameraManager$AvailabilityCallback;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v2}, Landroid/hardware/camera2/CameraManager$AvailabilityCallback;->onCameraUnavailable(Ljava/lang/String;)V

    return-void

    :pswitch_1d
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lx/j;

    iget-object v0, v0, Lx/j;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Landroid/hardware/camera2/CameraCaptureSession;

    invoke-virtual {v0, v2}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onReady(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void

    :pswitch_2b
    iget-object v0, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    iget-object v2, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v2, LX2/o;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_36
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_39
    .catchall {:try_start_36 .. :try_end_39} :catchall_3d

    invoke-virtual {v2}, LX2/o;->a()V

    return-void

    :catchall_3d
    move-exception v0

    move-object v3, v0

    invoke-virtual {v2}, LX2/o;->a()V

    throw v3

    :pswitch_43
    iget-object v0, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    iget-object v2, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v2, Lio/sentry/cache/f;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_4e
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_51
    .catchall {:try_start_4e .. :try_end_51} :catchall_52

    goto :goto_61

    :catchall_52
    move-exception v0

    move-object v3, v0

    iget-object v0, v2, Lio/sentry/cache/f;->a:Lio/sentry/M1;

    invoke-virtual {v0}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object v0

    sget-object v2, Lio/sentry/y1;->ERROR:Lio/sentry/y1;

    const-string v4, "Serialization task failed"

    invoke-interface {v0, v2, v4, v3}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_61
    return-void

    :pswitch_62
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/l;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Lio/sentry/Q;

    invoke-virtual {v0, v2}, Lio/sentry/l;->c(Lio/sentry/Q;)Ljava/util/List;

    return-void

    :pswitch_6e
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, LA1/b;

    iget-object v0, v0, LA1/b;->b:Ljava/lang/Object;

    check-cast v0, Lh1/T;

    iget-object v0, v0, Lh1/T;->z1:Lio/sentry/internal/debugmeta/c;

    iget-object v2, v0, Lio/sentry/internal/debugmeta/c;->a:Ljava/lang/Object;

    check-cast v2, Landroid/os/Handler;

    if-eqz v2, :cond_8a

    new-instance v4, LB1/K;

    iget-object v5, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v5, Lh1/t;

    invoke-direct {v4, v3, v0, v5}, LB1/K;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_8a
    return-void

    :pswitch_8b
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/internal/debugmeta/c;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v2, LZ0/F;->a:I

    iget-object v0, v0, Lio/sentry/internal/debugmeta/c;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/I;

    iget-object v0, v0, Landroidx/media3/exoplayer/I;->a:Landroidx/media3/exoplayer/L;

    iget-object v0, v0, Landroidx/media3/exoplayer/L;->r:Lg1/q;

    invoke-virtual {v0}, Lg1/q;->S()Lg1/a;

    move-result-object v2

    new-instance v3, LMa/g;

    iget-object v4, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Exception;

    invoke-direct {v3, v2, v4}, LMa/g;-><init>(Lg1/a;Ljava/lang/Exception;)V

    const/16 v4, 0x3f6

    invoke-virtual {v0, v2, v4, v3}, Lg1/q;->T(Lg1/a;ILZ0/m;)V

    return-void

    :pswitch_af
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lcom/supermoney/payments/reactnative/nativemodule/SystemBarModule;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Lcom/facebook/react/bridge/Promise;

    invoke-static {v0, v2}, Lcom/supermoney/payments/reactnative/nativemodule/SystemBarModule;->d(Lcom/supermoney/payments/reactnative/nativemodule/SystemBarModule;Lcom/facebook/react/bridge/Promise;)V

    return-void

    :pswitch_bb
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/perf/session/gauges/CpuGaugeCollector;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Lcom/google/firebase/perf/util/Timer;

    invoke-static {v0, v2}, Lcom/google/firebase/perf/session/gauges/CpuGaugeCollector;->a(Lcom/google/firebase/perf/session/gauges/CpuGaugeCollector;Lcom/google/firebase/perf/util/Timer;)V

    return-void

    :pswitch_c7
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/perf/config/DeviceCacheManager;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Landroid/content/Context;

    invoke-static {v0, v2}, Lcom/google/firebase/perf/config/DeviceCacheManager;->a(Lcom/google/firebase/perf/config/DeviceCacheManager;Landroid/content/Context;)V

    return-void

    :pswitch_d3
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Lcom/google/firebase/crashlytics/internal/settings/SettingsProvider;

    invoke-static {v0, v2}, Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;->j(Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;Lcom/google/firebase/crashlytics/internal/settings/SettingsProvider;)V

    return-void

    :pswitch_df
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    const-string v2, "$context"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Lc9/s;

    const-string v8, "this$0"

    invoke-static {v2, v8}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v8, LO4/d;

    invoke-direct {v8, v5}, LO4/d;-><init>(I)V

    iget-object v2, v2, Lc9/s;->a:Lx9/o;

    const-string v9, "sdkInstance"

    invoke-static {v2, v9}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v9, v2, Lx9/o;->d:Lw9/g;

    :try_start_ff
    new-instance v10, LAa/r;

    const/16 v11, 0xa

    invoke-direct {v10, v11, v8}, LAa/r;-><init>(ILjava/lang/Object;)V

    invoke-static {v9, v7, v10, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    iget-object v10, v2, Lx9/o;->b:Lr9/a;

    iget-object v10, v10, Lr9/a;->a:Ljava/lang/String;

    invoke-static {v10}, LZd/q;->o(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_120

    new-instance v0, LAd/d;

    const/16 v2, 0x9

    invoke-direct {v0, v2, v8}, LAd/d;-><init>(ILjava/lang/Object;)V

    invoke-static {v9, v7, v0, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    goto :goto_15f

    :catchall_11e
    move-exception v0

    goto :goto_146

    :cond_120
    new-instance v10, LAa/i;

    invoke-direct {v10, v3, v8}, LAa/i;-><init>(ILjava/lang/Object;)V

    invoke-static {v9, v7, v10, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-static {v0, v2}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object v3

    invoke-virtual {v3}, LK9/b;->B0()Z

    move-result v3

    if-eqz v3, :cond_15f

    invoke-virtual {v8, v0, v2}, LO4/d;->i(Landroid/content/Context;Lx9/o;)LJ9/a;

    move-result-object v0

    iput-object v0, v2, Lx9/o;->c:LJ9/a;

    sget v2, Lg9/c;->a:I
    :try_end_13a
    .catchall {:try_start_ff .. :try_end_13a} :catchall_11e

    :try_start_13a
    iget-object v0, v0, LJ9/a;->b:LA/b;

    iget-boolean v0, v0, LA/b;->b:Z
    :try_end_13e
    .catchall {:try_start_13a .. :try_end_13e} :catchall_13f

    goto :goto_15f

    :catchall_13f
    move-exception v0

    :try_start_140
    sget-object v2, Lg9/b;->a:Lg9/b;

    invoke-virtual {v9, v6, v0, v2}, Lw9/g;->a(ILjava/lang/Throwable;LHc/a;)V
    :try_end_145
    .catchall {:try_start_140 .. :try_end_145} :catchall_11e

    goto :goto_15f

    :goto_146
    instance-of v2, v0, Ln9/b;

    if-eqz v2, :cond_155

    new-instance v0, LAa/a;

    const/16 v2, 0xb

    invoke-direct {v0, v2, v8}, LAa/a;-><init>(ILjava/lang/Object;)V

    invoke-static {v9, v6, v0, v5}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    goto :goto_15f

    :cond_155
    new-instance v2, LAa/b;

    const/16 v3, 0xd

    invoke-direct {v2, v3, v8}, LAa/b;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v9, v6, v0, v2}, Lw9/g;->a(ILjava/lang/Throwable;LHc/a;)V

    :cond_15f
    :goto_15f
    return-void

    :pswitch_160
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    const-string v2, "$context"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, LIe/i;

    const-string v3, "this$0"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v2, LIe/i;->b:Ljava/lang/Object;

    check-cast v2, Lx9/o;

    const-string v3, "sdkInstance"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lm7/A;->u(Lx9/o;)Z

    invoke-static {v0, v2}, Lm7/A;->z(Landroid/content/Context;Lx9/o;)V

    invoke-static {v0, v2}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object v0

    invoke-virtual {v0, v6}, LK9/b;->r0(Z)V

    return-void

    :pswitch_189
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    move-object v8, v0

    check-cast v8, Landroidx/media3/exoplayer/L;

    iget-object v0, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/O;

    iget v3, v8, Landroidx/media3/exoplayer/L;->H:I

    iget v4, v0, Landroidx/media3/exoplayer/O;->c:I

    sub-int/2addr v3, v4

    iput v3, v8, Landroidx/media3/exoplayer/L;->H:I

    iget-boolean v4, v0, Landroidx/media3/exoplayer/O;->d:Z

    if-eqz v4, :cond_1a3

    iget v4, v0, Landroidx/media3/exoplayer/O;->e:I

    iput v4, v8, Landroidx/media3/exoplayer/L;->I:I

    iput-boolean v6, v8, Landroidx/media3/exoplayer/L;->J:Z

    :cond_1a3
    if-nez v3, :cond_25b

    iget-object v3, v0, Landroidx/media3/exoplayer/O;->b:Landroidx/media3/exoplayer/l0;

    iget-object v3, v3, Landroidx/media3/exoplayer/l0;->a:LW0/V;

    iget-object v4, v8, Landroidx/media3/exoplayer/L;->j0:Landroidx/media3/exoplayer/l0;

    iget-object v4, v4, Landroidx/media3/exoplayer/l0;->a:LW0/V;

    invoke-virtual {v4}, LW0/V;->q()Z

    move-result v4

    if-nez v4, :cond_1bf

    invoke-virtual {v3}, LW0/V;->q()Z

    move-result v4

    if-eqz v4, :cond_1bf

    iput v2, v8, Landroidx/media3/exoplayer/L;->k0:I

    const-wide/16 v4, 0x0

    iput-wide v4, v8, Landroidx/media3/exoplayer/L;->l0:J

    :cond_1bf
    invoke-virtual {v3}, LW0/V;->q()Z

    move-result v2

    if-nez v2, :cond_1f9

    move-object v2, v3

    check-cast v2, Landroidx/media3/exoplayer/q0;

    iget-object v2, v2, Landroidx/media3/exoplayer/q0;->h:[LW0/V;

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v4

    iget-object v5, v8, Landroidx/media3/exoplayer/L;->p:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ne v4, v5, :cond_1dc

    move v4, v6

    goto :goto_1dd

    :cond_1dc
    move v4, v7

    :goto_1dd
    invoke-static {v4}, Lm7/u;->e(Z)V

    move v4, v7

    :goto_1e1
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_1f9

    iget-object v5, v8, Landroidx/media3/exoplayer/L;->p:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/media3/exoplayer/K;

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LW0/V;

    iput-object v9, v5, Landroidx/media3/exoplayer/K;->b:LW0/V;

    add-int/2addr v4, v6

    goto :goto_1e1

    :cond_1f9
    iget-boolean v2, v8, Landroidx/media3/exoplayer/L;->J:Z

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    if-eqz v2, :cond_24c

    iget-object v2, v0, Landroidx/media3/exoplayer/O;->b:Landroidx/media3/exoplayer/l0;

    iget-object v2, v2, Landroidx/media3/exoplayer/l0;->b:Lt1/E;

    iget-object v9, v8, Landroidx/media3/exoplayer/L;->j0:Landroidx/media3/exoplayer/l0;

    iget-object v9, v9, Landroidx/media3/exoplayer/l0;->b:Lt1/E;

    invoke-virtual {v2, v9}, Lt1/E;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21e

    iget-object v2, v0, Landroidx/media3/exoplayer/O;->b:Landroidx/media3/exoplayer/l0;

    iget-wide v9, v2, Landroidx/media3/exoplayer/l0;->d:J

    iget-object v2, v8, Landroidx/media3/exoplayer/L;->j0:Landroidx/media3/exoplayer/l0;

    iget-wide v11, v2, Landroidx/media3/exoplayer/l0;->s:J

    cmp-long v2, v9, v11

    if-eqz v2, :cond_21d

    goto :goto_21e

    :cond_21d
    move v6, v7

    :cond_21e
    :goto_21e
    if-eqz v6, :cond_249

    invoke-virtual {v3}, LW0/V;->q()Z

    move-result v2

    if-nez v2, :cond_242

    iget-object v2, v0, Landroidx/media3/exoplayer/O;->b:Landroidx/media3/exoplayer/l0;

    iget-object v2, v2, Landroidx/media3/exoplayer/l0;->b:Lt1/E;

    invoke-virtual {v2}, Lt1/E;->b()Z

    move-result v2

    if-eqz v2, :cond_231

    goto :goto_242

    :cond_231
    iget-object v2, v0, Landroidx/media3/exoplayer/O;->b:Landroidx/media3/exoplayer/l0;

    iget-object v4, v2, Landroidx/media3/exoplayer/l0;->b:Lt1/E;

    iget-wide v9, v2, Landroidx/media3/exoplayer/l0;->d:J

    iget-object v2, v4, Lt1/E;->a:Ljava/lang/Object;

    iget-object v4, v8, Landroidx/media3/exoplayer/L;->o:LW0/T;

    invoke-virtual {v3, v2, v4}, LW0/V;->h(Ljava/lang/Object;LW0/T;)LW0/T;

    iget-wide v2, v4, LW0/T;->e:J

    add-long/2addr v9, v2

    goto :goto_246

    :cond_242
    :goto_242
    iget-object v2, v0, Landroidx/media3/exoplayer/O;->b:Landroidx/media3/exoplayer/l0;

    iget-wide v9, v2, Landroidx/media3/exoplayer/l0;->d:J

    :goto_246
    move v11, v6

    move-wide v13, v9

    goto :goto_24e

    :cond_249
    move-wide v13, v4

    move v11, v6

    goto :goto_24e

    :cond_24c
    move-wide v13, v4

    move v11, v7

    :goto_24e
    iput-boolean v7, v8, Landroidx/media3/exoplayer/L;->J:Z

    iget-object v9, v0, Landroidx/media3/exoplayer/O;->b:Landroidx/media3/exoplayer/l0;

    iget v12, v8, Landroidx/media3/exoplayer/L;->I:I

    const/16 v16, 0x0

    const/4 v10, 0x1

    const/4 v15, -0x1

    invoke-virtual/range {v8 .. v16}, Landroidx/media3/exoplayer/L;->Y(Landroidx/media3/exoplayer/l0;IZIJIZ)V

    :cond_25b
    return-void

    :pswitch_25c
    iget-object v0, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/bridge/ReactApplicationContext;

    check-cast v0, Lcom/facebook/react/bridge/BridgeReactContext;

    iget-object v2, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v2, Lcom/facebook/react/ReactInstanceManager;

    invoke-static {v2, v0}, Lcom/facebook/react/ReactInstanceManager;->c(Lcom/facebook/react/ReactInstanceManager;Lcom/facebook/react/bridge/BridgeReactContext;)V

    return-void

    :pswitch_26a
    iget-object v3, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v3, Lx9/o;

    iget-object v8, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v8, LAc/f;

    const-string v9, "$instance"

    invoke-static {v3, v9}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v9, "this$0"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v9, v3, Lx9/o;->d:Lw9/g;

    new-instance v10, LAa/i;

    invoke-direct {v10, v0, v8}, LAa/i;-><init>(ILjava/lang/Object;)V

    invoke-static {v9, v7, v10, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    iget-object v9, v8, LAc/f;->c:Ljava/lang/Object;

    check-cast v9, Ljava/lang/String;

    const-string v10, "action_progress_update"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_327

    iget-object v2, v8, LAc/f;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/Context;

    iget-object v9, v8, LAc/f;->d:Ljava/lang/Object;

    check-cast v9, Landroid/os/Bundle;

    iget-object v10, v3, Lx9/o;->d:Lw9/g;

    new-instance v11, LAa/b;

    invoke-direct {v11, v0, v8}, LAa/b;-><init>(ILjava/lang/Object;)V

    invoke-static {v10, v7, v11, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    const-string v0, "gcm_campaign_id"

    invoke-virtual {v9, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, v3}, LAc/f;->v(Landroid/content/Context;Ljava/lang/String;Lx9/o;)Landroid/os/Bundle;

    move-result-object v0

    if-nez v0, :cond_2b2

    goto/16 :goto_3c0

    :cond_2b2
    invoke-static {v9}, Ll7/e6;->g(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v10

    iget-object v11, v3, Lx9/o;->d:Lw9/g;

    new-instance v12, LFa/a;

    invoke-direct {v12, v5, v8, v10}, LFa/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v11, v7, v12, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-static {v10}, LZd/q;->o(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_2c8

    goto/16 :goto_3c0

    :cond_2c8
    const-string v11, "notification"

    invoke-virtual {v2, v11}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v11

    const-string v12, "null cannot be cast to non-null type android.app.NotificationManager"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v11, Landroid/app/NotificationManager;

    invoke-virtual {v11}, Landroid/app/NotificationManager;->getActiveNotifications()[Landroid/service/notification/StatusBarNotification;

    move-result-object v11

    const-string v12, "notificationManager.activeNotifications"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v12, v11

    move v13, v7

    :goto_2e0
    if-ge v13, v12, :cond_2f1

    aget-object v14, v11, v13

    invoke-virtual {v14}, Landroid/service/notification/StatusBarNotification;->getTag()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15, v10}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_2ef

    goto :goto_2f2

    :cond_2ef
    add-int/2addr v13, v6

    goto :goto_2e0

    :cond_2f1
    const/4 v14, 0x0

    :goto_2f2
    if-eqz v14, :cond_318

    const-string v3, "moe_re_notify"

    invoke-virtual {v0, v3, v6}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    sget-object v3, Lsa/w;->b:Lsa/w;

    if-nez v3, :cond_313

    const-class v3, Lsa/w;

    monitor-enter v3

    :try_start_300
    sget-object v4, Lsa/w;->b:Lsa/w;

    if-nez v4, :cond_30c

    new-instance v4, Lsa/w;

    invoke-direct {v4, v7}, Lsa/w;-><init>(Z)V

    goto :goto_30c

    :catchall_30a
    move-exception v0

    goto :goto_311

    :cond_30c
    :goto_30c
    sput-object v4, Lsa/w;->b:Lsa/w;
    :try_end_30e
    .catchall {:try_start_300 .. :try_end_30e} :catchall_30a

    monitor-exit v3

    move-object v3, v4

    goto :goto_313

    :goto_311
    monitor-exit v3

    throw v0

    :cond_313
    :goto_313
    invoke-virtual {v3, v2, v0}, Lsa/w;->h(Landroid/content/Context;Landroid/os/Bundle;)V

    goto/16 :goto_3c0

    :cond_318
    iget-object v0, v3, Lx9/o;->d:Lw9/g;

    new-instance v6, LE0/a;

    invoke-direct {v6, v5, v8, v10}, LE0/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v0, v7, v6, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-static {v2, v9, v3}, Ll7/p1;->b(Landroid/content/Context;Landroid/os/Bundle;Lx9/o;)V

    goto/16 :goto_3c0

    :cond_327
    const-string v0, "action_timer_on_expiry"

    invoke-static {v9, v0}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c0

    iget-object v0, v8, LAc/f;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v5, v8, LAc/f;->d:Ljava/lang/Object;

    check-cast v5, Landroid/os/Bundle;

    iget-object v6, v3, Lx9/o;->d:Lw9/g;

    new-instance v9, LAa/e;

    invoke-direct {v9, v4, v8}, LAa/e;-><init>(ILjava/lang/Object;)V

    invoke-static {v6, v7, v9, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    const-string v6, "displayName"

    invoke-virtual {v5, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_34b

    goto/16 :goto_3c0

    :cond_34b
    const-string v9, "gcm_campaign_id"

    invoke-virtual {v5, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v0, v9, v3}, LAc/f;->v(Landroid/content/Context;Ljava/lang/String;Lx9/o;)Landroid/os/Bundle;

    move-result-object v9

    if-nez v9, :cond_358

    goto :goto_3c0

    :cond_358
    invoke-static {v0, v5, v3}, Ll7/p1;->b(Landroid/content/Context;Landroid/os/Bundle;Lx9/o;)V

    invoke-static {v9}, Ll7/e6;->g(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v5

    iget-object v10, v3, Lx9/o;->d:Lw9/g;

    new-instance v11, LGa/b;

    invoke-direct {v11, v7, v8, v5, v6}, LGa/b;-><init>(ILjava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v10, v7, v11, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-static {v5}, LZd/q;->o(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_370

    goto :goto_3c0

    :cond_370
    iget-object v5, v3, Lx9/o;->d:Lw9/g;

    sget-object v8, LGa/j;->b:LGa/j;

    invoke-static {v5, v7, v8, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    const-string v5, "moe_template_meta"

    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    const-string v10, "templateName"

    invoke-virtual {v8, v10, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v6, "cardId"

    invoke-virtual {v8, v6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v6, "widgetId"

    invoke-virtual {v8, v6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    invoke-static {v8}, Lcom/newrelic/agent/android/instrumentation/JSONObjectInstrumentation;->toString(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v2

    const-string v6, "templateTrackingMetaToJson(meta).toString()"

    invoke-static {v2, v6}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v9, v5, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v2, Lsa/w;->b:Lsa/w;

    if-nez v2, :cond_3b3

    const-class v2, Lsa/w;

    monitor-enter v2

    :try_start_3a0
    sget-object v5, Lsa/w;->b:Lsa/w;

    if-nez v5, :cond_3ac

    new-instance v5, Lsa/w;

    invoke-direct {v5, v7}, Lsa/w;-><init>(Z)V

    goto :goto_3ac

    :catchall_3aa
    move-exception v0

    goto :goto_3b1

    :cond_3ac
    :goto_3ac
    sput-object v5, Lsa/w;->b:Lsa/w;
    :try_end_3ae
    .catchall {:try_start_3a0 .. :try_end_3ae} :catchall_3aa

    monitor-exit v2

    move-object v2, v5

    goto :goto_3b3

    :goto_3b1
    monitor-exit v2

    throw v0

    :cond_3b3
    :goto_3b3
    new-instance v5, Lsa/u;

    invoke-direct {v5, v2, v7}, Lsa/u;-><init>(Lsa/w;I)V

    iget-object v2, v3, Lx9/o;->d:Lw9/g;

    invoke-static {v2, v7, v5, v4}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-static {v0, v3, v9, v7}, Ll7/e6;->e(Landroid/content/Context;Lx9/o;Landroid/os/Bundle;Z)V

    :cond_3c0
    :goto_3c0
    return-void

    :pswitch_3c1
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, LN/h;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, LC/i;

    invoke-virtual {v0, v2}, LN/h;->a(LC/i;)V

    return-void

    :pswitch_3cd
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, LB1/i;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v0, LB1/L;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_3dc
    iget-object v0, v1, LB/f;->b:Ljava/lang/Object;

    check-cast v0, LB/g;

    iget-object v2, v1, LB/f;->c:Ljava/lang/Object;

    check-cast v2, Landroidx/concurrent/futures/k;

    invoke-virtual {v0, v2}, LB/g;->b(Landroidx/concurrent/futures/k;)V

    return-void

    :pswitch_data_3e8
    .packed-switch 0x0
        :pswitch_3dc
        :pswitch_3cd
        :pswitch_3c1
        :pswitch_26a
        :pswitch_25c
        :pswitch_189
        :pswitch_160
        :pswitch_df
        :pswitch_d3
        :pswitch_c7
        :pswitch_bb
        :pswitch_af
        :pswitch_8b
        :pswitch_6e
        :pswitch_62
        :pswitch_43
        :pswitch_2b
        :pswitch_1d
    .end packed-switch
.end method
