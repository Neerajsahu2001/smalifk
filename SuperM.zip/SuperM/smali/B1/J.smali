.class public final LB1/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final m:LB1/a;


# instance fields
.field public final a:LB1/i;

.field public final b:LB1/w;

.field public final c:LB1/B;

.field public final d:LB1/f;

.field public final e:LZ0/y;

.field public final f:Ljava/util/concurrent/CopyOnWriteArraySet;

.field public g:Landroidx/media3/common/b;

.field public h:LB1/u;

.field public i:LZ0/A;

.field public j:Landroid/util/Pair;

.field public k:I

.field public l:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LB1/a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LB1/j;->m:LB1/a;

    return-void
.end method

.method public constructor <init>(LB1/c;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p1, LB1/c;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    new-instance v1, LB1/i;

    invoke-direct {v1, p0, v0}, LB1/i;-><init>(LB1/j;Landroid/content/Context;)V

    iput-object v1, p0, LB1/j;->a:LB1/i;

    iget-object v0, p1, LB1/c;->f:Ljava/lang/Object;

    check-cast v0, LZ0/y;

    iput-object v0, p0, LB1/j;->e:LZ0/y;

    iget-object v2, p1, LB1/c;->c:Ljava/lang/Object;

    check-cast v2, LB1/w;

    iput-object v2, p0, LB1/j;->b:LB1/w;

    iput-object v0, v2, LB1/w;->l:LZ0/y;

    new-instance v0, LB1/B;

    new-instance v3, LA0/x;

    const/4 v4, 0x1

    invoke-direct {v3, v4, p0}, LA0/x;-><init>(ILjava/lang/Object;)V

    invoke-direct {v0, v3, v2}, LB1/B;-><init>(LA0/x;LB1/w;)V

    iput-object v0, p0, LB1/j;->c:LB1/B;

    iget-object p1, p1, LB1/c;->e:Ljava/lang/Object;

    check-cast p1, LB1/f;

    invoke-static {p1}, Lm7/u;->g(Ljava/lang/Object;)V

    iput-object p1, p0, LB1/j;->d:LB1/f;

    new-instance p1, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {p1}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    iput-object p1, p0, LB1/j;->f:Ljava/util/concurrent/CopyOnWriteArraySet;

    const/4 v0, 0x0

    iput v0, p0, LB1/j;->l:I

    invoke-virtual {p1, v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    return-void
.end method


# virtual methods
.method public final a(JJ)V
    .registers 27

    move-object/from16 v1, p0

    iget v0, v1, LB1/j;->k:I

    if-nez v0, :cond_198

    iget-object v0, v1, LB1/j;->c:LB1/B;

    iget-object v2, v0, LB1/B;->f:LA8/J;

    iget v3, v2, LA8/J;->b:I

    if-nez v3, :cond_10

    goto/16 :goto_198

    :cond_10
    if-eqz v3, :cond_192

    iget-object v3, v2, LA8/J;->d:Ljava/io/Serializable;

    check-cast v3, [J

    iget v4, v2, LA8/J;->a:I

    aget-wide v14, v3, v4

    iget-object v3, v0, LB1/B;->e:LZ0/B;

    monitor-enter v3

    const/4 v4, 0x1

    :try_start_1e
    invoke-virtual {v3, v14, v15, v4}, LZ0/B;->d(JZ)Ljava/lang/Object;

    move-result-object v5
    :try_end_22
    .catchall {:try_start_1e .. :try_end_22} :catchall_18e

    monitor-exit v3

    check-cast v5, Ljava/lang/Long;

    iget-object v3, v0, LB1/B;->b:LB1/w;

    const/4 v12, 0x2

    if-eqz v5, :cond_3d

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    iget-wide v8, v0, LB1/B;->i:J

    cmp-long v6, v6, v8

    if-eqz v6, :cond_3d

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    iput-wide v5, v0, LB1/B;->i:J

    invoke-virtual {v3, v12}, LB1/w;->c(I)V

    :cond_3d
    iget-wide v10, v0, LB1/B;->i:J

    iget-object v13, v0, LB1/B;->c:LB1/v;

    iget-object v5, v0, LB1/B;->b:LB1/w;

    const/16 v16, 0x0

    move-wide v6, v14

    move-wide/from16 v8, p1

    move-wide/from16 v17, v10

    move-wide/from16 v10, p3

    move-object/from16 v19, v13

    move-wide/from16 v12, v17

    move-wide/from16 v20, v14

    move/from16 v14, v16

    move-object/from16 v15, v19

    invoke-virtual/range {v5 .. v15}, LB1/w;->a(JJJJZLB1/v;)I

    move-result v5

    iget-object v6, v0, LB1/B;->a:LA0/x;

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v5, :cond_a8

    if-eq v5, v4, :cond_a8

    const/4 v9, 0x2

    if-eq v5, v9, :cond_79

    if-eq v5, v7, :cond_79

    const/4 v3, 0x4

    if-eq v5, v3, :cond_79

    const/4 v0, 0x5

    if-ne v5, v0, :cond_6f

    goto/16 :goto_198

    :cond_6f
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_79
    move-wide/from16 v9, v20

    iput-wide v9, v0, LB1/B;->j:J

    invoke-virtual {v2}, LA8/J;->a()J

    iget-object v0, v6, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, LB1/j;

    iget-object v0, v0, LB1/j;->f:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_a4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LB1/i;

    iget-object v3, v2, LB1/i;->j:LB1/L;

    iget-object v4, v2, LB1/i;->k:Ljava/util/concurrent/Executor;

    new-instance v5, LB1/g;

    const/4 v6, 0x0

    invoke-direct {v5, v6, v2, v3}, LB1/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v4, v5}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_8a

    :cond_a4
    invoke-static {v8}, Lm7/u;->g(Ljava/lang/Object;)V

    throw v8

    :cond_a8
    move-wide/from16 v9, v20

    iput-wide v9, v0, LB1/B;->j:J

    const/4 v9, 0x0

    if-nez v5, :cond_b1

    move v5, v4

    goto :goto_b2

    :cond_b1
    move v5, v9

    :goto_b2
    invoke-virtual {v2}, LA8/J;->a()J

    move-result-wide v11

    iget-object v2, v0, LB1/B;->d:LZ0/B;

    monitor-enter v2

    :try_start_b9
    invoke-virtual {v2, v11, v12, v4}, LZ0/B;->d(JZ)Ljava/lang/Object;

    move-result-object v10
    :try_end_bd
    .catchall {:try_start_b9 .. :try_end_bd} :catchall_18a

    monitor-exit v2

    check-cast v10, LW0/e0;

    if-nez v10, :cond_c3

    goto :goto_118

    :cond_c3
    sget-object v2, LW0/e0;->e:LW0/e0;

    invoke-virtual {v10, v2}, LW0/e0;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_118

    iget-object v2, v0, LB1/B;->h:LW0/e0;

    invoke-virtual {v10, v2}, LW0/e0;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_118

    iput-object v10, v0, LB1/B;->h:LW0/e0;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, LW0/o;

    invoke-direct {v2}, LW0/o;-><init>()V

    iget v13, v10, LW0/e0;->a:I

    iput v13, v2, LW0/o;->s:I

    iget v13, v10, LW0/e0;->b:I

    iput v13, v2, LW0/o;->t:I

    const-string v13, "video/raw"

    invoke-static {v13}, LW0/I;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    iput-object v13, v2, LW0/o;->m:Ljava/lang/String;

    new-instance v13, Landroidx/media3/common/b;

    invoke-direct {v13, v2}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    iget-object v2, v6, LA0/x;->b:Ljava/lang/Object;

    check-cast v2, LB1/j;

    iput-object v13, v2, LB1/j;->g:Landroidx/media3/common/b;

    iget-object v2, v2, LB1/j;->f:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_fe
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_118

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, LB1/i;

    iget-object v14, v13, LB1/i;->j:LB1/L;

    iget-object v15, v13, LB1/i;->k:Ljava/util/concurrent/Executor;

    new-instance v4, LB/f;

    invoke-direct {v4, v13, v14, v10}, LB/f;-><init>(LB1/i;LB1/L;LW0/e0;)V

    invoke-interface {v15, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v4, 0x1

    goto :goto_fe

    :cond_118
    :goto_118
    if-eqz v5, :cond_11b

    goto :goto_11f

    :cond_11b
    iget-object v0, v0, LB1/B;->c:LB1/v;

    iget-wide v4, v0, LB1/v;->b:J

    :goto_11f
    iget v0, v3, LB1/w;->e:I

    if-eq v0, v7, :cond_125

    const/4 v4, 0x1

    goto :goto_126

    :cond_125
    move v4, v9

    :goto_126
    iput v7, v3, LB1/w;->e:I

    iget-object v0, v3, LB1/w;->l:LZ0/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v9

    invoke-static {v9, v10}, LZ0/F;->Q(J)J

    move-result-wide v9

    iput-wide v9, v3, LB1/w;->g:J

    iget-object v0, v6, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, LB1/j;

    if-eqz v4, :cond_161

    iget-object v2, v0, LB1/j;->j:Landroid/util/Pair;

    if-eqz v2, :cond_161

    iget-object v2, v0, LB1/j;->f:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_147
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_161

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LB1/i;

    iget-object v4, v3, LB1/i;->j:LB1/L;

    iget-object v5, v3, LB1/i;->k:Ljava/util/concurrent/Executor;

    new-instance v6, LB1/h;

    const/4 v7, 0x0

    invoke-direct {v6, v7, v3, v4}, LB1/h;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v5, v6}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_147

    :cond_161
    iget-object v2, v0, LB1/j;->h:LB1/u;

    if-eqz v2, :cond_186

    iget-object v2, v0, LB1/j;->g:Landroidx/media3/common/b;

    if-nez v2, :cond_175

    new-instance v2, LW0/o;

    invoke-direct {v2}, LW0/o;-><init>()V

    new-instance v3, Landroidx/media3/common/b;

    invoke-direct {v3, v2}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    move-object v15, v3

    goto :goto_176

    :cond_175
    move-object v15, v2

    :goto_176
    iget-object v10, v0, LB1/j;->h:LB1/u;

    iget-object v0, v0, LB1/j;->e:LZ0/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v13

    const/16 v16, 0x0

    invoke-interface/range {v10 .. v16}, LB1/u;->c(JJLandroidx/media3/common/b;Landroid/media/MediaFormat;)V

    :cond_186
    invoke-static {v8}, Lm7/u;->g(Ljava/lang/Object;)V

    throw v8

    :catchall_18a
    move-exception v0

    move-object v3, v0

    monitor-exit v2

    throw v3

    :catchall_18e
    move-exception v0

    move-object v2, v0

    monitor-exit v3

    throw v2

    :cond_192
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0

    :cond_198
    :goto_198
    return-void
.end method
