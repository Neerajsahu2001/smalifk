.class public final LB1/l;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:LB1/k;

.field public b:LB1/k;

.field public c:Z

.field public d:J

.field public e:I
