.class public final synthetic LB1/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, LB1/h;->a:I

    iput-object p2, p0, LB1/h;->b:Ljava/lang/Object;

    iput-object p3, p0, LB1/h;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v3, p0, LB1/h;->a:I

    packed-switch v3, :pswitch_data_2be

    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lx/o;

    iget-object v0, v0, Lx/o;->a:Landroid/hardware/camera2/CameraDevice$StateCallback;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Landroid/hardware/camera2/CameraDevice;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraDevice$StateCallback;->onOpened(Landroid/hardware/camera2/CameraDevice;)V

    return-void

    :pswitch_16
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lw/j;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    iget-object v0, v0, Lw/j;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2a
    :goto_2a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_44

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lw/k;

    iget-object v4, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v4, Landroid/hardware/camera2/TotalCaptureResult;

    invoke-interface {v3, v4}, Lw/k;->a(Landroid/hardware/camera2/TotalCaptureResult;)Z

    move-result v4

    if-eqz v4, :cond_2a

    invoke-virtual {v1, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_2a

    :cond_44
    invoke-virtual {v1}, Ljava/util/HashSet;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_4d

    invoke-interface {v0, v1}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    :cond_4d
    return-void

    :pswitch_4e
    iget-object v3, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v3, Lx9/o;

    const-string v4, "$sdkInstance"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v4, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v4, Lee/j;

    const-string v5, "this$0"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_60
    sget-object v5, Lw9/g;->d:Lsa/x;

    new-instance v5, Lr9/i;

    invoke-direct {v5, v4, v2}, Lr9/i;-><init>(Lee/j;I)V

    invoke-static {v2, v5, v1}, LW4/c;->h(ILHc/a;I)V

    sget-object v1, Lp9/a;->a:Lx9/a;

    iget-object v1, v3, Lx9/o;->a:Lx9/h;

    iget-object v1, v1, Lx9/h;->a:Ljava/lang/String;

    const-string v2, "appId"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Lp9/a;->d:Ljava/util/LinkedHashMap;

    invoke-virtual {v2, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Le/b;->p(Ljava/lang/Object;)V
    :try_end_7e
    .catchall {:try_start_60 .. :try_end_7e} :catchall_7f

    goto :goto_8a

    :catchall_7f
    move-exception v1

    new-instance v2, Lr9/c;

    invoke-direct {v2, v4, v0}, Lr9/c;-><init>(Lee/j;I)V

    iget-object v3, v3, Lx9/o;->d:Lw9/g;

    invoke-virtual {v3, v0, v1, v2}, Lw9/g;->a(ILjava/lang/Throwable;LHc/a;)V

    :goto_8a
    return-void

    :pswitch_8b
    iget-object v1, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/profileinstaller/ProfileInstallerInitializer;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1c

    if-lt v1, v2, :cond_a1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v1}, Lq2/g;->a(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object v1

    goto :goto_aa

    :cond_a1
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    :goto_aa
    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/16 v3, 0x3e8

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {v2, v0}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    new-instance v2, LC/Z;

    iget-object v3, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    const/16 v4, 0x15

    invoke-direct {v2, v4, v3}, LC/Z;-><init>(ILjava/lang/Object;)V

    add-int/lit16 v0, v0, 0x1388

    int-to-long v3, v0

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :pswitch_cb
    const-string v0, "$job"

    iget-object v1, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v1, Lo9/a;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$onComplete"

    iget-object v2, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v2, LHc/b;

    invoke-static {v2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v1, Lo9/a;->c:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    invoke-interface {v2, v1}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :pswitch_e6
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lx9/o;

    const-string v3, "$sdkInstance"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    const-string v4, "$context"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lc9/u;->g(Lx9/o;)Ll9/k;

    move-result-object v0

    iget-object v4, v0, Ll9/k;->a:Lx9/o;

    iget-object v4, v4, Lx9/o;->d:Lw9/g;

    new-instance v5, Ll9/e;

    invoke-direct {v5, v0, v2}, Ll9/e;-><init>(Ll9/k;I)V

    invoke-static {v4, v2, v5, v1}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-virtual {v0, v3}, Ll9/k;->b(Landroid/content/Context;)V

    const/4 v1, 0x5

    invoke-virtual {v0, v3, v1}, Ll9/k;->e(Landroid/content/Context;I)V

    return-void

    :pswitch_110
    const-string v0, "replay.json"

    iget-object v1, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v1, Lio/sentry/cache/f;

    iget-object v2, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v2, Lio/sentry/protocol/y;

    invoke-virtual {v1, v2, v0}, Lio/sentry/cache/f;->i(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :pswitch_11e
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/internal/util/l;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_125
    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object v1

    iput-object v1, v0, Lio/sentry/android/core/internal/util/l;->j:Landroid/view/Choreographer;
    :try_end_12b
    .catchall {:try_start_125 .. :try_end_12b} :catchall_12c

    goto :goto_138

    :catchall_12c
    move-exception v0

    sget-object v1, Lio/sentry/y1;->ERROR:Lio/sentry/y1;

    const-string v2, "Error retrieving Choreographer instance. Slow and frozen frames will not be reported."

    iget-object v3, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v3, Lio/sentry/ILogger;

    invoke-interface {v3, v1, v2, v0}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_138
    return-void

    :pswitch_139
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lq5/b;

    iget-object v0, v0, Lq5/b;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/core/app/FrameMetricsAggregator;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Landroid/app/Activity;

    invoke-virtual {v0, v1}, Landroidx/core/app/FrameMetricsAggregator;->b(Landroid/app/Activity;)V

    return-void

    :pswitch_149
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Li9/j;

    const-string v3, "this$0"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    const-string v4, "$context"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v4, v0, Li9/j;->a:Lx9/o;

    iget-object v4, v4, Lx9/o;->d:Lw9/g;

    new-instance v5, Li9/g;

    invoke-direct {v5, v0, v2}, Li9/g;-><init>(Li9/j;I)V

    const/4 v2, 0x2

    invoke-static {v4, v1, v5, v2}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    invoke-virtual {v0, v3}, Li9/j;->e(Landroid/content/Context;)V

    return-void

    :pswitch_16c
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Ll7/j1;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Ll7/j1;->g(Landroid/graphics/Typeface;)V

    return-void

    :pswitch_178
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/swmansion/reanimated/layoutReanimation/SharedTransitionManager;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Landroid/view/ViewParent;

    invoke-static {v0, v1}, Lcom/swmansion/reanimated/layoutReanimation/SharedTransitionManager;->a(Lcom/swmansion/reanimated/layoutReanimation/SharedTransitionManager;Landroid/view/ViewParent;)V

    return-void

    :pswitch_184
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;->k(Lcom/supermoney/payments/camera/SumoCameraWithQrScannerImpl;Ljava/lang/String;)V

    return-void

    :pswitch_190
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/interop/rollouts/RolloutsStateSubscriber;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/remoteconfig/interop/rollouts/RolloutsState;

    invoke-static {v0, v1}, Lcom/google/firebase/remoteconfig/internal/rollouts/RolloutsStateSubscriptionsHandler;->b(Lcom/google/firebase/remoteconfig/interop/rollouts/RolloutsStateSubscriber;Lcom/google/firebase/remoteconfig/interop/rollouts/RolloutsState;)V

    return-void

    :pswitch_19c
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/crashlytics/internal/settings/SettingsProvider;

    invoke-static {v0, v1}, Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;->f(Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;Lcom/google/firebase/crashlytics/internal/settings/SettingsProvider;)V

    return-void

    :pswitch_1a8
    iget-object v0, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Exception;

    check-cast v0, LK5/x;

    iget-object v1, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/devsupport/DevSupportManagerBase;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2, v0}, Lcom/facebook/react/devsupport/DevSupportManagerBase;->showNewJavaError(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void

    :pswitch_1bd
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    const-string v1, "$context"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, LIe/i;

    const-string v3, "this$0"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v1, LIe/i;->b:Ljava/lang/Object;

    check-cast v1, Lx9/o;

    const-string v3, "sdkInstance"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Lm7/A;->u(Lx9/o;)Z

    invoke-static {v0, v1}, Lm7/A;->z(Landroid/content/Context;Lx9/o;)V

    invoke-static {v0, v1}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object v0

    invoke-virtual {v0, v2}, LK9/b;->r0(Z)V

    return-void

    :pswitch_1e6
    const-string v0, "this$0"

    iget-object v1, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v1, LE5/h;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$runnable"

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Runnable;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v0, 0xa

    :try_start_1fa
    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V
    :try_end_1fd
    .catchall {:try_start_1fa .. :try_end_1fd} :catchall_1fd

    :catchall_1fd
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    return-void

    :pswitch_201
    new-instance v0, LC/h;

    const/4 v1, 0x4

    iget-object v2, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v2, Landroid/view/Surface;

    invoke-direct {v0, v1, v2}, LC/h;-><init>(ILandroid/view/Surface;)V

    iget-object v1, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v1, Lq0/a;

    invoke-interface {v1, v0}, Lq0/a;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_213
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, LC/o0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, LD/S;

    invoke-interface {v1, v0}, LD/S;->k(LD/T;)V

    return-void

    :pswitch_222
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, LC/C;

    iget-object v1, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v1, LC/k0;

    iget-object v3, v0, LC/C;->h:Ljava/lang/Object;

    monitor-enter v3

    :try_start_22d
    iget-boolean v4, v0, LC/C;->i:Z

    monitor-exit v3
    :try_end_230
    .catchall {:try_start_22d .. :try_end_230} :catchall_2ac

    if-nez v4, :cond_29f

    new-instance v3, Landroid/util/Size;

    invoke-interface {v1}, LC/k0;->getWidth()I

    move-result v4

    invoke-interface {v1}, LC/k0;->getHeight()I

    move-result v5

    invoke-direct {v3, v4, v5}, Landroid/util/Size;-><init>(II)V

    iget-object v4, v0, LC/C;->g:LC/h0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v4, v0, LC/C;->g:LC/h0;

    invoke-interface {v4}, LC/h0;->b()LD/q0;

    move-result-object v4

    iget-object v4, v4, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v4}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iget-object v5, v0, LC/C;->g:LC/h0;

    invoke-interface {v5}, LC/h0;->b()LD/q0;

    move-result-object v5

    iget-object v5, v5, LD/q0;->a:Ljava/util/Map;

    invoke-interface {v5, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    new-instance v6, LC/G0;

    iget-object v7, v0, LC/C;->g:LC/h0;

    invoke-direct {v6, v1, v3, v7}, LC/G0;-><init>(LC/k0;Landroid/util/Size;LC/h0;)V

    const/4 v1, 0x0

    iput-object v1, v0, LC/C;->g:LC/h0;

    new-instance v1, LC/I0;

    invoke-static {v5}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-direct {v1, v3, v4}, LC/I0;-><init>(Ljava/util/List;Ljava/lang/String;)V

    invoke-virtual {v1, v6}, LC/I0;->a(LC/k0;)V

    :try_start_281
    iget-object v3, v0, LC/C;->b:LD/y;

    invoke-interface {v3, v1}, LD/y;->d(LD/Q;)V
    :try_end_286
    .catch Ljava/lang/Exception; {:try_start_281 .. :try_end_286} :catch_287

    goto :goto_29f

    :catch_287
    move-exception v1

    const-string v3, "CaptureProcessorPipeline"

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "Post processing image failed! "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, LHe/b;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_29f
    :goto_29f
    iget-object v1, v0, LC/C;->h:Ljava/lang/Object;

    monitor-enter v1

    :try_start_2a2
    iput-boolean v2, v0, LC/C;->j:Z

    monitor-exit v1
    :try_end_2a5
    .catchall {:try_start_2a2 .. :try_end_2a5} :catchall_2a9

    invoke-virtual {v0}, LC/C;->e()V

    return-void

    :catchall_2a9
    move-exception v0

    :try_start_2aa
    monitor-exit v1
    :try_end_2ab
    .catchall {:try_start_2aa .. :try_end_2ab} :catchall_2a9

    throw v0

    :catchall_2ac
    move-exception v0

    :try_start_2ad
    monitor-exit v3
    :try_end_2ae
    .catchall {:try_start_2ad .. :try_end_2ae} :catchall_2ac

    throw v0

    :pswitch_2af
    iget-object v0, p0, LB1/h;->b:Ljava/lang/Object;

    check-cast v0, LB1/i;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, LB1/h;->c:Ljava/lang/Object;

    check-cast v0, LB1/L;

    invoke-interface {v0}, LB1/L;->n()V

    return-void

    :pswitch_data_2be
    .packed-switch 0x0
        :pswitch_2af
        :pswitch_222
        :pswitch_213
        :pswitch_201
        :pswitch_1e6
        :pswitch_1bd
        :pswitch_1a8
        :pswitch_19c
        :pswitch_190
        :pswitch_184
        :pswitch_178
        :pswitch_16c
        :pswitch_149
        :pswitch_139
        :pswitch_11e
        :pswitch_110
        :pswitch_e6
        :pswitch_cb
        :pswitch_8b
        :pswitch_4e
        :pswitch_16
    .end packed-switch
.end method
