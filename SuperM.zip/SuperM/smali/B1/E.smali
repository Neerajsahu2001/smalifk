.class public final LB1/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LW0/d0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LB1/d;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {v0}, Ll7/c1;->a(Li8/l;)Li8/l;

    return-void
.end method
