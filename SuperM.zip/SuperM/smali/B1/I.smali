.class public final LB1/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:I

.field public final c:Ljava/util/ArrayList;

.field public d:Landroidx/media3/common/b;

.field public e:J

.field public f:J

.field public g:J

.field public h:Z

.field public i:J

.field public j:LB1/L;

.field public k:Ljava/util/concurrent/Executor;

.field public final synthetic l:LB1/j;


# direct methods
.method public constructor <init>(LB1/j;Landroid/content/Context;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB1/i;->l:LB1/j;

    iput-object p2, p0, LB1/i;->a:Landroid/content/Context;

    invoke-static {p2}, LZ0/F;->N(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_f

    const/4 p1, 0x1

    goto :goto_10

    :cond_f
    const/4 p1, 0x5

    :goto_10
    iput p1, p0, LB1/i;->b:I

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LB1/i;->c:Ljava/util/ArrayList;

    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide p1, p0, LB1/i;->g:J

    sget-object p1, LB1/L;->a0:Ll7/z7;

    iput-object p1, p0, LB1/i;->j:LB1/L;

    sget-object p1, LB1/j;->m:LB1/a;

    iput-object p1, p0, LB1/i;->k:Ljava/util/concurrent/Executor;

    return-void
.end method


# virtual methods
.method public final a(Z)V
    .registers 9

    const/4 v0, 0x0

    iput-boolean v0, p0, LB1/i;->h:Z

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v0, p0, LB1/i;->g:J

    iget-object v2, p0, LB1/i;->l:LB1/j;

    iget v3, v2, LB1/j;->l:I

    const/4 v4, 0x1

    if-ne v3, v4, :cond_29

    iget v3, v2, LB1/j;->k:I

    add-int/2addr v3, v4

    iput v3, v2, LB1/j;->k:I

    iget-object v3, v2, LB1/j;->c:LB1/B;

    invoke-virtual {v3}, LB1/B;->a()V

    iget-object v3, v2, LB1/j;->i:LZ0/A;

    invoke-static {v3}, Lm7/u;->g(Ljava/lang/Object;)V

    new-instance v5, LB1/b;

    const/4 v6, 0x0

    invoke-direct {v5, v6, v2}, LB1/b;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v3, v5}, LZ0/A;->c(Ljava/lang/Runnable;)Z

    :cond_29
    if-eqz p1, :cond_42

    iget-object p1, v2, LB1/j;->b:LB1/w;

    iget-object v2, p1, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    const-wide/16 v5, 0x0

    iput-wide v5, v2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    const-wide/16 v5, -0x1

    iput-wide v5, v2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iput-wide v5, v2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    iput-wide v0, p1, LB1/w;->h:J

    iput-wide v0, p1, LB1/w;->f:J

    invoke-virtual {p1, v4}, LB1/w;->c(I)V

    iput-wide v0, p1, LB1/w;->i:J

    :cond_42
    return-void
.end method

.method public final b(Landroidx/media3/common/b;)V
    .registers 6

    iget-object v0, p0, LB1/i;->l:LB1/j;

    iget v1, v0, LB1/j;->l:I

    if-nez v1, :cond_8

    const/4 v1, 0x1

    goto :goto_9

    :cond_8
    const/4 v1, 0x0

    :goto_9
    invoke-static {v1}, Lm7/u;->e(Z)V

    iget-object v1, p1, Landroidx/media3/common/b;->A:LW0/j;

    if-eqz v1, :cond_16

    invoke-virtual {v1}, LW0/j;->d()Z

    move-result v2

    if-nez v2, :cond_18

    :cond_16
    sget-object v1, LW0/j;->h:LW0/j;

    :cond_18
    iget v1, v1, LW0/j;->c:I

    const/4 v2, 0x7

    if-ne v1, v2, :cond_25

    sget v1, LZ0/F;->a:I

    const/16 v2, 0x22

    if-ge v1, v2, :cond_25

    new-instance v1, LW0/j;

    :cond_25
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v1}, Lm7/u;->g(Ljava/lang/Object;)V

    iget-object v2, v0, LB1/j;->e:LZ0/y;

    const/4 v3, 0x0

    invoke-virtual {v2, v1, v3}, LZ0/y;->a(Landroid/os/Looper;Landroid/os/Handler$Callback;)LZ0/A;

    move-result-object v1

    iput-object v1, v0, LB1/j;->i:LZ0/A;

    :try_start_35
    iget-object v1, v0, LB1/j;->d:LB1/f;

    sget-object v2, Lj8/T;->b:Lj8/Q;

    sget-object v2, Lj8/q0;->e:Lj8/q0;

    invoke-virtual {v1}, LB1/f;->a()V

    iget-object v0, v0, LB1/j;->j:Landroid/util/Pair;

    if-eqz v0, :cond_4f

    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Landroid/view/Surface;

    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, LZ0/x;

    iget p1, v0, LZ0/x;->a:I
    :try_end_4c
    .catch LW0/c0; {:try_start_35 .. :try_end_4c} :catch_4d

    goto :goto_4f

    :catch_4d
    move-exception v0

    goto :goto_50

    :cond_4f
    :goto_4f
    throw v3

    :goto_50
    new-instance v1, LB1/M;

    invoke-direct {v1, v0, p1}, LB1/M;-><init>(Ljava/lang/Exception;Landroidx/media3/common/b;)V

    throw v1
.end method

.method public final c()V
    .registers 9

    iget-object v0, p0, LB1/i;->d:Landroidx/media3/common/b;

    if-nez v0, :cond_5

    return-void

    :cond_5
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, LB1/i;->c:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, LB1/i;->d:Landroidx/media3/common/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    invoke-static {v1}, Lm7/u;->g(Ljava/lang/Object;)V

    iget-object v2, v0, Landroidx/media3/common/b;->A:LW0/j;

    if-eqz v2, :cond_22

    invoke-virtual {v2}, LW0/j;->d()Z

    move-result v2

    if-nez v2, :cond_24

    :cond_22
    sget-object v2, LW0/j;->h:LW0/j;

    :cond_24
    iget v2, v0, Landroidx/media3/common/b;->t:I

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-lez v2, :cond_2c

    move v5, v4

    goto :goto_2d

    :cond_2c
    move v5, v3

    :goto_2d
    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "width must be positive, but is: "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v5, v2}, Lm7/u;->b(ZLjava/lang/String;)V

    iget v0, v0, Landroidx/media3/common/b;->u:I

    if-lez v0, :cond_43

    move v3, v4

    :cond_43
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "height must be positive, but is: "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lm7/u;->b(ZLjava/lang/String;)V

    throw v1
.end method

.method public final d(JJ)V
    .registers 6

    :try_start_0
    iget-object v0, p0, LB1/i;->l:LB1/j;

    invoke-virtual {v0, p1, p2, p3, p4}, LB1/j;->a(JJ)V
    :try_end_5
    .catch Landroidx/media3/exoplayer/m; {:try_start_0 .. :try_end_5} :catch_6

    return-void

    :catch_6
    move-exception p1

    new-instance p2, LB1/M;

    iget-object p3, p0, LB1/i;->d:Landroidx/media3/common/b;

    if-eqz p3, :cond_e

    goto :goto_19

    :cond_e
    new-instance p3, LW0/o;

    invoke-direct {p3}, LW0/o;-><init>()V

    new-instance p4, Landroidx/media3/common/b;

    invoke-direct {p4, p3}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    move-object p3, p4

    :goto_19
    invoke-direct {p2, p1, p3}, LB1/M;-><init>(Ljava/lang/Exception;Landroidx/media3/common/b;)V

    throw p2
.end method

.method public final e(Landroid/view/Surface;LZ0/x;)V
    .registers 5

    iget-object v0, p0, LB1/i;->l:LB1/j;

    iget-object v1, v0, LB1/j;->j:Landroid/util/Pair;

    if-eqz v1, :cond_1d

    iget-object v1, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Landroid/view/Surface;

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    iget-object v1, v0, LB1/j;->j:Landroid/util/Pair;

    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, LZ0/x;

    invoke-virtual {v1, p2}, LZ0/x;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    goto :goto_25

    :cond_1d
    invoke-static {p1, p2}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p1

    iput-object p1, v0, LB1/j;->j:Landroid/util/Pair;

    iget p1, p2, LZ0/x;->a:I

    :goto_25
    return-void
.end method
