.class public final LB1/q;
.super Lo1/u;
.source "SourceFile"


# static fields
.field public static final e2:[I

.field public static f2:Z

.field public static g2:Z


# instance fields
.field public final A1:LW2/p;

.field public final B1:I

.field public final C1:Z

.field public final D1:LB1/w;

.field public final E1:LB1/v;

.field public F1:LB1/o;

.field public G1:Z

.field public H1:Z

.field public I1:LB1/i;

.field public J1:Z

.field public K1:Ljava/util/List;

.field public L1:Landroid/view/Surface;

.field public M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

.field public N1:LZ0/x;

.field public O1:Z

.field public P1:I

.field public Q1:J

.field public R1:I

.field public S1:I

.field public T1:I

.field public U1:J

.field public V1:I

.field public W1:J

.field public X1:LW0/e0;

.field public Y1:LW0/e0;

.field public Z1:I

.field public a2:Z

.field public b2:I

.field public c2:LB1/p;

.field public d2:LB1/u;

.field public final y1:Landroid/content/Context;

.field public final z1:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x9

    new-array v0, v0, [I

    fill-array-data v0, :array_a

    sput-object v0, LB1/q;->e2:[I

    return-void

    :array_a
    .array-data 4
        0x780
        0x640
        0x5a0
        0x500
        0x3c0
        0x356
        0x280
        0x21c
        0x1e0
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;Lo1/j;Lo1/v;JZLandroid/os/Handler;Landroidx/media3/exoplayer/I;)V
    .registers 15

    const/4 v1, 0x2

    const/high16 v5, 0x41f00000    # 30.0f

    move-object v0, p0

    move-object v2, p2

    move-object v3, p3

    move v4, p6

    invoke-direct/range {v0 .. v5}, Lo1/u;-><init>(ILo1/j;Lo1/v;ZF)V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, LB1/q;->y1:Landroid/content/Context;

    const/16 p2, 0x32

    iput p2, p0, LB1/q;->B1:I

    new-instance p2, LW2/p;

    const/4 p3, 0x2

    invoke-direct {p2, p3, p7, p8}, LW2/p;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    iput-object p2, p0, LB1/q;->A1:LW2/p;

    const/4 p2, 0x1

    iput-boolean p2, p0, LB1/q;->z1:Z

    new-instance p3, LB1/w;

    invoke-direct {p3, p1, p0, p4, p5}, LB1/w;-><init>(Landroid/content/Context;LB1/q;J)V

    iput-object p3, p0, LB1/q;->D1:LB1/w;

    new-instance p1, LB1/v;

    invoke-direct {p1}, LB1/v;-><init>()V

    iput-object p1, p0, LB1/q;->E1:LB1/v;

    const-string p1, "NVIDIA"

    sget-object p3, LZ0/F;->c:Ljava/lang/String;

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    iput-boolean p1, p0, LB1/q;->C1:Z

    sget-object p1, LZ0/x;->c:LZ0/x;

    iput-object p1, p0, LB1/q;->N1:LZ0/x;

    iput p2, p0, LB1/q;->P1:I

    sget-object p1, LW0/e0;->e:LW0/e0;

    iput-object p1, p0, LB1/q;->X1:LW0/e0;

    const/4 p1, 0x0

    iput p1, p0, LB1/q;->b2:I

    const/4 p1, 0x0

    iput-object p1, p0, LB1/q;->Y1:LW0/e0;

    const/16 p1, -0x3e8

    iput p1, p0, LB1/q;->Z1:I

    return-void
.end method

.method public static A0(Lo1/n;Landroidx/media3/common/b;)I
    .registers 13

    const/4 v0, 0x3

    const/4 v1, 0x4

    const-string v2, "video/hevc"

    const-string v3, "video/avc"

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v6, p1, Landroidx/media3/common/b;->t:I

    const/4 v7, -0x1

    if-eq v6, v7, :cond_d8

    iget v8, p1, Landroidx/media3/common/b;->u:I

    if-ne v8, v7, :cond_13

    goto/16 :goto_d8

    :cond_13
    iget-object v9, p1, Landroidx/media3/common/b;->n:Ljava/lang/String;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v10, "video/dolby-vision"

    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_39

    invoke-static {p1}, Lo1/B;->d(Landroidx/media3/common/b;)Landroid/util/Pair;

    move-result-object p1

    if-eqz p1, :cond_38

    iget-object p1, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/16 v9, 0x200

    if-eq p1, v9, :cond_36

    if-eq p1, v5, :cond_36

    if-ne p1, v4, :cond_38

    :cond_36
    move-object v9, v3

    goto :goto_39

    :cond_38
    move-object v9, v2

    :cond_39
    :goto_39
    invoke-virtual {v9}, Ljava/lang/String;->hashCode()I

    move-result p1

    sparse-switch p1, :sswitch_data_da

    :goto_40
    move v4, v7

    goto :goto_88

    :sswitch_42
    const-string p1, "video/x-vnd.on2.vp9"

    invoke-virtual {v9, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_4b

    goto :goto_40

    :cond_4b
    const/4 v4, 0x6

    goto :goto_88

    :sswitch_4d
    const-string p1, "video/x-vnd.on2.vp8"

    invoke-virtual {v9, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_56

    goto :goto_40

    :cond_56
    const/4 v4, 0x5

    goto :goto_88

    :sswitch_58
    invoke-virtual {v9, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5f

    goto :goto_40

    :cond_5f
    move v4, v1

    goto :goto_88

    :sswitch_61
    const-string p1, "video/mp4v-es"

    invoke-virtual {v9, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6a

    goto :goto_40

    :cond_6a
    move v4, v0

    goto :goto_88

    :sswitch_6c
    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_88

    goto :goto_40

    :sswitch_73
    const-string p1, "video/av01"

    invoke-virtual {v9, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_7c

    goto :goto_40

    :cond_7c
    move v4, v5

    goto :goto_88

    :sswitch_7e
    const-string p1, "video/3gpp"

    invoke-virtual {v9, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_87

    goto :goto_40

    :cond_87
    const/4 v4, 0x0

    :cond_88
    :goto_88
    packed-switch v4, :pswitch_data_f8

    return v7

    :pswitch_8c
    mul-int/2addr v6, v8

    mul-int/2addr v6, v0

    div-int/lit8 v6, v6, 0x8

    return v6

    :pswitch_91
    sget-object p1, LZ0/F;->d:Ljava/lang/String;

    const-string v0, "BRAVIA 4K 2015"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_c9

    const-string v0, "Amazon"

    sget-object v2, LZ0/F;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ba

    const-string v0, "KFSOWI"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_c9

    const-string v0, "AFTS"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_ba

    iget-boolean p0, p0, Lo1/n;->f:Z

    if-eqz p0, :cond_ba

    goto :goto_c9

    :cond_ba
    const/16 p0, 0x10

    invoke-static {v6, p0}, LZ0/F;->g(II)I

    move-result p1

    invoke-static {v8, p0}, LZ0/F;->g(II)I

    move-result p0

    mul-int/2addr p0, p1

    mul-int/lit16 p0, p0, 0x300

    div-int/2addr p0, v1

    return p0

    :cond_c9
    :goto_c9
    return v7

    :pswitch_ca
    mul-int/2addr v6, v8

    mul-int/2addr v6, v0

    div-int/2addr v6, v1

    const/high16 p0, 0x200000

    invoke-static {p0, v6}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0

    :pswitch_d4
    mul-int/2addr v6, v8

    mul-int/2addr v6, v0

    div-int/2addr v6, v1

    return v6

    :cond_d8
    :goto_d8
    return v7

    nop

    :sswitch_data_da
    .sparse-switch
        -0x63306f58 -> :sswitch_7e
        -0x631b55f6 -> :sswitch_73
        -0x63185e82 -> :sswitch_6c
        0x46cdc642 -> :sswitch_61
        0x4f62373a -> :sswitch_58
        0x5f50bed8 -> :sswitch_4d
        0x5f50bed9 -> :sswitch_42
    .end sparse-switch

    :pswitch_data_f8
    .packed-switch 0x0
        :pswitch_d4
        :pswitch_d4
        :pswitch_ca
        :pswitch_d4
        :pswitch_91
        :pswitch_d4
        :pswitch_8c
    .end packed-switch
.end method

.method public static B0(Landroid/content/Context;Lo1/v;Landroidx/media3/common/b;ZZ)Ljava/util/List;
    .registers 8

    iget-object v0, p2, Landroidx/media3/common/b;->n:Ljava/lang/String;

    if-nez v0, :cond_7

    sget-object p0, Lj8/q0;->e:Lj8/q0;

    return-object p0

    :cond_7
    sget v1, LZ0/F;->a:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_32

    const-string v1, "video/dolby-vision"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-static {p0}, LB1/n;->a(Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_32

    invoke-static {p2}, Lo1/B;->b(Landroidx/media3/common/b;)Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_24

    sget-object p0, Lj8/q0;->e:Lj8/q0;

    goto :goto_2b

    :cond_24
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, p3, p4}, Lo1/B;->f(Ljava/lang/String;ZZ)Ljava/util/List;

    move-result-object p0

    :goto_2b
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_32

    return-object p0

    :cond_32
    invoke-static {p1, p2, p3, p4}, Lo1/B;->h(Lo1/v;Landroidx/media3/common/b;ZZ)Lj8/q0;

    move-result-object p0

    return-object p0
.end method

.method public static C0(Lo1/n;Landroidx/media3/common/b;)I
    .registers 6

    iget v0, p1, Landroidx/media3/common/b;->o:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1e

    iget-object p0, p1, Landroidx/media3/common/b;->q:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_d
    if-ge v1, v0, :cond_1a

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [B

    array-length v3, v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_1a
    iget p0, p1, Landroidx/media3/common/b;->o:I

    add-int/2addr p0, v2

    return p0

    :cond_1e
    invoke-static {p0, p1}, LB1/q;->A0(Lo1/n;Landroidx/media3/common/b;)I

    move-result p0

    return p0
.end method

.method public static z0(Ljava/lang/String;)Z
    .registers 18

    const/16 v0, 0x1a

    const/16 v2, 0x1b

    const/16 v3, 0x1c

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/4 v10, -0x1

    const/4 v11, 0x1

    const-string v12, "OMX.google"

    move-object/from16 v13, p0

    invoke-virtual {v13, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v12

    const/4 v13, 0x0

    if-eqz v12, :cond_1a

    return v13

    :cond_1a
    const-class v12, LB1/q;

    monitor-enter v12

    :try_start_1d
    sget-boolean v14, LB1/q;->f2:Z

    if-nez v14, :cond_8c0

    sget v14, LZ0/F;->a:I

    if-gt v14, v3, :cond_92

    sget-object v15, LZ0/F;->b:Ljava/lang/String;

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_2a
    .catchall {:try_start_1d .. :try_end_2a} :catchall_8be

    invoke-virtual {v15}, Ljava/lang/String;->hashCode()I

    move-result v16

    sparse-switch v16, :sswitch_data_8c6

    :goto_31
    move v1, v10

    goto/16 :goto_8b

    :sswitch_34
    const-string v1, "machuca"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3d

    goto :goto_31

    :cond_3d
    move v1, v4

    goto :goto_8b

    :sswitch_3f
    const-string v1, "once"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_48

    goto :goto_31

    :cond_48
    move v1, v5

    goto :goto_8b

    :sswitch_4a
    const-string v1, "magnolia"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_53

    goto :goto_31

    :cond_53
    move v1, v6

    goto :goto_8b

    :sswitch_55
    const-string v1, "aquaman"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5e

    goto :goto_31

    :cond_5e
    move v1, v7

    goto :goto_8b

    :sswitch_60
    const-string v1, "oneday"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_69

    goto :goto_31

    :cond_69
    move v1, v8

    goto :goto_8b

    :sswitch_6b
    const-string v1, "dangalUHD"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_74

    goto :goto_31

    :cond_74
    move v1, v9

    goto :goto_8b

    :sswitch_76
    const-string v1, "dangalFHD"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7f

    goto :goto_31

    :cond_7f
    move v1, v11

    goto :goto_8b

    :sswitch_81
    const-string v1, "dangal"

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8a

    goto :goto_31

    :cond_8a
    move v1, v13

    :goto_8b
    packed-switch v1, :pswitch_data_8e8

    goto :goto_92

    :cond_8f
    :goto_8f
    :pswitch_8f
    move v13, v11

    goto/16 :goto_8b9

    :cond_92
    :goto_92
    if-gt v14, v2, :cond_9f

    :try_start_94
    const-string v1, "HWEML"

    sget-object v15, LZ0/F;->b:Ljava/lang/String;

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9f

    goto :goto_8f

    :cond_9f
    sget-object v1, LZ0/F;->d:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_a4
    .catchall {:try_start_94 .. :try_end_a4} :catchall_8be

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v15

    sparse-switch v15, :sswitch_data_8fc

    :goto_ab
    move v15, v10

    goto/16 :goto_112

    :sswitch_ae
    const-string v15, "AFTEUFF014"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_b7

    goto :goto_ab

    :cond_b7
    const/16 v15, 0x8

    goto/16 :goto_112

    :sswitch_bb
    const-string v15, "AFTSO001"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_c4

    goto :goto_ab

    :cond_c4
    move v15, v4

    goto :goto_112

    :sswitch_c6
    const-string v15, "AFTEU014"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_cf

    goto :goto_ab

    :cond_cf
    move v15, v5

    goto :goto_112

    :sswitch_d1
    const-string v15, "AFTEU011"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_da

    goto :goto_ab

    :cond_da
    move v15, v6

    goto :goto_112

    :sswitch_dc
    const-string v15, "AFTR"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_e5

    goto :goto_ab

    :cond_e5
    move v15, v7

    goto :goto_112

    :sswitch_e7
    const-string v15, "AFTN"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_f0

    goto :goto_ab

    :cond_f0
    move v15, v8

    goto :goto_112

    :sswitch_f2
    const-string v15, "AFTA"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_fb

    goto :goto_ab

    :cond_fb
    move v15, v9

    goto :goto_112

    :sswitch_fd
    const-string v15, "AFTKMST12"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_106

    goto :goto_ab

    :cond_106
    move v15, v11

    goto :goto_112

    :sswitch_108
    const-string v15, "AFTJMST12"

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_111

    goto :goto_ab

    :cond_111
    move v15, v13

    :goto_112
    packed-switch v15, :pswitch_data_922

    if-gt v14, v0, :cond_8b9

    :try_start_117
    sget-object v14, LZ0/F;->b:Ljava/lang/String;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_11c
    .catchall {:try_start_117 .. :try_end_11c} :catchall_8be

    invoke-virtual {v14}, Ljava/lang/String;->hashCode()I

    move-result v15

    sparse-switch v15, :sswitch_data_938

    :goto_123
    move v0, v10

    goto/16 :goto_8ae

    :sswitch_126
    const-string v0, "HWWAS-H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12f

    goto :goto_123

    :cond_12f
    const/16 v0, 0x8b

    goto/16 :goto_8ae

    :sswitch_133
    const-string v0, "HWVNS-H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_13c

    goto :goto_123

    :cond_13c
    const/16 v0, 0x8a

    goto/16 :goto_8ae

    :sswitch_140
    const-string v0, "ELUGA_Prim"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_149

    goto :goto_123

    :cond_149
    const/16 v0, 0x89

    goto/16 :goto_8ae

    :sswitch_14d
    const-string v0, "ELUGA_Note"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_156

    goto :goto_123

    :cond_156
    const/16 v0, 0x88

    goto/16 :goto_8ae

    :sswitch_15a
    const-string v0, "ASUS_X00AD_2"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_163

    goto :goto_123

    :cond_163
    const/16 v0, 0x87

    goto/16 :goto_8ae

    :sswitch_167
    const-string v0, "HWCAM-H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_170

    goto :goto_123

    :cond_170
    const/16 v0, 0x86

    goto/16 :goto_8ae

    :sswitch_174
    const-string v0, "HWBLN-H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_17d

    goto :goto_123

    :cond_17d
    const/16 v0, 0x85

    goto/16 :goto_8ae

    :sswitch_181
    const-string v0, "DM-01K"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18a

    goto :goto_123

    :cond_18a
    const/16 v0, 0x84

    goto/16 :goto_8ae

    :sswitch_18e
    const-string v0, "BRAVIA_ATV3_4K"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_197

    goto :goto_123

    :cond_197
    const/16 v0, 0x83

    goto/16 :goto_8ae

    :sswitch_19b
    const-string v0, "Infinix-X572"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1a5

    goto/16 :goto_123

    :cond_1a5
    const/16 v0, 0x82

    goto/16 :goto_8ae

    :sswitch_1a9
    const-string v0, "PB2-670M"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b3

    goto/16 :goto_123

    :cond_1b3
    const/16 v0, 0x81

    goto/16 :goto_8ae

    :sswitch_1b7
    const-string v0, "santoni"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1c1

    goto/16 :goto_123

    :cond_1c1
    const/16 v0, 0x80

    goto/16 :goto_8ae

    :sswitch_1c5
    const-string v0, "iball8735_9806"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1cf

    goto/16 :goto_123

    :cond_1cf
    const/16 v0, 0x7f

    goto/16 :goto_8ae

    :sswitch_1d3
    const-string v0, "CPH1715"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1dd

    goto/16 :goto_123

    :cond_1dd
    const/16 v0, 0x7e

    goto/16 :goto_8ae

    :sswitch_1e1
    const-string v0, "CPH1609"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1eb

    goto/16 :goto_123

    :cond_1eb
    const/16 v0, 0x7d

    goto/16 :goto_8ae

    :sswitch_1ef
    const-string v0, "woods_f"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1f9

    goto/16 :goto_123

    :cond_1f9
    const/16 v0, 0x7c

    goto/16 :goto_8ae

    :sswitch_1fd
    const-string v0, "htc_e56ml_dtul"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_207

    goto/16 :goto_123

    :cond_207
    const/16 v0, 0x7b

    goto/16 :goto_8ae

    :sswitch_20b
    const-string v0, "EverStar_S"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_215

    goto/16 :goto_123

    :cond_215
    const/16 v0, 0x7a

    goto/16 :goto_8ae

    :sswitch_219
    const-string v0, "hwALE-H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_223

    goto/16 :goto_123

    :cond_223
    const/16 v0, 0x79

    goto/16 :goto_8ae

    :sswitch_227
    const-string v0, "itel_S41"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_231

    goto/16 :goto_123

    :cond_231
    const/16 v0, 0x78

    goto/16 :goto_8ae

    :sswitch_235
    const-string v0, "LS-5017"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_23f

    goto/16 :goto_123

    :cond_23f
    const/16 v0, 0x77

    goto/16 :goto_8ae

    :sswitch_243
    const-string v0, "panell_d"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_24d

    goto/16 :goto_123

    :cond_24d
    const/16 v0, 0x76

    goto/16 :goto_8ae

    :sswitch_251
    const-string v0, "j2xlteins"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_25b

    goto/16 :goto_123

    :cond_25b
    const/16 v0, 0x75

    goto/16 :goto_8ae

    :sswitch_25f
    const-string v0, "A7000plus"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_269

    goto/16 :goto_123

    :cond_269
    const/16 v0, 0x74

    goto/16 :goto_8ae

    :sswitch_26d
    const-string v0, "manning"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_277

    goto/16 :goto_123

    :cond_277
    const/16 v0, 0x73

    goto/16 :goto_8ae

    :sswitch_27b
    const-string v0, "GIONEE_WBL7519"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_285

    goto/16 :goto_123

    :cond_285
    const/16 v0, 0x72

    goto/16 :goto_8ae

    :sswitch_289
    const-string v0, "GIONEE_WBL7365"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_293

    goto/16 :goto_123

    :cond_293
    const/16 v0, 0x71

    goto/16 :goto_8ae

    :sswitch_297
    const-string v0, "GIONEE_WBL5708"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2a1

    goto/16 :goto_123

    :cond_2a1
    const/16 v0, 0x70

    goto/16 :goto_8ae

    :sswitch_2a5
    const-string v0, "QM16XE_U"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2af

    goto/16 :goto_123

    :cond_2af
    const/16 v0, 0x6f

    goto/16 :goto_8ae

    :sswitch_2b3
    const-string v0, "Pixi5-10_4G"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2bd

    goto/16 :goto_123

    :cond_2bd
    const/16 v0, 0x6e

    goto/16 :goto_8ae

    :sswitch_2c1
    const-string v0, "TB3-850M"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2cb

    goto/16 :goto_123

    :cond_2cb
    const/16 v0, 0x6d

    goto/16 :goto_8ae

    :sswitch_2cf
    const-string v0, "TB3-850F"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2d9

    goto/16 :goto_123

    :cond_2d9
    const/16 v0, 0x6c

    goto/16 :goto_8ae

    :sswitch_2dd
    const-string v0, "TB3-730X"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2e7

    goto/16 :goto_123

    :cond_2e7
    const/16 v0, 0x6b

    goto/16 :goto_8ae

    :sswitch_2eb
    const-string v0, "TB3-730F"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2f5

    goto/16 :goto_123

    :cond_2f5
    const/16 v0, 0x6a

    goto/16 :goto_8ae

    :sswitch_2f9
    const-string v0, "A7020a48"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_303

    goto/16 :goto_123

    :cond_303
    const/16 v0, 0x69

    goto/16 :goto_8ae

    :sswitch_307
    const-string v0, "A7010a48"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_311

    goto/16 :goto_123

    :cond_311
    const/16 v0, 0x68

    goto/16 :goto_8ae

    :sswitch_315
    const-string v0, "griffin"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_31f

    goto/16 :goto_123

    :cond_31f
    const/16 v0, 0x67

    goto/16 :goto_8ae

    :sswitch_323
    const-string v0, "marino_f"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_32d

    goto/16 :goto_123

    :cond_32d
    const/16 v0, 0x66

    goto/16 :goto_8ae

    :sswitch_331
    const-string v0, "CPY83_I00"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_33b

    goto/16 :goto_123

    :cond_33b
    const/16 v0, 0x65

    goto/16 :goto_8ae

    :sswitch_33f
    const-string v0, "A2016a40"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_349

    goto/16 :goto_123

    :cond_349
    const/16 v0, 0x64

    goto/16 :goto_8ae

    :sswitch_34d
    const-string v0, "le_x6"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_357

    goto/16 :goto_123

    :cond_357
    const/16 v0, 0x63

    goto/16 :goto_8ae

    :sswitch_35b
    const-string v0, "l5460"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_365

    goto/16 :goto_123

    :cond_365
    const/16 v0, 0x62

    goto/16 :goto_8ae

    :sswitch_369
    const-string v0, "i9031"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_373

    goto/16 :goto_123

    :cond_373
    const/16 v0, 0x61

    goto/16 :goto_8ae

    :sswitch_377
    const-string v0, "X3_HK"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_381

    goto/16 :goto_123

    :cond_381
    const/16 v0, 0x60

    goto/16 :goto_8ae

    :sswitch_385
    const-string v0, "V23GB"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_38f

    goto/16 :goto_123

    :cond_38f
    const/16 v0, 0x5f

    goto/16 :goto_8ae

    :sswitch_393
    const-string v0, "Q4310"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_39d

    goto/16 :goto_123

    :cond_39d
    const/16 v0, 0x5e

    goto/16 :goto_8ae

    :sswitch_3a1
    const-string v0, "Q4260"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3ab

    goto/16 :goto_123

    :cond_3ab
    const/16 v0, 0x5d

    goto/16 :goto_8ae

    :sswitch_3af
    const-string v0, "PRO7S"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3b9

    goto/16 :goto_123

    :cond_3b9
    const/16 v0, 0x5c

    goto/16 :goto_8ae

    :sswitch_3bd
    const-string v0, "F3311"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3c7

    goto/16 :goto_123

    :cond_3c7
    const/16 v0, 0x5b

    goto/16 :goto_8ae

    :sswitch_3cb
    const-string v0, "F3215"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3d5

    goto/16 :goto_123

    :cond_3d5
    const/16 v0, 0x5a

    goto/16 :goto_8ae

    :sswitch_3d9
    const-string v0, "F3213"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3e3

    goto/16 :goto_123

    :cond_3e3
    const/16 v0, 0x59

    goto/16 :goto_8ae

    :sswitch_3e7
    const-string v0, "F3211"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3f1

    goto/16 :goto_123

    :cond_3f1
    const/16 v0, 0x58

    goto/16 :goto_8ae

    :sswitch_3f5
    const-string v0, "F3116"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3ff

    goto/16 :goto_123

    :cond_3ff
    const/16 v0, 0x57

    goto/16 :goto_8ae

    :sswitch_403
    const-string v0, "F3113"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_40d

    goto/16 :goto_123

    :cond_40d
    const/16 v0, 0x56

    goto/16 :goto_8ae

    :sswitch_411
    const-string v0, "F3111"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41b

    goto/16 :goto_123

    :cond_41b
    const/16 v0, 0x55

    goto/16 :goto_8ae

    :sswitch_41f
    const-string v0, "E5643"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_429

    goto/16 :goto_123

    :cond_429
    const/16 v0, 0x54

    goto/16 :goto_8ae

    :sswitch_42d
    const-string v0, "A1601"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_437

    goto/16 :goto_123

    :cond_437
    const/16 v0, 0x53

    goto/16 :goto_8ae

    :sswitch_43b
    const-string v0, "Aura_Note_2"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_445

    goto/16 :goto_123

    :cond_445
    const/16 v0, 0x52

    goto/16 :goto_8ae

    :sswitch_449
    const-string v0, "602LV"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_453

    goto/16 :goto_123

    :cond_453
    const/16 v0, 0x51

    goto/16 :goto_8ae

    :sswitch_457
    const-string v0, "601LV"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_461

    goto/16 :goto_123

    :cond_461
    const/16 v0, 0x50

    goto/16 :goto_8ae

    :sswitch_465
    const-string v0, "MEIZU_M5"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_46f

    goto/16 :goto_123

    :cond_46f
    const/16 v0, 0x4f

    goto/16 :goto_8ae

    :sswitch_473
    const-string v0, "p212"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_47d

    goto/16 :goto_123

    :cond_47d
    const/16 v0, 0x4e

    goto/16 :goto_8ae

    :sswitch_481
    const-string v0, "mido"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_48b

    goto/16 :goto_123

    :cond_48b
    const/16 v0, 0x4d

    goto/16 :goto_8ae

    :sswitch_48f
    const-string v0, "kate"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_499

    goto/16 :goto_123

    :cond_499
    const/16 v0, 0x4c

    goto/16 :goto_8ae

    :sswitch_49d
    const-string v0, "fugu"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4a7

    goto/16 :goto_123

    :cond_4a7
    const/16 v0, 0x4b

    goto/16 :goto_8ae

    :sswitch_4ab
    const-string v0, "XE2X"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4b5

    goto/16 :goto_123

    :cond_4b5
    const/16 v0, 0x4a

    goto/16 :goto_8ae

    :sswitch_4b9
    const-string v0, "Q427"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4c3

    goto/16 :goto_123

    :cond_4c3
    const/16 v0, 0x49

    goto/16 :goto_8ae

    :sswitch_4c7
    const-string v0, "Q350"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4d1

    goto/16 :goto_123

    :cond_4d1
    const/16 v0, 0x48

    goto/16 :goto_8ae

    :sswitch_4d5
    const-string v0, "P681"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4df

    goto/16 :goto_123

    :cond_4df
    const/16 v0, 0x47

    goto/16 :goto_8ae

    :sswitch_4e3
    const-string v0, "F04J"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4ed

    goto/16 :goto_123

    :cond_4ed
    const/16 v0, 0x46

    goto/16 :goto_8ae

    :sswitch_4f1
    const-string v0, "F04H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4fb

    goto/16 :goto_123

    :cond_4fb
    const/16 v0, 0x45

    goto/16 :goto_8ae

    :sswitch_4ff
    const-string v0, "F03H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_509

    goto/16 :goto_123

    :cond_509
    const/16 v0, 0x44

    goto/16 :goto_8ae

    :sswitch_50d
    const-string v0, "F02H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_517

    goto/16 :goto_123

    :cond_517
    const/16 v0, 0x43

    goto/16 :goto_8ae

    :sswitch_51b
    const-string v0, "F01J"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_525

    goto/16 :goto_123

    :cond_525
    const/16 v0, 0x42

    goto/16 :goto_8ae

    :sswitch_529
    const-string v0, "F01H"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_533

    goto/16 :goto_123

    :cond_533
    const/16 v0, 0x41

    goto/16 :goto_8ae

    :sswitch_537
    const-string v0, "1714"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_541

    goto/16 :goto_123

    :cond_541
    const/16 v0, 0x40

    goto/16 :goto_8ae

    :sswitch_545
    const-string v0, "1713"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_54f

    goto/16 :goto_123

    :cond_54f
    const/16 v0, 0x3f

    goto/16 :goto_8ae

    :sswitch_553
    const-string v0, "1601"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_55d

    goto/16 :goto_123

    :cond_55d
    const/16 v0, 0x3e

    goto/16 :goto_8ae

    :sswitch_561
    const-string v0, "flo"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_56b

    goto/16 :goto_123

    :cond_56b
    const/16 v0, 0x3d

    goto/16 :goto_8ae

    :sswitch_56f
    const-string v0, "deb"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_579

    goto/16 :goto_123

    :cond_579
    const/16 v0, 0x3c

    goto/16 :goto_8ae

    :sswitch_57d
    const-string v0, "cv3"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_587

    goto/16 :goto_123

    :cond_587
    const/16 v0, 0x3b

    goto/16 :goto_8ae

    :sswitch_58b
    const-string v0, "cv1"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_595

    goto/16 :goto_123

    :cond_595
    const/16 v0, 0x3a

    goto/16 :goto_8ae

    :sswitch_599
    const-string v0, "Z80"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5a3

    goto/16 :goto_123

    :cond_5a3
    const/16 v0, 0x39

    goto/16 :goto_8ae

    :sswitch_5a7
    const-string v0, "QX1"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b1

    goto/16 :goto_123

    :cond_5b1
    const/16 v0, 0x38

    goto/16 :goto_8ae

    :sswitch_5b5
    const-string v0, "PLE"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5bf

    goto/16 :goto_123

    :cond_5bf
    const/16 v0, 0x37

    goto/16 :goto_8ae

    :sswitch_5c3
    const-string v0, "P85"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5cd

    goto/16 :goto_123

    :cond_5cd
    const/16 v0, 0x36

    goto/16 :goto_8ae

    :sswitch_5d1
    const-string v0, "MX6"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5db

    goto/16 :goto_123

    :cond_5db
    const/16 v0, 0x35

    goto/16 :goto_8ae

    :sswitch_5df
    const-string v0, "M5c"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5e9

    goto/16 :goto_123

    :cond_5e9
    const/16 v0, 0x34

    goto/16 :goto_8ae

    :sswitch_5ed
    const-string v0, "M04"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5f7

    goto/16 :goto_123

    :cond_5f7
    const/16 v0, 0x33

    goto/16 :goto_8ae

    :sswitch_5fb
    const-string v0, "JGZ"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_605

    goto/16 :goto_123

    :cond_605
    const/16 v0, 0x32

    goto/16 :goto_8ae

    :sswitch_609
    const-string v0, "mh"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_613

    goto/16 :goto_123

    :cond_613
    const/16 v0, 0x31

    goto/16 :goto_8ae

    :sswitch_617
    const-string v0, "b5"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_621

    goto/16 :goto_123

    :cond_621
    const/16 v0, 0x30

    goto/16 :goto_8ae

    :sswitch_625
    const-string v0, "V5"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_62f

    goto/16 :goto_123

    :cond_62f
    const/16 v0, 0x2f

    goto/16 :goto_8ae

    :sswitch_633
    const-string v0, "V1"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_63d

    goto/16 :goto_123

    :cond_63d
    const/16 v0, 0x2e

    goto/16 :goto_8ae

    :sswitch_641
    const-string v0, "Q5"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_64b

    goto/16 :goto_123

    :cond_64b
    const/16 v0, 0x2d

    goto/16 :goto_8ae

    :sswitch_64f
    const-string v0, "C1"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_659

    goto/16 :goto_123

    :cond_659
    const/16 v0, 0x2c

    goto/16 :goto_8ae

    :sswitch_65d
    const-string v0, "woods_fn"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_667

    goto/16 :goto_123

    :cond_667
    const/16 v0, 0x2b

    goto/16 :goto_8ae

    :sswitch_66b
    const-string v0, "ELUGA_A3_Pro"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_675

    goto/16 :goto_123

    :cond_675
    const/16 v0, 0x2a

    goto/16 :goto_8ae

    :sswitch_679
    const-string v0, "Z12_PRO"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_683

    goto/16 :goto_123

    :cond_683
    const/16 v0, 0x29

    goto/16 :goto_8ae

    :sswitch_687
    const-string v0, "BLACK-1X"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_691

    goto/16 :goto_123

    :cond_691
    const/16 v0, 0x28

    goto/16 :goto_8ae

    :sswitch_695
    const-string v0, "taido_row"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_69f

    goto/16 :goto_123

    :cond_69f
    const/16 v0, 0x27

    goto/16 :goto_8ae

    :sswitch_6a3
    const-string v0, "Pixi4-7_3G"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6ad

    goto/16 :goto_123

    :cond_6ad
    const/16 v0, 0x26

    goto/16 :goto_8ae

    :sswitch_6b1
    const-string v0, "GIONEE_GBL7360"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6bb

    goto/16 :goto_123

    :cond_6bb
    const/16 v0, 0x25

    goto/16 :goto_8ae

    :sswitch_6bf
    const-string v0, "GiONEE_CBL7513"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6c9

    goto/16 :goto_123

    :cond_6c9
    const/16 v0, 0x24

    goto/16 :goto_8ae

    :sswitch_6cd
    const-string v0, "OnePlus5T"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6d7

    goto/16 :goto_123

    :cond_6d7
    const/16 v0, 0x23

    goto/16 :goto_8ae

    :sswitch_6db
    const-string v0, "whyred"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6e5

    goto/16 :goto_123

    :cond_6e5
    const/16 v0, 0x22

    goto/16 :goto_8ae

    :sswitch_6e9
    const-string v0, "watson"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6f3

    goto/16 :goto_123

    :cond_6f3
    const/16 v0, 0x21

    goto/16 :goto_8ae

    :sswitch_6f7
    const-string v0, "SVP-DTV15"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_701

    goto/16 :goto_123

    :cond_701
    const/16 v0, 0x20

    goto/16 :goto_8ae

    :sswitch_705
    const-string v0, "A7000-a"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_70f

    goto/16 :goto_123

    :cond_70f
    const/16 v0, 0x1f

    goto/16 :goto_8ae

    :sswitch_713
    const-string v0, "nicklaus_f"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_71d

    goto/16 :goto_123

    :cond_71d
    const/16 v0, 0x1e

    goto/16 :goto_8ae

    :sswitch_721
    const-string v0, "tcl_eu"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_72b

    goto/16 :goto_123

    :cond_72b
    const/16 v0, 0x1d

    goto/16 :goto_8ae

    :sswitch_72f
    const-string v0, "ELUGA_Ray_X"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_739

    goto/16 :goto_123

    :cond_739
    move v0, v3

    goto/16 :goto_8ae

    :sswitch_73c
    const-string v0, "s905x018"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_746

    goto/16 :goto_123

    :cond_746
    move v0, v2

    goto/16 :goto_8ae

    :sswitch_749
    const-string v2, "A10-70L"

    invoke-virtual {v14, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_8ae

    goto/16 :goto_123

    :sswitch_753
    const-string v0, "A10-70F"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_75d

    goto/16 :goto_123

    :cond_75d
    const/16 v0, 0x19

    goto/16 :goto_8ae

    :sswitch_761
    const-string v0, "namath"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_76b

    goto/16 :goto_123

    :cond_76b
    const/16 v0, 0x18

    goto/16 :goto_8ae

    :sswitch_76f
    const-string v0, "Slate_Pro"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_779

    goto/16 :goto_123

    :cond_779
    const/16 v0, 0x17

    goto/16 :goto_8ae

    :sswitch_77d
    const-string v0, "iris60"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_787

    goto/16 :goto_123

    :cond_787
    const/16 v0, 0x16

    goto/16 :goto_8ae

    :sswitch_78b
    const-string v0, "BRAVIA_ATV2"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_795

    goto/16 :goto_123

    :cond_795
    const/16 v0, 0x15

    goto/16 :goto_8ae

    :sswitch_799
    const-string v0, "GiONEE_GBL7319"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7a3

    goto/16 :goto_123

    :cond_7a3
    const/16 v0, 0x14

    goto/16 :goto_8ae

    :sswitch_7a7
    const-string v0, "panell_dt"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7b1

    goto/16 :goto_123

    :cond_7b1
    const/16 v0, 0x13

    goto/16 :goto_8ae

    :sswitch_7b5
    const-string v0, "panell_ds"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7bf

    goto/16 :goto_123

    :cond_7bf
    const/16 v0, 0x12

    goto/16 :goto_8ae

    :sswitch_7c3
    const-string v0, "panell_dl"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7cd

    goto/16 :goto_123

    :cond_7cd
    const/16 v0, 0x11

    goto/16 :goto_8ae

    :sswitch_7d1
    const-string v0, "vernee_M5"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7db

    goto/16 :goto_123

    :cond_7db
    const/16 v0, 0x10

    goto/16 :goto_8ae

    :sswitch_7df
    const-string v0, "pacificrim"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7e9

    goto/16 :goto_123

    :cond_7e9
    const/16 v0, 0xf

    goto/16 :goto_8ae

    :sswitch_7ed
    const-string v0, "Phantom6"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7f7

    goto/16 :goto_123

    :cond_7f7
    const/16 v0, 0xe

    goto/16 :goto_8ae

    :sswitch_7fb
    const-string v0, "ComioS1"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_805

    goto/16 :goto_123

    :cond_805
    const/16 v0, 0xd

    goto/16 :goto_8ae

    :sswitch_809
    const-string v0, "XT1663"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_813

    goto/16 :goto_123

    :cond_813
    const/16 v0, 0xc

    goto/16 :goto_8ae

    :sswitch_817
    const-string v0, "RAIJIN"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_821

    goto/16 :goto_123

    :cond_821
    const/16 v0, 0xb

    goto/16 :goto_8ae

    :sswitch_825
    const-string v0, "AquaPowerM"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_82f

    goto/16 :goto_123

    :cond_82f
    const/16 v0, 0xa

    goto/16 :goto_8ae

    :sswitch_833
    const-string v0, "PGN611"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_83d

    goto/16 :goto_123

    :cond_83d
    const/16 v0, 0x9

    goto/16 :goto_8ae

    :sswitch_841
    const-string v0, "PGN610"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_84b

    goto/16 :goto_123

    :cond_84b
    const/16 v0, 0x8

    goto/16 :goto_8ae

    :sswitch_84f
    const-string v0, "PGN528"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_859

    goto/16 :goto_123

    :cond_859
    move v0, v4

    goto :goto_8ae

    :sswitch_85b
    const-string v0, "NX573J"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_865

    goto/16 :goto_123

    :cond_865
    move v0, v5

    goto :goto_8ae

    :sswitch_867
    const-string v0, "NX541J"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_871

    goto/16 :goto_123

    :cond_871
    move v0, v6

    goto :goto_8ae

    :sswitch_873
    const-string v0, "CP8676_I02"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_87d

    goto/16 :goto_123

    :cond_87d
    move v0, v7

    goto :goto_8ae

    :sswitch_87f
    const-string v0, "K50a40"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_889

    goto/16 :goto_123

    :cond_889
    move v0, v8

    goto :goto_8ae

    :sswitch_88b
    const-string v0, "GIONEE_SWW1631"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_895

    goto/16 :goto_123

    :cond_895
    move v0, v9

    goto :goto_8ae

    :sswitch_897
    const-string v0, "GIONEE_SWW1627"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8a1

    goto/16 :goto_123

    :cond_8a1
    move v0, v11

    goto :goto_8ae

    :sswitch_8a3
    const-string v0, "GIONEE_SWW1609"

    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8ad

    goto/16 :goto_123

    :cond_8ad
    move v0, v13

    :cond_8ae
    :goto_8ae
    packed-switch v0, :pswitch_data_b6a

    const-string v0, "JSN-L21"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8f

    :cond_8b9
    :goto_8b9
    :try_start_8b9
    sput-boolean v13, LB1/q;->g2:Z

    sput-boolean v11, LB1/q;->f2:Z

    goto :goto_8c0

    :catchall_8be
    move-exception v0

    goto :goto_8c4

    :cond_8c0
    :goto_8c0
    monitor-exit v12
    :try_end_8c1
    .catchall {:try_start_8b9 .. :try_end_8c1} :catchall_8be

    sget-boolean v0, LB1/q;->g2:Z

    return v0

    :goto_8c4
    :try_start_8c4
    monitor-exit v12
    :try_end_8c5
    .catchall {:try_start_8c4 .. :try_end_8c5} :catchall_8be

    throw v0

    :sswitch_data_8c6
    .sparse-switch
        -0x4fd0ea5f -> :sswitch_81
        -0x48b8f57f -> :sswitch_76
        -0x48b8bd30 -> :sswitch_6b
        -0x3c588c8a -> :sswitch_60
        -0x2d5172e2 -> :sswitch_55
        -0x3de1850 -> :sswitch_4a
        0x341e81 -> :sswitch_3f
        0x31316ffa -> :sswitch_34
    .end sparse-switch

    :pswitch_data_8e8
    .packed-switch 0x0
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
    .end packed-switch

    :sswitch_data_8fc
    .sparse-switch
        -0x14d76e6c -> :sswitch_108
        -0x132295cd -> :sswitch_fd
        0x1e9d52 -> :sswitch_f2
        0x1e9d5f -> :sswitch_e7
        0x1e9d63 -> :sswitch_dc
        0x6a6b6031 -> :sswitch_d1
        0x6a6b6034 -> :sswitch_c6
        0x6b2deee6 -> :sswitch_bb
        0x7e53ab34 -> :sswitch_ae
    .end sparse-switch

    :pswitch_data_922
    .packed-switch 0x0
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
    .end packed-switch

    :sswitch_data_938
    .sparse-switch
        -0x7fd6c3bd -> :sswitch_8a3
        -0x7fd6c381 -> :sswitch_897
        -0x7fd6c368 -> :sswitch_88b
        -0x7d026749 -> :sswitch_87f
        -0x78929d6a -> :sswitch_873
        -0x75f50a1e -> :sswitch_867
        -0x75f4fe9d -> :sswitch_85b
        -0x736f875c -> :sswitch_84f
        -0x736f83c2 -> :sswitch_841
        -0x736f83c1 -> :sswitch_833
        -0x7327ce1c -> :sswitch_825
        -0x705c574b -> :sswitch_817
        -0x651ebb62 -> :sswitch_809
        -0x6423293b -> :sswitch_7fb
        -0x604f5117 -> :sswitch_7ed
        -0x5f691e13 -> :sswitch_7df
        -0x5ca40cc4 -> :sswitch_7d1
        -0x58520ec1 -> :sswitch_7c3
        -0x58520eba -> :sswitch_7b5
        -0x58520eb9 -> :sswitch_7a7
        -0x4eaed329 -> :sswitch_799
        -0x4892fb4f -> :sswitch_78b
        -0x465b3df3 -> :sswitch_77d
        -0x43e6c939 -> :sswitch_76f
        -0x3ec0fcc5 -> :sswitch_761
        -0x3b33cca0 -> :sswitch_753
        -0x3b33cc9a -> :sswitch_749
        -0x398ae3f6 -> :sswitch_73c
        -0x391f0fb4 -> :sswitch_72f
        -0x346837ae -> :sswitch_721
        -0x323788e3 -> :sswitch_713
        -0x30f57652 -> :sswitch_705
        -0x2f88a116 -> :sswitch_6f7
        -0x2f61ed98 -> :sswitch_6e9
        -0x2efd0837 -> :sswitch_6db
        -0x2e9e9441 -> :sswitch_6cd
        -0x2247b8b1 -> :sswitch_6bf
        -0x1f0fa2b7 -> :sswitch_6b1
        -0x19af3b41 -> :sswitch_6a3
        -0x114fad3e -> :sswitch_695
        -0x10dae90b -> :sswitch_687
        -0x1084b7b7 -> :sswitch_679
        -0xa5988e9 -> :sswitch_66b
        -0x35f9fbf -> :sswitch_65d
        0x84e -> :sswitch_64f
        0xa04 -> :sswitch_641
        0xa9b -> :sswitch_633
        0xa9f -> :sswitch_625
        0xc13 -> :sswitch_617
        0xd9b -> :sswitch_609
        0x11ebd -> :sswitch_5fb
        0x12711 -> :sswitch_5ed
        0x127db -> :sswitch_5df
        0x12beb -> :sswitch_5d1
        0x1334d -> :sswitch_5c3
        0x135c9 -> :sswitch_5b5
        0x13aea -> :sswitch_5a7
        0x158d2 -> :sswitch_599
        0x1821e -> :sswitch_58b
        0x18220 -> :sswitch_57d
        0x18401 -> :sswitch_56f
        0x18c69 -> :sswitch_561
        0x1716e6 -> :sswitch_553
        0x171ac8 -> :sswitch_545
        0x171ac9 -> :sswitch_537
        0x208c61 -> :sswitch_529
        0x208c63 -> :sswitch_51b
        0x208c80 -> :sswitch_50d
        0x208c9f -> :sswitch_4ff
        0x208cbe -> :sswitch_4f1
        0x208cc0 -> :sswitch_4e3
        0x252f5f -> :sswitch_4d5
        0x25981d -> :sswitch_4c7
        0x259b88 -> :sswitch_4b9
        0x290a13 -> :sswitch_4ab
        0x3021fd -> :sswitch_49d
        0x321e47 -> :sswitch_48f
        0x332327 -> :sswitch_481
        0x33ab63 -> :sswitch_473
        0x27691fb -> :sswitch_465
        0x30f8881 -> :sswitch_457
        0x30f8c42 -> :sswitch_449
        0x349f581 -> :sswitch_43b
        0x3ab0ea7 -> :sswitch_42d
        0x3e53ea5 -> :sswitch_41f
        0x3f25a44 -> :sswitch_411
        0x3f25a46 -> :sswitch_403
        0x3f25a49 -> :sswitch_3f5
        0x3f25e05 -> :sswitch_3e7
        0x3f25e07 -> :sswitch_3d9
        0x3f25e09 -> :sswitch_3cb
        0x3f261c6 -> :sswitch_3bd
        0x48dce49 -> :sswitch_3af
        0x48dd589 -> :sswitch_3a1
        0x48dd8af -> :sswitch_393
        0x4d36832 -> :sswitch_385
        0x4f0b0e7 -> :sswitch_377
        0x5e2479e -> :sswitch_369
        0x60acc05 -> :sswitch_35b
        0x6214744 -> :sswitch_34d
        0x9d91379 -> :sswitch_33f
        0xadc0551 -> :sswitch_331
        0xea056b3 -> :sswitch_323
        0x1121dbc3 -> :sswitch_315
        0x1255818c -> :sswitch_307
        0x1263990d -> :sswitch_2f9
        0x12d90f3a -> :sswitch_2eb
        0x12d90f4c -> :sswitch_2dd
        0x12d98b1b -> :sswitch_2cf
        0x12d98b22 -> :sswitch_2c1
        0x1844c711 -> :sswitch_2b3
        0x1e3e8044 -> :sswitch_2a5
        0x2f5336ed -> :sswitch_297
        0x2f54115e -> :sswitch_289
        0x2f541849 -> :sswitch_27b
        0x31cf010e -> :sswitch_26d
        0x36ad82f4 -> :sswitch_25f
        0x391a0b61 -> :sswitch_251
        0x3f3728cd -> :sswitch_243
        0x448ec687 -> :sswitch_235
        0x46260f63 -> :sswitch_227
        0x4c505106 -> :sswitch_219
        0x4de67084 -> :sswitch_20b
        0x506ac5a9 -> :sswitch_1fd
        0x5abad9cd -> :sswitch_1ef
        0x64d2e6e9 -> :sswitch_1e1
        0x64d2eac5 -> :sswitch_1d3
        0x65e4085b -> :sswitch_1c5
        0x6f373556 -> :sswitch_1b7
        0x719f1dcb -> :sswitch_1a9
        0x75d9a0f0 -> :sswitch_19b
        0x7796d144 -> :sswitch_18e
        0x785bcb26 -> :sswitch_181
        0x78fc0e50 -> :sswitch_174
        0x790521fb -> :sswitch_167
        0x7933207f -> :sswitch_15a
        0x7a05a409 -> :sswitch_14d
        0x7a0696bd -> :sswitch_140
        0x7a16dfe7 -> :sswitch_133
        0x7a1f0e95 -> :sswitch_126
    .end sparse-switch

    :pswitch_data_b6a
    .packed-switch 0x0
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
        :pswitch_8f
    .end packed-switch
.end method


# virtual methods
.method public final A(JJ)V
    .registers 6

    invoke-super {p0, p1, p2, p3, p4}, Lo1/u;->A(JJ)V

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-eqz v0, :cond_16

    :try_start_7
    invoke-virtual {v0, p1, p2, p3, p4}, LB1/i;->d(JJ)V
    :try_end_a
    .catch LB1/M; {:try_start_7 .. :try_end_a} :catch_b

    goto :goto_16

    :catch_b
    move-exception p1

    iget-object p2, p1, LB1/M;->a:Landroidx/media3/common/b;

    const/16 p3, 0x1b59

    const/4 p4, 0x0

    invoke-virtual {p0, p1, p2, p4, p3}, Landroidx/media3/exoplayer/e;->g(Ljava/lang/Exception;Landroidx/media3/common/b;ZI)Landroidx/media3/exoplayer/m;

    move-result-object p1

    throw p1

    :cond_16
    :goto_16
    return-void
.end method

.method public final D(FF)V
    .registers 9

    invoke-super {p0, p1, p2}, Lo1/u;->D(FF)V

    iget-object p2, p0, LB1/q;->I1:LB1/i;

    const-wide/16 v0, -0x1

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    if-eqz p2, :cond_37

    iget-object p2, p2, LB1/i;->l:LB1/j;

    iget-object p2, p2, LB1/j;->c:LB1/B;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x0

    cmpl-float v5, p1, v5

    if-lez v5, :cond_1a

    const/4 v5, 0x1

    goto :goto_1b

    :cond_1a
    move v5, v4

    :goto_1b
    invoke-static {v5}, Lm7/u;->a(Z)V

    iget-object p2, p2, LB1/B;->b:LB1/w;

    iget v5, p2, LB1/w;->k:F

    cmpl-float v5, p1, v5

    if-nez v5, :cond_27

    goto :goto_4f

    :cond_27
    iput p1, p2, LB1/w;->k:F

    iget-object p2, p2, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iput p1, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->i:F

    iput-wide v2, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    iput-wide v0, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iput-wide v0, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    invoke-virtual {p2, v4}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d(Z)V

    goto :goto_4f

    :cond_37
    iget-object p2, p0, LB1/q;->D1:LB1/w;

    iget v5, p2, LB1/w;->k:F

    cmpl-float v5, p1, v5

    if-nez v5, :cond_40

    goto :goto_4f

    :cond_40
    iput p1, p2, LB1/w;->k:F

    iget-object p2, p2, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iput p1, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->i:F

    iput-wide v2, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    iput-wide v0, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iput-wide v0, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    invoke-virtual {p2, v4}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d(Z)V

    :goto_4f
    return-void
.end method

.method public final D0()V
    .registers 9

    iget v0, p0, LB1/q;->R1:I

    if-lez v0, :cond_28

    iget-object v0, p0, Landroidx/media3/exoplayer/e;->g:LZ0/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, LB1/q;->Q1:J

    sub-long v2, v0, v2

    iget v4, p0, LB1/q;->R1:I

    iget-object v5, p0, LB1/q;->A1:LW2/p;

    iget-object v6, v5, LW2/p;->b:Ljava/lang/Object;

    check-cast v6, Landroid/os/Handler;

    if-eqz v6, :cond_23

    new-instance v7, LB1/D;

    invoke-direct {v7, v4, v2, v3, v5}, LB1/D;-><init>(IJLW2/p;)V

    invoke-virtual {v6, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_23
    const/4 v2, 0x0

    iput v2, p0, LB1/q;->R1:I

    iput-wide v0, p0, LB1/q;->Q1:J

    :cond_28
    return-void
.end method

.method public final E0(LW0/e0;)V
    .registers 3

    sget-object v0, LW0/e0;->e:LW0/e0;

    invoke-virtual {p1, v0}, LW0/e0;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_17

    iget-object v0, p0, LB1/q;->Y1:LW0/e0;

    invoke-virtual {p1, v0}, LW0/e0;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_17

    iput-object p1, p0, LB1/q;->Y1:LW0/e0;

    iget-object v0, p0, LB1/q;->A1:LW2/p;

    invoke-virtual {v0, p1}, LW2/p;->m(LW0/e0;)V

    :cond_17
    return-void
.end method

.method public final F0()V
    .registers 5

    iget-boolean v0, p0, LB1/q;->a2:Z

    if-eqz v0, :cond_29

    sget v0, LZ0/F;->a:I

    const/16 v1, 0x17

    if-ge v0, v1, :cond_b

    goto :goto_29

    :cond_b
    iget-object v1, p0, Lo1/u;->L:Lo1/k;

    if-nez v1, :cond_10

    return-void

    :cond_10
    new-instance v2, LB1/p;

    invoke-direct {v2, p0, v1}, LB1/p;-><init>(LB1/q;Lo1/k;)V

    iput-object v2, p0, LB1/q;->c2:LB1/p;

    const/16 v2, 0x21

    if-lt v0, v2, :cond_29

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v2, "tunnel-peek"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    invoke-interface {v1, v0}, Lo1/k;->b(Landroid/os/Bundle;)V

    :cond_29
    :goto_29
    return-void
.end method

.method public final G0()V
    .registers 4

    iget-object v0, p0, LB1/q;->L1:Landroid/view/Surface;

    iget-object v1, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    const/4 v2, 0x0

    if-ne v0, v1, :cond_9

    iput-object v2, p0, LB1/q;->L1:Landroid/view/Surface;

    :cond_9
    if-eqz v1, :cond_10

    invoke-virtual {v1}, Landroidx/media3/exoplayer/video/PlaceholderSurface;->release()V

    iput-object v2, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    :cond_10
    return-void
.end method

.method public final H(Lo1/n;Landroidx/media3/common/b;Landroidx/media3/common/b;)Landroidx/media3/exoplayer/g;
    .registers 15

    invoke-virtual {p1, p2, p3}, Lo1/n;->b(Landroidx/media3/common/b;Landroidx/media3/common/b;)Landroidx/media3/exoplayer/g;

    move-result-object v0

    iget-object v1, p0, LB1/q;->F1:LB1/o;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v2, p3, Landroidx/media3/common/b;->t:I

    iget v3, v1, LB1/o;->a:I

    iget v4, v0, Landroidx/media3/exoplayer/g;->e:I

    if-gt v2, v3, :cond_17

    iget v2, p3, Landroidx/media3/common/b;->u:I

    iget v3, v1, LB1/o;->b:I

    if-le v2, v3, :cond_19

    :cond_17
    or-int/lit16 v4, v4, 0x100

    :cond_19
    invoke-static {p1, p3}, LB1/q;->C0(Lo1/n;Landroidx/media3/common/b;)I

    move-result v2

    iget v1, v1, LB1/o;->c:I

    if-le v2, v1, :cond_23

    or-int/lit8 v4, v4, 0x40

    :cond_23
    move v10, v4

    new-instance v1, Landroidx/media3/exoplayer/g;

    if-eqz v10, :cond_2b

    const/4 v0, 0x0

    :goto_29
    move v9, v0

    goto :goto_2e

    :cond_2b
    iget v0, v0, Landroidx/media3/exoplayer/g;->d:I

    goto :goto_29

    :goto_2e
    iget-object v6, p1, Lo1/n;->a:Ljava/lang/String;

    move-object v5, v1

    move-object v7, p2

    move-object v8, p3

    invoke-direct/range {v5 .. v10}, Landroidx/media3/exoplayer/g;-><init>(Ljava/lang/String;Landroidx/media3/common/b;Landroidx/media3/common/b;II)V

    return-object v1
.end method

.method public final H0(Lo1/k;I)V
    .registers 8

    const-string v0, "releaseOutputBuffer"

    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    const/4 v0, 0x1

    invoke-interface {p1, p2, v0}, Lo1/k;->m(IZ)V

    invoke-static {}, Landroid/os/Trace;->endSection()V

    iget-object p1, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget p2, p1, Landroidx/media3/exoplayer/f;->e:I

    add-int/2addr p2, v0

    iput p2, p1, Landroidx/media3/exoplayer/f;->e:I

    const/4 p1, 0x0

    iput p1, p0, LB1/q;->S1:I

    iget-object p2, p0, LB1/q;->I1:LB1/i;

    if-nez p2, :cond_54

    iget-object p2, p0, LB1/q;->X1:LW0/e0;

    invoke-virtual {p0, p2}, LB1/q;->E0(LW0/e0;)V

    iget-object p2, p0, LB1/q;->D1:LB1/w;

    iget v1, p2, LB1/w;->e:I

    const/4 v2, 0x3

    if-eq v1, v2, :cond_27

    move p1, v0

    :cond_27
    iput v2, p2, LB1/w;->e:I

    iget-object v1, p2, LB1/w;->l:LZ0/y;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-static {v1, v2}, LZ0/F;->Q(J)J

    move-result-wide v1

    iput-wide v1, p2, LB1/w;->g:J

    if-eqz p1, :cond_54

    iget-object p1, p0, LB1/q;->L1:Landroid/view/Surface;

    if-eqz p1, :cond_54

    iget-object p2, p0, LB1/q;->A1:LW2/p;

    iget-object v1, p2, LW2/p;->b:Ljava/lang/Object;

    check-cast v1, Landroid/os/Handler;

    if-eqz v1, :cond_52

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    new-instance v4, LB1/E;

    invoke-direct {v4, p2, p1, v2, v3}, LB1/E;-><init>(LW2/p;Ljava/lang/Object;J)V

    invoke-virtual {v1, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_52
    iput-boolean v0, p0, LB1/q;->O1:Z

    :cond_54
    return-void
.end method

.method public final I(Ljava/lang/IllegalStateException;Lo1/n;)Lo1/m;
    .registers 5

    new-instance v0, LB1/m;

    iget-object v1, p0, LB1/q;->L1:Landroid/view/Surface;

    invoke-direct {v0, p1, p2}, Lo1/m;-><init>(Ljava/lang/IllegalStateException;Lo1/n;)V

    invoke-static {v1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    if-eqz v1, :cond_f

    invoke-virtual {v1}, Landroid/view/Surface;->isValid()Z

    :cond_f
    return-object v0
.end method

.method public final I0(Lo1/k;IJ)V
    .registers 8

    const-string v0, "releaseOutputBuffer"

    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    invoke-interface {p1, p2, p3, p4}, Lo1/k;->i(IJ)V

    invoke-static {}, Landroid/os/Trace;->endSection()V

    iget-object p1, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget p2, p1, Landroidx/media3/exoplayer/f;->e:I

    const/4 p3, 0x1

    add-int/2addr p2, p3

    iput p2, p1, Landroidx/media3/exoplayer/f;->e:I

    const/4 p1, 0x0

    iput p1, p0, LB1/q;->S1:I

    iget-object p2, p0, LB1/q;->I1:LB1/i;

    if-nez p2, :cond_54

    iget-object p2, p0, LB1/q;->X1:LW0/e0;

    invoke-virtual {p0, p2}, LB1/q;->E0(LW0/e0;)V

    iget-object p2, p0, LB1/q;->D1:LB1/w;

    iget p4, p2, LB1/w;->e:I

    const/4 v0, 0x3

    if-eq p4, v0, :cond_27

    move p1, p3

    :cond_27
    iput v0, p2, LB1/w;->e:I

    iget-object p4, p2, LB1/w;->l:LZ0/y;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    invoke-static {v0, v1}, LZ0/F;->Q(J)J

    move-result-wide v0

    iput-wide v0, p2, LB1/w;->g:J

    if-eqz p1, :cond_54

    iget-object p1, p0, LB1/q;->L1:Landroid/view/Surface;

    if-eqz p1, :cond_54

    iget-object p2, p0, LB1/q;->A1:LW2/p;

    iget-object p4, p2, LW2/p;->b:Ljava/lang/Object;

    check-cast p4, Landroid/os/Handler;

    if-eqz p4, :cond_52

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    new-instance v2, LB1/E;

    invoke-direct {v2, p2, p1, v0, v1}, LB1/E;-><init>(LW2/p;Ljava/lang/Object;J)V

    invoke-virtual {p4, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_52
    iput-boolean p3, p0, LB1/q;->O1:Z

    :cond_54
    return-void
.end method

.method public final J0(Lo1/n;)Z
    .registers 4

    sget v0, LZ0/F;->a:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_20

    iget-boolean v0, p0, LB1/q;->a2:Z

    if-nez v0, :cond_20

    iget-object v0, p1, Lo1/n;->a:Ljava/lang/String;

    invoke-static {v0}, LB1/q;->z0(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_20

    iget-boolean p1, p1, Lo1/n;->f:Z

    if-eqz p1, :cond_1e

    iget-object p1, p0, LB1/q;->y1:Landroid/content/Context;

    invoke-static {p1}, Landroidx/media3/exoplayer/video/PlaceholderSurface;->a(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_20

    :cond_1e
    const/4 p1, 0x1

    goto :goto_21

    :cond_20
    const/4 p1, 0x0

    :goto_21
    return p1
.end method

.method public final K0(Lo1/k;I)V
    .registers 4

    const-string v0, "skipVideoBuffer"

    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-interface {p1, p2, v0}, Lo1/k;->m(IZ)V

    invoke-static {}, Landroid/os/Trace;->endSection()V

    iget-object p1, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget p2, p1, Landroidx/media3/exoplayer/f;->f:I

    add-int/lit8 p2, p2, 0x1

    iput p2, p1, Landroidx/media3/exoplayer/f;->f:I

    return-void
.end method

.method public final L0(II)V
    .registers 5

    iget-object v0, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget v1, v0, Landroidx/media3/exoplayer/f;->h:I

    add-int/2addr v1, p1

    iput v1, v0, Landroidx/media3/exoplayer/f;->h:I

    add-int/2addr p1, p2

    iget p2, v0, Landroidx/media3/exoplayer/f;->g:I

    add-int/2addr p2, p1

    iput p2, v0, Landroidx/media3/exoplayer/f;->g:I

    iget p2, p0, LB1/q;->R1:I

    add-int/2addr p2, p1

    iput p2, p0, LB1/q;->R1:I

    iget p2, p0, LB1/q;->S1:I

    add-int/2addr p2, p1

    iput p2, p0, LB1/q;->S1:I

    iget p1, v0, Landroidx/media3/exoplayer/f;->i:I

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, v0, Landroidx/media3/exoplayer/f;->i:I

    iget p1, p0, LB1/q;->B1:I

    if-lez p1, :cond_2a

    iget p2, p0, LB1/q;->R1:I

    if-lt p2, p1, :cond_2a

    invoke-virtual {p0}, LB1/q;->D0()V

    :cond_2a
    return-void
.end method

.method public final M0(J)V
    .registers 6

    iget-object v0, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget-wide v1, v0, Landroidx/media3/exoplayer/f;->k:J

    add-long/2addr v1, p1

    iput-wide v1, v0, Landroidx/media3/exoplayer/f;->k:J

    iget v1, v0, Landroidx/media3/exoplayer/f;->l:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, Landroidx/media3/exoplayer/f;->l:I

    iget-wide v0, p0, LB1/q;->U1:J

    add-long/2addr v0, p1

    iput-wide v0, p0, LB1/q;->U1:J

    iget p1, p0, LB1/q;->V1:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, LB1/q;->V1:I

    return-void
.end method

.method public final Q(Lf1/f;)I
    .registers 6

    sget v0, LZ0/F;->a:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_15

    iget-boolean v0, p0, LB1/q;->a2:Z

    if-eqz v0, :cond_15

    iget-wide v0, p1, Lf1/f;->g:J

    iget-wide v2, p0, Landroidx/media3/exoplayer/e;->l:J

    cmp-long p1, v0, v2

    if-gez p1, :cond_15

    const/16 p1, 0x20

    return p1

    :cond_15
    const/4 p1, 0x0

    return p1
.end method

.method public final R()Z
    .registers 3

    iget-boolean v0, p0, LB1/q;->a2:Z

    if-eqz v0, :cond_c

    sget v0, LZ0/F;->a:I

    const/16 v1, 0x17

    if-ge v0, v1, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public final S(F[Landroidx/media3/common/b;)F
    .registers 9

    array-length v0, p2

    const/high16 v1, -0x40800000    # -1.0f

    const/4 v2, 0x0

    move v3, v1

    :goto_5
    if-ge v2, v0, :cond_16

    aget-object v4, p2, v2

    iget v4, v4, Landroidx/media3/common/b;->v:F

    cmpl-float v5, v4, v1

    if-eqz v5, :cond_13

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v3

    :cond_13
    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_16
    cmpl-float p2, v3, v1

    if-nez p2, :cond_1b

    goto :goto_1d

    :cond_1b
    mul-float v1, v3, p1

    :goto_1d
    return v1
.end method

.method public final T(Lo1/v;Landroidx/media3/common/b;Z)Ljava/util/ArrayList;
    .registers 6

    iget-object v0, p0, LB1/q;->y1:Landroid/content/Context;

    iget-boolean v1, p0, LB1/q;->a2:Z

    invoke-static {v0, p1, p2, p3, v1}, LB1/q;->B0(Landroid/content/Context;Lo1/v;Landroidx/media3/common/b;ZZ)Ljava/util/List;

    move-result-object p1

    sget-object p3, Lo1/B;->a:Ljava/util/regex/Pattern;

    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance p1, LC/C0;

    const/16 v0, 0x8

    invoke-direct {p1, v0, p2}, LC/C0;-><init>(ILjava/lang/Object;)V

    new-instance p2, Lo1/w;

    invoke-direct {p2, p1}, Lo1/w;-><init>(Lo1/A;)V

    invoke-static {p3, p2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    return-object p3
.end method

.method public final U(Lo1/n;Landroidx/media3/common/b;Landroid/media/MediaCrypto;F)Lo1/i;
    .registers 28

    move-object/from16 v0, p0

    move-object/from16 v2, p1

    move-object/from16 v4, p2

    move/from16 v1, p4

    iget-object v3, v0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    iget-boolean v5, v2, Lo1/n;->f:Z

    if-eqz v3, :cond_15

    iget-boolean v3, v3, Landroidx/media3/exoplayer/video/PlaceholderSurface;->a:Z

    if-eq v3, v5, :cond_15

    invoke-virtual/range {p0 .. p0}, LB1/q;->G0()V

    :cond_15
    iget-object v3, v0, Landroidx/media3/exoplayer/e;->j:[Landroidx/media3/common/b;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v6, v4, Landroidx/media3/common/b;->t:I

    invoke-static/range {p1 .. p2}, LB1/q;->C0(Lo1/n;Landroidx/media3/common/b;)I

    move-result v7

    array-length v8, v3

    const/4 v9, 0x1

    iget v12, v4, Landroidx/media3/common/b;->v:F

    iget v13, v4, Landroidx/media3/common/b;->t:I

    iget-object v14, v4, Landroidx/media3/common/b;->A:LW0/j;

    iget v15, v4, Landroidx/media3/common/b;->u:I

    const/4 v10, -0x1

    if-ne v8, v9, :cond_4b

    if-eq v7, v10, :cond_3e

    invoke-static/range {p1 .. p2}, LB1/q;->A0(Lo1/n;Landroidx/media3/common/b;)I

    move-result v3

    if-eq v3, v10, :cond_3e

    int-to-float v7, v7

    const/high16 v8, 0x3fc00000    # 1.5f

    mul-float/2addr v7, v8

    float-to-int v7, v7

    invoke-static {v7, v3}, Ljava/lang/Math;->min(II)I

    move-result v7

    :cond_3e
    new-instance v3, LB1/o;

    invoke-direct {v3, v6, v15, v7}, LB1/o;-><init>(III)V

    move/from16 v20, v5

    move-object/from16 v16, v14

    move/from16 v17, v15

    goto/16 :goto_1ae

    :cond_4b
    array-length v8, v3

    move v11, v15

    const/4 v9, 0x0

    const/16 v16, 0x0

    :goto_50
    if-ge v9, v8, :cond_a5

    aget-object v10, v3, v9

    move-object/from16 v18, v3

    if-eqz v14, :cond_67

    iget-object v3, v10, Landroidx/media3/common/b;->A:LW0/j;

    if-nez v3, :cond_67

    invoke-virtual {v10}, Landroidx/media3/common/b;->a()LW0/o;

    move-result-object v3

    iput-object v14, v3, LW0/o;->z:LW0/j;

    new-instance v10, Landroidx/media3/common/b;

    invoke-direct {v10, v3}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    :cond_67
    invoke-virtual {v2, v4, v10}, Lo1/n;->b(Landroidx/media3/common/b;Landroidx/media3/common/b;)Landroidx/media3/exoplayer/g;

    move-result-object v3

    iget v3, v3, Landroidx/media3/exoplayer/g;->d:I

    if-eqz v3, :cond_96

    iget v3, v10, Landroidx/media3/common/b;->u:I

    move/from16 v19, v8

    iget v8, v10, Landroidx/media3/common/b;->t:I

    move/from16 v20, v5

    const/4 v5, -0x1

    if-eq v8, v5, :cond_80

    if-ne v3, v5, :cond_7d

    goto :goto_80

    :cond_7d
    const/16 v17, 0x0

    goto :goto_82

    :cond_80
    :goto_80
    const/16 v17, 0x1

    :goto_82
    or-int v16, v16, v17

    invoke-static {v6, v8}, Ljava/lang/Math;->max(II)I

    move-result v6

    invoke-static {v11, v3}, Ljava/lang/Math;->max(II)I

    move-result v11

    invoke-static {v2, v10}, LB1/q;->C0(Lo1/n;Landroidx/media3/common/b;)I

    move-result v3

    invoke-static {v7, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    move v7, v3

    goto :goto_9b

    :cond_96
    move/from16 v20, v5

    move/from16 v19, v8

    const/4 v5, -0x1

    :goto_9b
    add-int/lit8 v9, v9, 0x1

    move v10, v5

    move-object/from16 v3, v18

    move/from16 v8, v19

    move/from16 v5, v20

    goto :goto_50

    :cond_a5
    move/from16 v20, v5

    if-eqz v16, :cond_1a5

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, "Resolutions unknown. Codec max resolution: "

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "x"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v8, "MediaCodecVideoRenderer"

    invoke-static {v8, v3}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    if-le v15, v13, :cond_c8

    const/4 v3, 0x1

    goto :goto_c9

    :cond_c8
    const/4 v3, 0x0

    :goto_c9
    if-eqz v3, :cond_cd

    move v9, v15

    goto :goto_ce

    :cond_cd
    move v9, v13

    :goto_ce
    if-eqz v3, :cond_d2

    move v10, v13

    goto :goto_d3

    :cond_d2
    move v10, v15

    :goto_d3
    int-to-float v1, v10

    move-object/from16 v16, v14

    int-to-float v14, v9

    div-float/2addr v1, v14

    sget-object v14, LB1/q;->e2:[I

    move/from16 v17, v15

    const/4 v4, 0x0

    :goto_dd
    const/16 v15, 0x9

    if-ge v4, v15, :cond_169

    aget v15, v14, v4

    move-object/from16 v18, v14

    int-to-float v14, v15

    mul-float/2addr v14, v1

    float-to-int v14, v14

    if-le v15, v9, :cond_169

    if-gt v14, v10, :cond_ee

    goto/16 :goto_169

    :cond_ee
    move/from16 v19, v1

    sget v1, LZ0/F;->a:I

    move/from16 v21, v9

    const/16 v9, 0x15

    if-lt v1, v9, :cond_137

    if-eqz v3, :cond_fc

    move v1, v14

    goto :goto_fd

    :cond_fc
    move v1, v15

    :goto_fd
    if-eqz v3, :cond_100

    goto :goto_101

    :cond_100
    move v15, v14

    :goto_101
    iget-object v9, v2, Lo1/n;->d:Landroid/media/MediaCodecInfo$CodecCapabilities;

    if-nez v9, :cond_109

    :goto_105
    move/from16 v22, v10

    const/4 v10, 0x0

    goto :goto_129

    :cond_109
    invoke-virtual {v9}, Landroid/media/MediaCodecInfo$CodecCapabilities;->getVideoCapabilities()Landroid/media/MediaCodecInfo$VideoCapabilities;

    move-result-object v9

    if-nez v9, :cond_110

    goto :goto_105

    :cond_110
    invoke-virtual {v9}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getWidthAlignment()I

    move-result v14

    invoke-virtual {v9}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getHeightAlignment()I

    move-result v9

    move/from16 v22, v10

    new-instance v10, Landroid/graphics/Point;

    invoke-static {v1, v14}, LZ0/F;->g(II)I

    move-result v1

    mul-int/2addr v1, v14

    invoke-static {v15, v9}, LZ0/F;->g(II)I

    move-result v14

    mul-int/2addr v14, v9

    invoke-direct {v10, v1, v14}, Landroid/graphics/Point;-><init>(II)V

    :goto_129
    if-eqz v10, :cond_15d

    iget v1, v10, Landroid/graphics/Point;->x:I

    iget v9, v10, Landroid/graphics/Point;->y:I

    float-to-double v14, v12

    invoke-virtual {v2, v1, v9, v14, v15}, Lo1/n;->f(IID)Z

    move-result v1

    if-eqz v1, :cond_15d

    goto :goto_16a

    :cond_137
    move/from16 v22, v10

    const/16 v1, 0x10

    :try_start_13b
    invoke-static {v15, v1}, LZ0/F;->g(II)I

    move-result v9

    mul-int/2addr v9, v1

    invoke-static {v14, v1}, LZ0/F;->g(II)I

    move-result v10

    mul-int/2addr v10, v1

    mul-int v1, v9, v10

    invoke-static {}, Lo1/B;->k()I

    move-result v14

    if-gt v1, v14, :cond_15d

    new-instance v1, Landroid/graphics/Point;

    if-eqz v3, :cond_153

    move v4, v10

    goto :goto_154

    :cond_153
    move v4, v9

    :goto_154
    if-eqz v3, :cond_157

    goto :goto_158

    :cond_157
    move v9, v10

    :goto_158
    invoke-direct {v1, v4, v9}, Landroid/graphics/Point;-><init>(II)V
    :try_end_15b
    .catch Lo1/y; {:try_start_13b .. :try_end_15b} :catch_169

    move-object v10, v1

    goto :goto_16a

    :cond_15d
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v14, v18

    move/from16 v1, v19

    move/from16 v9, v21

    move/from16 v10, v22

    goto/16 :goto_dd

    :catch_169
    :cond_169
    :goto_169
    const/4 v10, 0x0

    :goto_16a
    if-eqz v10, :cond_1a9

    iget v1, v10, Landroid/graphics/Point;->x:I

    invoke-static {v6, v1}, Ljava/lang/Math;->max(II)I

    move-result v6

    iget v1, v10, Landroid/graphics/Point;->y:I

    invoke-static {v11, v1}, Ljava/lang/Math;->max(II)I

    move-result v11

    invoke-virtual/range {p2 .. p2}, Landroidx/media3/common/b;->a()LW0/o;

    move-result-object v1

    iput v6, v1, LW0/o;->s:I

    iput v11, v1, LW0/o;->t:I

    new-instance v3, Landroidx/media3/common/b;

    invoke-direct {v3, v1}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    invoke-static {v2, v3}, LB1/q;->A0(Lo1/n;Landroidx/media3/common/b;)I

    move-result v1

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v7

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "Codec max resolution adjusted to: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v8, v1}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1a9

    :cond_1a5
    move-object/from16 v16, v14

    move/from16 v17, v15

    :cond_1a9
    :goto_1a9
    new-instance v3, LB1/o;

    invoke-direct {v3, v6, v11, v7}, LB1/o;-><init>(III)V

    :goto_1ae
    iput-object v3, v0, LB1/q;->F1:LB1/o;

    iget-boolean v1, v0, LB1/q;->a2:Z

    if-eqz v1, :cond_1b7

    iget v1, v0, LB1/q;->b2:I

    goto :goto_1b8

    :cond_1b7
    const/4 v1, 0x0

    :goto_1b8
    new-instance v4, Landroid/media/MediaFormat;

    invoke-direct {v4}, Landroid/media/MediaFormat;-><init>()V

    const-string v5, "mime"

    iget-object v6, v2, Lo1/n;->c:Ljava/lang/String;

    invoke-virtual {v4, v5, v6}, Landroid/media/MediaFormat;->setString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v5, "width"

    invoke-virtual {v4, v5, v13}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v5, "height"

    move/from16 v6, v17

    invoke-virtual {v4, v5, v6}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    move-object/from16 v5, p2

    iget-object v6, v5, Landroidx/media3/common/b;->q:Ljava/util/List;

    invoke-static {v4, v6}, Lm7/o;->c(Landroid/media/MediaFormat;Ljava/util/List;)V

    const/high16 v6, -0x40800000    # -1.0f

    cmpl-float v7, v12, v6

    if-eqz v7, :cond_1e2

    const-string v7, "frame-rate"

    invoke-virtual {v4, v7, v12}, Landroid/media/MediaFormat;->setFloat(Ljava/lang/String;F)V

    :cond_1e2
    const-string v7, "rotation-degrees"

    iget v8, v5, Landroidx/media3/common/b;->w:I

    invoke-static {v4, v7, v8}, Lm7/o;->b(Landroid/media/MediaFormat;Ljava/lang/String;I)V

    if-eqz v16, :cond_20f

    const-string v7, "color-transfer"

    move-object/from16 v8, v16

    iget v9, v8, LW0/j;->c:I

    invoke-static {v4, v7, v9}, Lm7/o;->b(Landroid/media/MediaFormat;Ljava/lang/String;I)V

    const-string v7, "color-standard"

    iget v9, v8, LW0/j;->a:I

    invoke-static {v4, v7, v9}, Lm7/o;->b(Landroid/media/MediaFormat;Ljava/lang/String;I)V

    const-string v7, "color-range"

    iget v9, v8, LW0/j;->b:I

    invoke-static {v4, v7, v9}, Lm7/o;->b(Landroid/media/MediaFormat;Ljava/lang/String;I)V

    iget-object v7, v8, LW0/j;->d:[B

    if-eqz v7, :cond_20f

    invoke-static {v7}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v7

    const-string v8, "hdr-static-info"

    invoke-virtual {v4, v8, v7}, Landroid/media/MediaFormat;->setByteBuffer(Ljava/lang/String;Ljava/nio/ByteBuffer;)V

    :cond_20f
    const-string v7, "video/dolby-vision"

    iget-object v8, v5, Landroidx/media3/common/b;->n:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_22c

    invoke-static/range {p2 .. p2}, Lo1/B;->d(Landroidx/media3/common/b;)Landroid/util/Pair;

    move-result-object v7

    if-eqz v7, :cond_22c

    iget-object v7, v7, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    const-string v8, "profile"

    invoke-static {v4, v8, v7}, Lm7/o;->b(Landroid/media/MediaFormat;Ljava/lang/String;I)V

    :cond_22c
    iget v7, v3, LB1/o;->a:I

    const-string v8, "max-width"

    invoke-virtual {v4, v8, v7}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v7, "max-height"

    iget v8, v3, LB1/o;->b:I

    invoke-virtual {v4, v7, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v7, "max-input-size"

    iget v3, v3, LB1/o;->c:I

    invoke-static {v4, v7, v3}, Lm7/o;->b(Landroid/media/MediaFormat;Ljava/lang/String;I)V

    sget v3, LZ0/F;->a:I

    const/16 v7, 0x17

    if-lt v3, v7, :cond_258

    const-string v7, "priority"

    const/4 v8, 0x0

    invoke-virtual {v4, v7, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    move/from16 v7, p4

    cmpl-float v6, v7, v6

    if-eqz v6, :cond_258

    const-string v6, "operating-rate"

    invoke-virtual {v4, v6, v7}, Landroid/media/MediaFormat;->setFloat(Ljava/lang/String;F)V

    :cond_258
    iget-boolean v6, v0, LB1/q;->C1:Z

    if-eqz v6, :cond_269

    const-string v6, "no-post-process"

    const/4 v7, 0x1

    invoke-virtual {v4, v6, v7}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v6, "auto-frc"

    const/4 v8, 0x0

    invoke-virtual {v4, v6, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    goto :goto_26a

    :cond_269
    const/4 v7, 0x1

    :goto_26a
    if-eqz v1, :cond_276

    const-string v6, "tunneled-playback"

    invoke-virtual {v4, v6, v7}, Landroid/media/MediaFormat;->setFeatureEnabled(Ljava/lang/String;Z)V

    const-string v6, "audio-session-id"

    invoke-virtual {v4, v6, v1}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    :cond_276
    const/16 v1, 0x23

    if-lt v3, v1, :cond_287

    iget v1, v0, LB1/q;->Z1:I

    neg-int v1, v1

    const/4 v3, 0x0

    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    const-string v3, "importance"

    invoke-virtual {v4, v3, v1}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    :cond_287
    iget-object v1, v0, LB1/q;->L1:Landroid/view/Surface;

    if-nez v1, :cond_2aa

    invoke-virtual/range {p0 .. p1}, LB1/q;->J0(Lo1/n;)Z

    move-result v1

    if-eqz v1, :cond_2a4

    iget-object v1, v0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-nez v1, :cond_29f

    iget-object v1, v0, LB1/q;->y1:Landroid/content/Context;

    move/from16 v3, v20

    invoke-static {v1, v3}, Landroidx/media3/exoplayer/video/PlaceholderSurface;->b(Landroid/content/Context;Z)Landroidx/media3/exoplayer/video/PlaceholderSurface;

    move-result-object v1

    iput-object v1, v0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    :cond_29f
    iget-object v1, v0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    iput-object v1, v0, LB1/q;->L1:Landroid/view/Surface;

    goto :goto_2aa

    :cond_2a4
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1}, Ljava/lang/IllegalStateException;-><init>()V

    throw v1

    :cond_2aa
    :goto_2aa
    iget-object v1, v0, LB1/q;->I1:LB1/i;

    if-eqz v1, :cond_2bc

    iget-object v1, v1, LB1/i;->a:Landroid/content/Context;

    invoke-static {v1}, LZ0/F;->N(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_2bc

    const-string v1, "allow-frame-drop"

    const/4 v3, 0x0

    invoke-virtual {v4, v1, v3}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    :cond_2bc
    iget-object v1, v0, LB1/q;->I1:LB1/i;

    if-nez v1, :cond_2d1

    iget-object v6, v0, LB1/q;->L1:Landroid/view/Surface;

    new-instance v7, Lo1/i;

    move-object v1, v7

    move-object/from16 v2, p1

    move-object v3, v4

    move-object/from16 v4, p2

    move-object v5, v6

    move-object/from16 v6, p3

    invoke-direct/range {v1 .. v6}, Lo1/i;-><init>(Lo1/n;Landroid/media/MediaFormat;Landroidx/media3/common/b;Landroid/view/Surface;Landroid/media/MediaCrypto;)V

    return-object v7

    :cond_2d1
    const/4 v1, 0x0

    invoke-static {v1}, Lm7/u;->e(Z)V

    const/4 v1, 0x0

    invoke-static {v1}, Lm7/u;->g(Ljava/lang/Object;)V

    throw v1
.end method

.method public final V(Lf1/f;)V
    .registers 9

    iget-boolean v0, p0, LB1/q;->H1:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    iget-object p1, p1, Lf1/f;->h:Ljava/nio/ByteBuffer;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v1, 0x7

    if-lt v0, v1, :cond_59

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v2

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v3

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {p1, v5}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/16 v6, -0x4b

    if-ne v0, v6, :cond_59

    const/16 v0, 0x3c

    if-ne v1, v0, :cond_59

    const/4 v0, 0x1

    if-ne v2, v0, :cond_59

    const/4 v1, 0x4

    if-ne v3, v1, :cond_59

    if-eqz v4, :cond_3b

    if-ne v4, v0, :cond_59

    :cond_3b
    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    new-array v0, v0, [B

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    invoke-virtual {p1, v5}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget-object p1, p0, Lo1/u;->L:Lo1/k;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const-string v2, "hdr10-plus-info"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V

    invoke-interface {p1, v1}, Lo1/k;->b(Landroid/os/Bundle;)V

    :cond_59
    return-void
.end method

.method public final a0(Ljava/lang/Exception;)V
    .registers 6

    const-string v0, "MediaCodecVideoRenderer"

    const-string v1, "Video codec error"

    invoke-static {v0, v1, p1}, LZ0/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, p0, LB1/q;->A1:LW2/p;

    iget-object v1, v0, LW2/p;->b:Ljava/lang/Object;

    check-cast v1, Landroid/os/Handler;

    if-eqz v1, :cond_18

    new-instance v2, LB1/G;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v0, p1}, LB1/G;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_18
    return-void
.end method

.method public final b0(Ljava/lang/String;JJ)V
    .registers 15

    iget-object v1, p0, LB1/q;->A1:LW2/p;

    iget-object v0, v1, LW2/p;->b:Ljava/lang/Object;

    move-object v7, v0

    check-cast v7, Landroid/os/Handler;

    if-eqz v7, :cond_15

    new-instance v8, LB1/C;

    move-object v0, v8

    move-object v2, p1

    move-wide v3, p2

    move-wide v5, p4

    invoke-direct/range {v0 .. v6}, LB1/C;-><init>(LW2/p;Ljava/lang/String;JJ)V

    invoke-virtual {v7, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_15
    invoke-static {p1}, LB1/q;->z0(Ljava/lang/String;)Z

    move-result p1

    iput-boolean p1, p0, LB1/q;->G1:Z

    iget-object p1, p0, Lo1/u;->S:Lo1/n;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget p2, LZ0/F;->a:I

    const/16 p3, 0x1d

    const/4 p4, 0x0

    if-lt p2, p3, :cond_4c

    const-string p2, "video/x-vnd.on2.vp9"

    iget-object p3, p1, Lo1/n;->b:Ljava/lang/String;

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_4c

    iget-object p1, p1, Lo1/n;->d:Landroid/media/MediaCodecInfo$CodecCapabilities;

    if-eqz p1, :cond_39

    iget-object p1, p1, Landroid/media/MediaCodecInfo$CodecCapabilities;->profileLevels:[Landroid/media/MediaCodecInfo$CodecProfileLevel;

    if-nez p1, :cond_3b

    :cond_39
    new-array p1, p4, [Landroid/media/MediaCodecInfo$CodecProfileLevel;

    :cond_3b
    array-length p2, p1

    move p3, p4

    :goto_3d
    if-ge p3, p2, :cond_4c

    aget-object p5, p1, p3

    iget p5, p5, Landroid/media/MediaCodecInfo$CodecProfileLevel;->profile:I

    const/16 v0, 0x4000

    if-ne p5, v0, :cond_49

    const/4 p4, 0x1

    goto :goto_4c

    :cond_49
    add-int/lit8 p3, p3, 0x1

    goto :goto_3d

    :cond_4c
    :goto_4c
    iput-boolean p4, p0, LB1/q;->H1:Z

    invoke-virtual {p0}, LB1/q;->F0()V

    return-void
.end method

.method public final c0(Ljava/lang/String;)V
    .registers 6

    iget-object v0, p0, LB1/q;->A1:LW2/p;

    iget-object v1, v0, LW2/p;->b:Ljava/lang/Object;

    check-cast v1, Landroid/os/Handler;

    if-eqz v1, :cond_11

    new-instance v2, LB1/K;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v0, p1}, LB1/K;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_11
    return-void
.end method

.method public final d(ILjava/lang/Object;)V
    .registers 10

    const/4 v0, 0x1

    iget-object v1, p0, LB1/q;->D1:LB1/w;

    const/4 v2, 0x0

    if-eq p1, v0, :cond_e8

    const/4 v3, 0x7

    if-eq p1, v3, :cond_d7

    const/16 v3, 0xa

    if-eq p1, v3, :cond_bf

    const/16 v3, 0x10

    if-eq p1, v3, :cond_92

    const/4 v2, 0x4

    if-eq p1, v2, :cond_7e

    const/4 v2, 0x5

    if-eq p1, v2, :cond_66

    const/16 v0, 0xd

    if-eq p1, v0, :cond_46

    const/16 v0, 0xe

    if-eq p1, v0, :cond_29

    const/16 v0, 0xb

    if-ne p1, v0, :cond_1a7

    check-cast p2, Landroidx/media3/exoplayer/M;

    iput-object p2, p0, Lo1/u;->G:Landroidx/media3/exoplayer/M;

    goto/16 :goto_1a7

    :cond_29
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, LZ0/x;

    iget p1, p2, LZ0/x;->a:I

    if-eqz p1, :cond_1a7

    iget p1, p2, LZ0/x;->b:I

    if-eqz p1, :cond_1a7

    iput-object p2, p0, LB1/q;->N1:LZ0/x;

    iget-object p1, p0, LB1/q;->I1:LB1/i;

    if-eqz p1, :cond_1a7

    iget-object v0, p0, LB1/q;->L1:Landroid/view/Surface;

    invoke-static {v0}, Lm7/u;->g(Ljava/lang/Object;)V

    invoke-virtual {p1, v0, p2}, LB1/i;->e(Landroid/view/Surface;LZ0/x;)V

    goto/16 :goto_1a7

    :cond_46
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/util/List;

    iput-object p2, p0, LB1/q;->K1:Ljava/util/List;

    iget-object p1, p0, LB1/q;->I1:LB1/i;

    if-eqz p1, :cond_1a7

    iget-object v0, p1, LB1/i;->c:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5b

    goto/16 :goto_1a7

    :cond_5b
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p1}, LB1/i;->c()V

    goto/16 :goto_1a7

    :cond_66
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iget-object p2, v1, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iget v1, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->j:I

    if-ne v1, p1, :cond_77

    goto/16 :goto_1a7

    :cond_77
    iput p1, p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->j:I

    invoke-virtual {p2, v0}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d(Z)V

    goto/16 :goto_1a7

    :cond_7e
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iput p1, p0, LB1/q;->P1:I

    iget-object p2, p0, Lo1/u;->L:Lo1/k;

    if-eqz p2, :cond_1a7

    invoke-interface {p2, p1}, Lo1/k;->n(I)V

    goto/16 :goto_1a7

    :cond_92
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iput p1, p0, LB1/q;->Z1:I

    iget-object p1, p0, Lo1/u;->L:Lo1/k;

    if-nez p1, :cond_a3

    goto/16 :goto_1a7

    :cond_a3
    sget p2, LZ0/F;->a:I

    const/16 v0, 0x23

    if-lt p2, v0, :cond_1a7

    new-instance p2, Landroid/os/Bundle;

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    iget v0, p0, LB1/q;->Z1:I

    neg-int v0, v0

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const-string v1, "importance"

    invoke-virtual {p2, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    invoke-interface {p1, p2}, Lo1/k;->b(Landroid/os/Bundle;)V

    goto/16 :goto_1a7

    :cond_bf
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iget p2, p0, LB1/q;->b2:I

    if-eq p2, p1, :cond_1a7

    iput p1, p0, LB1/q;->b2:I

    iget-boolean p1, p0, LB1/q;->a2:Z

    if-eqz p1, :cond_1a7

    invoke-virtual {p0}, Lo1/u;->n0()V

    goto/16 :goto_1a7

    :cond_d7
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, LB1/u;

    iput-object p2, p0, LB1/q;->d2:LB1/u;

    iget-object p1, p0, LB1/q;->I1:LB1/i;

    if-eqz p1, :cond_1a7

    iget-object p1, p1, LB1/i;->l:LB1/j;

    iput-object p2, p1, LB1/j;->h:LB1/u;

    goto/16 :goto_1a7

    :cond_e8
    instance-of p1, p2, Landroid/view/Surface;

    const/4 v3, 0x0

    if-eqz p1, :cond_f0

    check-cast p2, Landroid/view/Surface;

    goto :goto_f1

    :cond_f0
    move-object p2, v3

    :goto_f1
    if-nez p2, :cond_10d

    iget-object p1, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-eqz p1, :cond_f9

    move-object p2, p1

    goto :goto_10d

    :cond_f9
    iget-object p1, p0, Lo1/u;->S:Lo1/n;

    if-eqz p1, :cond_10d

    invoke-virtual {p0, p1}, LB1/q;->J0(Lo1/n;)Z

    move-result v4

    if-eqz v4, :cond_10d

    iget-object p2, p0, LB1/q;->y1:Landroid/content/Context;

    iget-boolean p1, p1, Lo1/n;->f:Z

    invoke-static {p2, p1}, Landroidx/media3/exoplayer/video/PlaceholderSurface;->b(Landroid/content/Context;Z)Landroidx/media3/exoplayer/video/PlaceholderSurface;

    move-result-object p2

    iput-object p2, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    :cond_10d
    :goto_10d
    iget-object p1, p0, LB1/q;->L1:Landroid/view/Surface;

    iget-object v4, p0, LB1/q;->A1:LW2/p;

    if-eq p1, p2, :cond_180

    iput-object p2, p0, LB1/q;->L1:Landroid/view/Surface;

    iget-object p1, p0, LB1/q;->I1:LB1/i;

    if-nez p1, :cond_135

    iget-object p1, v1, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v5, p2, Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-eqz v5, :cond_124

    move-object v5, v3

    goto :goto_125

    :cond_124
    move-object v5, p2

    :goto_125
    iget-object v6, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->e:Landroid/view/Surface;

    if-ne v6, v5, :cond_12a

    goto :goto_132

    :cond_12a
    invoke-virtual {p1}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->b()V

    iput-object v5, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->e:Landroid/view/Surface;

    invoke-virtual {p1, v0}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d(Z)V

    :goto_132
    invoke-virtual {v1, v0}, LB1/w;->c(I)V

    :cond_135
    iput-boolean v2, p0, LB1/q;->O1:Z

    iget p1, p0, Landroidx/media3/exoplayer/e;->h:I

    iget-object v2, p0, Lo1/u;->L:Lo1/k;

    if-eqz v2, :cond_157

    iget-object v5, p0, LB1/q;->I1:LB1/i;

    if-nez v5, :cond_157

    sget v5, LZ0/F;->a:I

    const/16 v6, 0x17

    if-lt v5, v6, :cond_151

    if-eqz p2, :cond_151

    iget-boolean v5, p0, LB1/q;->G1:Z

    if-nez v5, :cond_151

    invoke-interface {v2, p2}, Lo1/k;->p(Landroid/view/Surface;)V

    goto :goto_157

    :cond_151
    invoke-virtual {p0}, Lo1/u;->n0()V

    invoke-virtual {p0}, Lo1/u;->Y()V

    :cond_157
    :goto_157
    if-eqz p2, :cond_16b

    iget-object v2, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-eq p2, v2, :cond_16b

    iget-object p2, p0, LB1/q;->Y1:LW0/e0;

    if-eqz p2, :cond_164

    invoke-virtual {v4, p2}, LW2/p;->m(LW0/e0;)V

    :cond_164
    const/4 p2, 0x2

    if-ne p1, p2, :cond_17c

    invoke-virtual {v1, v0}, LB1/w;->b(Z)V

    goto :goto_17c

    :cond_16b
    iput-object v3, p0, LB1/q;->Y1:LW0/e0;

    iget-object p1, p0, LB1/q;->I1:LB1/i;

    if-eqz p1, :cond_17c

    iget-object p1, p1, LB1/i;->l:LB1/j;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, LZ0/x;->c:LZ0/x;

    iget p2, p2, LZ0/x;->a:I

    iput-object v3, p1, LB1/j;->j:Landroid/util/Pair;

    :cond_17c
    :goto_17c
    invoke-virtual {p0}, LB1/q;->F0()V

    goto :goto_1a7

    :cond_180
    if-eqz p2, :cond_1a7

    iget-object p1, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-eq p2, p1, :cond_1a7

    iget-object p1, p0, LB1/q;->Y1:LW0/e0;

    if-eqz p1, :cond_18d

    invoke-virtual {v4, p1}, LW2/p;->m(LW0/e0;)V

    :cond_18d
    iget-object p1, p0, LB1/q;->L1:Landroid/view/Surface;

    if-eqz p1, :cond_1a7

    iget-boolean p2, p0, LB1/q;->O1:Z

    if-eqz p2, :cond_1a7

    iget-object p2, v4, LW2/p;->b:Ljava/lang/Object;

    check-cast p2, Landroid/os/Handler;

    if-eqz p2, :cond_1a7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    new-instance v2, LB1/E;

    invoke-direct {v2, v4, p1, v0, v1}, LB1/E;-><init>(LW2/p;Ljava/lang/Object;J)V

    invoke-virtual {p2, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1a7
    :goto_1a7
    return-void
.end method

.method public final d0(LAa/t;)Landroidx/media3/exoplayer/g;
    .registers 7

    invoke-super {p0, p1}, Lo1/u;->d0(LAa/t;)Landroidx/media3/exoplayer/g;

    move-result-object v0

    iget-object p1, p1, LAa/t;->c:Ljava/lang/Object;

    check-cast p1, Landroidx/media3/common/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, LB1/q;->A1:LW2/p;

    iget-object v2, v1, LW2/p;->b:Ljava/lang/Object;

    check-cast v2, Landroid/os/Handler;

    if-eqz v2, :cond_1c

    new-instance v3, LB1/I;

    const/4 v4, 0x0

    invoke-direct {v3, v1, p1, v0, v4}, LB1/I;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1c
    return-object v0
.end method

.method public final e0(Landroidx/media3/common/b;Landroid/media/MediaFormat;)V
    .registers 12

    iget-object v0, p0, Lo1/u;->L:Lo1/k;

    if-eqz v0, :cond_9

    iget v1, p0, LB1/q;->P1:I

    invoke-interface {v0, v1}, Lo1/k;->n(I)V

    :cond_9
    iget-boolean v0, p0, LB1/q;->a2:Z

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_14

    iget p2, p1, Landroidx/media3/common/b;->t:I

    iget v0, p1, Landroidx/media3/common/b;->u:I

    goto :goto_64

    :cond_14
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "crop-right"

    invoke-virtual {p2, v0}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v3

    const-string v4, "crop-top"

    const-string v5, "crop-bottom"

    const-string v6, "crop-left"

    if-eqz v3, :cond_39

    invoke-virtual {p2, v6}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_39

    invoke-virtual {p2, v5}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_39

    invoke-virtual {p2, v4}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_39

    move v3, v2

    goto :goto_3a

    :cond_39
    move v3, v1

    :goto_3a
    if-eqz v3, :cond_47

    invoke-virtual {p2, v0}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p2, v6}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v6

    sub-int/2addr v0, v6

    add-int/2addr v0, v2

    goto :goto_4d

    :cond_47
    const-string v0, "width"

    invoke-virtual {p2, v0}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v0

    :goto_4d
    if-eqz v3, :cond_5b

    invoke-virtual {p2, v5}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p2, v4}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result p2

    sub-int/2addr v3, p2

    add-int/2addr v3, v2

    move p2, v3

    goto :goto_61

    :cond_5b
    const-string v3, "height"

    invoke-virtual {p2, v3}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result p2

    :goto_61
    move v8, v0

    move v0, p2

    move p2, v8

    :goto_64
    iget v3, p1, Landroidx/media3/common/b;->x:F

    sget v4, LZ0/F;->a:I

    const/16 v5, 0x15

    iget v6, p1, Landroidx/media3/common/b;->w:I

    if-lt v4, v5, :cond_7f

    const/16 v7, 0x5a

    if-eq v6, v7, :cond_76

    const/16 v7, 0x10e

    if-ne v6, v7, :cond_84

    :cond_76
    const/high16 v6, 0x3f800000    # 1.0f

    div-float v3, v6, v3

    move v6, v1

    move v8, v0

    move v0, p2

    move p2, v8

    goto :goto_85

    :cond_7f
    iget-object v7, p0, LB1/q;->I1:LB1/i;

    if-nez v7, :cond_84

    goto :goto_85

    :cond_84
    move v6, v1

    :goto_85
    new-instance v7, LW0/e0;

    invoke-direct {v7, v3, p2, v0, v6}, LW0/e0;-><init>(FIII)V

    iput-object v7, p0, LB1/q;->X1:LW0/e0;

    iget-object v7, p0, LB1/q;->I1:LB1/i;

    if-eqz v7, :cond_105

    invoke-virtual {p1}, Landroidx/media3/common/b;->a()LW0/o;

    move-result-object p1

    iput p2, p1, LW0/o;->s:I

    iput v0, p1, LW0/o;->t:I

    iput v6, p1, LW0/o;->v:I

    iput v3, p1, LW0/o;->w:F

    new-instance p2, Landroidx/media3/common/b;

    invoke-direct {p2, p1}, Landroidx/media3/common/b;-><init>(LW0/o;)V

    invoke-static {v1}, Lm7/u;->e(Z)V

    iget-object p1, v7, LB1/i;->l:LB1/j;

    iget-object p1, p1, LB1/j;->b:LB1/w;

    iget v0, p2, Landroidx/media3/common/b;->v:F

    invoke-virtual {p1, v0}, LB1/w;->f(F)V

    if-ge v4, v5, :cond_e3

    const/4 p1, -0x1

    iget v0, p2, Landroidx/media3/common/b;->w:I

    if-eq v0, p1, :cond_e3

    if-nez v0, :cond_b7

    goto :goto_e3

    :cond_b7
    int-to-float p1, v0

    :try_start_b8
    invoke-static {}, La/a;->d()V

    sget-object p2, La/a;->a:Ljava/lang/reflect/Constructor;

    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    sget-object v1, La/a;->b:Ljava/lang/reflect/Method;

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v1, p2, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, La/a;->c:Ljava/lang/reflect/Method;

    invoke-virtual {p1, p2, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, LA8/v;->p(Ljava/lang/Object;)V

    throw v0
    :try_end_dc
    .catch Ljava/lang/Exception; {:try_start_b8 .. :try_end_dc} :catch_dc

    :catch_dc
    move-exception p1

    new-instance p2, Ljava/lang/IllegalStateException;

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_e3
    :goto_e3
    iput-object p2, v7, LB1/i;->d:Landroidx/media3/common/b;

    iget-boolean p1, v7, LB1/i;->h:Z

    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    if-nez p1, :cond_f6

    invoke-virtual {v7}, LB1/i;->c()V

    iput-boolean v2, v7, LB1/i;->h:Z

    iput-wide v3, v7, LB1/i;->i:J

    goto :goto_10c

    :cond_f6
    iget-wide p1, v7, LB1/i;->g:J

    cmp-long p1, p1, v3

    if-eqz p1, :cond_fd

    move v1, v2

    :cond_fd
    invoke-static {v1}, Lm7/u;->e(Z)V

    iget-wide p1, v7, LB1/i;->g:J

    iput-wide p1, v7, LB1/i;->i:J

    goto :goto_10c

    :cond_105
    iget-object p2, p0, LB1/q;->D1:LB1/w;

    iget p1, p1, Landroidx/media3/common/b;->v:F

    invoke-virtual {p2, p1}, LB1/w;->f(F)V

    :goto_10c
    return-void
.end method

.method public final g0(J)V
    .registers 3

    invoke-super {p0, p1, p2}, Lo1/u;->g0(J)V

    iget-boolean p1, p0, LB1/q;->a2:Z

    if-nez p1, :cond_d

    iget p1, p0, LB1/q;->T1:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, LB1/q;->T1:I

    :cond_d
    return-void
.end method

.method public final h0()V
    .registers 9

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-eqz v0, :cond_19

    iget-object v1, p0, Lo1/u;->u1:Lo1/t;

    iget-wide v1, v1, Lo1/t;->c:J

    iget-wide v3, v0, LB1/i;->e:J

    cmp-long v3, v3, v1

    const-wide/16 v4, 0x0

    if-nez v3, :cond_14

    iget-wide v6, v0, LB1/i;->f:J

    cmp-long v3, v6, v4

    :cond_14
    iput-wide v1, v0, LB1/i;->e:J

    iput-wide v4, v0, LB1/i;->f:J

    goto :goto_1f

    :cond_19
    const/4 v0, 0x2

    iget-object v1, p0, LB1/q;->D1:LB1/w;

    invoke-virtual {v1, v0}, LB1/w;->c(I)V

    :goto_1f
    invoke-virtual {p0}, LB1/q;->F0()V

    return-void
.end method

.method public final i()V
    .registers 4

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    const/4 v1, 0x1

    if-eqz v0, :cond_10

    iget-object v0, v0, LB1/i;->l:LB1/j;

    iget-object v0, v0, LB1/j;->b:LB1/w;

    iget v2, v0, LB1/w;->e:I

    if-nez v2, :cond_18

    iput v1, v0, LB1/w;->e:I

    goto :goto_18

    :cond_10
    iget-object v0, p0, LB1/q;->D1:LB1/w;

    iget v2, v0, LB1/w;->e:I

    if-nez v2, :cond_18

    iput v1, v0, LB1/w;->e:I

    :cond_18
    :goto_18
    return-void
.end method

.method public final i0(Lf1/f;)V
    .registers 10

    iget-boolean v0, p0, LB1/q;->a2:Z

    const/4 v1, 0x1

    if-nez v0, :cond_a

    iget v2, p0, LB1/q;->T1:I

    add-int/2addr v2, v1

    iput v2, p0, LB1/q;->T1:I

    :cond_a
    sget v2, LZ0/F;->a:I

    const/16 v3, 0x17

    if-ge v2, v3, :cond_5d

    if-eqz v0, :cond_5d

    iget-wide v2, p1, Lf1/f;->g:J

    invoke-virtual {p0, v2, v3}, Lo1/u;->y0(J)V

    iget-object p1, p0, LB1/q;->X1:LW0/e0;

    invoke-virtual {p0, p1}, LB1/q;->E0(LW0/e0;)V

    iget-object p1, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget v0, p1, Landroidx/media3/exoplayer/f;->e:I

    add-int/2addr v0, v1

    iput v0, p1, Landroidx/media3/exoplayer/f;->e:I

    iget-object p1, p0, LB1/q;->D1:LB1/w;

    iget v0, p1, LB1/w;->e:I

    const/4 v4, 0x3

    if-eq v0, v4, :cond_2c

    move v0, v1

    goto :goto_2d

    :cond_2c
    const/4 v0, 0x0

    :goto_2d
    iput v4, p1, LB1/w;->e:I

    iget-object v4, p1, LB1/w;->l:LZ0/y;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    invoke-static {v4, v5}, LZ0/F;->Q(J)J

    move-result-wide v4

    iput-wide v4, p1, LB1/w;->g:J

    if-eqz v0, :cond_5a

    iget-object p1, p0, LB1/q;->L1:Landroid/view/Surface;

    if-eqz p1, :cond_5a

    iget-object v0, p0, LB1/q;->A1:LW2/p;

    iget-object v4, v0, LW2/p;->b:Ljava/lang/Object;

    check-cast v4, Landroid/os/Handler;

    if-eqz v4, :cond_58

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    new-instance v7, LB1/E;

    invoke-direct {v7, v0, p1, v5, v6}, LB1/E;-><init>(LW2/p;Ljava/lang/Object;J)V

    invoke-virtual {v4, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_58
    iput-boolean v1, p0, LB1/q;->O1:Z

    :cond_5a
    invoke-virtual {p0, v2, v3}, LB1/q;->g0(J)V

    :cond_5d
    return-void
.end method

.method public final j0(Landroidx/media3/common/b;)V
    .registers 5

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-nez v0, :cond_5

    return-void

    :cond_5
    :try_start_5
    invoke-virtual {v0, p1}, LB1/i;->b(Landroidx/media3/common/b;)V

    const/4 v0, 0x0

    throw v0
    :try_end_a
    .catch LB1/M; {:try_start_5 .. :try_end_a} :catch_a

    :catch_a
    move-exception v0

    const/4 v1, 0x0

    const/16 v2, 0x1b58

    invoke-virtual {p0, v0, p1, v1, v2}, Landroidx/media3/exoplayer/e;->g(Ljava/lang/Exception;Landroidx/media3/common/b;ZI)Landroidx/media3/exoplayer/m;

    move-result-object p1

    throw p1
.end method

.method public final l0(JJLo1/k;Ljava/nio/ByteBuffer;IIIJZZLandroidx/media3/common/b;)Z
    .registers 33

    move-object/from16 v1, p0

    move-object/from16 v0, p5

    move/from16 v2, p7

    invoke-virtual/range {p5 .. p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v1, Lo1/u;->u1:Lo1/t;

    iget-wide v4, v3, Lo1/t;->c:J

    sub-long v4, p10, v4

    iget-object v15, v1, LB1/q;->E1:LB1/v;

    iget-object v6, v1, LB1/q;->D1:LB1/w;

    iget-wide v13, v3, Lo1/t;->b:J

    move-wide/from16 v7, p10

    move-wide/from16 v9, p1

    move-wide/from16 v11, p3

    move-object v3, v15

    move/from16 v15, p13

    move-object/from16 v16, v3

    invoke-virtual/range {v6 .. v16}, LB1/w;->a(JJJJZLB1/v;)I

    move-result v3

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ne v3, v6, :cond_29

    return v7

    :cond_29
    const/4 v13, 0x1

    if-eqz p12, :cond_32

    if-nez p13, :cond_32

    invoke-virtual {v1, v0, v2}, LB1/q;->K0(Lo1/k;I)V

    return v13

    :cond_32
    iget-object v6, v1, LB1/q;->L1:Landroid/view/Surface;

    iget-object v8, v1, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    const-wide/16 v9, 0x7530

    iget-object v14, v1, LB1/q;->E1:LB1/v;

    if-ne v6, v8, :cond_50

    iget-object v6, v1, LB1/q;->I1:LB1/i;

    if-nez v6, :cond_50

    iget-wide v3, v14, LB1/v;->a:J

    cmp-long v3, v3, v9

    if-gez v3, :cond_4f

    invoke-virtual {v1, v0, v2}, LB1/q;->K0(Lo1/k;I)V

    iget-wide v2, v14, LB1/v;->a:J

    invoke-virtual {v1, v2, v3}, LB1/q;->M0(J)V

    return v13

    :cond_4f
    return v7

    :cond_50
    iget-object v6, v1, LB1/q;->I1:LB1/i;

    if-eqz v6, :cond_a2

    move-wide/from16 v11, p1

    move-wide/from16 v9, p3

    :try_start_58
    invoke-virtual {v6, v11, v12, v9, v10}, LB1/i;->d(JJ)V
    :try_end_5b
    .catch LB1/M; {:try_start_58 .. :try_end_5b} :catch_97

    iget-object v0, v1, LB1/q;->I1:LB1/i;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v7}, Lm7/u;->e(Z)V

    iget v2, v0, LB1/i;->b:I

    const/4 v3, -0x1

    if-eq v2, v3, :cond_69

    goto :goto_6a

    :cond_69
    move v13, v7

    :goto_6a
    invoke-static {v13}, Lm7/u;->e(Z)V

    iget-wide v2, v0, LB1/i;->i:J

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v6, v2, v4

    if-eqz v6, :cond_92

    iget-object v6, v0, LB1/i;->l:LB1/j;

    iget v8, v6, LB1/j;->k:I

    if-nez v8, :cond_91

    iget-object v6, v6, LB1/j;->c:LB1/B;

    iget-wide v8, v6, LB1/B;->j:J

    cmp-long v6, v8, v4

    if-eqz v6, :cond_91

    cmp-long v2, v8, v2

    if-gez v2, :cond_8b

    goto :goto_91

    :cond_8b
    invoke-virtual {v0}, LB1/i;->c()V

    iput-wide v4, v0, LB1/i;->i:J

    goto :goto_92

    :cond_91
    :goto_91
    return v7

    :cond_92
    :goto_92
    const/4 v0, 0x0

    invoke-static {v0}, Lm7/u;->g(Ljava/lang/Object;)V

    throw v0

    :catch_97
    move-exception v0

    move-object v2, v0

    iget-object v0, v2, LB1/M;->a:Landroidx/media3/common/b;

    const/16 v3, 0x1b59

    invoke-virtual {v1, v2, v0, v7, v3}, Landroidx/media3/exoplayer/e;->g(Ljava/lang/Exception;Landroidx/media3/common/b;ZI)Landroidx/media3/exoplayer/m;

    move-result-object v0

    throw v0

    :cond_a2
    const/16 v15, 0x15

    if-eqz v3, :cond_141

    if-eq v3, v13, :cond_d9

    const/4 v4, 0x2

    if-eq v3, v4, :cond_c5

    const/4 v4, 0x3

    if-eq v3, v4, :cond_bc

    const/4 v0, 0x5

    if-ne v3, v0, :cond_b2

    return v7

    :cond_b2
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_bc
    invoke-virtual {v1, v0, v2}, LB1/q;->K0(Lo1/k;I)V

    iget-wide v2, v14, LB1/v;->a:J

    invoke-virtual {v1, v2, v3}, LB1/q;->M0(J)V

    return v13

    :cond_c5
    const-string v3, "dropVideoBuffer"

    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    invoke-interface {v0, v2, v7}, Lo1/k;->m(IZ)V

    invoke-static {}, Landroid/os/Trace;->endSection()V

    invoke-virtual {v1, v7, v13}, LB1/q;->L0(II)V

    iget-wide v2, v14, LB1/v;->a:J

    invoke-virtual {v1, v2, v3}, LB1/q;->M0(J)V

    return v13

    :cond_d9
    iget-wide v11, v14, LB1/v;->b:J

    iget-wide v9, v14, LB1/v;->a:J

    sget v3, LZ0/F;->a:I

    if-lt v3, v15, :cond_10a

    iget-wide v6, v1, LB1/q;->W1:J

    cmp-long v3, v11, v6

    if-nez v3, :cond_ed

    invoke-virtual {v1, v0, v2}, LB1/q;->K0(Lo1/k;I)V

    move-wide v14, v9

    move-wide v4, v11

    goto :goto_103

    :cond_ed
    iget-object v6, v1, LB1/q;->d2:LB1/u;

    if-eqz v6, :cond_fe

    iget-object v3, v1, Lo1/u;->N:Landroid/media/MediaFormat;

    move-wide v7, v4

    move-wide v14, v9

    move-wide v9, v11

    move-wide v4, v11

    move-object/from16 v11, p14

    move-object v12, v3

    invoke-interface/range {v6 .. v12}, LB1/u;->c(JJLandroidx/media3/common/b;Landroid/media/MediaFormat;)V

    goto :goto_100

    :cond_fe
    move-wide v14, v9

    move-wide v4, v11

    :goto_100
    invoke-virtual {v1, v0, v2, v4, v5}, LB1/q;->I0(Lo1/k;IJ)V

    :goto_103
    invoke-virtual {v1, v14, v15}, LB1/q;->M0(J)V

    iput-wide v4, v1, LB1/q;->W1:J

    :goto_108
    move v7, v13

    goto :goto_140

    :cond_10a
    move-wide v14, v9

    move-wide v10, v11

    const-wide/16 v8, 0x7530

    cmp-long v3, v14, v8

    if-gez v3, :cond_140

    const-wide/16 v8, 0x2af8

    cmp-long v3, v14, v8

    if-lez v3, :cond_12c

    const-wide/16 v8, 0x2710

    sub-long v8, v14, v8

    const-wide/16 v16, 0x3e8

    :try_start_11e
    div-long v8, v8, v16

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_123
    .catch Ljava/lang/InterruptedException; {:try_start_11e .. :try_end_123} :catch_124

    goto :goto_12c

    :catch_124
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    goto :goto_140

    :cond_12c
    :goto_12c
    iget-object v6, v1, LB1/q;->d2:LB1/u;

    if-eqz v6, :cond_139

    iget-object v12, v1, Lo1/u;->N:Landroid/media/MediaFormat;

    move-wide v7, v4

    move-wide v9, v10

    move-object/from16 v11, p14

    invoke-interface/range {v6 .. v12}, LB1/u;->c(JJLandroidx/media3/common/b;Landroid/media/MediaFormat;)V

    :cond_139
    invoke-virtual {v1, v0, v2}, LB1/q;->H0(Lo1/k;I)V

    invoke-virtual {v1, v14, v15}, LB1/q;->M0(J)V

    goto :goto_108

    :cond_140
    :goto_140
    return v7

    :cond_141
    iget-object v3, v1, Landroidx/media3/exoplayer/e;->g:LZ0/y;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v11

    iget-object v6, v1, LB1/q;->d2:LB1/u;

    if-eqz v6, :cond_15a

    iget-object v3, v1, Lo1/u;->N:Landroid/media/MediaFormat;

    move-wide v7, v4

    move-wide v9, v11

    move-wide v4, v11

    move-object/from16 v11, p14

    move-object v12, v3

    invoke-interface/range {v6 .. v12}, LB1/u;->c(JJLandroidx/media3/common/b;Landroid/media/MediaFormat;)V

    goto :goto_15b

    :cond_15a
    move-wide v4, v11

    :goto_15b
    sget v3, LZ0/F;->a:I

    if-lt v3, v15, :cond_163

    invoke-virtual {v1, v0, v2, v4, v5}, LB1/q;->I0(Lo1/k;IJ)V

    goto :goto_166

    :cond_163
    invoke-virtual {v1, v0, v2}, LB1/q;->H0(Lo1/k;I)V

    :goto_166
    iget-wide v2, v14, LB1/v;->a:J

    invoke-virtual {v1, v2, v3}, LB1/q;->M0(J)V

    return v13
.end method

.method public final m()Ljava/lang/String;
    .registers 2

    const-string v0, "MediaCodecVideoRenderer"

    return-object v0
.end method

.method public final o()Z
    .registers 2

    iget-boolean v0, p0, Lo1/u;->p1:Z

    if-eqz v0, :cond_e

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-eqz v0, :cond_c

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_e

    :cond_c
    const/4 v0, 0x1

    goto :goto_f

    :cond_e
    :goto_e
    const/4 v0, 0x0

    :goto_f
    return v0
.end method

.method public final p0()V
    .registers 2

    invoke-super {p0}, Lo1/u;->p0()V

    const/4 v0, 0x0

    iput v0, p0, LB1/q;->T1:I

    return-void
.end method

.method public final q()Z
    .registers 11

    invoke-super {p0}, Lo1/u;->q()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_f

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-eqz v0, :cond_d

    goto :goto_f

    :cond_d
    move v0, v2

    goto :goto_10

    :cond_f
    :goto_f
    move v0, v1

    :goto_10
    if-eqz v0, :cond_23

    iget-object v3, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-eqz v3, :cond_1a

    iget-object v4, p0, LB1/q;->L1:Landroid/view/Surface;

    if-eq v4, v3, :cond_22

    :cond_1a
    iget-object v3, p0, Lo1/u;->L:Lo1/k;

    if-eqz v3, :cond_22

    iget-boolean v3, p0, LB1/q;->a2:Z

    if-eqz v3, :cond_23

    :cond_22
    return v2

    :cond_23
    iget-object v3, p0, LB1/q;->D1:LB1/w;

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    if-eqz v0, :cond_35

    iget v0, v3, LB1/w;->e:I

    const/4 v6, 0x3

    if-ne v0, v6, :cond_35

    iput-wide v4, v3, LB1/w;->i:J

    :goto_33
    move v1, v2

    goto :goto_4e

    :cond_35
    iget-wide v6, v3, LB1/w;->i:J

    cmp-long v0, v6, v4

    if-nez v0, :cond_3c

    goto :goto_4e

    :cond_3c
    iget-object v0, v3, LB1/w;->l:LZ0/y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iget-wide v8, v3, LB1/w;->i:J

    cmp-long v0, v6, v8

    if-gez v0, :cond_4c

    goto :goto_33

    :cond_4c
    iput-wide v4, v3, LB1/w;->i:J

    :goto_4e
    return v1
.end method

.method public final r()V
    .registers 7

    iget-object v0, p0, LB1/q;->A1:LW2/p;

    const/4 v1, 0x0

    iput-object v1, p0, LB1/q;->Y1:LW0/e0;

    iget-object v2, p0, LB1/q;->I1:LB1/i;

    const/4 v3, 0x0

    if-eqz v2, :cond_12

    iget-object v2, v2, LB1/i;->l:LB1/j;

    iget-object v2, v2, LB1/j;->b:LB1/w;

    invoke-virtual {v2, v3}, LB1/w;->c(I)V

    goto :goto_17

    :cond_12
    iget-object v2, p0, LB1/q;->D1:LB1/w;

    invoke-virtual {v2, v3}, LB1/w;->c(I)V

    :goto_17
    invoke-virtual {p0}, LB1/q;->F0()V

    iput-boolean v3, p0, LB1/q;->O1:Z

    iput-object v1, p0, LB1/q;->c2:LB1/p;

    :try_start_1e
    invoke-super {p0}, Lo1/u;->r()V
    :try_end_21
    .catchall {:try_start_1e .. :try_end_21} :catchall_3d

    iget-object v1, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter v1

    monitor-exit v1

    iget-object v2, v0, LW2/p;->b:Ljava/lang/Object;

    check-cast v2, Landroid/os/Handler;

    if-eqz v2, :cond_37

    new-instance v3, LB1/J;

    const/4 v4, 0x0

    invoke-direct {v3, v4, v0, v1}, LB1/J;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_37
    sget-object v1, LW0/e0;->e:LW0/e0;

    invoke-virtual {v0, v1}, LW2/p;->m(LW0/e0;)V

    return-void

    :catchall_3d
    move-exception v1

    iget-object v2, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter v2

    monitor-exit v2

    iget-object v3, v0, LW2/p;->b:Ljava/lang/Object;

    check-cast v3, Landroid/os/Handler;

    if-eqz v3, :cond_54

    new-instance v4, LB1/J;

    const/4 v5, 0x0

    invoke-direct {v4, v5, v0, v2}, LB1/J;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_54
    sget-object v2, LW0/e0;->e:LW0/e0;

    invoke-virtual {v0, v2}, LW2/p;->m(LW0/e0;)V

    throw v1
.end method

.method public final s(ZZ)V
    .registers 9

    new-instance p1, Landroidx/media3/exoplayer/f;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget-object p1, p0, Landroidx/media3/exoplayer/e;->d:Landroidx/media3/exoplayer/s0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-boolean p1, p1, Landroidx/media3/exoplayer/s0;->b:Z

    if-eqz p1, :cond_19

    iget v2, p0, LB1/q;->b2:I

    if-eqz v2, :cond_17

    goto :goto_19

    :cond_17
    move v2, v0

    goto :goto_1a

    :cond_19
    :goto_19
    move v2, v1

    :goto_1a
    invoke-static {v2}, Lm7/u;->e(Z)V

    iget-boolean v2, p0, LB1/q;->a2:Z

    if-eq v2, p1, :cond_26

    iput-boolean p1, p0, LB1/q;->a2:Z

    invoke-virtual {p0}, Lo1/u;->n0()V

    :cond_26
    iget-object p1, p0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget-object v2, p0, LB1/q;->A1:LW2/p;

    iget-object v3, v2, LW2/p;->b:Ljava/lang/Object;

    check-cast v3, Landroid/os/Handler;

    if-eqz v3, :cond_39

    new-instance v4, LB1/H;

    const/4 v5, 0x0

    invoke-direct {v4, v5, v2, p1}, LB1/H;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_39
    iget-boolean p1, p0, LB1/q;->J1:Z

    iget-object v2, p0, LB1/q;->D1:LB1/w;

    if-nez p1, :cond_8a

    iget-object p1, p0, LB1/q;->K1:Ljava/util/List;

    if-nez p1, :cond_47

    iget-boolean p1, p0, LB1/q;->z1:Z

    if-nez p1, :cond_88

    :cond_47
    iget-object p1, p0, LB1/q;->I1:LB1/i;

    if-nez p1, :cond_88

    new-instance p1, LB1/c;

    iget-object v3, p0, LB1/q;->y1:Landroid/content/Context;

    invoke-direct {p1, v3, v2}, LB1/c;-><init>(Landroid/content/Context;LB1/w;)V

    iget-object v3, p0, Landroidx/media3/exoplayer/e;->g:LZ0/y;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v3, p1, LB1/c;->f:Ljava/lang/Object;

    iget-boolean v3, p1, LB1/c;->a:Z

    xor-int/2addr v3, v1

    invoke-static {v3}, Lm7/u;->e(Z)V

    iget-object v3, p1, LB1/c;->e:Ljava/lang/Object;

    check-cast v3, LB1/f;

    if-nez v3, :cond_7d

    iget-object v3, p1, LB1/c;->d:Ljava/lang/Object;

    check-cast v3, LB1/e;

    if-nez v3, :cond_72

    new-instance v3, LB1/e;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    iput-object v3, p1, LB1/c;->d:Ljava/lang/Object;

    :cond_72
    new-instance v3, LB1/f;

    iget-object v4, p1, LB1/c;->d:Ljava/lang/Object;

    check-cast v4, LB1/e;

    invoke-direct {v3, v4}, LB1/f;-><init>(LB1/e;)V

    iput-object v3, p1, LB1/c;->e:Ljava/lang/Object;

    :cond_7d
    new-instance v3, LB1/j;

    invoke-direct {v3, p1}, LB1/j;-><init>(LB1/c;)V

    iput-boolean v1, p1, LB1/c;->a:Z

    iget-object p1, v3, LB1/j;->a:LB1/i;

    iput-object p1, p0, LB1/q;->I1:LB1/i;

    :cond_88
    iput-boolean v1, p0, LB1/q;->J1:Z

    :cond_8a
    iget-object p1, p0, LB1/q;->I1:LB1/i;

    if-eqz p1, :cond_10b

    new-instance v2, LA0/x;

    const/4 v3, 0x2

    invoke-direct {v2, v3, p0}, LA0/x;-><init>(ILjava/lang/Object;)V

    sget-object v3, Ln8/l;->a:Ln8/l;

    iput-object v2, p1, LB1/i;->j:LB1/L;

    iput-object v3, p1, LB1/i;->k:Ljava/util/concurrent/Executor;

    iget-object v2, p0, LB1/q;->d2:LB1/u;

    if-eqz v2, :cond_a2

    iget-object p1, p1, LB1/i;->l:LB1/j;

    iput-object v2, p1, LB1/j;->h:LB1/u;

    :cond_a2
    iget-object p1, p0, LB1/q;->L1:Landroid/view/Surface;

    if-eqz p1, :cond_b9

    iget-object p1, p0, LB1/q;->N1:LZ0/x;

    sget-object v2, LZ0/x;->c:LZ0/x;

    invoke-virtual {p1, v2}, LZ0/x;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_b9

    iget-object p1, p0, LB1/q;->I1:LB1/i;

    iget-object v2, p0, LB1/q;->L1:Landroid/view/Surface;

    iget-object v3, p0, LB1/q;->N1:LZ0/x;

    invoke-virtual {p1, v2, v3}, LB1/i;->e(Landroid/view/Surface;LZ0/x;)V

    :cond_b9
    iget-object p1, p0, LB1/q;->I1:LB1/i;

    iget v2, p0, Lo1/u;->J:F

    iget-object p1, p1, LB1/i;->l:LB1/j;

    iget-object p1, p1, LB1/j;->c:LB1/B;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x0

    cmpl-float v3, v2, v3

    if-lez v3, :cond_ca

    goto :goto_cb

    :cond_ca
    move v1, v0

    :goto_cb
    invoke-static {v1}, Lm7/u;->a(Z)V

    iget-object p1, p1, LB1/B;->b:LB1/w;

    iget v1, p1, LB1/w;->k:F

    cmpl-float v1, v2, v1

    if-nez v1, :cond_d7

    goto :goto_ea

    :cond_d7
    iput v2, p1, LB1/w;->k:F

    iget-object p1, p1, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iput v2, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->i:F

    const-wide/16 v1, 0x0

    iput-wide v1, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    const-wide/16 v1, -0x1

    iput-wide v1, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iput-wide v1, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    invoke-virtual {p1, v0}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d(Z)V

    :goto_ea
    iget-object p1, p0, LB1/q;->K1:Ljava/util/List;

    if-eqz p1, :cond_102

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    iget-object v1, v0, LB1/i;->c:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_f9

    goto :goto_102

    :cond_f9
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v0}, LB1/i;->c()V

    :cond_102
    :goto_102
    iget-object p1, p0, LB1/q;->I1:LB1/i;

    iget-object p1, p1, LB1/i;->l:LB1/j;

    iget-object p1, p1, LB1/j;->b:LB1/w;

    iput p2, p1, LB1/w;->e:I

    goto :goto_114

    :cond_10b
    iget-object p1, p0, Landroidx/media3/exoplayer/e;->g:LZ0/y;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, v2, LB1/w;->l:LZ0/y;

    iput p2, v2, LB1/w;->e:I

    :goto_114
    return-void
.end method

.method public final t(JZ)V
    .registers 12

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    const-wide/16 v1, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_1e

    invoke-virtual {v0, v3}, LB1/i;->a(Z)V

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    iget-object v4, p0, Lo1/u;->u1:Lo1/t;

    iget-wide v4, v4, Lo1/t;->c:J

    iget-wide v6, v0, LB1/i;->e:J

    cmp-long v6, v6, v4

    if-nez v6, :cond_1a

    iget-wide v6, v0, LB1/i;->f:J

    cmp-long v6, v6, v1

    :cond_1a
    iput-wide v4, v0, LB1/i;->e:J

    iput-wide v1, v0, LB1/i;->f:J

    :cond_1e
    invoke-super {p0, p1, p2, p3}, Lo1/u;->t(JZ)V

    iget-object p1, p0, LB1/q;->I1:LB1/i;

    iget-object p2, p0, LB1/q;->D1:LB1/w;

    if-nez p1, :cond_3f

    iget-object p1, p2, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iput-wide v1, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    const-wide/16 v0, -0x1

    iput-wide v0, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iput-wide v0, p1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v0, p2, LB1/w;->h:J

    iput-wide v0, p2, LB1/w;->f:J

    invoke-virtual {p2, v3}, LB1/w;->c(I)V

    iput-wide v0, p2, LB1/w;->i:J

    :cond_3f
    const/4 p1, 0x0

    if-eqz p3, :cond_45

    invoke-virtual {p2, p1}, LB1/w;->b(Z)V

    :cond_45
    invoke-virtual {p0}, LB1/q;->F0()V

    iput p1, p0, LB1/q;->S1:I

    return-void
.end method

.method public final t0(Lo1/n;)Z
    .registers 3

    iget-object v0, p0, LB1/q;->L1:Landroid/view/Surface;

    if-nez v0, :cond_d

    invoke-virtual {p0, p1}, LB1/q;->J0(Lo1/n;)Z

    move-result p1

    if-eqz p1, :cond_b

    goto :goto_d

    :cond_b
    const/4 p1, 0x0

    goto :goto_e

    :cond_d
    :goto_d
    const/4 p1, 0x1

    :goto_e
    return p1
.end method

.method public final u()V
    .registers 5

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-eqz v0, :cond_1e

    iget-boolean v1, p0, LB1/q;->z1:Z

    if-eqz v1, :cond_1e

    iget-object v0, v0, LB1/i;->l:LB1/j;

    iget v1, v0, LB1/j;->l:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_10

    goto :goto_1e

    :cond_10
    iget-object v1, v0, LB1/j;->i:LZ0/A;

    const/4 v3, 0x0

    if-eqz v1, :cond_1a

    iget-object v1, v1, LZ0/A;->a:Landroid/os/Handler;

    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    :cond_1a
    iput-object v3, v0, LB1/j;->j:Landroid/util/Pair;

    iput v2, v0, LB1/j;->l:I

    :cond_1e
    :goto_1e
    return-void
.end method

.method public final v()V
    .registers 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :try_start_2
    invoke-virtual {p0}, Lo1/u;->J()V

    invoke-virtual {p0}, Lo1/u;->n0()V
    :try_end_8
    .catchall {:try_start_2 .. :try_end_8} :catchall_1e

    :try_start_8
    iget-object v2, p0, Lo1/u;->F:Lk1/i;

    if-nez v2, :cond_d

    goto :goto_10

    :cond_d
    invoke-interface {v2, v1}, Lk1/i;->c(Lk1/k;)V

    :goto_10
    iput-object v1, p0, Lo1/u;->F:Lk1/i;
    :try_end_12
    .catchall {:try_start_8 .. :try_end_12} :catchall_1c

    iput-boolean v0, p0, LB1/q;->J1:Z

    iget-object v0, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-eqz v0, :cond_1b

    invoke-virtual {p0}, LB1/q;->G0()V

    :cond_1b
    return-void

    :catchall_1c
    move-exception v1

    goto :goto_29

    :catchall_1e
    move-exception v2

    :try_start_1f
    iget-object v3, p0, Lo1/u;->F:Lk1/i;

    if-eqz v3, :cond_26

    invoke-interface {v3, v1}, Lk1/i;->c(Lk1/k;)V

    :cond_26
    iput-object v1, p0, Lo1/u;->F:Lk1/i;

    throw v2
    :try_end_29
    .catchall {:try_start_1f .. :try_end_29} :catchall_1c

    :goto_29
    iput-boolean v0, p0, LB1/q;->J1:Z

    iget-object v0, p0, LB1/q;->M1:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    if-eqz v0, :cond_32

    invoke-virtual {p0}, LB1/q;->G0()V

    :cond_32
    throw v1
.end method

.method public final v0(Lo1/v;Landroidx/media3/common/b;)I
    .registers 15

    const/16 v0, 0x8

    const/4 v1, 0x1

    iget-object v2, p2, Landroidx/media3/common/b;->n:Ljava/lang/String;

    invoke-static {v2}, LW0/I;->m(Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-nez v2, :cond_11

    invoke-static {v3, v3, v3, v3}, Landroidx/media3/exoplayer/e;->f(IIII)I

    move-result p1

    return p1

    :cond_11
    iget-object v2, p2, Landroidx/media3/common/b;->r:Landroidx/media3/common/DrmInitData;

    if-eqz v2, :cond_17

    move v2, v1

    goto :goto_18

    :cond_17
    move v2, v3

    :goto_18
    iget-object v4, p0, LB1/q;->y1:Landroid/content/Context;

    invoke-static {v4, p1, p2, v2, v3}, LB1/q;->B0(Landroid/content/Context;Lo1/v;Landroidx/media3/common/b;ZZ)Ljava/util/List;

    move-result-object v5

    if-eqz v2, :cond_2a

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_2a

    invoke-static {v4, p1, p2, v3, v3}, LB1/q;->B0(Landroid/content/Context;Lo1/v;Landroidx/media3/common/b;ZZ)Ljava/util/List;

    move-result-object v5

    :cond_2a
    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_35

    invoke-static {v1, v3, v3, v3}, Landroidx/media3/exoplayer/e;->f(IIII)I

    move-result p1

    return p1

    :cond_35
    iget v6, p2, Landroidx/media3/common/b;->K:I

    if-eqz v6, :cond_42

    const/4 v7, 0x2

    if-ne v6, v7, :cond_3d

    goto :goto_42

    :cond_3d
    invoke-static {v7, v3, v3, v3}, Landroidx/media3/exoplayer/e;->f(IIII)I

    move-result p1

    return p1

    :cond_42
    :goto_42
    invoke-interface {v5, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lo1/n;

    invoke-virtual {v6, p2}, Lo1/n;->d(Landroidx/media3/common/b;)Z

    move-result v7

    if-nez v7, :cond_67

    move v8, v1

    :goto_4f
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v9

    if-ge v8, v9, :cond_67

    invoke-interface {v5, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lo1/n;

    invoke-virtual {v9, p2}, Lo1/n;->d(Landroidx/media3/common/b;)Z

    move-result v10

    if-eqz v10, :cond_65

    move v7, v1

    move v5, v3

    move-object v6, v9

    goto :goto_68

    :cond_65
    add-int/2addr v8, v1

    goto :goto_4f

    :cond_67
    move v5, v1

    :goto_68
    if-eqz v7, :cond_6c

    const/4 v8, 0x4

    goto :goto_6d

    :cond_6c
    const/4 v8, 0x3

    :goto_6d
    invoke-virtual {v6, p2}, Lo1/n;->e(Landroidx/media3/common/b;)Z

    move-result v9

    if-eqz v9, :cond_76

    const/16 v9, 0x10

    goto :goto_77

    :cond_76
    move v9, v0

    :goto_77
    iget-boolean v6, v6, Lo1/n;->g:Z

    if-eqz v6, :cond_7e

    const/16 v6, 0x40

    goto :goto_7f

    :cond_7e
    move v6, v3

    :goto_7f
    if-eqz v5, :cond_84

    const/16 v5, 0x80

    goto :goto_85

    :cond_84
    move v5, v3

    :goto_85
    sget v10, LZ0/F;->a:I

    const/16 v11, 0x1a

    if-lt v10, v11, :cond_9d

    const-string v10, "video/dolby-vision"

    iget-object v11, p2, Landroidx/media3/common/b;->n:Ljava/lang/String;

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_9d

    invoke-static {v4}, LB1/n;->a(Landroid/content/Context;)Z

    move-result v10

    if-nez v10, :cond_9d

    const/16 v5, 0x100

    :cond_9d
    if-eqz v7, :cond_d1

    invoke-static {v4, p1, p2, v2, v1}, LB1/q;->B0(Landroid/content/Context;Lo1/v;Landroidx/media3/common/b;ZZ)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_d1

    sget-object v1, Lo1/B;->a:Ljava/util/regex/Pattern;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance p1, LC/C0;

    invoke-direct {p1, v0, p2}, LC/C0;-><init>(ILjava/lang/Object;)V

    new-instance v0, Lo1/w;

    invoke-direct {v0, p1}, Lo1/w;-><init>(Lo1/A;)V

    invoke-static {v1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lo1/n;

    invoke-virtual {p1, p2}, Lo1/n;->d(Landroidx/media3/common/b;)Z

    move-result v0

    if-eqz v0, :cond_d1

    invoke-virtual {p1, p2}, Lo1/n;->e(Landroidx/media3/common/b;)Z

    move-result p1

    if-eqz p1, :cond_d1

    const/16 v3, 0x20

    :cond_d1
    or-int p1, v8, v9

    or-int/2addr p1, v3

    or-int/2addr p1, v6

    or-int/2addr p1, v5

    return p1
.end method

.method public final w()V
    .registers 4

    const/4 v0, 0x0

    iput v0, p0, LB1/q;->R1:I

    iget-object v1, p0, Landroidx/media3/exoplayer/e;->g:LZ0/y;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iput-wide v1, p0, LB1/q;->Q1:J

    const-wide/16 v1, 0x0

    iput-wide v1, p0, LB1/q;->U1:J

    iput v0, p0, LB1/q;->V1:I

    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-eqz v0, :cond_20

    iget-object v0, v0, LB1/i;->l:LB1/j;

    iget-object v0, v0, LB1/j;->b:LB1/w;

    invoke-virtual {v0}, LB1/w;->d()V

    goto :goto_25

    :cond_20
    iget-object v0, p0, LB1/q;->D1:LB1/w;

    invoke-virtual {v0}, LB1/w;->d()V

    :goto_25
    return-void
.end method

.method public final x()V
    .registers 7

    invoke-virtual {p0}, LB1/q;->D0()V

    iget v0, p0, LB1/q;->V1:I

    if-eqz v0, :cond_20

    iget-wide v1, p0, LB1/q;->U1:J

    iget-object v3, p0, LB1/q;->A1:LW2/p;

    iget-object v4, v3, LW2/p;->b:Ljava/lang/Object;

    check-cast v4, Landroid/os/Handler;

    if-eqz v4, :cond_19

    new-instance v5, LB1/F;

    invoke-direct {v5, v0, v1, v2, v3}, LB1/F;-><init>(IJLW2/p;)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_19
    const-wide/16 v0, 0x0

    iput-wide v0, p0, LB1/q;->U1:J

    const/4 v0, 0x0

    iput v0, p0, LB1/q;->V1:I

    :cond_20
    iget-object v0, p0, LB1/q;->I1:LB1/i;

    if-eqz v0, :cond_2c

    iget-object v0, v0, LB1/i;->l:LB1/j;

    iget-object v0, v0, LB1/j;->b:LB1/w;

    invoke-virtual {v0}, LB1/w;->e()V

    goto :goto_31

    :cond_2c
    iget-object v0, p0, LB1/q;->D1:LB1/w;

    invoke-virtual {v0}, LB1/w;->e()V

    :goto_31
    return-void
.end method
