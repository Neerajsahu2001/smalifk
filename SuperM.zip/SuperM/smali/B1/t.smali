.class public interface abstract LB1/t;
.super Ljava/lang/Object;
.source "SourceFile"
