.class public final LB1/r;
.super Landroid/os/HandlerThread;
.source "SourceFile"

# interfaces
.implements Landroid/os/Handler$Callback;


# instance fields
.field public a:LZ0/g;

.field public b:Landroid/os/Handler;

.field public c:Ljava/lang/Error;

.field public d:Ljava/lang/RuntimeException;

.field public e:Landroidx/media3/exoplayer/video/PlaceholderSurface;


# virtual methods
.method public final a(I)V
    .registers 18

    move-object/from16 v0, p0

    move/from16 v1, p1

    iget-object v2, v0, LB1/r;->a:LZ0/g;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v0, LB1/r;->a:LZ0/g;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x0

    invoke-static {v3}, Landroid/opengl/EGL14;->eglGetDisplay(I)Landroid/opengl/EGLDisplay;

    move-result-object v4

    const/4 v12, 0x1

    if-eqz v4, :cond_18

    move v5, v12

    goto :goto_19

    :cond_18
    move v5, v3

    :goto_19
    const-string v6, "eglGetDisplay failed"

    invoke-static {v6, v5}, Lm7/x;->c(Ljava/lang/String;Z)V

    const/4 v13, 0x2

    new-array v5, v13, [I

    invoke-static {v4, v5, v3, v5, v12}, Landroid/opengl/EGL14;->eglInitialize(Landroid/opengl/EGLDisplay;[II[II)Z

    move-result v5

    const-string v6, "eglInitialize failed"

    invoke-static {v6, v5}, Lm7/x;->c(Ljava/lang/String;Z)V

    iput-object v4, v2, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    new-array v14, v12, [Landroid/opengl/EGLConfig;

    new-array v15, v12, [I

    sget-object v5, LZ0/g;->g:[I

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v11, 0x0

    move-object v7, v14

    move-object v10, v15

    invoke-static/range {v4 .. v11}, Landroid/opengl/EGL14;->eglChooseConfig(Landroid/opengl/EGLDisplay;[II[Landroid/opengl/EGLConfig;II[II)Z

    move-result v4

    if-eqz v4, :cond_48

    aget v5, v15, v3

    if-lez v5, :cond_48

    aget-object v5, v14, v3

    if-eqz v5, :cond_48

    move v5, v12

    goto :goto_49

    :cond_48
    move v5, v3

    :goto_49
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    aget v6, v15, v3

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aget-object v7, v14, v3

    filled-new-array {v4, v6, v7}, [Ljava/lang/Object;

    move-result-object v4

    sget v6, LZ0/F;->a:I

    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v7, "eglChooseConfig failed: success=%b, numConfigs[0]=%d, configs[0]=%s"

    invoke-static {v6, v7, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v5}, Lm7/x;->c(Ljava/lang/String;Z)V

    aget-object v4, v14, v3

    iget-object v5, v2, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    const/4 v6, 0x4

    const/16 v7, 0x32c0

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/16 v10, 0x3038

    const/16 v11, 0x3098

    if-nez v1, :cond_7e

    new-array v14, v9, [I

    aput v11, v14, v3

    aput v13, v14, v12

    aput v10, v14, v13

    goto :goto_8a

    :cond_7e
    new-array v14, v8, [I

    aput v11, v14, v3

    aput v13, v14, v12

    aput v7, v14, v13

    aput v12, v14, v9

    aput v10, v14, v6

    :goto_8a
    sget-object v11, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    invoke-static {v5, v4, v11, v14, v3}, Landroid/opengl/EGL14;->eglCreateContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;Landroid/opengl/EGLContext;[II)Landroid/opengl/EGLContext;

    move-result-object v5

    if-eqz v5, :cond_94

    move v11, v12

    goto :goto_95

    :cond_94
    move v11, v3

    :goto_95
    const-string v14, "eglCreateContext failed"

    invoke-static {v14, v11}, Lm7/x;->c(Ljava/lang/String;Z)V

    iput-object v5, v2, LZ0/g;->d:Landroid/opengl/EGLContext;

    iget-object v11, v2, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    if-ne v1, v12, :cond_a3

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    goto :goto_d9

    :cond_a3
    const/16 v14, 0x3056

    const/16 v15, 0x3057

    if-ne v1, v13, :cond_be

    const/4 v10, 0x7

    new-array v10, v10, [I

    aput v15, v10, v3

    aput v12, v10, v12

    aput v14, v10, v13

    aput v12, v10, v9

    aput v7, v10, v6

    aput v12, v10, v8

    const/4 v6, 0x6

    const/16 v7, 0x3038

    aput v7, v10, v6

    goto :goto_cb

    :cond_be
    move v7, v10

    new-array v10, v8, [I

    aput v15, v10, v3

    aput v12, v10, v12

    aput v14, v10, v13

    aput v12, v10, v9

    aput v7, v10, v6

    :goto_cb
    invoke-static {v11, v4, v10, v3}, Landroid/opengl/EGL14;->eglCreatePbufferSurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;[II)Landroid/opengl/EGLSurface;

    move-result-object v4

    if-eqz v4, :cond_d3

    move v6, v12

    goto :goto_d4

    :cond_d3
    move v6, v3

    :goto_d4
    const-string v7, "eglCreatePbufferSurface failed"

    invoke-static {v7, v6}, Lm7/x;->c(Ljava/lang/String;Z)V

    :goto_d9
    invoke-static {v11, v4, v4, v5}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    move-result v5

    const-string v6, "eglMakeCurrent failed"

    invoke-static {v6, v5}, Lm7/x;->c(Ljava/lang/String;Z)V

    iput-object v4, v2, LZ0/g;->e:Landroid/opengl/EGLSurface;

    iget-object v4, v2, LZ0/g;->b:[I

    invoke-static {v12, v4, v3}, Landroid/opengl/GLES20;->glGenTextures(I[II)V

    invoke-static {}, Lm7/x;->b()V

    new-instance v5, Landroid/graphics/SurfaceTexture;

    aget v4, v4, v3

    invoke-direct {v5, v4}, Landroid/graphics/SurfaceTexture;-><init>(I)V

    iput-object v5, v2, LZ0/g;->f:Landroid/graphics/SurfaceTexture;

    invoke-virtual {v5, v2}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    new-instance v2, Landroidx/media3/exoplayer/video/PlaceholderSurface;

    iget-object v4, v0, LB1/r;->a:LZ0/g;

    iget-object v4, v4, LZ0/g;->f:Landroid/graphics/SurfaceTexture;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz v1, :cond_104

    move v3, v12

    :cond_104
    invoke-direct {v2, v0, v4, v3}, Landroidx/media3/exoplayer/video/PlaceholderSurface;-><init>(LB1/r;Landroid/graphics/SurfaceTexture;Z)V

    iput-object v2, v0, LB1/r;->e:Landroidx/media3/exoplayer/video/PlaceholderSurface;

    return-void
.end method

.method public final b()V
    .registers 7

    iget-object v0, p0, LB1/r;->a:LZ0/g;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, LB1/r;->a:LZ0/g;

    iget-object v1, v0, LZ0/g;->a:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v1, 0x0

    :try_start_d
    iget-object v2, v0, LZ0/g;->f:Landroid/graphics/SurfaceTexture;

    if-eqz v2, :cond_1e

    invoke-virtual {v2}, Landroid/graphics/SurfaceTexture;->release()V

    iget-object v2, v0, LZ0/g;->b:[I

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v4, v2, v3}, Landroid/opengl/GLES20;->glDeleteTextures(I[II)V
    :try_end_1b
    .catchall {:try_start_d .. :try_end_1b} :catchall_1c

    goto :goto_1e

    :catchall_1c
    move-exception v2

    goto :goto_6c

    :cond_1e
    :goto_1e
    iget-object v2, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    if-eqz v2, :cond_33

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v2, v3}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_33

    iget-object v2, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    invoke-static {v2, v3, v3, v4}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    :cond_33
    iget-object v2, v0, LZ0/g;->e:Landroid/opengl/EGLSurface;

    if-eqz v2, :cond_46

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    invoke-virtual {v2, v3}, Landroid/opengl/EGLSurface;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_46

    iget-object v2, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    iget-object v3, v0, LZ0/g;->e:Landroid/opengl/EGLSurface;

    invoke-static {v2, v3}, Landroid/opengl/EGL14;->eglDestroySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    :cond_46
    iget-object v2, v0, LZ0/g;->d:Landroid/opengl/EGLContext;

    if-eqz v2, :cond_4f

    iget-object v3, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v3, v2}, Landroid/opengl/EGL14;->eglDestroyContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLContext;)Z

    :cond_4f
    invoke-static {}, Landroid/opengl/EGL14;->eglReleaseThread()Z

    iget-object v2, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    if-eqz v2, :cond_63

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v2, v3}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_63

    iget-object v2, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v2}, Landroid/opengl/EGL14;->eglTerminate(Landroid/opengl/EGLDisplay;)Z

    :cond_63
    iput-object v1, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    iput-object v1, v0, LZ0/g;->d:Landroid/opengl/EGLContext;

    iput-object v1, v0, LZ0/g;->e:Landroid/opengl/EGLSurface;

    iput-object v1, v0, LZ0/g;->f:Landroid/graphics/SurfaceTexture;

    return-void

    :goto_6c
    iget-object v3, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    if-eqz v3, :cond_81

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v3, v4}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_81

    iget-object v3, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    sget-object v5, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    invoke-static {v3, v4, v4, v5}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    :cond_81
    iget-object v3, v0, LZ0/g;->e:Landroid/opengl/EGLSurface;

    if-eqz v3, :cond_94

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    invoke-virtual {v3, v4}, Landroid/opengl/EGLSurface;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94

    iget-object v3, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    iget-object v4, v0, LZ0/g;->e:Landroid/opengl/EGLSurface;

    invoke-static {v3, v4}, Landroid/opengl/EGL14;->eglDestroySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    :cond_94
    iget-object v3, v0, LZ0/g;->d:Landroid/opengl/EGLContext;

    if-eqz v3, :cond_9d

    iget-object v4, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v4, v3}, Landroid/opengl/EGL14;->eglDestroyContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLContext;)Z

    :cond_9d
    invoke-static {}, Landroid/opengl/EGL14;->eglReleaseThread()Z

    iget-object v3, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    if-eqz v3, :cond_b1

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    invoke-virtual {v3, v4}, Landroid/opengl/EGLDisplay;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_b1

    iget-object v3, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    invoke-static {v3}, Landroid/opengl/EGL14;->eglTerminate(Landroid/opengl/EGLDisplay;)Z

    :cond_b1
    iput-object v1, v0, LZ0/g;->c:Landroid/opengl/EGLDisplay;

    iput-object v1, v0, LZ0/g;->d:Landroid/opengl/EGLContext;

    iput-object v1, v0, LZ0/g;->e:Landroid/opengl/EGLSurface;

    iput-object v1, v0, LZ0/g;->f:Landroid/graphics/SurfaceTexture;

    throw v2
.end method

.method public final handleMessage(Landroid/os/Message;)Z
    .registers 5

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1f

    const/4 p1, 0x2

    if-eq v0, p1, :cond_9

    return v1

    :cond_9
    :try_start_9
    invoke-virtual {p0}, LB1/r;->b()V
    :try_end_c
    .catchall {:try_start_9 .. :try_end_c} :catchall_10

    :goto_c
    invoke-virtual {p0}, Landroid/os/HandlerThread;->quit()Z

    goto :goto_19

    :catchall_10
    move-exception p1

    :try_start_11
    const-string v0, "PlaceholderSurface"

    const-string v2, "Failed to release placeholder surface"

    invoke-static {v0, v2, p1}, LZ0/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_18
    .catchall {:try_start_11 .. :try_end_18} :catchall_1a

    goto :goto_c

    :goto_19
    return v1

    :catchall_1a
    move-exception p1

    invoke-virtual {p0}, Landroid/os/HandlerThread;->quit()Z

    throw p1

    :cond_1f
    :try_start_1f
    iget p1, p1, Landroid/os/Message;->arg1:I

    invoke-virtual {p0, p1}, LB1/r;->a(I)V
    :try_end_24
    .catch Ljava/lang/RuntimeException; {:try_start_1f .. :try_end_24} :catch_33
    .catch LZ0/i; {:try_start_1f .. :try_end_24} :catch_31
    .catch Ljava/lang/Error; {:try_start_1f .. :try_end_24} :catch_2f
    .catchall {:try_start_1f .. :try_end_24} :catchall_2d

    monitor-enter p0

    :try_start_25
    invoke-virtual {p0}, Ljava/lang/Object;->notify()V

    monitor-exit p0

    goto :goto_6c

    :catchall_2a
    move-exception p1

    monitor-exit p0
    :try_end_2c
    .catchall {:try_start_25 .. :try_end_2c} :catchall_2a

    throw p1

    :catchall_2d
    move-exception p1

    goto :goto_70

    :catch_2f
    move-exception p1

    goto :goto_35

    :catch_31
    move-exception p1

    goto :goto_47

    :catch_33
    move-exception p1

    goto :goto_5e

    :goto_35
    :try_start_35
    const-string v0, "PlaceholderSurface"

    const-string v2, "Failed to initialize placeholder surface"

    invoke-static {v0, v2, p1}, LZ0/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iput-object p1, p0, LB1/r;->c:Ljava/lang/Error;
    :try_end_3e
    .catchall {:try_start_35 .. :try_end_3e} :catchall_2d

    monitor-enter p0

    :try_start_3f
    invoke-virtual {p0}, Ljava/lang/Object;->notify()V

    monitor-exit p0

    goto :goto_6c

    :catchall_44
    move-exception p1

    monitor-exit p0
    :try_end_46
    .catchall {:try_start_3f .. :try_end_46} :catchall_44

    throw p1

    :goto_47
    :try_start_47
    const-string v0, "PlaceholderSurface"

    const-string v2, "Failed to initialize placeholder surface"

    invoke-static {v0, v2, p1}, LZ0/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    iput-object v0, p0, LB1/r;->d:Ljava/lang/RuntimeException;
    :try_end_55
    .catchall {:try_start_47 .. :try_end_55} :catchall_2d

    monitor-enter p0

    :try_start_56
    invoke-virtual {p0}, Ljava/lang/Object;->notify()V

    monitor-exit p0

    goto :goto_6c

    :catchall_5b
    move-exception p1

    monitor-exit p0
    :try_end_5d
    .catchall {:try_start_56 .. :try_end_5d} :catchall_5b

    throw p1

    :goto_5e
    :try_start_5e
    const-string v0, "PlaceholderSurface"

    const-string v2, "Failed to initialize placeholder surface"

    invoke-static {v0, v2, p1}, LZ0/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iput-object p1, p0, LB1/r;->d:Ljava/lang/RuntimeException;
    :try_end_67
    .catchall {:try_start_5e .. :try_end_67} :catchall_2d

    monitor-enter p0

    :try_start_68
    invoke-virtual {p0}, Ljava/lang/Object;->notify()V

    monitor-exit p0

    :goto_6c
    return v1

    :catchall_6d
    move-exception p1

    monitor-exit p0
    :try_end_6f
    .catchall {:try_start_68 .. :try_end_6f} :catchall_6d

    throw p1

    :goto_70
    monitor-enter p0

    :try_start_71
    invoke-virtual {p0}, Ljava/lang/Object;->notify()V

    monitor-exit p0
    :try_end_75
    .catchall {:try_start_71 .. :try_end_75} :catchall_76

    throw p1

    :catchall_76
    move-exception p1

    :try_start_77
    monitor-exit p0
    :try_end_78
    .catchall {:try_start_77 .. :try_end_78} :catchall_76

    throw p1
.end method
