.class public final LB1/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/opengl/GLSurfaceView$Renderer;


# static fields
.field public static final g:[Ljava/lang/String;

.field public static final h:Ljava/nio/FloatBuffer;


# instance fields
.field public final a:[I

.field public final b:[I

.field public final c:[I

.field public final d:[I

.field public final e:Ljava/util/concurrent/atomic/AtomicReference;

.field public f:LZ0/h;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string v0, "v_tex"

    const-string v1, "y_tex"

    const-string v2, "u_tex"

    filled-new-array {v1, v2, v0}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, LB1/s;->g:[Ljava/lang/String;

    const/16 v0, 0x8

    new-array v0, v0, [F

    fill-array-data v0, :array_1a

    invoke-static {v0}, Lm7/x;->d([F)Ljava/nio/FloatBuffer;

    move-result-object v0

    sput-object v0, LB1/s;->h:Ljava/nio/FloatBuffer;

    return-void

    :array_1a
    .array-data 4
        -0x40800000    # -1.0f
        0x3f800000    # 1.0f
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        -0x40800000    # -1.0f
    .end array-data
.end method

.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    new-array v1, v0, [I

    iput-object v1, p0, LB1/s;->a:[I

    new-array v1, v0, [I

    iput-object v1, p0, LB1/s;->b:[I

    new-array v1, v0, [I

    iput-object v1, p0, LB1/s;->c:[I

    new-array v1, v0, [I

    iput-object v1, p0, LB1/s;->d:[I

    new-instance v1, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object v1, p0, LB1/s;->e:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x0

    :goto_1c
    if-ge v1, v0, :cond_2a

    iget-object v2, p0, LB1/s;->c:[I

    iget-object v3, p0, LB1/s;->d:[I

    const/4 v4, -0x1

    aput v4, v3, v1

    aput v4, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_1c

    :cond_2a
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 6

    iget-object v0, p0, LB1/s;->a:[I

    const/4 v1, 0x0

    const/4 v2, 0x3

    :try_start_4
    invoke-static {v2, v0, v1}, Landroid/opengl/GLES20;->glGenTextures(I[II)V

    :goto_7
    if-ge v1, v2, :cond_2b

    iget-object v3, p0, LB1/s;->f:LZ0/h;

    sget-object v4, LB1/s;->g:[Ljava/lang/String;

    aget-object v4, v4, v1

    iget v3, v3, LZ0/h;->a:I

    invoke-static {v3, v4}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v3

    invoke-static {v3, v1}, Landroid/opengl/GLES20;->glUniform1i(II)V

    const v3, 0x84c0

    add-int/2addr v3, v1

    invoke-static {v3}, Landroid/opengl/GLES20;->glActiveTexture(I)V

    aget v3, v0, v1

    const/16 v4, 0xde1

    invoke-static {v4, v3}, Lm7/x;->a(II)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :catch_29
    move-exception v0

    goto :goto_2f

    :cond_2b
    invoke-static {}, Lm7/x;->b()V
    :try_end_2e
    .catch LZ0/i; {:try_start_4 .. :try_end_2e} :catch_29

    goto :goto_36

    :goto_2f
    const-string v1, "VideoDecoderGLSV"

    const-string v2, "Failed to set up the textures"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_36
    return-void
.end method

.method public final onDrawFrame(Ljavax/microedition/khronos/opengles/GL10;)V
    .registers 3

    iget-object p1, p0, LB1/s;->e:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le/b;->p(Ljava/lang/Object;)V

    return-void
.end method

.method public final onSurfaceChanged(Ljavax/microedition/khronos/opengles/GL10;II)V
    .registers 4

    const/4 p1, 0x0

    invoke-static {p1, p1, p2, p3}, Landroid/opengl/GLES20;->glViewport(IIII)V

    return-void
.end method

.method public final onSurfaceCreated(Ljavax/microedition/khronos/opengles/GL10;Ljavax/microedition/khronos/egl/EGLConfig;)V
    .registers 10

    iget-object p1, p0, LB1/s;->b:[I

    :try_start_2
    new-instance p2, LZ0/h;

    const-string v0, "varying vec2 interp_tc_y;\nvarying vec2 interp_tc_u;\nvarying vec2 interp_tc_v;\nattribute vec4 in_pos;\nattribute vec2 in_tc_y;\nattribute vec2 in_tc_u;\nattribute vec2 in_tc_v;\nvoid main() {\n  gl_Position = in_pos;\n  interp_tc_y = in_tc_y;\n  interp_tc_u = in_tc_u;\n  interp_tc_v = in_tc_v;\n}\n"

    const-string v1, "precision mediump float;\nvarying vec2 interp_tc_y;\nvarying vec2 interp_tc_u;\nvarying vec2 interp_tc_v;\nuniform sampler2D y_tex;\nuniform sampler2D u_tex;\nuniform sampler2D v_tex;\nuniform mat3 mColorConversion;\nvoid main() {\n  vec3 yuv;\n  yuv.x = texture2D(y_tex, interp_tc_y).r - 0.0625;\n  yuv.y = texture2D(u_tex, interp_tc_u).r - 0.5;\n  yuv.z = texture2D(v_tex, interp_tc_v).r - 0.5;\n  gl_FragColor = vec4(mColorConversion * yuv, 1.0);\n}\n"

    invoke-direct {p2, v0, v1}, LZ0/h;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    iput-object p2, p0, LB1/s;->f:LZ0/h;

    const-string v0, "in_pos"

    invoke-virtual {p2, v0}, LZ0/h;->c(Ljava/lang/String;)I

    move-result v1

    sget-object v6, LB1/s;->h:Ljava/nio/FloatBuffer;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/16 v3, 0x1406

    invoke-static/range {v1 .. v6}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    iget-object p2, p0, LB1/s;->f:LZ0/h;

    const-string v0, "in_tc_y"

    invoke-virtual {p2, v0}, LZ0/h;->c(Ljava/lang/String;)I

    move-result p2

    const/4 v0, 0x0

    aput p2, p1, v0

    iget-object p2, p0, LB1/s;->f:LZ0/h;

    const-string v0, "in_tc_u"

    invoke-virtual {p2, v0}, LZ0/h;->c(Ljava/lang/String;)I

    move-result p2

    const/4 v0, 0x1

    aput p2, p1, v0

    iget-object p2, p0, LB1/s;->f:LZ0/h;

    const-string v0, "in_tc_v"

    invoke-virtual {p2, v0}, LZ0/h;->c(Ljava/lang/String;)I

    move-result p2

    const/4 v0, 0x2

    aput p2, p1, v0

    iget-object p1, p0, LB1/s;->f:LZ0/h;

    const-string p2, "mColorConversion"

    iget p1, p1, LZ0/h;->a:I

    invoke-static {p1, p2}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    invoke-static {}, Lm7/x;->b()V

    invoke-virtual {p0}, LB1/s;->a()V

    invoke-static {}, Lm7/x;->b()V
    :try_end_50
    .catch LZ0/i; {:try_start_2 .. :try_end_50} :catch_51

    goto :goto_59

    :catch_51
    move-exception p1

    const-string p2, "VideoDecoderGLSV"

    const-string v0, "Failed to set up the textures and program"

    invoke-static {p2, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_59
    return-void
.end method
