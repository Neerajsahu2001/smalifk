.class public final LB1/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Handler$Callback;


# instance fields
.field public final a:Landroid/os/Handler;

.field public final synthetic b:LB1/q;


# direct methods
.method public constructor <init>(LB1/q;Lo1/k;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB1/p;->b:LB1/q;

    invoke-static {p0}, LZ0/F;->n(Landroid/os/Handler$Callback;)Landroid/os/Handler;

    move-result-object p1

    iput-object p1, p0, LB1/p;->a:Landroid/os/Handler;

    invoke-interface {p2, p0, p1}, Lo1/k;->e(LB1/p;Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public final a(J)V
    .registers 11

    iget-object v0, p0, LB1/p;->b:LB1/q;

    iget-object v1, v0, LB1/q;->c2:LB1/p;

    if-ne p0, v1, :cond_65

    iget-object v1, v0, Lo1/u;->L:Lo1/k;

    if-nez v1, :cond_b

    goto :goto_65

    :cond_b
    const-wide v1, 0x7fffffffffffffffL

    cmp-long v1, p1, v1

    const/4 v2, 0x1

    if-nez v1, :cond_18

    iput-boolean v2, v0, Lo1/u;->r1:Z

    goto :goto_65

    :cond_18
    :try_start_18
    invoke-virtual {v0, p1, p2}, Lo1/u;->y0(J)V

    iget-object v1, v0, LB1/q;->X1:LW0/e0;

    invoke-virtual {v0, v1}, LB1/q;->E0(LW0/e0;)V

    iget-object v1, v0, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget v3, v1, Landroidx/media3/exoplayer/f;->e:I

    add-int/2addr v3, v2

    iput v3, v1, Landroidx/media3/exoplayer/f;->e:I

    iget-object v1, v0, LB1/q;->D1:LB1/w;

    iget v3, v1, LB1/w;->e:I

    const/4 v4, 0x3

    if-eq v3, v4, :cond_30

    move v3, v2

    goto :goto_31

    :cond_30
    const/4 v3, 0x0

    :goto_31
    iput v4, v1, LB1/w;->e:I

    iget-object v4, v1, LB1/w;->l:LZ0/y;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    invoke-static {v4, v5}, LZ0/F;->Q(J)J

    move-result-wide v4

    iput-wide v4, v1, LB1/w;->g:J

    if-eqz v3, :cond_5e

    iget-object v1, v0, LB1/q;->L1:Landroid/view/Surface;

    if-eqz v1, :cond_5e

    iget-object v3, v0, LB1/q;->A1:LW2/p;

    iget-object v4, v3, LW2/p;->b:Ljava/lang/Object;

    check-cast v4, Landroid/os/Handler;

    if-eqz v4, :cond_5c

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    new-instance v7, LB1/E;

    invoke-direct {v7, v3, v1, v5, v6}, LB1/E;-><init>(LW2/p;Ljava/lang/Object;J)V

    invoke-virtual {v4, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_5c
    iput-boolean v2, v0, LB1/q;->O1:Z

    :cond_5e
    invoke-virtual {v0, p1, p2}, LB1/q;->g0(J)V
    :try_end_61
    .catch Landroidx/media3/exoplayer/m; {:try_start_18 .. :try_end_61} :catch_62

    goto :goto_65

    :catch_62
    move-exception p1

    iput-object p1, v0, Lo1/u;->s1:Landroidx/media3/exoplayer/m;

    :cond_65
    :goto_65
    return-void
.end method

.method public final handleMessage(Landroid/os/Message;)Z
    .registers 8

    iget v0, p1, Landroid/os/Message;->what:I

    if-eqz v0, :cond_6

    const/4 p1, 0x0

    return p1

    :cond_6
    iget v0, p1, Landroid/os/Message;->arg1:I

    iget p1, p1, Landroid/os/Message;->arg2:I

    sget v1, LZ0/F;->a:I

    int-to-long v0, v0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    const/16 v4, 0x20

    shl-long/2addr v0, v4

    int-to-long v4, p1

    and-long/2addr v2, v4

    or-long/2addr v0, v2

    invoke-virtual {p0, v0, v1}, LB1/p;->a(J)V

    const/4 p1, 0x1

    return p1
.end method
