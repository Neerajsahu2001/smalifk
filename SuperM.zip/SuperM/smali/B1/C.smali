.class public abstract Lb1/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "media3.database"

    invoke-static {v0}, LW0/F;->a(Ljava/lang/String;)V

    return-void
.end method

.method public static a(Landroid/database/sqlite/SQLiteDatabase;ILjava/lang/String;)I
    .registers 14

    :try_start_0
    sget v0, LZ0/F;->a:I

    const-string v0, "ExoPlayerVersions"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const-string v1, "sqlite_master"

    const-string v2, "tbl_name = ?"

    invoke-static {p0, v1, v2, v0}, Landroid/database/DatabaseUtils;->queryNumEntries(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    if-lez v0, :cond_19

    const/4 v0, 0x1

    goto :goto_1a

    :cond_19
    move v0, v1

    :goto_1a
    const/4 v2, -0x1

    if-nez v0, :cond_1e

    return v2

    :cond_1e
    const-string v4, "ExoPlayerVersions"

    const-string v0, "version"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v5

    const-string v6, "feature = ? AND instance_uid = ?"

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1, p2}, [Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v3, p0

    invoke-virtual/range {v3 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0
    :try_end_38
    .catch Landroid/database/SQLException; {:try_start_0 .. :try_end_38} :catch_42

    :try_start_38
    invoke-interface {p0}, Landroid/database/Cursor;->getCount()I

    move-result p1
    :try_end_3c
    .catchall {:try_start_38 .. :try_end_3c} :catchall_4f

    if-nez p1, :cond_44

    :try_start_3e
    invoke-interface {p0}, Landroid/database/Cursor;->close()V
    :try_end_41
    .catch Landroid/database/SQLException; {:try_start_3e .. :try_end_41} :catch_42

    return v2

    :catch_42
    move-exception p0

    goto :goto_5b

    :cond_44
    :try_start_44
    invoke-interface {p0}, Landroid/database/Cursor;->moveToNext()Z

    invoke-interface {p0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result p1
    :try_end_4b
    .catchall {:try_start_44 .. :try_end_4b} :catchall_4f

    :try_start_4b
    invoke-interface {p0}, Landroid/database/Cursor;->close()V
    :try_end_4e
    .catch Landroid/database/SQLException; {:try_start_4b .. :try_end_4e} :catch_42

    return p1

    :catchall_4f
    move-exception p1

    if-eqz p0, :cond_5a

    :try_start_52
    invoke-interface {p0}, Landroid/database/Cursor;->close()V
    :try_end_55
    .catchall {:try_start_52 .. :try_end_55} :catchall_56

    goto :goto_5a

    :catchall_56
    move-exception p0

    :try_start_57
    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_5a
    :goto_5a
    throw p1
    :try_end_5b
    .catch Landroid/database/SQLException; {:try_start_57 .. :try_end_5b} :catch_42

    :goto_5b
    new-instance p1, Lb1/a;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method

.method public static b(Landroid/database/sqlite/SQLiteDatabase;ILjava/lang/String;)V
    .registers 5

    :try_start_0
    const-string v0, "CREATE TABLE IF NOT EXISTS ExoPlayerVersions (feature INTEGER NOT NULL,instance_uid TEXT NOT NULL,version INTEGER NOT NULL,PRIMARY KEY (feature, instance_uid))"

    invoke-virtual {p0, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const-string v1, "feature"

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string p1, "instance_uid"

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "version"

    const/4 p2, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string p1, "ExoPlayerVersions"

    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2, v0}, Landroid/database/sqlite/SQLiteDatabase;->replaceOrThrow(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    :try_end_28
    .catch Landroid/database/SQLException; {:try_start_0 .. :try_end_28} :catch_29

    return-void

    :catch_29
    move-exception p0

    new-instance p1, Lb1/a;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method
