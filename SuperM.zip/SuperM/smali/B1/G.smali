.class public final synthetic LB1/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, LB1/g;->a:I

    iput-object p2, p0, LB1/g;->b:Ljava/lang/Object;

    iput-object p3, p0, LB1/g;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a()V
    .registers 9

    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Lfc/l;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Lx9/o;

    const-string v2, "$builder"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "$sdkInstance"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v0, Lfc/l;->c:Ljava/lang/Object;

    check-cast v2, Lr9/a;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1}, Lc9/u;->e(Lx9/o;)Lc9/s;

    move-result-object v1

    iget-object v0, v0, Lfc/l;->b:Ljava/lang/Object;

    check-cast v0, Landroid/app/Application;

    const-string v2, "application"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    monitor-enter v1

    :try_start_27
    iget-object v2, v1, Lc9/s;->a:Lx9/o;

    iget-object v2, v2, Lx9/o;->d:Lw9/g;

    new-instance v3, Lc9/n;

    const/4 v4, 0x0

    invoke-direct {v3, v1, v4}, Lc9/n;-><init>(Lc9/s;I)V

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v2, v4, v3, v5}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    iget-object v2, v1, Lc9/s;->f:Lt9/a;

    if-eqz v2, :cond_4c

    iget-object v2, v1, Lc9/s;->a:Lx9/o;

    iget-object v2, v2, Lx9/o;->d:Lw9/g;

    new-instance v3, Lc9/o;

    const/4 v6, 0x0

    invoke-direct {v3, v1, v6}, Lc9/o;-><init>(Lc9/s;I)V

    invoke-static {v2, v4, v3, v5}, Lw9/g;->b(Lw9/g;ILHc/a;I)V
    :try_end_47
    .catchall {:try_start_27 .. :try_end_47} :catchall_49

    monitor-exit v1

    goto :goto_68

    :catchall_49
    move-exception v0

    goto/16 :goto_dc

    :cond_4c
    :try_start_4c
    iget-object v2, v1, Lc9/s;->a:Lx9/o;

    iget-object v2, v2, Lx9/o;->d:Lw9/g;

    new-instance v3, Lc9/p;

    const/4 v6, 0x0

    invoke-direct {v3, v1, v6}, Lc9/p;-><init>(Lc9/s;I)V

    invoke-static {v2, v4, v3, v5}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    new-instance v2, Lt9/a;

    iget-object v3, v1, Lc9/s;->a:Lx9/o;

    iget-object v6, v1, Lc9/s;->h:Lk9/a;

    invoke-direct {v2, v3, v6}, Lt9/a;-><init>(Lx9/o;Lk9/a;)V

    iput-object v2, v1, Lc9/s;->f:Lt9/a;

    invoke-virtual {v0, v2}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V
    :try_end_67
    .catchall {:try_start_4c .. :try_end_67} :catchall_49

    monitor-exit v1

    :goto_68
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v2, "application.applicationContext"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-class v2, Lc9/s;

    monitor-enter v2

    :try_start_74
    iget-object v3, v1, Lc9/s;->a:Lx9/o;

    iget-object v3, v3, Lx9/o;->d:Lw9/g;

    new-instance v6, Lc9/q;

    const/4 v7, 0x0

    invoke-direct {v6, v1, v7}, Lc9/q;-><init>(Lc9/s;I)V

    invoke-static {v3, v4, v6, v5}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    iget-object v3, v1, Lc9/s;->e:Lt9/g;

    if-eqz v3, :cond_96

    iget-object v0, v1, Lc9/s;->a:Lx9/o;

    iget-object v0, v0, Lx9/o;->d:Lw9/g;

    new-instance v3, Lc9/r;

    const/4 v6, 0x0

    invoke-direct {v3, v1, v6}, Lc9/r;-><init>(Lc9/s;I)V

    invoke-static {v0, v4, v3, v5}, Lw9/g;->b(Lw9/g;ILHc/a;I)V
    :try_end_92
    .catchall {:try_start_74 .. :try_end_92} :catchall_94

    monitor-exit v2

    goto :goto_d8

    :catchall_94
    move-exception v0

    goto :goto_c9

    :cond_96
    :try_start_96
    new-instance v3, Lt9/g;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v6, "context.applicationContext"

    invoke-static {v0, v6}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v6, v1, Lc9/s;->a:Lx9/o;

    invoke-direct {v3, v0, v6}, Lt9/g;-><init>(Landroid/content/Context;Lx9/o;)V

    iput-object v3, v1, Lc9/s;->e:Lt9/g;

    invoke-static {}, Lm7/A;->v()Z

    move-result v0

    if-eqz v0, :cond_b2

    invoke-virtual {v1}, Lc9/s;->a()V

    goto :goto_d7

    :cond_b2
    iget-object v0, v1, Lc9/s;->a:Lx9/o;

    iget-object v0, v0, Lx9/o;->d:Lw9/g;

    new-instance v3, Lc9/j;

    const/4 v6, 0x1

    invoke-direct {v3, v1, v6}, Lc9/j;-><init>(Lc9/s;I)V

    invoke-static {v0, v4, v3, v5}, Lw9/g;->b(Lw9/g;ILHc/a;I)V

    new-instance v0, Lc9/k;

    const/4 v3, 0x1

    invoke-direct {v0, v1, v3}, Lc9/k;-><init>(Lc9/s;I)V

    invoke-static {v0}, Lm7/A;->C(LHc/a;)V
    :try_end_c8
    .catchall {:try_start_96 .. :try_end_c8} :catchall_94

    goto :goto_d7

    :goto_c9
    :try_start_c9
    iget-object v3, v1, Lc9/s;->a:Lx9/o;

    iget-object v3, v3, Lx9/o;->d:Lw9/g;

    new-instance v4, Lc9/l;

    const/4 v5, 0x1

    invoke-direct {v4, v1, v5}, Lc9/l;-><init>(Lc9/s;I)V

    const/4 v1, 0x1

    invoke-virtual {v3, v1, v0, v4}, Lw9/g;->a(ILjava/lang/Throwable;LHc/a;)V
    :try_end_d7
    .catchall {:try_start_c9 .. :try_end_d7} :catchall_d9

    :goto_d7
    monitor-exit v2

    :goto_d8
    return-void

    :catchall_d9
    move-exception v0

    monitor-exit v2

    throw v0

    :goto_dc
    monitor-exit v1

    throw v0
.end method


# virtual methods
.method public final run()V
    .registers 8

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget v2, p0, LB1/g;->a:I

    packed-switch v2, :pswitch_data_2f2

    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Lx/o;

    iget-object v0, v0, Lx/o;->a:Landroid/hardware/camera2/CameraDevice$StateCallback;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Landroid/hardware/camera2/CameraDevice;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraDevice$StateCallback;->onDisconnected(Landroid/hardware/camera2/CameraDevice;)V

    return-void

    :pswitch_15
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Lx/j;

    iget-object v0, v0, Lx/j;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Landroid/hardware/camera2/CameraCaptureSession;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onConfigureFailed(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void

    :pswitch_23
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Lw/e0;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Lw/e0;

    iget-object v2, v0, Lw/e0;->b:Ll7/G6;

    iget-object v3, v2, Ll7/G6;->b:Ljava/lang/Object;

    monitor-enter v3

    :try_start_30
    iget-object v4, v2, Ll7/G6;->c:Ljava/io/Serializable;

    check-cast v4, Ljava/util/LinkedHashSet;

    invoke-interface {v4, v0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    iget-object v2, v2, Ll7/G6;->d:Ljava/io/Serializable;

    check-cast v2, Ljava/util/LinkedHashSet;

    invoke-interface {v2, v0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v3
    :try_end_3f
    .catchall {:try_start_30 .. :try_end_3f} :catchall_4d

    invoke-virtual {v0, v1}, Lw/e0;->g(Lw/e0;)V

    iget-object v2, v0, Lw/e0;->f:Lw/c0;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v0, Lw/e0;->f:Lw/c0;

    invoke-virtual {v0, v1}, Lw/c0;->c(Lw/e0;)V

    return-void

    :catchall_4d
    move-exception v0

    :try_start_4e
    monitor-exit v3
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_4d

    throw v0

    :pswitch_50
    iget-object v0, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    iget-object v1, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v1, Lw/s;

    iget-object v2, v1, Lw/s;->f:Lw/l;

    :try_start_5a
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Lw/s;->v(Ljava/util/ArrayList;)V
    :try_end_5f
    .catchall {:try_start_5a .. :try_end_5f} :catchall_63

    invoke-virtual {v2}, Lw/l;->f()V

    return-void

    :catchall_63
    move-exception v0

    invoke-virtual {v2}, Lw/l;->f()V

    throw v0

    :pswitch_68
    invoke-direct {p0}, LB1/g;->a()V

    return-void

    :pswitch_6c
    const-string v0, "$job"

    iget-object v1, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v1, Lo9/a;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$onComplete"

    iget-object v2, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v2, LHc/b;

    invoke-static {v2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v1, Lo9/a;->c:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    invoke-interface {v2, v1}, LHc/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :pswitch_87
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/N;

    iget-object v2, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v2, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x0

    invoke-virtual {v2, v3, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v1

    if-eqz v1, :cond_bc

    iget-object v0, v0, Lio/sentry/android/core/N;->d:Lio/sentry/android/core/SentryPerformanceProvider;

    monitor-enter v0

    :try_start_9c
    invoke-static {}, Lio/sentry/android/core/performance/d;->c()Lio/sentry/android/core/performance/d;

    move-result-object v1

    iget-object v2, v1, Lio/sentry/android/core/performance/d;->d:Lio/sentry/android/core/performance/e;

    invoke-virtual {v2}, Lio/sentry/android/core/performance/e;->d()V

    iget-object v1, v1, Lio/sentry/android/core/performance/d;->c:Lio/sentry/android/core/performance/e;

    invoke-virtual {v1}, Lio/sentry/android/core/performance/e;->d()V

    iget-object v1, v0, Lio/sentry/android/core/SentryPerformanceProvider;->b:Landroid/app/Application;

    if-eqz v1, :cond_b8

    iget-object v2, v0, Lio/sentry/android/core/SentryPerformanceProvider;->c:Lio/sentry/android/core/N;

    if-eqz v2, :cond_b8

    invoke-virtual {v1, v2}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V
    :try_end_b5
    .catchall {:try_start_9c .. :try_end_b5} :catchall_b6

    goto :goto_b8

    :catchall_b6
    move-exception v1

    goto :goto_ba

    :cond_b8
    :goto_b8
    monitor-exit v0

    goto :goto_bc

    :goto_ba
    monitor-exit v0

    throw v1

    :cond_bc
    :goto_bc
    return-void

    :pswitch_bd
    iget-object v0, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v0, LB5/a;

    iget-object v1, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v1, Lio/sentry/SpotlightIntegration;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "Envelope sent to spotlight: %d"

    :try_start_ca
    iget-object v3, v1, Lio/sentry/SpotlightIntegration;->a:Lio/sentry/M1;

    if-eqz v3, :cond_16a

    invoke-virtual {v3}, Lio/sentry/M1;->getSpotlightConnectionUrl()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_db

    iget-object v3, v1, Lio/sentry/SpotlightIntegration;->a:Lio/sentry/M1;

    invoke-virtual {v3}, Lio/sentry/M1;->getSpotlightConnectionUrl()Ljava/lang/String;

    move-result-object v3

    goto :goto_e4

    :cond_db
    sget-boolean v3, Lio/sentry/util/d;->a:Z

    if-eqz v3, :cond_e2

    const-string v3, "http://10.0.2.2:8969/stream"

    goto :goto_e4

    :cond_e2
    const-string v3, "http://localhost:8969/stream"

    :goto_e4
    invoke-static {v3}, Lio/sentry/SpotlightIntegration;->i(Ljava/lang/String;)Ljava/net/HttpURLConnection;

    move-result-object v3
    :try_end_e8
    .catch Ljava/lang/Exception; {:try_start_ca .. :try_end_e8} :catch_11c

    :try_start_e8
    invoke-virtual {v3}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v4
    :try_end_ec
    .catchall {:try_start_e8 .. :try_end_ec} :catchall_103

    :try_start_ec
    new-instance v5, Ljava/util/zip/GZIPOutputStream;

    invoke-direct {v5, v4}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_f1
    .catchall {:try_start_ec .. :try_end_f1} :catchall_11e

    :try_start_f1
    iget-object v6, v1, Lio/sentry/SpotlightIntegration;->a:Lio/sentry/M1;

    invoke-virtual {v6}, Lio/sentry/M1;->getSerializer()Lio/sentry/O;

    move-result-object v6

    invoke-interface {v6, v0, v5}, Lio/sentry/O;->e(LB5/a;Ljava/io/OutputStream;)V
    :try_end_fa
    .catchall {:try_start_f1 .. :try_end_fa} :catchall_120

    :try_start_fa
    invoke-virtual {v5}, Ljava/io/OutputStream;->close()V
    :try_end_fd
    .catchall {:try_start_fa .. :try_end_fd} :catchall_11e

    if-eqz v4, :cond_105

    :try_start_ff
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_102
    .catchall {:try_start_ff .. :try_end_102} :catchall_103

    goto :goto_105

    :catchall_103
    move-exception v0

    goto :goto_135

    :cond_105
    :goto_105
    :try_start_105
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    iget-object v4, v1, Lio/sentry/SpotlightIntegration;->b:Lio/sentry/ILogger;

    sget-object v5, Lio/sentry/y1;->DEBUG:Lio/sentry/y1;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v4, v5, v2, v0}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_118
    invoke-static {v3}, Lio/sentry/SpotlightIntegration;->a(Ljava/net/HttpURLConnection;)V
    :try_end_11b
    .catch Ljava/lang/Exception; {:try_start_105 .. :try_end_11b} :catch_11c

    goto :goto_17b

    :catch_11c
    move-exception v0

    goto :goto_172

    :catchall_11e
    move-exception v0

    goto :goto_12a

    :catchall_120
    move-exception v0

    :try_start_121
    invoke-virtual {v5}, Ljava/io/OutputStream;->close()V
    :try_end_124
    .catchall {:try_start_121 .. :try_end_124} :catchall_125

    goto :goto_129

    :catchall_125
    move-exception v5

    :try_start_126
    invoke-virtual {v0, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_129
    throw v0
    :try_end_12a
    .catchall {:try_start_126 .. :try_end_12a} :catchall_11e

    :goto_12a
    if-eqz v4, :cond_134

    :try_start_12c
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_12f
    .catchall {:try_start_12c .. :try_end_12f} :catchall_130

    goto :goto_134

    :catchall_130
    move-exception v4

    :try_start_131
    invoke-virtual {v0, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_134
    :goto_134
    throw v0
    :try_end_135
    .catchall {:try_start_131 .. :try_end_135} :catchall_103

    :goto_135
    :try_start_135
    iget-object v4, v1, Lio/sentry/SpotlightIntegration;->b:Lio/sentry/ILogger;

    sget-object v5, Lio/sentry/y1;->ERROR:Lio/sentry/y1;

    const-string v6, "An exception occurred while submitting the envelope to the Sentry server."

    invoke-interface {v4, v5, v6, v0}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_13e
    .catchall {:try_start_135 .. :try_end_13e} :catchall_152

    :try_start_13e
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    iget-object v4, v1, Lio/sentry/SpotlightIntegration;->b:Lio/sentry/ILogger;

    sget-object v5, Lio/sentry/y1;->DEBUG:Lio/sentry/y1;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v4, v5, v2, v0}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_118

    :catchall_152
    move-exception v0

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    iget-object v5, v1, Lio/sentry/SpotlightIntegration;->b:Lio/sentry/ILogger;

    sget-object v6, Lio/sentry/y1;->DEBUG:Lio/sentry/y1;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    invoke-interface {v5, v6, v2, v4}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {v3}, Lio/sentry/SpotlightIntegration;->a(Ljava/net/HttpURLConnection;)V

    throw v0

    :cond_16a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v2, "SentryOptions are required to send envelopes."

    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_172
    .catch Ljava/lang/Exception; {:try_start_13e .. :try_end_172} :catch_11c

    :goto_172
    iget-object v1, v1, Lio/sentry/SpotlightIntegration;->b:Lio/sentry/ILogger;

    sget-object v2, Lio/sentry/y1;->ERROR:Lio/sentry/y1;

    const-string v3, "An exception occurred while creating the connection to spotlight."

    invoke-interface {v1, v2, v3, v0}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_17b
    return-void

    :pswitch_17c
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Landroid/app/Activity;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/facebook/react/modules/statusbar/StatusBarModule;->b(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_188
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/perf/session/gauges/CpuGaugeCollector;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/perf/util/Timer;

    invoke-static {v0, v1}, Lcom/google/firebase/perf/session/gauges/CpuGaugeCollector;->b(Lcom/google/firebase/perf/session/gauges/CpuGaugeCollector;Lcom/google/firebase/perf/util/Timer;)V

    return-void

    :pswitch_194
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map;

    invoke-static {v0, v1}, Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;->i(Lcom/google/firebase/crashlytics/internal/common/CrashlyticsCore;Ljava/util/Map;)V

    return-void

    :pswitch_1a0
    const-string v2, "$listener"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "$logoutMeta"

    iget-object v3, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v3, Lba/c;

    invoke-static {v3, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "this$0"

    iget-object v3, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v3, Lc9/z;

    invoke-static {v3, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_1b7
    throw v0
    :try_end_1b8
    .catchall {:try_start_1b7 .. :try_end_1b8} :catchall_1b8

    :catchall_1b8
    move-exception v0

    iget-object v2, v3, Lc9/z;->a:Lx9/o;

    iget-object v2, v2, Lx9/o;->d:Lw9/g;

    new-instance v4, LAa/c;

    const/16 v5, 0x18

    invoke-direct {v4, v5, v3}, LAa/c;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v2, v1, v0, v4}, Lw9/g;->a(ILjava/lang/Throwable;LHc/a;)V

    return-void

    :pswitch_1c8
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    const-string v2, "$context"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v2, LIe/i;

    const-string v3, "this$0"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v2, LIe/i;->b:Ljava/lang/Object;

    check-cast v2, Lx9/o;

    const-string v3, "sdkInstance"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lm7/A;->u(Lx9/o;)Z

    invoke-static {v0, v2}, Lm7/A;->z(Landroid/content/Context;Lx9/o;)V

    invoke-static {v0, v2}, Lc9/u;->h(Landroid/content/Context;Lx9/o;)LK9/b;

    move-result-object v0

    invoke-virtual {v0, v1}, LK9/b;->N(Z)V

    return-void

    :pswitch_1f1
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, LAa/t;

    iget-object v0, v0, LAa/t;->c:Ljava/lang/Object;

    check-cast v0, LC/P0;

    iget-object v0, v0, LC/P0;->i:Ljava/lang/Object;

    check-cast v0, Lg1/q;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Landroid/util/Pair;

    iget-object v2, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Lt1/E;

    invoke-virtual {v0, v2, v1}, Lg1/q;->p(ILt1/E;)V

    return-void

    :pswitch_211
    iget-object v0, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/o0;

    iget-object v2, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v2, Landroidx/media3/exoplayer/S;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_21c
    monitor-enter v0

    monitor-exit v0
    :try_end_21e
    .catch Landroidx/media3/exoplayer/m; {:try_start_21c .. :try_end_21e} :catch_230

    :try_start_21e
    iget-object v2, v0, Landroidx/media3/exoplayer/o0;->a:Landroidx/media3/exoplayer/n0;

    iget v3, v0, Landroidx/media3/exoplayer/o0;->d:I

    iget-object v4, v0, Landroidx/media3/exoplayer/o0;->e:Ljava/lang/Object;

    invoke-interface {v2, v3, v4}, Landroidx/media3/exoplayer/n0;->d(ILjava/lang/Object;)V
    :try_end_227
    .catchall {:try_start_21e .. :try_end_227} :catchall_22b

    :try_start_227
    invoke-virtual {v0, v1}, Landroidx/media3/exoplayer/o0;->b(Z)V

    return-void

    :catchall_22b
    move-exception v2

    invoke-virtual {v0, v1}, Landroidx/media3/exoplayer/o0;->b(Z)V

    throw v2
    :try_end_230
    .catch Landroidx/media3/exoplayer/m; {:try_start_227 .. :try_end_230} :catch_230

    :catch_230
    move-exception v0

    const-string v1, "ExoPlayerImplInternal"

    const-string v2, "Unexpected error delivering message on external thread."

    invoke-static {v1, v2, v0}, LZ0/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :pswitch_23e
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Ln8/r;

    const-string v2, "this$0"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "$innerFuture"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->f:Ljava/lang/Object;

    monitor-enter v2

    :try_start_253
    iget-boolean v3, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->g:Z

    if-eqz v3, :cond_26b

    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->h:LY2/k;

    const-string v1, "future"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, La3/a;->a:Ljava/lang/String;

    new-instance v1, LN2/j;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v0, v1}, LY2/k;->i(Ljava/lang/Object;)Z

    goto :goto_270

    :catchall_269
    move-exception v0

    goto :goto_272

    :cond_26b
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->h:LY2/k;

    invoke-virtual {v0, v1}, LY2/k;->k(Ln8/r;)Z
    :try_end_270
    .catchall {:try_start_253 .. :try_end_270} :catchall_269

    :goto_270
    monitor-exit v2

    return-void

    :goto_272
    monitor-exit v2

    throw v0

    :pswitch_274
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    const-string v1, "$listenersList"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, LU2/h;

    const-string v2, "this$0"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_28c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2a2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LT2/c;

    iget-object v3, v1, LU2/h;->e:Ljava/lang/Object;

    iput-object v3, v2, LT2/c;->d:Ljava/lang/Object;

    iget-object v4, v2, LT2/c;->e:LD9/f;

    invoke-virtual {v2, v4, v3}, LT2/c;->d(LD9/f;Ljava/lang/Object;)V

    goto :goto_28c

    :cond_2a2
    return-void

    :pswitch_2a3
    iget-object v1, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v1, LN/y;

    iget-object v2, v1, LN/y;->h:LC/P0;

    if-eqz v2, :cond_2b5

    iget-object v3, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v3, LC/P0;

    if-ne v2, v3, :cond_2b5

    iput-object v0, v1, LN/y;->h:LC/P0;

    iput-object v0, v1, LN/y;->g:Landroidx/concurrent/futures/n;

    :cond_2b5
    iget-object v2, v1, LN/y;->l:LN/i;

    if-eqz v2, :cond_2be

    invoke-virtual {v2}, LN/i;->a()V

    iput-object v0, v1, LN/y;->l:LN/i;

    :cond_2be
    return-void

    :pswitch_2bf
    new-instance v0, LC/h;

    const/4 v1, 0x3

    iget-object v2, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v2, Landroid/view/Surface;

    invoke-direct {v0, v1, v2}, LC/h;-><init>(ILandroid/view/Surface;)V

    iget-object v1, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v1, Lq0/a;

    invoke-interface {v1, v0}, Lq0/a;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_2d1
    iget-object v1, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v1, LC/B0;

    invoke-virtual {v1}, LC/B0;->e()V

    iget-object v1, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/concurrent/futures/k;

    if-eqz v1, :cond_2e1

    invoke-virtual {v1, v0}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    :cond_2e1
    return-void

    :pswitch_2e2
    iget-object v0, p0, LB1/g;->b:Ljava/lang/Object;

    check-cast v0, LB1/i;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, LB1/g;->c:Ljava/lang/Object;

    check-cast v0, LB1/L;

    invoke-interface {v0}, LB1/L;->v()V

    return-void

    nop

    :pswitch_data_2f2
    .packed-switch 0x0
        :pswitch_2e2
        :pswitch_2d1
        :pswitch_2bf
        :pswitch_2a3
        :pswitch_274
        :pswitch_23e
        :pswitch_211
        :pswitch_1f1
        :pswitch_1c8
        :pswitch_1a0
        :pswitch_194
        :pswitch_188
        :pswitch_17c
        :pswitch_bd
        :pswitch_87
        :pswitch_6c
        :pswitch_68
        :pswitch_50
        :pswitch_23
        :pswitch_15
    .end packed-switch
.end method
