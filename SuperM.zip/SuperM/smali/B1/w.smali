.class public final LB1/w;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LB1/q;

.field public final b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

.field public final c:J

.field public d:Z

.field public e:I

.field public f:J

.field public g:J

.field public h:J

.field public i:J

.field public j:Z

.field public k:F

.field public l:LZ0/y;


# direct methods
.method public constructor <init>(Landroid/content/Context;LB1/q;J)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LB1/w;->a:LB1/q;

    iput-wide p3, p0, LB1/w;->c:J

    new-instance p2, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    invoke-direct {p2, p1}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    const/4 p1, 0x0

    iput p1, p0, LB1/w;->e:I

    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide p1, p0, LB1/w;->f:J

    iput-wide p1, p0, LB1/w;->h:J

    iput-wide p1, p0, LB1/w;->i:J

    const/high16 p1, 0x3f800000    # 1.0f

    iput p1, p0, LB1/w;->k:F

    sget-object p1, LZ0/y;->a:LZ0/y;

    iput-object p1, p0, LB1/w;->l:LZ0/y;

    return-void
.end method


# virtual methods
.method public final a(JJJJZLB1/v;)I
    .registers 33

    move-object/from16 v0, p0

    move-wide/from16 v1, p1

    move-wide/from16 v3, p3

    move-object/from16 v5, p10

    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v6, v5, LB1/v;->a:J

    iput-wide v6, v5, LB1/v;->b:J

    iget-wide v8, v0, LB1/w;->f:J

    cmp-long v8, v8, v6

    if-nez v8, :cond_19

    iput-wide v3, v0, LB1/w;->f:J

    :cond_19
    iget-wide v8, v0, LB1/w;->h:J

    cmp-long v8, v8, v1

    const-wide/16 v9, -0x1

    const-wide/16 v13, 0x3e8

    const/4 v15, 0x0

    if-eqz v8, :cond_b5

    iget-object v8, v0, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iget-wide v11, v8, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    cmp-long v18, v11, v9

    if-eqz v18, :cond_32

    iput-wide v11, v8, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iget-wide v11, v8, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->o:J

    iput-wide v11, v8, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->q:J

    :cond_32
    iget-wide v11, v8, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    const-wide/16 v18, 0x1

    add-long v11, v11, v18

    iput-wide v11, v8, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    mul-long v11, v1, v13

    iget-object v9, v8, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->a:LB1/l;

    iget-object v10, v9, LB1/l;->a:LB1/k;

    invoke-virtual {v10, v11, v12}, LB1/k;->b(J)V

    iget-object v10, v9, LB1/l;->a:LB1/k;

    invoke-virtual {v10}, LB1/k;->a()Z

    move-result v10

    if-eqz v10, :cond_4e

    iput-boolean v15, v9, LB1/l;->c:Z

    goto :goto_88

    :cond_4e
    iget-wide v13, v9, LB1/l;->d:J

    cmp-long v10, v13, v6

    if-eqz v10, :cond_88

    iget-boolean v10, v9, LB1/l;->c:Z

    if-eqz v10, :cond_74

    iget-object v10, v9, LB1/l;->b:LB1/k;

    iget-wide v13, v10, LB1/k;->d:J

    const-wide/16 v16, 0x0

    cmp-long v20, v13, v16

    if-nez v20, :cond_64

    move v10, v15

    goto :goto_6f

    :cond_64
    sub-long v13, v13, v18

    const-wide/16 v18, 0xf

    rem-long v13, v13, v18

    long-to-int v13, v13

    iget-object v10, v10, LB1/k;->g:[Z

    aget-boolean v10, v10, v13

    :goto_6f
    if-eqz v10, :cond_72

    goto :goto_74

    :cond_72
    :goto_72
    const/4 v10, 0x1

    goto :goto_81

    :cond_74
    :goto_74
    iget-object v10, v9, LB1/l;->b:LB1/k;

    invoke-virtual {v10}, LB1/k;->c()V

    iget-object v10, v9, LB1/l;->b:LB1/k;

    iget-wide v13, v9, LB1/l;->d:J

    invoke-virtual {v10, v13, v14}, LB1/k;->b(J)V

    goto :goto_72

    :goto_81
    iput-boolean v10, v9, LB1/l;->c:Z

    iget-object v10, v9, LB1/l;->b:LB1/k;

    invoke-virtual {v10, v11, v12}, LB1/k;->b(J)V

    :cond_88
    :goto_88
    iget-boolean v10, v9, LB1/l;->c:Z

    if-eqz v10, :cond_9e

    iget-object v10, v9, LB1/l;->b:LB1/k;

    invoke-virtual {v10}, LB1/k;->a()Z

    move-result v10

    if-eqz v10, :cond_9e

    iget-object v10, v9, LB1/l;->a:LB1/k;

    iget-object v13, v9, LB1/l;->b:LB1/k;

    iput-object v13, v9, LB1/l;->a:LB1/k;

    iput-object v10, v9, LB1/l;->b:LB1/k;

    iput-boolean v15, v9, LB1/l;->c:Z

    :cond_9e
    iput-wide v11, v9, LB1/l;->d:J

    iget-object v10, v9, LB1/l;->a:LB1/k;

    invoke-virtual {v10}, LB1/k;->a()Z

    move-result v10

    if-eqz v10, :cond_aa

    move v10, v15

    goto :goto_ae

    :cond_aa
    iget v10, v9, LB1/l;->e:I

    const/4 v11, 0x1

    add-int/2addr v10, v11

    :goto_ae
    iput v10, v9, LB1/l;->e:I

    invoke-virtual {v8}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->c()V

    iput-wide v1, v0, LB1/w;->h:J

    :cond_b5
    sub-long/2addr v1, v3

    long-to-double v1, v1

    iget v8, v0, LB1/w;->k:F

    float-to-double v8, v8

    div-double/2addr v1, v8

    double-to-long v1, v1

    iget-boolean v8, v0, LB1/w;->d:Z

    if-eqz v8, :cond_d0

    iget-object v8, v0, LB1/w;->l:LZ0/y;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    invoke-static {v8, v9}, LZ0/F;->Q(J)J

    move-result-wide v8

    sub-long v8, v8, p5

    sub-long/2addr v1, v8

    :cond_d0
    iput-wide v1, v5, LB1/v;->a:J

    iget-wide v8, v0, LB1/w;->i:J

    cmp-long v8, v8, v6

    const-wide/16 v9, -0x7530

    const/4 v11, 0x3

    const/4 v12, 0x2

    if-eqz v8, :cond_e2

    iget-boolean v8, v0, LB1/w;->j:Z

    if-nez v8, :cond_e2

    :cond_e0
    move v1, v15

    goto :goto_120

    :cond_e2
    iget v8, v0, LB1/w;->e:I

    if-eqz v8, :cond_11e

    const/4 v13, 0x1

    if-eq v8, v13, :cond_11c

    if-eq v8, v12, :cond_118

    if-ne v8, v11, :cond_112

    iget-object v8, v0, LB1/w;->l:LZ0/y;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v13

    invoke-static {v13, v14}, LZ0/F;->Q(J)J

    move-result-wide v13

    iget-wide v11, v0, LB1/w;->g:J

    sub-long/2addr v13, v11

    iget-boolean v8, v0, LB1/w;->d:Z

    if-eqz v8, :cond_e0

    iget-object v8, v0, LB1/w;->a:LB1/q;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    cmp-long v1, v1, v9

    if-gez v1, :cond_e0

    const-wide/32 v1, 0x186a0

    cmp-long v1, v13, v1

    if-lez v1, :cond_e0

    goto :goto_11c

    :cond_112
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1}, Ljava/lang/IllegalStateException;-><init>()V

    throw v1

    :cond_118
    cmp-long v1, v3, p7

    if-ltz v1, :cond_e0

    :cond_11c
    :goto_11c
    const/4 v1, 0x1

    goto :goto_120

    :cond_11e
    iget-boolean v1, v0, LB1/w;->d:Z

    :goto_120
    if-eqz v1, :cond_123

    return v15

    :cond_123
    iget-boolean v1, v0, LB1/w;->d:Z

    if-eqz v1, :cond_12d

    iget-wide v11, v0, LB1/w;->f:J

    cmp-long v1, v3, v11

    if-nez v1, :cond_130

    :cond_12d
    const/4 v1, 0x5

    goto/16 :goto_269

    :cond_130
    iget-object v1, v0, LB1/w;->l:LZ0/y;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v11

    iget-object v1, v0, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iget-wide v13, v5, LB1/v;->a:J

    const-wide/16 v18, 0x3e8

    mul-long v13, v13, v18

    add-long/2addr v13, v11

    iget-wide v9, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    const-wide/16 v18, -0x1

    cmp-long v8, v9, v18

    if-eqz v8, :cond_19a

    iget-object v8, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->a:LB1/l;

    iget-object v8, v8, LB1/l;->a:LB1/k;

    invoke-virtual {v8}, LB1/k;->a()Z

    move-result v8

    if-eqz v8, :cond_19a

    iget-object v8, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->a:LB1/l;

    iget-object v9, v8, LB1/l;->a:LB1/k;

    invoke-virtual {v9}, LB1/k;->a()Z

    move-result v9

    if-eqz v9, :cond_16f

    iget-object v8, v8, LB1/l;->a:LB1/k;

    iget-wide v9, v8, LB1/k;->e:J

    const-wide/16 v16, 0x0

    cmp-long v18, v9, v16

    if-nez v18, :cond_16b

    const-wide/16 v2, 0x0

    goto :goto_170

    :cond_16b
    iget-wide v2, v8, LB1/k;->f:J

    div-long/2addr v2, v9

    goto :goto_170

    :cond_16f
    move-wide v2, v6

    :goto_170
    iget-wide v8, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->q:J

    iget-wide v6, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    move-wide/from16 v20, v11

    iget-wide v10, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    sub-long/2addr v6, v10

    mul-long/2addr v6, v2

    long-to-float v2, v6

    iget v3, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->i:F

    div-float/2addr v2, v3

    float-to-long v2, v2

    add-long/2addr v8, v2

    sub-long v2, v13, v8

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(J)J

    move-result-wide v2

    const-wide/32 v6, 0x1312d00

    cmp-long v2, v2, v6

    if-gtz v2, :cond_18f

    move-wide v13, v8

    goto :goto_19c

    :cond_18f
    const-wide/16 v2, 0x0

    iput-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    const-wide/16 v2, -0x1

    iput-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iput-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    goto :goto_19c

    :cond_19a
    move-wide/from16 v20, v11

    :goto_19c
    iget-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    iput-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    iput-wide v13, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->o:J

    iget-object v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->c:LB1/A;

    if-eqz v2, :cond_1d7

    iget-wide v3, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->k:J

    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v3, v3, v6

    if-nez v3, :cond_1b2

    goto :goto_1d7

    :cond_1b2
    iget-wide v2, v2, LB1/A;->a:J

    cmp-long v4, v2, v6

    if-nez v4, :cond_1b9

    goto :goto_1d7

    :cond_1b9
    iget-wide v6, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->k:J

    sub-long v8, v13, v2

    div-long/2addr v8, v6

    mul-long/2addr v8, v6

    add-long/2addr v8, v2

    cmp-long v2, v13, v8

    if-gtz v2, :cond_1c7

    sub-long v2, v8, v6

    goto :goto_1ca

    :cond_1c7
    add-long/2addr v6, v8

    move-wide v2, v8

    move-wide v8, v6

    :goto_1ca
    sub-long v6, v8, v13

    sub-long/2addr v13, v2

    cmp-long v4, v6, v13

    if-gez v4, :cond_1d2

    goto :goto_1d3

    :cond_1d2
    move-wide v8, v2

    :goto_1d3
    iget-wide v1, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->l:J

    sub-long v13, v8, v1

    :cond_1d7
    :goto_1d7
    iput-wide v13, v5, LB1/v;->b:J

    sub-long v13, v13, v20

    const-wide/16 v1, 0x3e8

    div-long/2addr v13, v1

    iput-wide v13, v5, LB1/v;->a:J

    iget-wide v1, v0, LB1/w;->i:J

    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v1, v1, v3

    if-eqz v1, :cond_1f1

    iget-boolean v1, v0, LB1/w;->j:Z

    if-nez v1, :cond_1f1

    const/4 v10, 0x1

    goto :goto_1f2

    :cond_1f1
    move v10, v15

    :goto_1f2
    iget-object v1, v0, LB1/w;->a:LB1/q;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/32 v2, -0x7a120

    cmp-long v2, v13, v2

    if-gez v2, :cond_240

    if-nez p9, :cond_240

    iget-object v2, v1, Landroidx/media3/exoplayer/e;->i:Lt1/c0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v3, v1, Landroidx/media3/exoplayer/e;->k:J

    sub-long v3, p3, v3

    invoke-interface {v2, v3, v4}, Lt1/c0;->h(J)I

    move-result v2

    if-nez v2, :cond_210

    goto :goto_240

    :cond_210
    if-eqz v10, :cond_221

    iget-object v3, v1, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget v4, v3, Landroidx/media3/exoplayer/f;->d:I

    add-int/2addr v4, v2

    iput v4, v3, Landroidx/media3/exoplayer/f;->d:I

    iget v2, v3, Landroidx/media3/exoplayer/f;->f:I

    iget v4, v1, LB1/q;->T1:I

    add-int/2addr v2, v4

    iput v2, v3, Landroidx/media3/exoplayer/f;->f:I

    goto :goto_22e

    :cond_221
    iget-object v3, v1, Lo1/u;->t1:Landroidx/media3/exoplayer/f;

    iget v4, v3, Landroidx/media3/exoplayer/f;->j:I

    const/4 v6, 0x1

    add-int/2addr v4, v6

    iput v4, v3, Landroidx/media3/exoplayer/f;->j:I

    iget v3, v1, LB1/q;->T1:I

    invoke-virtual {v1, v2, v3}, LB1/q;->L0(II)V

    :goto_22e
    invoke-virtual {v1}, Lo1/u;->O()Z

    move-result v2

    if-eqz v2, :cond_237

    invoke-virtual {v1}, Lo1/u;->Y()V

    :cond_237
    iget-object v1, v1, LB1/q;->I1:LB1/i;

    if-eqz v1, :cond_23e

    invoke-virtual {v1, v15}, LB1/i;->a(Z)V

    :cond_23e
    const/4 v1, 0x1

    goto :goto_241

    :cond_240
    :goto_240
    move v1, v15

    :goto_241
    if-eqz v1, :cond_245

    const/4 v1, 0x4

    return v1

    :cond_245
    iget-object v1, v0, LB1/w;->a:LB1/q;

    iget-wide v2, v5, LB1/v;->a:J

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v6, -0x7530

    cmp-long v1, v2, v6

    if-gez v1, :cond_255

    if-nez p9, :cond_255

    const/4 v15, 0x1

    :cond_255
    if-eqz v15, :cond_25d

    if-eqz v10, :cond_25b

    const/4 v11, 0x3

    goto :goto_25c

    :cond_25b
    const/4 v11, 0x2

    :goto_25c
    return v11

    :cond_25d
    iget-wide v1, v5, LB1/v;->a:J

    const-wide/32 v3, 0xc350

    cmp-long v1, v1, v3

    if-lez v1, :cond_268

    const/4 v1, 0x5

    return v1

    :cond_268
    const/4 v1, 0x1

    :goto_269
    return v1
.end method

.method public final b(Z)V
    .registers 6

    iput-boolean p1, p0, LB1/w;->j:Z

    iget-wide v0, p0, LB1/w;->c:J

    const-wide/16 v2, 0x0

    cmp-long p1, v0, v2

    if-lez p1, :cond_15

    iget-object p1, p0, LB1/w;->l:LZ0/y;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    add-long/2addr v2, v0

    goto :goto_1a

    :cond_15
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    :goto_1a
    iput-wide v2, p0, LB1/w;->i:J

    return-void
.end method

.method public final c(I)V
    .registers 3

    iget v0, p0, LB1/w;->e:I

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    iput p1, p0, LB1/w;->e:I

    return-void
.end method

.method public final d()V
    .registers 6

    const/4 v0, 0x1

    iput-boolean v0, p0, LB1/w;->d:Z

    iget-object v1, p0, LB1/w;->l:LZ0/y;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-static {v1, v2}, LZ0/F;->Q(J)J

    move-result-wide v1

    iput-wide v1, p0, LB1/w;->g:J

    iget-object v1, p0, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iput-boolean v0, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d:Z

    const-wide/16 v2, 0x0

    iput-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->m:J

    const-wide/16 v2, -0x1

    iput-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->p:J

    iput-wide v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->n:J

    const/4 v0, 0x0

    iget-object v2, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->b:LB1/z;

    if-eqz v2, :cond_43

    iget-object v3, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->c:LB1/A;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v3, LB1/A;->b:Landroid/os/Handler;

    const/4 v4, 0x2

    invoke-virtual {v3, v4}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v3, 0x0

    invoke-static {v3}, LZ0/F;->n(Landroid/os/Handler$Callback;)Landroid/os/Handler;

    move-result-object v3

    iget-object v4, v2, LB1/z;->a:Landroid/hardware/display/DisplayManager;

    invoke-virtual {v4, v2, v3}, Landroid/hardware/display/DisplayManager;->registerDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;Landroid/os/Handler;)V

    invoke-virtual {v4, v0}, Landroid/hardware/display/DisplayManager;->getDisplay(I)Landroid/view/Display;

    move-result-object v3

    iget-object v2, v2, LB1/z;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    invoke-static {v2, v3}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->a(Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;Landroid/view/Display;)V

    :cond_43
    invoke-virtual {v1, v0}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d(Z)V

    return-void
.end method

.method public final e()V
    .registers 4

    const/4 v0, 0x0

    iput-boolean v0, p0, LB1/w;->d:Z

    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v1, p0, LB1/w;->i:J

    iget-object v1, p0, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iput-boolean v0, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->d:Z

    iget-object v0, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->b:LB1/z;

    if-eqz v0, :cond_22

    iget-object v2, v0, LB1/z;->a:Landroid/hardware/display/DisplayManager;

    invoke-virtual {v2, v0}, Landroid/hardware/display/DisplayManager;->unregisterDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;)V

    iget-object v0, v1, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->c:LB1/A;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, LB1/A;->b:Landroid/os/Handler;

    const/4 v2, 0x3

    invoke-virtual {v0, v2}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    :cond_22
    invoke-virtual {v1}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->b()V

    return-void
.end method

.method public final f(F)V
    .registers 6

    iget-object v0, p0, LB1/w;->b:Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;

    iput p1, v0, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->f:F

    iget-object p1, v0, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->a:LB1/l;

    iget-object v1, p1, LB1/l;->a:LB1/k;

    invoke-virtual {v1}, LB1/k;->c()V

    iget-object v1, p1, LB1/l;->b:LB1/k;

    invoke-virtual {v1}, LB1/k;->c()V

    const/4 v1, 0x0

    iput-boolean v1, p1, LB1/l;->c:Z

    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v2, p1, LB1/l;->d:J

    iput v1, p1, LB1/l;->e:I

    invoke-virtual {v0}, Landroidx/media3/exoplayer/video/VideoFrameReleaseHelper;->c()V

    return-void
.end method
