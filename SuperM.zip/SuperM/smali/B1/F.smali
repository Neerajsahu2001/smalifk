.class public final LB1/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LW0/d0;


# direct methods
.method public constructor <init>(LB1/e;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB1/f;->a:LW0/d0;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    :try_start_0
    const-string v0, "androidx.media3.effect.PreviewingSingleInputVideoGraph$Factory"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-class v1, LW0/d0;

    filled-new-array {v1}, [Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    iget-object v1, p0, LB1/f;->a:LW0/d0;

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LB1/f;

    invoke-virtual {v0}, LB1/f;->a()V
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1f} :catch_20

    return-void

    :catch_20
    move-exception v0

    sget v1, LW0/c0;->a:I

    instance-of v1, v0, LW0/c0;

    if-eqz v1, :cond_2a

    check-cast v0, LW0/c0;

    goto :goto_30

    :cond_2a
    new-instance v1, LW0/c0;

    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    move-object v0, v1

    :goto_30
    throw v0
.end method
