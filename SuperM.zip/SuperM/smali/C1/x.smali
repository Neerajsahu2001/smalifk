.class public final Lc1/x;
.super Lc1/w;
.source "SourceFile"


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    const-string v0, "Invalid content type: "

    invoke-static {v0, p1}, LA8/v;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x7d3

    invoke-direct {p0, p1, v0}, Lc1/w;-><init>(Ljava/lang/String;I)V

    return-void
.end method
