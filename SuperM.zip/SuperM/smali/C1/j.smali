.class public final Lc1/j;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/net/Uri;

.field public b:J

.field public c:I

.field public d:[B

.field public e:Ljava/util/Map;

.field public f:J

.field public g:J

.field public h:Ljava/lang/String;

.field public i:I

.field public j:Ljava/lang/Object;


# virtual methods
.method public final a()Lc1/k;
    .registers 18

    move-object/from16 v0, p0

    iget-object v1, v0, Lc1/j;->a:Landroid/net/Uri;

    const-string v2, "The uri must be set."

    invoke-static {v1, v2}, Lm7/u;->h(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lc1/k;

    iget-object v4, v0, Lc1/j;->a:Landroid/net/Uri;

    iget-wide v5, v0, Lc1/j;->b:J

    iget v7, v0, Lc1/j;->c:I

    iget-object v8, v0, Lc1/j;->d:[B

    iget-object v9, v0, Lc1/j;->e:Ljava/util/Map;

    iget-wide v10, v0, Lc1/j;->f:J

    iget-wide v12, v0, Lc1/j;->g:J

    iget-object v14, v0, Lc1/j;->h:Ljava/lang/String;

    iget v15, v0, Lc1/j;->i:I

    iget-object v2, v0, Lc1/j;->j:Ljava/lang/Object;

    move-object v3, v1

    move-object/from16 v16, v2

    invoke-direct/range {v3 .. v16}, Lc1/k;-><init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;)V

    return-object v1
.end method

.method public final b(I)V
    .registers 2

    iput p1, p0, Lc1/j;->i:I

    return-void
.end method

.method public final c()V
    .registers 2

    sget-object v0, Lj8/v0;->g:Lj8/v0;

    iput-object v0, p0, Lc1/j;->e:Ljava/util/Map;

    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lc1/j;->h:Ljava/lang/String;

    return-void
.end method
