.class public final Lc1/t;
.super Lc1/b;
.source "SourceFile"


# instance fields
.field public e:Ljava/io/RandomAccessFile;

.field public f:Landroid/net/Uri;

.field public g:J

.field public h:Z


# virtual methods
.method public final c(Lc1/k;)J
    .registers 10

    iget-object v0, p1, Lc1/k;->a:Landroid/net/Uri;

    iget-wide v1, p1, Lc1/k;->f:J

    iput-object v0, p0, Lc1/t;->f:Landroid/net/Uri;

    invoke-virtual {p0}, Lc1/b;->p()V

    const/16 v3, 0x7d0

    const/16 v4, 0x7d6

    :try_start_d
    new-instance v5, Ljava/io/RandomAccessFile;

    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v7, "r"

    invoke-direct {v5, v6, v7}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1b
    .catch Ljava/io/FileNotFoundException; {:try_start_d .. :try_end_1b} :catch_56
    .catch Ljava/lang/SecurityException; {:try_start_d .. :try_end_1b} :catch_54
    .catch Ljava/lang/RuntimeException; {:try_start_d .. :try_end_1b} :catch_52

    iput-object v5, p0, Lc1/t;->e:Ljava/io/RandomAccessFile;

    :try_start_1d
    invoke-virtual {v5, v1, v2}, Ljava/io/RandomAccessFile;->seek(J)V

    iget-wide v4, p1, Lc1/k;->g:J

    const-wide/16 v6, -0x1

    cmp-long v0, v4, v6

    if-nez v0, :cond_32

    iget-object v0, p0, Lc1/t;->e:Ljava/io/RandomAccessFile;

    invoke-virtual {v0}, Ljava/io/RandomAccessFile;->length()J

    move-result-wide v4

    sub-long/2addr v4, v1

    goto :goto_32

    :catch_30
    move-exception p1

    goto :goto_4c

    :cond_32
    :goto_32
    iput-wide v4, p0, Lc1/t;->g:J
    :try_end_34
    .catch Ljava/io/IOException; {:try_start_1d .. :try_end_34} :catch_30

    const-wide/16 v0, 0x0

    cmp-long v0, v4, v0

    if-ltz v0, :cond_43

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc1/t;->h:Z

    invoke-virtual {p0, p1}, Lc1/b;->q(Lc1/k;)V

    iget-wide v0, p0, Lc1/t;->g:J

    return-wide v0

    :cond_43
    new-instance p1, Lc1/s;

    const/4 v0, 0x0

    const/16 v1, 0x7d8

    invoke-direct {p1, v1, v0, v0}, Lc1/h;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :goto_4c
    new-instance v0, Lc1/s;

    invoke-direct {v0, v3, p1}, Lc1/h;-><init>(ILjava/lang/Throwable;)V

    throw v0

    :catch_52
    move-exception p1

    goto :goto_58

    :catch_54
    move-exception p1

    goto :goto_5e

    :catch_56
    move-exception p1

    goto :goto_64

    :goto_58
    new-instance v0, Lc1/s;

    invoke-direct {v0, v3, p1}, Lc1/h;-><init>(ILjava/lang/Throwable;)V

    throw v0

    :goto_5e
    new-instance v0, Lc1/s;

    invoke-direct {v0, v4, p1}, Lc1/h;-><init>(ILjava/lang/Throwable;)V

    throw v0

    :goto_64
    invoke-virtual {v0}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_91

    invoke-virtual {v0}, Landroid/net/Uri;->getFragment()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_91

    new-instance v0, Lc1/s;

    sget v1, LZ0/F;->a:I

    const/16 v2, 0x15

    if-lt v1, v2, :cond_8b

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    invoke-static {v1}, Lc1/r;->a(Ljava/lang/Throwable;)Z

    move-result v1

    if-eqz v1, :cond_8b

    goto :goto_8d

    :cond_8b
    const/16 v4, 0x7d5

    :goto_8d
    invoke-direct {v0, v4, p1}, Lc1/h;-><init>(ILjava/lang/Throwable;)V

    throw v0

    :cond_91
    new-instance v1, Lc1/s;

    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Landroid/net/Uri;->getFragment()Ljava/lang/String;

    move-result-object v0

    const-string v4, "uri has query and/or fragment, which are not supported. Did you call Uri.parse() on a string containing \'?\' or \'#\'? Use Uri.fromFile(new File(path)) to avoid this. path="

    const-string v5, ",query="

    const-string v6, ",fragment="

    invoke-static {v4, v2, v5, v3, v6}, Ldb/s;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x3ec

    invoke-direct {v1, v2, v0, p1}, Lc1/h;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method

.method public final close()V
    .registers 6

    const/4 v0, 0x0

    iput-object v0, p0, Lc1/t;->f:Landroid/net/Uri;

    const/4 v1, 0x0

    :try_start_4
    iget-object v2, p0, Lc1/t;->e:Ljava/io/RandomAccessFile;

    if-eqz v2, :cond_10

    invoke-virtual {v2}, Ljava/io/RandomAccessFile;->close()V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_b} :catch_e
    .catchall {:try_start_4 .. :try_end_b} :catchall_c

    goto :goto_10

    :catchall_c
    move-exception v2

    goto :goto_24

    :catch_e
    move-exception v2

    goto :goto_1c

    :cond_10
    :goto_10
    iput-object v0, p0, Lc1/t;->e:Ljava/io/RandomAccessFile;

    iget-boolean v0, p0, Lc1/t;->h:Z

    if-eqz v0, :cond_1b

    iput-boolean v1, p0, Lc1/t;->h:Z

    invoke-virtual {p0}, Lc1/b;->o()V

    :cond_1b
    return-void

    :goto_1c
    :try_start_1c
    new-instance v3, Lc1/s;

    const/16 v4, 0x7d0

    invoke-direct {v3, v4, v2}, Lc1/h;-><init>(ILjava/lang/Throwable;)V

    throw v3
    :try_end_24
    .catchall {:try_start_1c .. :try_end_24} :catchall_c

    :goto_24
    iput-object v0, p0, Lc1/t;->e:Ljava/io/RandomAccessFile;

    iget-boolean v0, p0, Lc1/t;->h:Z

    if-eqz v0, :cond_2f

    iput-boolean v1, p0, Lc1/t;->h:Z

    invoke-virtual {p0}, Lc1/b;->o()V

    :cond_2f
    throw v2
.end method

.method public final k()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc1/t;->f:Landroid/net/Uri;

    return-object v0
.end method

.method public final l([BII)I
    .registers 9

    if-nez p3, :cond_4

    const/4 p1, 0x0

    return p1

    :cond_4
    iget-wide v0, p0, Lc1/t;->g:J

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-nez v2, :cond_e

    const/4 p1, -0x1

    return p1

    :cond_e
    :try_start_e
    iget-object v2, p0, Lc1/t;->e:Ljava/io/RandomAccessFile;

    sget v3, LZ0/F;->a:I

    int-to-long v3, p3

    invoke-static {v0, v1, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int p3, v0

    invoke-virtual {v2, p1, p2, p3}, Ljava/io/RandomAccessFile;->read([BII)I

    move-result p1
    :try_end_1c
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_1c} :catch_28

    if-lez p1, :cond_27

    iget-wide p2, p0, Lc1/t;->g:J

    int-to-long v0, p1

    sub-long/2addr p2, v0

    iput-wide p2, p0, Lc1/t;->g:J

    invoke-virtual {p0, p1}, Lc1/b;->n(I)V

    :cond_27
    return p1

    :catch_28
    move-exception p1

    new-instance p2, Lc1/s;

    const/16 p3, 0x7d0

    invoke-direct {p2, p3, p1}, Lc1/h;-><init>(ILjava/lang/Throwable;)V

    throw p2
.end method
