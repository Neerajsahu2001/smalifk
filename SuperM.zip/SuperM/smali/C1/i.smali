.class public final Lc1/i;
.super Ljava/io/InputStream;
.source "SourceFile"


# instance fields
.field public final a:Lc1/f;

.field public final b:Lc1/k;

.field public final c:[B

.field public d:Z

.field public e:Z


# direct methods
.method public constructor <init>(Lc1/f;Lc1/k;)V
    .registers 4

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc1/i;->d:Z

    iput-boolean v0, p0, Lc1/i;->e:Z

    iput-object p1, p0, Lc1/i;->a:Lc1/f;

    iput-object p2, p0, Lc1/i;->b:Lc1/k;

    const/4 p1, 0x1

    new-array p1, p1, [B

    iput-object p1, p0, Lc1/i;->c:[B

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    iget-boolean v0, p0, Lc1/i;->d:Z

    if-nez v0, :cond_e

    iget-object v0, p0, Lc1/i;->a:Lc1/f;

    iget-object v1, p0, Lc1/i;->b:Lc1/k;

    invoke-interface {v0, v1}, Lc1/f;->c(Lc1/k;)J

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc1/i;->d:Z

    :cond_e
    return-void
.end method

.method public final close()V
    .registers 2

    iget-boolean v0, p0, Lc1/i;->e:Z

    if-nez v0, :cond_c

    iget-object v0, p0, Lc1/i;->a:Lc1/f;

    invoke-interface {v0}, Lc1/f;->close()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc1/i;->e:Z

    :cond_c
    return-void
.end method

.method public final read()I
    .registers 5

    iget-object v0, p0, Lc1/i;->c:[B

    array-length v1, v0

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v2, v1}, Lc1/i;->read([BII)I

    move-result v1

    const/4 v3, -0x1

    if-ne v1, v3, :cond_c

    goto :goto_10

    :cond_c
    aget-byte v0, v0, v2

    and-int/lit16 v3, v0, 0xff

    :goto_10
    return v3
.end method

.method public final read([B)I
    .registers 4

    array-length v0, p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0}, Lc1/i;->read([BII)I

    move-result p1

    return p1
.end method

.method public final read([BII)I
    .registers 5

    iget-boolean v0, p0, Lc1/i;->e:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lm7/u;->e(Z)V

    invoke-virtual {p0}, Lc1/i;->a()V

    iget-object v0, p0, Lc1/i;->a:Lc1/f;

    invoke-interface {v0, p1, p2, p3}, LW0/k;->l([BII)I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_14

    return p2

    :cond_14
    return p1
.end method
