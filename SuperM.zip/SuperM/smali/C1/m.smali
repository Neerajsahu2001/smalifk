.class public final Lc1/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc1/v;


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LW2/c;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, LW2/c;-><init>(I)V

    iput-object v0, p0, Lc1/m;->c:Ljava/lang/Object;

    const/16 v0, 0x1f40

    iput v0, p0, Lc1/m;->a:I

    iput v0, p0, Lc1/m;->b:I

    return-void
.end method

.method public constructor <init>(Landroid/graphics/Bitmap;Lue/O;II)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p1, :cond_9

    move v2, v1

    goto :goto_a

    :cond_9
    move v2, v0

    :goto_a
    if-eqz p2, :cond_d

    move v0, v1

    :cond_d
    if-eq v2, v0, :cond_22

    iput-object p1, p0, Lc1/m;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc1/m;->d:Ljava/lang/Object;

    const-string p1, "loadedFrom == null"

    if-eqz p3, :cond_1c

    iput p3, p0, Lc1/m;->a:I

    iput p4, p0, Lc1/m;->b:I

    return-void

    :cond_1c
    new-instance p2, Ljava/lang/NullPointerException;

    invoke-direct {p2, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_22
    new-instance p1, Ljava/lang/AssertionError;

    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    throw p1
.end method

.method public constructor <init>(Lue/O;I)V
    .registers 5

    sget-object v0, Ldb/M;->a:Ljava/lang/StringBuilder;

    if-eqz p1, :cond_c

    check-cast p1, Lue/O;

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, v1, p1, p2, v0}, Lc1/m;-><init>(Landroid/graphics/Bitmap;Lue/O;II)V

    return-void

    :cond_c
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "source == null"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public g()Lc1/f;
    .registers 6

    new-instance v0, Lc1/q;

    iget-object v1, p0, Lc1/m;->d:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget v2, p0, Lc1/m;->a:I

    iget v3, p0, Lc1/m;->b:I

    iget-object v4, p0, Lc1/m;->c:Ljava/lang/Object;

    check-cast v4, LW2/c;

    invoke-direct {v0, v1, v2, v3, v4}, Lc1/q;-><init>(Ljava/lang/String;IILW2/c;)V

    return-object v0
.end method
