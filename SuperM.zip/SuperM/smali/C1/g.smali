.class public final synthetic Lc1/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li8/l;


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 3

    sget-object v0, Landroidx/media3/datasource/DataSourceBitmapLoader;->a:Li8/l;

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    instance-of v1, v0, Ln8/s;

    if-eqz v1, :cond_d

    check-cast v0, Ln8/s;

    goto :goto_20

    :cond_d
    instance-of v1, v0, Ljava/util/concurrent/ScheduledExecutorService;

    if-eqz v1, :cond_1a

    new-instance v1, Ln8/w;

    check-cast v0, Ljava/util/concurrent/ScheduledExecutorService;

    invoke-direct {v1, v0}, Ln8/w;-><init>(Ljava/util/concurrent/ScheduledExecutorService;)V

    :goto_18
    move-object v0, v1

    goto :goto_20

    :cond_1a
    new-instance v1, Ln8/t;

    invoke-direct {v1, v0}, Ln8/t;-><init>(Ljava/util/concurrent/ExecutorService;)V

    goto :goto_18

    :goto_20
    return-object v0
.end method
