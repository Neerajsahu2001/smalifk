.class public final Lc1/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc1/f;


# instance fields
.field public final a:Lc1/f;

.field public b:J

.field public c:Landroid/net/Uri;


# direct methods
.method public constructor <init>(Lc1/f;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lc1/C;->a:Lc1/f;

    sget-object p1, Landroid/net/Uri;->EMPTY:Landroid/net/Uri;

    iput-object p1, p0, Lc1/C;->c:Landroid/net/Uri;

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final c(Lc1/k;)J
    .registers 5

    iget-object v0, p1, Lc1/k;->a:Landroid/net/Uri;

    iput-object v0, p0, Lc1/C;->c:Landroid/net/Uri;

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    iget-object v0, p0, Lc1/C;->a:Lc1/f;

    invoke-interface {v0, p1}, Lc1/f;->c(Lc1/k;)J

    move-result-wide v1

    invoke-interface {v0}, Lc1/f;->k()Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lc1/C;->c:Landroid/net/Uri;

    invoke-interface {v0}, Lc1/f;->g()Ljava/util/Map;

    return-wide v1
.end method

.method public final close()V
    .registers 2

    iget-object v0, p0, Lc1/C;->a:Lc1/f;

    invoke-interface {v0}, Lc1/f;->close()V

    return-void
.end method

.method public final g()Ljava/util/Map;
    .registers 2

    iget-object v0, p0, Lc1/C;->a:Lc1/f;

    invoke-interface {v0}, Lc1/f;->g()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public final j(Lc1/E;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc1/C;->a:Lc1/f;

    invoke-interface {v0, p1}, Lc1/f;->j(Lc1/E;)V

    return-void
.end method

.method public final k()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc1/C;->a:Lc1/f;

    invoke-interface {v0}, Lc1/f;->k()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final l([BII)I
    .registers 6

    iget-object v0, p0, Lc1/C;->a:Lc1/f;

    invoke-interface {v0, p1, p2, p3}, LW0/k;->l([BII)I

    move-result p1

    const/4 p2, -0x1

    if-eq p1, p2, :cond_f

    iget-wide p2, p0, Lc1/C;->b:J

    int-to-long v0, p1

    add-long/2addr p2, v0

    iput-wide p2, p0, Lc1/C;->b:J

    :cond_f
    return p1
.end method
