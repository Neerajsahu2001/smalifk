.class public abstract Lc1/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc1/f;


# instance fields
.field public final a:Z

.field public final b:Ljava/util/ArrayList;

.field public c:I

.field public d:Lc1/k;


# direct methods
.method public constructor <init>(Z)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lc1/b;->a:Z

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Lc1/b;->b:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final j(Lc1/E;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc1/b;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_14

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget p1, p0, Lc1/b;->c:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Lc1/b;->c:I

    :cond_14
    return-void
.end method

.method public final n(I)V
    .registers 9

    iget-object v0, p0, Lc1/b;->d:Lc1/k;

    sget v1, LZ0/F;->a:I

    const/4 v1, 0x0

    :goto_5
    iget v2, p0, Lc1/b;->c:I

    if-ge v1, v2, :cond_32

    iget-object v2, p0, Lc1/b;->b:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc1/E;

    iget-boolean v3, p0, Lc1/b;->a:Z

    check-cast v2, Ly1/r;

    monitor-enter v2

    :try_start_16
    sget-object v4, Ly1/r;->n:Lj8/q0;

    if-eqz v3, :cond_2c

    const/16 v3, 0x8

    invoke-virtual {v0, v3}, Lc1/k;->c(I)Z

    move-result v3

    if-nez v3, :cond_2c

    iget-wide v3, v2, Ly1/r;->h:J

    int-to-long v5, p1

    add-long/2addr v3, v5

    iput-wide v3, v2, Ly1/r;->h:J
    :try_end_28
    .catchall {:try_start_16 .. :try_end_28} :catchall_2a

    monitor-exit v2

    goto :goto_2d

    :catchall_2a
    move-exception p1

    goto :goto_30

    :cond_2c
    monitor-exit v2

    :goto_2d
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :goto_30
    monitor-exit v2

    throw p1

    :cond_32
    return-void
.end method

.method public final o()V
    .registers 15

    const/4 v0, 0x1

    iget-object v1, p0, Lc1/b;->d:Lc1/k;

    sget v2, LZ0/F;->a:I

    const/4 v2, 0x0

    move v3, v2

    :goto_7
    iget v4, p0, Lc1/b;->c:I

    if-ge v3, v4, :cond_94

    iget-object v4, p0, Lc1/b;->b:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc1/E;

    iget-boolean v5, p0, Lc1/b;->a:Z

    check-cast v4, Ly1/r;

    monitor-enter v4

    :try_start_18
    sget-object v6, Ly1/r;->n:Lj8/q0;

    if-eqz v5, :cond_8e

    const/16 v5, 0x8

    invoke-virtual {v1, v5}, Lc1/k;->c(I)Z

    move-result v5

    if-nez v5, :cond_8e

    iget v5, v4, Ly1/r;->f:I

    if-lez v5, :cond_2a

    move v5, v0

    goto :goto_2b

    :cond_2a
    move v5, v2

    :goto_2b
    invoke-static {v5}, Lm7/u;->e(Z)V

    iget-object v5, v4, Ly1/r;->c:LZ0/y;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v12

    iget-wide v5, v4, Ly1/r;->g:J

    sub-long v5, v12, v5

    long-to-int v7, v5

    iget-wide v5, v4, Ly1/r;->i:J

    int-to-long v8, v7

    add-long/2addr v5, v8

    iput-wide v5, v4, Ly1/r;->i:J

    iget-wide v5, v4, Ly1/r;->j:J

    iget-wide v8, v4, Ly1/r;->h:J

    add-long/2addr v5, v8

    iput-wide v5, v4, Ly1/r;->j:J

    if-lez v7, :cond_87

    long-to-float v5, v8

    const/high16 v6, 0x45fa0000    # 8000.0f

    mul-float/2addr v5, v6

    int-to-float v6, v7

    div-float/2addr v5, v6

    iget-object v6, v4, Ly1/r;->e:Ly1/F;

    long-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v8

    double-to-int v8, v8

    invoke-virtual {v6, v5, v8}, Ly1/F;->a(FI)V

    iget-wide v5, v4, Ly1/r;->i:J

    const-wide/16 v8, 0x7d0

    cmp-long v5, v5, v8

    if-gez v5, :cond_70

    iget-wide v5, v4, Ly1/r;->j:J

    const-wide/32 v8, 0x80000

    cmp-long v5, v5, v8

    if-ltz v5, :cond_79

    goto :goto_70

    :catchall_6e
    move-exception v0

    goto :goto_92

    :cond_70
    :goto_70
    iget-object v5, v4, Ly1/r;->e:Ly1/F;

    invoke-virtual {v5}, Ly1/F;->b()F

    move-result v5

    float-to-long v5, v5

    iput-wide v5, v4, Ly1/r;->k:J

    :cond_79
    iget-wide v8, v4, Ly1/r;->h:J

    iget-wide v10, v4, Ly1/r;->k:J

    move-object v6, v4

    invoke-virtual/range {v6 .. v11}, Ly1/r;->c(IJJ)V

    iput-wide v12, v4, Ly1/r;->g:J

    const-wide/16 v5, 0x0

    iput-wide v5, v4, Ly1/r;->h:J

    :cond_87
    iget v5, v4, Ly1/r;->f:I

    sub-int/2addr v5, v0

    iput v5, v4, Ly1/r;->f:I
    :try_end_8c
    .catchall {:try_start_18 .. :try_end_8c} :catchall_6e

    monitor-exit v4

    goto :goto_8f

    :cond_8e
    monitor-exit v4

    :goto_8f
    add-int/2addr v3, v0

    goto/16 :goto_7

    :goto_92
    monitor-exit v4

    throw v0

    :cond_94
    const/4 v0, 0x0

    iput-object v0, p0, Lc1/b;->d:Lc1/k;

    return-void
.end method

.method public final p()V
    .registers 3

    const/4 v0, 0x0

    :goto_1
    iget v1, p0, Lc1/b;->c:I

    if-ge v0, v1, :cond_13

    iget-object v1, p0, Lc1/b;->b:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc1/E;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_13
    return-void
.end method

.method public final q(Lc1/k;)V
    .registers 6

    iput-object p1, p0, Lc1/b;->d:Lc1/k;

    const/4 v0, 0x0

    :goto_3
    iget v1, p0, Lc1/b;->c:I

    if-ge v0, v1, :cond_40

    iget-object v1, p0, Lc1/b;->b:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc1/E;

    iget-boolean v2, p0, Lc1/b;->a:Z

    check-cast v1, Ly1/r;

    monitor-enter v1

    :try_start_14
    sget-object v3, Ly1/r;->n:Lj8/q0;

    if-eqz v2, :cond_3a

    const/16 v2, 0x8

    invoke-virtual {p1, v2}, Lc1/k;->c(I)Z

    move-result v2

    if-nez v2, :cond_3a

    iget v2, v1, Ly1/r;->f:I

    if-nez v2, :cond_32

    iget-object v2, v1, Ly1/r;->c:LZ0/y;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iput-wide v2, v1, Ly1/r;->g:J

    goto :goto_32

    :catchall_30
    move-exception p1

    goto :goto_3e

    :cond_32
    :goto_32
    iget v2, v1, Ly1/r;->f:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v1, Ly1/r;->f:I
    :try_end_38
    .catchall {:try_start_14 .. :try_end_38} :catchall_30

    monitor-exit v1

    goto :goto_3b

    :cond_3a
    monitor-exit v1

    :goto_3b
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :goto_3e
    monitor-exit v1

    throw p1

    :cond_40
    return-void
.end method
