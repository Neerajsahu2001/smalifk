.class public final Lc1/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/net/Uri;

.field public final b:J

.field public final c:I

.field public final d:[B

.field public final e:Ljava/util/Map;

.field public final f:J

.field public final g:J

.field public final h:Ljava/lang/String;

.field public final i:I

.field public final j:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "media3.datasource"

    invoke-static {v0}, LW0/F;->a(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;)V
    .registers 27

    move-object v0, p0

    move-wide v1, p2

    move-object/from16 v3, p5

    move-wide/from16 v4, p7

    move-wide/from16 v6, p9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    add-long v8, v1, v4

    const-wide/16 v10, 0x0

    cmp-long v8, v8, v10

    const/4 v9, 0x0

    const/4 v12, 0x1

    if-ltz v8, :cond_17

    move v8, v12

    goto :goto_18

    :cond_17
    move v8, v9

    :goto_18
    invoke-static {v8}, Lm7/u;->a(Z)V

    cmp-long v8, v4, v10

    if-ltz v8, :cond_21

    move v8, v12

    goto :goto_22

    :cond_21
    move v8, v9

    :goto_22
    invoke-static {v8}, Lm7/u;->a(Z)V

    cmp-long v8, v6, v10

    if-gtz v8, :cond_2f

    const-wide/16 v10, -0x1

    cmp-long v8, v6, v10

    if-nez v8, :cond_30

    :cond_2f
    move v9, v12

    :cond_30
    invoke-static {v9}, Lm7/u;->a(Z)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v8, p1

    iput-object v8, v0, Lc1/k;->a:Landroid/net/Uri;

    iput-wide v1, v0, Lc1/k;->b:J

    move/from16 v1, p4

    iput v1, v0, Lc1/k;->c:I

    if-eqz v3, :cond_45

    array-length v1, v3

    if-eqz v1, :cond_45

    goto :goto_47

    :cond_45
    const/4 v1, 0x0

    move-object v3, v1

    :goto_47
    iput-object v3, v0, Lc1/k;->d:[B

    new-instance v1, Ljava/util/HashMap;

    move-object/from16 v2, p6

    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v1

    iput-object v1, v0, Lc1/k;->e:Ljava/util/Map;

    iput-wide v4, v0, Lc1/k;->f:J

    iput-wide v6, v0, Lc1/k;->g:J

    move-object/from16 v1, p11

    iput-object v1, v0, Lc1/k;->h:Ljava/lang/String;

    move/from16 v1, p12

    iput v1, v0, Lc1/k;->i:I

    move-object/from16 v1, p13

    iput-object v1, v0, Lc1/k;->j:Ljava/lang/Object;

    return-void
.end method

.method public static b(I)Ljava/lang/String;
    .registers 2

    const/4 v0, 0x1

    if-eq p0, v0, :cond_15

    const/4 v0, 0x2

    if-eq p0, v0, :cond_12

    const/4 v0, 0x3

    if-ne p0, v0, :cond_c

    const-string p0, "HEAD"

    return-object p0

    :cond_c
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    throw p0

    :cond_12
    const-string p0, "POST"

    return-object p0

    :cond_15
    const-string p0, "GET"

    return-object p0
.end method


# virtual methods
.method public final a()Lc1/j;
    .registers 4

    new-instance v0, Lc1/j;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iget-object v1, p0, Lc1/k;->a:Landroid/net/Uri;

    iput-object v1, v0, Lc1/j;->a:Landroid/net/Uri;

    iget-wide v1, p0, Lc1/k;->b:J

    iput-wide v1, v0, Lc1/j;->b:J

    iget v1, p0, Lc1/k;->c:I

    iput v1, v0, Lc1/j;->c:I

    iget-object v1, p0, Lc1/k;->d:[B

    iput-object v1, v0, Lc1/j;->d:[B

    iget-object v1, p0, Lc1/k;->e:Ljava/util/Map;

    iput-object v1, v0, Lc1/j;->e:Ljava/util/Map;

    iget-wide v1, p0, Lc1/k;->f:J

    iput-wide v1, v0, Lc1/j;->f:J

    iget-wide v1, p0, Lc1/k;->g:J

    iput-wide v1, v0, Lc1/j;->g:J

    iget-object v1, p0, Lc1/k;->h:Ljava/lang/String;

    iput-object v1, v0, Lc1/j;->h:Ljava/lang/String;

    iget v1, p0, Lc1/k;->i:I

    iput v1, v0, Lc1/j;->i:I

    iget-object v1, p0, Lc1/k;->j:Ljava/lang/Object;

    iput-object v1, v0, Lc1/j;->j:Ljava/lang/Object;

    return-object v0
.end method

.method public final c(I)Z
    .registers 3

    iget v0, p0, Lc1/k;->i:I

    and-int/2addr v0, p1

    if-ne v0, p1, :cond_7

    const/4 p1, 0x1

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    return p1
.end method

.method public final d(J)Lc1/k;
    .registers 8

    iget-wide v0, p0, Lc1/k;->g:J

    const-wide/16 v2, -0x1

    cmp-long v4, v0, v2

    if-nez v4, :cond_9

    goto :goto_b

    :cond_9
    sub-long v2, v0, p1

    :goto_b
    invoke-virtual {p0, p1, p2, v2, v3}, Lc1/k;->e(JJ)Lc1/k;

    move-result-object p1

    return-object p1
.end method

.method public final e(JJ)Lc1/k;
    .registers 22

    move-object/from16 v0, p0

    const-wide/16 v1, 0x0

    cmp-long v1, p1, v1

    if-nez v1, :cond_f

    iget-wide v1, v0, Lc1/k;->g:J

    cmp-long v1, v1, p3

    if-nez v1, :cond_f

    return-object v0

    :cond_f
    new-instance v1, Lc1/k;

    iget-wide v2, v0, Lc1/k;->f:J

    add-long v10, v2, p1

    iget v15, v0, Lc1/k;->i:I

    iget-object v2, v0, Lc1/k;->j:Ljava/lang/Object;

    iget-object v4, v0, Lc1/k;->a:Landroid/net/Uri;

    iget-wide v5, v0, Lc1/k;->b:J

    iget v7, v0, Lc1/k;->c:I

    iget-object v8, v0, Lc1/k;->d:[B

    iget-object v9, v0, Lc1/k;->e:Ljava/util/Map;

    iget-object v14, v0, Lc1/k;->h:Ljava/lang/String;

    move-object v3, v1

    move-wide/from16 v12, p3

    move-object/from16 v16, v2

    invoke-direct/range {v3 .. v16}, Lc1/k;-><init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;ILjava/lang/Object;)V

    return-object v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DataSpec["

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lc1/k;->c:I

    invoke-static {v1}, Lc1/k;->b(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lc1/k;->a:Landroid/net/Uri;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lc1/k;->f:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lc1/k;->g:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc1/k;->h:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lc1/k;->i:I

    const-string v2, "]"

    invoke-static {v0, v1, v2}, LB4/d;->j(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
