.class public final Lc1/y;
.super Lc1/w;
.source "SourceFile"


# instance fields
.field public final d:I

.field public final e:Ljava/util/Map;


# direct methods
.method public constructor <init>(ILc1/h;Ljava/util/Map;)V
    .registers 6

    const-string v0, "Response code: "

    invoke-static {p1, v0}, Le/b;->i(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x7d4

    invoke-direct {p0, v1, p2, v0}, Lc1/w;-><init>(ILjava/io/IOException;Ljava/lang/String;)V

    iput p1, p0, Lc1/y;->d:I

    iput-object p3, p0, Lc1/y;->e:Ljava/util/Map;

    return-void
.end method
