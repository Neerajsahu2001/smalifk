.class public interface abstract Lc1/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract g()Lc1/f;
.end method
