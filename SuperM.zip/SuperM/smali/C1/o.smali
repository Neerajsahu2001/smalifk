.class public final synthetic Lc1/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li8/h;


# virtual methods
.method public final apply(Ljava/lang/Object;)Z
    .registers 2

    check-cast p1, Ljava/lang/String;

    if-eqz p1, :cond_6

    const/4 p1, 0x1

    goto :goto_7

    :cond_6
    const/4 p1, 0x0

    :goto_7
    return p1
.end method
