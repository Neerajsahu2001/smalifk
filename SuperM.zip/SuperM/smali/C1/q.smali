.class public final Lc1/q;
.super Lc1/b;
.source "SourceFile"


# instance fields
.field public final e:Z

.field public final f:Z

.field public final g:I

.field public final h:I

.field public final i:Ljava/lang/String;

.field public final j:LW2/c;

.field public final k:LW2/c;

.field public final l:Li8/h;

.field public final m:Z

.field public n:Ljava/net/HttpURLConnection;

.field public o:Ljava/io/InputStream;

.field public p:Z

.field public q:I

.field public r:J

.field public s:J


# direct methods
.method public constructor <init>(Ljava/lang/String;IILW2/c;)V
    .registers 6

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lc1/b;-><init>(Z)V

    iput-object p1, p0, Lc1/q;->i:Ljava/lang/String;

    iput p2, p0, Lc1/q;->g:I

    iput p3, p0, Lc1/q;->h:I

    const/4 p1, 0x0

    iput-boolean p1, p0, Lc1/q;->e:Z

    iput-boolean p1, p0, Lc1/q;->f:Z

    iput-object p4, p0, Lc1/q;->j:LW2/c;

    const/4 p2, 0x0

    iput-object p2, p0, Lc1/q;->l:Li8/h;

    new-instance p2, LW2/c;

    const/4 p3, 0x6

    invoke-direct {p2, p3}, LW2/c;-><init>(I)V

    iput-object p2, p0, Lc1/q;->k:LW2/c;

    iput-boolean p1, p0, Lc1/q;->m:Z

    return-void
.end method

.method public static v(Ljava/net/HttpURLConnection;J)V
    .registers 5

    if-eqz p0, :cond_53

    sget v0, LZ0/F;->a:I

    const/16 v1, 0x14

    if-le v0, v1, :cond_9

    goto :goto_53

    :cond_9
    :try_start_9
    invoke-virtual {p0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p0

    const-wide/16 v0, -0x1

    cmp-long v0, p1, v0

    if-nez v0, :cond_1b

    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_22

    return-void

    :cond_1b
    const-wide/16 v0, 0x800

    cmp-long p1, p1, v0

    if-gtz p1, :cond_22

    return-void

    :cond_22
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const-string p2, "com.android.okhttp.internal.http.HttpTransport$ChunkedInputStream"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_3a

    const-string p2, "com.android.okhttp.internal.http.HttpTransport$FixedLengthInputStream"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_53

    :cond_3a
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p2, "unexpectedEndOfInput"

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {p1, p0, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_53
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_53} :catch_53

    :catch_53
    :cond_53
    :goto_53
    return-void
.end method


# virtual methods
.method public final c(Lc1/k;)J
    .registers 25

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const-wide/16 v2, 0x0

    iput-wide v2, v1, Lc1/q;->s:J

    iput-wide v2, v1, Lc1/q;->r:J

    invoke-virtual/range {p0 .. p0}, Lc1/b;->p()V

    const/4 v4, 0x1

    :try_start_e
    invoke-virtual/range {p0 .. p1}, Lc1/q;->t(Lc1/k;)Ljava/net/HttpURLConnection;

    move-result-object v5

    iput-object v5, v1, Lc1/q;->n:Ljava/net/HttpURLConnection;

    invoke-virtual {v5}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v6

    iput v6, v1, Lc1/q;->q:I

    invoke-virtual {v5}, Ljava/net/HttpURLConnection;->getResponseMessage()Ljava/lang/String;
    :try_end_1d
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_1d} :catch_1cb

    iget v6, v1, Lc1/q;->q:I

    const-string v7, "Content-Range"

    const/16 v8, 0xc8

    const-wide/16 v9, -0x1

    iget-wide v11, v0, Lc1/k;->f:J

    iget-wide v13, v0, Lc1/k;->g:J

    if-lt v6, v8, :cond_2f

    const/16 v15, 0x12b

    if-le v6, v15, :cond_33

    :cond_2f
    move-object/from16 v22, v5

    goto/16 :goto_17d

    :cond_33
    invoke-virtual {v5}, Ljava/net/URLConnection;->getContentType()Ljava/lang/String;

    move-result-object v6

    iget-object v15, v1, Lc1/q;->l:Li8/h;

    if-eqz v15, :cond_4b

    invoke-interface {v15, v6}, Li8/h;->apply(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_42

    goto :goto_4b

    :cond_42
    invoke-virtual/range {p0 .. p0}, Lc1/q;->r()V

    new-instance v0, Lc1/x;

    invoke-direct {v0, v6}, Lc1/x;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4b
    :goto_4b
    iget v6, v1, Lc1/q;->q:I

    if-ne v6, v8, :cond_54

    cmp-long v6, v11, v2

    if-eqz v6, :cond_54

    goto :goto_55

    :cond_54
    move-wide v11, v2

    :goto_55
    const-string v6, "Content-Encoding"

    invoke-virtual {v5, v6}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v8, "gzip"

    invoke-virtual {v8, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_135

    cmp-long v8, v13, v9

    if-eqz v8, :cond_6f

    iput-wide v13, v1, Lc1/q;->r:J

    move-object/from16 v22, v5

    move-wide/from16 v16, v11

    goto/16 :goto_13b

    :cond_6f
    const-string v8, "Content-Length"

    invoke-virtual {v5, v8}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v7}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    sget-object v13, Lc1/z;->a:Ljava/util/regex/Pattern;

    const-string v13, "Inconsistent headers ["

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v14

    const-string v15, "]"

    const-string v9, "HttpUtil"

    if-nez v14, :cond_a2

    :try_start_87
    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v16
    :try_end_8b
    .catch Ljava/lang/NumberFormatException; {:try_start_87 .. :try_end_8b} :catch_8e

    move-wide/from16 v18, v16

    goto :goto_a4

    :catch_8e
    new-instance v10, Ljava/lang/StringBuilder;

    const-string v14, "Unexpected Content-Length ["

    invoke-direct {v10, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, LZ0/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_a2
    const-wide/16 v18, -0x1

    :goto_a4
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10

    if-nez v10, :cond_120

    sget-object v10, Lc1/z;->a:Ljava/util/regex/Pattern;

    invoke-virtual {v10, v7}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->matches()Z

    move-result v14

    if-eqz v14, :cond_120

    const/4 v14, 0x2

    :try_start_b7
    invoke-virtual {v10, v14}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v14}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v16

    invoke-virtual {v10, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v20
    :try_end_cd
    .catch Ljava/lang/NumberFormatException; {:try_start_b7 .. :try_end_cd} :catch_105

    sub-long v16, v16, v20

    const-wide/16 v20, 0x1

    move-object/from16 v22, v5

    add-long v4, v16, v20

    move-wide/from16 v16, v11

    move-wide/from16 v10, v18

    cmp-long v2, v10, v2

    if-gez v2, :cond_e0

    move-wide/from16 v18, v4

    goto :goto_102

    :cond_e0
    cmp-long v2, v10, v4

    if-eqz v2, :cond_126

    :try_start_e4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "] ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v9, v2}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v10, v11, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v18
    :try_end_102
    .catch Ljava/lang/NumberFormatException; {:try_start_e4 .. :try_end_102} :catch_10b

    :goto_102
    const-wide/16 v2, -0x1

    goto :goto_129

    :catch_105
    move-object/from16 v22, v5

    move-wide/from16 v16, v11

    move-wide/from16 v10, v18

    :catch_10b
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Unexpected Content-Range ["

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v9, v2}, LZ0/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_126

    :cond_120
    move-object/from16 v22, v5

    move-wide/from16 v16, v11

    move-wide/from16 v10, v18

    :cond_126
    :goto_126
    move-wide/from16 v18, v10

    goto :goto_102

    :goto_129
    cmp-long v4, v18, v2

    if-eqz v4, :cond_130

    sub-long v9, v18, v16

    goto :goto_132

    :cond_130
    const-wide/16 v9, -0x1

    :goto_132
    iput-wide v9, v1, Lc1/q;->r:J

    goto :goto_13b

    :cond_135
    move-object/from16 v22, v5

    move-wide/from16 v16, v11

    iput-wide v13, v1, Lc1/q;->r:J

    :goto_13b
    const/16 v2, 0x7d0

    :try_start_13d
    invoke-virtual/range {v22 .. v22}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v3

    iput-object v3, v1, Lc1/q;->o:Ljava/io/InputStream;

    if-eqz v6, :cond_14e

    new-instance v3, Ljava/util/zip/GZIPInputStream;

    iget-object v4, v1, Lc1/q;->o:Ljava/io/InputStream;

    invoke-direct {v3, v4}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V

    iput-object v3, v1, Lc1/q;->o:Ljava/io/InputStream;
    :try_end_14e
    .catch Ljava/io/IOException; {:try_start_13d .. :try_end_14e} :catch_150

    :cond_14e
    const/4 v3, 0x1

    goto :goto_153

    :catch_150
    move-exception v0

    const/4 v4, 0x1

    goto :goto_174

    :goto_153
    iput-boolean v3, v1, Lc1/q;->p:Z

    invoke-virtual/range {p0 .. p1}, Lc1/b;->q(Lc1/k;)V

    move-wide/from16 v11, v16

    :try_start_15a
    invoke-virtual {v1, v11, v12}, Lc1/q;->w(J)V
    :try_end_15d
    .catch Ljava/io/IOException; {:try_start_15a .. :try_end_15d} :catch_160

    iget-wide v2, v1, Lc1/q;->r:J

    return-wide v2

    :catch_160
    move-exception v0

    move-object v3, v0

    invoke-virtual/range {p0 .. p0}, Lc1/q;->r()V

    instance-of v0, v3, Lc1/w;

    if-eqz v0, :cond_16d

    move-object v0, v3

    check-cast v0, Lc1/w;

    throw v0

    :cond_16d
    new-instance v0, Lc1/w;

    const/4 v4, 0x1

    invoke-direct {v0, v3, v2, v4}, Lc1/w;-><init>(Ljava/io/IOException;II)V

    throw v0

    :goto_174
    invoke-virtual/range {p0 .. p0}, Lc1/q;->r()V

    new-instance v3, Lc1/w;

    invoke-direct {v3, v0, v2, v4}, Lc1/w;-><init>(Ljava/io/IOException;II)V

    throw v3

    :goto_17d
    invoke-virtual/range {v22 .. v22}, Ljava/net/URLConnection;->getHeaderFields()Ljava/util/Map;

    move-result-object v5

    iget v6, v1, Lc1/q;->q:I

    const/16 v8, 0x1a0

    if-ne v6, v8, :cond_1a2

    move-object/from16 v6, v22

    invoke-virtual {v6, v7}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lc1/z;->b(Ljava/lang/String;)J

    move-result-wide v9

    cmp-long v7, v11, v9

    if-nez v7, :cond_1a4

    iput-boolean v4, v1, Lc1/q;->p:Z

    invoke-virtual/range {p0 .. p1}, Lc1/b;->q(Lc1/k;)V

    const-wide/16 v4, -0x1

    cmp-long v0, v13, v4

    if-eqz v0, :cond_1a1

    move-wide v2, v13

    :cond_1a1
    return-wide v2

    :cond_1a2
    move-object/from16 v6, v22

    :cond_1a4
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v0

    if-eqz v0, :cond_1ae

    :try_start_1aa
    invoke-static {v0}, Lk8/b;->b(Ljava/io/InputStream;)[B

    goto :goto_1b3

    :cond_1ae
    sget v0, LZ0/F;->a:I
    :try_end_1b0
    .catch Ljava/io/IOException; {:try_start_1aa .. :try_end_1b0} :catch_1b1

    goto :goto_1b3

    :catch_1b1
    sget v0, LZ0/F;->a:I

    :goto_1b3
    invoke-virtual/range {p0 .. p0}, Lc1/q;->r()V

    iget v0, v1, Lc1/q;->q:I

    if-ne v0, v8, :cond_1c2

    new-instance v0, Lc1/h;

    const/16 v2, 0x7d8

    invoke-direct {v0, v2}, Lc1/h;-><init>(I)V

    goto :goto_1c3

    :cond_1c2
    const/4 v0, 0x0

    :goto_1c3
    new-instance v2, Lc1/y;

    iget v3, v1, Lc1/q;->q:I

    invoke-direct {v2, v3, v0, v5}, Lc1/y;-><init>(ILc1/h;Ljava/util/Map;)V

    throw v2

    :catch_1cb
    move-exception v0

    invoke-virtual/range {p0 .. p0}, Lc1/q;->r()V

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lc1/w;->b(Ljava/io/IOException;I)Lc1/w;

    move-result-object v0

    throw v0
.end method

.method public final close()V
    .registers 9

    const/4 v0, 0x0

    const/4 v1, 0x0

    :try_start_2
    iget-object v2, p0, Lc1/q;->o:Ljava/io/InputStream;

    if-eqz v2, :cond_2a

    iget-wide v3, p0, Lc1/q;->r:J

    const-wide/16 v5, -0x1

    cmp-long v7, v3, v5

    if-nez v7, :cond_f

    goto :goto_13

    :cond_f
    iget-wide v5, p0, Lc1/q;->s:J

    sub-long v5, v3, v5

    :goto_13
    iget-object v3, p0, Lc1/q;->n:Ljava/net/HttpURLConnection;

    invoke-static {v3, v5, v6}, Lc1/q;->v(Ljava/net/HttpURLConnection;J)V
    :try_end_18
    .catchall {:try_start_2 .. :try_end_18} :catchall_1c

    :try_start_18
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_1b
    .catch Ljava/io/IOException; {:try_start_18 .. :try_end_1b} :catch_1e
    .catchall {:try_start_18 .. :try_end_1b} :catchall_1c

    goto :goto_2a

    :catchall_1c
    move-exception v2

    goto :goto_39

    :catch_1e
    move-exception v2

    :try_start_1f
    new-instance v3, Lc1/w;

    sget v4, LZ0/F;->a:I

    const/16 v4, 0x7d0

    const/4 v5, 0x3

    invoke-direct {v3, v2, v4, v5}, Lc1/w;-><init>(Ljava/io/IOException;II)V

    throw v3
    :try_end_2a
    .catchall {:try_start_1f .. :try_end_2a} :catchall_1c

    :cond_2a
    :goto_2a
    iput-object v1, p0, Lc1/q;->o:Ljava/io/InputStream;

    invoke-virtual {p0}, Lc1/q;->r()V

    iget-boolean v1, p0, Lc1/q;->p:Z

    if-eqz v1, :cond_38

    iput-boolean v0, p0, Lc1/q;->p:Z

    invoke-virtual {p0}, Lc1/b;->o()V

    :cond_38
    return-void

    :goto_39
    iput-object v1, p0, Lc1/q;->o:Ljava/io/InputStream;

    invoke-virtual {p0}, Lc1/q;->r()V

    iget-boolean v1, p0, Lc1/q;->p:Z

    if-eqz v1, :cond_47

    iput-boolean v0, p0, Lc1/q;->p:Z

    invoke-virtual {p0}, Lc1/b;->o()V

    :cond_47
    throw v2
.end method

.method public final g()Ljava/util/Map;
    .registers 3

    iget-object v0, p0, Lc1/q;->n:Ljava/net/HttpURLConnection;

    if-nez v0, :cond_7

    sget-object v0, Lj8/v0;->g:Lj8/v0;

    return-object v0

    :cond_7
    new-instance v1, Lc1/p;

    invoke-virtual {v0}, Ljava/net/URLConnection;->getHeaderFields()Ljava/util/Map;

    move-result-object v0

    invoke-direct {v1, v0}, Lc1/p;-><init>(Ljava/util/Map;)V

    return-object v1
.end method

.method public final k()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc1/q;->n:Ljava/net/HttpURLConnection;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_12

    :cond_6
    invoke-virtual {v0}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    :goto_12
    return-object v0
.end method

.method public final l([BII)I
    .registers 10

    if-nez p3, :cond_4

    const/4 p1, 0x0

    goto :goto_32

    :cond_4
    :try_start_4
    iget-wide v0, p0, Lc1/q;->r:J

    const-wide/16 v2, -0x1

    cmp-long v2, v0, v2

    const/4 v3, -0x1

    if-eqz v2, :cond_1e

    iget-wide v4, p0, Lc1/q;->s:J

    sub-long/2addr v0, v4

    const-wide/16 v4, 0x0

    cmp-long v2, v0, v4

    if-nez v2, :cond_18

    :goto_16
    move p1, v3

    goto :goto_32

    :cond_18
    int-to-long v4, p3

    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int p3, v0

    :cond_1e
    iget-object v0, p0, Lc1/q;->o:Ljava/io/InputStream;

    sget v1, LZ0/F;->a:I

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/InputStream;->read([BII)I

    move-result p1

    if-ne p1, v3, :cond_29

    goto :goto_16

    :cond_29
    iget-wide p2, p0, Lc1/q;->s:J

    int-to-long v0, p1

    add-long/2addr p2, v0

    iput-wide p2, p0, Lc1/q;->s:J

    invoke-virtual {p0, p1}, Lc1/b;->n(I)V
    :try_end_32
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_32} :catch_33

    :goto_32
    return p1

    :catch_33
    move-exception p1

    sget p2, LZ0/F;->a:I

    const/4 p2, 0x2

    invoke-static {p1, p2}, Lc1/w;->b(Ljava/io/IOException;I)Lc1/w;

    move-result-object p1

    throw p1
.end method

.method public final r()V
    .registers 4

    iget-object v0, p0, Lc1/q;->n:Ljava/net/HttpURLConnection;

    if-eqz v0, :cond_13

    :try_start_4
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_7} :catch_8

    goto :goto_10

    :catch_8
    move-exception v0

    const-string v1, "DefaultHttpDataSource"

    const-string v2, "Unexpected error while disconnecting"

    invoke-static {v1, v2, v0}, LZ0/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_10
    const/4 v0, 0x0

    iput-object v0, p0, Lc1/q;->n:Ljava/net/HttpURLConnection;

    :cond_13
    return-void
.end method

.method public final s(Ljava/net/URL;Ljava/lang/String;)Ljava/net/URL;
    .registers 7

    const/16 v0, 0x7d1

    if-eqz p2, :cond_84

    const/4 v1, 0x1

    :try_start_5
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, p1, p2}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V
    :try_end_a
    .catch Ljava/net/MalformedURLException; {:try_start_5 .. :try_end_a} :catch_7d

    invoke-virtual {v2}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object p2

    const-string v3, "https"

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2b

    const-string v3, "http"

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1f

    goto :goto_2b

    :cond_1f
    new-instance p1, Lc1/w;

    const-string v1, "Unsupported protocol redirect: "

    invoke-static {v1, p2}, LA8/v;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2, v0}, Lc1/w;-><init>(Ljava/lang/String;I)V

    throw p1

    :cond_2b
    :goto_2b
    iget-boolean v3, p0, Lc1/q;->e:Z

    if-nez v3, :cond_7c

    invoke-virtual {p1}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7c

    iget-boolean v3, p0, Lc1/q;->f:Z

    if-eqz v3, :cond_57

    :try_start_3d
    new-instance v3, Ljava/net/URL;

    invoke-virtual {v2}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p2, p1}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v3, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_4e
    .catch Ljava/net/MalformedURLException; {:try_start_3d .. :try_end_4e} :catch_50

    move-object v2, v3

    goto :goto_7c

    :catch_50
    move-exception p1

    new-instance p2, Lc1/w;

    invoke-direct {p2, p1, v0, v1}, Lc1/w;-><init>(Ljava/io/IOException;II)V

    throw p2

    :cond_57
    new-instance v1, Lc1/w;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Disallowed cross-protocol redirect ("

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " to "

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ")"

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1, v0}, Lc1/w;-><init>(Ljava/lang/String;I)V

    throw v1

    :cond_7c
    :goto_7c
    return-object v2

    :catch_7d
    move-exception p1

    new-instance p2, Lc1/w;

    invoke-direct {p2, p1, v0, v1}, Lc1/w;-><init>(Ljava/io/IOException;II)V

    throw p2

    :cond_84
    new-instance p1, Lc1/w;

    const-string p2, "Null location redirect"

    invoke-direct {p1, p2, v0}, Lc1/w;-><init>(Ljava/lang/String;I)V

    throw p1
.end method

.method public final t(Lc1/k;)Ljava/net/HttpURLConnection;
    .registers 27

    move-object/from16 v11, p0

    move-object/from16 v12, p1

    new-instance v1, Ljava/net/URL;

    iget-object v0, v12, Lc1/k;->a:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Lc1/k;->c(I)Z

    move-result v14

    iget-boolean v0, v11, Lc1/q;->e:Z

    iget-boolean v15, v11, Lc1/q;->m:Z

    iget v2, v12, Lc1/k;->c:I

    iget-object v3, v12, Lc1/k;->d:[B

    iget-wide v9, v12, Lc1/k;->f:J

    iget-wide v6, v12, Lc1/k;->g:J

    if-nez v0, :cond_36

    iget-boolean v0, v11, Lc1/q;->f:Z

    if-nez v0, :cond_36

    if-nez v15, :cond_36

    const/4 v13, 0x1

    iget-object v12, v12, Lc1/k;->e:Ljava/util/Map;

    move-object/from16 v0, p0

    move-wide v4, v9

    move v8, v14

    move v9, v13

    move-object v10, v12

    invoke-virtual/range {v0 .. v10}, Lc1/q;->u(Ljava/net/URL;I[BJJZZLjava/util/Map;)Ljava/net/HttpURLConnection;

    move-result-object v0

    return-object v0

    :cond_36
    const/4 v0, 0x0

    move-object v8, v1

    move v4, v2

    move-object/from16 v16, v3

    :goto_3b
    add-int/lit8 v5, v0, 0x1

    const/16 v1, 0x14

    if-gt v0, v1, :cond_be

    const/16 v17, 0x0

    iget-object v3, v12, Lc1/k;->e:Ljava/util/Map;

    move-object/from16 v0, p0

    move-object v1, v8

    move v2, v4

    move-object/from16 v18, v3

    move-object/from16 v3, v16

    move v12, v4

    move/from16 v19, v5

    move-wide v4, v9

    move-wide/from16 v20, v6

    move-object/from16 v22, v8

    move v8, v14

    move-wide/from16 v23, v9

    move/from16 v9, v17

    move-object/from16 v10, v18

    invoke-virtual/range {v0 .. v10}, Lc1/q;->u(Ljava/net/URL;I[BJJZZLjava/util/Map;)Ljava/net/HttpURLConnection;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1

    const-string v2, "Location"

    invoke-virtual {v0, v2}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x12f

    const/16 v4, 0x12d

    const/16 v5, 0x12c

    const/16 v6, 0x12e

    if-eq v12, v13, :cond_77

    const/4 v7, 0x3

    if-ne v12, v7, :cond_8a

    :cond_77
    if-eq v1, v5, :cond_87

    if-eq v1, v4, :cond_87

    if-eq v1, v6, :cond_87

    if-eq v1, v3, :cond_87

    const/16 v7, 0x133

    if-eq v1, v7, :cond_87

    const/16 v7, 0x134

    if-ne v1, v7, :cond_8a

    :cond_87
    move-object/from16 v1, v22

    goto :goto_ab

    :cond_8a
    const/4 v7, 0x2

    if-ne v12, v7, :cond_aa

    if-eq v1, v5, :cond_95

    if-eq v1, v4, :cond_95

    if-eq v1, v6, :cond_95

    if-ne v1, v3, :cond_aa

    :cond_95
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    if-eqz v15, :cond_a0

    if-ne v1, v6, :cond_a0

    move v4, v12

    :goto_9d
    move-object/from16 v1, v22

    goto :goto_a4

    :cond_a0
    const/16 v16, 0x0

    move v4, v13

    goto :goto_9d

    :goto_a4
    invoke-virtual {v11, v1, v2}, Lc1/q;->s(Ljava/net/URL;Ljava/lang/String;)Ljava/net/URL;

    move-result-object v0

    move-object v8, v0

    goto :goto_b4

    :cond_aa
    return-object v0

    :goto_ab
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    invoke-virtual {v11, v1, v2}, Lc1/q;->s(Ljava/net/URL;Ljava/lang/String;)Ljava/net/URL;

    move-result-object v0

    move-object v8, v0

    move v4, v12

    :goto_b4
    move-object/from16 v12, p1

    move/from16 v0, v19

    move-wide/from16 v6, v20

    move-wide/from16 v9, v23

    goto/16 :goto_3b

    :cond_be
    move/from16 v19, v5

    new-instance v0, Lc1/w;

    new-instance v1, Ljava/net/NoRouteToHostException;

    const-string v2, "Too many redirects: "

    move/from16 v3, v19

    invoke-static {v3, v2}, Le/b;->i(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/net/NoRouteToHostException;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x7d1

    invoke-direct {v0, v1, v2, v13}, Lc1/w;-><init>(Ljava/io/IOException;II)V

    throw v0
.end method

.method public final u(Ljava/net/URL;I[BJJZZLjava/util/Map;)Ljava/net/HttpURLConnection;
    .registers 13

    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    invoke-static {p1}, Lcom/google/firebase/perf/network/FirebasePerfUrlConnection;->instrument(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/net/URLConnection;

    check-cast p1, Ljava/net/HttpURLConnection;

    iget v0, p0, Lc1/q;->g:I

    invoke-virtual {p1, v0}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    iget v0, p0, Lc1/q;->h:I

    invoke-virtual {p1, v0}, Ljava/net/URLConnection;->setReadTimeout(I)V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, Lc1/q;->j:LW2/c;

    if-eqz v1, :cond_26

    invoke-virtual {v1}, LW2/c;->f()Ljava/util/Map;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_26
    iget-object v1, p0, Lc1/q;->k:LW2/c;

    invoke-virtual {v1}, LW2/c;->f()Ljava/util/Map;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    invoke-virtual {v0, p10}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p10

    invoke-interface {p10}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p10

    :goto_3a
    invoke-interface {p10}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-interface {p10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {p1, v1, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_3a

    :cond_56
    invoke-static {p4, p5, p6, p7}, Lc1/z;->a(JJ)Ljava/lang/String;

    move-result-object p4

    if-eqz p4, :cond_61

    const-string p5, "Range"

    invoke-virtual {p1, p5, p4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_61
    iget-object p4, p0, Lc1/q;->i:Ljava/lang/String;

    if-eqz p4, :cond_6a

    const-string p5, "User-Agent"

    invoke-virtual {p1, p5, p4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6a
    if-eqz p8, :cond_6f

    const-string p4, "gzip"

    goto :goto_71

    :cond_6f
    const-string p4, "identity"

    :goto_71
    const-string p5, "Accept-Encoding"

    invoke-virtual {p1, p5, p4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1, p9}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    if-eqz p3, :cond_7d

    const/4 p4, 0x1

    goto :goto_7e

    :cond_7d
    const/4 p4, 0x0

    :goto_7e
    invoke-virtual {p1, p4}, Ljava/net/URLConnection;->setDoOutput(Z)V

    invoke-static {p2}, Lc1/k;->b(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    if-eqz p3, :cond_9c

    array-length p2, p3

    invoke-virtual {p1, p2}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    invoke-virtual {p1}, Ljava/net/URLConnection;->connect()V

    invoke-virtual {p1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p2

    invoke-virtual {p2, p3}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V

    goto :goto_9f

    :cond_9c
    invoke-virtual {p1}, Ljava/net/URLConnection;->connect()V

    :goto_9f
    return-object p1
.end method

.method public final w(J)V
    .registers 10

    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-nez v2, :cond_7

    return-void

    :cond_7
    const/16 v2, 0x1000

    new-array v3, v2, [B

    :goto_b
    cmp-long v4, p1, v0

    if-lez v4, :cond_47

    int-to-long v4, v2

    invoke-static {p1, p2, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v4

    long-to-int v4, v4

    iget-object v5, p0, Lc1/q;->o:Ljava/io/InputStream;

    sget v6, LZ0/F;->a:I

    const/4 v6, 0x0

    invoke-virtual {v5, v3, v6, v4}, Ljava/io/InputStream;->read([BII)I

    move-result v4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v5

    if-nez v5, :cond_39

    const/4 v5, -0x1

    if-eq v4, v5, :cond_31

    int-to-long v5, v4

    sub-long/2addr p1, v5

    invoke-virtual {p0, v4}, Lc1/b;->n(I)V

    goto :goto_b

    :cond_31
    new-instance p1, Lc1/w;

    const/16 p2, 0x7d8

    invoke-direct {p1, p2}, Lc1/w;-><init>(I)V

    throw p1

    :cond_39
    new-instance p1, Lc1/w;

    new-instance p2, Ljava/io/InterruptedIOException;

    invoke-direct {p2}, Ljava/io/InterruptedIOException;-><init>()V

    const/16 v0, 0x7d0

    const/4 v1, 0x1

    invoke-direct {p1, p2, v0, v1}, Lc1/w;-><init>(Ljava/io/IOException;II)V

    throw p1

    :cond_47
    return-void
.end method
