.class public final Lc1/d;
.super Lc1/b;
.source "SourceFile"


# instance fields
.field public e:Lc1/k;

.field public f:[B

.field public g:I

.field public h:I


# virtual methods
.method public final c(Lc1/k;)J
    .registers 9

    invoke-virtual {p0}, Lc1/b;->p()V

    iput-object p1, p0, Lc1/d;->e:Lc1/k;

    iget-object v0, p1, Lc1/k;->a:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->normalizeScheme()Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v1

    const-string v2, "data"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Unsupported scheme: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lm7/u;->b(ZLjava/lang/String;)V

    invoke-virtual {v0}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v1

    sget v2, LZ0/F;->a:I

    const/4 v2, -0x1

    const-string v3, ","

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ne v2, v5, :cond_a1

    aget-object v0, v1, v4

    aget-object v1, v1, v3

    const-string v2, ";base64"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_5a

    :try_start_46
    invoke-static {v0, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    iput-object v1, p0, Lc1/d;->f:[B
    :try_end_4c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_46 .. :try_end_4c} :catch_4d

    goto :goto_6c

    :catch_4d
    move-exception p1

    const-string v1, "Error while parsing Base64 encoded string: "

    invoke-static {v1, v0}, LA8/v;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, LW0/J;

    invoke-direct {v1, v0, p1, v4, v3}, LW0/J;-><init>(Ljava/lang/String;Ljava/lang/Exception;ZI)V

    throw v1

    :cond_5a
    sget-object v1, Li8/e;->a:Ljava/nio/charset/Charset;

    invoke-virtual {v1}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Li8/e;->c:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    iput-object v0, p0, Lc1/d;->f:[B

    :goto_6c
    iget-object v0, p0, Lc1/d;->f:[B

    array-length v1, v0

    int-to-long v1, v1

    iget-wide v3, p1, Lc1/k;->f:J

    cmp-long v1, v3, v1

    if-gtz v1, :cond_97

    long-to-int v1, v3

    iput v1, p0, Lc1/d;->g:I

    array-length v0, v0

    sub-int/2addr v0, v1

    iput v0, p0, Lc1/d;->h:I

    const-wide/16 v1, -0x1

    iget-wide v3, p1, Lc1/k;->g:J

    cmp-long v1, v3, v1

    if-eqz v1, :cond_8d

    int-to-long v5, v0

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v5

    long-to-int v0, v5

    iput v0, p0, Lc1/d;->h:I

    :cond_8d
    invoke-virtual {p0, p1}, Lc1/b;->q(Lc1/k;)V

    if-eqz v1, :cond_93

    goto :goto_96

    :cond_93
    iget p1, p0, Lc1/d;->h:I

    int-to-long v3, p1

    :goto_96
    return-wide v3

    :cond_97
    iput-object v6, p0, Lc1/d;->f:[B

    new-instance p1, Lc1/h;

    const/16 v0, 0x7d8

    invoke-direct {p1, v0}, Lc1/h;-><init>(I)V

    throw p1

    :cond_a1
    const-string p1, "Unexpected URI format: "

    invoke-static {v0, p1}, Ldb/s;->g(Landroid/net/Uri;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v0, LW0/J;

    invoke-direct {v0, p1, v6, v4, v3}, LW0/J;-><init>(Ljava/lang/String;Ljava/lang/Exception;ZI)V

    throw v0
.end method

.method public final close()V
    .registers 3

    iget-object v0, p0, Lc1/d;->f:[B

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    iput-object v1, p0, Lc1/d;->f:[B

    invoke-virtual {p0}, Lc1/b;->o()V

    :cond_a
    iput-object v1, p0, Lc1/d;->e:Lc1/k;

    return-void
.end method

.method public final k()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc1/d;->e:Lc1/k;

    if-eqz v0, :cond_7

    iget-object v0, v0, Lc1/k;->a:Landroid/net/Uri;

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    return-object v0
.end method

.method public final l([BII)I
    .registers 6

    if-nez p3, :cond_4

    const/4 p1, 0x0

    return p1

    :cond_4
    iget v0, p0, Lc1/d;->h:I

    if-nez v0, :cond_a

    const/4 p1, -0x1

    return p1

    :cond_a
    invoke-static {p3, v0}, Ljava/lang/Math;->min(II)I

    move-result p3

    iget-object v0, p0, Lc1/d;->f:[B

    sget v1, LZ0/F;->a:I

    iget v1, p0, Lc1/d;->g:I

    invoke-static {v0, v1, p1, p2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p1, p0, Lc1/d;->g:I

    add-int/2addr p1, p3

    iput p1, p0, Lc1/d;->g:I

    iget p1, p0, Lc1/d;->h:I

    sub-int/2addr p1, p3

    iput p1, p0, Lc1/d;->h:I

    invoke-virtual {p0, p3}, Lc1/b;->n(I)V

    return p3
.end method
