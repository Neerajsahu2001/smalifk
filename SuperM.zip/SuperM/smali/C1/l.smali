.class public final Lc1/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc1/f;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/util/ArrayList;

.field public final c:Lc1/f;

.field public d:Lc1/t;

.field public e:Landroidx/media3/datasource/AssetDataSource;

.field public f:Landroidx/media3/datasource/ContentDataSource;

.field public g:Lc1/f;

.field public h:Lc1/G;

.field public i:Lc1/d;

.field public j:Landroidx/media3/datasource/RawResourceDataSource;

.field public k:Lc1/f;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lc1/f;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lc1/l;->a:Landroid/content/Context;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p0, Lc1/l;->c:Lc1/f;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lc1/l;->b:Ljava/util/ArrayList;

    return-void
.end method

.method public static o(Lc1/f;Lc1/E;)V
    .registers 2

    if-eqz p0, :cond_5

    invoke-interface {p0, p1}, Lc1/f;->j(Lc1/E;)V

    :cond_5
    return-void
.end method


# virtual methods
.method public final c(Lc1/k;)J
    .registers 8

    iget-object v0, p0, Lc1/l;->k:Lc1/f;

    const/4 v1, 0x0

    if-nez v0, :cond_7

    const/4 v0, 0x1

    goto :goto_8

    :cond_7
    move v0, v1

    :goto_8
    invoke-static {v0}, Lm7/u;->e(Z)V

    iget-object v0, p1, Lc1/k;->a:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    sget v2, LZ0/F;->a:I

    iget-object v2, p1, Lc1/k;->a:Landroid/net/Uri;

    invoke-virtual {v2}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    iget-object v5, p0, Lc1/l;->a:Landroid/content/Context;

    if-nez v4, :cond_102

    const-string v4, "file"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2b

    goto/16 :goto_102

    :cond_2b
    const-string v2, "asset"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_47

    iget-object v0, p0, Lc1/l;->e:Landroidx/media3/datasource/AssetDataSource;

    if-nez v0, :cond_41

    new-instance v0, Landroidx/media3/datasource/AssetDataSource;

    invoke-direct {v0, v5}, Landroidx/media3/datasource/AssetDataSource;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc1/l;->e:Landroidx/media3/datasource/AssetDataSource;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V

    :cond_41
    iget-object v0, p0, Lc1/l;->e:Landroidx/media3/datasource/AssetDataSource;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    goto/16 :goto_135

    :cond_47
    const-string v2, "content"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_63

    iget-object v0, p0, Lc1/l;->f:Landroidx/media3/datasource/ContentDataSource;

    if-nez v0, :cond_5d

    new-instance v0, Landroidx/media3/datasource/ContentDataSource;

    invoke-direct {v0, v5}, Landroidx/media3/datasource/ContentDataSource;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc1/l;->f:Landroidx/media3/datasource/ContentDataSource;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V

    :cond_5d
    iget-object v0, p0, Lc1/l;->f:Landroidx/media3/datasource/ContentDataSource;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    goto/16 :goto_135

    :cond_63
    const-string v2, "rtmp"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    iget-object v3, p0, Lc1/l;->c:Lc1/f;

    if-eqz v2, :cond_a4

    iget-object v0, p0, Lc1/l;->g:Lc1/f;

    if-nez v0, :cond_9e

    :try_start_71
    const-string v0, "androidx.media3.datasource.rtmp.RtmpDataSource"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc1/f;

    iput-object v0, p0, Lc1/l;->g:Lc1/f;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V
    :try_end_87
    .catch Ljava/lang/ClassNotFoundException; {:try_start_71 .. :try_end_87} :catch_91
    .catch Ljava/lang/Exception; {:try_start_71 .. :try_end_87} :catch_88

    goto :goto_98

    :catch_88
    move-exception p1

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Error instantiating RTMP extension"

    invoke-direct {v0, v1, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :catch_91
    const-string v0, "DefaultDataSource"

    const-string v1, "Attempting to play RTMP stream without depending on the RTMP extension"

    invoke-static {v0, v1}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_98
    iget-object v0, p0, Lc1/l;->g:Lc1/f;

    if-nez v0, :cond_9e

    iput-object v3, p0, Lc1/l;->g:Lc1/f;

    :cond_9e
    iget-object v0, p0, Lc1/l;->g:Lc1/f;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    goto/16 :goto_135

    :cond_a4
    const-string v2, "udp"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_c0

    iget-object v0, p0, Lc1/l;->h:Lc1/G;

    if-nez v0, :cond_ba

    new-instance v0, Lc1/G;

    invoke-direct {v0}, Lc1/G;-><init>()V

    iput-object v0, p0, Lc1/l;->h:Lc1/G;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V

    :cond_ba
    iget-object v0, p0, Lc1/l;->h:Lc1/G;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    goto/16 :goto_135

    :cond_c0
    const-string v2, "data"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_db

    iget-object v0, p0, Lc1/l;->i:Lc1/d;

    if-nez v0, :cond_d6

    new-instance v0, Lc1/d;

    invoke-direct {v0, v1}, Lc1/b;-><init>(Z)V

    iput-object v0, p0, Lc1/l;->i:Lc1/d;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V

    :cond_d6
    iget-object v0, p0, Lc1/l;->i:Lc1/d;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    goto :goto_135

    :cond_db
    const-string v1, "rawresource"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ef

    const-string v1, "android.resource"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ec

    goto :goto_ef

    :cond_ec
    iput-object v3, p0, Lc1/l;->k:Lc1/f;

    goto :goto_135

    :cond_ef
    :goto_ef
    iget-object v0, p0, Lc1/l;->j:Landroidx/media3/datasource/RawResourceDataSource;

    if-nez v0, :cond_fd

    new-instance v0, Landroidx/media3/datasource/RawResourceDataSource;

    invoke-direct {v0, v5}, Landroidx/media3/datasource/RawResourceDataSource;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc1/l;->j:Landroidx/media3/datasource/RawResourceDataSource;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V

    :cond_fd
    iget-object v0, p0, Lc1/l;->j:Landroidx/media3/datasource/RawResourceDataSource;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    goto :goto_135

    :cond_102
    :goto_102
    invoke-virtual {v2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_123

    const-string v2, "/android_asset/"

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_123

    iget-object v0, p0, Lc1/l;->e:Landroidx/media3/datasource/AssetDataSource;

    if-nez v0, :cond_11e

    new-instance v0, Landroidx/media3/datasource/AssetDataSource;

    invoke-direct {v0, v5}, Landroidx/media3/datasource/AssetDataSource;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc1/l;->e:Landroidx/media3/datasource/AssetDataSource;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V

    :cond_11e
    iget-object v0, p0, Lc1/l;->e:Landroidx/media3/datasource/AssetDataSource;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    goto :goto_135

    :cond_123
    iget-object v0, p0, Lc1/l;->d:Lc1/t;

    if-nez v0, :cond_131

    new-instance v0, Lc1/t;

    invoke-direct {v0, v1}, Lc1/b;-><init>(Z)V

    iput-object v0, p0, Lc1/l;->d:Lc1/t;

    invoke-virtual {p0, v0}, Lc1/l;->n(Lc1/f;)V

    :cond_131
    iget-object v0, p0, Lc1/l;->d:Lc1/t;

    iput-object v0, p0, Lc1/l;->k:Lc1/f;

    :goto_135
    iget-object v0, p0, Lc1/l;->k:Lc1/f;

    invoke-interface {v0, p1}, Lc1/f;->c(Lc1/k;)J

    move-result-wide v0

    return-wide v0
.end method

.method public final close()V
    .registers 3

    iget-object v0, p0, Lc1/l;->k:Lc1/f;

    if-eqz v0, :cond_f

    const/4 v1, 0x0

    :try_start_5
    invoke-interface {v0}, Lc1/f;->close()V
    :try_end_8
    .catchall {:try_start_5 .. :try_end_8} :catchall_b

    iput-object v1, p0, Lc1/l;->k:Lc1/f;

    goto :goto_f

    :catchall_b
    move-exception v0

    iput-object v1, p0, Lc1/l;->k:Lc1/f;

    throw v0

    :cond_f
    :goto_f
    return-void
.end method

.method public final g()Ljava/util/Map;
    .registers 2

    iget-object v0, p0, Lc1/l;->k:Lc1/f;

    if-nez v0, :cond_9

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    goto :goto_d

    :cond_9
    invoke-interface {v0}, Lc1/f;->g()Ljava/util/Map;

    move-result-object v0

    :goto_d
    return-object v0
.end method

.method public final j(Lc1/E;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc1/l;->c:Lc1/f;

    invoke-interface {v0, p1}, Lc1/f;->j(Lc1/E;)V

    iget-object v0, p0, Lc1/l;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lc1/l;->d:Lc1/t;

    invoke-static {v0, p1}, Lc1/l;->o(Lc1/f;Lc1/E;)V

    iget-object v0, p0, Lc1/l;->e:Landroidx/media3/datasource/AssetDataSource;

    invoke-static {v0, p1}, Lc1/l;->o(Lc1/f;Lc1/E;)V

    iget-object v0, p0, Lc1/l;->f:Landroidx/media3/datasource/ContentDataSource;

    invoke-static {v0, p1}, Lc1/l;->o(Lc1/f;Lc1/E;)V

    iget-object v0, p0, Lc1/l;->g:Lc1/f;

    invoke-static {v0, p1}, Lc1/l;->o(Lc1/f;Lc1/E;)V

    iget-object v0, p0, Lc1/l;->h:Lc1/G;

    invoke-static {v0, p1}, Lc1/l;->o(Lc1/f;Lc1/E;)V

    iget-object v0, p0, Lc1/l;->i:Lc1/d;

    invoke-static {v0, p1}, Lc1/l;->o(Lc1/f;Lc1/E;)V

    iget-object v0, p0, Lc1/l;->j:Landroidx/media3/datasource/RawResourceDataSource;

    invoke-static {v0, p1}, Lc1/l;->o(Lc1/f;Lc1/E;)V

    return-void
.end method

.method public final k()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lc1/l;->k:Lc1/f;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_a

    :cond_6
    invoke-interface {v0}, Lc1/f;->k()Landroid/net/Uri;

    move-result-object v0

    :goto_a
    return-object v0
.end method

.method public final l([BII)I
    .registers 5

    iget-object v0, p0, Lc1/l;->k:Lc1/f;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0, p1, p2, p3}, LW0/k;->l([BII)I

    move-result p1

    return p1
.end method

.method public final n(Lc1/f;)V
    .registers 5

    const/4 v0, 0x0

    :goto_1
    iget-object v1, p0, Lc1/l;->b:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_15

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc1/E;

    invoke-interface {p1, v1}, Lc1/f;->j(Lc1/E;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_15
    return-void
.end method
