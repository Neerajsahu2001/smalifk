.class public final LA0/p;
.super LE/o;
.source "SourceFile"


# virtual methods
.method public final b(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    invoke-static {p2}, Le/b;->p(Ljava/lang/Object;)V

    check-cast p3, LA0/z;

    const/4 p2, 0x1

    const/4 p3, 0x0

    if-eq p1, p2, :cond_12

    const/4 p2, 0x2

    if-eq p1, p2, :cond_11

    const/4 p2, 0x3

    if-eq p1, p2, :cond_10

    return-void

    :cond_10
    throw p3

    :cond_11
    throw p3

    :cond_12
    throw p3
.end method
