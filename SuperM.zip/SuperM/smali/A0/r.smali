.class public final LA0/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LA0/r;->a:I

    iput-object p2, p0, LA0/r;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lr7/O1;Lcom/google/android/gms/measurement/internal/zzok;)V
    .registers 3

    const/16 p2, 0x9

    iput p2, p0, LA0/r;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA0/r;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    iget v0, p0, LA0/r;->a:I

    packed-switch v0, :pswitch_data_290

    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, Lr7/O1;

    invoke-virtual {v0}, Lr7/O1;->V()Lr7/g0;

    move-result-object v1

    invoke-virtual {v1}, Lr7/g0;->x0()V

    new-instance v1, Lr7/Y;

    invoke-direct {v1, v0}, Lr7/Y;-><init>(Lr7/O1;)V

    iput-object v1, v0, Lr7/O1;->k:Lr7/Y;

    new-instance v1, Lr7/g;

    invoke-direct {v1, v0}, Lr7/g;-><init>(Lr7/O1;)V

    invoke-virtual {v1}, Lr7/K1;->C0()V

    iput-object v1, v0, Lr7/O1;->c:Lr7/g;

    invoke-virtual {v0}, Lr7/O1;->M()Lr7/d;

    move-result-object v1

    iget-object v2, v0, Lr7/O1;->a:Lr7/b0;

    invoke-static {v2}, LO6/A;->i(Ljava/lang/Object;)V

    iput-object v2, v1, Lr7/d;->e:Lr7/e;

    new-instance v1, Lr7/C1;

    invoke-direct {v1, v0}, Lr7/C1;-><init>(Lr7/O1;)V

    invoke-virtual {v1}, Lr7/K1;->C0()V

    iput-object v1, v0, Lr7/O1;->i:Lr7/C1;

    new-instance v1, Lr7/W1;

    invoke-direct {v1, v0}, Lr7/K1;-><init>(Lr7/O1;)V

    invoke-virtual {v1}, Lr7/K1;->C0()V

    iput-object v1, v0, Lr7/O1;->f:Lr7/W1;

    new-instance v1, Lr7/j1;

    invoke-direct {v1, v0}, Lr7/K1;-><init>(Lr7/O1;)V

    invoke-virtual {v1}, Lr7/K1;->C0()V

    iput-object v1, v0, Lr7/O1;->h:Lr7/j1;

    new-instance v1, Lr7/J1;

    invoke-direct {v1, v0}, Lr7/J1;-><init>(Lr7/O1;)V

    invoke-virtual {v1}, Lr7/K1;->C0()V

    iput-object v1, v0, Lr7/O1;->e:Lr7/J1;

    new-instance v1, Lr7/Q;

    invoke-direct {v1, v0}, Lr7/Q;-><init>(Lr7/O1;)V

    iput-object v1, v0, Lr7/O1;->d:Lr7/Q;

    iget v1, v0, Lr7/O1;->r:I

    iget v2, v0, Lr7/O1;->s:I

    if-eq v1, v2, :cond_78

    invoke-virtual {v0}, Lr7/O1;->zzj()Lr7/I;

    move-result-object v1

    iget v2, v0, Lr7/O1;->r:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v3, v0, Lr7/O1;->s:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-object v1, v1, Lr7/I;->g:Lr7/K;

    const-string v4, "Not all upload components initialized"

    invoke-virtual {v1, v2, v4, v3}, Lr7/K;->b(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)V

    :cond_78
    const/4 v1, 0x1

    iput-boolean v1, v0, Lr7/O1;->m:Z

    invoke-virtual {v0}, Lr7/O1;->V()Lr7/g0;

    move-result-object v1

    invoke-virtual {v1}, Lr7/g0;->x0()V

    iget-object v1, v0, Lr7/O1;->c:Lr7/g;

    invoke-static {v1}, Lr7/O1;->u(Lr7/K1;)V

    invoke-virtual {v1}, Lr7/g;->K1()V

    iget-object v1, v0, Lr7/O1;->c:Lr7/g;

    invoke-static {v1}, Lr7/O1;->u(Lr7/K1;)V

    invoke-virtual {v1}, LJ1/e;->x0()V

    invoke-virtual {v1}, Lr7/K1;->B0()V

    invoke-virtual {v1}, Lr7/g;->k1()Z

    move-result v2

    const-wide/16 v3, 0x0

    if-eqz v2, :cond_f2

    sget-object v2, Lr7/s;->h0:Lr7/w;

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Lr7/w;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Long;

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    cmp-long v6, v6, v3

    if-nez v6, :cond_af

    goto :goto_f2

    :cond_af
    invoke-virtual {v1}, Lr7/g;->F0()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v6

    iget-object v7, v1, LJ1/e;->b:Ljava/lang/Object;

    check-cast v7, Lr7/j0;

    iget-object v7, v7, Lr7/j0;->n:LV6/c;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v5}, Lr7/w;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v7, v2}, [Ljava/lang/String;

    move-result-object v2

    instance-of v5, v6, Landroid/database/sqlite/SQLiteDatabase;

    const-string v7, "trigger_uris"

    const-string v8, "abs(timestamp_millis - ?) > cast(? as integer)"

    if-nez v5, :cond_dd

    invoke-virtual {v6, v7, v8, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v2

    goto :goto_e1

    :cond_dd
    invoke-static {v6, v7, v8, v2}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->delete(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v2

    :goto_e1
    if-lez v2, :cond_f2

    invoke-virtual {v1}, LJ1/e;->zzj()Lr7/I;

    move-result-object v1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget-object v1, v1, Lr7/I;->o:Lr7/K;

    const-string v5, "Deleted stale trigger uris. rowsDeleted"

    invoke-virtual {v1, v2, v5}, Lr7/K;->a(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_f2
    :goto_f2
    iget-object v1, v0, Lr7/O1;->i:Lr7/C1;

    iget-object v1, v1, Lr7/C1;->i:Lr7/V;

    invoke-virtual {v1}, Lr7/V;->a()J

    move-result-wide v1

    cmp-long v1, v1, v3

    if-nez v1, :cond_112

    iget-object v1, v0, Lr7/O1;->i:Lr7/C1;

    iget-object v1, v1, Lr7/C1;->i:Lr7/V;

    invoke-virtual {v0}, Lr7/O1;->zzb()LV6/b;

    move-result-object v2

    check-cast v2, LV6/c;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lr7/V;->b(J)V

    :cond_112
    invoke-virtual {v0}, Lr7/O1;->B()V

    return-void

    :pswitch_116
    const/4 v0, 0x0

    iget-object v1, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v1, Lr7/k1;

    iput-object v0, v1, Lr7/k1;->k:Lr7/l1;

    return-void

    :pswitch_11e
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, Ljc/D;

    iget-object v0, v0, Ljc/D;->c:Ljc/E;

    const-string v1, "onPostExecuteInner"

    invoke-virtual {v0, v1}, Ljc/E;->k(Ljava/lang/String;)V

    return-void

    :pswitch_12a
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, Lj/I;

    iget-object v1, v0, Lj/I;->b:Landroid/view/Window$Callback;

    invoke-virtual {v0}, Lj/I;->w()Landroidx/appcompat/view/menu/MenuBuilder;

    move-result-object v0

    instance-of v2, v0, Landroidx/appcompat/view/menu/MenuBuilder;

    const/4 v3, 0x0

    if-eqz v2, :cond_13b

    move-object v2, v0

    goto :goto_13c

    :cond_13b
    move-object v2, v3

    :goto_13c
    if-eqz v2, :cond_141

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/MenuBuilder;->y()V

    :cond_141
    :try_start_141
    invoke-interface {v0}, Landroid/view/Menu;->clear()V

    const/4 v4, 0x0

    invoke-interface {v1, v4, v0}, Landroid/view/Window$Callback;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    move-result v5

    if-eqz v5, :cond_154

    invoke-interface {v1, v4, v3, v0}, Landroid/view/Window$Callback;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v1

    if-nez v1, :cond_157

    goto :goto_154

    :catchall_152
    move-exception v0

    goto :goto_15d

    :cond_154
    :goto_154
    invoke-interface {v0}, Landroid/view/Menu;->clear()V
    :try_end_157
    .catchall {:try_start_141 .. :try_end_157} :catchall_152

    :cond_157
    if-eqz v2, :cond_15c

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/MenuBuilder;->x()V

    :cond_15c
    return-void

    :goto_15d
    if-eqz v2, :cond_162

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/MenuBuilder;->x()V

    :cond_162
    throw v0

    :pswitch_163
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, Lorg/json/JSONObject;

    const-string v1, ""

    invoke-static {v1, v0}, Ll7/U4;->a(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ll7/U4;->b(Ljava/lang/String;)V

    return-void

    :pswitch_171
    new-instance v0, Ljava/lang/AssertionError;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unhandled stats message."

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v2, Landroid/os/Message;

    iget v2, v2, Landroid/os/Message;->what:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    :pswitch_18b
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/fragment/app/C;

    invoke-virtual {v0}, Landroidx/fragment/app/C;->startPostponedEnterTransition()V

    return-void

    :pswitch_193
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x80

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    return-void

    :pswitch_1a1
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, LQ2/j;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "Removing command "

    invoke-static {}, LN2/n;->d()LN2/n;

    move-result-object v2

    sget-object v3, LQ2/j;->j:Ljava/lang/String;

    const-string v4, "Checking if commands are complete."

    invoke-virtual {v2, v3, v4}, LN2/n;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, LQ2/j;->b()V

    iget-object v2, v0, LQ2/j;->g:Ljava/util/ArrayList;

    monitor-enter v2

    :try_start_1bb
    iget-object v4, v0, LQ2/j;->h:Landroid/content/Intent;

    if-eqz v4, :cond_1f3

    invoke-static {}, LN2/n;->d()LN2/n;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v0, LQ2/j;->h:Landroid/content/Intent;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v3, v1}, LN2/n;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, v0, LQ2/j;->g:Ljava/util/ArrayList;

    const/4 v4, 0x0

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    iget-object v4, v0, LQ2/j;->h:Landroid/content/Intent;

    invoke-virtual {v1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1eb

    const/4 v1, 0x0

    iput-object v1, v0, LQ2/j;->h:Landroid/content/Intent;

    goto :goto_1f3

    :catchall_1e9
    move-exception v0

    goto :goto_247

    :cond_1eb
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Dequeue-d command is not the first."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1f3
    :goto_1f3
    iget-object v1, v0, LQ2/j;->b:LZ2/a;

    check-cast v1, LAc/f;

    iget-object v1, v1, LAc/f;->b:Ljava/lang/Object;

    check-cast v1, LX2/o;

    iget-object v4, v0, LQ2/j;->f:LQ2/c;

    iget-object v5, v4, LQ2/c;->c:Ljava/lang/Object;

    monitor-enter v5
    :try_end_200
    .catchall {:try_start_1bb .. :try_end_200} :catchall_1e9

    :try_start_200
    iget-object v4, v4, LQ2/c;->b:Ljava/util/HashMap;

    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    move-result v4

    xor-int/lit8 v4, v4, 0x1

    monitor-exit v5
    :try_end_209
    .catchall {:try_start_200 .. :try_end_209} :catchall_244

    if-nez v4, :cond_237

    :try_start_20b
    iget-object v4, v0, LQ2/j;->g:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_237

    iget-object v4, v1, LX2/o;->b:Ljava/lang/Object;

    monitor-enter v4
    :try_end_216
    .catchall {:try_start_20b .. :try_end_216} :catchall_1e9

    :try_start_216
    iget-object v1, v1, LX2/o;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    monitor-exit v4
    :try_end_21f
    .catchall {:try_start_216 .. :try_end_21f} :catchall_234

    if-nez v1, :cond_237

    :try_start_221
    invoke-static {}, LN2/n;->d()LN2/n;

    move-result-object v1

    const-string v4, "No more commands & intents."

    invoke-virtual {v1, v3, v4}, LN2/n;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, v0, LQ2/j;->i:LQ2/i;

    if-eqz v0, :cond_242

    check-cast v0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    invoke-virtual {v0}, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->a()V
    :try_end_233
    .catchall {:try_start_221 .. :try_end_233} :catchall_1e9

    goto :goto_242

    :catchall_234
    move-exception v0

    :try_start_235
    monitor-exit v4
    :try_end_236
    .catchall {:try_start_235 .. :try_end_236} :catchall_234

    :try_start_236
    throw v0

    :cond_237
    iget-object v1, v0, LQ2/j;->g:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_242

    invoke-virtual {v0}, LQ2/j;->c()V

    :cond_242
    :goto_242
    monitor-exit v2
    :try_end_243
    .catchall {:try_start_236 .. :try_end_243} :catchall_1e9

    return-void

    :catchall_244
    move-exception v0

    :try_start_245
    monitor-exit v5
    :try_end_246
    .catchall {:try_start_245 .. :try_end_246} :catchall_244

    :try_start_246
    throw v0

    :goto_247
    monitor-exit v2
    :try_end_248
    .catchall {:try_start_246 .. :try_end_248} :catchall_1e9

    throw v0

    :pswitch_249
    monitor-enter p0

    :try_start_24a
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, LA0/z;

    const/4 v1, 0x0

    iput-boolean v1, v0, LA0/z;->c:Z

    monitor-exit p0
    :try_end_252
    .catchall {:try_start_24a .. :try_end_252} :catchall_28d

    :cond_252
    :goto_252
    sget-object v0, LA0/z;->w:Ljava/lang/ref/ReferenceQueue;

    invoke-virtual {v0}, Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;

    move-result-object v0

    if-eqz v0, :cond_264

    instance-of v1, v0, LA0/A;

    if-eqz v1, :cond_252

    check-cast v0, LA0/A;

    invoke-virtual {v0}, LA0/A;->a()Z

    goto :goto_252

    :cond_264
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, LA0/z;

    iget-object v0, v0, LA0/z;->f:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-nez v0, :cond_285

    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, LA0/z;

    iget-object v0, v0, LA0/z;->f:Landroid/view/View;

    sget-object v1, LA0/z;->x:LA0/q;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, LA0/z;

    iget-object v0, v0, LA0/z;->f:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    goto :goto_28c

    :cond_285
    iget-object v0, p0, LA0/r;->b:Ljava/lang/Object;

    check-cast v0, LA0/z;

    invoke-virtual {v0}, LA0/z;->executePendingBindings()V

    :goto_28c
    return-void

    :catchall_28d
    move-exception v0

    :try_start_28e
    monitor-exit p0
    :try_end_28f
    .catchall {:try_start_28e .. :try_end_28f} :catchall_28d

    throw v0

    :pswitch_data_290
    .packed-switch 0x0
        :pswitch_249
        :pswitch_1a1
        :pswitch_193
        :pswitch_18b
        :pswitch_171
        :pswitch_163
        :pswitch_12a
        :pswitch_11e
        :pswitch_116
    .end packed-switch
.end method
