.class public abstract LA0/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Landroidx/databinding/DataBinderMapperImpl;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/databinding/DataBinderMapperImpl;

    invoke-direct {v0}, Landroidx/databinding/DataBinderMapperImpl;-><init>()V

    sput-object v0, LA0/f;->a:Landroidx/databinding/DataBinderMapperImpl;

    return-void
.end method

.method public static a(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;Z)LA0/z;
    .registers 9

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p2, :cond_8

    if-eqz p3, :cond_8

    move v2, v1

    goto :goto_9

    :cond_8
    move v2, v0

    :goto_9
    if-eqz v2, :cond_10

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    goto :goto_11

    :cond_10
    move v3, v0

    :goto_11
    invoke-virtual {p0, p1, p2, p3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    sget-object p3, LA0/f;->a:Landroidx/databinding/DataBinderMapperImpl;

    const/4 v4, 0x0

    if-eqz v2, :cond_40

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p0

    sub-int v2, p0, v3

    if-ne v2, v1, :cond_2c

    sub-int/2addr p0, v1

    invoke-virtual {p2, p0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    invoke-virtual {p3, v4, p0, p1}, Landroidx/databinding/MergedDataBinderMapper;->getDataBinder(LA0/e;Landroid/view/View;I)LA0/z;

    move-result-object p0

    goto :goto_3f

    :cond_2c
    new-array p0, v2, [Landroid/view/View;

    :goto_2e
    if-ge v0, v2, :cond_3b

    add-int v1, v0, v3

    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    aput-object v1, p0, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2e

    :cond_3b
    invoke-virtual {p3, v4, p0, p1}, Landroidx/databinding/MergedDataBinderMapper;->getDataBinder(LA0/e;[Landroid/view/View;I)LA0/z;

    move-result-object p0

    :goto_3f
    return-object p0

    :cond_40
    invoke-virtual {p3, v4, p0, p1}, Landroidx/databinding/MergedDataBinderMapper;->getDataBinder(LA0/e;Landroid/view/View;I)LA0/z;

    move-result-object p0

    return-object p0
.end method
