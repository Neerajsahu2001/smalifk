.class public final LA0/o;
.super LA0/b;
.source "SourceFile"


# static fields
.field public static final f:LA0/n;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LA0/n;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LA0/o;->f:LA0/n;

    return-void
.end method
