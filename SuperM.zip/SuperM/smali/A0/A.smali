.class public abstract La0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[I

.field public static final b:[I


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    const v0, 0x7f040316

    const v1, 0x7f0404d0

    filled-new-array {v0, v1}, [I

    move-result-object v0

    sput-object v0, La0/a;->a:[I

    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_16

    sput-object v0, La0/a;->b:[I

    return-void

    nop

    :array_16
    .array-data 4
        0x10100b3
        0x7f040322
        0x7f040323
        0x7f040324
        0x7f040355
        0x7f04035f
        0x7f040360
    .end array-data
.end method
