.class public abstract LA0/t;
.super Ljava/lang/Object;
.source "SourceFile"
