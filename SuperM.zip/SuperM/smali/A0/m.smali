.class public abstract LA0/m;
.super Ljava/lang/Object;
.source "SourceFile"
