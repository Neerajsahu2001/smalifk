.class public interface abstract LA0/e;
.super Ljava/lang/Object;
.source "SourceFile"
