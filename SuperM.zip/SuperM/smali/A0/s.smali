.class public final LA0/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/Choreographer$FrameCallback;


# instance fields
.field public final synthetic a:LA0/z;


# direct methods
.method public constructor <init>(LA0/z;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA0/s;->a:LA0/z;

    return-void
.end method


# virtual methods
.method public final doFrame(J)V
    .registers 3

    iget-object p1, p0, LA0/s;->a:LA0/z;

    iget-object p1, p1, LA0/z;->b:LA0/r;

    invoke-virtual {p1}, LA0/r;->run()V

    return-void
.end method
