.class public interface abstract LA0/i;
.super Ljava/lang/Object;
.source "SourceFile"
