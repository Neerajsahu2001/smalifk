.class public abstract LA0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public collectDependencies()Ljava/util/List;
    .registers 2

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public abstract getDataBinder(LA0/e;Landroid/view/View;I)LA0/z;
.end method

.method public abstract getDataBinder(LA0/e;[Landroid/view/View;I)LA0/z;
.end method
