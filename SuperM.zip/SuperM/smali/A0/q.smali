.class public final LA0/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# virtual methods
.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .registers 3

    if-eqz p1, :cond_c

    const v0, 0x7f0a00d7

    invoke-virtual {p1, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LA0/z;

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    iget-object v0, v0, LA0/z;->b:LA0/r;

    invoke-virtual {v0}, LA0/r;->run()V

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method

.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    .registers 2

    return-void
.end method
