.class public final LA0/n;
.super LE/o;
.source "SourceFile"


# virtual methods
.method public final b(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 6

    check-cast p2, LA0/h;

    check-cast p3, LA0/i;

    check-cast p2, LA0/y;

    iget-object p2, p2, LA0/y;->a:LA0/A;

    invoke-virtual {p2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LA0/z;

    if-nez v0, :cond_13

    invoke-virtual {p2}, LA0/A;->a()Z

    :cond_13
    if-nez v0, :cond_16

    goto :goto_22

    :cond_16
    iget-object v1, p2, LA0/A;->c:Ljava/lang/Object;

    check-cast v1, LA0/i;

    if-eq v1, p3, :cond_1d

    goto :goto_22

    :cond_1d
    iget p2, p2, LA0/A;->b:I

    invoke-virtual {v0, p2, p3, p1}, LA0/z;->handleFieldChange(ILjava/lang/Object;I)V

    :goto_22
    return-void
.end method
