.class public final LA0/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA0/l;
.implements LB1/L;
.implements LD/o;
.implements Lr0/t;
.implements LO6/d;
.implements LO6/b;
.implements Ln/k;
.implements LN6/j;
.implements LZb/a;
.implements Landroidx/recyclerview/widget/J0;
.implements Landroidx/core/view/z;
.implements Lcom/bumptech/glide/load/data/g;
.implements Lcom/google/gson/internal/p;
.implements Landroidx/appcompat/widget/S0;
.implements Landroidx/appcompat/widget/w0;


# static fields
.field public static c:LA0/x;

.field public static d:LA0/x;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    iput p1, p0, LA0/x;->a:I

    packed-switch p1, :pswitch_data_22

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    new-instance v0, LD/d;

    invoke-direct {v0, p1}, LD/d;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    return-void

    :pswitch_15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ll1/d;

    const/4 v0, 0x5

    invoke-direct {p1, v0}, Ll1/d;-><init>(I)V

    iput-object p1, p0, LA0/x;->b:Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_22
    .packed-switch 0x18
        :pswitch_15
    .end packed-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LA0/x;->a:I

    iput-object p2, p0, LA0/x;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    iput p1, p0, LA0/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LA0/z;ILjava/lang/ref/ReferenceQueue;)V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, LA0/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LA0/A;

    invoke-direct {v0, p1, p2, p0, p3}, LA0/A;-><init>(LA0/z;ILA0/l;Ljava/lang/ref/ReferenceQueue;)V

    iput-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .registers 4

    const/16 v0, 0xd

    iput v0, p0, LA0/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_17

    new-instance v0, Landroidx/core/view/F;

    invoke-direct {v0, p1}, LF2/D;-><init>(Landroid/view/View;)V

    iput-object p1, v0, Landroidx/core/view/F;->h:Landroid/view/View;

    iput-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    goto :goto_1e

    :cond_17
    new-instance v0, LF2/D;

    invoke-direct {v0, p1}, LF2/D;-><init>(Landroid/view/View;)V

    iput-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    :goto_1e
    return-void
.end method

.method public constructor <init>(Landroid/widget/EditText;)V
    .registers 3

    const/4 v0, 0x5

    iput v0, p0, LA0/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "editText cannot be null"

    invoke-static {p1, v0}, Ll7/C5;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LAa/t;

    invoke-direct {v0, p1}, LAa/t;-><init>(Landroid/widget/EditText;)V

    iput-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lc8/f;)V
    .registers 5

    const/16 v0, 0x10

    iput v0, p0, LA0/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lc8/g;

    invoke-direct {v0, p1}, Lc8/g;-><init>(Lc8/f;)V

    new-instance p1, Lc8/d;

    const/4 v1, 0x1

    invoke-direct {p1, v0, v1}, Lc8/d;-><init>(Lc8/g;I)V

    invoke-static {p1}, Ld8/b;->a(Ld8/c;)Ld8/c;

    move-result-object p1

    new-instance v1, LB5/a;

    const/16 v2, 0xd

    invoke-direct {v1, v2, v0, p1}, LB5/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v1}, Ld8/b;->a(Ld8/c;)Ld8/c;

    move-result-object p1

    new-instance v1, Lc8/d;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Lc8/d;-><init>(Lc8/g;I)V

    invoke-static {v1}, Ld8/b;->a(Ld8/c;)Ld8/c;

    move-result-object v1

    new-instance v2, LD9/f;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object p1, v2, LD9/f;->a:Ljava/lang/Object;

    iput-object v1, v2, LD9/f;->b:Ljava/lang/Object;

    iput-object v0, v2, LD9/f;->c:Ljava/lang/Object;

    invoke-static {v2}, Ld8/b;->a(Ld8/c;)Ld8/c;

    move-result-object p1

    new-instance v0, LM4/a;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, LM4/a;-><init>(Ljava/lang/Object;Z)V

    invoke-static {v0}, Ld8/b;->a(Ld8/c;)Ld8/c;

    move-result-object p1

    iput-object p1, p0, LA0/x;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/zay;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V
    .registers 3

    const/16 p1, 0x9

    iput p1, p0, LA0/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA0/x;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;Lm4/h;)V
    .registers 4

    const/16 v0, 0x11

    iput v0, p0, LA0/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ls4/D;

    invoke-direct {v0, p1, p2}, Ls4/D;-><init>(Ljava/io/InputStream;Lm4/h;)V

    iput-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    const/high16 p1, 0x500000

    invoke-virtual {v0, p1}, Ls4/D;->mark(I)V

    return-void
.end method

.method public static F(Landroid/content/Context;)LA0/x;
    .registers 6

    sget-object v0, LA0/x;->d:LA0/x;

    if-nez v0, :cond_71

    new-instance v0, LA0/x;

    const-string v1, "BranchJsonConfig"

    const/16 v2, 0x17

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3}, LA0/x;-><init>(IZ)V

    const/4 v2, 0x0

    iput-object v2, v0, LA0/x;->b:Ljava/lang/Object;

    :try_start_11
    new-instance v2, Ljava/io/BufferedReader;

    new-instance v3, Ljava/io/InputStreamReader;

    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    const-string v4, "branch.json"

    invoke-virtual {p0, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0

    invoke-direct {v3, p0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_25
    .catch Ljava/io/FileNotFoundException; {:try_start_11 .. :try_end_25} :catch_6f
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_25} :catch_36
    .catch Lorg/json/JSONException; {:try_start_11 .. :try_end_25} :catch_34

    :try_start_25
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    :goto_2a
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_38

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2a

    :catch_34
    move-exception p0

    goto :goto_44

    :catch_36
    move-exception p0

    goto :goto_5a

    :cond_38
    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v2, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object v2, v0, LA0/x;->b:Ljava/lang/Object;
    :try_end_43
    .catch Ljava/io/IOException; {:try_start_25 .. :try_end_43} :catch_36
    .catch Lorg/json/JSONException; {:try_start_25 .. :try_end_43} :catch_34

    goto :goto_6f

    :goto_44
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Error parsing branch.json: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/newrelic/agent/android/instrumentation/LogInstrumentation;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_6f

    :goto_5a
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Error loading branch.json: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/newrelic/agent/android/instrumentation/LogInstrumentation;->e(Ljava/lang/String;Ljava/lang/String;)I

    :catch_6f
    :goto_6f
    sput-object v0, LA0/x;->d:LA0/x;

    :cond_71
    sget-object p0, LA0/x;->d:LA0/x;

    return-object p0
.end method

.method public static M(III)LA0/x;
    .registers 5

    new-instance v0, LA0/x;

    const/4 v1, 0x0

    invoke-static {p0, p1, v1, p2}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;->obtain(IIZI)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;

    move-result-object p0

    const/16 p1, 0x1d

    invoke-direct {v0, p1, p0}, LA0/x;-><init>(ILjava/lang/Object;)V

    return-object v0
.end method

.method private final O(Landroidx/appcompat/view/menu/MenuBuilder;)V
    .registers 2

    return-void
.end method

.method public static P()I
    .registers 5

    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    const/4 v1, 0x4

    new-array v1, v1, [B

    const/4 v2, 0x0

    move v3, v2

    :goto_a
    if-nez v3, :cond_2c

    invoke-virtual {v0, v1}, Ljava/security/SecureRandom;->nextBytes([B)V

    aget-byte v3, v1, v2

    and-int/lit8 v3, v3, 0x7f

    shl-int/lit8 v3, v3, 0x18

    const/4 v4, 0x1

    aget-byte v4, v1, v4

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x10

    or-int/2addr v3, v4

    const/4 v4, 0x2

    aget-byte v4, v1, v4

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x8

    or-int/2addr v3, v4

    const/4 v4, 0x3

    aget-byte v4, v1, v4

    and-int/lit16 v4, v4, 0xff

    or-int/2addr v3, v4

    goto :goto_a

    :cond_2c
    return v3
.end method


# virtual methods
.method public A(Landroidx/appcompat/view/menu/MenuBuilder;Ln/n;)V
    .registers 10

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Ln/g;

    iget-object v1, v0, Ln/g;->g:Landroid/os/Handler;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v1, v0, Ln/g;->i:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x0

    :goto_11
    const/4 v5, -0x1

    if-ge v4, v3, :cond_22

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ln/f;

    iget-object v6, v6, Ln/f;->b:Landroidx/appcompat/view/menu/MenuBuilder;

    if-ne p1, v6, :cond_1f

    goto :goto_23

    :cond_1f
    add-int/lit8 v4, v4, 0x1

    goto :goto_11

    :cond_22
    move v4, v5

    :goto_23
    if-ne v4, v5, :cond_26

    return-void

    :cond_26
    add-int/lit8 v4, v4, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v4, v3, :cond_35

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ln/f;

    :cond_35
    new-instance v1, Ll7/m7;

    invoke-direct {v1, p0, v2, p2, p1}, Ll7/m7;-><init>(LA0/x;Ln/f;Ln/n;Landroidx/appcompat/view/menu/MenuBuilder;)V

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    const-wide/16 v4, 0xc8

    add-long/2addr v2, v4

    iget-object p2, v0, Ln/g;->g:Landroid/os/Handler;

    invoke-virtual {p2, v1, p1, v2, v3}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;Ljava/lang/Object;J)Z

    return-void
.end method

.method public B()V
    .registers 2

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lcom/yalantis/ucrop/UCropActivity;

    iget-object v0, v0, Lcom/yalantis/ucrop/UCropActivity;->b1:Lcom/yalantis/ucrop/view/GestureCropImageView;

    invoke-virtual {v0}, Lcom/yalantis/ucrop/view/CropImageView;->k()V

    return-void
.end method

.method public C(Landroidx/appcompat/view/menu/MenuBuilder;)V
    .registers 6

    iget v0, p0, LA0/x;->a:I

    packed-switch v0, :pswitch_data_28

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lj/I;

    iget-object v1, v0, Lj/I;->a:Landroidx/appcompat/widget/k1;

    iget-object v1, v1, Landroidx/appcompat/widget/k1;->a:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->r()Z

    move-result v1

    iget-object v0, v0, Lj/I;->b:Landroid/view/Window$Callback;

    const/16 v2, 0x6c

    if-eqz v1, :cond_1b

    invoke-interface {v0, v2, p1}, Landroid/view/Window$Callback;->onPanelClosed(ILandroid/view/Menu;)V

    goto :goto_26

    :cond_1b
    const/4 v1, 0x0

    const/4 v3, 0x0

    invoke-interface {v0, v1, v3, p1}, Landroid/view/Window$Callback;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v1

    if-eqz v1, :cond_26

    invoke-interface {v0, v2, p1}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    :cond_26
    :goto_26
    :pswitch_26
    return-void

    nop

    :pswitch_data_28
    .packed-switch 0x8
        :pswitch_26
    .end packed-switch
.end method

.method public E(IILD1/o;)V
    .registers 23

    move/from16 v0, p1

    move/from16 v1, p2

    move-object/from16 v2, p3

    move-object/from16 v3, p0

    iget-object v4, v3, LA0/x;->b:Ljava/lang/Object;

    check-cast v4, LV1/d;

    iget-object v5, v4, LV1/d;->c:Landroid/util/SparseArray;

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x1

    const/16 v8, 0xa1

    const/16 v9, 0xa3

    const/4 v10, 0x0

    if-eq v0, v8, :cond_ee

    if-eq v0, v9, :cond_ee

    const/16 v8, 0xa5

    if-eq v0, v8, :cond_c1

    const/16 v5, 0x41ed

    if-eq v0, v5, :cond_a1

    const/16 v5, 0x4255

    if-eq v0, v5, :cond_93

    const/16 v5, 0x47e2

    if-eq v0, v5, :cond_80

    const/16 v5, 0x53ab

    if-eq v0, v5, :cond_66

    const/16 v5, 0x63a2

    if-eq v0, v5, :cond_58

    const/16 v5, 0x7672

    if-ne v0, v5, :cond_45

    invoke-virtual {v4, v0}, LV1/d;->e(I)V

    iget-object v0, v4, LV1/d;->w:LV1/c;

    new-array v4, v1, [B

    iput-object v4, v0, LV1/c;->w:[B

    invoke-virtual {v2, v4, v12, v1, v12}, LD1/o;->b([BIIZ)Z

    goto/16 :goto_307

    :cond_45
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unexpected id: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v10, v0}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object v0

    throw v0

    :cond_58
    invoke-virtual {v4, v0}, LV1/d;->e(I)V

    iget-object v0, v4, LV1/d;->w:LV1/c;

    new-array v4, v1, [B

    iput-object v4, v0, LV1/c;->k:[B

    invoke-virtual {v2, v4, v12, v1, v12}, LD1/o;->b([BIIZ)Z

    goto/16 :goto_307

    :cond_66
    iget-object v0, v4, LV1/d;->k:LZ0/w;

    iget-object v5, v0, LZ0/w;->a:[B

    invoke-static {v5, v12}, Ljava/util/Arrays;->fill([BB)V

    iget-object v5, v0, LZ0/w;->a:[B

    rsub-int/lit8 v6, v1, 0x4

    invoke-virtual {v2, v5, v6, v1, v12}, LD1/o;->b([BIIZ)Z

    invoke-virtual {v0, v12}, LZ0/w;->G(I)V

    invoke-virtual {v0}, LZ0/w;->w()J

    move-result-wide v0

    long-to-int v0, v0

    iput v0, v4, LV1/d;->y:I

    goto/16 :goto_307

    :cond_80
    new-array v5, v1, [B

    invoke-virtual {v2, v5, v12, v1, v12}, LD1/o;->b([BIIZ)Z

    invoke-virtual {v4, v0}, LV1/d;->e(I)V

    iget-object v0, v4, LV1/d;->w:LV1/c;

    new-instance v1, LD1/O;

    invoke-direct {v1, v13, v5, v12, v12}, LD1/O;-><init>(I[BII)V

    iput-object v1, v0, LV1/c;->j:LD1/O;

    goto/16 :goto_307

    :cond_93
    invoke-virtual {v4, v0}, LV1/d;->e(I)V

    iget-object v0, v4, LV1/d;->w:LV1/c;

    new-array v4, v1, [B

    iput-object v4, v0, LV1/c;->i:[B

    invoke-virtual {v2, v4, v12, v1, v12}, LD1/o;->b([BIIZ)Z

    goto/16 :goto_307

    :cond_a1
    invoke-virtual {v4, v0}, LV1/d;->e(I)V

    iget-object v0, v4, LV1/d;->w:LV1/c;

    iget v4, v0, LV1/c;->g:I

    const v5, 0x64767643

    if-eq v4, v5, :cond_b8

    const v5, 0x64766343

    if-ne v4, v5, :cond_b3

    goto :goto_b8

    :cond_b3
    invoke-virtual {v2, v1}, LD1/o;->i(I)V

    goto/16 :goto_307

    :cond_b8
    :goto_b8
    new-array v4, v1, [B

    iput-object v4, v0, LV1/c;->O:[B

    invoke-virtual {v2, v4, v12, v1, v12}, LD1/o;->b([BIIZ)Z

    goto/16 :goto_307

    :cond_c1
    iget v0, v4, LV1/d;->I:I

    if-eq v0, v7, :cond_c7

    goto/16 :goto_307

    :cond_c7
    iget v0, v4, LV1/d;->O:I

    invoke-virtual {v5, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LV1/c;

    iget v5, v4, LV1/d;->R:I

    if-ne v5, v6, :cond_e9

    const-string v5, "V_VP9"

    iget-object v0, v0, LV1/c;->b:Ljava/lang/String;

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e9

    iget-object v0, v4, LV1/d;->p:LZ0/w;

    invoke-virtual {v0, v1}, LZ0/w;->D(I)V

    iget-object v0, v0, LZ0/w;->a:[B

    invoke-virtual {v2, v0, v12, v1, v12}, LD1/o;->b([BIIZ)Z

    goto/16 :goto_307

    :cond_e9
    invoke-virtual {v2, v1}, LD1/o;->i(I)V

    goto/16 :goto_307

    :cond_ee
    iget v8, v4, LV1/d;->I:I

    const/16 v11, 0x8

    iget-object v14, v4, LV1/d;->i:LZ0/w;

    if-nez v8, :cond_10f

    iget-object v8, v4, LV1/d;->b:LV1/e;

    invoke-virtual {v8, v2, v12, v13, v11}, LV1/e;->c(LD1/o;ZZI)J

    move-result-wide v9

    long-to-int v9, v9

    iput v9, v4, LV1/d;->O:I

    iget v8, v8, LV1/e;->c:I

    iput v8, v4, LV1/d;->P:I

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v8, v4, LV1/d;->K:J

    iput v13, v4, LV1/d;->I:I

    invoke-virtual {v14, v12}, LZ0/w;->D(I)V

    :cond_10f
    iget v8, v4, LV1/d;->O:I

    invoke-virtual {v5, v8}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    move-object v10, v5

    check-cast v10, LV1/c;

    if-nez v10, :cond_125

    iget v0, v4, LV1/d;->P:I

    sub-int v0, v1, v0

    invoke-virtual {v2, v0}, LD1/o;->i(I)V

    iput v12, v4, LV1/d;->I:I

    goto/16 :goto_307

    :cond_125
    iget-object v5, v10, LV1/c;->Y:LD1/P;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v5, v4, LV1/d;->I:I

    if-ne v5, v13, :cond_2bc

    const/4 v5, 0x3

    invoke-virtual {v4, v2, v5}, LV1/d;->l(LD1/o;I)V

    iget-object v8, v14, LZ0/w;->a:[B

    aget-byte v8, v8, v7

    and-int/lit8 v8, v8, 0x6

    shr-int/2addr v8, v13

    const/16 v9, 0xff

    if-nez v8, :cond_15e

    iput v13, v4, LV1/d;->M:I

    iget-object v6, v4, LV1/d;->N:[I

    if-nez v6, :cond_146

    new-array v6, v13, [I

    goto :goto_152

    :cond_146
    array-length v8, v6

    if-lt v8, v13, :cond_14a

    goto :goto_152

    :cond_14a
    array-length v6, v6

    mul-int/2addr v6, v7

    invoke-static {v6, v13}, Ljava/lang/Math;->max(II)I

    move-result v6

    new-array v6, v6, [I

    :goto_152
    iput-object v6, v4, LV1/d;->N:[I

    iget v8, v4, LV1/d;->P:I

    sub-int/2addr v1, v8

    sub-int/2addr v1, v5

    aput v1, v6, v12

    :goto_15a
    move-object/from16 v18, v10

    goto/16 :goto_26c

    :cond_15e
    invoke-virtual {v4, v2, v6}, LV1/d;->l(LD1/o;I)V

    iget-object v15, v14, LZ0/w;->a:[B

    aget-byte v15, v15, v5

    and-int/2addr v15, v9

    add-int/2addr v15, v13

    iput v15, v4, LV1/d;->M:I

    iget-object v11, v4, LV1/d;->N:[I

    if-nez v11, :cond_170

    new-array v11, v15, [I

    goto :goto_17c

    :cond_170
    array-length v5, v11

    if-lt v5, v15, :cond_174

    goto :goto_17c

    :cond_174
    array-length v5, v11

    mul-int/2addr v5, v7

    invoke-static {v5, v15}, Ljava/lang/Math;->max(II)I

    move-result v5

    new-array v11, v5, [I

    :goto_17c
    iput-object v11, v4, LV1/d;->N:[I

    if-ne v8, v7, :cond_18b

    iget v5, v4, LV1/d;->P:I

    sub-int/2addr v1, v5

    sub-int/2addr v1, v6

    iget v5, v4, LV1/d;->M:I

    div-int/2addr v1, v5

    invoke-static {v11, v12, v5, v1}, Ljava/util/Arrays;->fill([IIII)V

    goto :goto_15a

    :cond_18b
    if-ne v8, v13, :cond_1be

    move v5, v12

    move v8, v5

    :goto_18f
    iget v11, v4, LV1/d;->M:I

    sub-int/2addr v11, v13

    if-ge v5, v11, :cond_1b4

    iget-object v11, v4, LV1/d;->N:[I

    aput v12, v11, v5

    :goto_198
    add-int/lit8 v11, v6, 0x1

    invoke-virtual {v4, v2, v11}, LV1/d;->l(LD1/o;I)V

    iget-object v15, v14, LZ0/w;->a:[B

    aget-byte v6, v15, v6

    and-int/2addr v6, v9

    iget-object v15, v4, LV1/d;->N:[I

    aget v16, v15, v5

    add-int v16, v16, v6

    aput v16, v15, v5

    if-eq v6, v9, :cond_1b2

    add-int v8, v8, v16

    add-int/lit8 v5, v5, 0x1

    move v6, v11

    goto :goto_18f

    :cond_1b2
    move v6, v11

    goto :goto_198

    :cond_1b4
    iget-object v5, v4, LV1/d;->N:[I

    iget v15, v4, LV1/d;->P:I

    sub-int/2addr v1, v15

    sub-int/2addr v1, v6

    sub-int/2addr v1, v8

    aput v1, v5, v11

    goto :goto_15a

    :cond_1be
    const/4 v5, 0x3

    if-ne v8, v5, :cond_2a8

    move v5, v12

    move v8, v5

    :goto_1c3
    iget v11, v4, LV1/d;->M:I

    sub-int/2addr v11, v13

    if-ge v5, v11, :cond_261

    iget-object v11, v4, LV1/d;->N:[I

    aput v12, v11, v5

    add-int/lit8 v11, v6, 0x1

    invoke-virtual {v4, v2, v11}, LV1/d;->l(LD1/o;I)V

    iget-object v15, v14, LZ0/w;->a:[B

    aget-byte v15, v15, v6

    if-eqz v15, :cond_259

    move v7, v12

    :goto_1d8
    const/16 v15, 0x8

    if-ge v7, v15, :cond_225

    rsub-int/lit8 v15, v7, 0x7

    shl-int v15, v13, v15

    iget-object v13, v14, LZ0/w;->a:[B

    aget-byte v13, v13, v6

    and-int/2addr v13, v15

    if-eqz v13, :cond_21c

    add-int v13, v11, v7

    invoke-virtual {v4, v2, v13}, LV1/d;->l(LD1/o;I)V

    iget-object v12, v14, LZ0/w;->a:[B

    aget-byte v6, v12, v6

    and-int/2addr v6, v9

    not-int v12, v15

    and-int/2addr v6, v12

    move-object v12, v10

    int-to-long v9, v6

    :goto_1f5
    if-ge v11, v13, :cond_20c

    const/16 v6, 0x8

    shl-long/2addr v9, v6

    iget-object v6, v14, LZ0/w;->a:[B

    add-int/lit8 v17, v11, 0x1

    aget-byte v6, v6, v11

    const/16 v11, 0xff

    and-int/2addr v6, v11

    move-object/from16 v18, v12

    int-to-long v11, v6

    or-long/2addr v9, v11

    move/from16 v11, v17

    move-object/from16 v12, v18

    goto :goto_1f5

    :cond_20c
    move-object/from16 v18, v12

    if-lez v5, :cond_21a

    mul-int/lit8 v7, v7, 0x7

    add-int/lit8 v7, v7, 0x6

    const-wide/16 v11, 0x1

    shl-long v6, v11, v7

    sub-long/2addr v6, v11

    sub-long/2addr v9, v6

    :cond_21a
    move v6, v13

    goto :goto_22a

    :cond_21c
    move-object/from16 v18, v10

    add-int/lit8 v7, v7, 0x1

    const/16 v9, 0xff

    const/4 v12, 0x0

    const/4 v13, 0x1

    goto :goto_1d8

    :cond_225
    move-object/from16 v18, v10

    const-wide/16 v9, 0x0

    move v6, v11

    :goto_22a
    const-wide/32 v11, -0x80000000

    cmp-long v7, v9, v11

    if-ltz v7, :cond_251

    const-wide/32 v11, 0x7fffffff

    cmp-long v7, v9, v11

    if-gtz v7, :cond_251

    long-to-int v7, v9

    iget-object v9, v4, LV1/d;->N:[I

    if-nez v5, :cond_23e

    goto :goto_243

    :cond_23e
    add-int/lit8 v10, v5, -0x1

    aget v10, v9, v10

    add-int/2addr v7, v10

    :goto_243
    aput v7, v9, v5

    add-int/2addr v8, v7

    add-int/lit8 v5, v5, 0x1

    move-object/from16 v10, v18

    const/4 v7, 0x2

    const/16 v9, 0xff

    const/4 v12, 0x0

    const/4 v13, 0x1

    goto/16 :goto_1c3

    :cond_251
    const-string v0, "EBML lacing sample size out of range."

    const/4 v1, 0x0

    invoke-static {v1, v0}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object v0

    throw v0

    :cond_259
    const/4 v1, 0x0

    const-string v0, "No valid varint length mask found"

    invoke-static {v1, v0}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object v0

    throw v0

    :cond_261
    move-object/from16 v18, v10

    iget-object v5, v4, LV1/d;->N:[I

    iget v7, v4, LV1/d;->P:I

    sub-int/2addr v1, v7

    sub-int/2addr v1, v6

    sub-int/2addr v1, v8

    aput v1, v5, v11

    :goto_26c
    iget-object v1, v14, LZ0/w;->a:[B

    const/4 v5, 0x0

    aget-byte v6, v1, v5

    const/16 v5, 0x8

    shl-int/lit8 v5, v6, 0x8

    const/4 v6, 0x1

    aget-byte v1, v1, v6

    const/16 v6, 0xff

    and-int/2addr v1, v6

    or-int/2addr v1, v5

    iget-wide v5, v4, LV1/d;->D:J

    int-to-long v7, v1

    invoke-virtual {v4, v7, v8}, LV1/d;->n(J)J

    move-result-wide v7

    add-long/2addr v7, v5

    iput-wide v7, v4, LV1/d;->J:J

    move-object/from16 v1, v18

    iget v5, v1, LV1/c;->d:I

    const/4 v6, 0x2

    if-eq v5, v6, :cond_29d

    const/16 v5, 0xa3

    if-ne v0, v5, :cond_29b

    iget-object v5, v14, LZ0/w;->a:[B

    aget-byte v5, v5, v6

    const/16 v7, 0x80

    and-int/2addr v5, v7

    if-ne v5, v7, :cond_29b

    goto :goto_29d

    :cond_29b
    const/4 v5, 0x0

    goto :goto_29e

    :cond_29d
    :goto_29d
    const/4 v5, 0x1

    :goto_29e
    iput v5, v4, LV1/d;->Q:I

    iput v6, v4, LV1/d;->I:I

    const/4 v5, 0x0

    iput v5, v4, LV1/d;->L:I

    :goto_2a5
    const/16 v5, 0xa3

    goto :goto_2be

    :cond_2a8
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Unexpected lacing value: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object v0

    throw v0

    :cond_2bc
    move-object v1, v10

    goto :goto_2a5

    :goto_2be
    if-ne v0, v5, :cond_2ef

    :goto_2c0
    iget v0, v4, LV1/d;->L:I

    iget v5, v4, LV1/d;->M:I

    if-ge v0, v5, :cond_2eb

    iget-object v5, v4, LV1/d;->N:[I

    aget v0, v5, v0

    const/4 v5, 0x0

    invoke-virtual {v4, v2, v1, v0, v5}, LV1/d;->o(LD1/o;LV1/c;IZ)I

    move-result v10

    iget-wide v5, v4, LV1/d;->J:J

    iget v0, v4, LV1/d;->L:I

    iget v7, v1, LV1/c;->e:I

    mul-int/2addr v0, v7

    div-int/lit16 v0, v0, 0x3e8

    int-to-long v7, v0

    add-long/2addr v7, v5

    iget v9, v4, LV1/d;->Q:I

    const/4 v11, 0x0

    move-object v5, v4

    move-object v6, v1

    move-object v0, v1

    invoke-virtual/range {v5 .. v11}, LV1/d;->g(LV1/c;JIII)V

    iget v1, v4, LV1/d;->L:I

    const/4 v5, 0x1

    add-int/2addr v1, v5

    iput v1, v4, LV1/d;->L:I

    move-object v1, v0

    goto :goto_2c0

    :cond_2eb
    const/4 v1, 0x0

    iput v1, v4, LV1/d;->I:I

    goto :goto_307

    :cond_2ef
    move-object v0, v1

    const/4 v5, 0x1

    :goto_2f1
    iget v1, v4, LV1/d;->L:I

    iget v6, v4, LV1/d;->M:I

    if-ge v1, v6, :cond_307

    iget-object v6, v4, LV1/d;->N:[I

    aget v7, v6, v1

    invoke-virtual {v4, v2, v0, v7, v5}, LV1/d;->o(LD1/o;LV1/c;IZ)I

    move-result v7

    aput v7, v6, v1

    iget v1, v4, LV1/d;->L:I

    add-int/2addr v1, v5

    iput v1, v4, LV1/d;->L:I

    goto :goto_2f1

    :cond_307
    :goto_307
    return-void
.end method

.method public declared-synchronized G()LA/a;
    .registers 4

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lx8/G0;

    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/v;->a()Lcom/google/crypto/tink/shaded/protobuf/x;

    move-result-object v0

    check-cast v0, Lx8/J0;

    invoke-virtual {v0}, Lx8/J0;->p()I

    move-result v1

    if-lez v1, :cond_1a

    new-instance v1, LA/a;

    const/16 v2, 0x1a

    invoke-direct {v1, v2, v0}, LA/a;-><init>(ILjava/lang/Object;)V
    :try_end_18
    .catchall {:try_start_1 .. :try_end_18} :catchall_22

    monitor-exit p0

    return-object v1

    :cond_1a
    :try_start_1a
    new-instance v0, Ljava/security/GeneralSecurityException;

    const-string v1, "empty keyset"

    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_22
    .catchall {:try_start_1a .. :try_end_22} :catchall_22

    :catchall_22
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public H()Ljava/lang/Boolean;
    .registers 4

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, LA0/x;->J(I)Z

    move-result v0

    if-nez v0, :cond_9

    const/4 v0, 0x0

    return-object v0

    :cond_9
    :try_start_9
    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lorg/json/JSONObject;

    const-string v1, "useTestInstance"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0
    :try_end_17
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_17} :catch_18

    return-object v0

    :catch_18
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Error parsing branch.json: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "BranchJsonConfig"

    invoke-static {v1, v0}, Lcom/newrelic/agent/android/instrumentation/LogInstrumentation;->e(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object v0
.end method

.method public I(IJ)V
    .registers 13

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, LV1/d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x5031

    const/4 v2, 0x0

    const-string v3, " not supported"

    if-eq p1, v1, :cond_25e

    const/16 v1, 0x5032

    const-wide/16 v4, 0x1

    if-eq p1, v1, :cond_243

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    sparse-switch p1, :sswitch_data_27c

    const/4 v1, -0x1

    packed-switch p1, :pswitch_data_302

    goto/16 :goto_264

    :pswitch_21
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->D:I

    goto/16 :goto_264

    :pswitch_2b
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->C:I

    goto/16 :goto_264

    :pswitch_35
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput-boolean v8, p1, LV1/c;->y:Z

    long-to-int p1, p2

    invoke-static {p1}, LW0/j;->f(I)I

    move-result p1

    if-eq p1, v1, :cond_264

    iget-object p2, v0, LV1/d;->w:LV1/c;

    iput p1, p2, LV1/c;->z:I

    goto/16 :goto_264

    :pswitch_49
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    long-to-int p1, p2

    invoke-static {p1}, LW0/j;->g(I)I

    move-result p1

    if-eq p1, v1, :cond_264

    iget-object p2, v0, LV1/d;->w:LV1/c;

    iput p1, p2, LV1/c;->A:I

    goto/16 :goto_264

    :pswitch_59
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    long-to-int p1, p2

    if-eq p1, v8, :cond_69

    if-eq p1, v7, :cond_63

    goto/16 :goto_264

    :cond_63
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v8, p1, LV1/c;->B:I

    goto/16 :goto_264

    :cond_69
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v7, p1, LV1/c;->B:I

    goto/16 :goto_264

    :sswitch_6f
    iput-wide p2, v0, LV1/d;->t:J

    goto/16 :goto_264

    :sswitch_73
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->e:I

    goto/16 :goto_264

    :sswitch_7d
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    long-to-int p1, p2

    if-eqz p1, :cond_9d

    if-eq p1, v8, :cond_97

    if-eq p1, v7, :cond_91

    if-eq p1, v6, :cond_8b

    goto/16 :goto_264

    :cond_8b
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v6, p1, LV1/c;->s:I

    goto/16 :goto_264

    :cond_91
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v7, p1, LV1/c;->s:I

    goto/16 :goto_264

    :cond_97
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v8, p1, LV1/c;->s:I

    goto/16 :goto_264

    :cond_9d
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v1, p1, LV1/c;->s:I

    goto/16 :goto_264

    :sswitch_a3
    iput-wide p2, v0, LV1/d;->T:J

    goto/16 :goto_264

    :sswitch_a7
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->Q:I

    goto/16 :goto_264

    :sswitch_b1
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput-wide p2, p1, LV1/c;->T:J

    goto/16 :goto_264

    :sswitch_ba
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput-wide p2, p1, LV1/c;->S:J

    goto/16 :goto_264

    :sswitch_c3
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->f:I

    goto/16 :goto_264

    :sswitch_cd
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput-boolean v8, p1, LV1/c;->y:Z

    long-to-int p2, p2

    iput p2, p1, LV1/c;->o:I

    goto/16 :goto_264

    :sswitch_d9
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    cmp-long p2, p2, v4

    if-nez p2, :cond_e3

    move v1, v8

    :cond_e3
    iput-boolean v1, p1, LV1/c;->V:Z

    goto/16 :goto_264

    :sswitch_e7
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->q:I

    goto/16 :goto_264

    :sswitch_f1
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->r:I

    goto/16 :goto_264

    :sswitch_fb
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->p:I

    goto/16 :goto_264

    :sswitch_105
    long-to-int p2, p2

    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    if-eqz p2, :cond_127

    if-eq p2, v8, :cond_121

    if-eq p2, v6, :cond_11b

    const/16 p1, 0xf

    if-eq p2, p1, :cond_115

    goto/16 :goto_264

    :cond_115
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v6, p1, LV1/c;->x:I

    goto/16 :goto_264

    :cond_11b
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v8, p1, LV1/c;->x:I

    goto/16 :goto_264

    :cond_121
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v7, p1, LV1/c;->x:I

    goto/16 :goto_264

    :cond_127
    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput v1, p1, LV1/c;->x:I

    goto/16 :goto_264

    :sswitch_12d
    iget-wide v1, v0, LV1/d;->s:J

    add-long/2addr p2, v1

    iput-wide p2, v0, LV1/d;->z:J

    goto/16 :goto_264

    :sswitch_134
    cmp-long p1, p2, v4

    if-nez p1, :cond_13a

    goto/16 :goto_264

    :cond_13a
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "AESSettingsCipherMode "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    :sswitch_150
    const-wide/16 v0, 0x5

    cmp-long p1, p2, v0

    if-nez p1, :cond_158

    goto/16 :goto_264

    :cond_158
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "ContentEncAlgo "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    :sswitch_16e
    cmp-long p1, p2, v4

    if-nez p1, :cond_174

    goto/16 :goto_264

    :cond_174
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "EBMLReadVersion "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    :sswitch_18a
    cmp-long p1, p2, v4

    if-ltz p1, :cond_196

    const-wide/16 v0, 0x2

    cmp-long p1, p2, v0

    if-gtz p1, :cond_196

    goto/16 :goto_264

    :cond_196
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "DocTypeReadVersion "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    :sswitch_1ac
    const-wide/16 v0, 0x3

    cmp-long p1, p2, v0

    if-nez p1, :cond_1b4

    goto/16 :goto_264

    :cond_1b4
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "ContentCompAlgo "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    :sswitch_1ca
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->g:I

    goto/16 :goto_264

    :sswitch_1d4
    iput-boolean v8, v0, LV1/d;->S:Z

    goto/16 :goto_264

    :sswitch_1d8
    iget-boolean v1, v0, LV1/d;->G:Z

    if-nez v1, :cond_264

    invoke-virtual {v0, p1}, LV1/d;->b(I)V

    iget-object p1, v0, LV1/d;->F:LZ0/q;

    invoke-virtual {p1, p2, p3}, LZ0/q;->c(J)V

    iput-boolean v8, v0, LV1/d;->G:Z

    goto/16 :goto_264

    :sswitch_1e8
    long-to-int p1, p2

    iput p1, v0, LV1/d;->R:I

    goto/16 :goto_264

    :sswitch_1ed
    invoke-virtual {v0, p2, p3}, LV1/d;->n(J)J

    move-result-wide p1

    iput-wide p1, v0, LV1/d;->D:J

    goto/16 :goto_264

    :sswitch_1f5
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->c:I

    goto :goto_264

    :sswitch_1fe
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->n:I

    goto :goto_264

    :sswitch_207
    invoke-virtual {v0, p1}, LV1/d;->b(I)V

    iget-object p1, v0, LV1/d;->E:LZ0/q;

    invoke-virtual {v0, p2, p3}, LV1/d;->n(J)J

    move-result-wide p2

    invoke-virtual {p1, p2, p3}, LZ0/q;->c(J)V

    goto :goto_264

    :sswitch_214
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->m:I

    goto :goto_264

    :sswitch_21d
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->P:I

    goto :goto_264

    :sswitch_226
    invoke-virtual {v0, p2, p3}, LV1/d;->n(J)J

    move-result-wide p1

    iput-wide p1, v0, LV1/d;->K:J

    goto :goto_264

    :sswitch_22d
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    cmp-long p2, p2, v4

    if-nez p2, :cond_237

    move v1, v8

    :cond_237
    iput-boolean v1, p1, LV1/c;->W:Z

    goto :goto_264

    :sswitch_23a
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    long-to-int p2, p2

    iput p2, p1, LV1/c;->d:I

    goto :goto_264

    :cond_243
    cmp-long p1, p2, v4

    if-nez p1, :cond_248

    goto :goto_264

    :cond_248
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "ContentEncodingScope "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    :cond_25e
    const-wide/16 v0, 0x0

    cmp-long p1, p2, v0

    if-nez p1, :cond_265

    :cond_264
    :goto_264
    return-void

    :cond_265
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "ContentEncodingOrder "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    nop

    :sswitch_data_27c
    .sparse-switch
        0x83 -> :sswitch_23a
        0x88 -> :sswitch_22d
        0x9b -> :sswitch_226
        0x9f -> :sswitch_21d
        0xb0 -> :sswitch_214
        0xb3 -> :sswitch_207
        0xba -> :sswitch_1fe
        0xd7 -> :sswitch_1f5
        0xe7 -> :sswitch_1ed
        0xee -> :sswitch_1e8
        0xf1 -> :sswitch_1d8
        0xfb -> :sswitch_1d4
        0x41e7 -> :sswitch_1ca
        0x4254 -> :sswitch_1ac
        0x4285 -> :sswitch_18a
        0x42f7 -> :sswitch_16e
        0x47e1 -> :sswitch_150
        0x47e8 -> :sswitch_134
        0x53ac -> :sswitch_12d
        0x53b8 -> :sswitch_105
        0x54b0 -> :sswitch_fb
        0x54b2 -> :sswitch_f1
        0x54ba -> :sswitch_e7
        0x55aa -> :sswitch_d9
        0x55b2 -> :sswitch_cd
        0x55ee -> :sswitch_c3
        0x56aa -> :sswitch_ba
        0x56bb -> :sswitch_b1
        0x6264 -> :sswitch_a7
        0x75a2 -> :sswitch_a3
        0x7671 -> :sswitch_7d
        0x23e383 -> :sswitch_73
        0x2ad7b1 -> :sswitch_6f
    .end sparse-switch

    :pswitch_data_302
    .packed-switch 0x55b9
        :pswitch_59
        :pswitch_49
        :pswitch_35
        :pswitch_2b
        :pswitch_21
    .end packed-switch
.end method

.method public J(I)Z
    .registers 3

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lorg/json/JSONObject;

    if-eqz v0, :cond_2d

    packed-switch p1, :pswitch_data_30

    const/4 p1, 0x0

    throw p1

    :pswitch_b
    const-string p1, "cppLevel"

    goto :goto_25

    :pswitch_e
    const-string p1, "fbAppId"

    goto :goto_25

    :pswitch_11
    const-string p1, "apiUrl"

    goto :goto_25

    :pswitch_14
    const-string p1, "deferInitForPluginRuntime"

    goto :goto_25

    :pswitch_17
    const-string p1, "enableLogging"

    goto :goto_25

    :pswitch_1a
    const-string p1, "useTestInstance"

    goto :goto_25

    :pswitch_1d
    const-string p1, "liveKey"

    goto :goto_25

    :pswitch_20
    const-string p1, "testKey"

    goto :goto_25

    :pswitch_23
    const-string p1, "branchKey"

    :goto_25
    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_2d

    const/4 p1, 0x1

    goto :goto_2e

    :cond_2d
    const/4 p1, 0x0

    :goto_2e
    return p1

    nop

    :pswitch_data_30
    .packed-switch 0x1
        :pswitch_23
        :pswitch_20
        :pswitch_1d
        :pswitch_1a
        :pswitch_17
        :pswitch_14
        :pswitch_11
        :pswitch_e
        :pswitch_b
    .end packed-switch
.end method

.method public declared-synchronized K(I)Z
    .registers 4

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lx8/G0;

    iget-object v0, v0, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast v0, Lx8/J0;

    invoke-virtual {v0}, Lx8/J0;->q()Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_15
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lx8/I0;

    invoke-virtual {v1}, Lx8/I0;->r()I

    move-result v1
    :try_end_25
    .catchall {:try_start_1 .. :try_end_25} :catchall_2a

    if-ne v1, p1, :cond_15

    monitor-exit p0

    const/4 p1, 0x1

    return p1

    :catchall_2a
    move-exception p1

    goto :goto_2f

    :cond_2c
    monitor-exit p0

    const/4 p1, 0x0

    return p1

    :goto_2f
    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized L(Lx8/E0;)Lx8/I0;
    .registers 6

    monitor-enter p0

    :try_start_1
    invoke-static {p1}, Lp8/s;->f(Lx8/E0;)Lx8/B0;

    move-result-object v0

    monitor-enter p0
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_23

    :try_start_6
    invoke-static {}, LA0/x;->P()I

    move-result v1

    :goto_a
    invoke-virtual {p0, v1}, LA0/x;->K(I)Z

    move-result v2

    if-eqz v2, :cond_17

    invoke-static {}, LA0/x;->P()I

    move-result v1
    :try_end_14
    .catchall {:try_start_6 .. :try_end_14} :catchall_15

    goto :goto_a

    :catchall_15
    move-exception p1

    goto :goto_59

    :cond_17
    :try_start_17
    monitor-exit p0

    invoke-virtual {p1}, Lx8/E0;->q()Lx8/U0;

    move-result-object p1

    sget-object v2, Lx8/U0;->b:Lx8/U0;

    if-ne p1, v2, :cond_25

    sget-object p1, Lx8/U0;->c:Lx8/U0;

    goto :goto_25

    :catchall_23
    move-exception p1

    goto :goto_5b

    :cond_25
    :goto_25
    invoke-static {}, Lx8/I0;->v()Lx8/H0;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/v;->c()V

    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast v3, Lx8/I0;

    invoke-static {v3, v0}, Lx8/I0;->m(Lx8/I0;Lx8/B0;)V

    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/v;->c()V

    iget-object v0, v2, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast v0, Lx8/I0;

    invoke-static {v0, v1}, Lx8/I0;->p(Lx8/I0;I)V

    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/v;->c()V

    iget-object v0, v2, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast v0, Lx8/I0;

    invoke-static {v0}, Lx8/I0;->o(Lx8/I0;)V

    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/v;->c()V

    iget-object v0, v2, Lcom/google/crypto/tink/shaded/protobuf/v;->b:Lcom/google/crypto/tink/shaded/protobuf/x;

    check-cast v0, Lx8/I0;

    invoke-static {v0, p1}, Lx8/I0;->n(Lx8/I0;Lx8/U0;)V

    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/v;->a()Lcom/google/crypto/tink/shaded/protobuf/x;

    move-result-object p1

    check-cast p1, Lx8/I0;
    :try_end_57
    .catchall {:try_start_17 .. :try_end_57} :catchall_23

    monitor-exit p0

    return-object p1

    :goto_59
    :try_start_59
    monitor-exit p0

    throw p1
    :try_end_5b
    .catchall {:try_start_59 .. :try_end_5b} :catchall_23

    :goto_5b
    monitor-exit p0

    throw p1
.end method

.method public N()V
    .registers 5

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Li1/e;

    sget-object v1, LA1/c;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_7
    sget-boolean v2, LA1/c;->c:Z

    if-eqz v2, :cond_10

    sget-wide v2, LA1/c;->d:J

    goto :goto_15

    :catchall_e
    move-exception v0

    goto :goto_1d

    :cond_10
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    :goto_15
    monitor-exit v1
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_e

    iput-wide v2, v0, Li1/e;->M:J

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Li1/e;->A(Z)V

    return-void

    :goto_1d
    :try_start_1d
    monitor-exit v1
    :try_end_1e
    .catchall {:try_start_1d .. :try_end_1e} :catchall_e

    throw v0
.end method

.method public Q(IJJ)V
    .registers 14

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, LV1/d;

    iget-object v1, v0, LV1/d;->d0:LD1/y;

    invoke-static {v1}, Lm7/u;->g(Ljava/lang/Object;)V

    const/16 v1, 0xa0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    if-eq p1, v1, :cond_f5

    const/16 v1, 0xae

    const/4 v5, -0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eq p1, v1, :cond_9c

    const/16 v1, 0xbb

    if-eq p1, v1, :cond_99

    const/16 v1, 0x4dbb

    const-wide/16 v2, -0x1

    if-eq p1, v1, :cond_94

    const/16 v1, 0x5035

    if-eq p1, v1, :cond_8c

    const/16 v1, 0x55d0

    if-eq p1, v1, :cond_84

    const v1, 0x18538067

    if-eq p1, v1, :cond_6c

    const p2, 0x1c53bb6b

    if-eq p1, p2, :cond_5c

    const p2, 0x1f43b675

    if-eq p1, p2, :cond_3a

    goto/16 :goto_f9

    :cond_3a
    iget-boolean p1, v0, LV1/d;->x:Z

    if-nez p1, :cond_f9

    iget-boolean p1, v0, LV1/d;->d:Z

    if-eqz p1, :cond_4c

    iget-wide p1, v0, LV1/d;->B:J

    cmp-long p1, p1, v2

    if-eqz p1, :cond_4c

    iput-boolean v7, v0, LV1/d;->A:Z

    goto/16 :goto_f9

    :cond_4c
    iget-object p1, v0, LV1/d;->d0:LD1/y;

    new-instance p2, LD1/B;

    iget-wide p3, v0, LV1/d;->v:J

    invoke-direct {p2, p3, p4}, LD1/B;-><init>(J)V

    invoke-interface {p1, p2}, LD1/y;->o(LD1/J;)V

    iput-boolean v7, v0, LV1/d;->x:Z

    goto/16 :goto_f9

    :cond_5c
    new-instance p1, LZ0/q;

    invoke-direct {p1}, LZ0/q;-><init>()V

    iput-object p1, v0, LV1/d;->E:LZ0/q;

    new-instance p1, LZ0/q;

    invoke-direct {p1}, LZ0/q;-><init>()V

    iput-object p1, v0, LV1/d;->F:LZ0/q;

    goto/16 :goto_f9

    :cond_6c
    iget-wide v4, v0, LV1/d;->s:J

    cmp-long p1, v4, v2

    if-eqz p1, :cond_7e

    cmp-long p1, v4, p2

    if-nez p1, :cond_77

    goto :goto_7e

    :cond_77
    const-string p1, "Multiple Segment elements not supported"

    invoke-static {v6, p1}, LW0/J;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)LW0/J;

    move-result-object p1

    throw p1

    :cond_7e
    :goto_7e
    iput-wide p2, v0, LV1/d;->s:J

    iput-wide p4, v0, LV1/d;->r:J

    goto/16 :goto_f9

    :cond_84
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput-boolean v7, p1, LV1/c;->y:Z

    goto :goto_f9

    :cond_8c
    invoke-virtual {v0, p1}, LV1/d;->e(I)V

    iget-object p1, v0, LV1/d;->w:LV1/c;

    iput-boolean v7, p1, LV1/c;->h:Z

    goto :goto_f9

    :cond_94
    iput v5, v0, LV1/d;->y:I

    iput-wide v2, v0, LV1/d;->z:J

    goto :goto_f9

    :cond_99
    iput-boolean v4, v0, LV1/d;->G:Z

    goto :goto_f9

    :cond_9c
    new-instance p1, LV1/c;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput v5, p1, LV1/c;->m:I

    iput v5, p1, LV1/c;->n:I

    iput v5, p1, LV1/c;->o:I

    iput v5, p1, LV1/c;->p:I

    iput v5, p1, LV1/c;->q:I

    iput v4, p1, LV1/c;->r:I

    iput v5, p1, LV1/c;->s:I

    const/4 p2, 0x0

    iput p2, p1, LV1/c;->t:F

    iput p2, p1, LV1/c;->u:F

    iput p2, p1, LV1/c;->v:F

    iput-object v6, p1, LV1/c;->w:[B

    iput v5, p1, LV1/c;->x:I

    iput-boolean v4, p1, LV1/c;->y:Z

    iput v5, p1, LV1/c;->z:I

    iput v5, p1, LV1/c;->A:I

    iput v5, p1, LV1/c;->B:I

    const/16 p2, 0x3e8

    iput p2, p1, LV1/c;->C:I

    const/16 p2, 0xc8

    iput p2, p1, LV1/c;->D:I

    const/high16 p2, -0x40800000    # -1.0f

    iput p2, p1, LV1/c;->E:F

    iput p2, p1, LV1/c;->F:F

    iput p2, p1, LV1/c;->G:F

    iput p2, p1, LV1/c;->H:F

    iput p2, p1, LV1/c;->I:F

    iput p2, p1, LV1/c;->J:F

    iput p2, p1, LV1/c;->K:F

    iput p2, p1, LV1/c;->L:F

    iput p2, p1, LV1/c;->M:F

    iput p2, p1, LV1/c;->N:F

    iput v7, p1, LV1/c;->P:I

    iput v5, p1, LV1/c;->Q:I

    const/16 p2, 0x1f40

    iput p2, p1, LV1/c;->R:I

    iput-wide v2, p1, LV1/c;->S:J

    iput-wide v2, p1, LV1/c;->T:J

    iput-boolean v7, p1, LV1/c;->W:Z

    const-string p2, "eng"

    iput-object p2, p1, LV1/c;->X:Ljava/lang/String;

    iput-object p1, v0, LV1/d;->w:LV1/c;

    goto :goto_f9

    :cond_f5
    iput-boolean v4, v0, LV1/d;->S:Z

    iput-wide v2, v0, LV1/d;->T:J

    :cond_f9
    :goto_f9
    return-void
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    check-cast p1, LT6/g;

    check-cast p2, Lv7/j;

    new-instance v0, LT6/f;

    invoke-direct {v0, p2}, LT6/f;-><init>(Lv7/j;)V

    invoke-virtual {p1}, LO6/e;->t()Landroid/os/IInterface;

    move-result-object p1

    check-cast p1, LT6/d;

    invoke-virtual {p1}, Lcom/google/android/gms/internal/measurement/M;->c()Landroid/os/Parcel;

    move-result-object p2

    invoke-static {p2, v0}, Lf7/a;->d(Landroid/os/Parcel;Landroid/os/IInterface;)V

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    invoke-static {p2, v0}, Lf7/a;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    const/4 v0, 0x2

    invoke-virtual {p1, p2, v0}, Lcom/google/android/gms/internal/measurement/M;->H(Landroid/os/Parcel;I)V

    return-void
.end method

.method public c(I)V
    .registers 3

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, LM6/g;

    invoke-interface {v0, p1}, LM6/g;->c(I)V

    return-void
.end method

.method public construct()Ljava/lang/Object;
    .registers 7

    const-string v0, "\' with no args"

    const-string v1, "Failed to invoke constructor \'"

    iget-object v2, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v2, Ljava/lang/reflect/Constructor;

    const/4 v3, 0x0

    :try_start_9
    invoke-virtual {v2, v3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_d
    .catch Ljava/lang/InstantiationException; {:try_start_9 .. :try_end_d} :catch_37
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_9 .. :try_end_d} :catch_19
    .catch Ljava/lang/IllegalAccessException; {:try_start_9 .. :try_end_d} :catch_e

    return-object v0

    :catch_e
    move-exception v0

    sget-object v1, LI8/c;->a:Ll7/O4;

    new-instance v1, Ljava/lang/RuntimeException;

    const-string v2, "Unexpected IllegalAccessException occurred (Gson 2.10.1). Certain ReflectionAccessFilter features require Java >= 9 to work correctly. If you are not using ReflectionAccessFilter, report this to the Gson maintainers."

    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :catch_19
    move-exception v3

    new-instance v4, Ljava/lang/RuntimeException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v2}, LI8/c;->b(Ljava/lang/reflect/Constructor;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    invoke-direct {v4, v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v4

    :catch_37
    move-exception v3

    new-instance v4, Ljava/lang/RuntimeException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v2}, LI8/c;->b(Ljava/lang/reflect/Constructor;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v4, v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v4
.end method

.method public i()V
    .registers 2

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Ls4/D;

    invoke-virtual {v0}, Ls4/D;->f()V

    return-void
.end method

.method public k(Lcom/google/android/gms/common/ConnectionResult;)V
    .registers 4

    iget v0, p1, Lcom/google/android/gms/common/ConnectionResult;->b:I

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    iget-object v1, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v1, LO6/e;

    if-eqz v0, :cond_16

    invoke-virtual {v1}, LO6/e;->s()Ljava/util/Set;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {v1, v0, p1}, LO6/e;->i(LO6/i;Ljava/util/Set;)V

    return-void

    :cond_16
    iget-object v0, v1, LO6/e;->p:LO6/c;

    if-eqz v0, :cond_1d

    invoke-interface {v0, p1}, LO6/c;->b(Lcom/google/android/gms/common/ConnectionResult;)V

    :cond_1d
    return-void
.end method

.method public l(Landroid/view/View;)Z
    .registers 4

    check-cast p1, Landroidx/viewpager2/widget/ViewPager2;

    iget p1, p1, Landroidx/viewpager2/widget/ViewPager2;->d:I

    const/4 v0, 0x1

    sub-int/2addr p1, v0

    iget-object v1, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v1, LAc/f;

    invoke-virtual {v1, p1}, LAc/f;->E(I)V

    return v0
.end method

.method public m()V
    .registers 3

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lcom/yalantis/ucrop/UCropActivity;

    iget-object v0, v0, Lcom/yalantis/ucrop/UCropActivity;->b1:Lcom/yalantis/ucrop/view/GestureCropImageView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/yalantis/ucrop/view/CropImageView;->n(Z)V

    return-void
.end method

.method public n()V
    .registers 8

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, LB1/q;

    iget-object v1, v0, LB1/q;->L1:Landroid/view/Surface;

    invoke-static {v1}, Lm7/u;->g(Ljava/lang/Object;)V

    iget-object v1, v0, LB1/q;->L1:Landroid/view/Surface;

    iget-object v2, v0, LB1/q;->A1:LW2/p;

    iget-object v3, v2, LW2/p;->b:Ljava/lang/Object;

    check-cast v3, Landroid/os/Handler;

    if-eqz v3, :cond_1f

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    new-instance v6, LB1/E;

    invoke-direct {v6, v2, v1, v4, v5}, LB1/E;-><init>(LW2/p;Ljava/lang/Object;J)V

    invoke-virtual {v3, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1f
    const/4 v1, 0x1

    iput-boolean v1, v0, LB1/q;->O1:Z

    return-void
.end method

.method public o(Landroidx/appcompat/view/menu/MenuBuilder;Ln/n;)V
    .registers 3

    iget-object p2, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast p2, Ln/g;

    iget-object p2, p2, Ln/g;->g:Landroid/os/Handler;

    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    return-void
.end method

.method public onConnected()V
    .registers 2

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, LM6/g;

    invoke-interface {v0}, LM6/g;->onConnected()V

    return-void
.end method

.method public onQueryTextChange(Ljava/lang/String;)Z
    .registers 6

    new-instance v0, LWa/a;

    iget-object v1, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v1, Lcom/swmansion/rnscreens/S;

    iget v2, v1, Lcom/swmansion/rnscreens/S;->m:I

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v3

    invoke-direct {v0, v2, v3, p1}, LWa/a;-><init>(IILjava/lang/String;)V

    invoke-virtual {v1, v0}, Lcom/swmansion/rnscreens/S;->d(Lcom/facebook/react/uimanager/events/Event;)V

    const/4 p1, 0x1

    return p1
.end method

.method public onQueryTextSubmit(Ljava/lang/String;)Z
    .registers 7

    new-instance v0, LL4/a;

    iget-object v1, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v1, Lcom/swmansion/rnscreens/S;

    iget v2, v1, Lcom/swmansion/rnscreens/S;->m:I

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v3

    const/4 v4, 0x1

    invoke-direct {v0, p1, v2, v3, v4}, LL4/a;-><init>(Ljava/lang/Object;III)V

    invoke-virtual {v1, v0}, Lcom/swmansion/rnscreens/S;->d(Lcom/facebook/react/uimanager/events/Event;)V

    const/4 p1, 0x1

    return p1
.end method

.method public p()LD/B;
    .registers 2

    sget-object v0, LD/c0;->c:LD/c0;

    return-object v0
.end method

.method public r()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Ls4/D;

    invoke-virtual {v0}, Ls4/D;->reset()V

    return-object v0
.end method

.method public s(Landroidx/appcompat/view/menu/MenuBuilder;Landroid/view/MenuItem;)Z
    .registers 3

    const/4 p1, 0x0

    iget p2, p0, LA0/x;->a:I

    packed-switch p2, :pswitch_data_14

    return p1

    :pswitch_7
    sget p2, Lcom/google/android/material/navigation/NavigationBarView;->f:I

    iget-object p2, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast p2, Lcom/google/android/material/navigation/NavigationBarView;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return p1

    :pswitch_data_14
    .packed-switch 0x8
        :pswitch_7
    .end packed-switch
.end method

.method public t(Landroidx/lifecycle/y;)V
    .registers 2

    return-void
.end method

.method public u(F)V
    .registers 6

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Lcom/yalantis/ucrop/UCropActivity;

    iget-object v0, v0, Lcom/yalantis/ucrop/UCropActivity;->b1:Lcom/yalantis/ucrop/view/GestureCropImageView;

    const/high16 v1, 0x42280000    # 42.0f

    div-float/2addr p1, v1

    iget-object v1, v0, Lcom/yalantis/ucrop/view/CropImageView;->s:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    const/4 v3, 0x0

    cmpl-float v3, p1, v3

    if-eqz v3, :cond_45

    iget-object v3, v0, Lcom/yalantis/ucrop/view/TransformImageView;->g:Landroid/graphics/Matrix;

    invoke-virtual {v3, p1, v2, v1}, Landroid/graphics/Matrix;->postRotate(FFF)Z

    invoke-virtual {v0, v3}, Lcom/yalantis/ucrop/view/TransformImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    iget-object p1, v0, Lcom/yalantis/ucrop/view/TransformImageView;->j:LO8/c;

    if-eqz p1, :cond_45

    invoke-virtual {v0, v3}, Lcom/yalantis/ucrop/view/TransformImageView;->a(Landroid/graphics/Matrix;)F

    move-result v0

    iget-object p1, p1, LO8/c;->b:Ljava/lang/Object;

    check-cast p1, Lcom/yalantis/ucrop/UCropActivity;

    iget-object p1, p1, Lcom/yalantis/ucrop/UCropActivity;->k1:Landroid/widget/TextView;

    if-eqz p1, :cond_45

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v2, "%.1f\u00b0"

    invoke-static {v1, v2, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_45
    return-void
.end method

.method public v()V
    .registers 4

    const/4 v0, 0x1

    iget-object v1, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v1, LB1/q;

    const/4 v2, 0x0

    invoke-virtual {v1, v2, v0}, LB1/q;->L0(II)V

    return-void
.end method

.method public x(Landroid/view/View;Landroidx/core/view/Q0;)Landroidx/core/view/Q0;
    .registers 9

    const/4 p1, 0x1

    iget-object v0, p0, LA0/x;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m:Landroidx/core/view/Q0;

    invoke-static {v1, p2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    iput-object p2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m:Landroidx/core/view/Q0;

    invoke-virtual {p2}, Landroidx/core/view/Q0;->d()I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_18

    move v1, p1

    goto :goto_19

    :cond_18
    move v1, v2

    :goto_19
    iput-boolean v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Z

    if-nez v1, :cond_25

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-nez v1, :cond_25

    move v1, p1

    goto :goto_26

    :cond_25
    move v1, v2

    :goto_26
    invoke-virtual {v0, v1}, Landroid/view/View;->setWillNotDraw(Z)V

    iget-object v1, p2, Landroidx/core/view/Q0;->a:Landroidx/core/view/O0;

    invoke-virtual {v1}, Landroidx/core/view/O0;->m()Z

    move-result v3

    if-eqz v3, :cond_32

    goto :goto_57

    :cond_32
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    :goto_36
    if-ge v2, v3, :cond_57

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    sget-object v5, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    invoke-virtual {v4}, Landroid/view/View;->getFitsSystemWindows()Z

    move-result v5

    if-eqz v5, :cond_55

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroidx/coordinatorlayout/widget/c;

    iget-object v4, v4, Landroidx/coordinatorlayout/widget/c;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$Behavior;

    if-eqz v4, :cond_55

    invoke-virtual {v1}, Landroidx/core/view/O0;->m()Z

    move-result v4

    if-eqz v4, :cond_55

    goto :goto_57

    :cond_55
    add-int/2addr v2, p1

    goto :goto_36

    :cond_57
    :goto_57
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    :cond_5a
    return-object p2
.end method

.method public y(Ljava/lang/Object;)V
    .registers 2

    invoke-static {p1}, Le/b;->p(Ljava/lang/Object;)V

    const/4 p1, 0x0

    throw p1
.end method

.method public z(Ljava/lang/Object;)V
    .registers 2

    invoke-static {p1}, Le/b;->p(Ljava/lang/Object;)V

    const/4 p1, 0x0

    throw p1
.end method
