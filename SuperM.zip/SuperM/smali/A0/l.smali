.class public interface abstract LA0/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract t(Landroidx/lifecycle/y;)V
.end method

.method public abstract y(Ljava/lang/Object;)V
.end method

.method public abstract z(Ljava/lang/Object;)V
.end method
