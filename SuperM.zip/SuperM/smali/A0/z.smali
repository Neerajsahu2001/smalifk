.class public abstract LA0/z;
.super LA0/a;
.source "SourceFile"


# static fields
.field public static final p:I

.field public static final q:Z = true

.field public static final r:LQ8/a;

.field public static final s:LQ4/a;

.field public static final t:Ll7/z7;

.field public static final u:LP8/b;

.field public static final v:LA0/p;

.field public static final w:Ljava/lang/ref/ReferenceQueue;

.field public static final x:LA0/q;


# instance fields
.field public final b:LA0/r;

.field public c:Z

.field public d:Z

.field public final e:[LA0/A;

.field public final f:Landroid/view/View;

.field public g:LA0/b;

.field public h:Z

.field public final i:Landroid/view/Choreographer;

.field public final j:LA0/s;

.field public final k:Landroid/os/Handler;

.field public l:LA0/z;

.field public m:Landroidx/lifecycle/y;

.field public n:LA0/v;

.field public o:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    sput v0, LA0/z;->p:I

    new-instance v0, LQ8/a;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, LQ8/a;-><init>(I)V

    sput-object v0, LA0/z;->r:LQ8/a;

    new-instance v0, LQ4/a;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, LQ4/a;-><init>(I)V

    sput-object v0, LA0/z;->s:LQ4/a;

    new-instance v0, Ll7/z7;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ll7/z7;-><init>(I)V

    sput-object v0, LA0/z;->t:Ll7/z7;

    new-instance v0, LP8/b;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, LP8/b;-><init>(I)V

    sput-object v0, LA0/z;->u:LP8/b;

    new-instance v0, LA0/p;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LA0/z;->v:LA0/p;

    new-instance v0, Ljava/lang/ref/ReferenceQueue;

    invoke-direct {v0}, Ljava/lang/ref/ReferenceQueue;-><init>()V

    sput-object v0, LA0/z;->w:Ljava/lang/ref/ReferenceQueue;

    new-instance v0, LA0/q;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LA0/z;->x:LA0/q;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;Landroid/view/View;I)V
    .registers 5

    if-nez p1, :cond_47

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, LA0/r;

    const/4 v0, 0x0

    invoke-direct {p1, v0, p0}, LA0/r;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LA0/z;->b:LA0/r;

    const/4 p1, 0x0

    iput-boolean p1, p0, LA0/z;->c:Z

    iput-boolean p1, p0, LA0/z;->d:Z

    new-array p1, p3, [LA0/A;

    iput-object p1, p0, LA0/z;->e:[LA0/A;

    iput-object p2, p0, LA0/z;->f:Landroid/view/View;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p1

    if-eqz p1, :cond_3f

    sget-boolean p1, LA0/z;->q:Z

    if-eqz p1, :cond_30

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object p1

    iput-object p1, p0, LA0/z;->i:Landroid/view/Choreographer;

    new-instance p1, LA0/s;

    invoke-direct {p1, p0}, LA0/s;-><init>(LA0/z;)V

    iput-object p1, p0, LA0/z;->j:LA0/s;

    goto :goto_3e

    :cond_30
    const/4 p1, 0x0

    iput-object p1, p0, LA0/z;->j:LA0/s;

    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, LA0/z;->k:Landroid/os/Handler;

    :goto_3e
    return-void

    :cond_3f
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "DataBinding must be created in view\'s UI Thread"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_47
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static b(Landroid/view/View;[Ljava/lang/Object;Landroid/util/SparseIntArray;Z)V
    .registers 9

    const/4 v0, 0x0

    if-eqz p0, :cond_d

    const v1, 0x7f0a00d7

    invoke-virtual {p0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LA0/z;

    goto :goto_e

    :cond_d
    move-object v1, v0

    :goto_e
    if-eqz v1, :cond_11

    return-void

    :cond_11
    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Ljava/lang/String;

    if-eqz v2, :cond_1c

    move-object v0, v1

    check-cast v0, Ljava/lang/String;

    :cond_1c
    const/4 v1, 0x0

    if-eqz p3, :cond_65

    if-eqz v0, :cond_65

    const-string p3, "layout"

    invoke-virtual {v0, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    if-eqz p3, :cond_65

    const/16 p3, 0x5f

    invoke-virtual {v0, p3}, Ljava/lang/String;->lastIndexOf(I)I

    move-result p3

    if-lez p3, :cond_8b

    add-int/lit8 p3, p3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-ne v2, p3, :cond_3a

    goto :goto_8b

    :cond_3a
    move v3, p3

    :goto_3b
    if-ge v3, v2, :cond_4b

    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Ljava/lang/Character;->isDigit(C)Z

    move-result v4

    if-nez v4, :cond_48

    goto :goto_8b

    :cond_48
    add-int/lit8 v3, v3, 0x1

    goto :goto_3b

    :cond_4b
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    move v3, v1

    :goto_50
    if-ge p3, v2, :cond_5e

    mul-int/lit8 v3, v3, 0xa

    invoke-virtual {v0, p3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    add-int/lit8 v4, v4, -0x30

    add-int/2addr v3, v4

    add-int/lit8 p3, p3, 0x1

    goto :goto_50

    :cond_5e
    aget-object p3, p1, v3

    if-nez p3, :cond_a0

    aput-object p0, p1, v3

    goto :goto_a0

    :cond_65
    if-eqz v0, :cond_8b

    const-string p3, "binding_"

    invoke-virtual {v0, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    if-eqz p3, :cond_8b

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result p3

    const/16 v2, 0x8

    move v3, v1

    :goto_76
    if-ge v2, p3, :cond_84

    mul-int/lit8 v3, v3, 0xa

    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v4

    add-int/lit8 v4, v4, -0x30

    add-int/2addr v3, v4

    add-int/lit8 v2, v2, 0x1

    goto :goto_76

    :cond_84
    aget-object p3, p1, v3

    if-nez p3, :cond_a0

    aput-object p0, p1, v3

    goto :goto_a0

    :cond_8b
    :goto_8b
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result p3

    if-lez p3, :cond_a0

    if-eqz p2, :cond_a0

    const/4 v0, -0x1

    invoke-virtual {p2, p3, v0}, Landroid/util/SparseIntArray;->get(II)I

    move-result p3

    if-ltz p3, :cond_a0

    aget-object v0, p1, p3

    if-nez v0, :cond_a0

    aput-object p0, p1, p3

    :cond_a0
    :goto_a0
    instance-of p3, p0, Landroid/view/ViewGroup;

    if-eqz p3, :cond_b7

    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p3

    move v0, v1

    :goto_ab
    if-ge v0, p3, :cond_b7

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-static {v2, p1, p2, v1}, LA0/z;->b(Landroid/view/View;[Ljava/lang/Object;Landroid/util/SparseIntArray;Z)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_ab

    :cond_b7
    return-void
.end method

.method public static bind(Ljava/lang/Object;Landroid/view/View;I)LA0/z;
    .registers 4

    if-nez p0, :cond_a

    sget-object p0, LA0/f;->a:Landroidx/databinding/DataBinderMapperImpl;

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1, p2}, Landroidx/databinding/MergedDataBinderMapper;->getDataBinder(LA0/e;Landroid/view/View;I)LA0/z;

    move-result-object p0

    return-object p0

    :cond_a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static executeBindingsOn(LA0/z;)V
    .registers 1

    invoke-virtual {p0}, LA0/z;->a()V

    return-void
.end method

.method public static getBuildSdkInt()I
    .registers 1

    sget v0, LA0/z;->p:I

    return v0
.end method

.method public static getColorFromResource(Landroid/view/View;I)I
    .registers 2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p0

    return p0
.end method

.method public static getColorStateListFromResource(Landroid/view/View;I)Landroid/content/res/ColorStateList;
    .registers 2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object p0

    return-object p0
.end method

.method public static getDrawableFromResource(Landroid/view/View;I)Landroid/graphics/drawable/Drawable;
    .registers 2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public static getFrom(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Map<",
            "TK;TT;>;TK;)TT;"
        }
    .end annotation

    if-nez p0, :cond_4

    const/4 p0, 0x0

    return-object p0

    :cond_4
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static getFromArray([BI)B
    .registers 3

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget-byte p0, p0, p1

    return p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return p0
.end method

.method public static getFromArray([CI)C
    .registers 3

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget-char p0, p0, p1

    return p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return p0
.end method

.method public static getFromArray([DI)D
    .registers 4

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget-wide v0, p0, p1

    return-wide v0

    :cond_b
    :goto_b
    const-wide/16 p0, 0x0

    return-wide p0
.end method

.method public static getFromArray([FI)F
    .registers 3

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget p0, p0, p1

    return p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return p0
.end method

.method public static getFromArray([II)I
    .registers 3

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget p0, p0, p1

    return p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return p0
.end method

.method public static getFromArray([JI)J
    .registers 4

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget-wide v0, p0, p1

    return-wide v0

    :cond_b
    :goto_b
    const-wide/16 p0, 0x0

    return-wide p0
.end method

.method public static getFromArray([Ljava/lang/Object;I)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;I)TT;"
        }
    .end annotation

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget-object p0, p0, p1

    return-object p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getFromArray([SI)S
    .registers 3

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget-short p0, p0, p1

    return p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return p0
.end method

.method public static getFromArray([ZI)Z
    .registers 3

    if-eqz p0, :cond_b

    if-ltz p1, :cond_b

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_b

    :cond_8
    aget-boolean p0, p0, p1

    return p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return p0
.end method

.method public static getFromList(Landroid/util/SparseIntArray;I)I
    .registers 2

    if-eqz p0, :cond_a

    if-gez p1, :cond_5

    goto :goto_a

    :cond_5
    invoke-virtual {p0, p1}, Landroid/util/SparseIntArray;->get(I)I

    move-result p0

    return p0

    :cond_a
    :goto_a
    const/4 p0, 0x0

    return p0
.end method

.method public static getFromList(Landroid/util/SparseLongArray;I)J
    .registers 2
    .annotation build Landroid/annotation/TargetApi;
        value = 0x12
    .end annotation

    if-eqz p0, :cond_a

    if-gez p1, :cond_5

    goto :goto_a

    :cond_5
    invoke-virtual {p0, p1}, Landroid/util/SparseLongArray;->get(I)J

    move-result-wide p0

    return-wide p0

    :cond_a
    :goto_a
    const-wide/16 p0, 0x0

    return-wide p0
.end method

.method public static getFromList(LQ/m;I)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LQ/m;",
            "I)TT;"
        }
    .end annotation

    const/4 v0, 0x0

    if-eqz p0, :cond_c

    if-gez p1, :cond_6

    goto :goto_c

    :cond_6
    int-to-long v1, p1

    invoke-virtual {p0, v1, v2, v0}, LQ/m;->d(JLjava/lang/Long;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_c
    :goto_c
    return-object v0
.end method

.method public static getFromList(Landroid/util/LongSparseArray;I)Ljava/lang/Object;
    .registers 4
    .annotation build Landroid/annotation/TargetApi;
        value = 0x10
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/util/LongSparseArray<",
            "TT;>;I)TT;"
        }
    .end annotation

    if-eqz p0, :cond_b

    if-gez p1, :cond_5

    goto :goto_b

    :cond_5
    int-to-long v0, p1

    invoke-virtual {p0, v0, v1}, Landroid/util/LongSparseArray;->get(J)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_b
    :goto_b
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getFromList(Landroid/util/SparseArray;I)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/util/SparseArray<",
            "TT;>;I)TT;"
        }
    .end annotation

    if-eqz p0, :cond_a

    if-gez p1, :cond_5

    goto :goto_a

    :cond_5
    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_a
    :goto_a
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getFromList(Ljava/util/List;I)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "TT;>;I)TT;"
        }
    .end annotation

    if-eqz p0, :cond_10

    if-ltz p1, :cond_10

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_10

    :cond_b
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_10
    :goto_10
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getFromList(Landroid/util/SparseBooleanArray;I)Z
    .registers 2

    if-eqz p0, :cond_a

    if-gez p1, :cond_5

    goto :goto_a

    :cond_5
    invoke-virtual {p0, p1}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result p0

    return p0

    :cond_a
    :goto_a
    const/4 p0, 0x0

    return p0
.end method

.method public static inflateInternal(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;ZLjava/lang/Object;)LA0/z;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "LA0/z;",
            ">(",
            "Landroid/view/LayoutInflater;",
            "I",
            "Landroid/view/ViewGroup;",
            "Z",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    if-nez p4, :cond_7

    invoke-static {p0, p1, p2, p3}, LA0/f;->a(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;Z)LA0/z;

    move-result-object p0

    return-object p0

    :cond_7
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static mapBindings(LA0/e;Landroid/view/View;ILA0/t;Landroid/util/SparseIntArray;)[Ljava/lang/Object;
    .registers 5

    new-array p0, p2, [Ljava/lang/Object;

    const/4 p2, 0x1

    invoke-static {p1, p0, p4, p2}, LA0/z;->b(Landroid/view/View;[Ljava/lang/Object;Landroid/util/SparseIntArray;Z)V

    return-object p0
.end method

.method public static mapBindings(LA0/e;[Landroid/view/View;ILA0/t;Landroid/util/SparseIntArray;)[Ljava/lang/Object;
    .registers 6

    new-array p0, p2, [Ljava/lang/Object;

    const/4 p2, 0x0

    :goto_3
    array-length p3, p1

    if-ge p2, p3, :cond_f

    aget-object p3, p1, p2

    const/4 v0, 0x1

    invoke-static {p3, p0, p4, v0}, LA0/z;->b(Landroid/view/View;[Ljava/lang/Object;Landroid/util/SparseIntArray;Z)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_3

    :cond_f
    return-object p0
.end method

.method public static parse(Ljava/lang/String;B)B
    .registers 2

    :try_start_0
    invoke-static {p0}, Ljava/lang/Byte;->parseByte(Ljava/lang/String;)B

    move-result p0
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_4} :catch_5

    return p0

    :catch_5
    return p1
.end method

.method public static parse(Ljava/lang/String;C)C
    .registers 3

    if-eqz p0, :cond_f

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_f

    :cond_9
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/String;->charAt(I)C

    move-result p0

    return p0

    :cond_f
    :goto_f
    return p1
.end method

.method public static parse(Ljava/lang/String;D)D
    .registers 3

    :try_start_0
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide p0
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_4} :catch_5

    return-wide p0

    :catch_5
    return-wide p1
.end method

.method public static parse(Ljava/lang/String;F)F
    .registers 2

    :try_start_0
    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_4} :catch_5

    return p0

    :catch_5
    return p1
.end method

.method public static parse(Ljava/lang/String;I)I
    .registers 2

    :try_start_0
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_4} :catch_5

    return p0

    :catch_5
    return p1
.end method

.method public static parse(Ljava/lang/String;J)J
    .registers 3

    :try_start_0
    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p0
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_4} :catch_5

    return-wide p0

    :catch_5
    return-wide p1
.end method

.method public static parse(Ljava/lang/String;S)S
    .registers 2

    :try_start_0
    invoke-static {p0}, Ljava/lang/Short;->parseShort(Ljava/lang/String;)S

    move-result p0
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_4} :catch_5

    return p0

    :catch_5
    return p1
.end method

.method public static parse(Ljava/lang/String;Z)Z
    .registers 2

    if-nez p0, :cond_3

    return p1

    :cond_3
    invoke-static {p0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static safeUnbox(Ljava/lang/Byte;)B
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x0

    goto :goto_8

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Byte;->byteValue()B

    move-result p0

    :goto_8
    return p0
.end method

.method public static safeUnbox(Ljava/lang/Character;)C
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x0

    goto :goto_8

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Character;->charValue()C

    move-result p0

    :goto_8
    return p0
.end method

.method public static safeUnbox(Ljava/lang/Double;)D
    .registers 3

    if-nez p0, :cond_5

    const-wide/16 v0, 0x0

    goto :goto_9

    :cond_5
    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    :goto_9
    return-wide v0
.end method

.method public static safeUnbox(Ljava/lang/Float;)F
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x0

    goto :goto_8

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    :goto_8
    return p0
.end method

.method public static safeUnbox(Ljava/lang/Integer;)I
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x0

    goto :goto_8

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    :goto_8
    return p0
.end method

.method public static safeUnbox(Ljava/lang/Long;)J
    .registers 3

    if-nez p0, :cond_5

    const-wide/16 v0, 0x0

    goto :goto_9

    :cond_5
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    :goto_9
    return-wide v0
.end method

.method public static safeUnbox(Ljava/lang/Short;)S
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x0

    goto :goto_8

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Short;->shortValue()S

    move-result p0

    :goto_8
    return p0
.end method

.method public static safeUnbox(Ljava/lang/Boolean;)Z
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x0

    goto :goto_8

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    :goto_8
    return p0
.end method

.method public static setBindingInverseListener(LA0/z;LA0/g;LA0/w;)V
    .registers 3

    if-eq p1, p2, :cond_b

    if-eqz p1, :cond_b

    invoke-static {p1}, Le/b;->p(Ljava/lang/Object;)V

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, LA0/a;->removeOnPropertyChangedCallback(LA0/h;)V

    :cond_b
    return-void
.end method

.method public static setTo(LQ/m;ILjava/lang/Object;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LQ/m;",
            "ITT;)V"
        }
    .end annotation

    if-eqz p0, :cond_f

    if-ltz p1, :cond_f

    invoke-virtual {p0}, LQ/m;->f()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_f

    :cond_b
    int-to-long v0, p1

    invoke-virtual {p0, p2, v0, v1}, LQ/m;->e(Ljava/lang/Object;J)V

    :cond_f
    :goto_f
    return-void
.end method

.method public static setTo(Landroid/util/LongSparseArray;ILjava/lang/Object;)V
    .registers 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x10
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/util/LongSparseArray<",
            "TT;>;ITT;)V"
        }
    .end annotation

    if-eqz p0, :cond_f

    if-ltz p1, :cond_f

    invoke-virtual {p0}, Landroid/util/LongSparseArray;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_f

    :cond_b
    int-to-long v0, p1

    invoke-virtual {p0, v0, v1, p2}, Landroid/util/LongSparseArray;->put(JLjava/lang/Object;)V

    :cond_f
    :goto_f
    return-void
.end method

.method public static setTo(Landroid/util/SparseArray;ILjava/lang/Object;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/util/SparseArray<",
            "TT;>;ITT;)V"
        }
    .end annotation

    if-eqz p0, :cond_e

    if-ltz p1, :cond_e

    invoke-virtual {p0}, Landroid/util/SparseArray;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_e

    :cond_b
    invoke-virtual {p0, p1, p2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_e
    :goto_e
    return-void
.end method

.method public static setTo(Landroid/util/SparseBooleanArray;IZ)V
    .registers 4

    if-eqz p0, :cond_e

    if-ltz p1, :cond_e

    invoke-virtual {p0}, Landroid/util/SparseBooleanArray;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_e

    :cond_b
    invoke-virtual {p0, p1, p2}, Landroid/util/SparseBooleanArray;->put(IZ)V

    :cond_e
    :goto_e
    return-void
.end method

.method public static setTo(Landroid/util/SparseIntArray;II)V
    .registers 4

    if-eqz p0, :cond_e

    if-ltz p1, :cond_e

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_e

    :cond_b
    invoke-virtual {p0, p1, p2}, Landroid/util/SparseIntArray;->put(II)V

    :cond_e
    :goto_e
    return-void
.end method

.method public static setTo(Landroid/util/SparseLongArray;IJ)V
    .registers 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x12
    .end annotation

    if-eqz p0, :cond_e

    if-ltz p1, :cond_e

    invoke-virtual {p0}, Landroid/util/SparseLongArray;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_e

    :cond_b
    invoke-virtual {p0, p1, p2, p3}, Landroid/util/SparseLongArray;->put(IJ)V

    :cond_e
    :goto_e
    return-void
.end method

.method public static setTo(Ljava/util/List;ILjava/lang/Object;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "TT;>;ITT;)V"
        }
    .end annotation

    if-eqz p0, :cond_e

    if-ltz p1, :cond_e

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    goto :goto_e

    :cond_b
    invoke-interface {p0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_e
    :goto_e
    return-void
.end method

.method public static setTo(Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Map<",
            "TK;TT;>;TK;TT;)V"
        }
    .end annotation

    if-nez p0, :cond_3

    return-void

    :cond_3
    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static setTo([BIB)V
    .registers 4

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput-byte p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([CIC)V
    .registers 4

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput-char p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([DID)V
    .registers 5

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput-wide p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([FIF)V
    .registers 4

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([III)V
    .registers 4

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([JIJ)V
    .registers 5

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput-wide p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;ITT;)V"
        }
    .end annotation

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput-object p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([SIS)V
    .registers 4

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput-short p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method

.method public static setTo([ZIZ)V
    .registers 4

    if-eqz p0, :cond_a

    if-ltz p1, :cond_a

    array-length v0, p0

    if-lt p1, v0, :cond_8

    goto :goto_a

    :cond_8
    aput-boolean p2, p0, p1

    :cond_a
    :goto_a
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    iget-boolean v0, p0, LA0/z;->h:Z

    if-eqz v0, :cond_8

    invoke-virtual {p0}, LA0/z;->requestRebind()V

    return-void

    :cond_8
    invoke-virtual {p0}, LA0/z;->hasPendingBindings()Z

    move-result v0

    if-nez v0, :cond_f

    return-void

    :cond_f
    const/4 v0, 0x1

    iput-boolean v0, p0, LA0/z;->h:Z

    const/4 v1, 0x0

    iput-boolean v1, p0, LA0/z;->d:Z

    iget-object v2, p0, LA0/z;->g:LA0/b;

    if-eqz v2, :cond_26

    invoke-virtual {v2, v0, p0}, LA0/b;->d(ILjava/lang/Object;)V

    iget-boolean v0, p0, LA0/z;->d:Z

    if-eqz v0, :cond_26

    iget-object v0, p0, LA0/z;->g:LA0/b;

    const/4 v2, 0x2

    invoke-virtual {v0, v2, p0}, LA0/b;->d(ILjava/lang/Object;)V

    :cond_26
    iget-boolean v0, p0, LA0/z;->d:Z

    if-nez v0, :cond_35

    invoke-virtual {p0}, LA0/z;->executeBindings()V

    iget-object v0, p0, LA0/z;->g:LA0/b;

    if-eqz v0, :cond_35

    const/4 v2, 0x3

    invoke-virtual {v0, v2, p0}, LA0/b;->d(ILjava/lang/Object;)V

    :cond_35
    iput-boolean v1, p0, LA0/z;->h:Z

    return-void
.end method

.method public addOnRebindCallback(LA0/m;)V
    .registers 4

    iget-object v0, p0, LA0/z;->g:LA0/b;

    if-nez v0, :cond_d

    new-instance v0, LA0/b;

    sget-object v1, LA0/z;->v:LA0/p;

    invoke-direct {v0, v1}, LA0/b;-><init>(LE/o;)V

    iput-object v0, p0, LA0/z;->g:LA0/b;

    :cond_d
    iget-object v0, p0, LA0/z;->g:LA0/b;

    invoke-virtual {v0, p1}, LA0/b;->a(Ljava/lang/Object;)V

    return-void
.end method

.method public ensureBindingComponentIsNotNull(Ljava/lang/Class;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Required DataBindingComponent is null in class "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ". A BindingAdapter in "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " is not static and requires an object to use, retrieved from the DataBindingComponent. If you don\'t use an inflation method taking a DataBindingComponent, use DataBindingUtil.setDefaultComponent or make all BindingAdapter methods static."

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public abstract executeBindings()V
.end method

.method public executePendingBindings()V
    .registers 2

    iget-object v0, p0, LA0/z;->l:LA0/z;

    if-nez v0, :cond_8

    invoke-virtual {p0}, LA0/z;->a()V

    goto :goto_b

    :cond_8
    invoke-virtual {v0}, LA0/z;->executePendingBindings()V

    :goto_b
    return-void
.end method

.method public getLifecycleOwner()Landroidx/lifecycle/y;
    .registers 2

    iget-object v0, p0, LA0/z;->m:Landroidx/lifecycle/y;

    return-object v0
.end method

.method public getObservedField(I)Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, LA0/z;->e:[LA0/A;

    aget-object p1, v0, p1

    if-nez p1, :cond_8

    const/4 p1, 0x0

    return-object p1

    :cond_8
    iget-object p1, p1, LA0/A;->c:Ljava/lang/Object;

    return-object p1
.end method

.method public getRoot()Landroid/view/View;
    .registers 2

    iget-object v0, p0, LA0/z;->f:Landroid/view/View;

    return-object v0
.end method

.method public handleFieldChange(ILjava/lang/Object;I)V
    .registers 5

    iget-boolean v0, p0, LA0/z;->o:Z

    if-nez v0, :cond_d

    invoke-virtual {p0, p1, p2, p3}, LA0/z;->onFieldChange(ILjava/lang/Object;I)Z

    move-result p1

    if-eqz p1, :cond_d

    invoke-virtual {p0}, LA0/z;->requestRebind()V

    :cond_d
    return-void
.end method

.method public abstract hasPendingBindings()Z
.end method

.method public abstract invalidateAll()V
.end method

.method public abstract onFieldChange(ILjava/lang/Object;I)Z
.end method

.method public registerTo(ILjava/lang/Object;LA0/c;)V
    .registers 6

    if-nez p2, :cond_3

    return-void

    :cond_3
    iget-object v0, p0, LA0/z;->e:[LA0/A;

    aget-object v1, v0, p1

    if-nez v1, :cond_1a

    sget-object v1, LA0/z;->w:Ljava/lang/ref/ReferenceQueue;

    invoke-interface {p3, p0, p1, v1}, LA0/c;->g(LA0/z;ILjava/lang/ref/ReferenceQueue;)LA0/A;

    move-result-object v1

    aput-object v1, v0, p1

    iget-object p1, p0, LA0/z;->m:Landroidx/lifecycle/y;

    if-eqz p1, :cond_1a

    iget-object p3, v1, LA0/A;->a:LA0/l;

    invoke-interface {p3, p1}, LA0/l;->t(Landroidx/lifecycle/y;)V

    :cond_1a
    invoke-virtual {v1}, LA0/A;->a()Z

    iput-object p2, v1, LA0/A;->c:Ljava/lang/Object;

    iget-object p1, v1, LA0/A;->a:LA0/l;

    invoke-interface {p1, p2}, LA0/l;->z(Ljava/lang/Object;)V

    return-void
.end method

.method public removeOnRebindCallback(LA0/m;)V
    .registers 3

    iget-object v0, p0, LA0/z;->g:LA0/b;

    if-eqz v0, :cond_7

    invoke-virtual {v0, p1}, LA0/b;->f(Ljava/lang/Object;)V

    :cond_7
    return-void
.end method

.method public requestRebind()V
    .registers 3

    iget-object v0, p0, LA0/z;->l:LA0/z;

    if-eqz v0, :cond_8

    invoke-virtual {v0}, LA0/z;->requestRebind()V

    goto :goto_3e

    :cond_8
    iget-object v0, p0, LA0/z;->m:Landroidx/lifecycle/y;

    if-eqz v0, :cond_1e

    invoke-interface {v0}, Landroidx/lifecycle/y;->getLifecycle()Landroidx/lifecycle/r;

    move-result-object v0

    check-cast v0, Landroidx/lifecycle/A;

    iget-object v0, v0, Landroidx/lifecycle/A;->d:Landroidx/lifecycle/q;

    sget-object v1, Landroidx/lifecycle/q;->d:Landroidx/lifecycle/q;

    invoke-virtual {v0, v1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v0

    if-ltz v0, :cond_1d

    goto :goto_1e

    :cond_1d
    return-void

    :cond_1e
    :goto_1e
    monitor-enter p0

    :try_start_1f
    iget-boolean v0, p0, LA0/z;->c:Z

    if-eqz v0, :cond_27

    monitor-exit p0

    return-void

    :catchall_25
    move-exception v0

    goto :goto_3f

    :cond_27
    const/4 v0, 0x1

    iput-boolean v0, p0, LA0/z;->c:Z

    monitor-exit p0
    :try_end_2b
    .catchall {:try_start_1f .. :try_end_2b} :catchall_25

    sget-boolean v0, LA0/z;->q:Z

    if-eqz v0, :cond_37

    iget-object v0, p0, LA0/z;->i:Landroid/view/Choreographer;

    iget-object v1, p0, LA0/z;->j:LA0/s;

    invoke-virtual {v0, v1}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    goto :goto_3e

    :cond_37
    iget-object v0, p0, LA0/z;->k:Landroid/os/Handler;

    iget-object v1, p0, LA0/z;->b:LA0/r;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_3e
    return-void

    :goto_3f
    :try_start_3f
    monitor-exit p0
    :try_end_40
    .catchall {:try_start_3f .. :try_end_40} :catchall_25

    throw v0
.end method

.method public setContainedBinding(LA0/z;)V
    .registers 2

    if-eqz p1, :cond_4

    iput-object p0, p1, LA0/z;->l:LA0/z;

    :cond_4
    return-void
.end method

.method public setLifecycleOwner(Landroidx/lifecycle/y;)V
    .registers 6

    instance-of v0, p1, Landroidx/fragment/app/C;

    if-eqz v0, :cond_b

    const-string v0, "DataBinding"

    const-string v1, "Setting the fragment as the LifecycleOwner might cause memory leaks because views lives shorter than the Fragment. Consider using Fragment\'s view lifecycle"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_b
    iget-object v0, p0, LA0/z;->m:Landroidx/lifecycle/y;

    if-ne v0, p1, :cond_10

    return-void

    :cond_10
    if-eqz v0, :cond_1b

    invoke-interface {v0}, Landroidx/lifecycle/y;->getLifecycle()Landroidx/lifecycle/r;

    move-result-object v0

    iget-object v1, p0, LA0/z;->n:LA0/v;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/r;->b(Landroidx/lifecycle/x;)V

    :cond_1b
    iput-object p1, p0, LA0/z;->m:Landroidx/lifecycle/y;

    if-eqz p1, :cond_33

    iget-object v0, p0, LA0/z;->n:LA0/v;

    if-nez v0, :cond_2a

    new-instance v0, LA0/v;

    invoke-direct {v0, p0}, LA0/v;-><init>(LA0/z;)V

    iput-object v0, p0, LA0/z;->n:LA0/v;

    :cond_2a
    invoke-interface {p1}, Landroidx/lifecycle/y;->getLifecycle()Landroidx/lifecycle/r;

    move-result-object v0

    iget-object v1, p0, LA0/z;->n:LA0/v;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/r;->a(Landroidx/lifecycle/x;)V

    :cond_33
    iget-object v0, p0, LA0/z;->e:[LA0/A;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_37
    if-ge v2, v1, :cond_45

    aget-object v3, v0, v2

    if-eqz v3, :cond_42

    iget-object v3, v3, LA0/A;->a:LA0/l;

    invoke-interface {v3, p1}, LA0/l;->t(Landroidx/lifecycle/y;)V

    :cond_42
    add-int/lit8 v2, v2, 0x1

    goto :goto_37

    :cond_45
    return-void
.end method

.method public setRootTag(Landroid/view/View;)V
    .registers 3

    const v0, 0x7f0a00d7

    invoke-virtual {p1, v0, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    return-void
.end method

.method public setRootTag([Landroid/view/View;)V
    .registers 6

    array-length v0, p1

    const/4 v1, 0x0

    :goto_2
    if-ge v1, v0, :cond_f

    aget-object v2, p1, v1

    const v3, 0x7f0a00d7

    invoke-virtual {v2, v3, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_f
    return-void
.end method

.method public abstract setVariable(ILjava/lang/Object;)Z
.end method

.method public unbind()V
    .registers 5

    iget-object v0, p0, LA0/z;->e:[LA0/A;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_4
    if-ge v2, v1, :cond_10

    aget-object v3, v0, v2

    if-eqz v3, :cond_d

    invoke-virtual {v3}, LA0/A;->a()Z

    :cond_d
    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_10
    return-void
.end method

.method public unregisterFrom(I)Z
    .registers 3

    iget-object v0, p0, LA0/z;->e:[LA0/A;

    aget-object p1, v0, p1

    if-eqz p1, :cond_b

    invoke-virtual {p1}, LA0/A;->a()Z

    move-result p1

    return p1

    :cond_b
    const/4 p1, 0x0

    return p1
.end method

.method public updateLiveDataRegistration(ILandroidx/lifecycle/G;)Z
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroidx/lifecycle/G;",
            ")Z"
        }
    .end annotation

    const/4 v0, 0x1

    iput-boolean v0, p0, LA0/z;->o:Z

    const/4 v0, 0x0

    :try_start_4
    sget-object v1, LA0/z;->u:LP8/b;

    invoke-virtual {p0, p1, p2, v1}, LA0/z;->updateRegistration(ILjava/lang/Object;LA0/c;)Z

    move-result p1
    :try_end_a
    .catchall {:try_start_4 .. :try_end_a} :catchall_d

    iput-boolean v0, p0, LA0/z;->o:Z

    return p1

    :catchall_d
    move-exception p1

    iput-boolean v0, p0, LA0/z;->o:Z

    throw p1
.end method

.method public updateRegistration(ILA0/i;)Z
    .registers 4

    sget-object v0, LA0/z;->r:LQ8/a;

    invoke-virtual {p0, p1, p2, v0}, LA0/z;->updateRegistration(ILjava/lang/Object;LA0/c;)Z

    move-result p1

    return p1
.end method

.method public updateRegistration(ILA0/j;)Z
    .registers 4

    sget-object v0, LA0/z;->s:LQ4/a;

    invoke-virtual {p0, p1, p2, v0}, LA0/z;->updateRegistration(ILjava/lang/Object;LA0/c;)Z

    move-result p1

    return p1
.end method

.method public updateRegistration(ILA0/k;)Z
    .registers 4

    sget-object v0, LA0/z;->t:Ll7/z7;

    invoke-virtual {p0, p1, p2, v0}, LA0/z;->updateRegistration(ILjava/lang/Object;LA0/c;)Z

    move-result p1

    return p1
.end method

.method public updateRegistration(ILjava/lang/Object;LA0/c;)Z
    .registers 6

    if-nez p2, :cond_7

    invoke-virtual {p0, p1}, LA0/z;->unregisterFrom(I)Z

    move-result p1

    return p1

    :cond_7
    iget-object v0, p0, LA0/z;->e:[LA0/A;

    aget-object v0, v0, p1

    const/4 v1, 0x1

    if-nez v0, :cond_12

    invoke-virtual {p0, p1, p2, p3}, LA0/z;->registerTo(ILjava/lang/Object;LA0/c;)V

    return v1

    :cond_12
    iget-object v0, v0, LA0/A;->c:Ljava/lang/Object;

    if-ne v0, p2, :cond_18

    const/4 p1, 0x0

    return p1

    :cond_18
    invoke-virtual {p0, p1}, LA0/z;->unregisterFrom(I)Z

    invoke-virtual {p0, p1, p2, p3}, LA0/z;->registerTo(ILjava/lang/Object;LA0/c;)V

    return v1
.end method
