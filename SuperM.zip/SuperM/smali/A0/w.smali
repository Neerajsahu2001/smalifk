.class public abstract LA0/w;
.super LA0/h;
.source "SourceFile"

# interfaces
.implements LA0/g;
