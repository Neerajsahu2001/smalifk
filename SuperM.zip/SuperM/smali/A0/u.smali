.class public final LA0/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/K;
.implements LA0/l;


# instance fields
.field public final a:LA0/A;

.field public b:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(LA0/z;ILjava/lang/ref/ReferenceQueue;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, LA0/u;->b:Ljava/lang/ref/WeakReference;

    new-instance v0, LA0/A;

    invoke-direct {v0, p1, p2, p0, p3}, LA0/A;-><init>(LA0/z;ILA0/l;Ljava/lang/ref/ReferenceQueue;)V

    iput-object v0, p0, LA0/u;->a:LA0/A;

    return-void
.end method


# virtual methods
.method public final onChanged(Ljava/lang/Object;)V
    .registers 5

    iget-object p1, p0, LA0/u;->a:LA0/A;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LA0/z;

    if-nez v0, :cond_d

    invoke-virtual {p1}, LA0/A;->a()Z

    :cond_d
    if-eqz v0, :cond_17

    iget-object v1, p1, LA0/A;->c:Ljava/lang/Object;

    const/4 v2, 0x0

    iget p1, p1, LA0/A;->b:I

    invoke-virtual {v0, p1, v1, v2}, LA0/z;->handleFieldChange(ILjava/lang/Object;I)V

    :cond_17
    return-void
.end method

.method public final t(Landroidx/lifecycle/y;)V
    .registers 4

    iget-object v0, p0, LA0/u;->b:Ljava/lang/ref/WeakReference;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_c

    :cond_6
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/lifecycle/y;

    :goto_c
    iget-object v1, p0, LA0/u;->a:LA0/A;

    iget-object v1, v1, LA0/A;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/lifecycle/G;

    if-eqz v1, :cond_1e

    if-eqz v0, :cond_19

    invoke-virtual {v1, p0}, Landroidx/lifecycle/G;->i(Landroidx/lifecycle/K;)V

    :cond_19
    if-eqz p1, :cond_1e

    invoke-virtual {v1, p1, p0}, Landroidx/lifecycle/G;->e(Landroidx/lifecycle/y;Landroidx/lifecycle/K;)V

    :cond_1e
    if-eqz p1, :cond_27

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LA0/u;->b:Ljava/lang/ref/WeakReference;

    :cond_27
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Landroidx/lifecycle/G;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/G;->i(Landroidx/lifecycle/K;)V

    return-void
.end method

.method public final z(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Landroidx/lifecycle/G;

    iget-object v0, p0, LA0/u;->b:Ljava/lang/ref/WeakReference;

    if-nez v0, :cond_8

    const/4 v0, 0x0

    goto :goto_e

    :cond_8
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/lifecycle/y;

    :goto_e
    if-eqz v0, :cond_13

    invoke-virtual {p1, v0, p0}, Landroidx/lifecycle/G;->e(Landroidx/lifecycle/y;Landroidx/lifecycle/K;)V

    :cond_13
    return-void
.end method
