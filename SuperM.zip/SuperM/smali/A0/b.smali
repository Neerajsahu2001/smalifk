.class public LA0/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public a:Ljava/util/ArrayList;

.field public b:J

.field public c:[J

.field public d:I

.field public final e:LE/o;


# direct methods
.method public constructor <init>(LE/o;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LA0/b;->a:Ljava/util/ArrayList;

    const-wide/16 v0, 0x0

    iput-wide v0, p0, LA0/b;->b:J

    iput-object p1, p0, LA0/b;->e:LE/o;

    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Ljava/lang/Object;)V
    .registers 3

    monitor-enter p0

    if-eqz p1, :cond_1b

    :try_start_3
    iget-object v0, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->lastIndexOf(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_14

    invoke-virtual {p0, v0}, LA0/b;->b(I)Z

    move-result v0

    if-eqz v0, :cond_19

    goto :goto_14

    :catchall_12
    move-exception p1

    goto :goto_23

    :cond_14
    :goto_14
    iget-object v0, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_19
    .catchall {:try_start_3 .. :try_end_19} :catchall_12

    :cond_19
    monitor-exit p0

    return-void

    :cond_1b
    :try_start_1b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "callback cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_23
    .catchall {:try_start_1b .. :try_end_23} :catchall_12

    :goto_23
    monitor-exit p0

    throw p1
.end method

.method public final b(I)Z
    .registers 12

    const-wide/16 v0, 0x0

    const-wide/16 v2, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/16 v6, 0x40

    if-ge p1, v6, :cond_15

    shl-long/2addr v2, p1

    iget-wide v6, p0, LA0/b;->b:J

    and-long/2addr v2, v6

    cmp-long p1, v2, v0

    if-eqz p1, :cond_13

    goto :goto_14

    :cond_13
    move v4, v5

    :goto_14
    return v4

    :cond_15
    iget-object v7, p0, LA0/b;->c:[J

    if-nez v7, :cond_1a

    return v5

    :cond_1a
    div-int/lit8 v8, p1, 0x40

    sub-int/2addr v8, v4

    array-length v9, v7

    if-lt v8, v9, :cond_21

    return v5

    :cond_21
    aget-wide v8, v7, v8

    rem-int/2addr p1, v6

    shl-long/2addr v2, p1

    and-long/2addr v2, v8

    cmp-long p1, v2, v0

    if-eqz p1, :cond_2b

    goto :goto_2c

    :cond_2b
    move v4, v5

    :goto_2c
    return v4
.end method

.method public final c(IIIJLjava/lang/Object;)V
    .registers 13

    const-wide/16 v0, 0x1

    :goto_2
    if-ge p2, p3, :cond_1c

    and-long v2, p4, v0

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-nez v2, :cond_17

    iget-object v2, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    iget-object v3, p0, LA0/b;->e:LE/o;

    invoke-virtual {v3, p1, v2, p6}, LE/o;->b(ILjava/lang/Object;Ljava/lang/Object;)V

    :cond_17
    const/4 v2, 0x1

    shl-long/2addr v0, v2

    add-int/lit8 p2, p2, 0x1

    goto :goto_2

    :cond_1c
    return-void
.end method

.method public final clone()Ljava/lang/Object;
    .registers 7

    monitor-enter p0

    const/4 v0, 0x0

    :try_start_2
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LA0/b;
    :try_end_8
    .catch Ljava/lang/CloneNotSupportedException; {:try_start_2 .. :try_end_8} :catch_39
    .catchall {:try_start_2 .. :try_end_8} :catchall_32

    const-wide/16 v2, 0x0

    :try_start_a
    iput-wide v2, v1, LA0/b;->b:J

    iput-object v0, v1, LA0/b;->c:[J

    const/4 v0, 0x0

    iput v0, v1, LA0/b;->d:I

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v1, LA0/b;->a:Ljava/util/ArrayList;

    iget-object v2, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    :goto_1e
    if-ge v0, v2, :cond_40

    invoke-virtual {p0, v0}, LA0/b;->b(I)Z

    move-result v3

    if-nez v3, :cond_36

    iget-object v3, v1, LA0/b;->a:Ljava/util/ArrayList;

    iget-object v4, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_31
    .catch Ljava/lang/CloneNotSupportedException; {:try_start_a .. :try_end_31} :catch_34
    .catchall {:try_start_a .. :try_end_31} :catchall_32

    goto :goto_36

    :catchall_32
    move-exception v0

    goto :goto_42

    :catch_34
    move-exception v0

    goto :goto_3d

    :cond_36
    :goto_36
    add-int/lit8 v0, v0, 0x1

    goto :goto_1e

    :catch_39
    move-exception v1

    move-object v5, v1

    move-object v1, v0

    move-object v0, v5

    :goto_3d
    :try_start_3d
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_40
    .catchall {:try_start_3d .. :try_end_40} :catchall_32

    :cond_40
    monitor-exit p0

    return-object v1

    :goto_42
    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized d(ILjava/lang/Object;)V
    .registers 11

    monitor-enter p0

    :try_start_1
    iget v0, p0, LA0/b;->d:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, LA0/b;->d:I

    iget-object v0, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    iget-object v0, p0, LA0/b;->c:[J

    if-nez v0, :cond_13

    const/4 v0, -0x1

    goto :goto_16

    :cond_13
    array-length v0, v0

    add-int/lit8 v0, v0, -0x1

    :goto_16
    invoke-virtual {p0, p1, v0, p2}, LA0/b;->e(IILjava/lang/Object;)V

    add-int/lit8 v0, v0, 0x2

    mul-int/lit8 v3, v0, 0x40

    const-wide/16 v5, 0x0

    move-object v1, p0

    move v2, p1

    move-object v7, p2

    invoke-virtual/range {v1 .. v7}, LA0/b;->c(IIIJLjava/lang/Object;)V

    iget p1, p0, LA0/b;->d:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, LA0/b;->d:I

    if-nez p1, :cond_5d

    iget-object p1, p0, LA0/b;->c:[J

    const-wide/16 v0, 0x0

    if-eqz p1, :cond_51

    array-length p1, p1

    add-int/lit8 p1, p1, -0x1

    :goto_36
    if-ltz p1, :cond_51

    iget-object p2, p0, LA0/b;->c:[J

    aget-wide v2, p2, p1

    cmp-long p2, v2, v0

    if-eqz p2, :cond_4e

    add-int/lit8 p2, p1, 0x1

    mul-int/lit8 p2, p2, 0x40

    invoke-virtual {p0, p2, v2, v3}, LA0/b;->g(IJ)V

    iget-object p2, p0, LA0/b;->c:[J

    aput-wide v0, p2, p1

    goto :goto_4e

    :catchall_4c
    move-exception p1

    goto :goto_5f

    :cond_4e
    :goto_4e
    add-int/lit8 p1, p1, -0x1

    goto :goto_36

    :cond_51
    iget-wide p1, p0, LA0/b;->b:J

    cmp-long v2, p1, v0

    if-eqz v2, :cond_5d

    const/4 v2, 0x0

    invoke-virtual {p0, v2, p1, p2}, LA0/b;->g(IJ)V

    iput-wide v0, p0, LA0/b;->b:J
    :try_end_5d
    .catchall {:try_start_1 .. :try_end_5d} :catchall_4c

    :cond_5d
    monitor-exit p0

    return-void

    :goto_5f
    monitor-exit p0

    throw p1
.end method

.method public final e(IILjava/lang/Object;)V
    .registers 13

    const/16 v0, 0x40

    if-gez p2, :cond_18

    iget-object p2, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/4 v3, 0x0

    iget-wide v5, p0, LA0/b;->b:J

    move-object v1, p0

    move v2, p1

    move-object v7, p3

    invoke-virtual/range {v1 .. v7}, LA0/b;->c(IIIJLjava/lang/Object;)V

    goto :goto_37

    :cond_18
    iget-object v1, p0, LA0/b;->c:[J

    aget-wide v6, v1, p2

    add-int/lit8 v1, p2, 0x1

    mul-int/lit8 v4, v1, 0x40

    iget-object v0, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v1, v4, 0x40

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v5

    add-int/lit8 p2, p2, -0x1

    invoke-virtual {p0, p1, p2, p3}, LA0/b;->e(IILjava/lang/Object;)V

    move-object v2, p0

    move v3, p1

    move-object v8, p3

    invoke-virtual/range {v2 .. v8}, LA0/b;->c(IIIJLjava/lang/Object;)V

    :goto_37
    return-void
.end method

.method public final declared-synchronized f(Ljava/lang/Object;)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget v0, p0, LA0/b;->d:I

    if-nez v0, :cond_d

    iget-object v0, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_18

    :catchall_b
    move-exception p1

    goto :goto_1a

    :cond_d
    iget-object v0, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->lastIndexOf(Ljava/lang/Object;)I

    move-result p1

    if-ltz p1, :cond_18

    invoke-virtual {p0, p1}, LA0/b;->h(I)V
    :try_end_18
    .catchall {:try_start_1 .. :try_end_18} :catchall_b

    :cond_18
    :goto_18
    monitor-exit p0

    return-void

    :goto_1a
    monitor-exit p0

    throw p1
.end method

.method public final g(IJ)V
    .registers 11

    add-int/lit8 v0, p1, 0x3f

    const-wide/high16 v1, -0x8000000000000000L

    :goto_4
    if-lt v0, p1, :cond_18

    and-long v3, p2, v1

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-eqz v3, :cond_13

    iget-object v3, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_13
    const/4 v3, 0x1

    ushr-long/2addr v1, v3

    add-int/lit8 v0, v0, -0x1

    goto :goto_4

    :cond_18
    return-void
.end method

.method public final h(I)V
    .registers 10

    const-wide/16 v0, 0x1

    const/16 v2, 0x40

    if-ge p1, v2, :cond_d

    shl-long/2addr v0, p1

    iget-wide v2, p0, LA0/b;->b:J

    or-long/2addr v0, v2

    iput-wide v0, p0, LA0/b;->b:J

    goto :goto_3f

    :cond_d
    div-int/lit8 v3, p1, 0x40

    add-int/lit8 v3, v3, -0x1

    iget-object v4, p0, LA0/b;->c:[J

    if-nez v4, :cond_21

    iget-object v4, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    div-int/2addr v4, v2

    new-array v4, v4, [J

    iput-object v4, p0, LA0/b;->c:[J

    goto :goto_36

    :cond_21
    array-length v4, v4

    if-gt v4, v3, :cond_36

    iget-object v4, p0, LA0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    div-int/2addr v4, v2

    new-array v4, v4, [J

    iget-object v5, p0, LA0/b;->c:[J

    array-length v6, v5

    const/4 v7, 0x0

    invoke-static {v5, v7, v4, v7, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v4, p0, LA0/b;->c:[J

    :cond_36
    :goto_36
    rem-int/2addr p1, v2

    shl-long/2addr v0, p1

    iget-object p1, p0, LA0/b;->c:[J

    aget-wide v4, p1, v3

    or-long/2addr v0, v4

    aput-wide v0, p1, v3

    :goto_3f
    return-void
.end method
