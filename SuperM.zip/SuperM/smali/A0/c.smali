.class public interface abstract LA0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract g(LA0/z;ILjava/lang/ref/ReferenceQueue;)LA0/A;
.end method
