.class public final LA0/y;
.super LA0/h;
.source "SourceFile"

# interfaces
.implements LA0/l;


# instance fields
.field public final a:LA0/A;


# direct methods
.method public constructor <init>(LA0/z;ILjava/lang/ref/ReferenceQueue;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LA0/A;

    invoke-direct {v0, p1, p2, p0, p3}, LA0/A;-><init>(LA0/z;ILA0/l;Ljava/lang/ref/ReferenceQueue;)V

    iput-object v0, p0, LA0/y;->a:LA0/A;

    return-void
.end method


# virtual methods
.method public final t(Landroidx/lifecycle/y;)V
    .registers 2

    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, LA0/i;

    check-cast p1, LA0/a;

    invoke-virtual {p1, p0}, LA0/a;->removeOnPropertyChangedCallback(LA0/h;)V

    return-void
.end method

.method public final z(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, LA0/i;

    check-cast p1, LA0/a;

    invoke-virtual {p1, p0}, LA0/a;->addOnPropertyChangedCallback(LA0/h;)V

    return-void
.end method
