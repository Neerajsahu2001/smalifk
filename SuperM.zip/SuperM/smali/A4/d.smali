.class public final LA4/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Class;

.field public final b:Lj4/k;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Lj4/k;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/d;->a:Ljava/lang/Class;

    iput-object p2, p0, LA4/d;->b:Lj4/k;

    return-void
.end method
