.class public final LA4/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Class;

.field public final b:Lj4/b;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Lj4/b;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/a;->a:Ljava/lang/Class;

    iput-object p2, p0, LA4/a;->b:Lj4/b;

    return-void
.end method
