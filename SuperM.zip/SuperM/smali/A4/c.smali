.class public final LA4/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Class;

.field public final b:Ljava/lang/Class;

.field public final c:Lj4/j;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Ljava/lang/Class;Lj4/j;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/c;->a:Ljava/lang/Class;

    iput-object p2, p0, LA4/c;->b:Ljava/lang/Class;

    iput-object p3, p0, LA4/c;->c:Lj4/j;

    return-void
.end method
