.class public final Lb2/c;
.super Lb2/j;
.source "SourceFile"


# static fields
.field public static final A:[I

.field public static final B:[I

.field public static final C:[I

.field public static final D:[I

.field public static final E:[I

.field public static final F:[I

.field public static final G:[Z

.field public static final z:[I


# instance fields
.field public final h:LZ0/w;

.field public final i:I

.field public final j:I

.field public final k:I

.field public final l:J

.field public final m:Ljava/util/ArrayList;

.field public n:Lb2/b;

.field public o:Ljava/util/List;

.field public p:Ljava/util/List;

.field public q:I

.field public r:I

.field public s:Z

.field public t:Z

.field public u:B

.field public v:B

.field public w:I

.field public x:Z

.field public y:J


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x7

    const/16 v1, 0x8

    new-array v2, v1, [I

    fill-array-data v2, :array_44

    sput-object v2, Lb2/c;->z:[I

    const/16 v2, 0x10

    new-array v1, v1, [I

    fill-array-data v1, :array_58

    sput-object v1, Lb2/c;->A:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_6c

    sput-object v0, Lb2/c;->B:[I

    const/16 v0, 0x20

    const/16 v1, 0x60

    new-array v1, v1, [I

    fill-array-data v1, :array_7e

    sput-object v1, Lb2/c;->C:[I

    new-array v1, v2, [I

    fill-array-data v1, :array_142

    sput-object v1, Lb2/c;->D:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_166

    sput-object v1, Lb2/c;->E:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_1aa

    sput-object v0, Lb2/c;->F:[I

    const/16 v0, 0x100

    new-array v0, v0, [Z

    fill-array-data v0, :array_1ee

    sput-object v0, Lb2/c;->G:[Z

    return-void

    :array_44
    .array-data 4
        0xb
        0x1
        0x3
        0xc
        0xe
        0x5
        0x7
        0x9
    .end array-data

    :array_58
    .array-data 4
        0x0
        0x4
        0x8
        0xc
        0x10
        0x14
        0x18
        0x1c
    .end array-data

    :array_6c
    .array-data 4
        -0x1
        -0xff0100
        -0xffff01
        -0xff0001
        -0x10000
        -0x100
        -0xff01
    .end array-data

    :array_7e
    .array-data 4
        0x20
        0x21
        0x22
        0x23
        0x24
        0x25
        0x26
        0x27
        0x28
        0x29
        0xe1
        0x2b
        0x2c
        0x2d
        0x2e
        0x2f
        0x30
        0x31
        0x32
        0x33
        0x34
        0x35
        0x36
        0x37
        0x38
        0x39
        0x3a
        0x3b
        0x3c
        0x3d
        0x3e
        0x3f
        0x40
        0x41
        0x42
        0x43
        0x44
        0x45
        0x46
        0x47
        0x48
        0x49
        0x4a
        0x4b
        0x4c
        0x4d
        0x4e
        0x4f
        0x50
        0x51
        0x52
        0x53
        0x54
        0x55
        0x56
        0x57
        0x58
        0x59
        0x5a
        0x5b
        0xe9
        0x5d
        0xed
        0xf3
        0xfa
        0x61
        0x62
        0x63
        0x64
        0x65
        0x66
        0x67
        0x68
        0x69
        0x6a
        0x6b
        0x6c
        0x6d
        0x6e
        0x6f
        0x70
        0x71
        0x72
        0x73
        0x74
        0x75
        0x76
        0x77
        0x78
        0x79
        0x7a
        0xe7
        0xf7
        0xd1
        0xf1
        0x25a0
    .end array-data

    :array_142
    .array-data 4
        0xae
        0xb0
        0xbd
        0xbf
        0x2122
        0xa2
        0xa3
        0x266a
        0xe0
        0x20
        0xe8
        0xe2
        0xea
        0xee
        0xf4
        0xfb
    .end array-data

    :array_166
    .array-data 4
        0xc1
        0xc9
        0xd3
        0xda
        0xdc
        0xfc
        0x2018
        0xa1
        0x2a
        0x27
        0x2014
        0xa9
        0x2120
        0x2022
        0x201c
        0x201d
        0xc0
        0xc2
        0xc7
        0xc8
        0xca
        0xcb
        0xeb
        0xce
        0xcf
        0xef
        0xd4
        0xd9
        0xf9
        0xdb
        0xab
        0xbb
    .end array-data

    :array_1aa
    .array-data 4
        0xc3
        0xe3
        0xcd
        0xcc
        0xec
        0xd2
        0xf2
        0xd5
        0xf5
        0x7b
        0x7d
        0x5c
        0x5e
        0x5f
        0x7c
        0x7e
        0xc4
        0xe4
        0xd6
        0xf6
        0xdf
        0xa5
        0xa4
        0x2502
        0xc5
        0xe5
        0xd8
        0xf8
        0x250c
        0x2510
        0x2514
        0x2518
    .end array-data

    :array_1ee
    .array-data 1
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x0t
        0x1t
        0x1t
        0x0t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
    .end array-data
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 8

    invoke-direct {p0}, Lb2/j;-><init>()V

    new-instance v0, LZ0/w;

    invoke-direct {v0}, LZ0/w;-><init>()V

    iput-object v0, p0, Lb2/c;->h:LZ0/w;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lb2/c;->m:Ljava/util/ArrayList;

    new-instance v0, Lb2/b;

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lb2/b;-><init>(II)V

    iput-object v0, p0, Lb2/c;->n:Lb2/b;

    iput v1, p0, Lb2/c;->w:I

    const-wide/32 v3, 0xf42400

    iput-wide v3, p0, Lb2/c;->l:J

    const-string v0, "application/x-mp4-cea-608"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v0, 0x3

    const/4 v3, 0x2

    if-eqz p1, :cond_2d

    move p1, v3

    goto :goto_2e

    :cond_2d
    move p1, v0

    :goto_2e
    iput p1, p0, Lb2/c;->i:I

    const/4 p1, 0x1

    if-eq p2, p1, :cond_54

    if-eq p2, v3, :cond_4f

    if-eq p2, v0, :cond_4a

    if-eq p2, v2, :cond_45

    const-string p2, "Cea608Decoder"

    const-string v0, "Invalid channel. Defaulting to CC1."

    invoke-static {p2, v0}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    iput v1, p0, Lb2/c;->k:I

    iput v1, p0, Lb2/c;->j:I

    goto :goto_58

    :cond_45
    iput p1, p0, Lb2/c;->k:I

    iput p1, p0, Lb2/c;->j:I

    goto :goto_58

    :cond_4a
    iput v1, p0, Lb2/c;->k:I

    iput p1, p0, Lb2/c;->j:I

    goto :goto_58

    :cond_4f
    iput p1, p0, Lb2/c;->k:I

    iput v1, p0, Lb2/c;->j:I

    goto :goto_58

    :cond_54
    iput v1, p0, Lb2/c;->k:I

    iput v1, p0, Lb2/c;->j:I

    :goto_58
    invoke-virtual {p0, v1}, Lb2/c;->m(I)V

    invoke-virtual {p0}, Lb2/c;->l()V

    iput-boolean p1, p0, Lb2/c;->x:Z

    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide p1, p0, Lb2/c;->y:J

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 1

    return-void
.end method

.method public final bridge synthetic d()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, Lb2/c;->i()La2/c;

    move-result-object v0

    return-object v0
.end method

.method public final flush()V
    .registers 4

    invoke-super {p0}, Lb2/j;->flush()V

    const/4 v0, 0x0

    iput-object v0, p0, Lb2/c;->o:Ljava/util/List;

    iput-object v0, p0, Lb2/c;->p:Ljava/util/List;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lb2/c;->m(I)V

    const/4 v1, 0x4

    iput v1, p0, Lb2/c;->r:I

    iget-object v2, p0, Lb2/c;->n:Lb2/b;

    iput v1, v2, Lb2/b;->h:I

    invoke-virtual {p0}, Lb2/c;->l()V

    iput-boolean v0, p0, Lb2/c;->s:Z

    iput-boolean v0, p0, Lb2/c;->t:Z

    iput-byte v0, p0, Lb2/c;->u:B

    iput-byte v0, p0, Lb2/c;->v:B

    iput v0, p0, Lb2/c;->w:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lb2/c;->x:Z

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v0, p0, Lb2/c;->y:J

    return-void
.end method

.method public final g()LA1/b;
    .registers 4

    iget-object v0, p0, Lb2/c;->o:Ljava/util/List;

    iput-object v0, p0, Lb2/c;->p:Ljava/util/List;

    new-instance v1, LA1/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/List;

    const/16 v2, 0x10

    invoke-direct {v1, v2, v0}, LA1/b;-><init>(ILjava/lang/Object;)V

    return-object v1
.end method

.method public final h(Lb2/i;)V
    .registers 16

    iget-object p1, p1, Lf1/f;->e:Ljava/nio/ByteBuffer;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    invoke-virtual {p1}, Ljava/nio/Buffer;->limit()I

    move-result p1

    iget-object v1, p0, Lb2/c;->h:LZ0/w;

    invoke-virtual {v1, p1, v0}, LZ0/w;->E(I[B)V

    const/4 p1, 0x0

    move v0, p1

    :cond_14
    :goto_14
    invoke-virtual {v1}, LZ0/w;->a()I

    move-result v2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v5, p0, Lb2/c;->i:I

    if-lt v2, v5, :cond_26c

    const/4 v2, 0x2

    if-ne v5, v2, :cond_23

    const/4 v5, -0x4

    goto :goto_27

    :cond_23
    invoke-virtual {v1}, LZ0/w;->u()I

    move-result v5

    :goto_27
    invoke-virtual {v1}, LZ0/w;->u()I

    move-result v6

    invoke-virtual {v1}, LZ0/w;->u()I

    move-result v7

    and-int/lit8 v8, v5, 0x2

    if-eqz v8, :cond_34

    goto :goto_14

    :cond_34
    and-int/lit8 v8, v5, 0x1

    iget v9, p0, Lb2/c;->j:I

    if-eq v8, v9, :cond_3b

    goto :goto_14

    :cond_3b
    and-int/lit8 v8, v6, 0x7f

    int-to-byte v8, v8

    and-int/lit8 v9, v7, 0x7f

    int-to-byte v9, v9

    if-nez v8, :cond_46

    if-nez v9, :cond_46

    goto :goto_14

    :cond_46
    iget-boolean v10, p0, Lb2/c;->s:Z

    and-int/lit8 v5, v5, 0x4

    const/4 v11, 0x4

    if-ne v5, v11, :cond_59

    sget-object v5, Lb2/c;->G:[Z

    aget-boolean v6, v5, v6

    if-eqz v6, :cond_59

    aget-boolean v5, v5, v7

    if-eqz v5, :cond_59

    move v5, v4

    goto :goto_5a

    :cond_59
    move v5, p1

    :goto_5a
    iput-boolean v5, p0, Lb2/c;->s:Z

    const/16 v6, 0x10

    if-eqz v5, :cond_7a

    and-int/lit16 v7, v8, 0xf0

    if-ne v7, v6, :cond_7a

    iget-boolean v7, p0, Lb2/c;->t:Z

    if-eqz v7, :cond_73

    iget-byte v7, p0, Lb2/c;->u:B

    if-ne v7, v8, :cond_73

    iget-byte v7, p0, Lb2/c;->v:B

    if-ne v7, v9, :cond_73

    iput-boolean p1, p0, Lb2/c;->t:Z

    goto :goto_14

    :cond_73
    iput-boolean v4, p0, Lb2/c;->t:Z

    iput-byte v8, p0, Lb2/c;->u:B

    iput-byte v9, p0, Lb2/c;->v:B

    goto :goto_7c

    :cond_7a
    iput-boolean p1, p0, Lb2/c;->t:Z

    :goto_7c
    if-nez v5, :cond_85

    if-eqz v10, :cond_14

    invoke-virtual {p0}, Lb2/c;->l()V

    :cond_83
    :goto_83
    move v0, v4

    goto :goto_14

    :cond_85
    const/16 v5, 0x20

    const/16 v7, 0x14

    if-gt v4, v8, :cond_92

    const/16 v10, 0xf

    if-gt v8, v10, :cond_92

    iput-boolean p1, p0, Lb2/c;->x:Z

    goto :goto_a8

    :cond_92
    and-int/lit16 v10, v8, 0xf6

    if-ne v10, v7, :cond_a8

    if-eq v9, v5, :cond_a6

    const/16 v10, 0x2f

    if-eq v9, v10, :cond_a6

    packed-switch v9, :pswitch_data_280

    packed-switch v9, :pswitch_data_28a

    goto :goto_a8

    :pswitch_a3
    iput-boolean p1, p0, Lb2/c;->x:Z

    goto :goto_a8

    :cond_a6
    :pswitch_a6
    iput-boolean v4, p0, Lb2/c;->x:Z

    :cond_a8
    :goto_a8
    iget-boolean v10, p0, Lb2/c;->x:Z

    if-nez v10, :cond_ae

    goto/16 :goto_14

    :cond_ae
    and-int/lit16 v10, v8, 0xe0

    if-nez v10, :cond_b7

    shr-int/lit8 v12, v8, 0x3

    and-int/2addr v12, v4

    iput v12, p0, Lb2/c;->w:I

    :cond_b7
    iget v12, p0, Lb2/c;->w:I

    iget v13, p0, Lb2/c;->k:I

    if-ne v12, v13, :cond_14

    if-nez v10, :cond_24e

    and-int/lit16 v0, v8, 0xf7

    const/16 v10, 0x11

    if-ne v0, v10, :cond_d8

    and-int/lit16 v12, v9, 0xf0

    const/16 v13, 0x30

    if-ne v12, v13, :cond_d8

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    and-int/lit8 v2, v9, 0xf

    sget-object v3, Lb2/c;->D:[I

    aget v2, v3, v2

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Lb2/b;->a(C)V

    goto :goto_83

    :cond_d8
    and-int/lit16 v12, v8, 0xf6

    const/16 v13, 0x12

    if-ne v12, v13, :cond_100

    and-int/lit16 v13, v9, 0xe0

    if-ne v13, v5, :cond_100

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    invoke-virtual {v0}, Lb2/b;->b()V

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    and-int/lit8 v2, v8, 0x1

    if-nez v2, :cond_f5

    and-int/lit8 v2, v9, 0x1f

    sget-object v3, Lb2/c;->E:[I

    aget v2, v3, v2

    :goto_f3
    int-to-char v2, v2

    goto :goto_fc

    :cond_f5
    and-int/lit8 v2, v9, 0x1f

    sget-object v3, Lb2/c;->F:[I

    aget v2, v3, v2

    goto :goto_f3

    :goto_fc
    invoke-virtual {v0, v2}, Lb2/b;->a(C)V

    goto :goto_83

    :cond_100
    if-ne v0, v10, :cond_12a

    and-int/lit16 v10, v9, 0xf0

    if-ne v10, v5, :cond_12a

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    invoke-virtual {v0, v5}, Lb2/b;->a(C)V

    and-int/lit8 v0, v9, 0x1

    if-ne v0, v4, :cond_111

    move v0, v4

    goto :goto_112

    :cond_111
    move v0, p1

    :goto_112
    shr-int/lit8 v2, v9, 0x1

    and-int/lit8 v2, v2, 0x7

    iget-object v3, p0, Lb2/c;->n:Lb2/b;

    iget-object v5, v3, Lb2/b;->a:Ljava/util/ArrayList;

    new-instance v6, Lb2/a;

    iget-object v3, v3, Lb2/b;->c:Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    invoke-direct {v6, v2, v3, v0}, Lb2/a;-><init>(IIZ)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_83

    :cond_12a
    and-int/lit16 v10, v8, 0xf0

    if-ne v10, v6, :cond_19a

    and-int/lit16 v10, v9, 0xc0

    const/16 v13, 0x40

    if-ne v10, v13, :cond_19a

    sget-object v0, Lb2/c;->z:[I

    and-int/lit8 v2, v8, 0x7

    aget v0, v0, v2

    and-int/lit8 v2, v9, 0x20

    if-eqz v2, :cond_140

    add-int/lit8 v0, v0, 0x1

    :cond_140
    iget-object v2, p0, Lb2/c;->n:Lb2/b;

    iget v3, v2, Lb2/b;->d:I

    if-eq v0, v3, :cond_164

    iget v3, p0, Lb2/c;->q:I

    if-eq v3, v4, :cond_160

    invoke-virtual {v2}, Lb2/b;->e()Z

    move-result v2

    if-nez v2, :cond_160

    new-instance v2, Lb2/b;

    iget v3, p0, Lb2/c;->q:I

    iget v5, p0, Lb2/c;->r:I

    invoke-direct {v2, v3, v5}, Lb2/b;-><init>(II)V

    iput-object v2, p0, Lb2/c;->n:Lb2/b;

    iget-object v3, p0, Lb2/c;->m:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_160
    iget-object v2, p0, Lb2/c;->n:Lb2/b;

    iput v0, v2, Lb2/b;->d:I

    :cond_164
    and-int/lit8 v0, v9, 0x10

    if-ne v0, v6, :cond_16a

    move v0, v4

    goto :goto_16b

    :cond_16a
    move v0, p1

    :goto_16b
    and-int/lit8 v2, v9, 0x1

    if-ne v2, v4, :cond_171

    move v2, v4

    goto :goto_172

    :cond_171
    move v2, p1

    :goto_172
    shr-int/lit8 v3, v9, 0x1

    and-int/lit8 v3, v3, 0x7

    iget-object v5, p0, Lb2/c;->n:Lb2/b;

    if-eqz v0, :cond_17d

    const/16 v6, 0x8

    goto :goto_17e

    :cond_17d
    move v6, v3

    :goto_17e
    iget-object v7, v5, Lb2/b;->a:Ljava/util/ArrayList;

    new-instance v8, Lb2/a;

    iget-object v5, v5, Lb2/b;->c:Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->length()I

    move-result v5

    invoke-direct {v8, v6, v5, v2}, Lb2/a;-><init>(IIZ)V

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz v0, :cond_83

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    sget-object v2, Lb2/c;->A:[I

    aget v2, v2, v3

    iput v2, v0, Lb2/b;->e:I

    goto/16 :goto_83

    :cond_19a
    const/16 v6, 0x17

    const/16 v8, 0x21

    if-ne v0, v6, :cond_1ae

    if-lt v9, v8, :cond_1ae

    const/16 v0, 0x23

    if-gt v9, v0, :cond_1ae

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    add-int/lit8 v9, v9, -0x20

    iput v9, v0, Lb2/b;->f:I

    goto/16 :goto_83

    :cond_1ae
    if-ne v12, v7, :cond_83

    and-int/lit16 v0, v9, 0xf0

    if-ne v0, v5, :cond_83

    if-eq v9, v5, :cond_249

    const/16 v0, 0x29

    if-eq v9, v0, :cond_244

    packed-switch v9, :pswitch_data_294

    iget v0, p0, Lb2/c;->q:I

    if-nez v0, :cond_1c3

    goto/16 :goto_83

    :cond_1c3
    if-eq v9, v8, :cond_21c

    packed-switch v9, :pswitch_data_29e

    goto/16 :goto_83

    :pswitch_1ca
    invoke-virtual {p0}, Lb2/c;->k()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, Lb2/c;->o:Ljava/util/List;

    invoke-virtual {p0}, Lb2/c;->l()V

    goto/16 :goto_83

    :pswitch_1d5
    invoke-virtual {p0}, Lb2/c;->l()V

    goto/16 :goto_83

    :pswitch_1da
    if-ne v0, v4, :cond_83

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    invoke-virtual {v0}, Lb2/b;->e()Z

    move-result v0

    if-nez v0, :cond_83

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    iget-object v2, v0, Lb2/b;->b:Ljava/util/ArrayList;

    invoke-virtual {v0}, Lb2/b;->d()Landroid/text/SpannableString;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v3, v0, Lb2/b;->c:Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v3, v0, Lb2/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    iget v3, v0, Lb2/b;->h:I

    iget v0, v0, Lb2/b;->d:I

    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    :goto_201
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lt v3, v0, :cond_83

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_201

    :pswitch_20b
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lb2/c;->o:Ljava/util/List;

    iget v0, p0, Lb2/c;->q:I

    if-eq v0, v4, :cond_217

    if-ne v0, v3, :cond_83

    :cond_217
    invoke-virtual {p0}, Lb2/c;->l()V

    goto/16 :goto_83

    :cond_21c
    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    invoke-virtual {v0}, Lb2/b;->b()V

    goto/16 :goto_83

    :pswitch_223
    invoke-virtual {p0, v4}, Lb2/c;->m(I)V

    iput v11, p0, Lb2/c;->r:I

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    iput v11, v0, Lb2/b;->h:I

    goto/16 :goto_83

    :pswitch_22e
    invoke-virtual {p0, v4}, Lb2/c;->m(I)V

    iput v3, p0, Lb2/c;->r:I

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    iput v3, v0, Lb2/b;->h:I

    goto/16 :goto_83

    :pswitch_239
    invoke-virtual {p0, v4}, Lb2/c;->m(I)V

    iput v2, p0, Lb2/c;->r:I

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    iput v2, v0, Lb2/b;->h:I

    goto/16 :goto_83

    :cond_244
    invoke-virtual {p0, v3}, Lb2/c;->m(I)V

    goto/16 :goto_83

    :cond_249
    invoke-virtual {p0, v2}, Lb2/c;->m(I)V

    goto/16 :goto_83

    :cond_24e
    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    and-int/lit8 v2, v8, 0x7f

    sub-int/2addr v2, v5

    sget-object v3, Lb2/c;->C:[I

    aget v2, v3, v2

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Lb2/b;->a(C)V

    and-int/lit16 v0, v9, 0xe0

    if-eqz v0, :cond_83

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    and-int/lit8 v2, v9, 0x7f

    sub-int/2addr v2, v5

    aget v2, v3, v2

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Lb2/b;->a(C)V

    goto/16 :goto_83

    :cond_26c
    if-eqz v0, :cond_27e

    iget p1, p0, Lb2/c;->q:I

    if-eq p1, v4, :cond_274

    if-ne p1, v3, :cond_27e

    :cond_274
    invoke-virtual {p0}, Lb2/c;->k()Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lb2/c;->o:Ljava/util/List;

    iget-wide v0, p0, Lb2/j;->e:J

    iput-wide v0, p0, Lb2/c;->y:J

    :cond_27e
    return-void

    nop

    :pswitch_data_280
    .packed-switch 0x25
        :pswitch_a6
        :pswitch_a6
        :pswitch_a6
    .end packed-switch

    :pswitch_data_28a
    .packed-switch 0x29
        :pswitch_a6
        :pswitch_a3
        :pswitch_a3
    .end packed-switch

    :pswitch_data_294
    .packed-switch 0x25
        :pswitch_239
        :pswitch_22e
        :pswitch_223
    .end packed-switch

    :pswitch_data_29e
    .packed-switch 0x2c
        :pswitch_20b
        :pswitch_1da
        :pswitch_1d5
        :pswitch_1ca
    .end packed-switch
.end method

.method public final i()La2/c;
    .registers 9

    invoke-super {p0}, Lb2/j;->i()La2/c;

    move-result-object v0

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    iget-wide v0, p0, Lb2/c;->l:J

    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v4, v0, v2

    if-eqz v4, :cond_3f

    iget-wide v4, p0, Lb2/c;->y:J

    cmp-long v6, v4, v2

    if-nez v6, :cond_19

    goto :goto_3f

    :cond_19
    iget-wide v6, p0, Lb2/j;->e:J

    sub-long/2addr v6, v4

    cmp-long v0, v6, v0

    if-ltz v0, :cond_3f

    iget-object v0, p0, Lb2/j;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La2/c;

    if-eqz v0, :cond_3f

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    iput-object v1, p0, Lb2/c;->o:Ljava/util/List;

    iput-wide v2, p0, Lb2/c;->y:J

    invoke-virtual {p0}, Lb2/c;->g()LA1/b;

    move-result-object v1

    iget-wide v2, p0, Lb2/j;->e:J

    iput-wide v2, v0, Lf1/g;->c:J

    iput-object v1, v0, La2/c;->e:La2/d;

    iput-wide v2, v0, La2/c;->f:J

    return-object v0

    :cond_3f
    :goto_3f
    const/4 v0, 0x0

    return-object v0
.end method

.method public final j()Z
    .registers 3

    iget-object v0, p0, Lb2/c;->o:Ljava/util/List;

    iget-object v1, p0, Lb2/c;->p:Ljava/util/List;

    if-eq v0, v1, :cond_8

    const/4 v0, 0x1

    goto :goto_9

    :cond_8
    const/4 v0, 0x0

    :goto_9
    return v0
.end method

.method public final k()Ljava/util/ArrayList;
    .registers 9

    iget-object v0, p0, Lb2/c;->m:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x2

    const/4 v4, 0x0

    move v5, v4

    :goto_e
    if-ge v5, v1, :cond_2a

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lb2/b;

    const/high16 v7, -0x80000000

    invoke-virtual {v6, v7}, Lb2/b;->c(I)LY0/b;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz v6, :cond_27

    iget v6, v6, LY0/b;->i:I

    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    move-result v3

    :cond_27
    add-int/lit8 v5, v5, 0x1

    goto :goto_e

    :cond_2a
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5, v1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_2f
    if-ge v4, v1, :cond_50

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LY0/b;

    if-eqz v6, :cond_4d

    iget v7, v6, LY0/b;->i:I

    if-eq v7, v3, :cond_4a

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lb2/b;

    invoke-virtual {v6, v3}, Lb2/b;->c(I)LY0/b;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_4a
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4d
    add-int/lit8 v4, v4, 0x1

    goto :goto_2f

    :cond_50
    return-object v5
.end method

.method public final l()V
    .registers 4

    iget-object v0, p0, Lb2/c;->n:Lb2/b;

    iget v1, p0, Lb2/c;->q:I

    iput v1, v0, Lb2/b;->g:I

    iget-object v1, v0, Lb2/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, v0, Lb2/b;->b:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, v0, Lb2/b;->c:Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->setLength(I)V

    const/16 v1, 0xf

    iput v1, v0, Lb2/b;->d:I

    iput v2, v0, Lb2/b;->e:I

    iput v2, v0, Lb2/b;->f:I

    iget-object v0, p0, Lb2/c;->m:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lb2/c;->n:Lb2/b;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final m(I)V
    .registers 5

    iget v0, p0, Lb2/c;->q:I

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput p1, p0, Lb2/c;->q:I

    const/4 v1, 0x3

    if-ne p1, v1, :cond_1f

    const/4 v0, 0x0

    :goto_b
    iget-object v1, p0, Lb2/c;->m:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1e

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lb2/b;

    iput p1, v1, Lb2/b;->g:I

    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_1e
    return-void

    :cond_1f
    invoke-virtual {p0}, Lb2/c;->l()V

    if-eq v0, v1, :cond_29

    const/4 v0, 0x1

    if-eq p1, v0, :cond_29

    if-nez p1, :cond_2f

    :cond_29
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lb2/c;->o:Ljava/util/List;

    :cond_2f
    return-void
.end method
