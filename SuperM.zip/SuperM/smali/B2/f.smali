.class public final Lb2/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final A:[Z

.field public static final B:[I

.field public static final C:[I

.field public static final D:[I

.field public static final E:[I

.field public static final v:I

.field public static final w:I

.field public static final x:[I

.field public static final y:[I

.field public static final z:[I


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Landroid/text/SpannableStringBuilder;

.field public c:Z

.field public d:Z

.field public e:I

.field public f:Z

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:I

.field public l:I

.field public m:I

.field public n:I

.field public o:I

.field public p:I

.field public q:I

.field public r:I

.field public s:I

.field public t:I

.field public u:I


# direct methods
.method static constructor <clinit>()V
    .registers 10

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {v0, v0, v0, v1}, Lb2/f;->c(IIII)I

    move-result v0

    sput v0, Lb2/f;->v:I

    invoke-static {v1, v1, v1, v1}, Lb2/f;->c(IIII)I

    move-result v0

    sput v0, Lb2/f;->w:I

    const/4 v2, 0x3

    invoke-static {v1, v1, v1, v2}, Lb2/f;->c(IIII)I

    move-result v1

    const/4 v9, 0x7

    new-array v2, v9, [I

    fill-array-data v2, :array_58

    sput-object v2, Lb2/f;->x:[I

    new-array v2, v9, [I

    fill-array-data v2, :array_6a

    sput-object v2, Lb2/f;->y:[I

    new-array v2, v9, [I

    fill-array-data v2, :array_7c

    sput-object v2, Lb2/f;->z:[I

    new-array v2, v9, [Z

    fill-array-data v2, :array_8e

    sput-object v2, Lb2/f;->A:[Z

    move v2, v0

    move v3, v1

    move v4, v0

    move v5, v0

    move v6, v1

    move v7, v0

    move v8, v0

    filled-new-array/range {v2 .. v8}, [I

    move-result-object v2

    sput-object v2, Lb2/f;->B:[I

    new-array v2, v9, [I

    fill-array-data v2, :array_96

    sput-object v2, Lb2/f;->C:[I

    new-array v2, v9, [I

    fill-array-data v2, :array_a8

    sput-object v2, Lb2/f;->D:[I

    move v2, v0

    move v3, v0

    move v6, v0

    move v7, v1

    move v8, v1

    filled-new-array/range {v2 .. v8}, [I

    move-result-object v0

    sput-object v0, Lb2/f;->E:[I

    return-void

    nop

    :array_58
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x2
        0x0
    .end array-data

    :array_6a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x2
    .end array-data

    :array_7c
    .array-data 4
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x1
    .end array-data

    :array_8e
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x1t
        0x1t
        0x1t
        0x0t
    .end array-data

    :array_96
    .array-data 4
        0x0
        0x1
        0x2
        0x3
        0x4
        0x3
        0x4
    .end array-data

    :array_a8
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x3
    .end array-data
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lb2/f;->a:Ljava/util/ArrayList;

    new-instance v0, Landroid/text/SpannableStringBuilder;

    invoke-direct {v0}, Landroid/text/SpannableStringBuilder;-><init>()V

    iput-object v0, p0, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    invoke-virtual {p0}, Lb2/f;->d()V

    return-void
.end method

.method public static c(IIII)I
    .registers 8

    const/4 v0, 0x4

    invoke-static {p0, v0}, Lm7/u;->c(II)V

    invoke-static {p1, v0}, Lm7/u;->c(II)V

    invoke-static {p2, v0}, Lm7/u;->c(II)V

    invoke-static {p3, v0}, Lm7/u;->c(II)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/16 v2, 0xff

    if-eqz p3, :cond_1b

    if-eq p3, v1, :cond_1b

    const/4 v3, 0x2

    if-eq p3, v3, :cond_1f

    const/4 v3, 0x3

    if-eq p3, v3, :cond_1d

    :cond_1b
    move p3, v2

    goto :goto_21

    :cond_1d
    move p3, v0

    goto :goto_21

    :cond_1f
    const/16 p3, 0x7f

    :goto_21
    if-le p0, v1, :cond_25

    move p0, v2

    goto :goto_26

    :cond_25
    move p0, v0

    :goto_26
    if-le p1, v1, :cond_2a

    move p1, v2

    goto :goto_2b

    :cond_2a
    move p1, v0

    :goto_2b
    if-le p2, v1, :cond_2e

    move v0, v2

    :cond_2e
    invoke-static {p3, p0, p1, v0}, Landroid/graphics/Color;->argb(IIII)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a(C)V
    .registers 5

    iget-object v0, p0, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    const/16 v1, 0xa

    if-ne p1, v1, :cond_48

    iget-object v1, p0, Lb2/f;->a:Ljava/util/ArrayList;

    invoke-virtual {p0}, Lb2/f;->b()Landroid/text/SpannableString;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Landroid/text/SpannableStringBuilder;->clear()V

    iget p1, p0, Lb2/f;->o:I

    const/4 v0, -0x1

    const/4 v2, 0x0

    if-eq p1, v0, :cond_1a

    iput v2, p0, Lb2/f;->o:I

    :cond_1a
    iget p1, p0, Lb2/f;->p:I

    if-eq p1, v0, :cond_20

    iput v2, p0, Lb2/f;->p:I

    :cond_20
    iget p1, p0, Lb2/f;->q:I

    if-eq p1, v0, :cond_26

    iput v2, p0, Lb2/f;->q:I

    :cond_26
    iget p1, p0, Lb2/f;->s:I

    if-eq p1, v0, :cond_2c

    iput v2, p0, Lb2/f;->s:I

    :cond_2c
    :goto_2c
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    iget v0, p0, Lb2/f;->j:I

    if-ge p1, v0, :cond_44

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/16 v0, 0xf

    if-lt p1, v0, :cond_3d

    goto :goto_44

    :cond_3d
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    iput p1, p0, Lb2/f;->u:I

    goto :goto_4b

    :cond_44
    :goto_44
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_2c

    :cond_48
    invoke-virtual {v0, p1}, Landroid/text/SpannableStringBuilder;->append(C)Landroid/text/SpannableStringBuilder;

    :goto_4b
    return-void
.end method

.method public final b()Landroid/text/SpannableString;
    .registers 7

    new-instance v0, Landroid/text/SpannableStringBuilder;

    iget-object v1, p0, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    invoke-direct {v0, v1}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v1

    if-lez v1, :cond_4d

    iget v2, p0, Lb2/f;->o:I

    const/16 v3, 0x21

    const/4 v4, -0x1

    if-eq v2, v4, :cond_1f

    new-instance v2, Landroid/text/style/StyleSpan;

    const/4 v5, 0x2

    invoke-direct {v2, v5}, Landroid/text/style/StyleSpan;-><init>(I)V

    iget v5, p0, Lb2/f;->o:I

    invoke-virtual {v0, v2, v5, v1, v3}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    :cond_1f
    iget v2, p0, Lb2/f;->p:I

    if-eq v2, v4, :cond_2d

    new-instance v2, Landroid/text/style/UnderlineSpan;

    invoke-direct {v2}, Landroid/text/style/UnderlineSpan;-><init>()V

    iget v5, p0, Lb2/f;->p:I

    invoke-virtual {v0, v2, v5, v1, v3}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    :cond_2d
    iget v2, p0, Lb2/f;->q:I

    if-eq v2, v4, :cond_3d

    new-instance v2, Landroid/text/style/ForegroundColorSpan;

    iget v5, p0, Lb2/f;->r:I

    invoke-direct {v2, v5}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    iget v5, p0, Lb2/f;->q:I

    invoke-virtual {v0, v2, v5, v1, v3}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    :cond_3d
    iget v2, p0, Lb2/f;->s:I

    if-eq v2, v4, :cond_4d

    new-instance v2, Landroid/text/style/BackgroundColorSpan;

    iget v4, p0, Lb2/f;->t:I

    invoke-direct {v2, v4}, Landroid/text/style/BackgroundColorSpan;-><init>(I)V

    iget v4, p0, Lb2/f;->s:I

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    :cond_4d
    new-instance v1, Landroid/text/SpannableString;

    invoke-direct {v1, v0}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    return-object v1
.end method

.method public final d()V
    .registers 3

    iget-object v0, p0, Lb2/f;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v0}, Landroid/text/SpannableStringBuilder;->clear()V

    const/4 v0, -0x1

    iput v0, p0, Lb2/f;->o:I

    iput v0, p0, Lb2/f;->p:I

    iput v0, p0, Lb2/f;->q:I

    iput v0, p0, Lb2/f;->s:I

    const/4 v0, 0x0

    iput v0, p0, Lb2/f;->u:I

    iput-boolean v0, p0, Lb2/f;->c:Z

    iput-boolean v0, p0, Lb2/f;->d:Z

    const/4 v1, 0x4

    iput v1, p0, Lb2/f;->e:I

    iput-boolean v0, p0, Lb2/f;->f:Z

    iput v0, p0, Lb2/f;->g:I

    iput v0, p0, Lb2/f;->h:I

    iput v0, p0, Lb2/f;->i:I

    const/16 v1, 0xf

    iput v1, p0, Lb2/f;->j:I

    iput v0, p0, Lb2/f;->k:I

    iput v0, p0, Lb2/f;->l:I

    iput v0, p0, Lb2/f;->m:I

    sget v0, Lb2/f;->w:I

    iput v0, p0, Lb2/f;->n:I

    sget v1, Lb2/f;->v:I

    iput v1, p0, Lb2/f;->r:I

    iput v0, p0, Lb2/f;->t:I

    return-void
.end method

.method public final e(ZZ)V
    .registers 8

    iget v0, p0, Lb2/f;->o:I

    iget-object v1, p0, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    const/16 v2, 0x21

    const/4 v3, -0x1

    if-eq v0, v3, :cond_1d

    if-nez p1, :cond_25

    new-instance p1, Landroid/text/style/StyleSpan;

    const/4 v0, 0x2

    invoke-direct {p1, v0}, Landroid/text/style/StyleSpan;-><init>(I)V

    iget v0, p0, Lb2/f;->o:I

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v4

    invoke-virtual {v1, p1, v0, v4, v2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    iput v3, p0, Lb2/f;->o:I

    goto :goto_25

    :cond_1d
    if-eqz p1, :cond_25

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result p1

    iput p1, p0, Lb2/f;->o:I

    :cond_25
    :goto_25
    iget p1, p0, Lb2/f;->p:I

    if-eq p1, v3, :cond_3c

    if-nez p2, :cond_44

    new-instance p1, Landroid/text/style/UnderlineSpan;

    invoke-direct {p1}, Landroid/text/style/UnderlineSpan;-><init>()V

    iget p2, p0, Lb2/f;->p:I

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v0

    invoke-virtual {v1, p1, p2, v0, v2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    iput v3, p0, Lb2/f;->p:I

    goto :goto_44

    :cond_3c
    if-eqz p2, :cond_44

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result p1

    iput p1, p0, Lb2/f;->p:I

    :cond_44
    :goto_44
    return-void
.end method

.method public final f(II)V
    .registers 9

    iget v0, p0, Lb2/f;->q:I

    iget-object v1, p0, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    const/16 v2, 0x21

    const/4 v3, -0x1

    if-eq v0, v3, :cond_1d

    iget v0, p0, Lb2/f;->r:I

    if-eq v0, p1, :cond_1d

    new-instance v0, Landroid/text/style/ForegroundColorSpan;

    iget v4, p0, Lb2/f;->r:I

    invoke-direct {v0, v4}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    iget v4, p0, Lb2/f;->q:I

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v5

    invoke-virtual {v1, v0, v4, v5, v2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    :cond_1d
    sget v0, Lb2/f;->v:I

    if-eq p1, v0, :cond_29

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v0

    iput v0, p0, Lb2/f;->q:I

    iput p1, p0, Lb2/f;->r:I

    :cond_29
    iget p1, p0, Lb2/f;->s:I

    if-eq p1, v3, :cond_41

    iget p1, p0, Lb2/f;->t:I

    if-eq p1, p2, :cond_41

    new-instance p1, Landroid/text/style/BackgroundColorSpan;

    iget v0, p0, Lb2/f;->t:I

    invoke-direct {p1, v0}, Landroid/text/style/BackgroundColorSpan;-><init>(I)V

    iget v0, p0, Lb2/f;->s:I

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v3

    invoke-virtual {v1, p1, v0, v3, v2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    :cond_41
    sget p1, Lb2/f;->w:I

    if-eq p2, p1, :cond_4d

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result p1

    iput p1, p0, Lb2/f;->s:I

    iput p2, p0, Lb2/f;->t:I

    :cond_4d
    return-void
.end method
