.class public final Lb2/h;
.super Lb2/j;
.source "SourceFile"


# instance fields
.field public final h:LZ0/w;

.field public final i:LZ0/v;

.field public j:I

.field public final k:I

.field public final l:[Lb2/f;

.field public m:Lb2/f;

.field public n:Ljava/util/List;

.field public o:Ljava/util/List;

.field public p:Lb2/g;

.field public q:I


# direct methods
.method public constructor <init>(ILjava/util/List;)V
    .registers 6

    invoke-direct {p0}, Lb2/j;-><init>()V

    new-instance v0, LZ0/w;

    invoke-direct {v0}, LZ0/w;-><init>()V

    iput-object v0, p0, Lb2/h;->h:LZ0/w;

    new-instance v0, LZ0/v;

    invoke-direct {v0}, LZ0/v;-><init>()V

    iput-object v0, p0, Lb2/h;->i:LZ0/v;

    const/4 v0, -0x1

    iput v0, p0, Lb2/h;->j:I

    const/4 v1, 0x1

    if-ne p1, v0, :cond_18

    move p1, v1

    :cond_18
    iput p1, p0, Lb2/h;->k:I

    const/4 p1, 0x0

    if-eqz p2, :cond_34

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    if-ne v0, v1, :cond_34

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    array-length v0, v0

    if-ne v0, v1, :cond_34

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [B

    aget-byte p2, p2, p1

    :cond_34
    const/16 p2, 0x8

    new-array v0, p2, [Lb2/f;

    iput-object v0, p0, Lb2/h;->l:[Lb2/f;

    move v0, p1

    :goto_3b
    if-ge v0, p2, :cond_49

    iget-object v1, p0, Lb2/h;->l:[Lb2/f;

    new-instance v2, Lb2/f;

    invoke-direct {v2}, Lb2/f;-><init>()V

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_3b

    :cond_49
    iget-object p2, p0, Lb2/h;->l:[Lb2/f;

    aget-object p1, p2, p1

    iput-object p1, p0, Lb2/h;->m:Lb2/f;

    return-void
.end method


# virtual methods
.method public final flush()V
    .registers 4

    invoke-super {p0}, Lb2/j;->flush()V

    const/4 v0, 0x0

    iput-object v0, p0, Lb2/h;->n:Ljava/util/List;

    iput-object v0, p0, Lb2/h;->o:Ljava/util/List;

    const/4 v1, 0x0

    iput v1, p0, Lb2/h;->q:I

    iget-object v2, p0, Lb2/h;->l:[Lb2/f;

    aget-object v1, v2, v1

    iput-object v1, p0, Lb2/h;->m:Lb2/f;

    invoke-virtual {p0}, Lb2/h;->m()V

    iput-object v0, p0, Lb2/h;->p:Lb2/g;

    return-void
.end method

.method public final g()LA1/b;
    .registers 4

    iget-object v0, p0, Lb2/h;->n:Ljava/util/List;

    iput-object v0, p0, Lb2/h;->o:Ljava/util/List;

    new-instance v1, LA1/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ljava/util/List;

    const/16 v2, 0x10

    invoke-direct {v1, v2, v0}, LA1/b;-><init>(ILjava/lang/Object;)V

    return-object v1
.end method

.method public final h(Lb2/i;)V
    .registers 12

    iget-object p1, p1, Lf1/f;->e:Ljava/nio/ByteBuffer;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    invoke-virtual {p1}, Ljava/nio/Buffer;->limit()I

    move-result p1

    iget-object v1, p0, Lb2/h;->h:LZ0/w;

    invoke-virtual {v1, p1, v0}, LZ0/w;->E(I[B)V

    :cond_12
    :goto_12
    invoke-virtual {v1}, LZ0/w;->a()I

    move-result p1

    const/4 v0, 0x3

    if-lt p1, v0, :cond_b1

    invoke-virtual {v1}, LZ0/w;->u()I

    move-result p1

    and-int/lit8 v2, p1, 0x3

    const/4 v3, 0x4

    and-int/2addr p1, v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ne p1, v3, :cond_27

    move p1, v4

    goto :goto_28

    :cond_27
    move p1, v5

    :goto_28
    invoke-virtual {v1}, LZ0/w;->u()I

    move-result v6

    int-to-byte v6, v6

    invoke-virtual {v1}, LZ0/w;->u()I

    move-result v7

    int-to-byte v7, v7

    const/4 v8, 0x2

    if-eq v2, v8, :cond_38

    if-eq v2, v0, :cond_38

    goto :goto_12

    :cond_38
    if-nez p1, :cond_3b

    goto :goto_12

    :cond_3b
    const-string p1, "Cea708Decoder"

    if-ne v2, v0, :cond_84

    invoke-virtual {p0}, Lb2/h;->k()V

    and-int/lit16 v0, v6, 0xc0

    shr-int/lit8 v0, v0, 0x6

    iget v2, p0, Lb2/h;->j:I

    const/4 v9, -0x1

    if-eq v2, v9, :cond_6e

    add-int/lit8 v2, v2, 0x1

    rem-int/2addr v2, v3

    if-eq v0, v2, :cond_6e

    invoke-virtual {p0}, Lb2/h;->m()V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Sequence number discontinuity. previous="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v3, p0, Lb2/h;->j:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " current="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6e
    iput v0, p0, Lb2/h;->j:I

    and-int/lit8 p1, v6, 0x3f

    if-nez p1, :cond_76

    const/16 p1, 0x40

    :cond_76
    new-instance v2, Lb2/g;

    invoke-direct {v2, v0, p1}, Lb2/g;-><init>(II)V

    iput-object v2, p0, Lb2/h;->p:Lb2/g;

    iput v4, v2, Lb2/g;->d:I

    iget-object p1, v2, Lb2/g;->c:[B

    aput-byte v7, p1, v5

    goto :goto_a2

    :cond_84
    if-ne v2, v8, :cond_87

    move v5, v4

    :cond_87
    invoke-static {v5}, Lm7/u;->a(Z)V

    iget-object v0, p0, Lb2/h;->p:Lb2/g;

    if-nez v0, :cond_95

    const-string v0, "Encountered DTVCC_PACKET_DATA before DTVCC_PACKET_START"

    invoke-static {p1, v0}, LZ0/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_12

    :cond_95
    iget p1, v0, Lb2/g;->d:I

    add-int/lit8 v2, p1, 0x1

    iget-object v3, v0, Lb2/g;->c:[B

    aput-byte v6, v3, p1

    add-int/2addr p1, v8

    iput p1, v0, Lb2/g;->d:I

    aput-byte v7, v3, v2

    :goto_a2
    iget-object p1, p0, Lb2/h;->p:Lb2/g;

    iget v0, p1, Lb2/g;->d:I

    iget p1, p1, Lb2/g;->b:I

    mul-int/2addr p1, v8

    sub-int/2addr p1, v4

    if-ne v0, p1, :cond_12

    invoke-virtual {p0}, Lb2/h;->k()V

    goto/16 :goto_12

    :cond_b1
    return-void
.end method

.method public final j()Z
    .registers 3

    iget-object v0, p0, Lb2/h;->n:Ljava/util/List;

    iget-object v1, p0, Lb2/h;->o:Ljava/util/List;

    if-eq v0, v1, :cond_8

    const/4 v0, 0x1

    goto :goto_9

    :cond_8
    const/4 v0, 0x0

    :goto_9
    return v0
.end method

.method public final k()V
    .registers 18

    move-object/from16 v0, p0

    iget-object v1, v0, Lb2/h;->p:Lb2/g;

    if-nez v1, :cond_7

    return-void

    :cond_7
    iget v2, v1, Lb2/g;->d:I

    iget v1, v1, Lb2/g;->b:I

    const/4 v3, 0x2

    mul-int/2addr v1, v3

    const/4 v4, 0x1

    sub-int/2addr v1, v4

    const-string v5, "Cea708Decoder"

    if-eq v2, v1, :cond_47

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "DtvCcPacket ended prematurely; size is "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v0, Lb2/h;->p:Lb2/g;

    iget v2, v2, Lb2/g;->b:I

    mul-int/2addr v2, v3

    sub-int/2addr v2, v4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", but current index is "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lb2/h;->p:Lb2/g;

    iget v2, v2, Lb2/g;->d:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " (sequence number "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lb2/h;->p:Lb2/g;

    iget v2, v2, Lb2/g;->a:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ");"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v5, v1}, LZ0/b;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_47
    iget-object v1, v0, Lb2/h;->p:Lb2/g;

    iget-object v2, v1, Lb2/g;->c:[B

    iget v1, v1, Lb2/g;->d:I

    iget-object v6, v0, Lb2/h;->i:LZ0/v;

    invoke-virtual {v6, v1, v2}, LZ0/v;->d0(I[B)V

    const/4 v2, 0x0

    :cond_53
    :goto_53
    invoke-virtual {v6}, LZ0/v;->b()I

    move-result v7

    if-lez v7, :cond_55b

    const/4 v7, 0x3

    invoke-virtual {v6, v7}, LZ0/v;->i(I)I

    move-result v8

    const/4 v9, 0x5

    invoke-virtual {v6, v9}, LZ0/v;->i(I)I

    move-result v9

    const/4 v10, 0x6

    const/4 v11, 0x7

    if-ne v8, v11, :cond_75

    invoke-virtual {v6, v3}, LZ0/v;->h0(I)V

    invoke-virtual {v6, v10}, LZ0/v;->i(I)I

    move-result v8

    if-ge v8, v11, :cond_75

    const-string v12, "Invalid extended service number: "

    invoke-static {v8, v12, v5}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    :cond_75
    if-nez v9, :cond_91

    if-eqz v8, :cond_55b

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "serviceNumber is non-zero ("

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, ") when blockSize is 0"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v5, v1}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_55b

    :cond_91
    iget v12, v0, Lb2/h;->k:I

    if-eq v8, v12, :cond_99

    invoke-virtual {v6, v9}, LZ0/v;->i0(I)V

    goto :goto_53

    :cond_99
    invoke-virtual {v6}, LZ0/v;->f()I

    move-result v8

    mul-int/lit8 v9, v9, 0x8

    add-int/2addr v9, v8

    :goto_a0
    invoke-virtual {v6}, LZ0/v;->f()I

    move-result v8

    if-ge v8, v9, :cond_53

    const/16 v8, 0x8

    invoke-virtual {v6, v8}, LZ0/v;->i(I)I

    move-result v12

    const/16 v15, 0x17

    const/16 v13, 0x9f

    const/16 v1, 0x7f

    const/16 v14, 0x18

    const/16 v4, 0x1f

    const/16 v10, 0x10

    if-eq v12, v10, :cond_3cb

    const/16 v11, 0xa

    if-gt v12, v4, :cond_126

    if-eqz v12, :cond_121

    if-eq v12, v7, :cond_11b

    if-eq v12, v8, :cond_10b

    packed-switch v12, :pswitch_data_568

    const/16 v1, 0x11

    if-lt v12, v1, :cond_e2

    if-gt v12, v15, :cond_e2

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v4, "Currently unsupported COMMAND_EXT1 Command: "

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v5, v1}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v8}, LZ0/v;->h0(I)V

    goto :goto_121

    :cond_e2
    if-lt v12, v14, :cond_fb

    if-gt v12, v4, :cond_fb

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v4, "Currently unsupported COMMAND_P16 Command: "

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v5, v1}, LZ0/b;->h(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v10}, LZ0/v;->h0(I)V

    goto :goto_121

    :cond_fb
    const-string v1, "Invalid C0 command: "

    invoke-static {v12, v1, v5}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    goto :goto_121

    :pswitch_101
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    invoke-virtual {v1, v11}, Lb2/f;->a(C)V

    goto :goto_121

    :pswitch_107
    invoke-virtual/range {p0 .. p0}, Lb2/h;->m()V

    goto :goto_121

    :cond_10b
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    iget-object v1, v1, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v4

    if-lez v4, :cond_121

    add-int/lit8 v8, v4, -0x1

    invoke-virtual {v1, v8, v4}, Landroid/text/SpannableStringBuilder;->delete(II)Landroid/text/SpannableStringBuilder;

    goto :goto_121

    :cond_11b
    invoke-virtual/range {p0 .. p0}, Lb2/h;->l()Ljava/util/List;

    move-result-object v1

    iput-object v1, v0, Lb2/h;->n:Ljava/util/List;

    :cond_121
    :goto_121
    :pswitch_121
    move v1, v3

    move v3, v7

    move/from16 v16, v9

    goto :goto_13f

    :cond_126
    if-gt v12, v1, :cond_145

    if-ne v12, v1, :cond_132

    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x266b

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_13a

    :cond_132
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    and-int/lit16 v2, v12, 0xff

    int-to-char v2, v2

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    :goto_13a
    move v1, v3

    move v3, v7

    move/from16 v16, v9

    const/4 v2, 0x1

    :goto_13f
    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    :goto_142
    const/4 v12, 0x7

    goto/16 :goto_553

    :cond_145
    if-gt v12, v13, :cond_3b3

    const/4 v1, 0x4

    iget-object v2, v0, Lb2/h;->l:[Lb2/f;

    packed-switch v12, :pswitch_data_572

    :pswitch_14d
    const-string v1, "Invalid C1 command: "

    invoke-static {v12, v1, v5}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    :pswitch_152
    move v3, v7

    move/from16 v16, v9

    :cond_155
    :goto_155
    const/4 v9, 0x1

    :cond_156
    const/4 v11, 0x0

    goto/16 :goto_3ae

    :pswitch_159
    add-int/lit16 v12, v12, -0x98

    aget-object v4, v2, v12

    invoke-virtual {v6, v3}, LZ0/v;->h0(I)V

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v10

    invoke-virtual {v6, v3}, LZ0/v;->h0(I)V

    invoke-virtual {v6, v7}, LZ0/v;->i(I)I

    move-result v11

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v13

    const/4 v14, 0x7

    invoke-virtual {v6, v14}, LZ0/v;->i(I)I

    move-result v15

    invoke-virtual {v6, v8}, LZ0/v;->i(I)I

    move-result v8

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v14

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v1

    invoke-virtual {v6, v3}, LZ0/v;->h0(I)V

    const/4 v7, 0x6

    invoke-virtual {v6, v7}, LZ0/v;->h0(I)V

    invoke-virtual {v6, v3}, LZ0/v;->h0(I)V

    const/4 v7, 0x3

    invoke-virtual {v6, v7}, LZ0/v;->i(I)I

    move-result v3

    move/from16 v16, v9

    invoke-virtual {v6, v7}, LZ0/v;->i(I)I

    move-result v9

    const/4 v7, 0x1

    iput-boolean v7, v4, Lb2/f;->c:Z

    iput-boolean v10, v4, Lb2/f;->d:Z

    iput v11, v4, Lb2/f;->e:I

    iput-boolean v13, v4, Lb2/f;->f:Z

    iput v15, v4, Lb2/f;->g:I

    iput v8, v4, Lb2/f;->h:I

    iput v14, v4, Lb2/f;->i:I

    iget v8, v4, Lb2/f;->j:I

    add-int/2addr v1, v7

    if-eq v8, v1, :cond_1c2

    iput v1, v4, Lb2/f;->j:I

    :goto_1ab
    iget-object v1, v4, Lb2/f;->a:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v7

    iget v8, v4, Lb2/f;->j:I

    if-ge v7, v8, :cond_1bd

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v7

    const/16 v8, 0xf

    if-lt v7, v8, :cond_1c2

    :cond_1bd
    const/4 v7, 0x0

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_1ab

    :cond_1c2
    if-eqz v3, :cond_1e4

    iget v1, v4, Lb2/f;->l:I

    if-eq v1, v3, :cond_1e4

    iput v3, v4, Lb2/f;->l:I

    add-int/lit8 v3, v3, -0x1

    sget-object v1, Lb2/f;->B:[I

    aget v1, v1, v3

    sget-object v7, Lb2/f;->A:[Z

    aget-boolean v7, v7, v3

    sget-object v7, Lb2/f;->y:[I

    aget v7, v7, v3

    sget-object v7, Lb2/f;->z:[I

    aget v7, v7, v3

    sget-object v7, Lb2/f;->x:[I

    aget v3, v7, v3

    iput v1, v4, Lb2/f;->n:I

    iput v3, v4, Lb2/f;->k:I

    :cond_1e4
    if-eqz v9, :cond_203

    iget v1, v4, Lb2/f;->m:I

    if-eq v1, v9, :cond_203

    iput v9, v4, Lb2/f;->m:I

    add-int/lit8 v9, v9, -0x1

    sget-object v1, Lb2/f;->D:[I

    aget v1, v1, v9

    sget-object v1, Lb2/f;->C:[I

    aget v1, v1, v9

    const/4 v1, 0x0

    invoke-virtual {v4, v1, v1}, Lb2/f;->e(ZZ)V

    sget-object v1, Lb2/f;->E:[I

    aget v1, v1, v9

    sget v3, Lb2/f;->v:I

    invoke-virtual {v4, v3, v1}, Lb2/f;->f(II)V

    :cond_203
    iget v1, v0, Lb2/h;->q:I

    if-eq v1, v12, :cond_20d

    iput v12, v0, Lb2/h;->q:I

    aget-object v1, v2, v12

    iput-object v1, v0, Lb2/h;->m:Lb2/f;

    :cond_20d
    :goto_20d
    const/4 v3, 0x3

    goto/16 :goto_155

    :pswitch_210
    move/from16 v16, v9

    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    iget-boolean v1, v1, Lb2/f;->c:Z

    if-nez v1, :cond_21e

    const/16 v1, 0x20

    invoke-virtual {v6, v1}, LZ0/v;->h0(I)V

    goto :goto_20d

    :cond_21e
    const/4 v1, 0x2

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v2

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v3

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v4

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v7

    invoke-static {v3, v4, v7, v2}, Lb2/f;->c(IIII)I

    move-result v2

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v3

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v4

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v7

    const/4 v9, 0x0

    invoke-static {v3, v4, v7, v9}, Lb2/f;->c(IIII)I

    invoke-virtual {v6}, LZ0/v;->h()Z

    invoke-virtual {v6}, LZ0/v;->h()Z

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v3

    invoke-virtual {v6, v8}, LZ0/v;->h0(I)V

    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    iput v2, v1, Lb2/f;->n:I

    iput v3, v1, Lb2/f;->k:I

    goto :goto_20d

    :pswitch_260
    move/from16 v16, v9

    iget-object v2, v0, Lb2/h;->m:Lb2/f;

    iget-boolean v2, v2, Lb2/f;->c:Z

    if-nez v2, :cond_26c

    invoke-virtual {v6, v10}, LZ0/v;->h0(I)V

    goto :goto_20d

    :cond_26c
    invoke-virtual {v6, v1}, LZ0/v;->h0(I)V

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v1

    const/4 v2, 0x2

    invoke-virtual {v6, v2}, LZ0/v;->h0(I)V

    const/4 v2, 0x6

    invoke-virtual {v6, v2}, LZ0/v;->i(I)I

    iget-object v2, v0, Lb2/h;->m:Lb2/f;

    iget v3, v2, Lb2/f;->u:I

    if-eq v3, v1, :cond_284

    invoke-virtual {v2, v11}, Lb2/f;->a(C)V

    :cond_284
    iput v1, v2, Lb2/f;->u:I

    goto :goto_20d

    :pswitch_287
    move/from16 v16, v9

    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    iget-boolean v1, v1, Lb2/f;->c:Z

    if-nez v1, :cond_294

    invoke-virtual {v6, v14}, LZ0/v;->h0(I)V

    goto/16 :goto_20d

    :cond_294
    const/4 v1, 0x2

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v2

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v3

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v4

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v7

    invoke-static {v3, v4, v7, v2}, Lb2/f;->c(IIII)I

    move-result v2

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v3

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v4

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v7

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v8

    invoke-static {v4, v7, v8, v3}, Lb2/f;->c(IIII)I

    move-result v3

    invoke-virtual {v6, v1}, LZ0/v;->h0(I)V

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v4

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v7

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    move-result v8

    const/4 v1, 0x0

    invoke-static {v4, v7, v8, v1}, Lb2/f;->c(IIII)I

    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    invoke-virtual {v1, v2, v3}, Lb2/f;->f(II)V

    goto/16 :goto_20d

    :pswitch_2d7
    move/from16 v16, v9

    iget-object v2, v0, Lb2/h;->m:Lb2/f;

    iget-boolean v2, v2, Lb2/f;->c:Z

    if-nez v2, :cond_2e4

    invoke-virtual {v6, v10}, LZ0/v;->h0(I)V

    goto/16 :goto_20d

    :cond_2e4
    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    const/4 v1, 0x2

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    invoke-virtual {v6, v1}, LZ0/v;->i(I)I

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v1

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v2

    const/4 v3, 0x3

    invoke-virtual {v6, v3}, LZ0/v;->i(I)I

    invoke-virtual {v6, v3}, LZ0/v;->i(I)I

    iget-object v4, v0, Lb2/h;->m:Lb2/f;

    invoke-virtual {v4, v1, v2}, Lb2/f;->e(ZZ)V

    goto/16 :goto_155

    :pswitch_304
    move v3, v7

    move/from16 v16, v9

    invoke-virtual/range {p0 .. p0}, Lb2/h;->m()V

    goto/16 :goto_155

    :pswitch_30c
    move v3, v7

    move/from16 v16, v9

    invoke-virtual {v6, v8}, LZ0/v;->h0(I)V

    goto/16 :goto_155

    :pswitch_314
    move v3, v7

    move/from16 v16, v9

    const/4 v1, 0x1

    :goto_318
    if-gt v1, v8, :cond_155

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v4

    if-eqz v4, :cond_327

    rsub-int/lit8 v4, v1, 0x8

    aget-object v4, v2, v4

    invoke-virtual {v4}, Lb2/f;->d()V

    :cond_327
    add-int/lit8 v1, v1, 0x1

    goto :goto_318

    :pswitch_32a
    move v3, v7

    move/from16 v16, v9

    const/4 v7, 0x1

    :goto_32e
    if-gt v7, v8, :cond_155

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v1

    if-eqz v1, :cond_340

    rsub-int/lit8 v1, v7, 0x8

    aget-object v1, v2, v1

    iget-boolean v4, v1, Lb2/f;->d:Z

    const/4 v9, 0x1

    xor-int/2addr v4, v9

    iput-boolean v4, v1, Lb2/f;->d:Z

    :cond_340
    add-int/lit8 v7, v7, 0x1

    goto :goto_32e

    :pswitch_343
    move v3, v7

    move/from16 v16, v9

    const/4 v7, 0x1

    :goto_347
    if-gt v7, v8, :cond_155

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v1

    if-eqz v1, :cond_356

    rsub-int/lit8 v1, v7, 0x8

    aget-object v1, v2, v1

    const/4 v4, 0x0

    iput-boolean v4, v1, Lb2/f;->d:Z

    :cond_356
    add-int/lit8 v7, v7, 0x1

    goto :goto_347

    :pswitch_359
    move v3, v7

    move/from16 v16, v9

    const/4 v7, 0x1

    :goto_35d
    if-gt v7, v8, :cond_155

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v1

    if-eqz v1, :cond_36d

    rsub-int/lit8 v1, v7, 0x8

    aget-object v1, v2, v1

    const/4 v9, 0x1

    iput-boolean v9, v1, Lb2/f;->d:Z

    goto :goto_36e

    :cond_36d
    const/4 v9, 0x1

    :goto_36e
    add-int/lit8 v7, v7, 0x1

    goto :goto_35d

    :pswitch_371
    move v3, v7

    move/from16 v16, v9

    const/4 v9, 0x1

    move v7, v9

    :goto_376
    if-gt v7, v8, :cond_156

    invoke-virtual {v6}, LZ0/v;->h()Z

    move-result v1

    if-eqz v1, :cond_399

    rsub-int/lit8 v1, v7, 0x8

    aget-object v1, v2, v1

    iget-object v4, v1, Lb2/f;->a:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    iget-object v4, v1, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v4}, Landroid/text/SpannableStringBuilder;->clear()V

    const/4 v4, -0x1

    iput v4, v1, Lb2/f;->o:I

    iput v4, v1, Lb2/f;->p:I

    iput v4, v1, Lb2/f;->q:I

    iput v4, v1, Lb2/f;->s:I

    const/4 v11, 0x0

    iput v11, v1, Lb2/f;->u:I

    goto :goto_39a

    :cond_399
    const/4 v11, 0x0

    :goto_39a
    add-int/lit8 v7, v7, 0x1

    goto :goto_376

    :pswitch_39d
    move v3, v7

    move/from16 v16, v9

    const/4 v9, 0x1

    const/4 v11, 0x0

    add-int/lit8 v12, v12, -0x80

    iget v1, v0, Lb2/h;->q:I

    if-eq v1, v12, :cond_3ae

    iput v12, v0, Lb2/h;->q:I

    aget-object v1, v2, v12

    iput-object v1, v0, Lb2/h;->m:Lb2/f;

    :cond_3ae
    :goto_3ae
    move v2, v9

    :goto_3af
    const/4 v1, 0x2

    const/4 v10, 0x6

    goto/16 :goto_142

    :cond_3b3
    move v3, v7

    move/from16 v16, v9

    const/16 v1, 0xff

    const/4 v9, 0x1

    const/4 v11, 0x0

    if-gt v12, v1, :cond_3c5

    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    and-int/lit16 v2, v12, 0xff

    int-to-char v2, v2

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_3ae

    :cond_3c5
    const-string v1, "Invalid base command: "

    invoke-static {v12, v1, v5}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    goto :goto_3af

    :cond_3cb
    move v3, v7

    move/from16 v16, v9

    const/4 v9, 0x1

    const/4 v11, 0x0

    invoke-virtual {v6, v8}, LZ0/v;->i(I)I

    move-result v7

    if-gt v7, v4, :cond_3f2

    const/4 v12, 0x7

    if-gt v7, v12, :cond_3db

    goto/16 :goto_507

    :cond_3db
    const/16 v1, 0xf

    if-gt v7, v1, :cond_3e4

    invoke-virtual {v6, v8}, LZ0/v;->h0(I)V

    goto/16 :goto_507

    :cond_3e4
    if-gt v7, v15, :cond_3eb

    invoke-virtual {v6, v10}, LZ0/v;->h0(I)V

    goto/16 :goto_507

    :cond_3eb
    if-gt v7, v4, :cond_507

    invoke-virtual {v6, v14}, LZ0/v;->h0(I)V

    goto/16 :goto_507

    :cond_3f2
    const/4 v12, 0x7

    const/16 v4, 0xa0

    if-gt v7, v1, :cond_50a

    const/16 v1, 0x20

    if-eq v7, v1, :cond_4ff

    const/16 v1, 0x21

    if-eq v7, v1, :cond_4f9

    const/16 v1, 0x25

    if-eq v7, v1, :cond_4f1

    const/16 v1, 0x2a

    if-eq v7, v1, :cond_4e9

    const/16 v1, 0x2c

    if-eq v7, v1, :cond_4e1

    const/16 v1, 0x3f

    if-eq v7, v1, :cond_4d9

    const/16 v1, 0x39

    if-eq v7, v1, :cond_4d1

    const/16 v1, 0x3a

    if-eq v7, v1, :cond_4c9

    const/16 v1, 0x3c

    if-eq v7, v1, :cond_4c1

    const/16 v1, 0x3d

    if-eq v7, v1, :cond_4b9

    packed-switch v7, :pswitch_data_5b6

    packed-switch v7, :pswitch_data_5c6

    const-string v1, "Invalid G2 character: "

    invoke-static {v7, v1, v5}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_506

    :pswitch_42c
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x250c

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_435
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2518

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_43e
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2500

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_447
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2514

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_450
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2510

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_459
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2502

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_462
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x215e

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_46b
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x215d

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_474
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x215c

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_47d
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x215b

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_486
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2022

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_48f
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x201d

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_498
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x201c

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto/16 :goto_506

    :pswitch_4a1
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2019

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :pswitch_4a9
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2018

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :pswitch_4b1
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2588

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4b9
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2120

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4c1
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x153

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4c9
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x161

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4d1
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2122

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4d9
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x178

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4e1
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x152

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4e9
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x160

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4f1
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v2, 0x2026

    invoke-virtual {v1, v2}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4f9
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    invoke-virtual {v1, v4}, Lb2/f;->a(C)V

    goto :goto_506

    :cond_4ff
    iget-object v1, v0, Lb2/h;->m:Lb2/f;

    const/16 v10, 0x20

    invoke-virtual {v1, v10}, Lb2/f;->a(C)V

    :goto_506
    move v2, v9

    :cond_507
    :goto_507
    const/4 v1, 0x2

    const/4 v10, 0x6

    goto :goto_553

    :cond_50a
    const/16 v10, 0x20

    if-gt v7, v13, :cond_530

    const/16 v1, 0x87

    if-gt v7, v1, :cond_516

    invoke-virtual {v6, v10}, LZ0/v;->h0(I)V

    goto :goto_507

    :cond_516
    const/16 v1, 0x8f

    if-gt v7, v1, :cond_520

    const/16 v1, 0x28

    invoke-virtual {v6, v1}, LZ0/v;->h0(I)V

    goto :goto_507

    :cond_520
    if-gt v7, v13, :cond_507

    const/4 v1, 0x2

    invoke-virtual {v6, v1}, LZ0/v;->h0(I)V

    const/4 v10, 0x6

    invoke-virtual {v6, v10}, LZ0/v;->i(I)I

    move-result v4

    mul-int/2addr v4, v8

    invoke-virtual {v6, v4}, LZ0/v;->h0(I)V

    goto :goto_553

    :cond_530
    const/4 v1, 0x2

    const/16 v8, 0xff

    const/4 v10, 0x6

    if-gt v7, v8, :cond_54e

    if-ne v7, v4, :cond_540

    iget-object v2, v0, Lb2/h;->m:Lb2/f;

    const/16 v4, 0x33c4

    invoke-virtual {v2, v4}, Lb2/f;->a(C)V

    goto :goto_54c

    :cond_540
    const-string v2, "Invalid G3 character: "

    invoke-static {v7, v2, v5}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    iget-object v2, v0, Lb2/h;->m:Lb2/f;

    const/16 v4, 0x5f

    invoke-virtual {v2, v4}, Lb2/f;->a(C)V

    :goto_54c
    move v2, v9

    goto :goto_553

    :cond_54e
    const-string v4, "Invalid extended command: "

    invoke-static {v7, v4, v5}, LA8/z;->m(ILjava/lang/String;Ljava/lang/String;)V

    :goto_553
    move v7, v3

    move v4, v9

    move v11, v12

    move/from16 v9, v16

    move v3, v1

    goto/16 :goto_a0

    :cond_55b
    :goto_55b
    if-eqz v2, :cond_563

    invoke-virtual/range {p0 .. p0}, Lb2/h;->l()Ljava/util/List;

    move-result-object v1

    iput-object v1, v0, Lb2/h;->n:Ljava/util/List;

    :cond_563
    const/4 v1, 0x0

    iput-object v1, v0, Lb2/h;->p:Lb2/g;

    return-void

    nop

    :pswitch_data_568
    .packed-switch 0xc
        :pswitch_107
        :pswitch_101
        :pswitch_121
    .end packed-switch

    :pswitch_data_572
    .packed-switch 0x80
        :pswitch_39d
        :pswitch_39d
        :pswitch_39d
        :pswitch_39d
        :pswitch_39d
        :pswitch_39d
        :pswitch_39d
        :pswitch_39d
        :pswitch_371
        :pswitch_359
        :pswitch_343
        :pswitch_32a
        :pswitch_314
        :pswitch_30c
        :pswitch_152
        :pswitch_304
        :pswitch_2d7
        :pswitch_287
        :pswitch_260
        :pswitch_14d
        :pswitch_14d
        :pswitch_14d
        :pswitch_14d
        :pswitch_210
        :pswitch_159
        :pswitch_159
        :pswitch_159
        :pswitch_159
        :pswitch_159
        :pswitch_159
        :pswitch_159
        :pswitch_159
    .end packed-switch

    :pswitch_data_5b6
    .packed-switch 0x30
        :pswitch_4b1
        :pswitch_4a9
        :pswitch_4a1
        :pswitch_498
        :pswitch_48f
        :pswitch_486
    .end packed-switch

    :pswitch_data_5c6
    .packed-switch 0x76
        :pswitch_47d
        :pswitch_474
        :pswitch_46b
        :pswitch_462
        :pswitch_459
        :pswitch_450
        :pswitch_447
        :pswitch_43e
        :pswitch_435
        :pswitch_42c
    .end packed-switch
.end method

.method public final l()Ljava/util/List;
    .registers 18

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    :goto_7
    const/16 v3, 0x8

    if-ge v2, v3, :cond_f4

    move-object/from16 v3, p0

    iget-object v4, v3, Lb2/h;->l:[Lb2/f;

    aget-object v5, v4, v2

    iget-boolean v6, v5, Lb2/f;->c:Z

    if-eqz v6, :cond_f0

    iget-object v6, v5, Lb2/f;->a:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_27

    iget-object v5, v5, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v5}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v5

    if-nez v5, :cond_27

    goto/16 :goto_f0

    :cond_27
    aget-object v4, v4, v2

    iget-boolean v5, v4, Lb2/f;->d:Z

    if-eqz v5, :cond_f0

    iget-boolean v5, v4, Lb2/f;->c:Z

    if-eqz v5, :cond_ea

    iget-object v5, v4, Lb2/f;->a:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_43

    iget-object v6, v4, Lb2/f;->b:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v6}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v6

    if-nez v6, :cond_43

    goto/16 :goto_ea

    :cond_43
    new-instance v8, Landroid/text/SpannableStringBuilder;

    invoke-direct {v8}, Landroid/text/SpannableStringBuilder;-><init>()V

    move v6, v1

    :goto_49
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_60

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v8, v7}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/16 v7, 0xa

    invoke-virtual {v8, v7}, Landroid/text/SpannableStringBuilder;->append(C)Landroid/text/SpannableStringBuilder;

    add-int/lit8 v6, v6, 0x1

    goto :goto_49

    :cond_60
    invoke-virtual {v4}, Lb2/f;->b()Landroid/text/SpannableString;

    move-result-object v5

    invoke-virtual {v8, v5}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    iget v5, v4, Lb2/f;->k:I

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v5, :cond_92

    if-eq v5, v6, :cond_8f

    if-eq v5, v7, :cond_8b

    const/4 v9, 0x3

    if-ne v5, v9, :cond_75

    goto :goto_92

    :cond_75
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unexpected justification value: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, v4, Lb2/f;->k:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8b
    sget-object v5, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    :goto_8d
    move-object v9, v5

    goto :goto_95

    :cond_8f
    sget-object v5, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    goto :goto_8d

    :cond_92
    :goto_92
    sget-object v5, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    goto :goto_8d

    :goto_95
    iget-boolean v5, v4, Lb2/f;->f:Z

    if-eqz v5, :cond_a4

    iget v5, v4, Lb2/f;->h:I

    int-to-float v5, v5

    const/high16 v10, 0x42c60000    # 99.0f

    div-float/2addr v5, v10

    iget v11, v4, Lb2/f;->g:I

    int-to-float v11, v11

    div-float/2addr v11, v10

    goto :goto_b1

    :cond_a4
    iget v5, v4, Lb2/f;->h:I

    int-to-float v5, v5

    const/high16 v10, 0x43510000    # 209.0f

    div-float/2addr v5, v10

    iget v10, v4, Lb2/f;->g:I

    int-to-float v10, v10

    const/high16 v11, 0x42940000    # 74.0f

    div-float v11, v10, v11

    :goto_b1
    const v10, 0x3f666666    # 0.9f

    mul-float/2addr v5, v10

    const v12, 0x3d4ccccd    # 0.05f

    add-float/2addr v5, v12

    mul-float/2addr v11, v10

    add-float v10, v11, v12

    iget v11, v4, Lb2/f;->i:I

    div-int/lit8 v12, v11, 0x3

    if-nez v12, :cond_c4

    move v12, v1

    goto :goto_c9

    :cond_c4
    if-ne v12, v6, :cond_c8

    move v12, v6

    goto :goto_c9

    :cond_c8
    move v12, v7

    :goto_c9
    rem-int/lit8 v11, v11, 0x3

    if-nez v11, :cond_cf

    move v13, v1

    goto :goto_d4

    :cond_cf
    if-ne v11, v6, :cond_d3

    move v13, v6

    goto :goto_d4

    :cond_d3
    move v13, v7

    :goto_d4
    iget v15, v4, Lb2/f;->n:I

    sget v7, Lb2/f;->w:I

    if-eq v15, v7, :cond_dc

    move v14, v6

    goto :goto_dd

    :cond_dc
    move v14, v1

    :goto_dd
    new-instance v6, Lb2/e;

    iget v4, v4, Lb2/f;->e:I

    move-object v7, v6

    move v11, v12

    move v12, v5

    move/from16 v16, v4

    invoke-direct/range {v7 .. v16}, Lb2/e;-><init>(Landroid/text/SpannableStringBuilder;Landroid/text/Layout$Alignment;FIFIZII)V

    goto :goto_eb

    :cond_ea
    :goto_ea
    const/4 v6, 0x0

    :goto_eb
    if-eqz v6, :cond_f0

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_f0
    :goto_f0
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_7

    :cond_f4
    move-object/from16 v3, p0

    sget-object v2, Lb2/e;->c:Lb2/d;

    invoke-static {v0, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    new-instance v2, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    :goto_104
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_118

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lb2/e;

    iget-object v4, v4, Lb2/e;->a:LY0/b;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_104

    :cond_118
    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final m()V
    .registers 3

    const/4 v0, 0x0

    :goto_1
    const/16 v1, 0x8

    if-ge v0, v1, :cond_f

    iget-object v1, p0, Lb2/h;->l:[Lb2/f;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Lb2/f;->d()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_f
    return-void
.end method
