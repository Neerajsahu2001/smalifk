.class public final synthetic Lb2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lb2/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 7

    iget v0, p0, Lb2/d;->a:I

    packed-switch v0, :pswitch_data_6c

    check-cast p1, Ly1/E;

    check-cast p2, Ly1/E;

    iget p1, p1, Ly1/E;->c:F

    iget p2, p2, Ly1/E;->c:F

    invoke-static {p1, p2}, Ljava/lang/Float;->compare(FF)I

    move-result p1

    return p1

    :pswitch_12
    check-cast p1, Landroid/util/Size;

    check-cast p2, Landroid/util/Size;

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result v0

    int-to-long v0, v0

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result p1

    int-to-long v2, p1

    mul-long/2addr v0, v2

    invoke-virtual {p2}, Landroid/util/Size;->getWidth()I

    move-result p1

    int-to-long v2, p1

    invoke-virtual {p2}, Landroid/util/Size;->getHeight()I

    move-result p1

    int-to-long p1, p1

    mul-long/2addr v2, p1

    sub-long/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Long;->signum(J)I

    move-result p1

    return p1

    :pswitch_32
    check-cast p1, [B

    check-cast p2, [B

    array-length v0, p1

    array-length v1, p2

    if-eq v0, v1, :cond_3e

    array-length p1, p1

    array-length p2, p2

    sub-int/2addr p1, p2

    goto :goto_50

    :cond_3e
    const/4 v0, 0x0

    move v1, v0

    :goto_40
    array-length v2, p1

    if-ge v1, v2, :cond_4f

    aget-byte v2, p1, v1

    aget-byte v3, p2, v1

    if-eq v2, v3, :cond_4c

    sub-int p1, v2, v3

    goto :goto_50

    :cond_4c
    add-int/lit8 v1, v1, 0x1

    goto :goto_40

    :cond_4f
    move p1, v0

    :goto_50
    return p1

    :pswitch_51
    check-cast p1, Li2/c;

    check-cast p2, Li2/c;

    iget-wide v0, p1, Li2/c;->b:J

    iget-wide p1, p2, Li2/c;->b:J

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->compare(JJ)I

    move-result p1

    return p1

    :pswitch_5e
    check-cast p1, Lb2/e;

    check-cast p2, Lb2/e;

    iget p2, p2, Lb2/e;->b:I

    iget p1, p1, Lb2/e;->b:I

    invoke-static {p2, p1}, Ljava/lang/Integer;->compare(II)I

    move-result p1

    return p1

    nop

    :pswitch_data_6c
    .packed-switch 0x0
        :pswitch_5e
        :pswitch_51
        :pswitch_32
        :pswitch_12
    .end packed-switch
.end method
