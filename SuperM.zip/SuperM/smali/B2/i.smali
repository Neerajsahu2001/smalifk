.class public final Lb2/i;
.super La2/i;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# instance fields
.field public l:J


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .registers 11

    check-cast p1, Lb2/i;

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, LX1/c;->f(I)Z

    move-result v1

    invoke-virtual {p1, v0}, LX1/c;->f(I)Z

    move-result v2

    const/4 v3, -0x1

    const/4 v4, 0x1

    if-eq v1, v2, :cond_17

    invoke-virtual {p0, v0}, LX1/c;->f(I)Z

    move-result p1

    if-eqz p1, :cond_32

    :goto_15
    move v3, v4

    goto :goto_32

    :cond_17
    iget-wide v0, p0, Lf1/f;->g:J

    iget-wide v5, p1, Lf1/f;->g:J

    sub-long/2addr v0, v5

    const-wide/16 v5, 0x0

    cmp-long v2, v0, v5

    if-nez v2, :cond_2d

    iget-wide v0, p0, Lb2/i;->l:J

    iget-wide v7, p1, Lb2/i;->l:J

    sub-long/2addr v0, v7

    cmp-long p1, v0, v5

    if-nez p1, :cond_2d

    const/4 v3, 0x0

    goto :goto_32

    :cond_2d
    cmp-long p1, v0, v5

    if-lez p1, :cond_32

    goto :goto_15

    :cond_32
    :goto_32
    return v3
.end method
