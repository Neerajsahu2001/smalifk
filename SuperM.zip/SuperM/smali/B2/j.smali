.class public abstract Lb2/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/e;


# instance fields
.field public final a:Ljava/util/ArrayDeque;

.field public final b:Ljava/util/ArrayDeque;

.field public final c:Ljava/util/PriorityQueue;

.field public d:Lb2/i;

.field public e:J

.field public f:J

.field public g:J


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lb2/j;->a:Ljava/util/ArrayDeque;

    const/4 v0, 0x0

    move v1, v0

    :goto_c
    const/16 v2, 0xa

    if-ge v1, v2, :cond_1e

    iget-object v2, p0, Lb2/j;->a:Ljava/util/ArrayDeque;

    new-instance v3, Lb2/i;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Lf1/f;-><init>(I)V

    invoke-virtual {v2, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_c

    :cond_1e
    new-instance v1, Ljava/util/ArrayDeque;

    invoke-direct {v1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v1, p0, Lb2/j;->b:Ljava/util/ArrayDeque;

    :goto_25
    const/4 v1, 0x2

    if-ge v0, v1, :cond_3d

    iget-object v1, p0, Lb2/j;->b:Ljava/util/ArrayDeque;

    new-instance v2, La2/c;

    new-instance v3, LI1/a;

    const/4 v4, 0x5

    invoke-direct {v3, v4, p0}, LI1/a;-><init>(ILjava/lang/Object;)V

    invoke-direct {v2}, La2/c;-><init>()V

    iput-object v3, v2, La2/c;->h:Ljava/lang/Object;

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_25

    :cond_3d
    new-instance v0, Ljava/util/PriorityQueue;

    invoke-direct {v0}, Ljava/util/PriorityQueue;-><init>()V

    iput-object v0, p0, Lb2/j;->c:Ljava/util/PriorityQueue;

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v0, p0, Lb2/j;->g:J

    return-void
.end method


# virtual methods
.method public a()V
    .registers 1

    return-void
.end method

.method public final b(J)V
    .registers 3

    iput-wide p1, p0, Lb2/j;->g:J

    return-void
.end method

.method public final c(J)V
    .registers 3

    iput-wide p1, p0, Lb2/j;->e:J

    return-void
.end method

.method public bridge synthetic d()Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0}, Lb2/j;->i()La2/c;

    move-result-object v0

    return-object v0
.end method

.method public final e()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lb2/j;->d:Lb2/i;

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    invoke-static {v0}, Lm7/u;->e(Z)V

    iget-object v0, p0, Lb2/j;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_14

    const/4 v0, 0x0

    goto :goto_1c

    :cond_14
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lb2/i;

    iput-object v0, p0, Lb2/j;->d:Lb2/i;

    :goto_1c
    return-object v0
.end method

.method public final f(La2/i;)V
    .registers 6

    iget-object v0, p0, Lb2/j;->d:Lb2/i;

    if-ne p1, v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    invoke-static {v0}, Lm7/u;->a(Z)V

    check-cast p1, Lb2/i;

    iget-wide v0, p0, Lb2/j;->g:J

    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v2, v0, v2

    if-eqz v2, :cond_26

    iget-wide v2, p1, Lf1/f;->g:J

    cmp-long v0, v2, v0

    if-gez v0, :cond_26

    invoke-virtual {p1}, Lf1/f;->o()V

    iget-object v0, p0, Lb2/j;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_34

    :cond_26
    iget-wide v0, p0, Lb2/j;->f:J

    const-wide/16 v2, 0x1

    add-long/2addr v2, v0

    iput-wide v2, p0, Lb2/j;->f:J

    iput-wide v0, p1, Lb2/i;->l:J

    iget-object v0, p0, Lb2/j;->c:Ljava/util/PriorityQueue;

    invoke-virtual {v0, p1}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    :goto_34
    const/4 p1, 0x0

    iput-object p1, p0, Lb2/j;->d:Lb2/i;

    return-void
.end method

.method public flush()V
    .registers 4

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lb2/j;->f:J

    iput-wide v0, p0, Lb2/j;->e:J

    :goto_6
    iget-object v0, p0, Lb2/j;->c:Ljava/util/PriorityQueue;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v1

    iget-object v2, p0, Lb2/j;->a:Ljava/util/ArrayDeque;

    if-nez v1, :cond_1f

    invoke-virtual {v0}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lb2/i;

    sget v1, LZ0/F;->a:I

    invoke-virtual {v0}, Lf1/f;->o()V

    invoke-virtual {v2, v0}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_6

    :cond_1f
    iget-object v0, p0, Lb2/j;->d:Lb2/i;

    if-eqz v0, :cond_2c

    invoke-virtual {v0}, Lf1/f;->o()V

    invoke-virtual {v2, v0}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    const/4 v0, 0x0

    iput-object v0, p0, Lb2/j;->d:Lb2/i;

    :cond_2c
    return-void
.end method

.method public abstract g()LA1/b;
.end method

.method public abstract h(Lb2/i;)V
.end method

.method public i()La2/c;
    .registers 8

    iget-object v0, p0, Lb2/j;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_a

    return-object v2

    :cond_a
    :goto_a
    iget-object v1, p0, Lb2/j;->c:Ljava/util/PriorityQueue;

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_6a

    invoke-virtual {v1}, Ljava/util/PriorityQueue;->peek()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lb2/i;

    sget v4, LZ0/F;->a:I

    iget-wide v3, v3, Lf1/f;->g:J

    iget-wide v5, p0, Lb2/j;->e:J

    cmp-long v3, v3, v5

    if-gtz v3, :cond_6a

    invoke-virtual {v1}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lb2/i;

    const/4 v3, 0x4

    invoke-virtual {v1, v3}, LX1/c;->f(I)Z

    move-result v4

    iget-object v5, p0, Lb2/j;->a:Ljava/util/ArrayDeque;

    if-eqz v4, :cond_41

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La2/c;

    invoke-virtual {v0, v3}, LX1/c;->b(I)V

    invoke-virtual {v1}, Lf1/f;->o()V

    invoke-virtual {v5, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    return-object v0

    :cond_41
    invoke-virtual {p0, v1}, Lb2/j;->h(Lb2/i;)V

    invoke-virtual {p0}, Lb2/j;->j()Z

    move-result v3

    if-eqz v3, :cond_63

    invoke-virtual {p0}, Lb2/j;->g()LA1/b;

    move-result-object v2

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La2/c;

    iget-wide v3, v1, Lf1/f;->g:J

    iput-wide v3, v0, Lf1/g;->c:J

    iput-object v2, v0, La2/c;->e:La2/d;

    iput-wide v3, v0, La2/c;->f:J

    invoke-virtual {v1}, Lf1/f;->o()V

    invoke-virtual {v5, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    return-object v0

    :cond_63
    invoke-virtual {v1}, Lf1/f;->o()V

    invoke-virtual {v5, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_a

    :cond_6a
    return-object v2
.end method

.method public abstract j()Z
.end method
