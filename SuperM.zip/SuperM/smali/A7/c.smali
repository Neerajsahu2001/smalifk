.class public final LA7/c;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public a:Z

.field public final synthetic b:Landroidx/appcompat/widget/ActionMenuView;

.field public final synthetic c:I

.field public final synthetic d:Z

.field public final synthetic e:Lcom/google/android/material/bottomappbar/BottomAppBar;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroidx/appcompat/widget/ActionMenuView;IZ)V
    .registers 5

    iput-object p1, p0, LA7/c;->e:Lcom/google/android/material/bottomappbar/BottomAppBar;

    iput-object p2, p0, LA7/c;->b:Landroidx/appcompat/widget/ActionMenuView;

    iput p3, p0, LA7/c;->c:I

    iput-boolean p4, p0, LA7/c;->d:Z

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .registers 2

    const/4 p1, 0x1

    iput-boolean p1, p0, LA7/c;->a:Z

    return-void
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .registers 5

    iget-boolean p1, p0, LA7/c;->a:Z

    if-nez p1, :cond_12

    iget-object p1, p0, LA7/c;->e:Lcom/google/android/material/bottomappbar/BottomAppBar;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v0, p0, LA7/c;->c:I

    iget-boolean v1, p0, LA7/c;->d:Z

    iget-object v2, p0, LA7/c;->b:Landroidx/appcompat/widget/ActionMenuView;

    invoke-virtual {p1, v2, v0, v1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->L(Landroidx/appcompat/widget/ActionMenuView;IZ)V

    :cond_12
    return-void
.end method
