.class public final LA7/d;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LA7/d;->a:I

    iput-object p2, p0, LA7/d;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .registers 4

    iget v0, p0, LA7/d;->a:I

    packed-switch v0, :pswitch_data_28

    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationEnd(Landroid/animation/Animator;)V

    return-void

    :pswitch_9
    iget-object p1, p0, LA7/d;->b:Ljava/lang/Object;

    check-cast p1, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;

    const/4 v0, 0x0

    iput-object v0, p1, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->d:Landroid/view/ViewPropertyAnimator;

    return-void

    :pswitch_11
    iget-object p1, p0, LA7/d;->b:Ljava/lang/Object;

    check-cast p1, Landroidx/media3/ui/A;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/media3/ui/A;->h(I)V

    return-void

    :pswitch_1a
    iget-object v0, p0, LA7/d;->b:Ljava/lang/Object;

    check-cast v0, LW2/D;

    iget-object v1, v0, LW2/D;->b:Ljava/lang/Object;

    check-cast v1, Landroid/animation/ValueAnimator;

    if-ne v1, p1, :cond_27

    const/4 p1, 0x0

    iput-object p1, v0, LW2/D;->b:Ljava/lang/Object;

    :cond_27
    return-void

    :pswitch_data_28
    .packed-switch 0x1
        :pswitch_1a
        :pswitch_11
        :pswitch_9
    .end packed-switch
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .registers 4

    iget v0, p0, LA7/d;->a:I

    packed-switch v0, :pswitch_data_32

    :pswitch_5
    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationStart(Landroid/animation/Animator;)V

    return-void

    :pswitch_9
    iget-object p1, p0, LA7/d;->b:Ljava/lang/Object;

    check-cast p1, Landroidx/media3/ui/A;

    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Landroidx/media3/ui/A;->h(I)V

    return-void

    :pswitch_12
    iget-object v0, p0, LA7/d;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/material/bottomappbar/BottomAppBar;

    iget-object v1, v0, Lcom/google/android/material/bottomappbar/BottomAppBar;->g1:LA7/a;

    invoke-virtual {v1, p1}, LA7/a;->onAnimationStart(Landroid/animation/Animator;)V

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->E()Landroid/view/View;

    move-result-object p1

    instance-of v1, p1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    if-eqz v1, :cond_26

    check-cast p1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    goto :goto_27

    :cond_26
    const/4 p1, 0x0

    :goto_27
    if-eqz p1, :cond_30

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->G()F

    move-result v0

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setTranslationX(F)V

    :cond_30
    return-void

    nop

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_12
        :pswitch_5
        :pswitch_9
    .end packed-switch
.end method
