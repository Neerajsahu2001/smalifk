.class public final LA7/b;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LA7/b;->a:I

    iput-object p2, p0, LA7/b;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .registers 5

    const/4 v0, 0x0

    iget-object v1, p0, LA7/b;->b:Ljava/lang/Object;

    iget v2, p0, LA7/b;->a:I

    packed-switch v2, :pswitch_data_20

    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationEnd(Landroid/animation/Animator;)V

    return-void

    :pswitch_c
    sget-object p1, Landroidx/core/view/g0;->a:Ljava/util/WeakHashMap;

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->setClipBounds(Landroid/graphics/Rect;)V

    return-void

    :pswitch_14
    check-cast v1, Lcom/google/android/material/bottomappbar/BottomAppBar;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p1, 0x0

    iput-boolean p1, v1, Lcom/google/android/material/bottomappbar/BottomAppBar;->a1:Z

    iput-object v0, v1, Lcom/google/android/material/bottomappbar/BottomAppBar;->U0:Landroid/animation/Animator;

    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_14
        :pswitch_c
    .end packed-switch
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .registers 3

    iget v0, p0, LA7/b;->a:I

    packed-switch v0, :pswitch_data_36

    :pswitch_5
    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationStart(Landroid/animation/Animator;)V

    return-void

    :pswitch_9
    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationStart(Landroid/animation/Animator;)V

    iget-object p1, p0, LA7/b;->b:Ljava/lang/Object;

    check-cast p1, LQ7/k;

    iget-object v0, p1, LQ7/k;->f:Ljava/util/ArrayList;

    if-eqz v0, :cond_2c

    iget-boolean p1, p1, LQ7/k;->g:Z

    if-nez p1, :cond_2c

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1c
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LG2/a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_1c

    :cond_2c
    return-void

    :pswitch_2d
    iget-object p1, p0, LA7/b;->b:Ljava/lang/Object;

    check-cast p1, Lcom/google/android/material/bottomappbar/BottomAppBar;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    nop

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_2d
        :pswitch_5
        :pswitch_9
    .end packed-switch
.end method
