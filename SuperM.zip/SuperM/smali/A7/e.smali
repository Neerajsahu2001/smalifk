.class public final LA7/e;
.super LU7/e;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public b:F

.field public c:F

.field public d:F

.field public e:F

.field public f:F

.field public g:F


# virtual methods
.method public final i(FFFLU7/v;)V
    .registers 30

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p3

    move-object/from16 v9, p4

    iget v3, v0, LA7/e;->d:F

    const/4 v10, 0x0

    cmpl-float v4, v3, v10

    if-nez v4, :cond_13

    invoke-virtual {v9, v1, v10}, LU7/v;->d(FF)V

    return-void

    :cond_13
    iget v11, v0, LA7/e;->c:F

    const/high16 v12, 0x40000000    # 2.0f

    mul-float v4, v11, v12

    add-float/2addr v4, v3

    div-float v13, v4, v12

    iget v4, v0, LA7/e;->b:F

    mul-float v14, v2, v4

    iget v4, v0, LA7/e;->f:F

    add-float v15, p2, v4

    iget v4, v0, LA7/e;->e:F

    mul-float/2addr v4, v2

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v5, v2, v13, v4}, Le/b;->f(FFFF)F

    move-result v4

    div-float v6, v4, v13

    cmpl-float v5, v6, v5

    if-ltz v5, :cond_37

    invoke-virtual {v9, v1, v10}, LU7/v;->d(FF)V

    return-void

    :cond_37
    iget v5, v0, LA7/e;->g:F

    mul-float v16, v5, v2

    const/high16 v2, -0x40800000    # -1.0f

    cmpl-float v2, v5, v2

    if-eqz v2, :cond_53

    mul-float/2addr v5, v12

    sub-float/2addr v5, v3

    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const v3, 0x3dcccccd    # 0.1f

    cmpg-float v2, v2, v3

    if-gez v2, :cond_4f

    goto :goto_53

    :cond_4f
    const/4 v2, 0x0

    :goto_50
    move/from16 v17, v2

    goto :goto_55

    :cond_53
    :goto_53
    const/4 v2, 0x1

    goto :goto_50

    :goto_55
    if-nez v17, :cond_5c

    const/high16 v2, 0x3fe00000    # 1.75f

    move/from16 v18, v10

    goto :goto_5f

    :cond_5c
    move/from16 v18, v4

    move v2, v10

    :goto_5f
    add-float v3, v13, v14

    mul-float/2addr v3, v3

    add-float v4, v18, v14

    mul-float v5, v4, v4

    sub-float/2addr v3, v5

    float-to-double v5, v3

    invoke-static {v5, v6}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v5

    double-to-float v3, v5

    sub-float v5, v15, v3

    add-float v19, v15, v3

    div-float/2addr v3, v4

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->atan(D)D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Math;->toDegrees(D)D

    move-result-wide v3

    double-to-float v8, v3

    const/high16 v3, 0x42b40000    # 90.0f

    sub-float/2addr v3, v8

    add-float v20, v3, v2

    invoke-virtual {v9, v5, v10}, LU7/v;->d(FF)V

    sub-float v3, v5, v14

    add-float/2addr v5, v14

    mul-float v21, v14, v12

    const/high16 v7, 0x43870000    # 270.0f

    const/4 v4, 0x0

    move-object/from16 v2, p4

    move/from16 v6, v21

    move/from16 v22, v8

    invoke-virtual/range {v2 .. v8}, LU7/v;->a(FFFFFF)V

    const/high16 v2, 0x43340000    # 180.0f

    if-eqz v17, :cond_ae

    sub-float v3, v15, v13

    neg-float v4, v13

    sub-float v4, v4, v18

    add-float v5, v15, v13

    sub-float v6, v13, v18

    sub-float v7, v2, v20

    mul-float v20, v20, v12

    sub-float v8, v20, v2

    move-object/from16 v2, p4

    invoke-virtual/range {v2 .. v8}, LU7/v;->a(FFFFFF)V

    goto :goto_e8

    :cond_ae
    mul-float v3, v16, v12

    add-float v17, v3, v11

    sub-float v3, v15, v13

    add-float v8, v16, v11

    neg-float v7, v8

    add-float v5, v3, v17

    sub-float v18, v2, v20

    mul-float v4, v20, v12

    sub-float/2addr v4, v2

    div-float v23, v4, v12

    move-object/from16 v2, p4

    move v4, v7

    move v6, v8

    move/from16 v24, v7

    move/from16 v7, v18

    move v10, v8

    move/from16 v8, v23

    invoke-virtual/range {v2 .. v8}, LU7/v;->a(FFFFFF)V

    add-float v5, v15, v13

    div-float/2addr v11, v12

    add-float v11, v11, v16

    sub-float v2, v5, v11

    invoke-virtual {v9, v2, v10}, LU7/v;->d(FF)V

    sub-float v3, v5, v17

    const/high16 v2, -0x3d4c0000    # -90.0f

    add-float v8, v20, v2

    const/high16 v7, 0x42b40000    # 90.0f

    move-object/from16 v2, p4

    move/from16 v4, v24

    move v6, v10

    invoke-virtual/range {v2 .. v8}, LU7/v;->a(FFFFFF)V

    :goto_e8
    sub-float v3, v19, v14

    add-float v5, v19, v14

    const/high16 v2, 0x43870000    # 270.0f

    sub-float v7, v2, v22

    const/4 v4, 0x0

    move-object/from16 v2, p4

    move/from16 v6, v21

    move/from16 v8, v22

    invoke-virtual/range {v2 .. v8}, LU7/v;->a(FFFFFF)V

    const/4 v2, 0x0

    invoke-virtual {v9, v1, v2}, LU7/v;->d(FF)V

    return-void
.end method
