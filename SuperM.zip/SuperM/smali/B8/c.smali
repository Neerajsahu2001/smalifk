.class public final LB8/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lw8/b;


# instance fields
.field public final a:LB8/b;


# direct methods
.method public constructor <init>(LB8/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB8/c;->a:LB8/b;

    return-void
.end method


# virtual methods
.method public final a(I[B)[B
    .registers 6

    if-lez p1, :cond_2c

    iget-object v0, p0, LB8/c;->a:LB8/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, LB8/a;

    invoke-direct {v1, v0, p2}, LB8/a;-><init>(LB8/b;[B)V

    :try_start_c
    new-array p2, p1, [B

    const/4 v0, 0x0

    :goto_f
    if-ge v0, p1, :cond_25

    sub-int v2, p1, v0

    invoke-virtual {v1, p2, v0, v2}, LB8/a;->read([BII)I

    move-result v2

    if-lez v2, :cond_1b

    add-int/2addr v0, v2

    goto :goto_f

    :cond_1b
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string p2, "Provided StreamingPrf terminated before providing requested number of bytes."

    invoke-direct {p1, p2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_23
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_23} :catch_23

    :catch_23
    move-exception p1

    goto :goto_26

    :cond_25
    return-object p2

    :goto_26
    new-instance p2, Ljava/security/GeneralSecurityException;

    invoke-direct {p2, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_2c
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string p2, "Invalid outputLength specified."

    invoke-direct {p1, p2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
