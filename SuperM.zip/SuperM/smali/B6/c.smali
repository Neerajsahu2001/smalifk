.class public abstract LB6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LQ4/a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LQ4/a;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, LQ4/a;-><init>(I)V

    sput-object v0, LB6/c;->a:LQ4/a;

    return-void
.end method
