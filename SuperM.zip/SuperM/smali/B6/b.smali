.class public abstract LB6/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LQ8/a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LQ8/a;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, LQ8/a;-><init>(I)V

    sput-object v0, LB6/b;->a:LQ8/a;

    return-void
.end method
