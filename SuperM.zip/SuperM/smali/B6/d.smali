.class public final LB6/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB6/a;


# virtual methods
.method public final a()J
    .registers 3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    return-wide v0
.end method
