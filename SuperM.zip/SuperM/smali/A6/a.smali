.class public final synthetic La6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/react/devsupport/interfaces/DevOptionHandler;


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Lcom/facebook/react/modules/debug/DevSettingsModule;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lcom/facebook/react/modules/debug/DevSettingsModule;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La6/a;->a:Ljava/lang/String;

    iput-object p2, p0, La6/a;->b:Lcom/facebook/react/modules/debug/DevSettingsModule;

    return-void
.end method


# virtual methods
.method public final onOptionSelected()V
    .registers 3

    iget-object v0, p0, La6/a;->a:Ljava/lang/String;

    iget-object v1, p0, La6/a;->b:Lcom/facebook/react/modules/debug/DevSettingsModule;

    invoke-static {v0, v1}, Lcom/facebook/react/modules/debug/DevSettingsModule;->a(Ljava/lang/String;Lcom/facebook/react/modules/debug/DevSettingsModule;)V

    return-void
.end method
