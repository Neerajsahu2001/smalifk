.class public interface abstract LA6/c;
.super Ljava/lang/Object;
.source "SourceFile"
