.class public final synthetic Lb3/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv7/b;
.implements LZ0/m;
.implements Lv7/d;
.implements Lio/sentry/F1;
.implements LA6/b;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, Lb3/y;->a:I

    iput-object p2, p0, Lb3/y;->b:Ljava/lang/Object;

    iput-object p3, p0, Lb3/y;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .registers 7

    check-cast p1, Lio/sentry/android/core/q;

    iget-object v0, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/cache/a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v1, p1, Lio/sentry/android/core/q;->d:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iget-object v1, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v1, Lio/sentry/android/core/SentryAndroidOptions;

    invoke-virtual {v1}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object v1

    sget-object v2, Lio/sentry/y1;->DEBUG:Lio/sentry/y1;

    const-string v3, "Writing last reported ANR marker with timestamp %d"

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object v4

    invoke-interface {v1, v2, v3, v4}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, v0, Lio/sentry/cache/c;->a:Lio/sentry/M1;

    invoke-virtual {v0}, Lio/sentry/M1;->getCacheDirPath()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_37

    invoke-virtual {v0}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object p1

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "Cache dir path is null, the ANR marker will not be written"

    invoke-interface {p1, v2, v1, v0}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_6e

    :cond_37
    new-instance v2, Ljava/io/File;

    const-string v3, "last_anr_report"

    invoke-direct {v2, v1, v3}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_3e
    new-instance v1, Ljava/io/FileOutputStream;

    invoke-direct {v1, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_43
    .catchall {:try_start_3e .. :try_end_43} :catchall_57

    :try_start_43
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    sget-object v2, Lio/sentry/cache/c;->g:Ljava/nio/charset/Charset;

    invoke-virtual {p1, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v1}, Ljava/io/OutputStream;->flush()V
    :try_end_53
    .catchall {:try_start_43 .. :try_end_53} :catchall_59

    :try_start_53
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_56
    .catchall {:try_start_53 .. :try_end_56} :catchall_57

    goto :goto_6e

    :catchall_57
    move-exception p1

    goto :goto_63

    :catchall_59
    move-exception p1

    :try_start_5a
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_5d
    .catchall {:try_start_5a .. :try_end_5d} :catchall_5e

    goto :goto_62

    :catchall_5e
    move-exception v1

    :try_start_5f
    invoke-virtual {p1, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_62
    throw p1
    :try_end_63
    .catchall {:try_start_5f .. :try_end_63} :catchall_57

    :goto_63
    invoke-virtual {v0}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object v0

    sget-object v1, Lio/sentry/y1;->ERROR:Lio/sentry/y1;

    const-string v2, "Error writing the ANR marker to the disk"

    invoke-interface {v0, v1, v2, p1}, Lio/sentry/ILogger;->j(Lio/sentry/y1;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_6e
    return-void
.end method

.method public b(Lio/sentry/s1;)Lio/sentry/s1;
    .registers 5

    iget-object v0, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v0, Lone/upswing/sdk/g2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Lio/sentry/s1;->u:Lio/sentry/y1;

    sget-object v1, Lio/sentry/y1;->DEBUG:Lio/sentry/y1;

    const/4 v2, 0x0

    if-eq v0, v1, :cond_44

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v1, "prodMaterialUIWithoutTink"

    invoke-virtual {v1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "this as java.lang.String).toUpperCase(Locale.ROOT)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "STAGE"

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_24

    goto :goto_44

    :cond_24
    iget-object v0, p1, Lio/sentry/s1;->t:LC/y0;

    if-nez v0, :cond_29

    goto :goto_2e

    :cond_29
    iget-object v0, v0, LC/y0;->b:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Ljava/util/ArrayList;

    :goto_2e
    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    const-string v0, "ICI"

    iget-object v1, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Lio/sentry/a1;->a(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Lio/sentry/protocol/I;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Lio/sentry/protocol/I;->b:Ljava/lang/String;

    iput-object v0, p1, Lio/sentry/a1;->i:Lio/sentry/protocol/I;

    goto :goto_45

    :cond_44
    :goto_44
    move-object p1, v2

    :goto_45
    return-object p1
.end method

.method public execute()Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v0, Ly6/f;

    iget-object v0, v0, Ly6/f;->c:Lz6/d;

    check-cast v0, Lz6/o;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_1a

    goto :goto_37

    :cond_1a
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "DELETE FROM events WHERE _id in "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Lz6/o;->G(Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lz6/o;->a()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    :goto_37
    const/4 v0, 0x0

    return-object v0
.end method

.method public f(Lv7/i;)Ljava/lang/Object;
    .registers 11

    const/4 v0, 0x1

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/core/app/NotificationCompat$Builder;

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    iget-object v2, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v2, Lapp/notifee/core/model/NotificationModel;

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->toBundle()Landroid/os/Bundle;

    move-result-object v3

    const-string v4, "notifee.notification"

    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v3, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v3, Landroid/os/Bundle;

    if-eqz v3, :cond_24

    const-string v4, "notifee.trigger"

    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_24
    iget-object v3, p1, Landroidx/core/app/NotificationCompat$Builder;->A:Landroid/os/Bundle;

    if-nez v3, :cond_30

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3, v1}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    iput-object v3, p1, Landroidx/core/app/NotificationCompat$Builder;->A:Landroid/os/Bundle;

    goto :goto_33

    :cond_30
    invoke-virtual {v3, v1}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    :goto_33
    invoke-virtual {p1}, Landroidx/core/app/NotificationCompat$Builder;->a()Landroid/app/Notification;

    move-result-object p1

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->a()Lapp/notifee/core/model/NotificationAndroidModel;

    move-result-object v3

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getLoopSound()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_53

    iget v4, p1, Landroid/app/Notification;->flags:I

    or-int/lit8 v4, v4, 0x4

    iput v4, p1, Landroid/app/Notification;->flags:I

    :cond_53
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getFlags()[I

    move-result-object v4

    if-eqz v4, :cond_71

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getFlags()[I

    move-result-object v4

    array-length v4, v4

    if-lez v4, :cond_71

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getFlags()[I

    move-result-object v4

    array-length v5, v4

    const/4 v6, 0x0

    :goto_66
    if-ge v6, v5, :cond_71

    aget v7, v4, v6

    iget v8, p1, Landroid/app/Notification;->flags:I

    or-int/2addr v7, v8

    iput v7, p1, Landroid/app/Notification;->flags:I

    add-int/2addr v6, v0

    goto :goto_66

    :cond_71
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getLightUpScreen()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_a0

    sget-object v4, Lm7/D2;->a:Landroid/content/Context;

    const-string v5, "power"

    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/PowerManager;

    invoke-virtual {v4}, Landroid/os/PowerManager;->isInteractive()Z

    move-result v5

    if-nez v5, :cond_a0

    const v5, 0x3000001a

    const-string v6, "Notifee:lock"

    invoke-virtual {v4, v5, v6}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v5

    invoke-virtual {v5}, Landroid/os/PowerManager$WakeLock;->acquire()V

    const-string v5, "Notifee:cpuLock"

    invoke-virtual {v4, v0, v5}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->acquire()V

    :cond_a0
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getAsForegroundService()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_d3

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->toBundle()Landroid/os/Bundle;

    move-result-object v0

    sget-object v3, Lapp/notifee/core/ForegroundService;->a:Ljava/lang/String;

    new-instance v3, Landroid/content/Intent;

    sget-object v4, Lm7/D2;->a:Landroid/content/Context;

    const-class v5, Lapp/notifee/core/ForegroundService;

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v4, "app.notifee.core.ForegroundService.START"

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const-string v4, "hashCode"

    invoke-virtual {v3, v4, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v1, "notification"

    invoke-virtual {v3, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const-string p1, "notificationBundle"

    invoke-virtual {v3, p1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    sget-object p1, Lm7/D2;->a:Landroid/content/Context;

    invoke-virtual {p1, v3}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_e1

    :cond_d3
    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    new-instance v4, Ld0/c0;

    invoke-direct {v4, v0}, Ld0/c0;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getTag()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0, v1, p1}, Ld0/c0;->a(Ljava/lang/String;ILandroid/app/Notification;)V

    :goto_e1
    new-instance p1, Lapp/notifee/core/event/NotificationEvent;

    const/4 v0, 0x3

    invoke-direct {p1, v0, v2}, Lapp/notifee/core/event/NotificationEvent;-><init>(ILapp/notifee/core/model/NotificationModel;)V

    invoke-static {p1}, Lte/d;->a(Ljava/lang/Object;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, Lb3/y;->a:I

    check-cast p1, Lg1/b;

    packed-switch v0, :pswitch_data_2e

    iget-object v0, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v1, LW0/e0;

    invoke-interface {p1, v0, v1}, Lg1/b;->q(Lg1/a;LW0/e0;)V

    iget p1, v1, LW0/e0;->a:I

    return-void

    :pswitch_15
    iget-object v0, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v1, Lt1/A;

    invoke-interface {p1, v0, v1}, Lg1/b;->k(Lg1/a;Lt1/A;)V

    return-void

    :pswitch_21
    iget-object v0, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v1, LW0/g;

    invoke-interface {p1, v0, v1}, Lg1/b;->w(Lg1/a;LW0/g;)V

    return-void

    nop

    :pswitch_data_2e
    .packed-switch 0x1
        :pswitch_21
        :pswitch_15
    .end packed-switch
.end method

.method public onComplete(Lv7/i;)V
    .registers 4

    iget-object v0, p0, Lb3/y;->b:Ljava/lang/Object;

    check-cast v0, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;

    iget-object v1, p0, Lb3/y;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/bridge/Promise;

    invoke-static {v0, v1, p1}, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;->e(Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;Lcom/facebook/react/bridge/Promise;Lv7/i;)V

    return-void
.end method
