.class public final synthetic Lb3/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lb3/h;->a:I

    iput-object p2, p0, Lb3/h;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 3

    iget v0, p0, Lb3/h;->a:I

    packed-switch v0, :pswitch_data_4c

    iget-object v0, p0, Lb3/h;->b:Ljava/lang/Object;

    check-cast v0, Loc/g;

    iget-object v0, v0, LQ7/l;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/analytics/FirebaseAnalytics;->resetAnalyticsData()V

    const/4 v0, 0x0

    return-object v0

    :pswitch_16
    iget-object v0, p0, Lb3/h;->b:Ljava/lang/Object;

    check-cast v0, Lw3/d;

    invoke-virtual {v0}, Lw3/d;->k()[B

    move-result-object v0

    return-object v0

    :pswitch_1f
    iget-object v0, p0, Lb3/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/runtime/ReactHostImpl;

    invoke-static {v0}, Lcom/facebook/react/runtime/ReactHostImpl;->C(Lcom/facebook/react/runtime/ReactHostImpl;)Lcom/facebook/react/runtime/internal/bolts/Task;

    move-result-object v0

    return-object v0

    :pswitch_28
    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    new-instance v1, Ld0/c0;

    invoke-direct {v1, v0}, Ld0/c0;-><init>(Landroid/content/Context;)V

    iget-object v0, v1, Ld0/c0;->b:Landroid/app/NotificationManager;

    iget-object v1, p0, Lb3/h;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Ld0/W;->i(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v0

    if-nez v0, :cond_3e

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_4b

    :cond_3e
    invoke-virtual {v0}, Landroid/app/NotificationChannel;->getImportance()I

    move-result v0

    if-nez v0, :cond_46

    const/4 v0, 0x1

    goto :goto_47

    :cond_46
    const/4 v0, 0x0

    :goto_47
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    :goto_4b
    return-object v0

    :pswitch_data_4c
    .packed-switch 0x0
        :pswitch_28
        :pswitch_1f
        :pswitch_16
    .end packed-switch
.end method
