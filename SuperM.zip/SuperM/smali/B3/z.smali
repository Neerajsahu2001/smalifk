.class public final synthetic Lb3/z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lb3/z;->a:I

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 4

    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    new-instance v1, Ld0/c0;

    invoke-direct {v1, v0}, Ld0/c0;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    iget v2, p0, Lb3/z;->a:I

    if-eq v2, v0, :cond_e

    if-nez v2, :cond_13

    :cond_e
    iget-object v0, v1, Ld0/c0;->b:Landroid/app/NotificationManager;

    invoke-virtual {v0}, Landroid/app/NotificationManager;->cancelAll()V

    :cond_13
    const/4 v0, 0x2

    if-eq v2, v0, :cond_18

    if-nez v2, :cond_32

    :cond_18
    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {v0}, LO2/A;->c(Landroid/content/Context;)LO2/A;

    move-result-object v0

    new-instance v1, LX2/c;

    invoke-direct {v1, v0}, LX2/c;-><init>(LO2/A;)V

    iget-object v2, v0, LO2/A;->d:LZ2/a;

    invoke-interface {v2, v1}, LZ2/a;->r(Ljava/lang/Runnable;)V

    new-instance v1, Ln8/m;

    invoke-direct {v1, v0}, Ln8/m;-><init>(LO2/A;)V

    iget-object v0, v0, LO2/A;->d:LZ2/a;

    invoke-interface {v0, v1}, LZ2/a;->r(Ljava/lang/Runnable;)V

    :cond_32
    const/4 v0, 0x0

    return-object v0
.end method
