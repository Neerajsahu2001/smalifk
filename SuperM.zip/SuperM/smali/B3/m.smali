.class public final synthetic Lb3/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/io/Serializable;)V
    .registers 3

    iput p1, p0, Lb3/m;->a:I

    iput-object p2, p0, Lb3/m;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 5

    iget v0, p0, Lb3/m;->a:I

    packed-switch v0, :pswitch_data_34

    iget-object v0, p0, Lb3/m;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-static {v0}, Lio/invertase/firebase/messaging/ReactNativeFirebaseMessagingModule;->f(Ljava/lang/Boolean;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :pswitch_e
    iget-object v0, p0, Lb3/m;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_32

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lte/b;

    new-instance v2, Lb3/n;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v1}, Lb3/n;-><init>(ILjava/lang/Object;)V

    sget-object v1, Lb3/p;->a:Ljava/util/concurrent/ExecutorService;

    invoke-static {v2, v1}, Lv7/l;->c(Ljava/util/concurrent/Callable;Ljava/util/concurrent/Executor;)Lv7/v;

    move-result-object v1

    invoke-static {v1}, Lv7/l;->a(Lv7/i;)Ljava/lang/Object;

    goto :goto_16

    :cond_32
    const/4 v0, 0x0

    return-object v0

    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method
