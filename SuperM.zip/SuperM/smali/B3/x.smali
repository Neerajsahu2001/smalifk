.class public final synthetic Lb3/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, Lb3/x;->a:I

    iput-object p2, p0, Lb3/x;->b:Ljava/lang/Object;

    iput-object p3, p0, Lb3/x;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Loc/g;Landroid/os/Bundle;)V
    .registers 4

    const/4 v0, 0x3

    iput v0, p0, Lb3/x;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb3/x;->c:Ljava/lang/Object;

    iput-object p2, p0, Lb3/x;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 23

    move-object/from16 v1, p0

    const/4 v0, 0x6

    const/4 v2, 0x0

    iget-object v3, v1, Lb3/x;->b:Ljava/lang/Object;

    iget-object v4, v1, Lb3/x;->c:Ljava/lang/Object;

    iget v5, v1, Lb3/x;->a:I

    packed-switch v5, :pswitch_data_2ce

    check-cast v4, Loc/g;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "analytics_storage"

    check-cast v3, Landroid/os/Bundle;

    invoke-virtual {v3, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    const-string v5, "ad_storage"

    invoke-virtual {v3, v5}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    const-string v6, "ad_user_data"

    invoke-virtual {v3, v6}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v6

    const-string v7, "ad_personalization"

    invoke-virtual {v3, v7}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v3

    new-instance v7, Ljava/util/EnumMap;

    const-class v8, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;

    invoke-direct {v7, v8}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    sget-object v8, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;->ANALYTICS_STORAGE:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;

    if-eqz v0, :cond_3a

    sget-object v0, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->GRANTED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    goto :goto_3c

    :cond_3a
    sget-object v0, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->DENIED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    :goto_3c
    invoke-virtual {v7, v8, v0}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;->AD_STORAGE:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;

    if-eqz v5, :cond_46

    sget-object v5, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->GRANTED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    goto :goto_48

    :cond_46
    sget-object v5, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->DENIED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    :goto_48
    invoke-virtual {v7, v0, v5}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;->AD_USER_DATA:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;

    if-eqz v6, :cond_52

    sget-object v5, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->GRANTED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    goto :goto_54

    :cond_52
    sget-object v5, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->DENIED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    :goto_54
    invoke-virtual {v7, v0, v5}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;->AD_PERSONALIZATION:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentType;

    if-eqz v3, :cond_5e

    sget-object v3, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->GRANTED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    goto :goto_60

    :cond_5e
    sget-object v3, Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;->DENIED:Lcom/google/firebase/analytics/FirebaseAnalytics$ConsentStatus;

    :goto_60
    invoke-virtual {v7, v0, v3}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v4, LQ7/l;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    move-result-object v0

    invoke-virtual {v0, v7}, Lcom/google/firebase/analytics/FirebaseAnalytics;->setConsent(Ljava/util/Map;)V

    return-object v2

    :pswitch_6f
    check-cast v3, Lcom/airbnb/lottie/LottieAnimationView;

    iget-boolean v0, v3, Lcom/airbnb/lottie/LottieAnimationView;->m:Z

    check-cast v4, Ljava/lang/String;

    if-eqz v0, :cond_90

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget-object v2, Ln3/l;->a:Ljava/util/HashMap;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "asset_"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v4, v2}, Ln3/l;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ln3/y;

    move-result-object v0

    goto :goto_98

    :cond_90
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v4, v2}, Ln3/l;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ln3/y;

    move-result-object v0

    :goto_98
    return-object v0

    :pswitch_99
    check-cast v3, Lio/sentry/O;

    check-cast v4, Lio/sentry/Y1;

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :try_start_a2
    new-instance v5, Ljava/io/BufferedWriter;

    new-instance v0, Ljava/io/OutputStreamWriter;

    sget-object v6, Lio/sentry/p1;->d:Ljava/nio/charset/Charset;

    invoke-direct {v0, v2, v6}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v5, v0}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V
    :try_end_ae
    .catchall {:try_start_a2 .. :try_end_ae} :catchall_bc

    :try_start_ae
    invoke-interface {v3, v4, v5}, Lio/sentry/O;->f(Ljava/lang/Object;Ljava/io/BufferedWriter;)V

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_b5
    .catchall {:try_start_ae .. :try_end_b5} :catchall_bf

    :try_start_b5
    invoke-virtual {v5}, Ljava/io/Writer;->close()V
    :try_end_b8
    .catchall {:try_start_b5 .. :try_end_b8} :catchall_bc

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V

    return-object v0

    :catchall_bc
    move-exception v0

    move-object v3, v0

    goto :goto_cb

    :catchall_bf
    move-exception v0

    move-object v3, v0

    :try_start_c1
    invoke-virtual {v5}, Ljava/io/Writer;->close()V
    :try_end_c4
    .catchall {:try_start_c1 .. :try_end_c4} :catchall_c5

    goto :goto_ca

    :catchall_c5
    move-exception v0

    move-object v4, v0

    :try_start_c7
    invoke-virtual {v3, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_ca
    throw v3
    :try_end_cb
    .catchall {:try_start_c7 .. :try_end_cb} :catchall_bc

    :goto_cb
    :try_start_cb
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_ce
    .catchall {:try_start_cb .. :try_end_ce} :catchall_cf

    goto :goto_d4

    :catchall_cf
    move-exception v0

    move-object v2, v0

    invoke-virtual {v3, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_d4
    throw v3

    :pswitch_d5
    check-cast v3, Landroid/os/Bundle;

    const-string v5, "type"

    invoke-virtual {v3, v5}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5}, Lte/g;->a(Ljava/lang/Object;)I

    move-result v5

    check-cast v4, Lapp/notifee/core/model/NotificationModel;

    const-string v8, "id"

    const-string v9, "Periodic"

    const-string v10, "workType"

    const-string v11, "trigger:"

    const-class v12, Lapp/notifee/core/Worker;

    const-string v13, "workRequestType"

    const-string v14, "app.notifee.core.NotificationManager.TRIGGER"

    if-eqz v5, :cond_1cf

    const/4 v15, 0x1

    if-eq v5, v15, :cond_f8

    goto/16 :goto_2c3

    :cond_f8
    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v11, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    sget-object v11, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {v11}, LO2/A;->c(Landroid/content/Context;)LO2/A;

    move-result-object v11

    new-instance v15, Ljava/util/HashMap;

    invoke-direct {v15}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v15, v10, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v15, v13, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v15, v8, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v8, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {v8}, Lapp/notifee/core/database/a;->a(Landroid/content/Context;)Lapp/notifee/core/database/a;

    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    new-instance v9, Lte/p;

    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->toBundle()Landroid/os/Bundle;

    move-result-object v13

    invoke-static {v13}, Lte/g;->c(Landroid/os/Bundle;)[B

    move-result-object v13

    invoke-static {v3}, Lte/g;->c(Landroid/os/Bundle;)[B

    move-result-object v2

    invoke-direct {v9, v10, v13, v2, v8}, Lte/p;-><init>(Ljava/lang/String;[B[BLjava/lang/Boolean;)V

    sget-object v2, Lapp/notifee/core/database/a;->b:Lapp/notifee/core/database/a;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v8, Lapp/notifee/core/database/NotifeeCoreDatabase;->l:Ljava/util/concurrent/ExecutorService;

    new-instance v10, LB1/J;

    invoke-direct {v10, v0, v2, v9}, LB1/J;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v8, v10}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const-string v0, "interval"

    invoke-virtual {v3, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_154

    invoke-virtual {v3, v0}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lte/g;->a(Ljava/lang/Object;)I

    move-result v7

    goto :goto_155

    :cond_154
    const/4 v7, -0x1

    :goto_155
    int-to-long v7, v7

    new-instance v2, LN2/v;

    sget-object v9, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-string v10, "timeUnit"

    invoke-virtual {v3, v10}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const-string v13, "IntervalTriggerModel"

    const-string v6, "An error occurred whilst trying to convert interval time unit: "

    if-eqz v0, :cond_183

    invoke-virtual {v3, v10}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :try_start_16a
    invoke-static {v1}, Ljava/util/concurrent/TimeUnit;->valueOf(Ljava/lang/String;)Ljava/util/concurrent/TimeUnit;

    move-result-object v9
    :try_end_16e
    .catch Ljava/lang/IllegalArgumentException; {:try_start_16a .. :try_end_16e} :catch_16f

    goto :goto_187

    :catch_16f
    move-exception v0

    move-object/from16 v16, v9

    move-object v9, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v13, v0, v9}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_185

    :cond_183
    move-object/from16 v16, v9

    :goto_185
    move-object/from16 v9, v16

    :goto_187
    invoke-direct {v2, v12, v7, v8, v9}, LN2/v;-><init>(Ljava/lang/Class;JLjava/util/concurrent/TimeUnit;)V

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v3, v10}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1ac

    invoke-virtual {v3, v10}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :try_start_196
    invoke-static {v3}, Ljava/util/concurrent/TimeUnit;->valueOf(Ljava/lang/String;)Ljava/util/concurrent/TimeUnit;

    move-result-object v1
    :try_end_19a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_196 .. :try_end_19a} :catch_19b

    goto :goto_1ac

    :catch_19b
    move-exception v0

    move-object v9, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v13, v0, v9}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_1ac
    :goto_1ac
    invoke-virtual {v2, v7, v8, v1}, LN2/z;->e(JLjava/util/concurrent/TimeUnit;)LN2/z;

    move-result-object v0

    check-cast v0, LN2/v;

    invoke-virtual {v0, v14}, LN2/z;->a(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, LN2/z;->a(Ljava/lang/String;)V

    new-instance v1, LN2/e;

    invoke-direct {v1, v15}, LN2/e;-><init>(Ljava/util/Map;)V

    invoke-static {v1}, LN2/e;->c(LN2/e;)[B

    invoke-virtual {v0, v1}, LN2/z;->f(LN2/e;)LN2/z;

    invoke-virtual {v0}, LN2/z;->b()LN2/A;

    move-result-object v0

    check-cast v0, LN2/w;

    const/4 v1, 0x3

    invoke-virtual {v11, v5, v1, v0}, LO2/A;->b(Ljava/lang/String;ILN2/w;)LN2/u;

    goto/16 :goto_2c3

    :cond_1cf
    new-instance v1, Ld3/d;

    invoke-direct {v1, v3}, Ld3/d;-><init>(Landroid/os/Bundle;)V

    iget v2, v1, Ld3/d;->a:I

    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v11, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "timestamp"

    invoke-virtual {v3, v6}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v11

    const-wide/16 v16, 0x0

    if-eqz v11, :cond_206

    invoke-virtual {v3, v6}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6}, Lte/g;->d(Ljava/lang/Object;)J

    move-result-wide v18

    cmp-long v6, v18, v16

    if-lez v6, :cond_206

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v18, v18, v16

    const-wide/16 v16, 0x3e8

    move-object v11, v1

    div-long v0, v18, v16

    long-to-float v0, v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    int-to-long v0, v0

    goto :goto_209

    :cond_206
    move-object v11, v1

    move-wide/from16 v0, v16

    :goto_209
    new-instance v15, Ljava/util/HashMap;

    invoke-direct {v15}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v15, v10, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v15, v8, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v8, v11, Ld3/d;->c:Ljava/lang/Boolean;

    sget-object v10, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {v10}, Lapp/notifee/core/database/a;->a(Landroid/content/Context;)Lapp/notifee/core/database/a;

    new-instance v10, Lte/p;

    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4}, Lapp/notifee/core/model/NotificationModel;->toBundle()Landroid/os/Bundle;

    move-result-object v17

    invoke-static/range {v17 .. v17}, Lte/g;->c(Landroid/os/Bundle;)[B

    move-result-object v7

    invoke-static {v3}, Lte/g;->c(Landroid/os/Bundle;)[B

    move-result-object v3

    invoke-direct {v10, v6, v7, v3, v8}, Lte/p;-><init>(Ljava/lang/String;[B[BLjava/lang/Boolean;)V

    sget-object v3, Lapp/notifee/core/database/a;->b:Lapp/notifee/core/database/a;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v6, Lapp/notifee/core/database/NotifeeCoreDatabase;->l:Ljava/util/concurrent/ExecutorService;

    new-instance v7, LB1/J;

    move-object/from16 v17, v9

    const/4 v9, 0x6

    invoke-direct {v7, v9, v3, v10}, LB1/J;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v6, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_250

    invoke-static {v4, v11}, Lb3/r;->b(Lapp/notifee/core/model/NotificationModel;Ld3/d;)V

    goto :goto_2c3

    :cond_250
    sget-object v3, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {v3}, LO2/A;->c(Landroid/content/Context;)LO2/A;

    move-result-object v3

    const/4 v6, -0x1

    if-ne v2, v6, :cond_296

    new-instance v2, LN2/p;

    invoke-direct {v2, v12}, LN2/p;-><init>(Ljava/lang/Class;)V

    invoke-virtual {v2, v14}, LN2/z;->a(Ljava/lang/String;)V

    invoke-virtual {v2, v5}, LN2/z;->a(Ljava/lang/String;)V

    const-string v6, "OneTime"

    invoke-virtual {v15, v13, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, LN2/e;

    invoke-direct {v6, v15}, LN2/e;-><init>(Ljava/util/Map;)V

    invoke-static {v6}, LN2/e;->c(LN2/e;)[B

    invoke-virtual {v2, v6}, LN2/z;->f(LN2/e;)LN2/z;

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v2, v0, v1, v6}, LN2/z;->e(JLjava/util/concurrent/TimeUnit;)LN2/z;

    invoke-virtual {v2}, LN2/z;->b()LN2/A;

    move-result-object v0

    check-cast v0, LN2/q;

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v20

    new-instance v0, LO2/u;

    const/16 v21, 0x0

    const/16 v19, 0x1

    move-object/from16 v16, v0

    move-object/from16 v17, v3

    move-object/from16 v18, v5

    invoke-direct/range {v16 .. v21}, LO2/u;-><init>(LO2/A;Ljava/lang/String;ILjava/util/List;Ljava/util/List;)V

    invoke-virtual {v0}, LO2/u;->b()LN2/u;

    goto :goto_2c3

    :cond_296
    new-instance v6, LN2/v;

    int-to-long v7, v2

    iget-object v2, v11, Ld3/d;->b:Ljava/util/concurrent/TimeUnit;

    invoke-direct {v6, v12, v7, v8, v2}, LN2/v;-><init>(Ljava/lang/Class;JLjava/util/concurrent/TimeUnit;)V

    invoke-virtual {v6, v14}, LN2/z;->a(Ljava/lang/String;)V

    invoke-virtual {v6, v5}, LN2/z;->a(Ljava/lang/String;)V

    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v6, v0, v1, v2}, LN2/z;->e(JLjava/util/concurrent/TimeUnit;)LN2/z;

    move-object/from16 v0, v17

    invoke-virtual {v15, v13, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, LN2/e;

    invoke-direct {v0, v15}, LN2/e;-><init>(Ljava/util/Map;)V

    invoke-static {v0}, LN2/e;->c(LN2/e;)[B

    invoke-virtual {v6, v0}, LN2/z;->f(LN2/e;)LN2/z;

    invoke-virtual {v6}, LN2/z;->b()LN2/A;

    move-result-object v0

    check-cast v0, LN2/w;

    const/4 v1, 0x3

    invoke-virtual {v3, v5, v1, v0}, LO2/A;->b(Ljava/lang/String;ILN2/w;)LN2/u;

    :goto_2c3
    new-instance v0, Lapp/notifee/core/event/NotificationEvent;

    const/4 v1, 0x7

    invoke-direct {v0, v1, v4}, Lapp/notifee/core/event/NotificationEvent;-><init>(ILapp/notifee/core/model/NotificationModel;)V

    invoke-static {v0}, Lte/d;->a(Ljava/lang/Object;)V

    const/4 v1, 0x0

    return-object v1

    :pswitch_data_2ce
    .packed-switch 0x0
        :pswitch_d5
        :pswitch_99
        :pswitch_6f
    .end packed-switch
.end method
