.class public final synthetic Lb3/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lb3/j;->a:I

    iput-object p2, p0, Lb3/j;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 6

    iget v0, p0, Lb3/j;->a:I

    packed-switch v0, :pswitch_data_66

    invoke-static {}, Lcom/google/firebase/perf/FirebasePerformance;->getInstance()Lcom/google/firebase/perf/FirebasePerformance;

    move-result-object v0

    iget-object v1, p0, Lb3/j;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcom/google/firebase/perf/FirebasePerformance;->setPerformanceCollectionEnabled(Ljava/lang/Boolean;)V

    return-object v1

    :pswitch_11
    iget-object v0, p0, Lb3/j;->b:Ljava/lang/Object;

    check-cast v0, Lio/invertase/firebase/messaging/ReactNativeFirebaseMessagingModule;

    invoke-static {v0}, Lio/invertase/firebase/messaging/ReactNativeFirebaseMessagingModule;->a(Lio/invertase/firebase/messaging/ReactNativeFirebaseMessagingModule;)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    :pswitch_1a
    iget-object v0, p0, Lb3/j;->b:Ljava/lang/Object;

    check-cast v0, Lapp/notifee/core/model/NotificationAndroidStyleModel;

    invoke-static {v0}, Lapp/notifee/core/model/NotificationAndroidStyleModel;->b(Lapp/notifee/core/model/NotificationAndroidStyleModel;)Ld0/K;

    move-result-object v0

    return-object v0

    :pswitch_23
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    new-instance v1, Landroid/app/NotificationChannelGroup;

    iget-object v2, p0, Lb3/j;->b:Ljava/lang/Object;

    check-cast v2, Lte/a;

    iget-object v3, v2, Lte/a;->a:Landroid/os/Bundle;

    const-string v4, "id"

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v2, v2, Lte/a;->a:Landroid/os/Bundle;

    const-string v4, "name"

    invoke-virtual {v2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-direct {v1, v3, v4}, Landroid/app/NotificationChannelGroup;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/16 v3, 0x1c

    if-lt v0, v3, :cond_57

    const-string v0, "description"

    invoke-virtual {v2, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_57

    invoke-virtual {v2, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LK0/b;->l(Landroid/app/NotificationChannelGroup;Ljava/lang/String;)V

    :cond_57
    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    new-instance v2, Ld0/c0;

    invoke-direct {v2, v0}, Ld0/c0;-><init>(Landroid/content/Context;)V

    iget-object v0, v2, Ld0/c0;->b:Landroid/app/NotificationManager;

    invoke-static {v0, v1}, Ld0/W;->b(Landroid/app/NotificationManager;Landroid/app/NotificationChannelGroup;)V

    const/4 v0, 0x0

    return-object v0

    nop

    :pswitch_data_66
    .packed-switch 0x0
        :pswitch_23
        :pswitch_1a
        :pswitch_11
    .end packed-switch
.end method
