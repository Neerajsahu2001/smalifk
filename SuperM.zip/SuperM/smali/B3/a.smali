.class public final synthetic Lb3/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Landroidx/concurrent/futures/k;

.field public final synthetic b:I

.field public final synthetic c:Z


# direct methods
.method public synthetic constructor <init>(Landroidx/concurrent/futures/k;IZ)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb3/a;->a:Landroidx/concurrent/futures/k;

    iput p2, p0, Lb3/a;->b:I

    iput-boolean p3, p0, Lb3/a;->c:Z

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .registers 5

    check-cast p1, Landroid/os/Bundle;

    sget v0, Lapp/notifee/core/BlockStateBroadcastReceiver;->a:I

    new-instance v0, LB/a;

    iget-object v1, p0, Lb3/a;->a:Landroidx/concurrent/futures/k;

    const/4 v2, 0x5

    invoke-direct {v0, v2, v1}, LB/a;-><init>(ILjava/lang/Object;)V

    new-instance v1, Lapp/notifee/core/event/BlockStateEvent;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    iput-boolean v2, v1, Lapp/notifee/core/event/BlockStateEvent;->e:Z

    iget v2, p0, Lb3/a;->b:I

    iput v2, v1, Lapp/notifee/core/event/BlockStateEvent;->a:I

    iput-object v0, v1, Lapp/notifee/core/event/BlockStateEvent;->d:Lapp/notifee/core/interfaces/MethodCallResult;

    iget-boolean v0, p0, Lb3/a;->c:Z

    iput-boolean v0, v1, Lapp/notifee/core/event/BlockStateEvent;->b:Z

    iput-object p1, v1, Lapp/notifee/core/event/BlockStateEvent;->c:Landroid/os/Bundle;

    invoke-static {v1}, Lte/d;->a(Ljava/lang/Object;)V

    return-void
.end method
