.class public final synthetic Lb3/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv7/d;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lapp/notifee/core/interfaces/MethodCallResult;


# direct methods
.method public synthetic constructor <init>(ILapp/notifee/core/interfaces/MethodCallResult;)V
    .registers 3

    iput p1, p0, Lb3/d;->a:I

    iput-object p2, p0, Lb3/d;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onComplete(Lv7/i;)V
    .registers 5

    iget v0, p0, Lb3/d;->a:I

    packed-switch v0, :pswitch_data_3c

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    iget-object v1, p0, Lb3/d;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v2, 0x0

    if-eqz v0, :cond_18

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Void;

    invoke-interface {v1, v2, p1}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_1f

    :cond_18
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v1, p1, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_1f
    return-void

    :pswitch_20
    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    iget-object v1, p0, Lb3/d;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v2, 0x0

    if-eqz v0, :cond_33

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Void;

    invoke-interface {v1, v2, p1}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_3a

    :cond_33
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v1, p1, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_3a
    return-void

    nop

    :pswitch_data_3c
    .packed-switch 0x0
        :pswitch_20
    .end packed-switch
.end method
