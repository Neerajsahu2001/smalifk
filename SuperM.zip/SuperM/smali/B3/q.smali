.class public final synthetic Lb3/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv7/d;


# instance fields
.field public final synthetic a:Landroid/os/Bundle;

.field public final synthetic b:Lapp/notifee/core/model/NotificationModel;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lte/p;


# direct methods
.method public synthetic constructor <init>(Landroid/os/Bundle;Lapp/notifee/core/model/NotificationModel;Ljava/lang/String;Lte/p;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb3/q;->a:Landroid/os/Bundle;

    iput-object p2, p0, Lb3/q;->b:Lapp/notifee/core/model/NotificationModel;

    iput-object p3, p0, Lb3/q;->c:Ljava/lang/String;

    iput-object p4, p0, Lb3/q;->d:Lte/p;

    return-void
.end method


# virtual methods
.method public final onComplete(Lv7/i;)V
    .registers 7

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    if-nez v0, :cond_12

    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    const-string v0, "NotifeeAlarmManager"

    const-string v1, "Failed to display notification"

    invoke-static {v0, v1, p1}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_6e

    :cond_12
    iget-object p1, p0, Lb3/q;->a:Landroid/os/Bundle;

    const-string v0, "repeatFrequency"

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    iget-object v2, p0, Lb3/q;->c:Ljava/lang/String;

    if-eqz v1, :cond_5a

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lte/g;->a(Ljava/lang/Object;)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_5a

    new-instance v0, Ld3/d;

    invoke-direct {v0, p1}, Ld3/d;-><init>(Landroid/os/Bundle;)V

    invoke-virtual {v0}, Ld3/d;->a()V

    iget-object v1, p0, Lb3/q;->b:Lapp/notifee/core/model/NotificationModel;

    invoke-static {v1, v0}, Lb3/r;->b(Lapp/notifee/core/model/NotificationModel;Ld3/d;)V

    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {v0}, Lapp/notifee/core/database/a;->a(Landroid/content/Context;)Lapp/notifee/core/database/a;

    move-result-object v0

    new-instance v1, Lte/p;

    iget-object v3, p0, Lb3/q;->d:Lte/p;

    iget-object v3, v3, Lte/p;->b:[B

    invoke-static {p1}, Lte/g;->c(Landroid/os/Bundle;)[B

    move-result-object p1

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-direct {v1, v2, v3, p1, v4}, Lte/p;-><init>(Ljava/lang/String;[B[BLjava/lang/Boolean;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Lapp/notifee/core/database/NotifeeCoreDatabase;->l:Ljava/util/concurrent/ExecutorService;

    new-instance v2, LB1/K;

    const/4 v3, 0x7

    invoke-direct {v2, v3, v0, v1}, LB1/K;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {p1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_6e

    :cond_5a
    sget-object p1, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {p1}, Lapp/notifee/core/database/a;->a(Landroid/content/Context;)Lapp/notifee/core/database/a;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lapp/notifee/core/database/NotifeeCoreDatabase;->l:Ljava/util/concurrent/ExecutorService;

    new-instance v1, LB/e;

    const/4 v3, 0x6

    invoke-direct {v1, v3, p1, v2}, LB/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_6e
    return-void
.end method
