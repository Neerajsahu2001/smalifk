.class public final synthetic Lb3/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILandroid/os/Bundle;Landroid/os/Bundle;)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, Lb3/v;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lb3/v;->b:I

    iput-object p2, p0, Lb3/v;->c:Ljava/lang/Object;

    iput-object p3, p0, Lb3/v;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/util/List;)V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, Lb3/v;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lb3/v;->c:Ljava/lang/Object;

    iput p1, p0, Lb3/v;->b:I

    iput-object p2, p0, Lb3/v;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 12

    iget v0, p0, Lb3/v;->a:I

    packed-switch v0, :pswitch_data_136

    sget-object v0, Ltc/g;->e:Landroid/util/SparseArray;

    iget v1, p0, Lb3/v;->b:I

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/firebase/perf/metrics/HttpMetric;

    iget-object v3, p0, Lb3/v;->c:Ljava/lang/Object;

    check-cast v3, Landroid/os/Bundle;

    const-string v4, "httpResponseCode"

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_23

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->getDouble(Ljava/lang/String;)D

    move-result-wide v4

    double-to-int v4, v4

    invoke-virtual {v2, v4}, Lcom/google/firebase/perf/metrics/HttpMetric;->setHttpResponseCode(I)V

    :cond_23
    const-string v4, "requestPayloadSize"

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_34

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->getDouble(Ljava/lang/String;)D

    move-result-wide v4

    double-to-int v4, v4

    int-to-long v4, v4

    invoke-virtual {v2, v4, v5}, Lcom/google/firebase/perf/metrics/HttpMetric;->setRequestPayloadSize(J)V

    :cond_34
    const-string v4, "responsePayloadSize"

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_45

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->getDouble(Ljava/lang/String;)D

    move-result-wide v4

    double-to-int v4, v4

    int-to-long v4, v4

    invoke-virtual {v2, v4, v5}, Lcom/google/firebase/perf/metrics/HttpMetric;->setResponsePayloadSize(J)V

    :cond_45
    const-string v4, "responseContentType"

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_54

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/google/firebase/perf/metrics/HttpMetric;->setResponseContentType(Ljava/lang/String;)V

    :cond_54
    iget-object v3, p0, Lb3/v;->d:Ljava/lang/Object;

    check-cast v3, Landroid/os/Bundle;

    invoke-virtual {v3}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_60
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_77

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v3, v5}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2, v5, v6}, Lcom/google/firebase/perf/metrics/HttpMetric;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_60

    :cond_77
    invoke-virtual {v2}, Lcom/google/firebase/perf/metrics/HttpMetric;->stop()V

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->remove(I)V

    const/4 v0, 0x0

    return-object v0

    :pswitch_7f
    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {v0}, LO2/A;->c(Landroid/content/Context;)LO2/A;

    move-result-object v0

    sget-object v1, Lm7/D2;->a:Landroid/content/Context;

    new-instance v2, Ld0/c0;

    invoke-direct {v2, v1}, Ld0/c0;-><init>(Landroid/content/Context;)V

    iget-object v1, p0, Lb3/v;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_94
    :goto_94
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_134

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Removing notification with id "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v7, "NotificationManager"

    invoke-static {v7, v5}, Lapp/notifee/core/Logger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    iget v8, p0, Lb3/v;->b:I

    if-eq v8, v5, :cond_eb

    iget-object v5, v2, Ld0/c0;->b:Landroid/app/NotificationManager;

    iget-object v9, p0, Lb3/v;->d:Ljava/lang/Object;

    check-cast v9, Ljava/lang/String;

    if-eqz v9, :cond_e4

    const-string v10, "0"

    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_e4

    :try_start_c9
    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4
    :try_end_d1
    .catch Ljava/lang/Exception; {:try_start_c9 .. :try_end_d1} :catch_d2

    goto :goto_db

    :catch_d2
    const-string v10, "cancelAllNotificationsWithIds -> Failed to parse id as integer  "

    invoke-virtual {v10, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v7, v10}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_db
    if-eqz v4, :cond_e4

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v5, v9, v4}, Landroid/app/NotificationManager;->cancel(Ljava/lang/String;I)V

    :cond_e4
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v4

    invoke-virtual {v5, v9, v4}, Landroid/app/NotificationManager;->cancel(Ljava/lang/String;I)V

    :cond_eb
    const/4 v4, 0x1

    if-eq v8, v4, :cond_94

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v7, v5}, Lapp/notifee/core/Logger;->i(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "trigger:"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    new-instance v6, LX2/d;

    invoke-direct {v6, v0, v5, v4}, LX2/d;-><init>(LO2/A;Ljava/lang/String;Z)V

    iget-object v4, v0, LO2/A;->d:LZ2/a;

    invoke-interface {v4, v6}, LZ2/a;->r(Ljava/lang/Runnable;)V

    new-instance v4, Ln8/m;

    invoke-direct {v4, v0}, Ln8/m;-><init>(LO2/A;)V

    iget-object v5, v0, LO2/A;->d:LZ2/a;

    invoke-interface {v5, v4}, LZ2/a;->r(Ljava/lang/Runnable;)V

    invoke-static {v3}, Lb3/r;->a(Ljava/lang/String;)Landroid/app/PendingIntent;

    move-result-object v3

    sget-object v4, Lm7/D2;->a:Landroid/content/Context;

    const-string v5, "alarm"

    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/AlarmManager;

    if-eqz v3, :cond_94

    invoke-virtual {v4, v3}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V

    goto/16 :goto_94

    :cond_134
    return-object v4

    nop

    :pswitch_data_136
    .packed-switch 0x0
        :pswitch_7f
    .end packed-switch
.end method
