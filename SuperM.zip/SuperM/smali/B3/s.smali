.class public final synthetic Lb3/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, Lb3/s;->a:I

    iput-object p2, p0, Lb3/s;->b:Ljava/lang/Object;

    iput-object p3, p0, Lb3/s;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 11

    iget v0, p0, Lb3/s;->a:I

    packed-switch v0, :pswitch_data_3aa

    iget-object v0, p0, Lb3/s;->b:Ljava/lang/Object;

    check-cast v0, Ljava/io/InputStream;

    iget-object v1, p0, Lb3/s;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Ln3/l;->c(Ljava/io/InputStream;Ljava/lang/String;)Ln3/y;

    move-result-object v0

    return-object v0

    :pswitch_12
    iget-object v0, p0, Lb3/s;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/O;

    iget-object v1, p0, Lb3/s;->c:Ljava/lang/Object;

    check-cast v1, Lio/sentry/clientreport/b;

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :try_start_1f
    new-instance v3, Ljava/io/BufferedWriter;

    new-instance v4, Ljava/io/OutputStreamWriter;

    sget-object v5, Lio/sentry/p1;->d:Ljava/nio/charset/Charset;

    invoke-direct {v4, v2, v5}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v3, v4}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V
    :try_end_2b
    .catchall {:try_start_1f .. :try_end_2b} :catchall_39

    :try_start_2b
    invoke-interface {v0, v1, v3}, Lio/sentry/O;->f(Ljava/lang/Object;Ljava/io/BufferedWriter;)V

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_32
    .catchall {:try_start_2b .. :try_end_32} :catchall_3b

    :try_start_32
    invoke-virtual {v3}, Ljava/io/Writer;->close()V
    :try_end_35
    .catchall {:try_start_32 .. :try_end_35} :catchall_39

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V

    return-object v0

    :catchall_39
    move-exception v0

    goto :goto_45

    :catchall_3b
    move-exception v0

    :try_start_3c
    invoke-virtual {v3}, Ljava/io/Writer;->close()V
    :try_end_3f
    .catchall {:try_start_3c .. :try_end_3f} :catchall_40

    goto :goto_44

    :catchall_40
    move-exception v1

    :try_start_41
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_44
    throw v0
    :try_end_45
    .catchall {:try_start_41 .. :try_end_45} :catchall_39

    :goto_45
    :try_start_45
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_48
    .catchall {:try_start_45 .. :try_end_48} :catchall_49

    goto :goto_4d

    :catchall_49
    move-exception v1

    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4d
    throw v0

    :pswitch_4e
    iget-object v0, p0, Lb3/s;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v1, p0, Lb3/s;->c:Ljava/lang/Object;

    check-cast v1, Landroid/content/Intent;

    invoke-static {v0, v1}, Lcom/google/firebase/messaging/FcmBroadcastProcessor;->b(Landroid/content/Context;Landroid/content/Intent;)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :pswitch_5b
    iget-object v0, p0, Lb3/s;->b:Ljava/lang/Object;

    check-cast v0, Lapp/notifee/core/database/a;

    iget-object v0, v0, Lapp/notifee/core/database/a;->a:Lte/o;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "SELECT * from work_data WHERE id = ?"

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ls2/m;->i(ILjava/lang/String;)Ls2/m;

    move-result-object v1

    iget-object v3, p0, Lb3/s;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    if-nez v3, :cond_75

    invoke-virtual {v1, v2}, Ls2/m;->S(I)V

    goto :goto_78

    :cond_75
    invoke-virtual {v1, v2, v3}, Ls2/m;->o(ILjava/lang/String;)V

    :goto_78
    iget-object v0, v0, Lte/o;->a:Ljava/lang/Object;

    check-cast v0, Ls2/k;

    invoke-virtual {v0}, Ls2/k;->b()V

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3}, Ls2/k;->m(Ly2/e;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v0

    :try_start_84
    const-string v4, "id"

    invoke-static {v0, v4}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v5, "notification"

    invoke-static {v0, v5}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v5

    const-string v6, "trigger"

    invoke-static {v0, v6}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v6

    const-string v7, "with_alarm_manager"

    invoke-static {v0, v7}, Lm7/G;->a(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v8

    if-eqz v8, :cond_ee

    invoke-interface {v0, v4}, Landroid/database/Cursor;->isNull(I)Z

    move-result v8

    if-eqz v8, :cond_aa

    move-object v4, v3

    goto :goto_ae

    :cond_aa
    invoke-interface {v0, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    :goto_ae
    invoke-interface {v0, v5}, Landroid/database/Cursor;->isNull(I)Z

    move-result v8

    if-eqz v8, :cond_b6

    move-object v5, v3

    goto :goto_ba

    :cond_b6
    invoke-interface {v0, v5}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v5

    :goto_ba
    invoke-interface {v0, v6}, Landroid/database/Cursor;->isNull(I)Z

    move-result v8

    if-eqz v8, :cond_c2

    move-object v6, v3

    goto :goto_c6

    :cond_c2
    invoke-interface {v0, v6}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v6

    :goto_c6
    invoke-interface {v0, v7}, Landroid/database/Cursor;->isNull(I)Z

    move-result v8

    if-eqz v8, :cond_ce

    move-object v7, v3

    goto :goto_d6

    :cond_ce
    invoke-interface {v0, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    :goto_d6
    if-nez v7, :cond_d9

    goto :goto_e5

    :cond_d9
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-eqz v3, :cond_e0

    goto :goto_e1

    :cond_e0
    const/4 v2, 0x0

    :goto_e1
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    :goto_e5
    new-instance v2, Lte/p;

    invoke-direct {v2, v4, v5, v6, v3}, Lte/p;-><init>(Ljava/lang/String;[B[BLjava/lang/Boolean;)V
    :try_end_ea
    .catchall {:try_start_84 .. :try_end_ea} :catchall_ec

    move-object v3, v2

    goto :goto_ee

    :catchall_ec
    move-exception v2

    goto :goto_f5

    :cond_ee
    :goto_ee
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    invoke-virtual {v1}, Ls2/m;->l()V

    return-object v3

    :goto_f5
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    invoke-virtual {v1}, Ls2/m;->l()V

    throw v2

    :pswitch_fc
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    new-instance v1, Landroidx/core/app/NotificationCompat$Builder;

    sget-object v2, Lm7/D2;->a:Landroid/content/Context;

    iget-object v3, p0, Lb3/s;->b:Ljava/lang/Object;

    check-cast v3, Lapp/notifee/core/model/NotificationAndroidModel;

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getChannelId()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v2, v4}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iget-object v2, p0, Lb3/s;->c:Ljava/lang/Object;

    check-cast v2, Lapp/notifee/core/model/NotificationModel;

    iget-object v4, v2, Lapp/notifee/core/model/NotificationModel;->a:Landroid/os/Bundle;

    const-string v5, "data"

    invoke-virtual {v4, v5}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v4

    if-eqz v4, :cond_122

    invoke-virtual {v4}, Landroid/os/Bundle;->clone()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    goto :goto_127

    :cond_122
    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    :goto_127
    iput-object v4, v1, Landroidx/core/app/NotificationCompat$Builder;->A:Landroid/os/Bundle;

    const-string v4, "notification"

    filled-new-array {v4}, [Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->toBundle()Landroid/os/Bundle;

    move-result-object v6

    filled-new-array {v6}, [Landroid/os/Bundle;

    move-result-object v6

    const-string v7, "app.notifee.core.ReceiverService.DELETE_INTENT"

    invoke-static {v7, v5, v6}, Lapp/notifee/core/ReceiverService;->a(Ljava/lang/String;[Ljava/lang/String;[Landroid/os/Bundle;)Landroid/app/PendingIntent;

    move-result-object v5

    iget-object v6, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    iput-object v5, v6, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    sget-object v5, Lm7/D2;->a:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v5

    iget v5, v5, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v6, 0x1

    const-string v7, "pressAction"

    const/16 v8, 0x1f

    if-lt v5, v8, :cond_177

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v5, v8, :cond_177

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->b()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    move-result v5

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getPressAction()Landroid/os/Bundle;

    move-result-object v8

    filled-new-array {v4, v7}, [Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->toBundle()Landroid/os/Bundle;

    move-result-object v7

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getPressAction()Landroid/os/Bundle;

    move-result-object v9

    filled-new-array {v7, v9}, [Landroid/os/Bundle;

    move-result-object v7

    invoke-static {v5, v8, v6, v4, v7}, Lm7/D;->a(ILandroid/os/Bundle;I[Ljava/lang/String;[Landroid/os/Bundle;)Landroid/app/PendingIntent;

    move-result-object v4

    iput-object v4, v1, Landroidx/core/app/NotificationCompat$Builder;->g:Landroid/app/PendingIntent;

    goto :goto_18f

    :cond_177
    filled-new-array {v4, v7}, [Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2}, Lapp/notifee/core/model/NotificationModel;->toBundle()Landroid/os/Bundle;

    move-result-object v5

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getPressAction()Landroid/os/Bundle;

    move-result-object v7

    filled-new-array {v5, v7}, [Landroid/os/Bundle;

    move-result-object v5

    const-string v7, "app.notifee.core.ReceiverService.PRESS_INTENT"

    invoke-static {v7, v4, v5}, Lapp/notifee/core/ReceiverService;->a(Ljava/lang/String;[Ljava/lang/String;[Landroid/os/Bundle;)Landroid/app/PendingIntent;

    move-result-object v4

    iput-object v4, v1, Landroidx/core/app/NotificationCompat$Builder;->g:Landroid/app/PendingIntent;

    :goto_18f
    iget-object v2, v2, Lapp/notifee/core/model/NotificationModel;->a:Landroid/os/Bundle;

    const-string v4, "title"

    invoke-virtual {v2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    if-eqz v5, :cond_1a5

    invoke-virtual {v2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v7}, Lp0/c;->a(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroidx/core/app/NotificationCompat$Builder;->g(Ljava/lang/CharSequence;)V

    :cond_1a5
    const-string v4, "subtitle"

    invoke-virtual {v2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_1b8

    invoke-virtual {v2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v7}, Lp0/c;->a(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroidx/core/app/NotificationCompat$Builder;->m(Ljava/lang/CharSequence;)V

    :cond_1b8
    const-string v4, "body"

    invoke-virtual {v2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_1cb

    invoke-virtual {v2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v7}, Lp0/c;->a(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroidx/core/app/NotificationCompat$Builder;->f(Ljava/lang/CharSequence;)V

    :cond_1cb
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getBadgeIconType()Ljava/lang/Integer;

    move-result-object v2

    if-eqz v2, :cond_1db

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getBadgeIconType()Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iput v2, v1, Landroidx/core/app/NotificationCompat$Builder;->G:I

    :cond_1db
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getCategory()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_1e7

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getCategory()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Landroidx/core/app/NotificationCompat$Builder;->z:Ljava/lang/String;

    :cond_1e7
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getColor()Ljava/lang/Integer;

    move-result-object v2

    if-eqz v2, :cond_1f7

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getColor()Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iput v2, v1, Landroidx/core/app/NotificationCompat$Builder;->B:I

    :cond_1f7
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getColorized()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    iput-boolean v2, v1, Landroidx/core/app/NotificationCompat$Builder;->x:Z

    iput-boolean v6, v1, Landroidx/core/app/NotificationCompat$Builder;->y:Z

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getChronometerCountDown()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    iget-object v4, v1, Landroidx/core/app/NotificationCompat$Builder;->A:Landroid/os/Bundle;

    if-nez v4, :cond_216

    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    iput-object v4, v1, Landroidx/core/app/NotificationCompat$Builder;->A:Landroid/os/Bundle;

    :cond_216
    iget-object v4, v1, Landroidx/core/app/NotificationCompat$Builder;->A:Landroid/os/Bundle;

    const-string v5, "android.chronometerCountDown"

    invoke-virtual {v4, v5, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getGroup()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_229

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getGroup()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Landroidx/core/app/NotificationCompat$Builder;->t:Ljava/lang/String;

    :cond_229
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getGroupAlertBehaviour()I

    move-result v2

    iput v2, v1, Landroidx/core/app/NotificationCompat$Builder;->J:I

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getGroupSummary()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    iput-boolean v2, v1, Landroidx/core/app/NotificationCompat$Builder;->u:Z

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getInputHistory()[Ljava/lang/CharSequence;

    move-result-object v2

    if-eqz v2, :cond_245

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getInputHistory()[Ljava/lang/CharSequence;

    move-result-object v2

    iput-object v2, v1, Landroidx/core/app/NotificationCompat$Builder;->p:[Ljava/lang/CharSequence;

    :cond_245
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getLights()Ljava/util/ArrayList;

    move-result-object v2

    const/4 v4, 0x2

    if-eqz v2, :cond_282

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getLights()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget-object v9, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    iput v5, v9, Landroid/app/Notification;->ledARGB:I

    iput v8, v9, Landroid/app/Notification;->ledOnMS:I

    iput v2, v9, Landroid/app/Notification;->ledOffMS:I

    if-eqz v8, :cond_27b

    if-eqz v2, :cond_27b

    move v7, v6

    :cond_27b
    iget v2, v9, Landroid/app/Notification;->flags:I

    and-int/lit8 v2, v2, -0x2

    or-int/2addr v2, v7

    iput v2, v9, Landroid/app/Notification;->flags:I

    :cond_282
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getLocalOnly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    iput-boolean v2, v1, Landroidx/core/app/NotificationCompat$Builder;->w:Z

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getNumber()Ljava/lang/Integer;

    move-result-object v2

    if-eqz v2, :cond_29c

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getNumber()Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iput v2, v1, Landroidx/core/app/NotificationCompat$Builder;->j:I

    :cond_29c
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getSound()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_2c9

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getSound()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lte/j;->e(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    if-eqz v2, :cond_2b2

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1, v2}, Landroidx/core/app/NotificationCompat$Builder;->k(Landroid/net/Uri;)V

    goto :goto_2c9

    :cond_2b2
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v5, "Unable to retrieve sound for notification, sound was specified as: "

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getSound()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v5, "NotificationManager"

    invoke-static {v5, v2}, Lapp/notifee/core/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2c9
    :goto_2c9
    invoke-virtual {v3, v0}, Lapp/notifee/core/model/NotificationAndroidModel;->getDefaults(Ljava/lang/Boolean;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iget-object v2, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    iput v0, v2, Landroid/app/Notification;->defaults:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_2de

    iget v0, v2, Landroid/app/Notification;->flags:I

    or-int/2addr v0, v6

    iput v0, v2, Landroid/app/Notification;->flags:I

    :cond_2de
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getOngoing()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v1, v4, v0}, Landroidx/core/app/NotificationCompat$Builder;->h(IZ)V

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getOnlyAlertOnce()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/16 v2, 0x8

    invoke-virtual {v1, v2, v0}, Landroidx/core/app/NotificationCompat$Builder;->h(IZ)V

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getPriority()I

    move-result v0

    iput v0, v1, Landroidx/core/app/NotificationCompat$Builder;->k:I

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getProgress()Ld3/a;

    move-result-object v0

    if-eqz v0, :cond_30e

    iget v2, v0, Ld3/a;->a:I

    iput v2, v1, Landroidx/core/app/NotificationCompat$Builder;->q:I

    iget v2, v0, Ld3/a;->b:I

    iput v2, v1, Landroidx/core/app/NotificationCompat$Builder;->r:I

    iget-boolean v0, v0, Ld3/a;->c:Z

    iput-boolean v0, v1, Landroidx/core/app/NotificationCompat$Builder;->s:Z

    :cond_30e
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getShortcutId()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_31a

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getShortcutId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Landroidx/core/app/NotificationCompat$Builder;->H:Ljava/lang/String;

    :cond_31a
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getShowTimestamp()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, v1, Landroidx/core/app/NotificationCompat$Builder;->l:Z

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getSmallIcon()Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_347

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getSmallIconLevel()Ljava/lang/Integer;

    move-result-object v2

    if-eqz v2, :cond_33f

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget-object v4, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    iput v0, v4, Landroid/app/Notification;->icon:I

    iput v2, v4, Landroid/app/Notification;->iconLevel:I

    goto :goto_347

    :cond_33f
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iget-object v2, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    iput v0, v2, Landroid/app/Notification;->icon:I

    :cond_347
    :goto_347
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getSortKey()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_353

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getSortKey()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Landroidx/core/app/NotificationCompat$Builder;->v:Ljava/lang/String;

    :cond_353
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getTicker()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_365

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getTicker()Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    invoke-static {v0}, Landroidx/core/app/NotificationCompat$Builder;->b(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, v2, Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;

    :cond_365
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getTimeoutAfter()Ljava/lang/Long;

    move-result-object v0

    if-eqz v0, :cond_375

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getTimeoutAfter()Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    iput-wide v4, v1, Landroidx/core/app/NotificationCompat$Builder;->I:J

    :cond_375
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getShowChronometer()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, v1, Landroidx/core/app/NotificationCompat$Builder;->m:Z

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getVibrationPattern()[J

    move-result-object v0

    array-length v2, v0

    if-lez v2, :cond_38a

    iget-object v2, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    iput-object v0, v2, Landroid/app/Notification;->vibrate:[J

    :cond_38a
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getVisibility()I

    move-result v0

    iput v0, v1, Landroidx/core/app/NotificationCompat$Builder;->C:I

    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getTimestamp()J

    move-result-wide v4

    const-wide/16 v6, -0x1

    cmp-long v0, v4, v6

    if-lez v0, :cond_39e

    iget-object v0, v1, Landroidx/core/app/NotificationCompat$Builder;->L:Landroid/app/Notification;

    iput-wide v4, v0, Landroid/app/Notification;->when:J

    :cond_39e
    invoke-virtual {v3}, Lapp/notifee/core/model/NotificationAndroidModel;->getAutoCancel()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v1, v0}, Landroidx/core/app/NotificationCompat$Builder;->c(Z)V

    return-object v1

    :pswitch_data_3aa
    .packed-switch 0x0
        :pswitch_fc
        :pswitch_5b
        :pswitch_4e
        :pswitch_12
    .end packed-switch
.end method
