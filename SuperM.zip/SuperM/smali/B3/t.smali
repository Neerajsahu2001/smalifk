.class public final synthetic Lb3/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv7/b;
.implements Lv7/d;
.implements Lcom/nozbe/watermelondb/g;
.implements Lcom/nozbe/watermelondb/l;
.implements LZ0/m;
.implements Lio/sentry/R0;
.implements LD1/z;
.implements LA6/b;
.implements Lz6/m;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput p1, p0, Lb3/t;->a:I

    iput-object p2, p0, Lb3/t;->b:Ljava/lang/Object;

    iput-object p3, p0, Lb3/t;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lg1/a;Landroidx/media3/common/b;Landroidx/media3/exoplayer/g;)V
    .registers 4

    const/4 p3, 0x4

    iput p3, p0, Lb3/t;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb3/t;->b:Ljava/lang/Object;

    iput-object p2, p0, Lb3/t;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Landroid/database/sqlite/SQLiteDatabase;

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Lz6/o;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Ls6/k;

    invoke-static {p1, v1}, Lz6/o;->f(Landroid/database/sqlite/SQLiteDatabase;Ls6/k;)Ljava/lang/Long;

    move-result-object p1

    if-nez p1, :cond_16

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_3e

    :cond_16
    invoke-virtual {v0}, Lz6/o;->a()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Long;->toString()Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    instance-of v1, v0, Landroid/database/sqlite/SQLiteDatabase;

    const-string v2, "SELECT 1 FROM events WHERE context_id = ? LIMIT 1"

    if-nez v1, :cond_2d

    invoke-virtual {v0, v2, p1}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    goto :goto_31

    :cond_2d
    invoke-static {v0, v2, p1}, Lcom/newrelic/agent/android/instrumentation/SQLiteInstrumentation;->rawQuery(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    :goto_31
    new-instance v0, LR1/b;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, LR1/b;-><init>(I)V

    invoke-static {p1, v0}, Lz6/o;->K(Landroid/database/Cursor;Lz6/m;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    :goto_3e
    return-object p1
.end method

.method public b(Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/bridge/ReadableArray;

    invoke-static {v0, v1, p1}, Lcom/nozbe/watermelondb/WMDatabaseBridge;->c(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public c()V
    .registers 7

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Lcom/nozbe/watermelondb/h;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, ";"

    iget-object v2, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_13
    if-ge v3, v2, :cond_27

    aget-object v4, v1, v3

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_24

    invoke-virtual {v0, v4}, Lcom/nozbe/watermelondb/h;->b(Ljava/lang/String;)V

    :cond_24
    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    :cond_27
    return-void
.end method

.method public d()[LD1/w;
    .registers 4

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    iget-object v1, v0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->c:La2/j;

    iget-object v2, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v2, Landroidx/media3/common/b;

    invoke-interface {v1, v2}, La2/j;->p(Landroidx/media3/common/b;)Z

    move-result v1

    if-eqz v1, :cond_1c

    new-instance v1, La2/h;

    iget-object v0, v0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->c:La2/j;

    invoke-interface {v0, v2}, La2/j;->l(Landroidx/media3/common/b;)La2/l;

    move-result-object v0

    invoke-direct {v1, v0, v2}, La2/h;-><init>(La2/l;Landroidx/media3/common/b;)V

    goto :goto_21

    :cond_1c
    new-instance v1, Lt1/r;

    invoke-direct {v1, v2}, Lt1/r;-><init>(Landroidx/media3/common/b;)V

    :goto_21
    const/4 v0, 0x1

    new-array v0, v0, [LD1/w;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    return-object v0
.end method

.method public e(Lio/sentry/Q0;)V
    .registers 6

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/ActivityLifecycleIntegration;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Lio/sentry/Q;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, p1, Lio/sentry/Q0;->o:Ljava/lang/Object;

    monitor-enter v2

    :try_start_e
    iget-object v3, p1, Lio/sentry/Q0;->b:Lio/sentry/Q;

    if-nez v3, :cond_16

    invoke-virtual {p1, v1}, Lio/sentry/Q0;->c(Lio/sentry/Q;)V

    goto :goto_2d

    :cond_16
    iget-object p1, v0, Lio/sentry/android/core/ActivityLifecycleIntegration;->d:Lio/sentry/android/core/SentryAndroidOptions;

    if-eqz p1, :cond_2d

    invoke-virtual {p1}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object p1

    sget-object v0, Lio/sentry/y1;->DEBUG:Lio/sentry/y1;

    invoke-interface {v1}, Lio/sentry/Q;->getName()Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v3, "Transaction \'%s\' won\'t be bound to the Scope since there\'s one already in there."

    invoke-interface {p1, v0, v3, v1}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2d
    :goto_2d
    monitor-exit v2

    return-void

    :catchall_2f
    move-exception p1

    monitor-exit v2
    :try_end_31
    .catchall {:try_start_e .. :try_end_31} :catchall_2f

    throw p1
.end method

.method public execute()Ljava/lang/Object;
    .registers 8

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Ly6/f;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    int-to-long v3, v3

    sget-object v5, Lv6/c;->g:Lv6/c;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v6, v0, Ly6/f;->i:Lz6/c;

    check-cast v6, Lz6/o;

    invoke-virtual {v6, v3, v4, v2, v5}, Lz6/o;->p(JLjava/lang/String;Lv6/c;)V

    goto :goto_13

    :cond_3a
    const/4 v0, 0x0

    return-object v0
.end method

.method public f(Lv7/i;)Ljava/lang/Object;
    .registers 7

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lte/p;

    const/4 v0, 0x0

    if-eqz p1, :cond_d

    iget-object v1, p1, Lte/p;->b:[B

    if-nez v1, :cond_3d

    :cond_d
    iget-object v1, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v1, LN2/e;

    iget-object v1, v1, LN2/e;->a:Ljava/util/HashMap;

    const-string v2, "notification"

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, [Ljava/lang/Byte;

    if-eqz v2, :cond_33

    check-cast v1, [Ljava/lang/Byte;

    array-length v2, v1

    new-array v2, v2, [B

    const/4 v3, 0x0

    :goto_23
    array-length v4, v1

    if-ge v3, v4, :cond_31

    aget-object v4, v1, v3

    invoke-virtual {v4}, Ljava/lang/Byte;->byteValue()B

    move-result v4

    aput-byte v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_23

    :cond_31
    move-object v1, v2

    goto :goto_34

    :cond_33
    move-object v1, v0

    :goto_34
    const-string v2, "NotificationManager"

    if-eqz v1, :cond_53

    const-string v3, "The trigger notification was created using an older version, please consider recreating the notification."

    invoke-static {v2, v3}, Lapp/notifee/core/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3d
    invoke-static {v1}, Lte/g;->b([B)Landroid/os/Bundle;

    move-result-object v1

    new-instance v2, Lapp/notifee/core/model/NotificationModel;

    invoke-direct {v2, v1}, Lapp/notifee/core/model/NotificationModel;-><init>(Landroid/os/Bundle;)V

    iget-object p1, p1, Lte/p;->c:[B

    if-eqz p1, :cond_4e

    invoke-static {p1}, Lte/g;->b([B)Landroid/os/Bundle;

    move-result-object v0

    :cond_4e
    invoke-static {v2, v0}, Lb3/B;->a(Lapp/notifee/core/model/NotificationModel;Landroid/os/Bundle;)Lv7/v;

    move-result-object v0

    goto :goto_63

    :cond_53
    const-string p1, "Attempted to handle doScheduledWork but no notification data was found."

    invoke-static {v2, p1}, Lapp/notifee/core/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, LN2/l;->a()LN2/k;

    move-result-object p1

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/concurrent/futures/k;

    invoke-virtual {v1, p1}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    :goto_63
    return-object v0
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, Lb3/t;->a:I

    check-cast p1, Lg1/b;

    packed-switch v0, :pswitch_data_20

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Lt1/A;

    invoke-interface {p1, v0, v1}, Lg1/b;->j(Lg1/a;Lt1/A;)V

    return-void

    :pswitch_13
    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Lg1/a;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/media3/common/b;

    invoke-interface {p1, v0, v1}, Lg1/b;->d(Lg1/a;Landroidx/media3/common/b;)V

    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x4
        :pswitch_13
    .end packed-switch
.end method

.method public onComplete(Lv7/i;)V
    .registers 4

    iget v0, p0, Lb3/t;->a:I

    packed-switch v0, :pswitch_data_1e

    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/bridge/Promise;

    invoke-static {v0, v1, p1}, Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;->c(Lio/invertase/firebase/config/ReactNativeFirebaseConfigModule;Lcom/facebook/react/bridge/Promise;Lv7/i;)V

    return-void

    :pswitch_11
    iget-object v0, p0, Lb3/t;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/messaging/EnhancedIntentService;

    iget-object v1, p0, Lb3/t;->c:Ljava/lang/Object;

    check-cast v1, Landroid/content/Intent;

    invoke-static {v0, v1, p1}, Lcom/google/firebase/messaging/EnhancedIntentService;->b(Lcom/google/firebase/messaging/EnhancedIntentService;Landroid/content/Intent;Lv7/i;)V

    return-void

    nop

    :pswitch_data_1e
    .packed-switch 0x1
        :pswitch_11
    .end packed-switch
.end method
