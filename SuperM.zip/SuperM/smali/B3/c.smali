.class public final synthetic Lb3/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv7/d;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lapp/notifee/core/interfaces/MethodCallResult;


# direct methods
.method public synthetic constructor <init>(ILapp/notifee/core/interfaces/MethodCallResult;)V
    .registers 3

    iput p1, p0, Lb3/c;->a:I

    iput-object p2, p0, Lb3/c;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onComplete(Lv7/i;)V
    .registers 7

    iget v0, p0, Lb3/c;->a:I

    packed-switch v0, :pswitch_data_40

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    iget-object v1, p0, Lb3/c;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v2, 0x0

    if-eqz v0, :cond_12

    invoke-interface {v1, v2, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_24

    :cond_12
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object v0

    const-string v3, "API"

    const-string v4, "displayNotification"

    invoke-static {v3, v4, v0}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v1, p1, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_24
    return-void

    :pswitch_25
    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    iget-object v1, p0, Lb3/c;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v2, 0x0

    if-eqz v0, :cond_38

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    invoke-interface {v1, v2, p1}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_3f

    :cond_38
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v1, p1, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_3f
    return-void

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_25
    .end packed-switch
.end method
