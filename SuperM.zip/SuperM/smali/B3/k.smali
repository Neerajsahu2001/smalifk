.class public final synthetic Lb3/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lb3/k;->a:I

    iput-object p2, p0, Lb3/k;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 3

    iget v0, p0, Lb3/k;->a:I

    packed-switch v0, :pswitch_data_2e

    iget-object v0, p0, Lb3/k;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/messaging/FirebaseMessaging;

    invoke-static {v0}, Lio/invertase/firebase/messaging/ReactNativeFirebaseMessagingModule;->c(Lcom/google/firebase/messaging/FirebaseMessaging;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :pswitch_e
    iget-object v0, p0, Lb3/k;->b:Ljava/lang/Object;

    check-cast v0, Landroid/os/Bundle;

    invoke-static {v0}, Lapp/notifee/core/model/NotificationAndroidStyleModel;->c(Landroid/os/Bundle;)Ld0/g0;

    move-result-object v0

    return-object v0

    :pswitch_17
    sget-object v0, Lm7/D2;->a:Landroid/content/Context;

    new-instance v1, Ld0/c0;

    invoke-direct {v1, v0}, Ld0/c0;-><init>(Landroid/content/Context;)V

    iget-object v0, v1, Ld0/c0;->b:Landroid/app/NotificationManager;

    iget-object v1, p0, Lb3/k;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Ld0/W;->i(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v0

    invoke-static {v0}, Lb3/p;->a(Landroid/app/NotificationChannel;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_2e
    .packed-switch 0x0
        :pswitch_17
        :pswitch_e
    .end packed-switch
.end method
