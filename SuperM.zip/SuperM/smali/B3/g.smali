.class public final synthetic Lb3/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv7/d;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lapp/notifee/core/interfaces/MethodCallResult;


# direct methods
.method public synthetic constructor <init>(ILapp/notifee/core/interfaces/MethodCallResult;)V
    .registers 3

    iput p1, p0, Lb3/g;->a:I

    iput-object p2, p0, Lb3/g;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onComplete(Lv7/i;)V
    .registers 8

    iget v0, p0, Lb3/g;->a:I

    packed-switch v0, :pswitch_data_c6

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v1

    iget-object v2, p0, Lb3/g;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v3, 0x0

    if-eqz v1, :cond_33

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2f

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lte/p;

    iget-object v1, v1, Lte/p;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1d

    :cond_2f
    invoke-interface {v2, v3, v0}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_3a

    :cond_33
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v2, p1, v3}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_3a
    return-void

    :pswitch_3b
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v1

    iget-object v2, p0, Lb3/g;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    if-eqz v1, :cond_82

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_52
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lte/p;

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    iget-object v4, v1, Lte/p;->b:[B

    invoke-static {v4}, Lte/g;->b([B)Landroid/os/Bundle;

    move-result-object v4

    const-string v5, "notification"

    invoke-virtual {v3, v5, v4}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v1, v1, Lte/p;->c:[B

    invoke-static {v1}, Lte/g;->b([B)Landroid/os/Bundle;

    move-result-object v1

    const-string v4, "trigger"

    invoke-virtual {v3, v4, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_52

    :cond_7d
    const/4 p1, 0x0

    invoke-interface {v2, p1, v0}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_89

    :cond_82
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v2, p1, v0}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_89
    return-void

    :pswitch_8a
    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    iget-object v1, p0, Lb3/g;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v2, 0x0

    if-eqz v0, :cond_9d

    invoke-virtual {p1}, Lv7/i;->j()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Void;

    invoke-interface {v1, v2, p1}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_a4

    :cond_9d
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v1, p1, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_a4
    return-void

    :pswitch_a5
    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    iget-object v1, p0, Lb3/g;->b:Lapp/notifee/core/interfaces/MethodCallResult;

    const/4 v2, 0x0

    if-eqz v0, :cond_b2

    invoke-interface {v1, v2, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    goto :goto_c4

    :cond_b2
    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object v0

    const-string v3, "API"

    const-string v4, "createTriggerNotification"

    invoke-static {v3, v4, v0}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    invoke-interface {v1, p1, v2}, Lapp/notifee/core/interfaces/MethodCallResult;->onComplete(Ljava/lang/Exception;Ljava/lang/Object;)V

    :goto_c4
    return-void

    nop

    :pswitch_data_c6
    .packed-switch 0x0
        :pswitch_a5
        :pswitch_8a
        :pswitch_3b
    .end packed-switch
.end method
