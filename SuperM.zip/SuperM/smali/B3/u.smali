.class public final synthetic Lb3/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv7/d;
.implements Lcom/nozbe/watermelondb/l;
.implements LZ0/m;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lg1/a;Lt1/v;Lt1/A;Ljava/io/IOException;Z)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb3/u;->b:Ljava/lang/Object;

    iput-object p3, p0, Lb3/u;->c:Ljava/lang/Object;

    iput-object p4, p0, Lb3/u;->a:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    iput-object p1, p0, Lb3/u;->b:Ljava/lang/Object;

    iput-object p2, p0, Lb3/u;->c:Ljava/lang/Object;

    iput-object p3, p0, Lb3/u;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb3/u;->a:Ljava/lang/Object;

    iput-object p2, p0, Lb3/u;->b:Ljava/lang/Object;

    iput-object p3, p0, Lb3/u;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(Lio/sentry/Y1;)V
    .registers 8

    const/4 v0, 0x0

    iget-object v1, p0, Lb3/u;->b:Ljava/lang/Object;

    check-cast v1, Lio/sentry/c1;

    if-eqz p1, :cond_6e

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lb3/u;->c:Ljava/lang/Object;

    check-cast v1, Lio/sentry/s1;

    invoke-virtual {v1}, Lio/sentry/s1;->b()Lio/sentry/protocol/x;

    move-result-object v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    move v2, v3

    goto :goto_18

    :cond_17
    move v2, v0

    :goto_18
    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    sget-object v2, Lio/sentry/X1;->Crashed:Lio/sentry/X1;

    goto :goto_1f

    :cond_1e
    move-object v2, v4

    :goto_1f
    sget-object v5, Lio/sentry/X1;->Crashed:Lio/sentry/X1;

    if-eq v5, v2, :cond_29

    invoke-virtual {v1}, Lio/sentry/s1;->c()Z

    move-result v5

    if-eqz v5, :cond_2a

    :cond_29
    move v0, v3

    :cond_2a
    iget-object v3, v1, Lio/sentry/a1;->d:Lio/sentry/protocol/s;

    if-eqz v3, :cond_45

    iget-object v3, v3, Lio/sentry/protocol/s;->f:Ljava/util/Map;

    if-eqz v3, :cond_45

    const-string v5, "user-agent"

    invoke-interface {v3, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_45

    iget-object v1, v1, Lio/sentry/a1;->d:Lio/sentry/protocol/s;

    iget-object v1, v1, Lio/sentry/protocol/s;->f:Ljava/util/Map;

    invoke-interface {v1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    goto :goto_46

    :cond_45
    move-object v1, v4

    :goto_46
    iget-object v3, p0, Lb3/u;->a:Ljava/lang/Object;

    check-cast v3, Lio/sentry/v;

    invoke-static {v3}, Lcom/facebook/imagepipeline/nativecode/b;->c(Lio/sentry/v;)Ljava/lang/Object;

    move-result-object v3

    instance-of v5, v3, Lio/sentry/hints/a;

    if-eqz v5, :cond_5a

    check-cast v3, Lio/sentry/hints/a;

    invoke-interface {v3}, Lio/sentry/hints/a;->e()Ljava/lang/String;

    move-result-object v4

    sget-object v2, Lio/sentry/X1;->Abnormal:Lio/sentry/X1;

    :cond_5a
    invoke-virtual {p1, v2, v1, v0, v4}, Lio/sentry/Y1;->c(Lio/sentry/X1;Ljava/lang/String;ZLjava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7f

    iget-object v0, p1, Lio/sentry/Y1;->g:Lio/sentry/X1;

    sget-object v1, Lio/sentry/X1;->Ok:Lio/sentry/X1;

    if-eq v0, v1, :cond_7f

    invoke-static {}, LZ6/f;->c()Ljava/util/Date;

    move-result-object v0

    invoke-virtual {p1, v0}, Lio/sentry/Y1;->b(Ljava/util/Date;)V

    goto :goto_7f

    :cond_6e
    iget-object p1, v1, Lio/sentry/c1;->a:Ljava/lang/Object;

    check-cast p1, Lio/sentry/M1;

    invoke-virtual {p1}, Lio/sentry/M1;->getLogger()Lio/sentry/ILogger;

    move-result-object p1

    sget-object v1, Lio/sentry/y1;->INFO:Lio/sentry/y1;

    const-string v2, "Session is null on scope.withSession"

    new-array v0, v0, [Ljava/lang/Object;

    invoke-interface {p1, v1, v2, v0}, Lio/sentry/ILogger;->k(Lio/sentry/y1;Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_7f
    :goto_7f
    return-void
.end method

.method public b(Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, Lb3/u;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lb3/u;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/bridge/ReadableArray;

    iget-object v2, p0, Lb3/u;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-static {v2, v0, v1, p1}, Lcom/nozbe/watermelondb/WMDatabaseBridge;->g(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;Lcom/nozbe/watermelondb/q;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public invoke(Ljava/lang/Object;)V
    .registers 5

    check-cast p1, Lg1/b;

    iget-object v0, p0, Lb3/u;->c:Ljava/lang/Object;

    check-cast v0, Lt1/A;

    iget-object v1, p0, Lb3/u;->a:Ljava/lang/Object;

    check-cast v1, Ljava/io/IOException;

    iget-object v2, p0, Lb3/u;->b:Ljava/lang/Object;

    check-cast v2, Lg1/a;

    invoke-interface {p1, v2, v0, v1}, Lg1/b;->r(Lg1/a;Lt1/A;Ljava/io/IOException;)V

    return-void
.end method

.method public onComplete(Lv7/i;)V
    .registers 6

    invoke-static {}, LN2/l;->a()LN2/k;

    move-result-object v0

    iget-object v1, p0, Lb3/u;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/concurrent/futures/k;

    invoke-virtual {v1, v0}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Lv7/i;->l()Z

    move-result v0

    if-nez v0, :cond_1d

    invoke-virtual {p1}, Lv7/i;->i()Ljava/lang/Exception;

    move-result-object p1

    const-string v0, "NotificationManager"

    const-string v1, "Failed to display notification"

    invoke-static {v0, v1, p1}, Lapp/notifee/core/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_49

    :cond_1d
    const-string p1, "workRequestType"

    iget-object v0, p0, Lb3/u;->c:Ljava/lang/Object;

    check-cast v0, LN2/e;

    invoke-virtual {v0, p1}, LN2/e;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_49

    const-string v0, "OneTime"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_49

    sget-object p1, Lm7/D2;->a:Landroid/content/Context;

    invoke-static {p1}, Lapp/notifee/core/database/a;->a(Landroid/content/Context;)Lapp/notifee/core/database/a;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lapp/notifee/core/database/NotifeeCoreDatabase;->l:Ljava/util/concurrent/ExecutorService;

    new-instance v1, LB/e;

    iget-object v2, p0, Lb3/u;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    const/4 v3, 0x6

    invoke-direct {v1, v3, p1, v2}, LB/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_49
    :goto_49
    return-void
.end method
