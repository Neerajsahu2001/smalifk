.class public final LC5/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC5/l;


# instance fields
.field public final a:LC5/f;

.field public final b:LC5/f;

.field public final c:LC5/q;

.field public final d:LT4/g;

.field public e:LC5/m;

.field public f:J

.field public final g:Z

.field public final h:Z


# direct methods
.method public constructor <init>(LC5/q;LT4/g;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object p1, p0, LC5/k;->c:LC5/q;

    new-instance v0, LC5/f;

    new-instance v1, Lfc/l;

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v1, p0, p1, v2, v3}, Lfc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    invoke-direct {v0, v1}, LC5/f;-><init>(Lfc/l;)V

    iput-object v0, p0, LC5/k;->a:LC5/f;

    new-instance v0, LC5/f;

    new-instance v1, Lfc/l;

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v1, p0, p1, v2, v3}, Lfc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    invoke-direct {v0, v1}, LC5/f;-><init>(Lfc/l;)V

    iput-object v0, p0, LC5/k;->b:LC5/f;

    iput-object p2, p0, LC5/k;->d:LT4/g;

    invoke-interface {p2}, LT4/g;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LC5/m;

    const-string p2, "mMemoryCacheParamsSupplier returned null"

    invoke-static {p1, p2}, Lm7/q;->d(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LC5/k;->e:LC5/m;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p1

    iput-wide p1, p0, LC5/k;->f:J

    const/4 p1, 0x0

    iput-boolean p1, p0, LC5/k;->g:Z

    iput-boolean p1, p0, LC5/k;->h:Z

    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Ljava/util/ArrayList;)V
    .registers 5

    monitor-enter p0

    if-eqz p1, :cond_28

    :try_start_3
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_28

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LC5/g;

    monitor-enter p0
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_25

    :try_start_14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v1, v0, LC5/g;->d:Z

    const/4 v2, 0x1

    xor-int/2addr v1, v2

    invoke-static {v1}, Lm7/q;->e(Z)V

    iput-boolean v2, v0, LC5/g;->d:Z
    :try_end_20
    .catchall {:try_start_14 .. :try_end_20} :catchall_22

    :try_start_20
    monitor-exit p0

    goto :goto_7

    :catchall_22
    move-exception p1

    monitor-exit p0

    throw p1
    :try_end_25
    .catchall {:try_start_20 .. :try_end_25} :catchall_25

    :catchall_25
    move-exception p1

    monitor-exit p0

    throw p1

    :cond_28
    monitor-exit p0

    return-void
.end method

.method public final b(Ljava/lang/Object;LX4/b;)LX4/b;
    .registers 10

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, LC5/k;->d()V

    monitor-enter p0

    :try_start_a
    iget-object v0, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v0, p1}, LC5/f;->d(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LC5/g;

    iget-object v0, p0, LC5/k;->b:LC5/f;

    invoke-virtual {v0, p1}, LC5/f;->d(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LC5/g;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_33

    monitor-enter p0
    :try_end_1f
    .catchall {:try_start_a .. :try_end_1f} :catchall_2d

    :try_start_1f
    iget-boolean v3, v0, LC5/g;->d:Z

    xor-int/2addr v3, v1

    invoke-static {v3}, Lm7/q;->e(Z)V

    iput-boolean v1, v0, LC5/g;->d:Z
    :try_end_27
    .catchall {:try_start_1f .. :try_end_27} :catchall_30

    :try_start_27
    monitor-exit p0

    invoke-virtual {p0, v0}, LC5/k;->g(LC5/g;)LX4/b;

    move-result-object v0

    goto :goto_34

    :catchall_2d
    move-exception p1

    goto/16 :goto_a8

    :catchall_30
    move-exception p1

    monitor-exit p0

    throw p1

    :cond_33
    move-object v0, v2

    :goto_34
    invoke-virtual {p2}, LX4/b;->p()Ljava/lang/Object;

    move-result-object v3

    iget-object v4, p0, LC5/k;->c:LC5/q;

    invoke-interface {v4, v3}, LC5/q;->e(Ljava/lang/Object;)I

    move-result v3

    monitor-enter p0
    :try_end_3f
    .catchall {:try_start_27 .. :try_end_3f} :catchall_2d

    :try_start_3f
    iget-object v4, p0, LC5/k;->e:LC5/m;

    iget v4, v4, LC5/m;->d:I

    if-gt v3, v4, :cond_81

    monitor-enter p0
    :try_end_46
    .catchall {:try_start_3f .. :try_end_46} :catchall_72

    :try_start_46
    iget-object v4, p0, LC5/k;->b:LC5/f;

    invoke-virtual {v4}, LC5/f;->a()I

    move-result v4

    iget-object v5, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v5}, LC5/f;->a()I

    move-result v5
    :try_end_52
    .catchall {:try_start_46 .. :try_end_52} :catchall_7e

    sub-int/2addr v4, v5

    :try_start_53
    monitor-exit p0

    iget-object v5, p0, LC5/k;->e:LC5/m;

    iget v5, v5, LC5/m;->b:I

    sub-int/2addr v5, v1

    if-gt v4, v5, :cond_81

    monitor-enter p0
    :try_end_5c
    .catchall {:try_start_53 .. :try_end_5c} :catchall_72

    :try_start_5c
    iget-object v4, p0, LC5/k;->b:LC5/f;

    monitor-enter v4
    :try_end_5f
    .catchall {:try_start_5c .. :try_end_5f} :catchall_77

    :try_start_5f
    iget v5, v4, LC5/f;->a:I
    :try_end_61
    .catchall {:try_start_5f .. :try_end_61} :catchall_79

    :try_start_61
    monitor-exit v4

    iget-object v4, p0, LC5/k;->a:LC5/f;

    monitor-enter v4
    :try_end_65
    .catchall {:try_start_61 .. :try_end_65} :catchall_77

    :try_start_65
    iget v6, v4, LC5/f;->a:I
    :try_end_67
    .catchall {:try_start_65 .. :try_end_67} :catchall_74

    :try_start_67
    monitor-exit v4
    :try_end_68
    .catchall {:try_start_67 .. :try_end_68} :catchall_77

    sub-int/2addr v5, v6

    :try_start_69
    monitor-exit p0

    iget-object v4, p0, LC5/k;->e:LC5/m;

    iget v4, v4, LC5/m;->a:I
    :try_end_6e
    .catchall {:try_start_69 .. :try_end_6e} :catchall_72

    sub-int/2addr v4, v3

    if-gt v5, v4, :cond_81

    goto :goto_82

    :catchall_72
    move-exception p1

    goto :goto_a6

    :catchall_74
    move-exception p1

    :try_start_75
    monitor-exit v4

    throw p1

    :catchall_77
    move-exception p1

    goto :goto_7c

    :catchall_79
    move-exception p1

    monitor-exit v4

    throw p1
    :try_end_7c
    .catchall {:try_start_75 .. :try_end_7c} :catchall_77

    :goto_7c
    :try_start_7c
    monitor-exit p0

    throw p1

    :catchall_7e
    move-exception p1

    monitor-exit p0

    throw p1
    :try_end_81
    .catchall {:try_start_7c .. :try_end_81} :catchall_72

    :cond_81
    const/4 v1, 0x0

    :goto_82
    :try_start_82
    monitor-exit p0

    if-eqz v1, :cond_9e

    iget-boolean v1, p0, LC5/k;->g:Z

    if-eqz v1, :cond_8f

    new-instance v1, LC5/g;

    invoke-direct {v1, p1, p2, v3}, LC5/g;-><init>(Ljava/lang/Object;LX4/b;I)V

    goto :goto_95

    :cond_8f
    new-instance v1, LC5/g;

    const/4 v2, -0x1

    invoke-direct {v1, p1, p2, v2}, LC5/g;-><init>(Ljava/lang/Object;LX4/b;I)V

    :goto_95
    iget-object p2, p0, LC5/k;->b:LC5/f;

    invoke-virtual {p2, p1, v1}, LC5/f;->c(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v1}, LC5/k;->e(LC5/g;)LX4/b;

    move-result-object v2

    :cond_9e
    monitor-exit p0
    :try_end_9f
    .catchall {:try_start_82 .. :try_end_9f} :catchall_2d

    invoke-static {v0}, LX4/b;->l(LX4/b;)V

    invoke-virtual {p0}, LC5/k;->c()V

    return-object v2

    :goto_a6
    :try_start_a6
    monitor-exit p0

    throw p1

    :goto_a8
    monitor-exit p0
    :try_end_a9
    .catchall {:try_start_a6 .. :try_end_a9} :catchall_2d

    throw p1
.end method

.method public final c()V
    .registers 7

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LC5/k;->e:LC5/m;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, LC5/k;->e:LC5/m;

    iget v0, v0, LC5/m;->b:I

    monitor-enter p0
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_71

    :try_start_b
    iget-object v1, p0, LC5/k;->b:LC5/f;

    invoke-virtual {v1}, LC5/f;->a()I

    move-result v1

    iget-object v2, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v2}, LC5/f;->a()I

    move-result v2
    :try_end_17
    .catchall {:try_start_b .. :try_end_17} :catchall_7d

    sub-int/2addr v1, v2

    :try_start_18
    monitor-exit p0

    sub-int/2addr v0, v1

    const v1, 0x7fffffff

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget-object v1, p0, LC5/k;->e:LC5/m;

    iget v2, v1, LC5/m;->c:I

    iget v1, v1, LC5/m;->a:I

    monitor-enter p0
    :try_end_28
    .catchall {:try_start_18 .. :try_end_28} :catchall_71

    :try_start_28
    iget-object v3, p0, LC5/k;->b:LC5/f;

    monitor-enter v3
    :try_end_2b
    .catchall {:try_start_28 .. :try_end_2b} :catchall_76

    :try_start_2b
    iget v4, v3, LC5/f;->a:I
    :try_end_2d
    .catchall {:try_start_2b .. :try_end_2d} :catchall_78

    :try_start_2d
    monitor-exit v3

    iget-object v3, p0, LC5/k;->a:LC5/f;

    monitor-enter v3
    :try_end_31
    .catchall {:try_start_2d .. :try_end_31} :catchall_76

    :try_start_31
    iget v5, v3, LC5/f;->a:I
    :try_end_33
    .catchall {:try_start_31 .. :try_end_33} :catchall_73

    :try_start_33
    monitor-exit v3
    :try_end_34
    .catchall {:try_start_33 .. :try_end_34} :catchall_76

    sub-int/2addr v4, v5

    :try_start_35
    monitor-exit p0

    sub-int/2addr v1, v4

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-virtual {p0, v0, v1}, LC5/k;->h(II)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p0, v0}, LC5/k;->a(Ljava/util/ArrayList;)V

    monitor-exit p0
    :try_end_43
    .catchall {:try_start_35 .. :try_end_43} :catchall_71

    if-eqz v0, :cond_5d

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_49
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC5/g;

    invoke-virtual {p0, v2}, LC5/k;->g(LC5/g;)LX4/b;

    move-result-object v2

    invoke-static {v2}, LX4/b;->l(LX4/b;)V

    goto :goto_49

    :cond_5d
    if-eqz v0, :cond_70

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_63
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_70

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LC5/g;

    goto :goto_63

    :cond_70
    return-void

    :catchall_71
    move-exception v0

    goto :goto_80

    :catchall_73
    move-exception v0

    :try_start_74
    monitor-exit v3

    throw v0

    :catchall_76
    move-exception v0

    goto :goto_7b

    :catchall_78
    move-exception v0

    monitor-exit v3

    throw v0
    :try_end_7b
    .catchall {:try_start_74 .. :try_end_7b} :catchall_76

    :goto_7b
    :try_start_7b
    monitor-exit p0

    throw v0

    :catchall_7d
    move-exception v0

    monitor-exit p0

    throw v0

    :goto_80
    monitor-exit p0
    :try_end_81
    .catchall {:try_start_7b .. :try_end_81} :catchall_71

    throw v0
.end method

.method public final declared-synchronized d()V
    .registers 5

    monitor-enter p0

    :try_start_1
    iget-wide v0, p0, LC5/k;->f:J

    iget-object v2, p0, LC5/k;->e:LC5/m;

    iget-wide v2, v2, LC5/m;->e:J

    add-long/2addr v0, v2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2
    :try_end_c
    .catchall {:try_start_1 .. :try_end_c} :catchall_29

    cmp-long v0, v0, v2

    if-lez v0, :cond_12

    monitor-exit p0

    return-void

    :cond_12
    :try_start_12
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, LC5/k;->f:J

    iget-object v0, p0, LC5/k;->d:LT4/g;

    invoke-interface {v0}, LT4/g;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LC5/m;

    const-string v1, "mMemoryCacheParamsSupplier returned null"

    invoke-static {v0, v1}, Lm7/q;->d(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, LC5/k;->e:LC5/m;
    :try_end_27
    .catchall {:try_start_12 .. :try_end_27} :catchall_29

    monitor-exit p0

    return-void

    :catchall_29
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized e(LC5/g;)LX4/b;
    .registers 4

    monitor-enter p0

    :try_start_1
    monitor-enter p0
    :try_end_2
    .catchall {:try_start_1 .. :try_end_2} :catchall_27

    :try_start_2
    iget-boolean v0, p1, LC5/g;->d:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lm7/q;->e(Z)V

    iget v0, p1, LC5/g;->c:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p1, LC5/g;->c:I
    :try_end_f
    .catchall {:try_start_2 .. :try_end_f} :catchall_29

    :try_start_f
    monitor-exit p0

    iget-object v0, p1, LC5/g;->b:LX4/b;

    invoke-virtual {v0}, LX4/b;->p()Ljava/lang/Object;

    move-result-object v0

    new-instance v1, Lio/sentry/internal/debugmeta/c;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object p0, v1, Lio/sentry/internal/debugmeta/c;->b:Ljava/lang/Object;

    iput-object p1, v1, Lio/sentry/internal/debugmeta/c;->a:Ljava/lang/Object;

    sget-object p1, LX4/b;->f:LU7/e;

    invoke-static {v0, v1, p1}, LX4/b;->i0(Ljava/lang/Object;LX4/c;LX4/a;)LX4/b;

    move-result-object p1
    :try_end_25
    .catchall {:try_start_f .. :try_end_25} :catchall_27

    monitor-exit p0

    return-object p1

    :catchall_27
    move-exception p1

    goto :goto_2c

    :catchall_29
    move-exception p1

    :try_start_2a
    monitor-exit p0

    throw p1
    :try_end_2c
    .catchall {:try_start_2a .. :try_end_2c} :catchall_27

    :goto_2c
    monitor-exit p0

    throw p1
.end method

.method public final f(LE5/b;)I
    .registers 5

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v0, p1}, LC5/f;->e(LE5/b;)Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, LC5/k;->b:LC5/f;

    invoke-virtual {v1, p1}, LC5/f;->e(LE5/b;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p0, p1}, LC5/k;->a(Ljava/util/ArrayList;)V

    monitor-exit p0
    :try_end_11
    .catchall {:try_start_1 .. :try_end_11} :catchall_45

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_15
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_29

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LC5/g;

    invoke-virtual {p0, v2}, LC5/k;->g(LC5/g;)LX4/b;

    move-result-object v2

    invoke-static {v2}, LX4/b;->l(LX4/b;)V

    goto :goto_15

    :cond_29
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LC5/g;

    goto :goto_2d

    :cond_3a
    invoke-virtual {p0}, LC5/k;->d()V

    invoke-virtual {p0}, LC5/k;->c()V

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    return p1

    :catchall_45
    move-exception p1

    :try_start_46
    monitor-exit p0
    :try_end_47
    .catchall {:try_start_46 .. :try_end_47} :catchall_45

    throw p1
.end method

.method public final declared-synchronized g(LC5/g;)LX4/b;
    .registers 3

    monitor-enter p0

    :try_start_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p1, LC5/g;->d:Z

    if-eqz v0, :cond_11

    iget v0, p1, LC5/g;->c:I

    if-nez v0, :cond_11

    iget-object p1, p1, LC5/g;->b:LX4/b;
    :try_end_e
    .catchall {:try_start_1 .. :try_end_e} :catchall_f

    goto :goto_12

    :catchall_f
    move-exception p1

    goto :goto_14

    :cond_11
    const/4 p1, 0x0

    :goto_12
    monitor-exit p0

    return-object p1

    :goto_14
    monitor-exit p0

    throw p1
.end method

.method public final get(Ljava/lang/Object;)LX4/b;
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter p0

    :try_start_4
    iget-object v0, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v0, p1}, LC5/f;->d(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LC5/g;

    iget-object v0, p0, LC5/k;->b:LC5/f;

    monitor-enter v0
    :try_end_f
    .catchall {:try_start_4 .. :try_end_f} :catchall_21

    :try_start_f
    iget-object v1, v0, LC5/f;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_17
    .catchall {:try_start_f .. :try_end_17} :catchall_2c

    :try_start_17
    monitor-exit v0

    check-cast p1, LC5/g;

    if-eqz p1, :cond_23

    invoke-virtual {p0, p1}, LC5/k;->e(LC5/g;)LX4/b;

    move-result-object p1

    goto :goto_24

    :catchall_21
    move-exception p1

    goto :goto_2f

    :cond_23
    const/4 p1, 0x0

    :goto_24
    monitor-exit p0
    :try_end_25
    .catchall {:try_start_17 .. :try_end_25} :catchall_21

    invoke-virtual {p0}, LC5/k;->d()V

    invoke-virtual {p0}, LC5/k;->c()V

    return-object p1

    :catchall_2c
    move-exception p1

    :try_start_2d
    monitor-exit v0

    throw p1

    :goto_2f
    monitor-exit p0
    :try_end_30
    .catchall {:try_start_2d .. :try_end_30} :catchall_21

    throw p1
.end method

.method public final declared-synchronized h(II)Ljava/util/ArrayList;
    .registers 8

    monitor-enter p0

    const/4 v0, 0x0

    :try_start_2
    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    move-result p2

    iget-object v1, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v1}, LC5/f;->a()I

    move-result v1

    const/4 v2, 0x0

    if-gt v1, p1, :cond_23

    iget-object v1, p0, LC5/k;->a:LC5/f;

    monitor-enter v1
    :try_end_16
    .catchall {:try_start_2 .. :try_end_16} :catchall_20

    :try_start_16
    iget v3, v1, LC5/f;->a:I
    :try_end_18
    .catchall {:try_start_16 .. :try_end_18} :catchall_1d

    :try_start_18
    monitor-exit v1
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_20

    if-gt v3, p2, :cond_23

    monitor-exit p0

    return-object v2

    :catchall_1d
    move-exception p1

    :try_start_1e
    monitor-exit v1

    throw p1

    :catchall_20
    move-exception p1

    goto/16 :goto_b5

    :cond_23
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :goto_28
    iget-object v3, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v3}, LC5/f;->a()I

    move-result v3

    if-gt v3, p1, :cond_3c

    iget-object v3, p0, LC5/k;->a:LC5/f;

    monitor-enter v3
    :try_end_33
    .catchall {:try_start_1e .. :try_end_33} :catchall_20

    :try_start_33
    iget v4, v3, LC5/f;->a:I
    :try_end_35
    .catchall {:try_start_33 .. :try_end_35} :catchall_39

    :try_start_35
    monitor-exit v3

    if-le v4, p2, :cond_75

    goto :goto_3c

    :catchall_39
    move-exception p1

    monitor-exit v3

    throw p1

    :cond_3c
    :goto_3c
    iget-object v3, p0, LC5/k;->a:LC5/f;

    monitor-enter v3
    :try_end_3f
    .catchall {:try_start_35 .. :try_end_3f} :catchall_20

    :try_start_3f
    iget-object v4, v3, LC5/f;->c:Ljava/lang/Object;

    check-cast v4, Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_4b

    move-object v4, v2

    goto :goto_5b

    :cond_4b
    iget-object v4, v3, LC5/f;->c:Ljava/lang/Object;

    check-cast v4, Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4
    :try_end_5b
    .catchall {:try_start_3f .. :try_end_5b} :catchall_b2

    :goto_5b
    :try_start_5b
    monitor-exit v3

    if-nez v4, :cond_a0

    iget-boolean p1, p0, LC5/k;->h:Z

    if-eqz p1, :cond_79

    iget-object p1, p0, LC5/k;->a:LC5/f;

    monitor-enter p1
    :try_end_65
    .catchall {:try_start_5b .. :try_end_65} :catchall_20

    :try_start_65
    iget-object p2, p1, LC5/f;->c:Ljava/lang/Object;

    check-cast p2, Ljava/util/LinkedHashMap;

    invoke-virtual {p2}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_74

    iput v0, p1, LC5/f;->a:I
    :try_end_71
    .catchall {:try_start_65 .. :try_end_71} :catchall_72

    goto :goto_74

    :catchall_72
    move-exception p2

    goto :goto_77

    :cond_74
    :goto_74
    :try_start_74
    monitor-exit p1
    :try_end_75
    .catchall {:try_start_74 .. :try_end_75} :catchall_20

    :cond_75
    monitor-exit p0

    return-object v1

    :goto_77
    :try_start_77
    monitor-exit p1

    throw p2

    :cond_79
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "key is null, but exclusiveEntries count: %d, size: %d"

    iget-object v0, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v0}, LC5/f;->a()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget-object v1, p0, LC5/k;->a:LC5/f;

    monitor-enter v1
    :try_end_8a
    .catchall {:try_start_77 .. :try_end_8a} :catchall_20

    :try_start_8a
    iget v2, v1, LC5/f;->a:I
    :try_end_8c
    .catchall {:try_start_8a .. :try_end_8c} :catchall_9d

    :try_start_8c
    monitor-exit v1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {p2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_9d
    move-exception p1

    monitor-exit v1

    throw p1

    :cond_a0
    iget-object v3, p0, LC5/k;->a:LC5/f;

    invoke-virtual {v3, v4}, LC5/f;->d(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v3, p0, LC5/k;->b:LC5/f;

    invoke-virtual {v3, v4}, LC5/f;->d(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LC5/g;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_28

    :catchall_b2
    move-exception p1

    monitor-exit v3

    throw p1
    :try_end_b5
    .catchall {:try_start_8c .. :try_end_b5} :catchall_20

    :goto_b5
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized j(LD/C;)Z
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LC5/k;->b:LC5/f;

    invoke-virtual {v0, p1}, LC5/f;->b(LD/C;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_f

    xor-int/lit8 p1, p1, 0x1

    monitor-exit p0

    return p1

    :catchall_f
    move-exception p1

    monitor-exit p0

    throw p1
.end method
