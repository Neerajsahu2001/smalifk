.class public interface abstract LC5/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract o(Ljava/lang/Object;)V
.end method

.method public abstract r(Ljava/lang/Object;)V
.end method

.method public abstract u(Ljava/lang/Object;)V
.end method
