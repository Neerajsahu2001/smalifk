.class public final LC5/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC/D;
.implements Landroidx/concurrent/futures/l;
.implements Lcom/bumptech/glide/integration/webp/c;
.implements Ls4/k;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    const/4 v0, 0x0

    iput p1, p0, LC5/p;->a:I

    sparse-switch p1, :sswitch_data_32

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, LD/Z;->i()LD/Z;

    move-result-object p1

    iput-object p1, p0, LC5/p;->b:Ljava/lang/Object;

    return-void

    :sswitch_10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object p1, LF4/r;->a:[C

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1, v0}, Ljava/util/ArrayDeque;-><init>(I)V

    iput-object p1, p0, LC5/p;->b:Ljava/lang/Object;

    return-void

    :sswitch_1d
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    const-string v0, "getMainLooper()"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    return-void

    nop

    :sswitch_data_32
    .sparse-switch
        0x9 -> :sswitch_1d
        0xc -> :sswitch_10
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC5/p;->a:I

    iput-object p2, p0, LC5/p;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    iput p1, p0, LC5/p;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LC3/g;)V
    .registers 3

    const/4 v0, 0x4

    iput v0, p0, LC5/p;->a:I

    const-string v0, "configuration"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC5/p;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/nio/ByteBuffer;)V
    .registers 3

    const/4 v0, 0x7

    iput v0, p0, LC5/p;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC5/p;->b:Ljava/lang/Object;

    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    return-void
.end method


# virtual methods
.method public C()I
    .registers 4

    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/Buffer;->remaining()I

    move-result v1

    const/4 v2, 0x1

    if-ge v1, v2, :cond_d

    const/4 v0, -0x1

    return v0

    :cond_d
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v0

    return v0
.end method

.method public E()J
    .registers 6

    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/Buffer;->remaining()I

    move-result v1

    int-to-long v1, v1

    const-wide/16 v3, 0x4

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v1

    long-to-int v1, v1

    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v2

    add-int/2addr v2, v1

    invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    int-to-long v0, v1

    return-wide v0
.end method

.method public a()V
    .registers 4

    monitor-enter p0

    :try_start_1
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v1, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    monitor-exit p0
    :try_end_16
    .catchall {:try_start_1 .. :try_end_16} :catchall_2c

    const/4 v1, 0x0

    :goto_17
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2b

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LI5/d;

    if-eqz v2, :cond_28

    invoke-virtual {v2}, LI5/d;->close()V

    :cond_28
    add-int/lit8 v1, v1, 0x1

    goto :goto_17

    :cond_2b
    return-void

    :catchall_2c
    move-exception v0

    :try_start_2d
    monitor-exit p0
    :try_end_2e
    .catchall {:try_start_2d .. :try_end_2e} :catchall_2c

    throw v0
.end method

.method public b()LD/Y;
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public c()I
    .registers 3

    iget v0, p0, LC5/p;->a:I

    packed-switch v0, :pswitch_data_24

    invoke-virtual {p0}, LC5/p;->f()S

    move-result v0

    shl-int/lit8 v0, v0, 0x8

    invoke-virtual {p0}, LC5/p;->f()S

    move-result v1

    or-int/2addr v0, v1

    return v0

    :pswitch_11
    invoke-virtual {p0}, LC5/p;->C()I

    move-result v0

    shl-int/lit8 v0, v0, 0x8

    const v1, 0xff00

    and-int/2addr v0, v1

    invoke-virtual {p0}, LC5/p;->C()I

    move-result v1

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v0, v1

    return v0

    nop

    :pswitch_data_24
    .packed-switch 0x7
        :pswitch_11
    .end packed-switch
.end method

.method public declared-synchronized e(LO4/e;)LI5/d;
    .registers 7

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LI5/d;

    if-eqz v0, :cond_49

    monitor-enter v0
    :try_end_e
    .catchall {:try_start_1 .. :try_end_e} :catchall_47

    :try_start_e
    invoke-static {v0}, LI5/d;->i0(LI5/d;)Z

    move-result v1

    if-nez v1, :cond_3e

    iget-object v1, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const-class v1, LC5/p;

    const-string v2, "Found closed reference %d for key %s (%d)"

    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-object v4, p1, LO4/e;->a:Ljava/lang/String;

    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {v3, v4, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {v1, v2, p1}, LU4/a;->n(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V

    monitor-exit v0
    :try_end_39
    .catchall {:try_start_e .. :try_end_39} :catchall_3c

    monitor-exit p0

    const/4 p1, 0x0

    return-object p1

    :catchall_3c
    move-exception p1

    goto :goto_45

    :cond_3e
    :try_start_3e
    invoke-static {v0}, LI5/d;->a(LI5/d;)LI5/d;

    move-result-object p1

    monitor-exit v0

    move-object v0, p1

    goto :goto_49

    :goto_45
    monitor-exit v0
    :try_end_46
    .catchall {:try_start_3e .. :try_end_46} :catchall_3c

    :try_start_46
    throw p1
    :try_end_47
    .catchall {:try_start_46 .. :try_end_47} :catchall_47

    :catchall_47
    move-exception p1

    goto :goto_4b

    :cond_49
    :goto_49
    monitor-exit p0

    return-object v0

    :goto_4b
    monitor-exit p0

    throw p1
.end method

.method public f()S
    .registers 3

    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_d

    int-to-short v0, v0

    return v0

    :cond_d
    new-instance v0, Ls4/j;

    invoke-direct {v0}, Ls4/j;-><init>()V

    throw v0
.end method

.method public g(J)J
    .registers 11

    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-gez v2, :cond_7

    return-wide v0

    :cond_7
    move-wide v2, p1

    :goto_8
    cmp-long v4, v2, v0

    if-lez v4, :cond_26

    iget-object v4, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v4, Ljava/io/InputStream;

    invoke-virtual {v4, v2, v3}, Ljava/io/InputStream;->skip(J)J

    move-result-wide v5

    cmp-long v7, v5, v0

    if-lez v7, :cond_1a

    sub-long/2addr v2, v5

    goto :goto_8

    :cond_1a
    invoke-virtual {v4}, Ljava/io/InputStream;->read()I

    move-result v4

    const/4 v5, -0x1

    if-ne v4, v5, :cond_22

    goto :goto_26

    :cond_22
    const-wide/16 v4, 0x1

    sub-long/2addr v2, v4

    goto :goto_8

    :cond_26
    :goto_26
    sub-long/2addr p1, v2

    return-wide p1
.end method

.method public declared-synchronized h()V
    .registers 4

    monitor-enter p0

    :try_start_1
    const-class v0, LC5/p;

    const-string v1, "Count = %d"

    iget-object v2, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->size()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v2, v0, v1}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V
    :try_end_14
    .catchall {:try_start_1 .. :try_end_14} :catchall_16

    monitor-exit p0

    return-void

    :catchall_16
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized i(Lf4/d;)V
    .registers 3

    monitor-enter p0

    const/4 v0, 0x0

    :try_start_2
    iput-object v0, p1, Lf4/d;->b:Ljava/nio/ByteBuffer;

    iput-object v0, p1, Lf4/d;->c:Lf4/c;

    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayDeque;

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z
    :try_end_d
    .catchall {:try_start_2 .. :try_end_d} :catchall_f

    monitor-exit p0

    return-void

    :catchall_f
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized j(LO4/a;LI5/d;)V
    .registers 7

    monitor-enter p0

    :try_start_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p2}, LI5/d;->i0(LI5/d;)Z

    move-result v0

    if-eqz v0, :cond_63

    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LI5/d;
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_4b

    if-nez v0, :cond_1b

    monitor-exit p0

    return-void

    :cond_1b
    :try_start_1b
    iget-object v1, v0, LI5/d;->a:LX4/b;

    invoke-static {v1}, LX4/b;->i(LX4/b;)LX4/b;

    move-result-object v1

    iget-object p2, p2, LI5/d;->a:LX4/b;

    invoke-static {p2}, LX4/b;->i(LX4/b;)LX4/b;

    move-result-object p2
    :try_end_27
    .catchall {:try_start_1b .. :try_end_27} :catchall_4b

    if-eqz v1, :cond_58

    if-eqz p2, :cond_58

    :try_start_2b
    invoke-virtual {v1}, LX4/b;->p()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2}, LX4/b;->p()Ljava/lang/Object;

    move-result-object v3

    if-eq v2, v3, :cond_36

    goto :goto_58

    :cond_36
    iget-object v2, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3d
    .catchall {:try_start_2b .. :try_end_3d} :catchall_4d

    :try_start_3d
    invoke-static {p2}, LX4/b;->l(LX4/b;)V

    invoke-static {v1}, LX4/b;->l(LX4/b;)V

    invoke-static {v0}, LI5/d;->f(LI5/d;)V

    invoke-virtual {p0}, LC5/p;->h()V
    :try_end_49
    .catchall {:try_start_3d .. :try_end_49} :catchall_4b

    monitor-exit p0

    return-void

    :catchall_4b
    move-exception p1

    goto :goto_69

    :catchall_4d
    move-exception p1

    :try_start_4e
    invoke-static {p2}, LX4/b;->l(LX4/b;)V

    invoke-static {v1}, LX4/b;->l(LX4/b;)V

    invoke-static {v0}, LI5/d;->f(LI5/d;)V

    throw p1

    :cond_58
    :goto_58
    invoke-static {p2}, LX4/b;->l(LX4/b;)V

    invoke-static {v1}, LX4/b;->l(LX4/b;)V

    invoke-static {v0}, LI5/d;->f(LI5/d;)V
    :try_end_61
    .catchall {:try_start_4e .. :try_end_61} :catchall_4b

    monitor-exit p0

    return-void

    :cond_63
    :try_start_63
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
    :try_end_69
    .catchall {:try_start_63 .. :try_end_69} :catchall_4b

    :goto_69
    monitor-exit p0

    throw p1
.end method

.method public k()LT3/t;
    .registers 5

    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, LC3/g;

    iget-object v1, v0, LC3/g;->n:Ljava/lang/String;

    if-eqz v1, :cond_15

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_f

    goto :goto_15

    :cond_f
    iget-object v0, v0, LC3/g;->n:Ljava/lang/String;

    invoke-static {v0}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    goto :goto_2d

    :cond_15
    :goto_15
    iget v1, v0, LC3/g;->G:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_24

    iget-boolean v0, v0, LC3/g;->m:Z

    if-eqz v0, :cond_21

    const-string v0, "https://api.eu.amplitude.com/batch"

    goto :goto_2d

    :cond_21
    const-string v0, "https://api.eu.amplitude.com/2/httpapi"

    goto :goto_2d

    :cond_24
    iget-boolean v0, v0, LC3/g;->m:Z

    if-eqz v0, :cond_2b

    const-string v0, "https://api2.amplitude.com/batch"

    goto :goto_2d

    :cond_2b
    const-string v0, "https://api2.amplitude.com/2/httpapi"

    :goto_2d
    :try_start_2d
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_32
    .catch Ljava/net/MalformedURLException; {:try_start_2d .. :try_end_32} :catch_7b

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    invoke-static {v0}, Lcom/newrelic/agent/android/instrumentation/URLConnectionInstrumentation;->openConnection(Ljava/net/URLConnection;)Ljava/net/URLConnection;

    move-result-object v0

    invoke-static {v0}, Lcom/google/firebase/perf/network/FirebasePerfUrlConnection;->instrument(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/net/URLConnection;

    const-string v1, "null cannot be cast to non-null type java.net.HttpURLConnection"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/net/HttpURLConnection;

    const-string v1, "POST"

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const-string v1, "Content-Type"

    const-string v2, "application/json; charset=utf-8"

    invoke-virtual {v0, v1, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "Accept"

    const-string v2, "application/json"

    invoke-virtual {v0, v1, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/net/URLConnection;->setDoOutput(Z)V

    invoke-virtual {v0, v1}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/16 v1, 0x3a98

    invoke-virtual {v0, v1}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const v1, 0x31128

    invoke-virtual {v0, v1}, Ljava/net/URLConnection;->setReadTimeout(I)V

    invoke-virtual {v0}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    const-string v2, "connection.outputStream"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, LT3/t;

    invoke-direct {v2, v0, v1, p0}, LT3/t;-><init>(Ljava/net/HttpURLConnection;Ljava/io/OutputStream;LC5/p;)V

    return-object v2

    :catch_7b
    move-exception v1

    new-instance v2, Ljava/io/IOException;

    const-string v3, "Attempted to use malformed url: "

    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2
.end method

.method public n(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v0, LG/e;

    iget-object v1, v0, LG/e;->b:Landroidx/concurrent/futures/k;

    if-nez v1, :cond_a

    const/4 v1, 0x1

    goto :goto_b

    :cond_a
    const/4 v1, 0x0

    :goto_b
    const-string v2, "The result can only set once!"

    invoke-static {v1, v2}, Ll7/C5;->f(ZLjava/lang/String;)V

    iput-object p1, v0, LG/e;->b:Landroidx/concurrent/futures/k;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "FutureChain["

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "]"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public s(I[B)I
    .registers 7

    const/4 v0, 0x0

    move v1, v0

    :goto_2
    const/4 v2, -0x1

    if-ge v0, p1, :cond_13

    iget-object v1, p0, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, Ljava/io/InputStream;

    sub-int v3, p1, v0

    invoke-virtual {v1, p2, v0, v3}, Ljava/io/InputStream;->read([BII)I

    move-result v1

    if-eq v1, v2, :cond_13

    add-int/2addr v0, v1

    goto :goto_2

    :cond_13
    if-nez v0, :cond_1e

    if-eq v1, v2, :cond_18

    goto :goto_1e

    :cond_18
    new-instance p1, Ls4/j;

    invoke-direct {p1}, Ls4/j;-><init>()V

    throw p1

    :cond_1e
    :goto_1e
    return v0
.end method
