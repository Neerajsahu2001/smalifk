.class public final LC5/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:LX4/b;

.field public c:I

.field public d:Z

.field public final e:I


# direct methods
.method public constructor <init>(Ljava/lang/Object;LX4/b;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, LC5/g;->a:Ljava/lang/Object;

    invoke-static {p2}, LX4/b;->i(LX4/b;)LX4/b;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, LC5/g;->b:LX4/b;

    const/4 p1, 0x0

    iput p1, p0, LC5/g;->c:I

    iput-boolean p1, p0, LC5/g;->d:Z

    iput p3, p0, LC5/g;->e:I

    return-void
.end method
