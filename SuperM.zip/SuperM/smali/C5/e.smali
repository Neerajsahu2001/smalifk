.class public final LC5/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LP4/l;

.field public final b:Lfc/l;

.field public final c:LW4/g;

.field public final d:Ljava/util/concurrent/Executor;

.field public final e:Ljava/util/concurrent/Executor;

.field public final f:LC5/o;

.field public final g:LC5/p;


# direct methods
.method public constructor <init>(LP4/l;Lfc/l;LW4/g;Ljava/util/concurrent/ExecutorService;Ljava/util/concurrent/ExecutorService;LC5/o;)V
    .registers 8

    const-string v0, "fileCache"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "pooledByteBufferFactory"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "pooledByteStreams"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "readExecutor"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "writeExecutor"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "imageCacheStatsTracker"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC5/e;->a:LP4/l;

    iput-object p2, p0, LC5/e;->b:Lfc/l;

    iput-object p3, p0, LC5/e;->c:LW4/g;

    iput-object p4, p0, LC5/e;->d:Ljava/util/concurrent/Executor;

    iput-object p5, p0, LC5/e;->e:Ljava/util/concurrent/Executor;

    iput-object p6, p0, LC5/e;->f:LC5/o;

    new-instance p1, LC5/p;

    const/4 p2, 0x0

    const/4 p3, 0x0

    invoke-direct {p1, p2, p3}, LC5/p;-><init>(IZ)V

    new-instance p2, Ljava/util/HashMap;

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    iput-object p2, p1, LC5/p;->b:Ljava/lang/Object;

    iput-object p1, p0, LC5/e;->g:LC5/p;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    iget-object v0, p0, LC5/e;->g:LC5/p;

    invoke-virtual {v0}, LC5/p;->a()V

    :try_start_5
    new-instance v0, LC5/c;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p0}, LC5/c;-><init>(ILjava/lang/Object;)V

    iget-object v1, p0, LC5/e;->e:Ljava/util/concurrent/Executor;

    invoke-static {v0, v1}, Le3/g;->a(Ljava/util/concurrent/Callable;Ljava/util/concurrent/Executor;)Le3/g;

    move-result-object v0

    const-string v1, "{\n      Task.call(\n     \u2026     writeExecutor)\n    }"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_16} :catch_17

    goto :goto_23

    :catch_17
    move-exception v0

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "Failed to schedule disk-cache clear"

    invoke-static {v2, v1, v0}, LU4/a;->r(Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Exception;)V

    invoke-static {v0}, Le3/g;->d(Ljava/lang/Exception;)Le3/g;

    :goto_23
    return-void
.end method

.method public final b(LO4/e;)Z
    .registers 10

    iget-object v0, p0, LC5/e;->g:LC5/p;

    monitor-enter v0

    :try_start_3
    iget-object v1, v0, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_89

    const/4 v2, 0x1

    if-nez v1, :cond_10

    monitor-exit v0

    goto :goto_47

    :cond_10
    :try_start_10
    iget-object v1, v0, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LI5/d;

    monitor-enter v1
    :try_end_1b
    .catchall {:try_start_10 .. :try_end_1b} :catchall_89

    :try_start_1b
    invoke-static {v1}, LI5/d;->i0(LI5/d;)Z

    move-result v3

    if-nez v3, :cond_84

    iget-object v3, v0, LC5/p;->b:Ljava/lang/Object;

    check-cast v3, Ljava/util/HashMap;

    invoke-virtual {v3, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const-class v3, LC5/p;

    const-string v4, "Found closed reference %d for key %s (%d)"

    invoke-static {v1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget-object v6, p1, LO4/e;->a:Ljava/lang/String;

    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v5, v6, v7}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v3, v4, v5}, LU4/a;->n(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V

    monitor-exit v1
    :try_end_46
    .catchall {:try_start_1b .. :try_end_46} :catchall_82

    monitor-exit v0

    :goto_47
    iget-object v0, p0, LC5/e;->a:LP4/l;

    check-cast v0, LP4/j;

    invoke-virtual {v0, p1}, LP4/j;->f(LO4/e;)Z

    move-result v0

    if-eqz v0, :cond_52

    goto :goto_86

    :cond_52
    iget-object v0, p0, LC5/e;->g:LC5/p;

    invoke-virtual {v0, p1}, LC5/p;->e(LO4/e;)LI5/d;

    move-result-object v0

    iget-object v1, p0, LC5/e;->f:LC5/o;

    const-class v3, LC5/e;

    if-eqz v0, :cond_6c

    invoke-virtual {v0}, LI5/d;->close()V

    const-string v0, "Found image for %s in staging area"

    iget-object p1, p1, LO4/e;->a:Ljava/lang/String;

    invoke-static {p1, v3, v0}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_86

    :cond_6c
    const-string v0, "Did not find image for %s in staging area"

    iget-object v2, p1, LO4/e;->a:Ljava/lang/String;

    invoke-static {v2, v3, v0}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_76
    iget-object v0, p0, LC5/e;->a:LP4/l;

    check-cast v0, LP4/j;

    invoke-virtual {v0, p1}, LP4/j;->e(LO4/e;)Z

    move-result p1
    :try_end_7e
    .catch Ljava/lang/Exception; {:try_start_76 .. :try_end_7e} :catch_80

    :goto_7e
    move v2, p1

    goto :goto_86

    :catch_80
    const/4 p1, 0x0

    goto :goto_7e

    :catchall_82
    move-exception p1

    goto :goto_87

    :cond_84
    :try_start_84
    monitor-exit v1
    :try_end_85
    .catchall {:try_start_84 .. :try_end_85} :catchall_82

    monitor-exit v0

    :goto_86
    return v2

    :goto_87
    :try_start_87
    monitor-exit v1
    :try_end_88
    .catchall {:try_start_87 .. :try_end_88} :catchall_82

    :try_start_88
    throw p1
    :try_end_89
    .catchall {:try_start_88 .. :try_end_89} :catchall_89

    :catchall_89
    move-exception p1

    monitor-exit v0

    throw p1
.end method

.method public final c(LO4/e;Ljava/util/concurrent/atomic/AtomicBoolean;)Le3/g;
    .registers 5

    invoke-static {}, LO5/a;->b()V

    iget-object v0, p0, LC5/e;->g:LC5/p;

    invoke-virtual {v0, p1}, LC5/p;->e(LO4/e;)LI5/d;

    move-result-object v0

    iget-object v1, p1, LO4/e;->a:Ljava/lang/String;

    if-eqz v0, :cond_46

    const-class p1, LC5/e;

    const-string p2, "Found image for %s in staging area"

    invoke-static {v1, p1, p2}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    iget-object p1, p0, LC5/e;->f:LC5/o;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Le3/g;->g:Ljava/util/concurrent/ExecutorService;

    instance-of p1, v0, Ljava/lang/Boolean;

    if-eqz p1, :cond_2d

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_2a

    sget-object p1, Le3/g;->i:Le3/g;

    goto :goto_38

    :cond_2a
    sget-object p1, Le3/g;->j:Le3/g;

    goto :goto_38

    :cond_2d
    new-instance p1, Le3/g;

    invoke-direct {p1}, Le3/g;-><init>()V

    invoke-virtual {p1, v0}, Le3/g;->i(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_3e

    :goto_38
    const-string p2, "forResult(pinnedImage)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_65

    :cond_3e
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Cannot set the result of a completed task."

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_46
    :try_start_46
    new-instance v0, LC5/b;

    invoke-direct {v0, p2, p0, p1}, LC5/b;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;LC5/e;LO4/e;)V

    iget-object p1, p0, LC5/e;->d:Ljava/util/concurrent/Executor;

    invoke-static {v0, p1}, Le3/g;->a(Ljava/util/concurrent/Callable;Ljava/util/concurrent/Executor;)Le3/g;

    move-result-object p1

    const-string p2, "{\n      val token = Fres\u2026      readExecutor)\n    }"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_56
    .catch Ljava/lang/Exception; {:try_start_46 .. :try_end_56} :catch_57

    goto :goto_65

    :catch_57
    move-exception p1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object p2

    const-string v0, "Failed to schedule disk-cache read for %s"

    invoke-static {v0, p2, p1}, LU4/a;->r(Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Exception;)V

    invoke-static {p1}, Le3/g;->d(Ljava/lang/Exception;)Le3/g;

    move-result-object p1

    :goto_65
    return-object p1
.end method

.method public final d(LO4/a;LI5/d;)V
    .registers 8

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "encodedImage"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, LO5/a;->b()V

    invoke-static {p2}, LI5/d;->i0(LI5/d;)Z

    move-result v0

    if-eqz v0, :cond_60

    iget-object v0, p0, LC5/e;->g:LC5/p;

    monitor-enter v0

    :try_start_16
    invoke-static {p2}, LI5/d;->i0(LI5/d;)Z

    move-result v1

    if-eqz v1, :cond_58

    iget-object v1, v0, LC5/p;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-static {p2}, LI5/d;->a(LI5/d;)LI5/d;

    move-result-object v2

    invoke-virtual {v1, p1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LI5/d;

    invoke-static {v1}, LI5/d;->f(LI5/d;)V

    invoke-virtual {v0}, LC5/p;->h()V
    :try_end_30
    .catchall {:try_start_16 .. :try_end_30} :catchall_56

    monitor-exit v0

    invoke-static {p2}, LI5/d;->a(LI5/d;)LI5/d;

    move-result-object v1

    :try_start_35
    iget-object v2, p0, LC5/e;->e:Ljava/util/concurrent/Executor;

    new-instance v3, LC5/d;

    const/4 v4, 0x0

    invoke-direct {v3, p0, p1, v1, v4}, LC5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_40
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_40} :catch_41

    goto :goto_55

    :catch_41
    move-exception v2

    invoke-interface {p1}, LO4/a;->c()Ljava/lang/String;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "Failed to schedule disk-cache write for %s"

    invoke-static {v4, v3, v2}, LU4/a;->r(Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Exception;)V

    invoke-virtual {v0, p1, p2}, LC5/p;->j(LO4/a;LI5/d;)V

    invoke-static {v1}, LI5/d;->f(LI5/d;)V

    :goto_55
    return-void

    :catchall_56
    move-exception p1

    goto :goto_5e

    :cond_58
    :try_start_58
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
    :try_end_5e
    .catchall {:try_start_58 .. :try_end_5e} :catchall_56

    :goto_5e
    monitor-exit v0

    throw p1

    :cond_60
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Check failed."

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final e(LO4/e;)LK5/w;
    .registers 9

    iget-object v0, p1, LO4/e;->a:Ljava/lang/String;

    iget-object v1, p0, LC5/e;->f:LC5/o;

    const-class v2, LC5/e;

    :try_start_6
    const-string v3, "Disk cache read for %s"

    invoke-static {v0, v2, v3}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    iget-object v3, p0, LC5/e;->a:LP4/l;

    check-cast v3, LP4/j;

    invoke-virtual {v3, p1}, LP4/j;->c(LO4/e;)LN4/a;

    move-result-object p1

    if-nez p1, :cond_21

    const-string p1, "Disk cache miss for %s"

    invoke-static {v0, v2, p1}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p1, 0x0

    return-object p1

    :catch_1f
    move-exception p1

    goto :goto_66

    :cond_21
    const-string v3, "Found entry in disk cache for %s"

    invoke-static {v0, v2, v3}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Ljava/io/FileInputStream;

    iget-object v4, p1, LN4/a;->a:Ljava/io/File;

    invoke-direct {v3, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_30
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_30} :catch_1f

    :try_start_30
    iget-object v4, p0, LC5/e;->b:Lfc/l;

    iget-object p1, p1, LN4/a;->a:Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v5

    long-to-int p1, v5

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v5, LK5/y;

    iget-object v6, v4, Lfc/l;->b:Ljava/lang/Object;

    check-cast v6, LK5/v;

    invoke-direct {v5, v6, p1}, LK5/y;-><init>(LK5/v;I)V
    :try_end_45
    .catchall {:try_start_30 .. :try_end_45} :catchall_61

    :try_start_45
    iget-object p1, v4, Lfc/l;->c:Ljava/lang/Object;

    check-cast p1, LW4/g;

    invoke-virtual {p1, v3, v5}, LW4/g;->b(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v5}, LK5/y;->f()LK5/w;

    move-result-object p1
    :try_end_50
    .catchall {:try_start_45 .. :try_end_50} :catchall_5c

    :try_start_50
    invoke-virtual {v5}, LK5/y;->close()V
    :try_end_53
    .catchall {:try_start_50 .. :try_end_53} :catchall_61

    :try_start_53
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    const-string v3, "Successful read from disk cache for %s"

    invoke-static {v0, v2, v3}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V
    :try_end_5b
    .catch Ljava/io/IOException; {:try_start_53 .. :try_end_5b} :catch_1f

    return-object p1

    :catchall_5c
    move-exception p1

    :try_start_5d
    invoke-virtual {v5}, LK5/y;->close()V

    throw p1
    :try_end_61
    .catchall {:try_start_5d .. :try_end_61} :catchall_61

    :catchall_61
    move-exception p1

    :try_start_62
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    throw p1
    :try_end_66
    .catch Ljava/io/IOException; {:try_start_62 .. :try_end_66} :catch_1f

    :goto_66
    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v2, "Exception reading from cache for %s"

    invoke-static {v2, v0, p1}, LU4/a;->r(Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Exception;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    throw p1
.end method

.method public final f(LO4/a;LI5/d;)V
    .registers 6

    invoke-interface {p1}, LO4/a;->c()Ljava/lang/String;

    move-result-object v0

    const-string v1, "About to write to disk-cache for key %s"

    const-class v2, LC5/e;

    invoke-static {v0, v2, v1}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    :try_start_b
    iget-object v0, p0, LC5/e;->a:LP4/l;

    new-instance v1, LC/L0;

    invoke-direct {v1, p2, p0}, LC/L0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    check-cast v0, LP4/j;

    invoke-virtual {v0, p1, v1}, LP4/j;->g(LO4/a;LC/L0;)LN4/a;

    iget-object p2, p0, LC5/e;->f:LC5/o;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p2, "Successful disk-cache write for key %s"

    invoke-interface {p1}, LO4/a;->c()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2, p2}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V
    :try_end_25
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_25} :catch_26

    goto :goto_34

    :catch_26
    move-exception p2

    invoke-interface {p1}, LO4/a;->c()Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "Failed to write to disk-cache for key %s"

    invoke-static {v0, p1, p2}, LU4/a;->r(Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Exception;)V

    :goto_34
    return-void
.end method
