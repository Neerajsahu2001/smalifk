.class public final synthetic LC5/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    iput p4, p0, LC5/d;->a:I

    iput-object p1, p0, LC5/d;->b:Ljava/lang/Object;

    iput-object p2, p0, LC5/d;->c:Ljava/lang/Object;

    iput-object p3, p0, LC5/d;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget v0, p0, LC5/d;->a:I

    packed-switch v0, :pswitch_data_104

    iget-object v0, p0, LC5/d;->b:Ljava/lang/Object;

    check-cast v0, Lx/j;

    iget-object v0, v0, Lx/j;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    iget-object v1, p0, LC5/d;->c:Ljava/lang/Object;

    check-cast v1, Landroid/hardware/camera2/CameraCaptureSession;

    iget-object v2, p0, LC5/d;->d:Ljava/lang/Object;

    check-cast v2, Landroid/view/Surface;

    invoke-static {v0, v1, v2}, Lx/b;->a(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;Landroid/hardware/camera2/CameraCaptureSession;Landroid/view/Surface;)V

    return-void

    :pswitch_17
    iget-object v0, p0, LC5/d;->b:Ljava/lang/Object;

    check-cast v0, Lx9/o;

    const-string v1, "$sdkInstance"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LC5/d;->c:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    const-string v2, "$context"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, LC5/d;->d:Ljava/lang/Object;

    check-cast v2, Landroid/os/Bundle;

    const-string v3, "$pushPayload"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lsa/r;->b(Lx9/o;)Lsa/q;

    move-result-object v0

    invoke-virtual {v0, v1, v2}, Lsa/q;->d(Landroid/content/Context;Landroid/os/Bundle;)V

    return-void

    :pswitch_3a
    iget-object v0, p0, LC5/d;->b:Ljava/lang/Object;

    check-cast v0, Lx9/o;

    const-string v1, "$instance"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LC5/d;->c:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    const-string v2, "$context"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, LC5/d;->d:Ljava/lang/Object;

    check-cast v2, Ljava/util/concurrent/CountDownLatch;

    const-string v3, "$countDownLatch"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-boolean v3, Lm7/k;->a:Z

    if-nez v3, :cond_69

    invoke-static {v0}, Lma/i;->a(Lx9/o;)Lma/h;

    move-result-object v0

    new-instance v3, Lc9/z;

    iget-object v0, v0, Lma/h;->a:Lx9/o;

    const/4 v4, 0x1

    invoke-direct {v3, v0, v4}, Lc9/z;-><init>(Lx9/o;I)V

    const/4 v0, 0x0

    invoke-virtual {v3, v1, v0}, Lc9/z;->a(Landroid/content/Context;Z)V

    :cond_69
    invoke-virtual {v2}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    return-void

    :pswitch_6d
    iget-object v0, p0, LC5/d;->b:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/ActivityLifecycleIntegration;

    iget-object v1, p0, LC5/d;->c:Ljava/lang/Object;

    check-cast v1, Lio/sentry/P;

    iget-object v2, p0, LC5/d;->d:Ljava/lang/Object;

    check-cast v2, Lio/sentry/P;

    invoke-virtual {v0, v1, v2}, Lio/sentry/android/core/ActivityLifecycleIntegration;->z(Lio/sentry/P;Lio/sentry/P;)V

    return-void

    :pswitch_7d
    iget-object v0, p0, LC5/d;->b:Ljava/lang/Object;

    check-cast v0, Lb4/A;

    iget-boolean v1, v0, Lb4/A;->k1:Z

    iget-object v2, p0, LC5/d;->c:Ljava/lang/Object;

    check-cast v2, LY3/j;

    if-eqz v1, :cond_8e

    iget-object v1, v0, Lb4/A;->P:LY3/j;

    if-ne v2, v1, :cond_8e

    goto :goto_b8

    :cond_8e
    :try_start_8e
    invoke-virtual {v0, v2}, Lb4/A;->X(LY3/j;)V
    :try_end_91
    .catch Ljava/lang/Exception; {:try_start_8e .. :try_end_91} :catch_92

    goto :goto_b8

    :catch_92
    move-exception v1

    const/4 v2, 0x1

    iget-object v3, p0, LC5/d;->d:Ljava/lang/Object;

    check-cast v3, Lb4/A;

    iput-boolean v2, v3, Lb4/A;->l:Z

    const-string v2, "Failed to initialize Player! 1"

    const-string v3, "ReactExoplayerView"

    invoke-static {v3, v2}, Lm7/L3;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lm7/L3;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object v0, v0, Lb4/A;->a:LZ3/E;

    iget-object v0, v0, LZ3/E;->c:LHc/d;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "1001"

    invoke-interface {v0, v2, v1, v3}, LHc/d;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_b8
    return-void

    :pswitch_b9
    iget-object v0, p0, LC5/d;->b:Ljava/lang/Object;

    check-cast v0, LW2/p;

    iget-object v0, v0, LW2/p;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/J;

    iget-object v1, p0, LC5/d;->c:Ljava/lang/Object;

    check-cast v1, LD/W;

    if-eqz v1, :cond_ca

    invoke-virtual {v0, v1}, Landroidx/lifecycle/G;->i(Landroidx/lifecycle/K;)V

    :cond_ca
    iget-object v1, p0, LC5/d;->d:Ljava/lang/Object;

    check-cast v1, LD/W;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/G;->f(Landroidx/lifecycle/K;)V

    return-void

    :pswitch_d2
    iget-object v0, p0, LC5/d;->d:Ljava/lang/Object;

    check-cast v0, LI5/d;

    iget-object v1, p0, LC5/d;->b:Ljava/lang/Object;

    check-cast v1, LC5/e;

    iget-object v2, p0, LC5/d;->c:Ljava/lang/Object;

    check-cast v2, LO4/a;

    const-string v3, "this$0"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, v1, LC5/e;->g:LC5/p;

    const-string v4, "$key"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_ea
    invoke-virtual {v1, v2, v0}, LC5/e;->f(LO4/a;LI5/d;)V
    :try_end_ed
    .catchall {:try_start_ea .. :try_end_ed} :catchall_f7

    invoke-static {v0}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    invoke-virtual {v3, v2, v0}, LC5/p;->j(LO4/a;LI5/d;)V

    invoke-static {v0}, LI5/d;->f(LI5/d;)V

    return-void

    :catchall_f7
    move-exception v1

    :try_start_f8
    throw v1
    :try_end_f9
    .catchall {:try_start_f8 .. :try_end_f9} :catchall_f9

    :catchall_f9
    move-exception v1

    invoke-static {v0}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    invoke-virtual {v3, v2, v0}, LC5/p;->j(LO4/a;LI5/d;)V

    invoke-static {v0}, LI5/d;->f(LI5/d;)V

    throw v1

    :pswitch_data_104
    .packed-switch 0x0
        :pswitch_d2
        :pswitch_b9
        :pswitch_7d
        :pswitch_6d
        :pswitch_3a
        :pswitch_17
    .end packed-switch
.end method
