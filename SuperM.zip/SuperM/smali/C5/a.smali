.class public abstract Lc5/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Z

.field public static final b:[B

.field public static final c:[B

.field public static final d:[B

.field public static final e:[B

.field public static final f:[B


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    sput-boolean v0, Lc5/a;->a:Z

    const-string v0, "RIFF"

    invoke-static {v0}, Lc5/a;->a(Ljava/lang/String;)[B

    move-result-object v0

    sput-object v0, Lc5/a;->b:[B

    const-string v0, "WEBP"

    invoke-static {v0}, Lc5/a;->a(Ljava/lang/String;)[B

    move-result-object v0

    sput-object v0, Lc5/a;->c:[B

    const-string v0, "VP8 "

    invoke-static {v0}, Lc5/a;->a(Ljava/lang/String;)[B

    move-result-object v0

    sput-object v0, Lc5/a;->d:[B

    const-string v0, "VP8L"

    invoke-static {v0}, Lc5/a;->a(Ljava/lang/String;)[B

    move-result-object v0

    sput-object v0, Lc5/a;->e:[B

    const-string v0, "VP8X"

    invoke-static {v0}, Lc5/a;->a(Ljava/lang/String;)[B

    move-result-object v0

    sput-object v0, Lc5/a;->f:[B

    return-void
.end method

.method public static a(Ljava/lang/String;)[B
    .registers 3

    :try_start_0
    const-string v0, "ASCII"

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0
    :try_end_6
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_6} :catch_7

    return-object p0

    :catch_7
    move-exception p0

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "ASCII not found!"

    invoke-direct {v0, v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static b(I[B)Z
    .registers 4

    const/16 v0, 0x14

    const/4 v1, 0x0

    if-lt p0, v0, :cond_18

    sget-object p0, Lc5/a;->b:[B

    invoke-static {v1, p1, p0}, Lc5/a;->c(I[B[B)Z

    move-result p0

    if-eqz p0, :cond_18

    const/16 p0, 0x8

    sget-object v0, Lc5/a;->c:[B

    invoke-static {p0, p1, v0}, Lc5/a;->c(I[B[B)Z

    move-result p0

    if-eqz p0, :cond_18

    const/4 v1, 0x1

    :cond_18
    return v1
.end method

.method public static c(I[B[B)Z
    .registers 7

    const/4 v0, 0x0

    if-eqz p2, :cond_1b

    array-length v1, p2

    add-int/2addr v1, p0

    array-length v2, p1

    if-le v1, v2, :cond_9

    return v0

    :cond_9
    move v1, v0

    :goto_a
    array-length v2, p2

    if-ge v1, v2, :cond_19

    add-int v2, v1, p0

    aget-byte v2, p1, v2

    aget-byte v3, p2, v1

    if-eq v2, v3, :cond_16

    return v0

    :cond_16
    add-int/lit8 v1, v1, 0x1

    goto :goto_a

    :cond_19
    const/4 p0, 0x1

    return p0

    :cond_1b
    return v0
.end method
