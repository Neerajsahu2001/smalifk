.class public final synthetic LC5/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final synthetic b:LC5/e;

.field public final synthetic c:LO4/a;


# direct methods
.method public synthetic constructor <init>(Ljava/util/concurrent/atomic/AtomicBoolean;LC5/e;LO4/e;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC5/b;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    iput-object p2, p0, LC5/b;->b:LC5/e;

    iput-object p3, p0, LC5/b;->c:LO4/a;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 7

    iget-object v0, p0, LC5/b;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    const-string v1, "$isCancelled"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, LC5/b;->b:LC5/e;

    const-string v2, "this$0"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, LC5/b;->c:LO4/a;

    const-string v3, "$key"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-nez v0, :cond_8a

    iget-object v0, v1, LC5/e;->g:LC5/p;

    move-object v3, v2

    check-cast v3, LO4/e;

    invoke-virtual {v0, v3}, LC5/p;->e(LO4/e;)LI5/d;

    move-result-object v0

    const-class v3, LC5/e;

    iget-object v4, v1, LC5/e;->f:LC5/o;

    if-eqz v0, :cond_37

    invoke-interface {v2}, LO4/a;->c()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Found image for %s in staging area"

    invoke-static {v1, v3, v2}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_5f

    :cond_37
    invoke-interface {v2}, LO4/a;->c()Ljava/lang/String;

    move-result-object v0

    const-string v5, "Did not find image for %s in staging area"

    invoke-static {v0, v3, v5}, LU4/a;->l(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    :try_start_44
    check-cast v2, LO4/e;

    invoke-virtual {v1, v2}, LC5/e;->e(LO4/e;)LK5/w;

    move-result-object v1

    if-nez v1, :cond_4d

    goto :goto_89

    :cond_4d
    invoke-static {v1}, LX4/b;->V(Ljava/io/Closeable;)LX4/b;

    move-result-object v1

    const-string v2, "of(buffer)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_56
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_56} :catch_89
    .catchall {:try_start_44 .. :try_end_56} :catchall_81

    :try_start_56
    new-instance v2, LI5/d;

    invoke-direct {v2, v1}, LI5/d;-><init>(LX4/b;)V
    :try_end_5b
    .catchall {:try_start_56 .. :try_end_5b} :catchall_83

    :try_start_5b
    invoke-static {v1}, LX4/b;->l(LX4/b;)V
    :try_end_5e
    .catch Ljava/lang/Exception; {:try_start_5b .. :try_end_5e} :catch_89
    .catchall {:try_start_5b .. :try_end_5e} :catchall_81

    move-object v0, v2

    :goto_5f
    invoke-static {}, Ljava/lang/Thread;->interrupted()Z

    move-result v1

    if-nez v1, :cond_66

    goto :goto_89

    :cond_66
    sget-object v1, LU4/a;->a:LU4/b;

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, LU4/b;->a(I)Z

    move-result v1

    if-eqz v1, :cond_78

    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    const-string v3, "Host thread was interrupted, decreasing reference count"

    invoke-static {v2, v1, v3}, LU4/b;->b(ILjava/lang/String;Ljava/lang/String;)V

    :cond_78
    invoke-virtual {v0}, LI5/d;->close()V

    new-instance v0, Ljava/lang/InterruptedException;

    invoke-direct {v0}, Ljava/lang/InterruptedException;-><init>()V

    throw v0

    :catchall_81
    move-exception v0

    goto :goto_88

    :catchall_83
    move-exception v2

    :try_start_84
    invoke-static {v1}, LX4/b;->l(LX4/b;)V

    throw v2
    :try_end_88
    .catch Ljava/lang/Exception; {:try_start_84 .. :try_end_88} :catch_89
    .catchall {:try_start_84 .. :try_end_88} :catchall_81

    :goto_88
    throw v0

    :catch_89
    :goto_89
    return-object v0

    :cond_8a
    new-instance v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v0}, Ljava/util/concurrent/CancellationException;-><init>()V

    throw v0
.end method
