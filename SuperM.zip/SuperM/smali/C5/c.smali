.class public final synthetic LC5/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, LC5/c;->a:I

    iput-object p2, p0, LC5/c;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 5

    iget v0, p0, LC5/c;->a:I

    packed-switch v0, :pswitch_data_54

    iget-object v0, p0, LC5/c;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/messaging/FirebaseMessaging;

    invoke-static {v0}, Lio/invertase/firebase/messaging/ReactNativeFirebaseMessagingModule;->m(Lcom/google/firebase/messaging/FirebaseMessaging;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_e
    iget-object v0, p0, LC5/c;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;

    invoke-static {v0}, Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;->i(Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;)Ljava/lang/Void;

    move-result-object v0

    return-object v0

    :pswitch_17
    iget-object v0, p0, LC5/c;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lte/a;

    new-instance v2, Lb3/j;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v1}, Lb3/j;-><init>(ILjava/lang/Object;)V

    sget-object v1, Lb3/p;->a:Ljava/util/concurrent/ExecutorService;

    invoke-static {v2, v1}, Lv7/l;->c(Ljava/util/concurrent/Callable;Ljava/util/concurrent/Executor;)Lv7/v;

    move-result-object v1

    invoke-static {v1}, Lv7/l;->a(Lv7/i;)Ljava/lang/Object;

    goto :goto_1f

    :cond_3b
    const/4 v0, 0x0

    return-object v0

    :pswitch_3d
    const-string v0, "this$0"

    iget-object v1, p0, LC5/c;->b:Ljava/lang/Object;

    check-cast v1, LC5/e;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v1, LC5/e;->g:LC5/p;

    invoke-virtual {v0}, LC5/p;->a()V

    iget-object v0, v1, LC5/e;->a:LP4/l;

    check-cast v0, LP4/j;

    invoke-virtual {v0}, LP4/j;->a()V

    const/4 v0, 0x0

    return-object v0

    :pswitch_data_54
    .packed-switch 0x0
        :pswitch_3d
        :pswitch_17
        :pswitch_e
    .end packed-switch
.end method
