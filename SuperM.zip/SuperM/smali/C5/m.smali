.class public final LC5/m;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:J


# direct methods
.method public constructor <init>(IIIIJ)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LC5/m;->a:I

    iput p2, p0, LC5/m;->b:I

    iput p3, p0, LC5/m;->c:I

    iput p4, p0, LC5/m;->d:I

    iput-wide p5, p0, LC5/m;->e:J

    return-void
.end method
