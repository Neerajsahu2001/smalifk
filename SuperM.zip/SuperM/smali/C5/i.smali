.class public final LC5/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly1/x;
.implements LZ6/b;
.implements Lcom/google/gson/internal/p;
.implements Lr7/v;


# static fields
.field public static b:LC5/i;


# instance fields
.field public final synthetic a:I


# direct methods
.method public constructor <init>()V
    .registers 2

    const/16 v0, 0xd

    iput v0, p0, LC5/i;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lz1/b;

    invoke-direct {v0}, Lz1/b;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, LC5/i;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;Z)I
    .registers 4

    invoke-static {p1, p2, p3}, LZ6/d;->d(Landroid/content/Context;Ljava/lang/String;Z)I

    move-result p1

    return p1
.end method

.method public b()V
    .registers 5

    sget-object v0, LA1/c;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    sget-object v1, LA1/c;->b:Ljava/lang/Object;

    monitor-enter v1
    :try_end_6
    .catchall {:try_start_3 .. :try_end_6} :catchall_d

    :try_start_6
    sget-boolean v2, LA1/c;->c:Z

    if-eqz v2, :cond_11

    monitor-exit v1
    :try_end_b
    .catchall {:try_start_6 .. :try_end_b} :catchall_f

    :try_start_b
    monitor-exit v0
    :try_end_c
    .catchall {:try_start_b .. :try_end_c} :catchall_d

    return-void

    :catchall_d
    move-exception v1

    goto :goto_24

    :catchall_f
    move-exception v2

    goto :goto_22

    :cond_11
    :try_start_11
    monitor-exit v1
    :try_end_12
    .catchall {:try_start_11 .. :try_end_12} :catchall_f

    :try_start_12
    invoke-static {}, LA1/c;->a()J

    move-result-wide v2

    monitor-enter v1
    :try_end_17
    .catchall {:try_start_12 .. :try_end_17} :catchall_d

    :try_start_17
    sput-wide v2, LA1/c;->d:J

    const/4 v2, 0x1

    sput-boolean v2, LA1/c;->c:Z

    monitor-exit v1
    :try_end_1d
    .catchall {:try_start_17 .. :try_end_1d} :catchall_1f

    :try_start_1d
    monitor-exit v0
    :try_end_1e
    .catchall {:try_start_1d .. :try_end_1e} :catchall_d

    return-void

    :catchall_1f
    move-exception v2

    :try_start_20
    monitor-exit v1
    :try_end_21
    .catchall {:try_start_20 .. :try_end_21} :catchall_1f

    :try_start_21
    throw v2
    :try_end_22
    .catchall {:try_start_21 .. :try_end_22} :catchall_d

    :goto_22
    :try_start_22
    monitor-exit v1
    :try_end_23
    .catchall {:try_start_22 .. :try_end_23} :catchall_f

    :try_start_23
    throw v2

    :goto_24
    monitor-exit v0
    :try_end_25
    .catchall {:try_start_23 .. :try_end_25} :catchall_d

    throw v1
.end method

.method public c(Landroid/content/Context;Ljava/lang/String;)I
    .registers 3

    invoke-static {p1, p2}, LZ6/d;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public construct()Ljava/lang/Object;
    .registers 2

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    return-object v0
.end method

.method public d()V
    .registers 1

    return-void
.end method

.method public e(LN5/d;Ljava/lang/Object;)LC5/a;
    .registers 11

    new-instance v7, LC5/a;

    invoke-virtual {p1}, LN5/d;->getSourceUri()Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, LN5/d;->getResizeOptions()LD5/e;

    move-result-object v2

    invoke-virtual {p1}, LN5/d;->getRotationOptions()LD5/f;

    move-result-object v3

    invoke-virtual {p1}, LN5/d;->getImageDecodeOptions()LD5/c;

    move-result-object v4

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, LC5/a;-><init>(Ljava/lang/String;LD5/e;LD5/f;LD5/c;LO4/a;Ljava/lang/String;)V

    iput-object p2, v7, LC5/a;->g:Ljava/lang/Object;

    return-object v7
.end method

.method public f(LN5/d;Ljava/lang/Object;)LO4/e;
    .registers 3

    invoke-virtual {p1}, LN5/d;->getSourceUri()Landroid/net/Uri;

    move-result-object p1

    new-instance p2, LO4/e;

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, LO4/e;-><init>(Ljava/lang/String;)V

    return-object p2
.end method

.method public g(LN5/d;Ljava/lang/Object;)LC5/a;
    .registers 12

    invoke-virtual {p1}, LN5/d;->getPostprocessor()LN5/f;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-interface {v0}, LN5/f;->getPostprocessorCacheKey()LO4/a;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    move-object v8, v0

    move-object v7, v1

    goto :goto_18

    :cond_15
    const/4 v1, 0x0

    move-object v7, v1

    move-object v8, v7

    :goto_18
    new-instance v0, LC5/a;

    invoke-virtual {p1}, LN5/d;->getSourceUri()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, LN5/d;->getResizeOptions()LD5/e;

    move-result-object v4

    invoke-virtual {p1}, LN5/d;->getRotationOptions()LD5/f;

    move-result-object v5

    invoke-virtual {p1}, LN5/d;->getImageDecodeOptions()LD5/c;

    move-result-object v6

    move-object v2, v0

    invoke-direct/range {v2 .. v8}, LC5/a;-><init>(Ljava/lang/String;LD5/e;LD5/f;LD5/c;LO4/a;Ljava/lang/String;)V

    iput-object p2, v0, LC5/a;->g:Ljava/lang/Object;

    return-object v0
.end method

.method public zza()Ljava/lang/Object;
    .registers 3

    iget v0, p0, LC5/i;->a:I

    packed-switch v0, :pswitch_data_70

    sget-object v0, Lcom/google/android/gms/internal/measurement/B4;->b:Lcom/google/android/gms/internal/measurement/B4;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/B4;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/E4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/D4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/D4;->c:Lcom/google/android/gms/internal/measurement/O2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    :pswitch_1e
    sget-object v0, Lcom/google/android/gms/internal/measurement/d4;->b:Lcom/google/android/gms/internal/measurement/d4;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/d4;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/g4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/f4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/f4;->d:Lcom/google/android/gms/internal/measurement/L2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    long-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :pswitch_3d
    sget-object v0, Lcom/google/android/gms/internal/measurement/d4;->b:Lcom/google/android/gms/internal/measurement/d4;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/d4;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/g4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/f4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/f4;->x:Lcom/google/android/gms/internal/measurement/L2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    :pswitch_56
    sget-object v0, Lcom/google/android/gms/internal/measurement/A4;->b:Lcom/google/android/gms/internal/measurement/A4;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/A4;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/z4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/C4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/C4;->a:Lcom/google/android/gms/internal/measurement/O2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    nop

    :pswitch_data_70
    .packed-switch 0x8
        :pswitch_56
        :pswitch_3d
        :pswitch_1e
    .end packed-switch
.end method
