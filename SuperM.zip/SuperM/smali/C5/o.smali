.class public final LC5/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp8/o;
.implements Lj6/b;
.implements Lr7/v;
.implements Ljavax/inject/Provider;


# static fields
.field public static b:LC5/o;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, LC5/o;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lx8/E0;)V
    .registers 4

    const/16 v0, 0xc

    iput v0, p0, LC5/o;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Lx8/E0;->r()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lq8/a;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2e

    :try_start_13
    invoke-virtual {p1}, Lx8/E0;->s()Lcom/google/crypto/tink/shaded/protobuf/i;

    move-result-object v0

    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/p;->a()Lcom/google/crypto/tink/shaded/protobuf/p;

    move-result-object v1

    invoke-static {v0, v1}, Lx8/J;->p(Lcom/google/crypto/tink/shaded/protobuf/i;Lcom/google/crypto/tink/shaded/protobuf/p;)Lx8/J;

    invoke-static {p1}, Lp8/s;->e(Lx8/E0;)Lcom/google/crypto/tink/shaded/protobuf/a;

    move-result-object p1

    check-cast p1, Lx8/H;
    :try_end_24
    .catch Lcom/google/crypto/tink/shaded/protobuf/D; {:try_start_13 .. :try_end_24} :catch_25

    goto :goto_56

    :catch_25
    move-exception p1

    new-instance v0, Ljava/security/GeneralSecurityException;

    const-string v1, "invalid KeyFormat protobuf, expected AesGcmKeyFormat"

    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_2e
    sget-object v1, Lq8/a;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_60

    :try_start_36
    invoke-virtual {p1}, Lx8/E0;->s()Lcom/google/crypto/tink/shaded/protobuf/i;

    move-result-object v0

    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/p;->a()Lcom/google/crypto/tink/shaded/protobuf/p;

    move-result-object v1

    invoke-static {v0, v1}, Lx8/j;->o(Lcom/google/crypto/tink/shaded/protobuf/i;Lcom/google/crypto/tink/shaded/protobuf/p;)Lx8/j;

    move-result-object v0

    invoke-static {p1}, Lp8/s;->e(Lx8/E0;)Lcom/google/crypto/tink/shaded/protobuf/a;

    move-result-object p1

    check-cast p1, Lx8/h;

    invoke-virtual {v0}, Lx8/j;->m()Lx8/t;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Lx8/j;->n()Lx8/x0;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_56
    .catch Lcom/google/crypto/tink/shaded/protobuf/D; {:try_start_36 .. :try_end_56} :catch_57

    :goto_56
    return-void

    :catch_57
    move-exception p1

    new-instance v0, Ljava/security/GeneralSecurityException;

    const-string v1, "invalid KeyFormat protobuf, expected AesCtrHmacAeadKeyFormat"

    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_60
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v1, "unsupported AEAD DEM key type: "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static final b(Landroid/view/VelocityTracker;Landroid/view/MotionEvent;)V
    .registers 5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    sub-float/2addr v0, v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    sub-float/2addr v1, v2

    invoke-virtual {p1, v0, v1}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    invoke-static {p0}, Lkotlin/jvm/internal/l;->c(Ljava/lang/Object;)V

    invoke-virtual {p0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    neg-float p0, v0

    neg-float v0, v1

    invoke-virtual {p1, p0, v0}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    return-void
.end method

.method public static final c(I)Ljava/lang/String;
    .registers 2

    sget-object v0, LD5/b;->c:Luc/l;

    const v0, 0x7fffffff

    if-ne p0, v0, :cond_a

    const-string p0, ""

    goto :goto_e

    :cond_a
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    :goto_e
    return-object p0
.end method

.method public static d(Ljava/lang/String;)LD5/b;
    .registers 8

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    :cond_4
    const/4 v1, 0x1

    :try_start_5
    sget-object v2, LD5/b;->c:Luc/l;

    invoke-virtual {v2}, Luc/l;->getValue()Ljava/lang/Object;

    move-result-object v2

    const-string v3, "<get-headerParsingRegEx>(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/util/regex/Pattern;

    invoke-virtual {v2, p0}, Ljava/util/regex/Pattern;->split(Ljava/lang/CharSequence;)[Ljava/lang/String;

    move-result-object v2

    array-length v3, v2

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-ne v3, v4, :cond_1d

    move v3, v1

    goto :goto_1e

    :cond_1d
    move v3, v5

    :goto_1e
    if-eqz v3, :cond_7f

    aget-object v3, v2, v5

    const-string v4, "bytes"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_79

    aget-object v3, v2, v1

    const-string v4, "headerParts[1]"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/4 v4, 0x2

    aget-object v4, v2, v4

    const-string v6, "headerParts[2]"

    invoke-static {v4, v6}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    const/4 v6, 0x3

    aget-object v2, v2, v6

    const-string v6, "headerParts[3]"

    invoke-static {v2, v6}, Lkotlin/jvm/internal/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    if-le v4, v3, :cond_51

    move v6, v1

    goto :goto_52

    :cond_51
    move v6, v5

    :goto_52
    if-eqz v6, :cond_73

    if-le v2, v4, :cond_57

    move v5, v1

    :cond_57
    if-eqz v5, :cond_6d

    sub-int/2addr v2, v1

    if-ge v4, v2, :cond_64

    new-instance v2, LD5/b;

    invoke-direct {v2, v3, v4}, LD5/b;-><init>(II)V

    return-object v2

    :catch_62
    move-exception v2

    goto :goto_85

    :cond_64
    new-instance v2, LD5/b;

    const v4, 0x7fffffff

    invoke-direct {v2, v3, v4}, LD5/b;-><init>(II)V

    return-object v2

    :cond_6d
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v2

    :cond_73
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v2

    :cond_79
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v2

    :cond_7f
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v2
    :try_end_85
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_85} :catch_62

    :goto_85
    new-instance v3, Ljava/lang/IllegalArgumentException;

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string v1, "Invalid Content-Range header value: \"%s\""

    invoke-static {v0, v1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v3, p0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v3
.end method


# virtual methods
.method public a(Ljava/lang/String;)Z
    .registers 2

    invoke-static {p1}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    const/4 p1, 0x1

    return p1
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .registers 2

    const-string v0, "com.google.android.datatransport.events"

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    iget v0, p0, LC5/o;->a:I

    packed-switch v0, :pswitch_data_e

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_a
    const-string v0, "(isBackgroundSyncEnabled=true)"

    return-object v0

    nop

    :pswitch_data_e
    .packed-switch 0x5
        :pswitch_a
    .end packed-switch
.end method

.method public zza()Ljava/lang/Object;
    .registers 3

    iget v0, p0, LC5/o;->a:I

    packed-switch v0, :pswitch_data_86

    sget-object v0, Lcom/google/android/gms/internal/measurement/r5;->b:Lcom/google/android/gms/internal/measurement/r5;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/r5;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/u5;

    check-cast v0, Lcom/google/android/gms/internal/measurement/t5;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/t5;->b:Lcom/google/android/gms/internal/measurement/O2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    :pswitch_1e
    sget-object v0, Lcom/google/android/gms/internal/measurement/d4;->b:Lcom/google/android/gms/internal/measurement/d4;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/d4;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/g4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/f4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/f4;->A:Lcom/google/android/gms/internal/measurement/P2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    :pswitch_34
    sget-object v0, Lcom/google/android/gms/internal/measurement/d4;->b:Lcom/google/android/gms/internal/measurement/d4;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/d4;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/g4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/f4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/f4;->a0:Lcom/google/android/gms/internal/measurement/L2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    long-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :pswitch_53
    sget-object v0, Lcom/google/android/gms/internal/measurement/Y3;->b:Lcom/google/android/gms/internal/measurement/Y3;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/Y3;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/a4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/Z3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/Z3;->a:Lcom/google/android/gms/internal/measurement/O2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    :pswitch_6c
    sget-object v0, Lcom/google/android/gms/internal/measurement/p4;->b:Lcom/google/android/gms/internal/measurement/p4;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/p4;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/s4;

    check-cast v0, Lcom/google/android/gms/internal/measurement/r4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lcom/google/android/gms/internal/measurement/r4;->a:Lcom/google/android/gms/internal/measurement/O2;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I2;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    nop

    :pswitch_data_86
    .packed-switch 0x7
        :pswitch_6c
        :pswitch_53
        :pswitch_34
        :pswitch_1e
    .end packed-switch
.end method
