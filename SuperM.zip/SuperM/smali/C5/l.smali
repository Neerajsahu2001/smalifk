.class public interface abstract LC5/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Ljava/lang/Object;LX4/b;)LX4/b;
.end method

.method public abstract f(LE5/b;)I
.end method

.method public abstract get(Ljava/lang/Object;)LX4/b;
.end method

.method public abstract j(LD/C;)Z
.end method
