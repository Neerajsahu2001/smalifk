.class public final LC5/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x8

    new-array v0, v0, [Ljava/lang/Object;

    iput-object v0, p0, LC5/f;->b:Ljava/lang/Object;

    const/4 v0, 0x0

    iput v0, p0, LC5/f;->a:I

    return-void
.end method

.method public constructor <init>(Lfc/l;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, LC5/f;->c:Ljava/lang/Object;

    const/4 v0, 0x0

    iput v0, p0, LC5/f;->a:I

    iput-object p1, p0, LC5/f;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public declared-synchronized a()I
    .registers 2

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LC5/f;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/AbstractMap;->size()I

    move-result v0
    :try_end_9
    .catchall {:try_start_1 .. :try_end_9} :catchall_b

    monitor-exit p0

    return v0

    :catchall_b
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized b(LD/C;)Ljava/util/ArrayList;
    .registers 6

    monitor-enter p0

    :try_start_1
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, LC5/f;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    iget-object v1, p0, LC5/f;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1e
    :goto_1e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p1, v3}, LD/C;->d(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1e

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_37
    .catchall {:try_start_1 .. :try_end_37} :catchall_38

    goto :goto_1e

    :catchall_38
    move-exception p1

    goto :goto_3c

    :cond_3a
    monitor-exit p0

    return-object v0

    :goto_3c
    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized c(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 6

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LC5/f;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, LC5/f;->a:I

    if-nez v0, :cond_f

    const/4 v0, 0x0

    goto :goto_17

    :cond_f
    iget-object v2, p0, LC5/f;->b:Ljava/lang/Object;

    check-cast v2, LC5/q;

    invoke-interface {v2, v0}, LC5/q;->e(Ljava/lang/Object;)I

    move-result v0

    :goto_17
    sub-int/2addr v1, v0

    iput v1, p0, LC5/f;->a:I

    iget-object v0, p0, LC5/f;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1, p2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget p1, p0, LC5/f;->a:I

    iget-object v0, p0, LC5/f;->b:Ljava/lang/Object;

    check-cast v0, LC5/q;

    invoke-interface {v0, p2}, LC5/q;->e(Ljava/lang/Object;)I

    move-result p2

    add-int/2addr p1, p2

    iput p1, p0, LC5/f;->a:I
    :try_end_2e
    .catchall {:try_start_1 .. :try_end_2e} :catchall_30

    monitor-exit p0

    return-void

    :catchall_30
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized d(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, LC5/f;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    iget v0, p0, LC5/f;->a:I

    if-nez p1, :cond_f

    const/4 v1, 0x0

    goto :goto_17

    :cond_f
    iget-object v1, p0, LC5/f;->b:Ljava/lang/Object;

    check-cast v1, LC5/q;

    invoke-interface {v1, p1}, LC5/q;->e(Ljava/lang/Object;)I

    move-result v1

    :goto_17
    sub-int/2addr v0, v1

    iput v0, p0, LC5/f;->a:I
    :try_end_1a
    .catchall {:try_start_1 .. :try_end_1a} :catchall_1c

    monitor-exit p0

    return-object p1

    :catchall_1c
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized e(LE5/b;)Ljava/util/ArrayList;
    .registers 7

    monitor-enter p0

    :try_start_1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, LC5/f;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_12
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_47

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p1, v3}, LE5/b;->j(Ljava/lang/Object;)Z

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v3, p0, LC5/f;->a:I

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_36

    const/4 v2, 0x0

    goto :goto_3e

    :cond_36
    iget-object v4, p0, LC5/f;->b:Ljava/lang/Object;

    check-cast v4, LC5/q;

    invoke-interface {v4, v2}, LC5/q;->e(Ljava/lang/Object;)I

    move-result v2

    :goto_3e
    sub-int/2addr v3, v2

    iput v3, p0, LC5/f;->a:I

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V
    :try_end_44
    .catchall {:try_start_1 .. :try_end_44} :catchall_45

    goto :goto_12

    :catchall_45
    move-exception p1

    goto :goto_49

    :cond_47
    monitor-exit p0

    return-object v0

    :goto_49
    monitor-exit p0

    throw p1
.end method

.method public f(Ljava/lang/String;Lcom/google/android/gms/common/Feature;)V
    .registers 7

    iget v0, p0, LC5/f;->a:I

    add-int/lit8 v0, v0, 0x1

    iget-object v1, p0, LC5/f;->b:Ljava/lang/Object;

    check-cast v1, [Ljava/lang/Object;

    array-length v2, v1

    add-int/2addr v0, v0

    if-le v0, v2, :cond_31

    if-ltz v0, :cond_29

    shr-int/lit8 v3, v2, 0x1

    add-int/2addr v2, v3

    add-int/lit8 v2, v2, 0x1

    if-ge v2, v0, :cond_1d

    add-int/lit8 v0, v0, -0x1

    invoke-static {v0}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v0

    add-int v2, v0, v0

    :cond_1d
    if-gez v2, :cond_22

    const v2, 0x7fffffff

    :cond_22
    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, LC5/f;->b:Ljava/lang/Object;

    goto :goto_31

    :cond_29
    new-instance p1, Ljava/lang/AssertionError;

    const-string p2, "cannot store more than MAX_VALUE elements"

    invoke-direct {p1, p2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p1

    :cond_31
    :goto_31
    iget-object v0, p0, LC5/f;->b:Ljava/lang/Object;

    check-cast v0, [Ljava/lang/Object;

    iget v1, p0, LC5/f;->a:I

    add-int v2, v1, v1

    aput-object p1, v0, v2

    add-int/lit8 v2, v2, 0x1

    aput-object p2, v0, v2

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, LC5/f;->a:I

    return-void
.end method
