.class final Lp/S$a;
.super Landroid/hardware/camera2/CameraManager$AvailabilityCallback;
.source "CameraManagerCompat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lp/S;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/util/concurrent/Executor;

.field final b:Landroid/hardware/camera2/CameraManager$AvailabilityCallback;

.field private final c:Ljava/lang/Object;

.field private d:Z


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraManager$AvailabilityCallback;)V
    .registers 4

    invoke-direct {p0}, Landroid/hardware/camera2/CameraManager$AvailabilityCallback;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lp/S$a;->c:Ljava/lang/Object;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lp/S$a;->d:Z

    iput-object p1, p0, Lp/S$a;->a:Ljava/util/concurrent/Executor;

    iput-object p2, p0, Lp/S$a;->b:Landroid/hardware/camera2/CameraManager$AvailabilityCallback;

    return-void
.end method


# virtual methods
.method final a()V
    .registers 3

    iget-object v0, p0, Lp/S$a;->c:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x1

    :try_start_4
    iput-boolean v1, p0, Lp/S$a;->d:Z

    monitor-exit v0

    return-void

    :catchall_8
    move-exception v1

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_4 .. :try_end_a} :catchall_8

    throw v1
.end method

.method public final onCameraAccessPrioritiesChanged()V
    .registers 4

    iget-object v0, p0, Lp/S$a;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, Lp/S$a;->d:Z

    if-nez v1, :cond_14

    iget-object v1, p0, Lp/S$a;->a:Ljava/util/concurrent/Executor;

    new-instance v2, Lp/P;

    invoke-direct {v2, p0}, Lp/P;-><init>(Lp/S$a;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_14

    :catchall_12
    move-exception v1

    goto :goto_16

    :cond_14
    :goto_14
    monitor-exit v0

    return-void

    :goto_16
    monitor-exit v0
    :try_end_17
    .catchall {:try_start_3 .. :try_end_17} :catchall_12

    throw v1
.end method

.method public final onCameraAvailable(Ljava/lang/String;)V
    .registers 5

    iget-object v0, p0, Lp/S$a;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, Lp/S$a;->d:Z

    if-nez v1, :cond_14

    iget-object v1, p0, Lp/S$a;->a:Ljava/util/concurrent/Executor;

    new-instance v2, Lp/O;

    invoke-direct {v2, p0, p1}, Lp/O;-><init>(Lp/S$a;Ljava/lang/String;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_14

    :catchall_12
    move-exception p1

    goto :goto_16

    :cond_14
    :goto_14
    monitor-exit v0

    return-void

    :goto_16
    monitor-exit v0
    :try_end_17
    .catchall {:try_start_3 .. :try_end_17} :catchall_12

    throw p1
.end method

.method public final onCameraUnavailable(Ljava/lang/String;)V
    .registers 5

    iget-object v0, p0, Lp/S$a;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, Lp/S$a;->d:Z

    if-nez v1, :cond_14

    iget-object v1, p0, Lp/S$a;->a:Ljava/util/concurrent/Executor;

    new-instance v2, Lp/Q;

    invoke-direct {v2, p0, p1}, Lp/Q;-><init>(Lp/S$a;Ljava/lang/String;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_14

    :catchall_12
    move-exception p1

    goto :goto_16

    :cond_14
    :goto_14
    monitor-exit v0

    return-void

    :goto_16
    monitor-exit v0
    :try_end_17
    .catchall {:try_start_3 .. :try_end_17} :catchall_12

    throw p1
.end method
