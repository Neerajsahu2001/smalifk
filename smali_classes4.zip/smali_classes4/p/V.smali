.class public final synthetic Lp/v;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lp/l$c;

.field public final synthetic b:Landroid/hardware/camera2/CameraCaptureSession;

.field public final synthetic c:Landroid/view/Surface;


# direct methods
.method public synthetic constructor <init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;Landroid/view/Surface;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/v;->a:Lp/l$c;

    iput-object p2, p0, Lp/v;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iput-object p3, p0, Lp/v;->c:Landroid/view/Surface;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lp/v;->a:Lp/l$c;

    iget-object v0, v0, Lp/l$c;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    iget-object v1, p0, Lp/v;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iget-object v2, p0, Lp/v;->c:Landroid/view/Surface;

    invoke-static {v0, v1, v2}, Lp/c;->a(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;Landroid/hardware/camera2/CameraCaptureSession;Landroid/view/Surface;)V

    return-void
.end method
