.class public final synthetic Lp/r;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lp/l$b;

.field public final synthetic b:Landroid/hardware/camera2/CameraCaptureSession;

.field public final synthetic c:Landroid/hardware/camera2/CaptureRequest;

.field public final synthetic d:Landroid/view/Surface;

.field public final synthetic e:J


# direct methods
.method public synthetic constructor <init>(Lp/l$b;Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/view/Surface;J)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/r;->a:Lp/l$b;

    iput-object p2, p0, Lp/r;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iput-object p3, p0, Lp/r;->c:Landroid/hardware/camera2/CaptureRequest;

    iput-object p4, p0, Lp/r;->d:Landroid/view/Surface;

    iput-wide p5, p0, Lp/r;->e:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 8

    iget-object v0, p0, Lp/r;->a:Lp/l$b;

    iget-object v1, v0, Lp/l$b;->a:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    iget-object v2, p0, Lp/r;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iget-object v3, p0, Lp/r;->c:Landroid/hardware/camera2/CaptureRequest;

    iget-object v4, p0, Lp/r;->d:Landroid/view/Surface;

    iget-wide v5, p0, Lp/r;->e:J

    invoke-static/range {v1 .. v6}, Lp/e;->a(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/view/Surface;J)V

    return-void
.end method
