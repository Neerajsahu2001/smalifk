.class public final synthetic Lp/p;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lp/l$b;

.field public final synthetic b:Landroid/hardware/camera2/CameraCaptureSession;

.field public final synthetic c:I

.field public final synthetic d:J


# direct methods
.method public synthetic constructor <init>(Lp/l$b;Landroid/hardware/camera2/CameraCaptureSession;IJ)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/p;->a:Lp/l$b;

    iput-object p2, p0, Lp/p;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iput p3, p0, Lp/p;->c:I

    iput-wide p4, p0, Lp/p;->d:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget-object v0, p0, Lp/p;->a:Lp/l$b;

    iget-object v0, v0, Lp/l$b;->a:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    iget-object v1, p0, Lp/p;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iget v2, p0, Lp/p;->c:I

    iget-wide v3, p0, Lp/p;->d:J

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureSequenceCompleted(Landroid/hardware/camera2/CameraCaptureSession;IJ)V

    return-void
.end method
