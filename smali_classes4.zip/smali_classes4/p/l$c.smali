.class final Lp/l$c;
.super Landroid/hardware/camera2/CameraCaptureSession$StateCallback;
.source "CameraCaptureSessionCompat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lp/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation


# instance fields
.field final a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

.field private final b:Ljava/util/concurrent/Executor;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCaptureSession$StateCallback;)V
    .registers 3

    invoke-direct {p0}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;-><init>()V

    iput-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    iput-object p2, p0, Lp/l$c;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    return-void
.end method


# virtual methods
.method public final onActive(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    new-instance v0, Lp/t;

    invoke-direct {v0, p0, p1}, Lp/t;-><init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onCaptureQueueEmpty(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    new-instance v0, Lp/w;

    invoke-direct {v0, p0, p1}, Lp/w;-><init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onClosed(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    new-instance v0, Lp/u;

    invoke-direct {v0, p0, p1}, Lp/u;-><init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onConfigureFailed(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    new-instance v0, Lp/z;

    invoke-direct {v0, p0, p1}, Lp/z;-><init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onConfigured(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    new-instance v0, Lp/x;

    invoke-direct {v0, p0, p1}, Lp/x;-><init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onReady(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    new-instance v0, Lp/y;

    invoke-direct {v0, p0, p1}, Lp/y;-><init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onSurfacePrepared(Landroid/hardware/camera2/CameraCaptureSession;Landroid/view/Surface;)V
    .registers 4

    new-instance v0, Lp/v;

    invoke-direct {v0, p0, p1, p2}, Lp/v;-><init>(Lp/l$c;Landroid/hardware/camera2/CameraCaptureSession;Landroid/view/Surface;)V

    iget-object p1, p0, Lp/l$c;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
