.class interface abstract Lp/F$a;
.super Ljava/lang/Object;
.source "CameraDeviceCompat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lp/F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lq/i;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lp/k;
        }
    .end annotation
.end method
