.class public final Lp/a;
.super Ljava/lang/Object;
.source "ApiCompat.java"


# direct methods
.method public static a(Landroid/hardware/camera2/CameraDevice;)V
    .registers 1

    invoke-virtual {p0}, Landroid/hardware/camera2/CameraDevice;->close()V

    return-void
.end method
