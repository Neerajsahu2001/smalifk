.class public final Lp/l;
.super Ljava/lang/Object;
.source "CameraCaptureSessionCompat.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lp/l$c;,
        Lp/l$b;,
        Lp/l$a;
    }
.end annotation


# instance fields
.field private final a:Lp/B;


# direct methods
.method private constructor <init>(Landroid/hardware/camera2/CameraCaptureSession;Landroid/os/Handler;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_12

    new-instance p2, Lp/A;

    const/4 v0, 0x0

    invoke-direct {p2, p1, v0}, Lp/B;-><init>(Landroid/hardware/camera2/CameraCaptureSession;Ljava/lang/Object;)V

    iput-object p2, p0, Lp/l;->a:Lp/B;

    goto :goto_1e

    :cond_12
    new-instance v0, Lp/B;

    new-instance v1, Lp/B$a;

    invoke-direct {v1, p2}, Lp/B$a;-><init>(Landroid/os/Handler;)V

    invoke-direct {v0, p1, v1}, Lp/B;-><init>(Landroid/hardware/camera2/CameraCaptureSession;Ljava/lang/Object;)V

    iput-object v0, p0, Lp/l;->a:Lp/B;

    :goto_1e
    return-void
.end method

.method public static d(Landroid/hardware/camera2/CameraCaptureSession;Landroid/os/Handler;)Lp/l;
    .registers 3

    new-instance v0, Lp/l;

    invoke-direct {v0, p0, p1}, Lp/l;-><init>(Landroid/hardware/camera2/CameraCaptureSession;Landroid/os/Handler;)V

    return-object v0
.end method


# virtual methods
.method public final a(Ljava/util/ArrayList;Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/hardware/camera2/CameraAccessException;
        }
    .end annotation

    iget-object v0, p0, Lp/l;->a:Lp/B;

    invoke-interface {v0, p1, p2, p3}, Lp/l$a;->a(Ljava/util/ArrayList;Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I

    move-result p1

    return p1
.end method

.method public final b(Landroid/hardware/camera2/CaptureRequest;Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/hardware/camera2/CameraAccessException;
        }
    .end annotation

    iget-object v0, p0, Lp/l;->a:Lp/B;

    invoke-interface {v0, p1, p2, p3}, Lp/l$a;->b(Landroid/hardware/camera2/CaptureRequest;Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I

    move-result p1

    return p1
.end method

.method public final c()Landroid/hardware/camera2/CameraCaptureSession;
    .registers 2

    iget-object v0, p0, Lp/l;->a:Lp/B;

    iget-object v0, v0, Lp/B;->a:Landroid/hardware/camera2/CameraCaptureSession;

    return-object v0
.end method
