.class public final synthetic Lp/s;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lp/l$b;

.field public final synthetic b:Landroid/hardware/camera2/CameraCaptureSession;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lp/l$b;Landroid/hardware/camera2/CameraCaptureSession;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/s;->a:Lp/l$b;

    iput-object p2, p0, Lp/s;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iput p3, p0, Lp/s;->c:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lp/s;->a:Lp/l$b;

    iget-object v0, v0, Lp/l$b;->a:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    iget-object v1, p0, Lp/s;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iget v2, p0, Lp/s;->c:I

    invoke-virtual {v0, v1, v2}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureSequenceAborted(Landroid/hardware/camera2/CameraCaptureSession;I)V

    return-void
.end method
