.class public final synthetic Lp/m;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lp/l$b;

.field public final synthetic b:Landroid/hardware/camera2/CameraCaptureSession;

.field public final synthetic c:Landroid/hardware/camera2/CaptureRequest;

.field public final synthetic d:J

.field public final synthetic e:J


# direct methods
.method public synthetic constructor <init>(Lp/l$b;Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;JJ)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/m;->a:Lp/l$b;

    iput-object p2, p0, Lp/m;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iput-object p3, p0, Lp/m;->c:Landroid/hardware/camera2/CaptureRequest;

    iput-wide p4, p0, Lp/m;->d:J

    iput-wide p6, p0, Lp/m;->e:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    iget-object v0, p0, Lp/m;->a:Lp/l$b;

    iget-object v1, v0, Lp/l$b;->a:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    iget-object v2, p0, Lp/m;->b:Landroid/hardware/camera2/CameraCaptureSession;

    iget-object v3, p0, Lp/m;->c:Landroid/hardware/camera2/CaptureRequest;

    iget-wide v4, p0, Lp/m;->d:J

    iget-wide v6, p0, Lp/m;->e:J

    invoke-virtual/range {v1 .. v7}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureStarted(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;JJ)V

    return-void
.end method
