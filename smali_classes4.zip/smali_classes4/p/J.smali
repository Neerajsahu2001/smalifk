.class public final Lp/j;
.super Ljava/lang/Object;
.source "ApiCompat.java"


# direct methods
.method public static a(Landroid/hardware/camera2/CameraManager$AvailabilityCallback;)V
    .registers 1

    invoke-static {p0}, Lp/i;->a(Landroid/hardware/camera2/CameraManager$AvailabilityCallback;)V

    return-void
.end method
