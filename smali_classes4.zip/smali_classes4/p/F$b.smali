.class final Lp/F$b;
.super Landroid/hardware/camera2/CameraDevice$StateCallback;
.source "CameraDeviceCompat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lp/F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation


# instance fields
.field final a:Landroid/hardware/camera2/CameraDevice$StateCallback;

.field private final b:Ljava/util/concurrent/Executor;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraDevice$StateCallback;)V
    .registers 3

    invoke-direct {p0}, Landroid/hardware/camera2/CameraDevice$StateCallback;-><init>()V

    iput-object p1, p0, Lp/F$b;->b:Ljava/util/concurrent/Executor;

    iput-object p2, p0, Lp/F$b;->a:Landroid/hardware/camera2/CameraDevice$StateCallback;

    return-void
.end method


# virtual methods
.method public final onClosed(Landroid/hardware/camera2/CameraDevice;)V
    .registers 3

    new-instance v0, Lp/G;

    invoke-direct {v0, p0, p1}, Lp/G;-><init>(Lp/F$b;Landroid/hardware/camera2/CameraDevice;)V

    iget-object p1, p0, Lp/F$b;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onDisconnected(Landroid/hardware/camera2/CameraDevice;)V
    .registers 3

    new-instance v0, Lp/I;

    invoke-direct {v0, p0, p1}, Lp/I;-><init>(Lp/F$b;Landroid/hardware/camera2/CameraDevice;)V

    iget-object p1, p0, Lp/F$b;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onError(Landroid/hardware/camera2/CameraDevice;I)V
    .registers 4

    new-instance v0, Lp/H;

    invoke-direct {v0, p0, p1, p2}, Lp/H;-><init>(Lp/F$b;Landroid/hardware/camera2/CameraDevice;I)V

    iget-object p1, p0, Lp/F$b;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onOpened(Landroid/hardware/camera2/CameraDevice;)V
    .registers 3

    new-instance v0, Lp/J;

    invoke-direct {v0, p0, p1}, Lp/J;-><init>(Lp/F$b;Landroid/hardware/camera2/CameraDevice;)V

    iget-object p1, p0, Lp/F$b;->b:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
