.class public final Lo/a;
.super Lt/j;
.source "Camera2ImplConfig.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo/a$a;
    }
.end annotation


# static fields
.field public static final A:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroid/hardware/camera2/CameraCaptureSession$StateCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static final B:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static final C:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Lo/c;",
            ">;"
        }
    .end annotation
.end field

.field public static final D:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final E:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final y:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final z:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroid/hardware/camera2/CameraDevice$StateCallback;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "camera2.captureRequest.templateType"

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Lo/a;->y:Landroidx/camera/core/impl/H$a;

    const-string v0, "camera2.cameraDevice.stateCallback"

    const-class v1, Landroid/hardware/camera2/CameraDevice$StateCallback;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Lo/a;->z:Landroidx/camera/core/impl/H$a;

    const-string v0, "camera2.cameraCaptureSession.stateCallback"

    const-class v1, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Lo/a;->A:Landroidx/camera/core/impl/H$a;

    const-string v0, "camera2.cameraCaptureSession.captureCallback"

    const-class v1, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Lo/a;->B:Landroidx/camera/core/impl/H$a;

    const-string v0, "camera2.cameraEvent.callback"

    const-class v1, Lo/c;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Lo/a;->C:Landroidx/camera/core/impl/H$a;

    const-string v0, "camera2.captureRequest.tag"

    const-class v1, Ljava/lang/Object;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Lo/a;->D:Landroidx/camera/core/impl/H$a;

    const-string v0, "camera2.cameraCaptureSession.physicalCameraId"

    const-class v1, Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Lo/a;->E:Landroidx/camera/core/impl/H$a;

    return-void
.end method
