.class public final Lo/a$a;
.super Ljava/lang/Object;
.source "Camera2ImplConfig.java"

# interfaces
.implements Landroidx/camera/core/H;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/camera/core/H<",
        "Lo/a;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/k0;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    iput-object v0, p0, Lo/a$a;->a:Landroidx/camera/core/impl/k0;

    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/impl/j0;
    .registers 2

    iget-object v0, p0, Lo/a$a;->a:Landroidx/camera/core/impl/k0;

    return-object v0
.end method

.method public final b()Lo/a;
    .registers 3

    new-instance v0, Lo/a;

    iget-object v1, p0, Lo/a$a;->a:Landroidx/camera/core/impl/k0;

    invoke-static {v1}, Landroidx/camera/core/impl/o0;->D(Landroidx/camera/core/impl/j0;)Landroidx/camera/core/impl/o0;

    move-result-object v1

    invoke-direct {v0, v1}, Lt/j;-><init>(Landroidx/camera/core/impl/H;)V

    return-object v0
.end method

.method public final c(Landroidx/camera/core/impl/H;)V
    .registers 6

    invoke-interface {p1}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/H$a;

    iget-object v2, p0, Lo/a$a;->a:Landroidx/camera/core/impl/k0;

    invoke-interface {p1, v1}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_8

    :cond_1e
    return-void
.end method

.method public final e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V
    .registers 5

    sget-object v0, Lo/a;->y:Landroidx/camera/core/impl/H$a;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "camera2.captureRequest.option."

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/hardware/camera2/CaptureRequest$Key;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p1}, Landroidx/camera/core/impl/H$a;->b(Ljava/lang/String;Ljava/lang/Object;)Landroidx/camera/core/impl/H$a;

    move-result-object p1

    iget-object v0, p0, Lo/a$a;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v0, p1, p2}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method
