.class public final Lo/c;
.super Landroidx/camera/core/impl/i0;
.source "CameraEventCallbacks.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo/c$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/camera/core/impl/i0<",
        "Lo/b;",
        ">;"
    }
.end annotation


# direct methods
.method public static e()Lo/c;
    .registers 2

    new-instance v0, Lo/c;

    const/4 v1, 0x0

    new-array v1, v1, [Lo/b;

    invoke-direct {v0}, Landroidx/camera/core/impl/i0;-><init>()V

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/i0;->a(Ljava/util/List;)V

    return-object v0
.end method


# virtual methods
.method public final b()Lo/c;
    .registers 3

    invoke-static {}, Lo/c;->e()Lo/c;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/camera/core/impl/i0;->c()Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/i0;->a(Ljava/util/List;)V

    return-object v0
.end method

.method public final bridge synthetic clone()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    invoke-virtual {p0}, Lo/c;->b()Lo/c;

    move-result-object v0

    return-object v0
.end method

.method public final d()Lo/c$a;
    .registers 3

    new-instance v0, Lo/c$a;

    invoke-virtual {p0}, Landroidx/camera/core/impl/i0;->c()Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Lo/c$a;-><init>(Ljava/util/List;)V

    return-object v0
.end method
