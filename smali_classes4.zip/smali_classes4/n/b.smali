.class public final synthetic Ln/b;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/impl/u$a;


# virtual methods
.method public final a(Landroid/content/Context;Ljava/lang/Object;Ljava/util/Set;)Landroidx/camera/camera2/internal/c0;
    .registers 5

    :try_start_0
    new-instance v0, Landroidx/camera/camera2/internal/c0;

    invoke-direct {v0, p1, p2, p3}, Landroidx/camera/camera2/internal/c0;-><init>(Landroid/content/Context;Ljava/lang/Object;Ljava/util/Set;)V
    :try_end_5
    .catch Landroidx/camera/core/u; {:try_start_0 .. :try_end_5} :catch_6

    return-object v0

    :catch_6
    move-exception p1

    new-instance p2, Landroidx/camera/core/z0;

    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p2
.end method
