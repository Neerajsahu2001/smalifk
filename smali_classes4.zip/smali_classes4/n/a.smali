.class public final synthetic Ln/a;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/impl/v$a;


# virtual methods
.method public final a(Landroid/content/Context;Landroidx/camera/core/impl/A;Landroidx/camera/core/s;)Landroidx/camera/camera2/internal/v;
    .registers 5

    new-instance v0, Landroidx/camera/camera2/internal/v;

    invoke-direct {v0, p1, p2, p3}, Landroidx/camera/camera2/internal/v;-><init>(Landroid/content/Context;Landroidx/camera/core/impl/A;Landroidx/camera/core/s;)V

    return-object v0
.end method
