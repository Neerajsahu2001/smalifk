.class public final Landroidx/camera/core/I$a;
.super Ljava/lang/Object;
.source "FocusMeteringAction.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/I;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field final a:Ljava/util/ArrayList;

.field final b:Ljava/util/ArrayList;

.field final c:Ljava/util/ArrayList;

.field d:J


# direct methods
.method public constructor <init>(Landroidx/camera/core/D0;)V
    .registers 3

    const/4 v0, 0x7

    invoke-direct {p0, p1, v0}, Landroidx/camera/core/I$a;-><init>(Landroidx/camera/core/D0;I)V

    return-void
.end method

.method public constructor <init>(Landroidx/camera/core/D0;I)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/I$a;->a:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/I$a;->b:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/I$a;->c:Ljava/util/ArrayList;

    const-wide/16 v0, 0x1388

    iput-wide v0, p0, Landroidx/camera/core/I$a;->d:J

    invoke-virtual {p0, p1, p2}, Landroidx/camera/core/I$a;->a(Landroidx/camera/core/D0;I)V

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/D0;I)V
    .registers 6

    const/4 v0, 0x1

    if-lt p2, v0, :cond_7

    const/4 v1, 0x7

    if-gt p2, v1, :cond_7

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid metering mode "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    and-int/lit8 v0, p2, 0x1

    if-eqz v0, :cond_22

    iget-object v0, p0, Landroidx/camera/core/I$a;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_22
    and-int/lit8 v0, p2, 0x2

    if-eqz v0, :cond_2b

    iget-object v0, p0, Landroidx/camera/core/I$a;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2b
    and-int/lit8 p2, p2, 0x4

    if-eqz p2, :cond_34

    iget-object p2, p0, Landroidx/camera/core/I$a;->c:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_34
    return-void
.end method

.method public final b()Landroidx/camera/core/I;
    .registers 2

    new-instance v0, Landroidx/camera/core/I;

    invoke-direct {v0, p0}, Landroidx/camera/core/I;-><init>(Landroidx/camera/core/I$a;)V

    return-object v0
.end method

.method public final c()V
    .registers 3

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Landroidx/camera/core/I$a;->d:J

    return-void
.end method
