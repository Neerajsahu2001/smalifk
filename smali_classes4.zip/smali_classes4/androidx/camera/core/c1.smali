.class public final synthetic Landroidx/camera/core/c1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/i1$h;

.field public final synthetic b:Landroidx/camera/core/i1$g;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/i1$h;Landroidx/camera/core/i1$g;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/c1;->a:Landroidx/camera/core/i1$h;

    iput-object p2, p0, Landroidx/camera/core/c1;->b:Landroidx/camera/core/i1$g;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/c1;->a:Landroidx/camera/core/i1$h;

    check-cast v0, Landroidx/camera/view/m;

    iget-object v1, p0, Landroidx/camera/core/c1;->b:Landroidx/camera/core/i1$g;

    invoke-virtual {v0, v1}, Landroidx/camera/view/m;->a(Landroidx/camera/core/i1$g;)V

    return-void
.end method
