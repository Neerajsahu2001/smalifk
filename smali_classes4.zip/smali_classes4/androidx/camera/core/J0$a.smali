.class final Landroidx/camera/core/J0$a;
.super Landroidx/camera/core/impl/g;
.source "Preview.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/J0;->K(Ljava/lang/String;Landroidx/camera/core/impl/q0;Landroid/util/Size;)Landroidx/camera/core/impl/u0$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/impl/W;

.field final synthetic b:Landroidx/camera/core/J0;


# direct methods
.method constructor <init>(Landroidx/camera/core/J0;Landroidx/camera/core/impl/W;)V
    .registers 3

    iput-object p1, p0, Landroidx/camera/core/J0$a;->b:Landroidx/camera/core/J0;

    iput-object p2, p0, Landroidx/camera/core/J0$a;->a:Landroidx/camera/core/impl/W;

    invoke-direct {p0}, Landroidx/camera/core/impl/g;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Landroidx/camera/core/impl/o;)V
    .registers 2

    iget-object p1, p0, Landroidx/camera/core/J0$a;->a:Landroidx/camera/core/impl/W;

    invoke-interface {p1}, Landroidx/camera/core/impl/W;->a()Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, Landroidx/camera/core/J0$a;->b:Landroidx/camera/core/J0;

    invoke-virtual {p1}, Landroidx/camera/core/j1;->u()V

    :cond_d
    return-void
.end method
