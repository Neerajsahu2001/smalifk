.class public abstract Landroidx/camera/core/j1;
.super Ljava/lang/Object;
.source "UseCase.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/j1$b;,
        Landroidx/camera/core/j1$d;,
        Landroidx/camera/core/j1$c;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/HashSet;

.field private final b:Ljava/lang/Object;

.field private c:Landroidx/camera/core/j1$c;

.field private d:Landroidx/camera/core/impl/E0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation
.end field

.field private e:Landroidx/camera/core/impl/E0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation
.end field

.field private f:Landroidx/camera/core/impl/E0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation
.end field

.field private g:Landroid/util/Size;

.field private h:Landroidx/camera/core/impl/E0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation
.end field

.field private i:Landroid/graphics/Rect;

.field private j:Landroidx/camera/core/impl/x;

.field private k:Landroidx/camera/core/impl/u0;


# direct methods
.method protected constructor <init>(Landroidx/camera/core/impl/E0;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/E0<",
            "*>;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/j1;->a:Ljava/util/HashSet;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/j1;->b:Ljava/lang/Object;

    sget-object v0, Landroidx/camera/core/j1$c;->INACTIVE:Landroidx/camera/core/j1$c;

    iput-object v0, p0, Landroidx/camera/core/j1;->c:Landroidx/camera/core/j1$c;

    invoke-static {}, Landroidx/camera/core/impl/u0;->a()Landroidx/camera/core/impl/u0;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/j1;->k:Landroidx/camera/core/impl/u0;

    iput-object p1, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    iput-object p1, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    return-void
.end method


# virtual methods
.method protected A(Landroidx/camera/core/impl/w;Landroidx/camera/core/impl/E0$a;)Landroidx/camera/core/impl/E0;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/w;",
            "Landroidx/camera/core/impl/E0$a<",
            "***>;)",
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation

    invoke-interface {p2}, Landroidx/camera/core/impl/E0$a;->d()Landroidx/camera/core/impl/E0;

    move-result-object p1

    return-object p1
.end method

.method public final B()V
    .registers 1

    invoke-virtual {p0}, Landroidx/camera/core/j1;->x()V

    return-void
.end method

.method public C()V
    .registers 1

    return-void
.end method

.method protected abstract D(Landroid/util/Size;)Landroid/util/Size;
.end method

.method public E(Landroid/graphics/Matrix;)V
    .registers 2

    return-void
.end method

.method public F(I)V
    .registers 2

    invoke-virtual {p0, p1}, Landroidx/camera/core/j1;->G(I)Z

    return-void
.end method

.method protected final G(I)Z
    .registers 7

    iget-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    check-cast v0, Landroidx/camera/core/impl/Z;

    const/4 v1, -0x1

    invoke-interface {v0, v1}, Landroidx/camera/core/impl/Z;->s(I)I

    move-result v0

    if-eq v0, v1, :cond_10

    if-eq v0, p1, :cond_e

    goto :goto_10

    :cond_e
    const/4 p1, 0x0

    return p1

    :cond_10
    :goto_10
    iget-object v0, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    invoke-virtual {p0, v0}, Landroidx/camera/core/j1;->m(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/E0$a;

    move-result-object v0

    invoke-interface {v0}, Landroidx/camera/core/impl/E0$a;->d()Landroidx/camera/core/impl/E0;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/Z;

    invoke-interface {v2, v1}, Landroidx/camera/core/impl/Z;->s(I)I

    move-result v3

    if-eq v3, v1, :cond_24

    if-eq v3, p1, :cond_2a

    :cond_24
    move-object v4, v0

    check-cast v4, Landroidx/camera/core/impl/Z$a;

    invoke-interface {v4, p1}, Landroidx/camera/core/impl/Z$a;->b(I)Ljava/lang/Object;

    :cond_2a
    if-eq v3, v1, :cond_5d

    if-eq p1, v1, :cond_5d

    if-ne v3, p1, :cond_31

    goto :goto_5d

    :cond_31
    invoke-static {v3}, Landroidx/camera/core/impl/utils/b;->b(I)I

    move-result v1

    invoke-static {p1}, Landroidx/camera/core/impl/utils/b;->b(I)I

    move-result p1

    sub-int/2addr p1, v1

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    rem-int/lit16 p1, p1, 0xb4

    const/16 v1, 0x5a

    if-ne p1, v1, :cond_5d

    invoke-interface {v2}, Landroidx/camera/core/impl/Z;->m()Landroid/util/Size;

    move-result-object p1

    if-eqz p1, :cond_5d

    move-object v1, v0

    check-cast v1, Landroidx/camera/core/impl/Z$a;

    new-instance v2, Landroid/util/Size;

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result v3

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result p1

    invoke-direct {v2, v3, p1}, Landroid/util/Size;-><init>(II)V

    invoke-interface {v1, v2}, Landroidx/camera/core/impl/Z$a;->c(Landroid/util/Size;)Ljava/lang/Object;

    :cond_5d
    :goto_5d
    invoke-interface {v0}, Landroidx/camera/core/impl/E0$a;->d()Landroidx/camera/core/impl/E0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    invoke-virtual {p0}, Landroidx/camera/core/j1;->c()Landroidx/camera/core/impl/x;

    move-result-object p1

    if-nez p1, :cond_6e

    iget-object p1, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    iput-object p1, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    goto :goto_7c

    :cond_6e
    invoke-interface {p1}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/core/j1;->d:Landroidx/camera/core/impl/E0;

    iget-object v1, p0, Landroidx/camera/core/j1;->h:Landroidx/camera/core/impl/E0;

    invoke-virtual {p0, p1, v0, v1}, Landroidx/camera/core/j1;->p(Landroidx/camera/core/impl/w;Landroidx/camera/core/impl/E0;Landroidx/camera/core/impl/E0;)Landroidx/camera/core/impl/E0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    :goto_7c
    const/4 p1, 0x1

    return p1
.end method

.method public H(Landroid/graphics/Rect;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/core/j1;->i:Landroid/graphics/Rect;

    return-void
.end method

.method protected final I(Landroidx/camera/core/impl/u0;)V
    .registers 4

    iput-object p1, p0, Landroidx/camera/core/j1;->k:Landroidx/camera/core/impl/u0;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->j()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_a
    :goto_a
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_24

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/K;

    invoke-virtual {v0}, Landroidx/camera/core/impl/K;->e()Ljava/lang/Class;

    move-result-object v1

    if-nez v1, :cond_a

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/K;->m(Ljava/lang/Class;)V

    goto :goto_a

    :cond_24
    return-void
.end method

.method public final J(Landroid/util/Size;)V
    .registers 2

    invoke-virtual {p0, p1}, Landroidx/camera/core/j1;->D(Landroid/util/Size;)Landroid/util/Size;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/j1;->g:Landroid/util/Size;

    return-void
.end method

.method protected final a()I
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    check-cast v0, Landroidx/camera/core/impl/Z;

    invoke-interface {v0}, Landroidx/camera/core/impl/Z;->B()I

    move-result v0

    return v0
.end method

.method public final b()Landroid/util/Size;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/j1;->g:Landroid/util/Size;

    return-object v0
.end method

.method public final c()Landroidx/camera/core/impl/x;
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/j1;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/j1;->j:Landroidx/camera/core/impl/x;

    monitor-exit v0

    return-object v1

    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method protected final d()Landroidx/camera/core/impl/t;
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/j1;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/j1;->j:Landroidx/camera/core/impl/x;

    if-nez v1, :cond_d

    sget-object v1, Landroidx/camera/core/impl/t;->a:Landroidx/camera/core/impl/t;

    monitor-exit v0

    return-object v1

    :catchall_b
    move-exception v1

    goto :goto_13

    :cond_d
    invoke-interface {v1}, Landroidx/camera/core/impl/x;->e()Landroidx/camera/camera2/internal/t;

    move-result-object v1

    monitor-exit v0

    return-object v1

    :goto_13
    monitor-exit v0
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_b

    throw v1
.end method

.method protected final e()Ljava/lang/String;
    .registers 4

    invoke-virtual {p0}, Landroidx/camera/core/j1;->c()Landroidx/camera/core/impl/x;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "No camera attached to use case: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v0}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/K;->b()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final f()Landroidx/camera/core/impl/E0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    return-object v0
.end method

.method public abstract g(ZLandroidx/camera/core/impl/F0;)Landroidx/camera/core/impl/E0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Landroidx/camera/core/impl/F0;",
            ")",
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation
.end method

.method public final h()I
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    invoke-interface {v0}, Landroidx/camera/core/impl/X;->f()I

    move-result v0

    return v0
.end method

.method public final i()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "<UnknownUseCase-"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ">"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lw/h;->i(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final j()Landroidx/camera/core/impl/u0;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/j1;->k:Landroidx/camera/core/impl/u0;

    return-object v0
.end method

.method public k()I
    .registers 2

    invoke-virtual {p0}, Landroidx/camera/core/j1;->l()I

    move-result v0

    return v0
.end method

.method protected final l()I
    .registers 3
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    check-cast v0, Landroidx/camera/core/impl/Z;

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Landroidx/camera/core/impl/Z;->s(I)I

    move-result v0

    return v0
.end method

.method public abstract m(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/E0$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/H;",
            ")",
            "Landroidx/camera/core/impl/E0$a<",
            "***>;"
        }
    .end annotation
.end method

.method public final n()Landroid/graphics/Rect;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/j1;->i:Landroid/graphics/Rect;

    return-object v0
.end method

.method protected final o(Ljava/lang/String;)Z
    .registers 3

    invoke-virtual {p0}, Landroidx/camera/core/j1;->c()Landroidx/camera/core/impl/x;

    move-result-object v0

    if-nez v0, :cond_8

    const/4 p1, 0x0

    return p1

    :cond_8
    invoke-virtual {p0}, Landroidx/camera/core/j1;->e()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final p(Landroidx/camera/core/impl/w;Landroidx/camera/core/impl/E0;Landroidx/camera/core/impl/E0;)Landroidx/camera/core/impl/E0;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/w;",
            "Landroidx/camera/core/impl/E0<",
            "*>;",
            "Landroidx/camera/core/impl/E0<",
            "*>;)",
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation

    if-eqz p3, :cond_c

    invoke-static {p3}, Landroidx/camera/core/impl/k0;->F(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/k0;

    move-result-object p3

    sget-object v0, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p3, v0}, Landroidx/camera/core/impl/k0;->I(Landroidx/camera/core/impl/H$a;)V

    goto :goto_10

    :cond_c
    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object p3

    :goto_10
    iget-object v0, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    invoke-interface {v0}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_36

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/H$a;

    iget-object v2, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    invoke-interface {v2, v1}, Landroidx/camera/core/impl/H;->y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object v2

    iget-object v3, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    invoke-interface {v3, v1}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p3, v1, v2, v3}, Landroidx/camera/core/impl/k0;->G(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;Ljava/lang/Object;)V

    goto :goto_1a

    :cond_36
    if-eqz p2, :cond_69

    invoke-interface {p2}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_40
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_69

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1}, Landroidx/camera/core/impl/H$a;->c()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v3}, Landroidx/camera/core/impl/H$a;->c()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5d

    goto :goto_40

    :cond_5d
    invoke-interface {p2, v1}, Landroidx/camera/core/impl/H;->y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object v2

    invoke-interface {p2, v1}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p3, v1, v2, v3}, Landroidx/camera/core/impl/k0;->G(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;Ljava/lang/Object;)V

    goto :goto_40

    :cond_69
    sget-object p2, Landroidx/camera/core/impl/Z;->i:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p3, p2}, Landroidx/camera/core/impl/o0;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result p2

    if-eqz p2, :cond_7c

    sget-object p2, Landroidx/camera/core/impl/Z;->f:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p3, p2}, Landroidx/camera/core/impl/o0;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result v0

    if-eqz v0, :cond_7c

    invoke-virtual {p3, p2}, Landroidx/camera/core/impl/k0;->I(Landroidx/camera/core/impl/H$a;)V

    :cond_7c
    invoke-virtual {p0, p3}, Landroidx/camera/core/j1;->m(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/E0$a;

    move-result-object p2

    invoke-virtual {p0, p1, p2}, Landroidx/camera/core/j1;->A(Landroidx/camera/core/impl/w;Landroidx/camera/core/impl/E0$a;)Landroidx/camera/core/impl/E0;

    move-result-object p1

    return-object p1
.end method

.method protected final q()V
    .registers 2

    sget-object v0, Landroidx/camera/core/j1$c;->ACTIVE:Landroidx/camera/core/j1$c;

    iput-object v0, p0, Landroidx/camera/core/j1;->c:Landroidx/camera/core/j1$c;

    invoke-virtual {p0}, Landroidx/camera/core/j1;->t()V

    return-void
.end method

.method protected final r()V
    .registers 2

    sget-object v0, Landroidx/camera/core/j1$c;->INACTIVE:Landroidx/camera/core/j1$c;

    iput-object v0, p0, Landroidx/camera/core/j1;->c:Landroidx/camera/core/j1$c;

    invoke-virtual {p0}, Landroidx/camera/core/j1;->t()V

    return-void
.end method

.method protected final s()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/j1;->a:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/j1$d;

    invoke-interface {v1, p0}, Landroidx/camera/core/j1$d;->f(Landroidx/camera/core/j1;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final t()V
    .registers 4

    sget-object v0, Landroidx/camera/core/j1$a;->a:[I

    iget-object v1, p0, Landroidx/camera/core/j1;->c:Landroidx/camera/core/j1$c;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    iget-object v1, p0, Landroidx/camera/core/j1;->a:Ljava/util/HashSet;

    const/4 v2, 0x1

    if-eq v0, v2, :cond_27

    const/4 v2, 0x2

    if-eq v0, v2, :cond_13

    goto :goto_3b

    :cond_13
    invoke-virtual {v1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_17
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/j1$d;

    invoke-interface {v1, p0}, Landroidx/camera/core/j1$d;->c(Landroidx/camera/core/j1;)V

    goto :goto_17

    :cond_27
    invoke-virtual {v1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/j1$d;

    invoke-interface {v1, p0}, Landroidx/camera/core/j1$d;->m(Landroidx/camera/core/j1;)V

    goto :goto_2b

    :cond_3b
    :goto_3b
    return-void
.end method

.method protected final u()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/j1;->a:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/j1$d;

    invoke-interface {v1, p0}, Landroidx/camera/core/j1$d;->d(Landroidx/camera/core/j1;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final v(Landroidx/camera/core/impl/x;Landroidx/camera/core/impl/E0;Landroidx/camera/core/impl/E0;)V
    .registers 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/x;",
            "Landroidx/camera/core/impl/E0<",
            "*>;",
            "Landroidx/camera/core/impl/E0<",
            "*>;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/j1;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iput-object p1, p0, Landroidx/camera/core/j1;->j:Landroidx/camera/core/impl/x;

    iget-object v1, p0, Landroidx/camera/core/j1;->a:Ljava/util/HashSet;

    invoke-virtual {v1, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    monitor-exit v0
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_2a

    iput-object p2, p0, Landroidx/camera/core/j1;->d:Landroidx/camera/core/impl/E0;

    iput-object p3, p0, Landroidx/camera/core/j1;->h:Landroidx/camera/core/impl/E0;

    invoke-interface {p1}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object p1

    iget-object p2, p0, Landroidx/camera/core/j1;->d:Landroidx/camera/core/impl/E0;

    iget-object p3, p0, Landroidx/camera/core/j1;->h:Landroidx/camera/core/impl/E0;

    invoke-virtual {p0, p1, p2, p3}, Landroidx/camera/core/j1;->p(Landroidx/camera/core/impl/w;Landroidx/camera/core/impl/E0;Landroidx/camera/core/impl/E0;)Landroidx/camera/core/impl/E0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    invoke-interface {p1}, Lw/j;->t()Landroidx/camera/core/j1$b;

    move-result-object p1

    if-eqz p1, :cond_26

    invoke-interface {p1}, Landroidx/camera/core/j1$b;->a()V

    :cond_26
    invoke-virtual {p0}, Landroidx/camera/core/j1;->w()V

    return-void

    :catchall_2a
    move-exception p1

    :try_start_2b
    monitor-exit v0
    :try_end_2c
    .catchall {:try_start_2b .. :try_end_2c} :catchall_2a

    throw p1
.end method

.method public w()V
    .registers 1

    return-void
.end method

.method protected x()V
    .registers 1

    return-void
.end method

.method public final y(Landroidx/camera/core/impl/x;)V
    .registers 4

    invoke-virtual {p0}, Landroidx/camera/core/j1;->z()V

    iget-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    invoke-interface {v0}, Lw/j;->t()Landroidx/camera/core/j1$b;

    move-result-object v0

    if-eqz v0, :cond_e

    invoke-interface {v0}, Landroidx/camera/core/j1$b;->b()V

    :cond_e
    iget-object v0, p0, Landroidx/camera/core/j1;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_11
    iget-object v1, p0, Landroidx/camera/core/j1;->j:Landroidx/camera/core/impl/x;

    if-ne p1, v1, :cond_17

    const/4 p1, 0x1

    goto :goto_18

    :cond_17
    const/4 p1, 0x0

    :goto_18
    invoke-static {p1}, Landroidx/core/util/g;->b(Z)V

    iget-object p1, p0, Landroidx/camera/core/j1;->j:Landroidx/camera/core/impl/x;

    iget-object v1, p0, Landroidx/camera/core/j1;->a:Ljava/util/HashSet;

    invoke-virtual {v1, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/camera/core/j1;->j:Landroidx/camera/core/impl/x;

    monitor-exit v0
    :try_end_26
    .catchall {:try_start_11 .. :try_end_26} :catchall_33

    iput-object p1, p0, Landroidx/camera/core/j1;->g:Landroid/util/Size;

    iput-object p1, p0, Landroidx/camera/core/j1;->i:Landroid/graphics/Rect;

    iget-object v0, p0, Landroidx/camera/core/j1;->e:Landroidx/camera/core/impl/E0;

    iput-object v0, p0, Landroidx/camera/core/j1;->f:Landroidx/camera/core/impl/E0;

    iput-object p1, p0, Landroidx/camera/core/j1;->d:Landroidx/camera/core/impl/E0;

    iput-object p1, p0, Landroidx/camera/core/j1;->h:Landroidx/camera/core/impl/E0;

    return-void

    :catchall_33
    move-exception p1

    :try_start_34
    monitor-exit v0
    :try_end_35
    .catchall {:try_start_34 .. :try_end_35} :catchall_33

    throw p1
.end method

.method public z()V
    .registers 1

    return-void
.end method
