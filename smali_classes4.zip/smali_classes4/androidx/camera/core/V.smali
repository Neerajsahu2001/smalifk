.class public final synthetic Landroidx/camera/core/v;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/concurrent/futures/b$c;


# instance fields
.field public final synthetic a:Landroidx/camera/core/y;

.field public final synthetic b:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Landroidx/camera/core/y;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/camera/core/v;->a:Landroidx/camera/core/y;

    iput-object p1, p0, Landroidx/camera/core/v;->b:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/concurrent/futures/b$a;)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/v;->a:Landroidx/camera/core/y;

    iget-object v1, p0, Landroidx/camera/core/v;->b:Landroid/content/Context;

    invoke-static {v0, v1, p1}, Landroidx/camera/core/y;->b(Landroidx/camera/core/y;Landroid/content/Context;Landroidx/concurrent/futures/b$a;)V

    const-string p1, "CameraX initInternal"

    return-object p1
.end method
