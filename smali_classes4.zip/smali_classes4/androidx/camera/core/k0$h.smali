.class public final Landroidx/camera/core/k0$h;
.super Ljava/lang/Object;
.source "ImageCapture.java"

# interfaces
.implements Landroidx/camera/core/impl/E0$a;
.implements Landroidx/camera/core/impl/Z$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "h"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/camera/core/impl/E0$a<",
        "Landroidx/camera/core/k0;",
        "Landroidx/camera/core/impl/V;",
        "Landroidx/camera/core/k0$h;",
        ">;",
        "Landroidx/camera/core/impl/Z$a<",
        "Landroidx/camera/core/k0$h;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/k0;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    invoke-direct {p0, v0}, Landroidx/camera/core/k0$h;-><init>(Landroidx/camera/core/impl/k0;)V

    return-void
.end method

.method private constructor <init>(Landroidx/camera/core/impl/k0;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    sget-object v0, Lw/h;->u:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    :try_start_8
    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_f

    :catch_d
    nop

    move-object p1, v1

    :goto_f
    check-cast p1, Ljava/lang/Class;

    const-class v0, Landroidx/camera/core/k0;

    if-eqz p1, :cond_38

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1c

    goto :goto_38

    :cond_1c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid target class configuration for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_38
    :goto_38
    sget-object p1, Lw/h;->u:Landroidx/camera/core/impl/H$a;

    iget-object v2, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, p1, v0}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    sget-object p1, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    :try_start_41
    invoke-virtual {v2, p1}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v1
    :try_end_45
    .catch Ljava/lang/IllegalArgumentException; {:try_start_41 .. :try_end_45} :catch_46

    goto :goto_47

    :catch_46
    nop

    :goto_47
    if-nez v1, :cond_68

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "-"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/camera/core/k0$h;->k(Ljava/lang/String;)V

    :cond_68
    return-void
.end method

.method public static f(Landroidx/camera/core/impl/H;)Landroidx/camera/core/k0$h;
    .registers 2

    new-instance v0, Landroidx/camera/core/k0$h;

    invoke-static {p0}, Landroidx/camera/core/impl/k0;->F(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/k0;

    move-result-object p0

    invoke-direct {v0, p0}, Landroidx/camera/core/k0$h;-><init>(Landroidx/camera/core/impl/k0;)V

    return-object v0
.end method


# virtual methods
.method public final a()Landroidx/camera/core/impl/j0;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    return-object v0
.end method

.method public final b(I)Ljava/lang/Object;
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->g:Landroidx/camera/core/impl/H$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-object v1, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-object p0
.end method

.method public final bridge synthetic c(Landroid/util/Size;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p0, p1}, Landroidx/camera/core/k0$h;->l(Landroid/util/Size;)V

    return-object p0
.end method

.method public final bridge synthetic d()Landroidx/camera/core/impl/E0;
    .registers 2

    invoke-virtual {p0}, Landroidx/camera/core/k0$h;->g()Landroidx/camera/core/impl/V;

    move-result-object v0

    return-object v0
.end method

.method public final e()Landroidx/camera/core/k0;
    .registers 8

    sget-object v0, Landroidx/camera/core/impl/Z;->f:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    :try_start_8
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_f

    :catch_d
    nop

    move-object v0, v2

    :goto_f
    if-eqz v0, :cond_25

    sget-object v0, Landroidx/camera/core/impl/Z;->i:Landroidx/camera/core/impl/H$a;

    :try_start_13
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_17
    .catch Ljava/lang/IllegalArgumentException; {:try_start_13 .. :try_end_17} :catch_18

    goto :goto_1a

    :catch_18
    nop

    move-object v0, v2

    :goto_1a
    if-nez v0, :cond_1d

    goto :goto_25

    :cond_1d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_25
    :goto_25
    sget-object v0, Landroidx/camera/core/impl/V;->C:Landroidx/camera/core/impl/H$a;

    :try_start_27
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_2b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_27 .. :try_end_2b} :catch_2c

    goto :goto_2e

    :catch_2c
    nop

    move-object v0, v2

    :goto_2e
    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_4d

    sget-object v5, Landroidx/camera/core/impl/V;->B:Landroidx/camera/core/impl/H$a;

    :try_start_36
    invoke-virtual {v1, v5}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v5
    :try_end_3a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_36 .. :try_end_3a} :catch_3b

    goto :goto_3d

    :catch_3b
    nop

    move-object v5, v2

    :goto_3d
    if-nez v5, :cond_41

    const/4 v5, 0x1

    goto :goto_42

    :cond_41
    const/4 v5, 0x0

    :goto_42
    const-string v6, "Cannot set buffer format with CaptureProcessor defined."

    invoke-static {v5, v6}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    sget-object v5, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1, v5, v0}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_6f

    :cond_4d
    sget-object v0, Landroidx/camera/core/impl/V;->B:Landroidx/camera/core/impl/H$a;

    :try_start_4f
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_53
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4f .. :try_end_53} :catch_54

    goto :goto_56

    :catch_54
    nop

    move-object v0, v2

    :goto_56
    if-eqz v0, :cond_64

    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    const/16 v5, 0x23

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v0, v5}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_6f

    :cond_64
    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    const/16 v5, 0x100

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v0, v5}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    :goto_6f
    new-instance v0, Landroidx/camera/core/k0;

    invoke-virtual {p0}, Landroidx/camera/core/k0$h;->g()Landroidx/camera/core/impl/V;

    move-result-object v5

    invoke-direct {v0, v5}, Landroidx/camera/core/k0;-><init>(Landroidx/camera/core/impl/V;)V

    sget-object v5, Landroidx/camera/core/impl/Z;->i:Landroidx/camera/core/impl/H$a;

    :try_start_7a
    invoke-virtual {v1, v5}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v2
    :try_end_7e
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7a .. :try_end_7e} :catch_7f

    goto :goto_80

    :catch_7f
    nop

    :goto_80
    check-cast v2, Landroid/util/Size;

    if-eqz v2, :cond_94

    new-instance v5, Landroid/util/Rational;

    invoke-virtual {v2}, Landroid/util/Size;->getWidth()I

    move-result v6

    invoke-virtual {v2}, Landroid/util/Size;->getHeight()I

    move-result v2

    invoke-direct {v5, v6, v2}, Landroid/util/Rational;-><init>(II)V

    invoke-virtual {v0, v5}, Landroidx/camera/core/k0;->W(Landroid/util/Rational;)V

    :cond_94
    sget-object v2, Landroidx/camera/core/impl/V;->D:Landroidx/camera/core/impl/H$a;

    const/4 v5, 0x2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    :try_start_9b
    invoke-virtual {v1, v2}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v6
    :try_end_9f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_9b .. :try_end_9f} :catch_a0

    goto :goto_a1

    :catch_a0
    nop

    :goto_a1
    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-lt v2, v4, :cond_aa

    const/4 v3, 0x1

    :cond_aa
    const-string v2, "Maximum outstanding image count must be at least 1"

    invoke-static {v3, v2}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    sget-object v2, Lw/f;->s:Landroidx/camera/core/impl/H$a;

    invoke-static {}, Lu/a;->c()Ljava/util/concurrent/Executor;

    move-result-object v3

    :try_start_b5
    invoke-virtual {v1, v2}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v3
    :try_end_b9
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b5 .. :try_end_b9} :catch_b9

    :catch_b9
    check-cast v3, Ljava/util/concurrent/Executor;

    const-string v2, "The IO executor can\'t be null"

    invoke-static {v3, v2}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Landroidx/camera/core/impl/V;->z:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1, v2}, Landroidx/camera/core/impl/o0;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result v3

    if-eqz v3, :cond_ed

    invoke-virtual {v1, v2}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-eqz v1, :cond_ed

    if-eq v1, v4, :cond_ed

    if-ne v1, v5, :cond_d9

    goto :goto_ed

    :cond_d9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "The flash mode is not allowed to set: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_ed
    :goto_ed
    return-object v0
.end method

.method public final g()Landroidx/camera/core/impl/V;
    .registers 3

    new-instance v0, Landroidx/camera/core/impl/V;

    iget-object v1, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-static {v1}, Landroidx/camera/core/impl/o0;->D(Landroidx/camera/core/impl/j0;)Landroidx/camera/core/impl/o0;

    move-result-object v1

    invoke-direct {v0, v1}, Landroidx/camera/core/impl/V;-><init>(Landroidx/camera/core/impl/o0;)V

    return-object v0
.end method

.method public final h()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/V;->y:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final i()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/E0;->q:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final j(I)V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->f:Landroidx/camera/core/impl/H$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-object v1, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final k(Ljava/lang/String;)V
    .registers 4

    sget-object v0, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final l(Landroid/util/Size;)V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->i:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/k0$h;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method
