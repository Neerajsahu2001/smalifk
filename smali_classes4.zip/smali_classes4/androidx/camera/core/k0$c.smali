.class final Landroidx/camera/core/k0$c;
.super Ljava/lang/Object;
.source "ImageCapture.java"

# interfaces
.implements Landroidx/camera/core/k0$k$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/k0;->N(Ljava/lang/String;Landroidx/camera/core/impl/V;Landroid/util/Size;)Landroidx/camera/core/impl/u0$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lw/n;


# direct methods
.method constructor <init>(Lw/n;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$c;->a:Lw/n;

    return-void
.end method
