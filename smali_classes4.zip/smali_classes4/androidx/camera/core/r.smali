.class public interface abstract Landroidx/camera/core/r;
.super Ljava/lang/Object;
.source "CameraInfo.java"


# virtual methods
.method public abstract a()I
.end method

.method public abstract g()Landroidx/lifecycle/I;
.end method

.method public abstract h(I)I
.end method

.method public abstract i()Landroidx/lifecycle/I;
.end method
