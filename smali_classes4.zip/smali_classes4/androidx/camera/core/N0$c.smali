.class final Landroidx/camera/core/N0$c;
.super Ljava/lang/Object;
.source "ProcessingImageReader.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/N0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/util/List<",
        "Landroidx/camera/core/r0;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/N0;


# direct methods
.method constructor <init>(Landroidx/camera/core/N0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/N0$c;->a:Landroidx/camera/core/N0;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 2

    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 6

    check-cast p1, Ljava/util/List;

    iget-object p1, p0, Landroidx/camera/core/N0$c;->a:Landroidx/camera/core/N0;

    iget-object p1, p1, Landroidx/camera/core/N0;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_7
    iget-object v0, p0, Landroidx/camera/core/N0$c;->a:Landroidx/camera/core/N0;

    iget-boolean v1, v0, Landroidx/camera/core/N0;->e:Z

    if-eqz v1, :cond_11

    monitor-exit p1

    goto :goto_4c

    :catchall_f
    move-exception v0

    goto :goto_52

    :cond_11
    const/4 v1, 0x1

    iput-boolean v1, v0, Landroidx/camera/core/N0;->f:Z

    iget-object v1, v0, Landroidx/camera/core/N0;->q:Landroidx/camera/core/Z0;

    iget-object v2, v0, Landroidx/camera/core/N0;->t:Landroidx/camera/core/N0$e;

    iget-object v3, v0, Landroidx/camera/core/N0;->u:Ljava/util/concurrent/Executor;

    monitor-exit p1
    :try_end_1b
    .catchall {:try_start_7 .. :try_end_1b} :catchall_f

    :try_start_1b
    iget-object p1, v0, Landroidx/camera/core/N0;->n:Landroidx/camera/core/impl/E;

    invoke-interface {p1, v1}, Landroidx/camera/core/impl/E;->d(Landroidx/camera/core/impl/a0;)V
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_20} :catch_21

    goto :goto_3e

    :catch_21
    move-exception p1

    iget-object v0, p0, Landroidx/camera/core/N0$c;->a:Landroidx/camera/core/N0;

    iget-object v0, v0, Landroidx/camera/core/N0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_27
    iget-object v1, p0, Landroidx/camera/core/N0$c;->a:Landroidx/camera/core/N0;

    iget-object v1, v1, Landroidx/camera/core/N0;->q:Landroidx/camera/core/Z0;

    invoke-virtual {v1}, Landroidx/camera/core/Z0;->e()V

    if-eqz v2, :cond_3d

    if-eqz v3, :cond_3d

    new-instance v1, Landroidx/camera/core/P0;

    invoke-direct {v1, v2, p1}, Landroidx/camera/core/P0;-><init>(Landroidx/camera/core/N0$e;Ljava/lang/Exception;)V

    invoke-interface {v3, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_3d

    :catchall_3b
    move-exception p1

    goto :goto_50

    :cond_3d
    :goto_3d
    monitor-exit v0
    :try_end_3e
    .catchall {:try_start_27 .. :try_end_3e} :catchall_3b

    :goto_3e
    iget-object p1, p0, Landroidx/camera/core/N0$c;->a:Landroidx/camera/core/N0;

    iget-object p1, p1, Landroidx/camera/core/N0;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_43
    iget-object v0, p0, Landroidx/camera/core/N0$c;->a:Landroidx/camera/core/N0;

    const/4 v1, 0x0

    iput-boolean v1, v0, Landroidx/camera/core/N0;->f:Z

    monitor-exit p1
    :try_end_49
    .catchall {:try_start_43 .. :try_end_49} :catchall_4d

    invoke-virtual {v0}, Landroidx/camera/core/N0;->j()V

    :goto_4c
    return-void

    :catchall_4d
    move-exception v0

    :try_start_4e
    monitor-exit p1
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_4d

    throw v0

    :goto_50
    :try_start_50
    monitor-exit v0
    :try_end_51
    .catchall {:try_start_50 .. :try_end_51} :catchall_3b

    throw p1

    :goto_52
    :try_start_52
    monitor-exit p1
    :try_end_53
    .catchall {:try_start_52 .. :try_end_53} :catchall_f

    throw v0
.end method
