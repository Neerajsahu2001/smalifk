.class public final Landroidx/camera/core/e;
.super Ljava/lang/Object;
.source "AspectRatio.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
