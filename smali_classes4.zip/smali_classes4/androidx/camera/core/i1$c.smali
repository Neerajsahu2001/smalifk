.class final Landroidx/camera/core/i1$c;
.super Ljava/lang/Object;
.source "SurfaceRequest.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/i1;-><init>(Landroid/util/Size;Landroidx/camera/core/impl/x;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Landroid/view/Surface;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/util/concurrent/o;

.field final synthetic b:Landroidx/concurrent/futures/b$a;

.field final synthetic c:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/google/common/util/concurrent/o;Landroidx/concurrent/futures/b$a;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/i1$c;->a:Lcom/google/common/util/concurrent/o;

    iput-object p2, p0, Landroidx/camera/core/i1$c;->b:Landroidx/concurrent/futures/b$a;

    iput-object p3, p0, Landroidx/camera/core/i1$c;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 7

    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    const/4 v1, 0x0

    iget-object v2, p0, Landroidx/camera/core/i1$c;->b:Landroidx/concurrent/futures/b$a;

    if-eqz v0, :cond_27

    new-instance v0, Landroidx/camera/core/i1$e;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Landroidx/camera/core/i1$c;->c:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " cancelled."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v2, v0}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    move-result p1

    invoke-static {p1, v1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    goto :goto_2a

    :cond_27
    invoke-virtual {v2, v1}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    :goto_2a
    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Landroid/view/Surface;

    iget-object p1, p0, Landroidx/camera/core/i1$c;->a:Lcom/google/common/util/concurrent/o;

    iget-object v0, p0, Landroidx/camera/core/i1$c;->b:Landroidx/concurrent/futures/b$a;

    invoke-static {p1, v0}, Lv/f;->j(Lcom/google/common/util/concurrent/o;Landroidx/concurrent/futures/b$a;)V

    return-void
.end method
