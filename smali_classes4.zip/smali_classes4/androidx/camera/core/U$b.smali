.class final Landroidx/camera/core/U$b;
.super Landroidx/camera/core/K;
.source "ImageAnalysisNonBlockingAnalyzer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/U;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# instance fields
.field final c:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/camera/core/U;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroidx/camera/core/r0;Landroidx/camera/core/U;)V
    .registers 3

    invoke-direct {p0, p1}, Landroidx/camera/core/K;-><init>(Landroidx/camera/core/r0;)V

    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Landroidx/camera/core/U$b;->c:Ljava/lang/ref/WeakReference;

    new-instance p1, Landroidx/camera/core/V;

    invoke-direct {p1, p0}, Landroidx/camera/core/V;-><init>(Landroidx/camera/core/U$b;)V

    invoke-virtual {p0, p1}, Landroidx/camera/core/K;->c(Landroidx/camera/core/K$a;)V

    return-void
.end method
