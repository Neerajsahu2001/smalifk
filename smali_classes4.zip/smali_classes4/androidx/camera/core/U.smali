.class public final Landroidx/camera/core/u;
.super Ljava/lang/Exception;
.source "CameraUnavailableException.java"
