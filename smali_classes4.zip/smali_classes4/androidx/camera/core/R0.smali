.class public interface abstract Landroidx/camera/core/r0;
.super Ljava/lang/Object;
.source "ImageProxy.java"

# interfaces
.implements Ljava/lang/AutoCloseable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/r0$a;
    }
.end annotation


# virtual methods
.method public abstract B0()[Landroidx/camera/core/r0$a;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ArrayReturn"
        }
    .end annotation
.end method

.method public abstract V0()Landroidx/camera/core/o0;
.end method

.method public abstract c1()Landroid/media/Image;
.end method

.method public abstract getCropRect()Landroid/graphics/Rect;
.end method

.method public abstract getFormat()I
.end method

.method public abstract getHeight()I
.end method

.method public abstract getWidth()I
.end method
