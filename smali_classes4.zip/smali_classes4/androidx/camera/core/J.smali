.class final Landroidx/camera/core/j;
.super Landroidx/camera/core/i1$f;
.source "AutoValue_SurfaceRequest_Result.java"


# instance fields
.field private final a:I

.field private final b:Landroid/view/Surface;


# direct methods
.method constructor <init>(ILandroid/view/Surface;)V
    .registers 3

    invoke-direct {p0}, Landroidx/camera/core/i1$f;-><init>()V

    iput p1, p0, Landroidx/camera/core/j;->a:I

    if-eqz p2, :cond_a

    iput-object p2, p0, Landroidx/camera/core/j;->b:Landroid/view/Surface;

    return-void

    :cond_a
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null surface"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/j;->a:I

    return v0
.end method

.method public final b()Landroid/view/Surface;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/j;->b:Landroid/view/Surface;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Landroidx/camera/core/i1$f;

    const/4 v2, 0x0

    if-eqz v1, :cond_22

    check-cast p1, Landroidx/camera/core/i1$f;

    invoke-virtual {p1}, Landroidx/camera/core/i1$f;->a()I

    move-result v1

    iget v3, p0, Landroidx/camera/core/j;->a:I

    if-ne v3, v1, :cond_20

    iget-object v1, p0, Landroidx/camera/core/j;->b:Landroid/view/Surface;

    invoke-virtual {p1}, Landroidx/camera/core/i1$f;->b()Landroid/view/Surface;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_20

    goto :goto_21

    :cond_20
    const/4 v0, 0x0

    :goto_21
    return v0

    :cond_22
    return v2
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, Landroidx/camera/core/j;->a:I

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int v0, v0, v1

    iget-object v1, p0, Landroidx/camera/core/j;->b:Landroid/view/Surface;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Result{resultCode="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Landroidx/camera/core/j;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", surface="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/camera/core/j;->b:Landroid/view/Surface;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
