.class public final synthetic Landroidx/camera/core/x;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/y;

.field public final synthetic b:Ljava/util/concurrent/Executor;

.field public final synthetic c:J

.field public final synthetic d:Landroidx/concurrent/futures/b$a;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/y;Ljava/util/concurrent/Executor;JLandroidx/concurrent/futures/b$a;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/x;->a:Landroidx/camera/core/y;

    iput-object p2, p0, Landroidx/camera/core/x;->b:Ljava/util/concurrent/Executor;

    iput-wide p3, p0, Landroidx/camera/core/x;->c:J

    iput-object p5, p0, Landroidx/camera/core/x;->d:Landroidx/concurrent/futures/b$a;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget-wide v0, p0, Landroidx/camera/core/x;->c:J

    iget-object v2, p0, Landroidx/camera/core/x;->d:Landroidx/concurrent/futures/b$a;

    iget-object v3, p0, Landroidx/camera/core/x;->a:Landroidx/camera/core/y;

    iget-object v4, p0, Landroidx/camera/core/x;->b:Ljava/util/concurrent/Executor;

    invoke-static {v3, v4, v0, v1, v2}, Landroidx/camera/core/y;->c(Landroidx/camera/core/y;Ljava/util/concurrent/Executor;JLandroidx/concurrent/futures/b$a;)V

    return-void
.end method
