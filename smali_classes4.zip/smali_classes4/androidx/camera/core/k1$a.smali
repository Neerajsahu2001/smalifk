.class public final Landroidx/camera/core/k1$a;
.super Ljava/lang/Object;
.source "UseCaseGroup.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:Landroidx/camera/core/q1;

.field private final b:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/k1$a;->b:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/j1;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/k1$a;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final b()Landroidx/camera/core/k1;
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/k1$a;->b:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    const-string v2, "UseCase must not be empty."

    invoke-static {v1, v2}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    new-instance v1, Landroidx/camera/core/k1;

    iget-object v2, p0, Landroidx/camera/core/k1$a;->a:Landroidx/camera/core/q1;

    invoke-direct {v1, v2, v0}, Landroidx/camera/core/k1;-><init>(Landroidx/camera/core/q1;Ljava/util/ArrayList;)V

    return-object v1
.end method

.method public final c(Landroidx/camera/core/q1;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/core/k1$a;->a:Landroidx/camera/core/q1;

    return-void
.end method
