.class final Landroidx/camera/core/k0$j;
.super Ljava/lang/Object;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "j"
.end annotation


# instance fields
.field final a:I

.field final b:I

.field private final c:Landroid/util/Rational;

.field private final d:Ljava/util/concurrent/Executor;

.field private final e:Landroidx/camera/core/k0$m;

.field f:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private final g:Landroid/graphics/Rect;

.field private final h:Landroid/graphics/Matrix;


# direct methods
.method constructor <init>(IILandroid/util/Rational;Landroid/graphics/Rect;Landroid/graphics/Matrix;Ljava/util/concurrent/ScheduledExecutorService;Landroidx/camera/core/k0$m;)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Landroidx/camera/core/k0$j;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    iput p1, p0, Landroidx/camera/core/k0$j;->a:I

    iput p2, p0, Landroidx/camera/core/k0$j;->b:I

    if-eqz p3, :cond_2b

    invoke-virtual {p3}, Landroid/util/Rational;->isZero()Z

    move-result p1

    const/4 p2, 0x1

    xor-int/2addr p1, p2

    const-string v0, "Target ratio cannot be zero"

    invoke-static {p1, v0}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    invoke-virtual {p3}, Landroid/util/Rational;->floatValue()F

    move-result p1

    const/4 v0, 0x0

    cmpl-float p1, p1, v0

    if-lez p1, :cond_26

    const/4 v1, 0x1

    :cond_26
    const-string p1, "Target ratio must be positive"

    invoke-static {v1, p1}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    :cond_2b
    iput-object p3, p0, Landroidx/camera/core/k0$j;->c:Landroid/util/Rational;

    iput-object p4, p0, Landroidx/camera/core/k0$j;->g:Landroid/graphics/Rect;

    iput-object p5, p0, Landroidx/camera/core/k0$j;->h:Landroid/graphics/Matrix;

    iput-object p6, p0, Landroidx/camera/core/k0$j;->d:Ljava/util/concurrent/Executor;

    iput-object p7, p0, Landroidx/camera/core/k0$j;->e:Landroidx/camera/core/k0$m;

    return-void
.end method

.method public static a(Landroidx/camera/core/k0$j;Landroidx/camera/core/r0;)V
    .registers 13

    iget-object p0, p0, Landroidx/camera/core/k0$j;->e:Landroidx/camera/core/k0$m;

    check-cast p0, Landroidx/camera/core/k0$e;

    iget-object v0, p0, Landroidx/camera/core/k0$e;->f:Landroidx/camera/core/k0;

    iget-object v1, v0, Landroidx/camera/core/k0;->m:Ljava/util/concurrent/Executor;

    new-instance v10, Landroidx/camera/core/x0;

    invoke-interface {p1}, Landroidx/camera/core/r0;->V0()Landroidx/camera/core/o0;

    move-result-object v2

    invoke-interface {v2}, Landroidx/camera/core/o0;->b()I

    move-result v5

    iget-object v8, v0, Landroidx/camera/core/k0;->G:Ljava/util/concurrent/Executor;

    iget v6, p0, Landroidx/camera/core/k0$e;->b:I

    iget-object v7, p0, Landroidx/camera/core/k0$e;->c:Ljava/util/concurrent/Executor;

    iget-object v4, p0, Landroidx/camera/core/k0$e;->a:Landroidx/camera/core/k0$o;

    iget-object v9, p0, Landroidx/camera/core/k0$e;->d:Landroidx/camera/core/x0$b;

    move-object v2, v10

    move-object v3, p1

    invoke-direct/range {v2 .. v9}, Landroidx/camera/core/x0;-><init>(Landroidx/camera/core/r0;Landroidx/camera/core/k0$o;IILjava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Landroidx/camera/core/x0$b;)V

    invoke-interface {v1, v10}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static b(Landroidx/camera/core/k0$j;ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroidx/camera/core/n0;

    invoke-direct {v0, p1, p2, p3}, Landroidx/camera/core/n0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Landroidx/camera/core/k0$j;->e:Landroidx/camera/core/k0$m;

    check-cast p0, Landroidx/camera/core/k0$e;

    iget-object p0, p0, Landroidx/camera/core/k0$e;->e:Landroidx/camera/core/k0$n;

    invoke-interface {p0, v0}, Landroidx/camera/core/k0$n;->a(Landroidx/camera/core/n0;)V

    return-void
.end method


# virtual methods
.method final c(Landroidx/camera/core/r0;)V
    .registers 13

    iget-object v0, p0, Landroidx/camera/core/k0$j;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_10

    check-cast p1, Landroidx/camera/core/a1;

    invoke-virtual {p1}, Landroidx/camera/core/a1;->close()V

    return-void

    :cond_10
    sget-object v0, Landroidx/camera/core/k0;->J:Lz/a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v0, Ly/b;

    invoke-static {v0}, Ly/a;->a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object v0

    check-cast v0, Ly/b;

    if-eqz v0, :cond_22

    sget-object v0, Landroidx/camera/core/impl/D;->h:Landroidx/camera/core/impl/H$a;

    goto :goto_2f

    :cond_22
    move-object v0, p1

    check-cast v0, Landroidx/camera/core/K;

    invoke-virtual {v0}, Landroidx/camera/core/K;->getFormat()I

    move-result v0

    const/16 v3, 0x100

    if-ne v0, v3, :cond_2f

    const/4 v0, 0x1

    goto :goto_30

    :cond_2f
    :goto_2f
    const/4 v0, 0x0

    :goto_30
    iget v3, p0, Landroidx/camera/core/k0$j;->a:I

    if-eqz v0, :cond_79

    :try_start_34
    move-object v0, p1

    check-cast v0, Landroidx/camera/core/K;

    invoke-virtual {v0}, Landroidx/camera/core/K;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v1

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    move-result v1

    new-array v1, v1, [B

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    new-instance v4, Ljava/io/ByteArrayInputStream;

    invoke-direct {v4, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {v4}, Landroidx/camera/core/impl/utils/e;->c(Ljava/io/ByteArrayInputStream;)Landroidx/camera/core/impl/utils/e;

    move-result-object v1

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    new-instance v0, Landroid/util/Size;

    invoke-virtual {v1}, Landroidx/camera/core/impl/utils/e;->g()I

    move-result v4

    invoke-virtual {v1}, Landroidx/camera/core/impl/utils/e;->d()I

    move-result v5

    invoke-direct {v0, v4, v5}, Landroid/util/Size;-><init>(II)V

    invoke-virtual {v1}, Landroidx/camera/core/impl/utils/e;->f()I

    move-result v1
    :try_end_6c
    .catch Ljava/io/IOException; {:try_start_34 .. :try_end_6c} :catch_6d

    goto :goto_8a

    :catch_6d
    move-exception v0

    const-string v1, "Unable to parse JPEG exif"

    invoke-virtual {p0, v2, v1, v0}, Landroidx/camera/core/k0$j;->d(ILjava/lang/String;Ljava/lang/Throwable;)V

    check-cast p1, Landroidx/camera/core/a1;

    invoke-virtual {p1}, Landroidx/camera/core/a1;->close()V

    return-void

    :cond_79
    new-instance v0, Landroid/util/Size;

    move-object v1, p1

    check-cast v1, Landroidx/camera/core/K;

    invoke-virtual {v1}, Landroidx/camera/core/K;->getWidth()I

    move-result v4

    invoke-virtual {v1}, Landroidx/camera/core/K;->getHeight()I

    move-result v1

    invoke-direct {v0, v4, v1}, Landroid/util/Size;-><init>(II)V

    move v1, v3

    :goto_8a
    move-object v4, p1

    check-cast v4, Landroidx/camera/core/K;

    invoke-virtual {v4}, Landroidx/camera/core/K;->V0()Landroidx/camera/core/o0;

    move-result-object v5

    invoke-interface {v5}, Landroidx/camera/core/o0;->d()Landroidx/camera/core/impl/B0;

    move-result-object v5

    invoke-virtual {v4}, Landroidx/camera/core/K;->V0()Landroidx/camera/core/o0;

    move-result-object v4

    invoke-interface {v4}, Landroidx/camera/core/o0;->a()J

    move-result-wide v6

    new-instance v10, Landroidx/camera/core/h;

    iget-object v9, p0, Landroidx/camera/core/k0$j;->h:Landroid/graphics/Matrix;

    move-object v4, v10

    move v8, v1

    invoke-direct/range {v4 .. v9}, Landroidx/camera/core/h;-><init>(Landroidx/camera/core/impl/B0;JILandroid/graphics/Matrix;)V

    new-instance v4, Landroidx/camera/core/Y0;

    invoke-direct {v4, p1, v0, v10}, Landroidx/camera/core/Y0;-><init>(Landroidx/camera/core/r0;Landroid/util/Size;Landroidx/camera/core/o0;)V

    iget-object v5, p0, Landroidx/camera/core/k0$j;->g:Landroid/graphics/Rect;

    iget-object v6, p0, Landroidx/camera/core/k0$j;->c:Landroid/util/Rational;

    invoke-static {v5, v6, v3, v0, v1}, Landroidx/camera/core/k0;->M(Landroid/graphics/Rect;Landroid/util/Rational;ILandroid/util/Size;I)Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/camera/core/Y0;->m(Landroid/graphics/Rect;)V

    :try_start_b6
    iget-object v0, p0, Landroidx/camera/core/k0$j;->d:Ljava/util/concurrent/Executor;

    new-instance v1, Landroidx/camera/core/c;

    invoke-direct {v1, p0, v4, v2}, Landroidx/camera/core/c;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_c0
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_b6 .. :try_end_c0} :catch_c1

    goto :goto_cd

    :catch_c1
    const-string v0, "ImageCapture"

    const-string v1, "Unable to post to the supplied executor."

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    check-cast p1, Landroidx/camera/core/a1;

    invoke-virtual {p1}, Landroidx/camera/core/a1;->close()V

    :goto_cd
    return-void
.end method

.method final d(ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 7

    iget-object v0, p0, Landroidx/camera/core/k0$j;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_b

    return-void

    :cond_b
    :try_start_b
    iget-object v0, p0, Landroidx/camera/core/k0$j;->d:Ljava/util/concurrent/Executor;

    new-instance v1, Landroidx/camera/core/m0;

    invoke-direct {v1, p0, p1, p2, p3}, Landroidx/camera/core/m0;-><init>(Landroidx/camera/core/k0$j;ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_15
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_b .. :try_end_15} :catch_16

    goto :goto_1d

    :catch_16
    const-string p1, "ImageCapture"

    const-string p2, "Unable to post to the supplied executor."

    invoke-static {p1, p2}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1d
    return-void
.end method
