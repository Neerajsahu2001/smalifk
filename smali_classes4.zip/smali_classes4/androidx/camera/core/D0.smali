.class public final synthetic Landroidx/camera/core/d0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroidx/camera/core/d0;->a:I

    iput-object p2, p0, Landroidx/camera/core/d0;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget v0, p0, Landroidx/camera/core/d0;->a:I

    iget-object v1, p0, Landroidx/camera/core/d0;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_40

    check-cast v1, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    sget v0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->o:I

    const-string v0, "this$0"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v0

    const/high16 v2, 0x40000000    # 2.0f

    invoke-static {v0, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v3

    invoke-static {v3, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-virtual {v1, v0, v2}, Landroid/view/View;->measure(II)V

    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v0

    invoke-virtual {v1}, Landroid/view/View;->getTop()I

    move-result v2

    invoke-virtual {v1}, Landroid/view/View;->getRight()I

    move-result v3

    invoke-virtual {v1}, Landroid/view/View;->getBottom()I

    move-result v4

    invoke-virtual {v1, v0, v2, v3, v4}, Landroid/view/View;->layout(IIII)V

    return-void

    :pswitch_39
    check-cast v1, Landroidx/camera/core/X0;

    invoke-virtual {v1}, Landroidx/camera/core/X0;->i()V

    return-void

    nop

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_39
    .end packed-switch
.end method
