.class public final Landroidx/camera/core/y;
.super Ljava/lang/Object;
.source "CameraX.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/y$a;
    }
.end annotation


# static fields
.field private static final n:Ljava/lang/Object;

.field private static final o:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final a:Landroidx/camera/core/impl/y;

.field private final b:Ljava/lang/Object;

.field private final c:Landroidx/camera/core/z;

.field private final d:Ljava/util/concurrent/Executor;

.field private final e:Landroid/os/Handler;

.field private final f:Landroid/os/HandlerThread;

.field private g:Landroidx/camera/core/impl/v;

.field private h:Landroidx/camera/core/impl/u;

.field private i:Landroidx/camera/core/impl/F0;

.field private j:Landroid/content/Context;

.field private final k:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private l:Landroidx/camera/core/y$a;

.field private m:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/core/y;->n:Ljava/lang/Object;

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    sput-object v0, Landroidx/camera/core/y;->o:Landroid/util/SparseArray;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/camera/core/impl/y;

    invoke-direct {v0}, Landroidx/camera/core/impl/y;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/y;->a:Landroidx/camera/core/impl/y;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/y;->b:Ljava/lang/Object;

    sget-object v0, Landroidx/camera/core/y$a;->UNINITIALIZED:Landroidx/camera/core/y$a;

    iput-object v0, p0, Landroidx/camera/core/y;->l:Landroidx/camera/core/y$a;

    const/4 v0, 0x0

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/y;->m:Lcom/google/common/util/concurrent/o;

    const-string v1, "CameraX"

    invoke-static {p1}, Landroidx/camera/core/impl/utils/d;->b(Landroid/content/Context;)Landroid/app/Application;

    move-result-object v2

    instance-of v3, v2, Landroidx/camera/core/z$b;

    if-eqz v3, :cond_29

    check-cast v2, Landroidx/camera/core/z$b;

    goto :goto_7b

    :cond_29
    :try_start_29
    invoke-static {p1}, Landroidx/camera/core/impl/utils/d;->a(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    new-instance v4, Landroid/content/ComponentName;

    const-class v5, Landroidx/camera/core/impl/MetadataHolderService;

    invoke-direct {v4, v2, v5}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v2, 0x280

    invoke-virtual {v3, v4, v2}, Landroid/content/pm/PackageManager;->getServiceInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ServiceInfo;

    move-result-object v2

    iget-object v2, v2, Landroid/content/pm/ServiceInfo;->metaData:Landroid/os/Bundle;

    if-eqz v2, :cond_57

    const-string v3, "androidx.camera.core.impl.MetadataHolderService.DEFAULT_CONFIG_PROVIDER"

    invoke-virtual {v2, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_58

    :catch_49
    move-exception v2

    goto :goto_75

    :catch_4b
    move-exception v2

    goto :goto_75

    :catch_4d
    move-exception v2

    goto :goto_75

    :catch_4f
    move-exception v2

    goto :goto_75

    :catch_51
    move-exception v2

    goto :goto_75

    :catch_53
    move-exception v2

    goto :goto_75

    :catch_55
    move-exception v2

    goto :goto_75

    :cond_57
    move-object v2, v0

    :goto_58
    if-nez v2, :cond_61

    const-string v2, "No default CameraXConfig.Provider specified in meta-data. The most likely cause is you did not include a default implementation in your build such as \'camera-camera2\'."

    invoke-static {v1, v2}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    :goto_5f
    move-object v2, v0

    goto :goto_7b

    :cond_61
    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v3, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    new-array v3, v3, [Ljava/lang/Object;

    invoke-virtual {v2, v3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/z$b;
    :try_end_74
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_29 .. :try_end_74} :catch_55
    .catch Ljava/lang/ClassNotFoundException; {:try_start_29 .. :try_end_74} :catch_53
    .catch Ljava/lang/InstantiationException; {:try_start_29 .. :try_end_74} :catch_51
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_29 .. :try_end_74} :catch_4f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_29 .. :try_end_74} :catch_4d
    .catch Ljava/lang/IllegalAccessException; {:try_start_29 .. :try_end_74} :catch_4b
    .catch Ljava/lang/NullPointerException; {:try_start_29 .. :try_end_74} :catch_49

    goto :goto_7b

    :goto_75
    const-string v3, "Failed to retrieve default CameraXConfig.Provider from meta-data"

    invoke-static {v1, v3, v2}, Landroidx/camera/core/A0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_5f

    :goto_7b
    if-eqz v2, :cond_138

    invoke-interface {v2}, Landroidx/camera/core/z$b;->getCameraXConfig()Landroidx/camera/core/z;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/y;->c:Landroidx/camera/core/z;

    invoke-virtual {v1}, Landroidx/camera/core/z;->D()Ljava/util/concurrent/Executor;

    move-result-object v2

    invoke-virtual {v1}, Landroidx/camera/core/z;->G()Landroid/os/Handler;

    move-result-object v3

    if-nez v2, :cond_92

    new-instance v2, Landroidx/camera/core/p;

    invoke-direct {v2}, Landroidx/camera/core/p;-><init>()V

    :cond_92
    iput-object v2, p0, Landroidx/camera/core/y;->d:Ljava/util/concurrent/Executor;

    if-nez v3, :cond_ad

    new-instance v2, Landroid/os/HandlerThread;

    const-string v3, "CameraX-scheduler"

    const/16 v4, 0xa

    invoke-direct {v2, v3, v4}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    invoke-virtual {v2}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-static {v2}, Landroidx/core/os/k;->a(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object v2

    iput-object v2, p0, Landroidx/camera/core/y;->e:Landroid/os/Handler;

    goto :goto_af

    :cond_ad
    iput-object v3, p0, Landroidx/camera/core/y;->e:Landroid/os/Handler;

    :goto_af
    sget-object v2, Landroidx/camera/core/z;->D:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Landroidx/camera/core/z;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/o0;

    invoke-virtual {v1, v2, v0}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    sget-object v1, Landroidx/camera/core/y;->n:Ljava/lang/Object;

    monitor-enter v1

    if-nez v0, :cond_c9

    :try_start_c5
    monitor-exit v1

    goto :goto_12f

    :catchall_c7
    move-exception p1

    goto :goto_136

    :cond_c9
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const-string v3, "minLogLevel"

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v2, v5, v3, v4}, Landroidx/core/util/g;->d(IILjava/lang/String;I)V

    sget-object v2, Landroidx/camera/core/y;->o:Landroid/util/SparseArray;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    if-eqz v3, :cond_f0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    add-int/2addr v6, v3

    :cond_f0
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v0, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v0

    if-nez v0, :cond_105

    invoke-static {}, Landroidx/camera/core/A0;->h()V

    goto :goto_12e

    :cond_105
    invoke-virtual {v2, v5}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_10f

    invoke-static {v5}, Landroidx/camera/core/A0;->i(I)V

    goto :goto_12e

    :cond_10f
    const/4 v0, 0x4

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_11a

    invoke-static {v0}, Landroidx/camera/core/A0;->i(I)V

    goto :goto_12e

    :cond_11a
    const/4 v0, 0x5

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_125

    invoke-static {v0}, Landroidx/camera/core/A0;->i(I)V

    goto :goto_12e

    :cond_125
    invoke-virtual {v2, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_12e

    invoke-static {v4}, Landroidx/camera/core/A0;->i(I)V

    :cond_12e
    :goto_12e
    monitor-exit v1
    :try_end_12f
    .catchall {:try_start_c5 .. :try_end_12f} :catchall_c7

    :goto_12f
    invoke-direct {p0, p1}, Landroidx/camera/core/y;->h(Landroid/content/Context;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/y;->k:Lcom/google/common/util/concurrent/o;

    return-void

    :goto_136
    :try_start_136
    monitor-exit v1
    :try_end_137
    .catchall {:try_start_136 .. :try_end_137} :catchall_c7

    throw p1

    :cond_138
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "CameraX is not configured properly. The most likely cause is you did not include a default implementation in your build such as \'camera-camera2\'."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static a(Landroidx/camera/core/y;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/b$a;J)V
    .registers 13

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    :try_start_4
    invoke-static {p1}, Landroidx/camera/core/impl/utils/d;->b(Landroid/content/Context;)Landroid/app/Application;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/y;->j:Landroid/content/Context;

    if-nez v1, :cond_1c

    invoke-static {p1}, Landroidx/camera/core/impl/utils/d;->a(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/y;->j:Landroid/content/Context;

    goto :goto_1c

    :catch_13
    move-exception p1

    goto/16 :goto_af

    :catch_16
    move-exception p1

    goto/16 :goto_af

    :catch_19
    move-exception p1

    goto/16 :goto_af

    :cond_1c
    :goto_1c
    iget-object p1, p0, Landroidx/camera/core/y;->c:Landroidx/camera/core/z;

    invoke-virtual {p1}, Landroidx/camera/core/z;->E()Landroidx/camera/core/impl/v$a;

    move-result-object p1

    if-eqz p1, :cond_a2

    iget-object v1, p0, Landroidx/camera/core/y;->d:Ljava/util/concurrent/Executor;

    iget-object v2, p0, Landroidx/camera/core/y;->e:Landroid/os/Handler;

    invoke-static {v1, v2}, Landroidx/camera/core/impl/A;->a(Ljava/util/concurrent/Executor;Landroid/os/Handler;)Landroidx/camera/core/impl/A;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/y;->c:Landroidx/camera/core/z;

    invoke-virtual {v2}, Landroidx/camera/core/z;->C()Landroidx/camera/core/s;

    move-result-object v2

    iget-object v3, p0, Landroidx/camera/core/y;->j:Landroid/content/Context;

    invoke-interface {p1, v3, v1, v2}, Landroidx/camera/core/impl/v$a;->a(Landroid/content/Context;Landroidx/camera/core/impl/A;Landroidx/camera/core/s;)Landroidx/camera/camera2/internal/v;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/y;->g:Landroidx/camera/core/impl/v;

    iget-object p1, p0, Landroidx/camera/core/y;->c:Landroidx/camera/core/z;

    invoke-virtual {p1}, Landroidx/camera/core/z;->F()Landroidx/camera/core/impl/u$a;

    move-result-object p1

    if-eqz p1, :cond_95

    iget-object v1, p0, Landroidx/camera/core/y;->j:Landroid/content/Context;

    iget-object v3, p0, Landroidx/camera/core/y;->g:Landroidx/camera/core/impl/v;

    invoke-interface {v3}, Landroidx/camera/core/impl/v;->c()Ljava/lang/Object;

    move-result-object v3

    iget-object v4, p0, Landroidx/camera/core/y;->g:Landroidx/camera/core/impl/v;

    invoke-interface {v4}, Landroidx/camera/core/impl/v;->b()Ljava/util/LinkedHashSet;

    move-result-object v4

    invoke-interface {p1, v1, v3, v4}, Landroidx/camera/core/impl/u$a;->a(Landroid/content/Context;Ljava/lang/Object;Ljava/util/Set;)Landroidx/camera/camera2/internal/c0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/y;->h:Landroidx/camera/core/impl/u;

    iget-object p1, p0, Landroidx/camera/core/y;->c:Landroidx/camera/core/z;

    invoke-virtual {p1}, Landroidx/camera/core/z;->H()Landroidx/camera/core/impl/F0$c;

    move-result-object p1

    if-eqz p1, :cond_88

    iget-object v1, p0, Landroidx/camera/core/y;->j:Landroid/content/Context;

    invoke-interface {p1, v1}, Landroidx/camera/core/impl/F0$c;->a(Landroid/content/Context;)Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/y;->i:Landroidx/camera/core/impl/F0;

    instance-of p1, p2, Landroidx/camera/core/p;

    if-eqz p1, :cond_72

    move-object p1, p2

    check-cast p1, Landroidx/camera/core/p;

    iget-object v1, p0, Landroidx/camera/core/y;->g:Landroidx/camera/core/impl/v;

    invoke-virtual {p1, v1}, Landroidx/camera/core/p;->a(Landroidx/camera/core/impl/v;)V

    :cond_72
    iget-object p1, p0, Landroidx/camera/core/y;->a:Landroidx/camera/core/impl/y;

    iget-object v1, p0, Landroidx/camera/core/y;->g:Landroidx/camera/core/impl/v;

    invoke-virtual {p1, v1}, Landroidx/camera/core/impl/y;->b(Landroidx/camera/core/impl/v;)V

    iget-object p1, p0, Landroidx/camera/core/y;->j:Landroid/content/Context;

    iget-object v1, p0, Landroidx/camera/core/y;->a:Landroidx/camera/core/impl/y;

    invoke-static {p1, v1, v2}, Landroidx/camera/core/impl/B;->a(Landroid/content/Context;Landroidx/camera/core/impl/y;Landroidx/camera/core/s;)V

    invoke-direct {p0}, Landroidx/camera/core/y;->i()V

    invoke-virtual {p3, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    goto/16 :goto_110

    :cond_88
    new-instance p1, Landroidx/camera/core/z0;

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Invalid app configuration provided. Missing UseCaseConfigFactory."

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {p1, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_95
    new-instance p1, Landroidx/camera/core/z0;

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Invalid app configuration provided. Missing CameraDeviceSurfaceManager."

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {p1, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_a2
    new-instance p1, Landroidx/camera/core/z0;

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Invalid app configuration provided. Missing CameraFactory."

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {p1, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p1
    :try_end_af
    .catch Landroidx/camera/core/impl/B$a; {:try_start_4 .. :try_end_af} :catch_19
    .catch Landroidx/camera/core/z0; {:try_start_4 .. :try_end_af} :catch_16
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_af} :catch_13

    :goto_af
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    sub-long/2addr v1, p4

    const-wide/16 v3, 0x9c4

    cmp-long v5, v1, v3

    if-gez v5, :cond_e9

    const-string v0, "CameraX"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Retry init. Start time "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, " current time "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, p1}, Landroidx/camera/core/A0;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p1, p0, Landroidx/camera/core/y;->e:Landroid/os/Handler;

    new-instance v6, Landroidx/camera/core/x;

    move-object v0, v6

    move-object v1, p0

    move-object v2, p2

    move-wide v3, p4

    move-object v5, p3

    invoke-direct/range {v0 .. v5}, Landroidx/camera/core/x;-><init>(Landroidx/camera/core/y;Ljava/util/concurrent/Executor;JLandroidx/concurrent/futures/b$a;)V

    invoke-static {p1, v6}, Landroidx/core/os/k;->b(Landroid/os/Handler;Ljava/lang/Runnable;)V

    goto :goto_110

    :cond_e9
    iget-object p2, p0, Landroidx/camera/core/y;->b:Ljava/lang/Object;

    monitor-enter p2

    :try_start_ec
    sget-object p4, Landroidx/camera/core/y$a;->INITIALIZING_ERROR:Landroidx/camera/core/y$a;

    iput-object p4, p0, Landroidx/camera/core/y;->l:Landroidx/camera/core/y$a;

    monitor-exit p2
    :try_end_f1
    .catchall {:try_start_ec .. :try_end_f1} :catchall_111

    instance-of p0, p1, Landroidx/camera/core/impl/B$a;

    if-eqz p0, :cond_100

    const-string p0, "CameraX"

    const-string p1, "The device might underreport the amount of the cameras. Finish the initialize task since we are already reaching the maximum number of retries."

    invoke-static {p0, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p3, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    goto :goto_110

    :cond_100
    instance-of p0, p1, Landroidx/camera/core/z0;

    if-eqz p0, :cond_108

    invoke-virtual {p3, p1}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    goto :goto_110

    :cond_108
    new-instance p0, Landroidx/camera/core/z0;

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    invoke-virtual {p3, p0}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    :goto_110
    return-void

    :catchall_111
    move-exception p0

    :try_start_112
    monitor-exit p2
    :try_end_113
    .catchall {:try_start_112 .. :try_end_113} :catchall_111

    throw p0
.end method

.method public static b(Landroidx/camera/core/y;Landroid/content/Context;Landroidx/concurrent/futures/b$a;)V
    .registers 12

    iget-object v7, p0, Landroidx/camera/core/y;->d:Ljava/util/concurrent/Executor;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    new-instance v8, Landroidx/camera/core/w;

    move-object v0, v8

    move-object v1, p0

    move-object v2, p1

    move-object v3, v7

    move-object v4, p2

    invoke-direct/range {v0 .. v6}, Landroidx/camera/core/w;-><init>(Landroidx/camera/core/y;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/b$a;J)V

    invoke-interface {v7, v8}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static c(Landroidx/camera/core/y;Ljava/util/concurrent/Executor;JLandroidx/concurrent/futures/b$a;)V
    .registers 13

    iget-object v2, p0, Landroidx/camera/core/y;->j:Landroid/content/Context;

    new-instance v7, Landroidx/camera/core/w;

    move-object v0, v7

    move-object v1, p0

    move-object v3, p1

    move-object v4, p4

    move-wide v5, p2

    invoke-direct/range {v0 .. v6}, Landroidx/camera/core/w;-><init>(Landroidx/camera/core/y;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/b$a;J)V

    invoke-interface {p1, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private h(Landroid/content/Context;)Lcom/google/common/util/concurrent/o;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/y;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/y;->l:Landroidx/camera/core/y$a;

    sget-object v2, Landroidx/camera/core/y$a;->UNINITIALIZED:Landroidx/camera/core/y$a;

    if-ne v1, v2, :cond_b

    const/4 v1, 0x1

    goto :goto_c

    :cond_b
    const/4 v1, 0x0

    :goto_c
    const-string v2, "CameraX.initInternal() should only be called once per instance"

    invoke-static {v1, v2}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    sget-object v1, Landroidx/camera/core/y$a;->INITIALIZING:Landroidx/camera/core/y$a;

    iput-object v1, p0, Landroidx/camera/core/y;->l:Landroidx/camera/core/y$a;

    new-instance v1, Landroidx/camera/core/v;

    invoke-direct {v1, p1, p0}, Landroidx/camera/core/v;-><init>(Landroid/content/Context;Landroidx/camera/core/y;)V

    invoke-static {v1}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    monitor-exit v0

    return-object p1

    :catchall_20
    move-exception p1

    monitor-exit v0
    :try_end_22
    .catchall {:try_start_3 .. :try_end_22} :catchall_20

    throw p1
.end method

.method private i()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/y;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    sget-object v1, Landroidx/camera/core/y$a;->INITIALIZED:Landroidx/camera/core/y$a;

    iput-object v1, p0, Landroidx/camera/core/y;->l:Landroidx/camera/core/y$a;

    monitor-exit v0

    return-void

    :catchall_9
    move-exception v1

    monitor-exit v0
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_9

    throw v1
.end method


# virtual methods
.method public final d()Landroidx/camera/core/impl/u;
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/y;->h:Landroidx/camera/core/impl/u;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "CameraX not initialized yet."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final e()Landroidx/camera/core/impl/y;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/y;->a:Landroidx/camera/core/impl/y;

    return-object v0
.end method

.method public final f()Landroidx/camera/core/impl/F0;
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/y;->i:Landroidx/camera/core/impl/F0;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "CameraX not initialized yet."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final g()Lcom/google/common/util/concurrent/o;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/y;->k:Lcom/google/common/util/concurrent/o;

    return-object v0
.end method
