.class final Landroidx/camera/core/C0$a;
.super Landroidx/camera/core/impl/g;
.source "MetadataImageReader.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/C0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/C0;


# direct methods
.method constructor <init>(Landroidx/camera/core/C0;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/core/C0$a;->a:Landroidx/camera/core/C0;

    invoke-direct {p0}, Landroidx/camera/core/impl/g;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Landroidx/camera/core/impl/o;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/C0$a;->a:Landroidx/camera/core/C0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/C0;->o(Landroidx/camera/core/impl/o;)V

    return-void
.end method
