.class public final Landroidx/camera/core/p1$b;
.super Ljava/lang/Object;
.source "VideoCapture.java"

# interfaces
.implements Landroidx/camera/core/impl/E0$a;
.implements Landroidx/camera/core/impl/Z$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/p1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/camera/core/impl/E0$a<",
        "Landroidx/camera/core/p1;",
        "Landroidx/camera/core/impl/G0;",
        "Landroidx/camera/core/p1$b;",
        ">;",
        "Landroidx/camera/core/impl/Z$a<",
        "Landroidx/camera/core/p1$b;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/k0;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    invoke-direct {p0, v0}, Landroidx/camera/core/p1$b;-><init>(Landroidx/camera/core/impl/k0;)V

    return-void
.end method

.method private constructor <init>(Landroidx/camera/core/impl/k0;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    sget-object v0, Lw/h;->u:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    :try_start_8
    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_f

    :catch_d
    nop

    move-object p1, v1

    :goto_f
    check-cast p1, Ljava/lang/Class;

    const-class v0, Landroidx/camera/core/p1;

    if-eqz p1, :cond_38

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1c

    goto :goto_38

    :cond_1c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid target class configuration for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_38
    :goto_38
    sget-object p1, Lw/h;->u:Landroidx/camera/core/impl/H$a;

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, p1, v0}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    sget-object p1, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    :try_start_41
    invoke-virtual {v2, p1}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v1
    :try_end_45
    .catch Ljava/lang/IllegalArgumentException; {:try_start_41 .. :try_end_45} :catch_46

    goto :goto_47

    :catch_46
    nop

    :goto_47
    if-nez v1, :cond_6a

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "-"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object v0, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v2, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    :cond_6a
    return-void
.end method

.method static f(Landroidx/camera/core/impl/H;)Landroidx/camera/core/p1$b;
    .registers 2

    new-instance v0, Landroidx/camera/core/p1$b;

    invoke-static {p0}, Landroidx/camera/core/impl/k0;->F(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/k0;

    move-result-object p0

    invoke-direct {v0, p0}, Landroidx/camera/core/p1$b;-><init>(Landroidx/camera/core/impl/k0;)V

    return-object v0
.end method


# virtual methods
.method public final a()Landroidx/camera/core/impl/j0;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    return-object v0
.end method

.method public final b(I)Ljava/lang/Object;
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->g:Landroidx/camera/core/impl/H$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-object v1, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-object p0
.end method

.method public final c(Landroid/util/Size;)Ljava/lang/Object;
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->i:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-object p0
.end method

.method public final bridge synthetic d()Landroidx/camera/core/impl/E0;
    .registers 2

    invoke-virtual {p0}, Landroidx/camera/core/p1$b;->g()Landroidx/camera/core/impl/G0;

    move-result-object v0

    return-object v0
.end method

.method public final e()Landroidx/camera/core/p1;
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->f:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    :try_start_8
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_d

    goto :goto_f

    :catch_d
    nop

    move-object v0, v2

    :goto_f
    if-eqz v0, :cond_27

    sget-object v0, Landroidx/camera/core/impl/Z;->i:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_16
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v2
    :try_end_1a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_16 .. :try_end_1a} :catch_1b

    goto :goto_1c

    :catch_1b
    nop

    :goto_1c
    if-nez v2, :cond_1f

    goto :goto_27

    :cond_1f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_27
    :goto_27
    new-instance v0, Landroidx/camera/core/p1;

    invoke-virtual {p0}, Landroidx/camera/core/p1$b;->g()Landroidx/camera/core/impl/G0;

    move-result-object v1

    invoke-direct {v0, v1}, Landroidx/camera/core/p1;-><init>(Landroidx/camera/core/impl/G0;)V

    return-object v0
.end method

.method public final g()Landroidx/camera/core/impl/G0;
    .registers 3

    new-instance v0, Landroidx/camera/core/impl/G0;

    iget-object v1, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-static {v1}, Landroidx/camera/core/impl/o0;->D(Landroidx/camera/core/impl/j0;)Landroidx/camera/core/impl/o0;

    move-result-object v1

    invoke-direct {v0, v1}, Landroidx/camera/core/impl/G0;-><init>(Landroidx/camera/core/impl/o0;)V

    return-object v0
.end method

.method public final h()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/G0;->B:Landroidx/camera/core/impl/H$a;

    const v1, 0xfa00

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final i()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/G0;->D:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final j()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/G0;->E:Landroidx/camera/core/impl/H$a;

    const/16 v1, 0x400

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final k()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/G0;->C:Landroidx/camera/core/impl/H$a;

    const/16 v1, 0x1f40

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final l()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/G0;->z:Landroidx/camera/core/impl/H$a;

    const/high16 v1, 0x800000

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final m()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/G0;->A:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final n(Landroid/util/Size;)V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->k:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final o()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/E0;->q:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final p()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/Z;->f:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final q()V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/G0;->y:Landroidx/camera/core/impl/H$a;

    const/16 v1, 0x1e

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/core/p1$b;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method
