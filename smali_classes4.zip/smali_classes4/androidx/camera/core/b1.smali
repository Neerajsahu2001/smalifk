.class public final Landroidx/camera/core/b1;
.super Landroidx/camera/core/E0;
.source "SurfaceOrientedMeteringPointFactory.java"


# virtual methods
.method protected final a()Landroid/graphics/PointF;
    .registers 3

    new-instance v0, Landroid/graphics/PointF;

    const/high16 v1, 0x3f000000    # 0.5f

    invoke-direct {v0, v1, v1}, Landroid/graphics/PointF;-><init>(FF)V

    return-object v0
.end method
