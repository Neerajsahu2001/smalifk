.class public interface abstract Landroidx/camera/core/o0;
.super Ljava/lang/Object;
.source "ImageInfo.java"


# virtual methods
.method public abstract a()J
.end method

.method public abstract b()I
.end method

.method public abstract c(Landroidx/camera/core/impl/utils/g$b;)V
.end method

.method public abstract d()Landroidx/camera/core/impl/B0;
.end method
