.class abstract Landroidx/camera/core/y0;
.super Ljava/lang/Object;
.source "ImmutableImageInfo.java"

# interfaces
.implements Landroidx/camera/core/o0;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Landroidx/camera/core/impl/utils/g$b;)V
    .registers 3

    move-object v0, p0

    check-cast v0, Landroidx/camera/core/h;

    invoke-virtual {v0}, Landroidx/camera/core/h;->b()I

    move-result v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/g$b;->m(I)V

    return-void
.end method
