.class public final synthetic Landroidx/camera/core/e0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/impl/u0$c;


# instance fields
.field public final synthetic a:Landroidx/camera/core/k0;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Landroidx/camera/core/impl/V;

.field public final synthetic d:Landroid/util/Size;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/k0;Ljava/lang/String;Landroidx/camera/core/impl/V;Landroid/util/Size;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/e0;->a:Landroidx/camera/core/k0;

    iput-object p2, p0, Landroidx/camera/core/e0;->b:Ljava/lang/String;

    iput-object p3, p0, Landroidx/camera/core/e0;->c:Landroidx/camera/core/impl/V;

    iput-object p4, p0, Landroidx/camera/core/e0;->d:Landroid/util/Size;

    return-void
.end method


# virtual methods
.method public final onError()V
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/e0;->a:Landroidx/camera/core/k0;

    invoke-virtual {v0}, Landroidx/camera/core/k0;->L()V

    iget-object v1, p0, Landroidx/camera/core/e0;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroidx/camera/core/j1;->o(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_21

    iget-object v2, p0, Landroidx/camera/core/e0;->c:Landroidx/camera/core/impl/V;

    iget-object v3, p0, Landroidx/camera/core/e0;->d:Landroid/util/Size;

    invoke-virtual {v0, v1, v2, v3}, Landroidx/camera/core/k0;->N(Ljava/lang/String;Landroidx/camera/core/impl/V;Landroid/util/Size;)Landroidx/camera/core/impl/u0$b;

    move-result-object v1

    iput-object v1, v0, Landroidx/camera/core/k0;->z:Landroidx/camera/core/impl/u0$b;

    invoke-virtual {v1}, Landroidx/camera/core/impl/u0$b;->k()Landroidx/camera/core/impl/u0;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/camera/core/j1;->I(Landroidx/camera/core/impl/u0;)V

    invoke-virtual {v0}, Landroidx/camera/core/j1;->s()V

    :cond_21
    return-void
.end method
