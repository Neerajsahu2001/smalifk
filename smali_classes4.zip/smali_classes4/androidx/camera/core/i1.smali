.class public final Landroidx/camera/core/i1;
.super Ljava/lang/Object;
.source "SurfaceRequest.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/i1$g;,
        Landroidx/camera/core/i1$f;,
        Landroidx/camera/core/i1$h;,
        Landroidx/camera/core/i1$e;
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/Object;

.field private final b:Landroid/util/Size;

.field private final c:Z

.field private final d:Landroidx/camera/core/impl/x;

.field final e:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Landroid/view/Surface;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Landroidx/concurrent/futures/b$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/concurrent/futures/b$a<",
            "Landroid/view/Surface;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private final h:Landroidx/concurrent/futures/b$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/concurrent/futures/b$a<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private final i:Landroidx/camera/core/impl/K;

.field private j:Landroidx/camera/core/i1$g;

.field private k:Landroidx/camera/core/i1$h;

.field private l:Ljava/util/concurrent/Executor;


# direct methods
.method public constructor <init>(Landroid/util/Size;Landroidx/camera/core/impl/x;Z)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/i1;->a:Ljava/lang/Object;

    iput-object p1, p0, Landroidx/camera/core/i1;->b:Landroid/util/Size;

    iput-object p2, p0, Landroidx/camera/core/i1;->d:Landroidx/camera/core/impl/x;

    iput-boolean p3, p0, Landroidx/camera/core/i1;->c:Z

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "SurfaceRequest[size: "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p3, ", id: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, "]"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    new-instance p3, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-direct {p3, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    new-instance v1, Landroidx/camera/core/d1;

    invoke-direct {v1, p3, p2}, Landroidx/camera/core/d1;-><init>(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/String;)V

    invoke-static {v1}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v1

    invoke-virtual {p3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroidx/concurrent/futures/b$a;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p3, p0, Landroidx/camera/core/i1;->h:Landroidx/concurrent/futures/b$a;

    new-instance v2, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v2, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    new-instance v3, Landroidx/camera/core/e1;

    const/4 v4, 0x0

    invoke-direct {v3, v2, p2, v4}, Landroidx/camera/core/e1;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v3}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v3

    iput-object v3, p0, Landroidx/camera/core/i1;->g:Lcom/google/common/util/concurrent/o;

    new-instance v4, Landroidx/camera/core/i1$a;

    invoke-direct {v4, p3, v1}, Landroidx/camera/core/i1$a;-><init>(Landroidx/concurrent/futures/b$a;Lcom/google/common/util/concurrent/o;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p3

    invoke-static {v3, v4, p3}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroidx/concurrent/futures/b$a;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    new-instance v0, Landroidx/camera/core/f1;

    invoke-direct {v0, v1, p2}, Landroidx/camera/core/f1;-><init>(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/i1;->e:Lcom/google/common/util/concurrent/o;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/concurrent/futures/b$a;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v1, p0, Landroidx/camera/core/i1;->f:Landroidx/concurrent/futures/b$a;

    new-instance v1, Landroidx/camera/core/i1$b;

    invoke-direct {v1, p0, p1}, Landroidx/camera/core/i1$b;-><init>(Landroidx/camera/core/i1;Landroid/util/Size;)V

    iput-object v1, p0, Landroidx/camera/core/i1;->i:Landroidx/camera/core/impl/K;

    invoke-virtual {v1}, Landroidx/camera/core/impl/K;->i()Lcom/google/common/util/concurrent/o;

    move-result-object p1

    new-instance v1, Landroidx/camera/core/i1$c;

    invoke-direct {v1, p1, p3, p2}, Landroidx/camera/core/i1$c;-><init>(Lcom/google/common/util/concurrent/o;Landroidx/concurrent/futures/b$a;Ljava/lang/String;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p2

    invoke-static {v0, v1, p2}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    new-instance p2, Landroidx/camera/core/g1;

    invoke-direct {p2, p0}, Landroidx/camera/core/g1;-><init>(Landroidx/camera/core/i1;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p3

    invoke-interface {p1, p2, p3}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public static a(Landroidx/core/util/a;Landroid/view/Surface;)V
    .registers 4

    new-instance v0, Landroidx/camera/core/j;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p1}, Landroidx/camera/core/j;-><init>(ILandroid/view/Surface;)V

    invoke-interface {p0, v0}, Landroidx/core/util/a;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method public static b(Landroidx/core/util/a;Landroid/view/Surface;)V
    .registers 4

    new-instance v0, Landroidx/camera/core/j;

    const/4 v1, 0x3

    invoke-direct {v0, v1, p1}, Landroidx/camera/core/j;-><init>(ILandroid/view/Surface;)V

    invoke-interface {p0, v0}, Landroidx/core/util/a;->accept(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    .registers 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PairedRegistration"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/i1;->h:Landroidx/concurrent/futures/b$a;

    invoke-virtual {v0, p1, p2}, Landroidx/concurrent/futures/b$a;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public final d()Landroidx/camera/core/impl/x;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/i1;->d:Landroidx/camera/core/impl/x;

    return-object v0
.end method

.method public final e()Landroidx/camera/core/impl/K;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/i1;->i:Landroidx/camera/core/impl/K;

    return-object v0
.end method

.method public final f()Landroid/util/Size;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/i1;->b:Landroid/util/Size;

    return-object v0
.end method

.method public final g()Z
    .registers 2

    iget-boolean v0, p0, Landroidx/camera/core/i1;->c:Z

    return v0
.end method

.method public final h(Landroid/view/Surface;Ljava/util/concurrent/Executor;Landroidx/core/util/a;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/Surface;",
            "Ljava/util/concurrent/Executor;",
            "Landroidx/core/util/a<",
            "Landroidx/camera/core/i1$f;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/i1;->f:Landroidx/concurrent/futures/b$a;

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2f

    iget-object v0, p0, Landroidx/camera/core/i1;->e:Lcom/google/common/util/concurrent/o;

    invoke-interface {v0}, Ljava/util/concurrent/Future;->isCancelled()Z

    move-result v1

    if-eqz v1, :cond_11

    goto :goto_2f

    :cond_11
    invoke-interface {v0}, Ljava/util/concurrent/Future;->isDone()Z

    move-result v1

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    const/4 v1, 0x1

    :try_start_1a
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    new-instance v0, Lt/e;

    invoke-direct {v0, p3, p1, v1}, Lt/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_25
    .catch Ljava/lang/InterruptedException; {:try_start_1a .. :try_end_25} :catch_26
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_1a .. :try_end_25} :catch_26

    goto :goto_39

    :catch_26
    new-instance v0, Lt/f;

    invoke-direct {v0, p3, p1, v1}, Lt/f;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_39

    :cond_2f
    :goto_2f
    new-instance v0, Landroidx/camera/core/i1$d;

    invoke-direct {v0, p3, p1}, Landroidx/camera/core/i1$d;-><init>(Landroidx/core/util/a;Landroid/view/Surface;)V

    iget-object p1, p0, Landroidx/camera/core/i1;->g:Lcom/google/common/util/concurrent/o;

    invoke-static {p1, v0, p2}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    :goto_39
    return-void
.end method

.method public final i(Ljava/util/concurrent/Executor;Landroidx/camera/view/m;)V
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/i1;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iput-object p2, p0, Landroidx/camera/core/i1;->k:Landroidx/camera/core/i1$h;

    iput-object p1, p0, Landroidx/camera/core/i1;->l:Ljava/util/concurrent/Executor;

    iget-object v1, p0, Landroidx/camera/core/i1;->j:Landroidx/camera/core/i1$g;

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_3 .. :try_end_a} :catchall_15

    if-eqz v1, :cond_14

    new-instance v0, Landroidx/camera/core/h1;

    invoke-direct {v0, p2, v1}, Landroidx/camera/core/h1;-><init>(Landroidx/camera/view/m;Landroidx/camera/core/i1$g;)V

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_14
    return-void

    :catchall_15
    move-exception p1

    :try_start_16
    monitor-exit v0
    :try_end_17
    .catchall {:try_start_16 .. :try_end_17} :catchall_15

    throw p1
.end method

.method public final j(Landroidx/camera/core/i1$g;)V
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/i1;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iput-object p1, p0, Landroidx/camera/core/i1;->j:Landroidx/camera/core/i1$g;

    iget-object v1, p0, Landroidx/camera/core/i1;->k:Landroidx/camera/core/i1$h;

    iget-object v2, p0, Landroidx/camera/core/i1;->l:Ljava/util/concurrent/Executor;

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_3 .. :try_end_a} :catchall_17

    if-eqz v1, :cond_16

    if-eqz v2, :cond_16

    new-instance v0, Landroidx/camera/core/c1;

    invoke-direct {v0, v1, p1}, Landroidx/camera/core/c1;-><init>(Landroidx/camera/core/i1$h;Landroidx/camera/core/i1$g;)V

    invoke-interface {v2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_16
    return-void

    :catchall_17
    move-exception p1

    :try_start_18
    monitor-exit v0
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_17

    throw p1
.end method

.method public final k()V
    .registers 3

    new-instance v0, Landroidx/camera/core/impl/K$b;

    const-string v1, "Surface request will not complete."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/core/i1;->f:Landroidx/concurrent/futures/b$a;

    invoke-virtual {v1, v0}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    return-void
.end method
