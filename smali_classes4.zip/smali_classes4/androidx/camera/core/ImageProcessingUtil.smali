.class final Landroidx/camera/core/ImageProcessingUtil;
.super Ljava/lang/Object;
.source "ImageProcessingUtil.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/ImageProcessingUtil$a;
    }
.end annotation


# static fields
.field private static a:I

.field public static final synthetic b:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "image_processing_util_jni"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroidx/camera/core/r0;)V
    .registers 16

    invoke-static {p0}, Landroidx/camera/core/ImageProcessingUtil;->c(Landroidx/camera/core/r0;)Z

    move-result v0

    const-string v1, "ImageProcessingUtil"

    if-nez v0, :cond_e

    const-string p0, "Unsupported format for YUV to RGB"

    invoke-static {v1, p0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_e
    invoke-interface {p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v10

    invoke-interface {p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result v11

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v2, 0x0

    aget-object v0, v0, v2

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v3

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v4, 0x1

    aget-object v0, v0, v4

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v5

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v6, 0x2

    aget-object v0, v0, v6

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v7

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v2

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->b()I

    move-result v12

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v4

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->b()I

    move-result v14

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v2

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v2

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v4

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v4

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object p0

    aget-object p0, p0, v6

    check-cast p0, Landroidx/camera/core/a$a;

    invoke-virtual {p0}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v6

    move v8, v12

    move v9, v14

    move v13, v14

    invoke-static/range {v2 .. v14}, Landroidx/camera/core/ImageProcessingUtil;->nativeShiftPixel(Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;IIIIIIII)I

    move-result p0

    if-eqz p0, :cond_85

    sget-object p0, Landroidx/camera/core/ImageProcessingUtil$a;->ERROR_CONVERSION:Landroidx/camera/core/ImageProcessingUtil$a;

    goto :goto_87

    :cond_85
    sget-object p0, Landroidx/camera/core/ImageProcessingUtil$a;->SUCCESS:Landroidx/camera/core/ImageProcessingUtil$a;

    :goto_87
    sget-object v0, Landroidx/camera/core/ImageProcessingUtil$a;->ERROR_CONVERSION:Landroidx/camera/core/ImageProcessingUtil$a;

    if-ne p0, v0, :cond_90

    const-string p0, "One pixel shift for YUV failure"

    invoke-static {v1, p0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_90
    return-void
.end method

.method public static b(Landroidx/camera/core/r0;Landroidx/camera/core/X0;Ljava/nio/ByteBuffer;IZ)Landroidx/camera/core/r0;
    .registers 27

    move/from16 v15, p3

    invoke-static/range {p0 .. p0}, Landroidx/camera/core/ImageProcessingUtil;->c(Landroidx/camera/core/r0;)Z

    move-result v0

    const/16 v16, 0x0

    const-string v14, "ImageProcessingUtil"

    if-nez v0, :cond_12

    const-string v0, "Unsupported format for YUV to RGB"

    invoke-static {v14, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v16

    :cond_12
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v17

    if-eqz v15, :cond_2b

    const/16 v0, 0x5a

    if-eq v15, v0, :cond_2b

    const/16 v0, 0xb4

    if-eq v15, v0, :cond_2b

    const/16 v0, 0x10e

    if-ne v15, v0, :cond_25

    goto :goto_2b

    :cond_25
    const-string v0, "Unsupported rotation degrees for rotate RGB"

    invoke-static {v14, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v16

    :cond_2b
    :goto_2b
    invoke-virtual/range {p1 .. p1}, Landroidx/camera/core/X0;->a()Landroid/view/Surface;

    move-result-object v8

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v10

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result v11

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v0, v0, v1

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v2

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/16 v19, 0x1

    aget-object v0, v0, v19

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v3

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v4, 0x2

    aget-object v0, v0, v4

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v5

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v1

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->b()I

    move-result v6

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v19

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->b()I

    move-result v7

    if-eqz p4, :cond_7b

    move v12, v6

    goto :goto_7c

    :cond_7b
    const/4 v12, 0x0

    :goto_7c
    if-eqz p4, :cond_80

    move v13, v7

    goto :goto_81

    :cond_80
    const/4 v13, 0x0

    :goto_81
    if-eqz p4, :cond_86

    move/from16 v20, v7

    goto :goto_88

    :cond_86
    const/16 v20, 0x0

    :goto_88
    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v1

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v1

    aget-object v1, v1, v19

    check-cast v1, Landroidx/camera/core/a$a;

    invoke-virtual {v1}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v9

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v1

    aget-object v1, v1, v4

    check-cast v1, Landroidx/camera/core/a$a;

    invoke-virtual {v1}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v4

    move v1, v2

    move-object v2, v9

    move-object/from16 v9, p2

    move-object/from16 v21, v14

    move/from16 v14, v20

    move/from16 v15, p3

    invoke-static/range {v0 .. v15}, Landroidx/camera/core/ImageProcessingUtil;->nativeConvertAndroid420ToABGR(Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;IIILandroid/view/Surface;Ljava/nio/ByteBuffer;IIIIII)I

    move-result v0

    if-eqz v0, :cond_bf

    sget-object v0, Landroidx/camera/core/ImageProcessingUtil$a;->ERROR_CONVERSION:Landroidx/camera/core/ImageProcessingUtil$a;

    goto :goto_c1

    :cond_bf
    sget-object v0, Landroidx/camera/core/ImageProcessingUtil$a;->SUCCESS:Landroidx/camera/core/ImageProcessingUtil$a;

    :goto_c1
    sget-object v1, Landroidx/camera/core/ImageProcessingUtil$a;->ERROR_CONVERSION:Landroidx/camera/core/ImageProcessingUtil$a;

    if-ne v0, v1, :cond_cd

    const-string v0, "YUV to RGB conversion failure"

    move-object/from16 v1, v21

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v16

    :cond_cd
    move-object/from16 v1, v21

    const-string v0, "MH"

    const/4 v2, 0x3

    invoke-static {v0, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_101

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sub-long v2, v2, v17

    sget v0, Landroidx/camera/core/ImageProcessingUtil;->a:I

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "Image processing performance profiling, duration: ["

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "], image count: "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    sget v0, Landroidx/camera/core/ImageProcessingUtil;->a:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Landroidx/camera/core/ImageProcessingUtil;->a:I

    :cond_101
    invoke-virtual/range {p1 .. p1}, Landroidx/camera/core/X0;->c()Landroidx/camera/core/r0;

    move-result-object v0

    if-nez v0, :cond_10d

    const-string v0, "YUV to RGB acquireLatestImage failure"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v16

    :cond_10d
    new-instance v1, Landroidx/camera/core/a1;

    invoke-direct {v1, v0}, Landroidx/camera/core/a1;-><init>(Landroidx/camera/core/r0;)V

    new-instance v2, Landroidx/camera/core/p0;

    move-object/from16 v3, p0

    invoke-direct {v2, v0, v3}, Landroidx/camera/core/p0;-><init>(Landroidx/camera/core/r0;Landroidx/camera/core/r0;)V

    invoke-virtual {v1, v2}, Landroidx/camera/core/K;->c(Landroidx/camera/core/K$a;)V

    return-object v1
.end method

.method private static c(Landroidx/camera/core/r0;)Z
    .registers 3

    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result v0

    const/16 v1, 0x23

    if-ne v0, v1, :cond_12

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object p0

    array-length p0, p0

    const/4 v0, 0x3

    if-ne p0, v0, :cond_12

    const/4 p0, 0x1

    goto :goto_13

    :cond_12
    const/4 p0, 0x0

    :goto_13
    return p0
.end method

.method public static d(Landroidx/camera/core/r0;Landroidx/camera/core/X0;Landroid/media/ImageWriter;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;I)Landroidx/camera/core/r0;
    .registers 33

    move/from16 v6, p6

    invoke-static/range {p0 .. p0}, Landroidx/camera/core/ImageProcessingUtil;->c(Landroidx/camera/core/r0;)Z

    move-result v0

    const/16 v22, 0x0

    const-string v5, "ImageProcessingUtil"

    if-nez v0, :cond_12

    const-string v0, "Unsupported format for rotate YUV"

    invoke-static {v5, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v22

    :cond_12
    if-eqz v6, :cond_27

    const/16 v0, 0x5a

    if-eq v6, v0, :cond_27

    const/16 v0, 0xb4

    if-eq v6, v0, :cond_27

    const/16 v0, 0x10e

    if-ne v6, v0, :cond_21

    goto :goto_27

    :cond_21
    const-string v0, "Unsupported rotation degrees for rotate YUV"

    invoke-static {v5, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v22

    :cond_27
    :goto_27
    sget-object v3, Landroidx/camera/core/ImageProcessingUtil$a;->ERROR_CONVERSION:Landroidx/camera/core/ImageProcessingUtil$a;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_122

    if-lez v6, :cond_122

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v19

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result v20

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v0, v0, v1

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v16

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v12, 0x1

    aget-object v0, v0, v12

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v17

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v15, 0x2

    aget-object v0, v0, v15

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->a()I

    move-result v18

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v12

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->b()I

    move-result v21

    invoke-static/range {p2 .. p2}, Lx/a;->b(Landroid/media/ImageWriter;)Landroid/media/Image;

    move-result-object v14

    if-nez v14, :cond_78

    move-object/from16 v24, v3

    move-object/from16 v25, v5

    goto/16 :goto_11f

    :cond_78
    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    aget-object v0, v0, v1

    check-cast v0, Landroidx/camera/core/a$a;

    invoke-virtual {v0}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v2

    aget-object v2, v2, v12

    check-cast v2, Landroidx/camera/core/a$a;

    invoke-virtual {v2}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v2

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v4

    aget-object v4, v4, v15

    check-cast v4, Landroidx/camera/core/a$a;

    invoke-virtual {v4}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v4

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v7

    aget-object v7, v7, v1

    invoke-virtual {v7}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v7

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v8

    aget-object v8, v8, v1

    invoke-virtual {v8}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v8

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v9

    aget-object v1, v9, v1

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result v9

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v1

    aget-object v1, v1, v12

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v10

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v1

    aget-object v1, v1, v12

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v11

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v1

    aget-object v1, v1, v12

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result v12

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v1

    aget-object v1, v1, v15

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v13

    invoke-virtual {v14}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v1

    aget-object v1, v1, v15

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v1

    move-object/from16 v23, v14

    move v14, v1

    invoke-virtual/range {v23 .. v23}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v1

    aget-object v1, v1, v15

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result v15

    move/from16 v1, v16

    move-object/from16 v24, v3

    move/from16 v3, v17

    move-object/from16 v25, v5

    move/from16 v5, v18

    move/from16 v6, v21

    move-object/from16 v16, p3

    move-object/from16 v17, p4

    move-object/from16 v18, p5

    move/from16 v21, p6

    invoke-static/range {v0 .. v21}, Landroidx/camera/core/ImageProcessingUtil;->nativeRotateYUV(Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;III)I

    move-result v0

    if-eqz v0, :cond_116

    move-object/from16 v3, v24

    goto :goto_11f

    :cond_116
    move-object/from16 v0, p2

    move-object/from16 v1, v23

    invoke-static {v0, v1}, Lx/a;->e(Landroid/media/ImageWriter;Landroid/media/Image;)V

    sget-object v3, Landroidx/camera/core/ImageProcessingUtil$a;->SUCCESS:Landroidx/camera/core/ImageProcessingUtil$a;

    :goto_11f
    move-object/from16 v0, v24

    goto :goto_129

    :cond_122
    move-object/from16 v24, v3

    move-object/from16 v25, v5

    move-object/from16 v0, v24

    move-object v3, v0

    :goto_129
    if-ne v3, v0, :cond_133

    const-string v0, "rotate YUV failure"

    move-object/from16 v1, v25

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v22

    :cond_133
    move-object/from16 v1, v25

    invoke-virtual/range {p1 .. p1}, Landroidx/camera/core/X0;->c()Landroidx/camera/core/r0;

    move-result-object v0

    if-nez v0, :cond_141

    const-string v0, "YUV rotation acquireLatestImage failure"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v22

    :cond_141
    new-instance v1, Landroidx/camera/core/a1;

    invoke-direct {v1, v0}, Landroidx/camera/core/a1;-><init>(Landroidx/camera/core/r0;)V

    new-instance v2, Landroidx/camera/core/q0;

    move-object/from16 v3, p0

    invoke-direct {v2, v0, v3}, Landroidx/camera/core/q0;-><init>(Landroidx/camera/core/r0;Landroidx/camera/core/r0;)V

    invoke-virtual {v1, v2}, Landroidx/camera/core/K;->c(Landroidx/camera/core/K$a;)V

    return-object v1
.end method

.method private static native nativeConvertAndroid420ToABGR(Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;IIILandroid/view/Surface;Ljava/nio/ByteBuffer;IIIIII)I
.end method

.method private static native nativeRotateYUV(Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;IILjava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;III)I
.end method

.method private static native nativeShiftPixel(Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;IIIIIIII)I
.end method

.method private static native nativeWriteJpegToSurface([BLandroid/view/Surface;)I
.end method
