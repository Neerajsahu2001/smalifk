.class interface abstract Landroidx/camera/core/K$a;
.super Ljava/lang/Object;
.source "ForwardingImageProxy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/K;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation


# virtual methods
.method public abstract b(Landroidx/camera/core/r0;)V
.end method
