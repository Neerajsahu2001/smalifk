.class public final Landroidx/camera/core/n0;
.super Ljava/lang/Exception;
.source "ImageCaptureException.java"


# instance fields
.field private final a:I


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 4

    invoke-direct {p0, p2, p3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    iput p1, p0, Landroidx/camera/core/n0;->a:I

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/n0;->a:I

    return v0
.end method
