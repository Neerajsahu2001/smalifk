.class public interface abstract Landroidx/camera/core/n;
.super Ljava/lang/Object;
.source "CameraControl.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/n$a;
    }
.end annotation


# virtual methods
.method public abstract b()Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end method

.method public abstract d(Z)Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end method

.method public abstract e(Landroidx/camera/core/I;)Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/I;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Landroidx/camera/core/J;",
            ">;"
        }
    .end annotation
.end method
