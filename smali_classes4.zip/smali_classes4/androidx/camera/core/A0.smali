.class public final synthetic Landroidx/camera/core/a0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lm/a;


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Ljava/util/List;

    sget-object p1, Landroidx/camera/core/k0;->I:Landroidx/camera/core/k0$i;

    const/4 p1, 0x0

    return-object p1
.end method
