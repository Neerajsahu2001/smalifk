.class final enum Landroidx/camera/core/j1$c;
.super Ljava/lang/Enum;
.source "UseCase.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/j1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/j1$c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/j1$c;

.field public static final enum ACTIVE:Landroidx/camera/core/j1$c;

.field public static final enum INACTIVE:Landroidx/camera/core/j1$c;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance v2, Landroidx/camera/core/j1$c;

    const-string v3, "ACTIVE"

    invoke-direct {v2, v3, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Landroidx/camera/core/j1$c;->ACTIVE:Landroidx/camera/core/j1$c;

    new-instance v3, Landroidx/camera/core/j1$c;

    const-string v4, "INACTIVE"

    invoke-direct {v3, v4, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Landroidx/camera/core/j1$c;->INACTIVE:Landroidx/camera/core/j1$c;

    const/4 v4, 0x2

    new-array v4, v4, [Landroidx/camera/core/j1$c;

    aput-object v2, v4, v1

    aput-object v3, v4, v0

    sput-object v4, Landroidx/camera/core/j1$c;->$VALUES:[Landroidx/camera/core/j1$c;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/j1$c;
    .registers 2

    const-class v0, Landroidx/camera/core/j1$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/j1$c;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/j1$c;
    .registers 1

    sget-object v0, Landroidx/camera/core/j1$c;->$VALUES:[Landroidx/camera/core/j1$c;

    invoke-virtual {v0}, [Landroidx/camera/core/j1$c;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/j1$c;

    return-object v0
.end method
