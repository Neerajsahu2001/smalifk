.class final Landroidx/camera/core/impl/C0$a;
.super Ljava/lang/Object;
.source "UseCaseAttachState.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/C0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/u0;

.field private b:Z

.field private c:Z


# direct methods
.method constructor <init>(Landroidx/camera/core/impl/u0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/core/impl/C0$a;->b:Z

    iput-boolean v0, p0, Landroidx/camera/core/impl/C0$a;->c:Z

    iput-object p1, p0, Landroidx/camera/core/impl/C0$a;->a:Landroidx/camera/core/impl/u0;

    return-void
.end method


# virtual methods
.method final a()Z
    .registers 2

    iget-boolean v0, p0, Landroidx/camera/core/impl/C0$a;->c:Z

    return v0
.end method

.method final b()Z
    .registers 2

    iget-boolean v0, p0, Landroidx/camera/core/impl/C0$a;->b:Z

    return v0
.end method

.method final c()Landroidx/camera/core/impl/u0;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/C0$a;->a:Landroidx/camera/core/impl/u0;

    return-object v0
.end method

.method final d(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/camera/core/impl/C0$a;->c:Z

    return-void
.end method

.method final e(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/camera/core/impl/C0$a;->b:Z

    return-void
.end method
