.class public final enum Landroidx/camera/core/impl/l;
.super Ljava/lang/Enum;
.source "CameraCaptureMetaData.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/impl/l;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/impl/l;

.field public static final enum INACTIVE:Landroidx/camera/core/impl/l;

.field public static final enum LOCKED_FOCUSED:Landroidx/camera/core/impl/l;

.field public static final enum LOCKED_NOT_FOCUSED:Landroidx/camera/core/impl/l;

.field public static final enum PASSIVE_FOCUSED:Landroidx/camera/core/impl/l;

.field public static final enum PASSIVE_NOT_FOCUSED:Landroidx/camera/core/impl/l;

.field public static final enum SCANNING:Landroidx/camera/core/impl/l;

.field public static final enum UNKNOWN:Landroidx/camera/core/impl/l;


# direct methods
.method static constructor <clinit>()V
    .registers 15

    const/4 v0, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v7, Landroidx/camera/core/impl/l;

    const-string v8, "UNKNOWN"

    invoke-direct {v7, v8, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Landroidx/camera/core/impl/l;->UNKNOWN:Landroidx/camera/core/impl/l;

    new-instance v8, Landroidx/camera/core/impl/l;

    const-string v9, "INACTIVE"

    invoke-direct {v8, v9, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Landroidx/camera/core/impl/l;->INACTIVE:Landroidx/camera/core/impl/l;

    new-instance v9, Landroidx/camera/core/impl/l;

    const-string v10, "SCANNING"

    invoke-direct {v9, v10, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Landroidx/camera/core/impl/l;->SCANNING:Landroidx/camera/core/impl/l;

    new-instance v10, Landroidx/camera/core/impl/l;

    const-string v11, "PASSIVE_FOCUSED"

    invoke-direct {v10, v11, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Landroidx/camera/core/impl/l;->PASSIVE_FOCUSED:Landroidx/camera/core/impl/l;

    new-instance v11, Landroidx/camera/core/impl/l;

    const-string v12, "PASSIVE_NOT_FOCUSED"

    invoke-direct {v11, v12, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Landroidx/camera/core/impl/l;->PASSIVE_NOT_FOCUSED:Landroidx/camera/core/impl/l;

    new-instance v12, Landroidx/camera/core/impl/l;

    const-string v13, "LOCKED_FOCUSED"

    invoke-direct {v12, v13, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v12, Landroidx/camera/core/impl/l;->LOCKED_FOCUSED:Landroidx/camera/core/impl/l;

    new-instance v13, Landroidx/camera/core/impl/l;

    const-string v14, "LOCKED_NOT_FOCUSED"

    invoke-direct {v13, v14, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v13, Landroidx/camera/core/impl/l;->LOCKED_NOT_FOCUSED:Landroidx/camera/core/impl/l;

    const/4 v14, 0x7

    new-array v14, v14, [Landroidx/camera/core/impl/l;

    aput-object v7, v14, v6

    aput-object v8, v14, v5

    aput-object v9, v14, v4

    aput-object v10, v14, v3

    aput-object v11, v14, v2

    aput-object v12, v14, v1

    aput-object v13, v14, v0

    sput-object v14, Landroidx/camera/core/impl/l;->$VALUES:[Landroidx/camera/core/impl/l;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/impl/l;
    .registers 2

    const-class v0, Landroidx/camera/core/impl/l;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/impl/l;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/impl/l;
    .registers 1

    sget-object v0, Landroidx/camera/core/impl/l;->$VALUES:[Landroidx/camera/core/impl/l;

    invoke-virtual {v0}, [Landroidx/camera/core/impl/l;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/impl/l;

    return-object v0
.end method
