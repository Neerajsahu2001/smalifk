.class public interface abstract Landroidx/camera/core/impl/x;
.super Ljava/lang/Object;
.source "CameraInternal.java"

# interfaces
.implements Landroidx/camera/core/l;
.implements Landroidx/camera/core/j1$d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/x$a;
    }
.end annotation


# virtual methods
.method public abstract a()Landroidx/camera/core/r;
.end method

.method public abstract e()Landroidx/camera/camera2/internal/t;
.end method

.method public abstract g(Z)V
.end method

.method public abstract h(Ljava/util/Collection;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Landroidx/camera/core/j1;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract i()Landroidx/camera/camera2/internal/K;
.end method

.method public abstract j(Landroidx/camera/core/impl/p;)V
.end method

.method public abstract k()Landroidx/camera/core/impl/h0;
.end method

.method public abstract l(Ljava/util/ArrayList;)V
.end method
