.class public interface abstract Landroidx/camera/core/impl/t0;
.super Ljava/lang/Object;
.source "ReadableConfig.java"

# interfaces
.implements Landroidx/camera/core/impl/H;


# virtual methods
.method public abstract getConfig()Landroidx/camera/core/impl/H;
.end method
