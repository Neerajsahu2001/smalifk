.class public final Landroidx/camera/core/impl/w0;
.super Landroidx/camera/core/impl/K;
.source "SessionProcessorSurface.java"


# virtual methods
.method public final l()Lcom/google/common/util/concurrent/o;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Landroid/view/Surface;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    return-object v0
.end method
