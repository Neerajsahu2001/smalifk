.class public interface abstract Landroidx/camera/core/impl/j0;
.super Ljava/lang/Object;
.source "MutableConfig.java"

# interfaces
.implements Landroidx/camera/core/impl/H;
