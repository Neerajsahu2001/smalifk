.class public interface abstract Landroidx/camera/core/impl/F0$c;
.super Ljava/lang/Object;
.source "UseCaseConfigFactory.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/F0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a(Landroid/content/Context;)Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/z0;
        }
    .end annotation
.end method
