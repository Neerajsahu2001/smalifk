.class public final enum Landroidx/camera/core/impl/n;
.super Ljava/lang/Enum;
.source "CameraCaptureMetaData.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/impl/n;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/impl/n;

.field public static final enum FIRED:Landroidx/camera/core/impl/n;

.field public static final enum NONE:Landroidx/camera/core/impl/n;

.field public static final enum READY:Landroidx/camera/core/impl/n;

.field public static final enum UNKNOWN:Landroidx/camera/core/impl/n;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v4, Landroidx/camera/core/impl/n;

    const-string v5, "UNKNOWN"

    invoke-direct {v4, v5, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Landroidx/camera/core/impl/n;->UNKNOWN:Landroidx/camera/core/impl/n;

    new-instance v5, Landroidx/camera/core/impl/n;

    const-string v6, "NONE"

    invoke-direct {v5, v6, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Landroidx/camera/core/impl/n;->NONE:Landroidx/camera/core/impl/n;

    new-instance v6, Landroidx/camera/core/impl/n;

    const-string v7, "READY"

    invoke-direct {v6, v7, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Landroidx/camera/core/impl/n;->READY:Landroidx/camera/core/impl/n;

    new-instance v7, Landroidx/camera/core/impl/n;

    const-string v8, "FIRED"

    invoke-direct {v7, v8, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Landroidx/camera/core/impl/n;->FIRED:Landroidx/camera/core/impl/n;

    const/4 v8, 0x4

    new-array v8, v8, [Landroidx/camera/core/impl/n;

    aput-object v4, v8, v3

    aput-object v5, v8, v2

    aput-object v6, v8, v1

    aput-object v7, v8, v0

    sput-object v8, Landroidx/camera/core/impl/n;->$VALUES:[Landroidx/camera/core/impl/n;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/impl/n;
    .registers 2

    const-class v0, Landroidx/camera/core/impl/n;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/impl/n;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/impl/n;
    .registers 1

    sget-object v0, Landroidx/camera/core/impl/n;->$VALUES:[Landroidx/camera/core/impl/n;

    invoke-virtual {v0}, [Landroidx/camera/core/impl/n;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/impl/n;

    return-object v0
.end method
