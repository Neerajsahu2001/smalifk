.class public final Landroidx/camera/core/impl/z;
.super Ljava/lang/Object;
.source "CameraStateRegistry.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/z$a;,
        Landroidx/camera/core/impl/z$b;
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/StringBuilder;

.field private final b:Ljava/lang/Object;

.field private final c:I

.field private final d:Ljava/util/HashMap;

.field private e:I


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/z;->a:Ljava/lang/StringBuilder;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/z;->b:Ljava/lang/Object;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    const/4 v0, 0x1

    iput v0, p0, Landroidx/camera/core/impl/z;->c:I

    const-string v1, "mLock"

    monitor-enter v1

    :try_start_1e
    iput v0, p0, Landroidx/camera/core/impl/z;->e:I

    monitor-exit v1

    return-void

    :catchall_22
    move-exception v0

    monitor-exit v1
    :try_end_24
    .catchall {:try_start_1e .. :try_end_24} :catchall_22

    throw v0
.end method

.method private c()V
    .registers 15

    const/4 v0, 0x2

    const/4 v1, 0x1

    const-string v2, "CameraStateRegistry"

    invoke-static {v2}, Landroidx/camera/core/A0;->f(Ljava/lang/String;)Z

    move-result v3

    const-string v4, "-------------------------------------------------------------------\n"

    const-string v5, "%-45s%-22s\n"

    const/4 v6, 0x0

    iget-object v7, p0, Landroidx/camera/core/impl/z;->a:Ljava/lang/StringBuilder;

    if-eqz v3, :cond_2f

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->setLength(I)V

    const-string v3, "Recalculating open cameras:\n"

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-array v8, v0, [Ljava/lang/Object;

    const-string v9, "Camera"

    aput-object v9, v8, v6

    const-string v9, "State"

    aput-object v9, v8, v1

    invoke-static {v3, v5, v8}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2f
    iget-object v3, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {v3}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const/4 v8, 0x0

    :cond_3a
    :goto_3a
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_96

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    invoke-static {v2}, Landroidx/camera/core/A0;->f(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_82

    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroidx/camera/core/impl/z$a;

    invoke-virtual {v10}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object v10

    if-eqz v10, :cond_67

    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroidx/camera/core/impl/z$a;

    invoke-virtual {v10}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    goto :goto_69

    :cond_67
    const-string v10, "UNKNOWN"

    :goto_69
    sget-object v11, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroidx/camera/core/l;

    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v12

    new-array v13, v0, [Ljava/lang/Object;

    aput-object v12, v13, v6

    aput-object v10, v13, v1

    invoke-static {v11, v5, v13}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_82
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroidx/camera/core/impl/z$a;

    invoke-virtual {v9}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object v9

    if-eqz v9, :cond_3a

    invoke-virtual {v9}, Landroidx/camera/core/impl/x$a;->a()Z

    move-result v9

    if-eqz v9, :cond_3a

    add-int/2addr v8, v1

    goto :goto_3a

    :cond_96
    invoke-static {v2}, Landroidx/camera/core/A0;->f(Ljava/lang/String;)Z

    move-result v0

    iget v1, p0, Landroidx/camera/core/impl/z;->c:I

    if-eqz v0, :cond_c8

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Open count: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " (Max allowed: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_c8
    sub-int/2addr v1, v8

    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Landroidx/camera/core/impl/z;->e:I

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/impl/z;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2c

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/z$a;

    invoke-virtual {v2}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object v2

    sget-object v3, Landroidx/camera/core/impl/x$a;->CLOSING:Landroidx/camera/core/impl/x$a;

    if-ne v2, v3, :cond_d

    monitor-exit v0

    const/4 v0, 0x1

    return v0

    :catchall_2a
    move-exception v1

    goto :goto_2f

    :cond_2c
    monitor-exit v0

    const/4 v0, 0x0

    return v0

    :goto_2f
    monitor-exit v0
    :try_end_30
    .catchall {:try_start_3 .. :try_end_30} :catchall_2a

    throw v1
.end method

.method public final b(Landroidx/camera/core/l;Landroidx/camera/core/impl/x$a;Z)V
    .registers 11

    iget-object v0, p0, Landroidx/camera/core/impl/z;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget v1, p0, Landroidx/camera/core/impl/z;->e:I

    sget-object v2, Landroidx/camera/core/impl/x$a;->RELEASED:Landroidx/camera/core/impl/x$a;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ne p2, v2, :cond_1f

    iget-object v2, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/z$a;

    if-eqz v2, :cond_1d

    invoke-direct {p0}, Landroidx/camera/core/impl/z;->c()V

    invoke-virtual {v2}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object v2

    goto :goto_4c

    :cond_1d
    move-object v2, v4

    goto :goto_4c

    :cond_1f
    iget-object v2, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/z$a;

    const-string v5, "Cannot update state of camera which has not yet been registered. Register with CameraStateRegistry.registerCamera()"

    invoke-static {v2, v5}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, p2}, Landroidx/camera/core/impl/z$a;->c(Landroidx/camera/core/impl/x$a;)Landroidx/camera/core/impl/x$a;

    move-result-object v2

    sget-object v5, Landroidx/camera/core/impl/x$a;->OPENING:Landroidx/camera/core/impl/x$a;

    if-ne p2, v5, :cond_47

    if-eqz p2, :cond_3d

    invoke-virtual {p2}, Landroidx/camera/core/impl/x$a;->a()Z

    move-result v6

    if-eqz v6, :cond_3d

    goto :goto_3f

    :cond_3d
    if-ne v2, v5, :cond_41

    :goto_3f
    const/4 v5, 0x1

    goto :goto_42

    :cond_41
    const/4 v5, 0x0

    :goto_42
    const-string v6, "Cannot mark camera as opening until camera was successful at calling CameraStateRegistry.tryOpenCamera()"

    invoke-static {v5, v6}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    :cond_47
    if-eq v2, p2, :cond_4c

    invoke-direct {p0}, Landroidx/camera/core/impl/z;->c()V

    :cond_4c
    :goto_4c
    if-ne v2, p2, :cond_53

    monitor-exit v0

    return-void

    :catchall_50
    move-exception p1

    goto/16 :goto_cd

    :cond_53
    if-ge v1, v3, :cond_92

    iget v1, p0, Landroidx/camera/core/impl/z;->e:I

    if-lez v1, :cond_92

    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    iget-object p2, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {p2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_68
    :goto_68
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_aa

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/z$a;

    invoke-virtual {v2}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object v2

    sget-object v3, Landroidx/camera/core/impl/x$a;->PENDING_OPEN:Landroidx/camera/core/impl/x$a;

    if-ne v2, v3, :cond_68

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/l;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/z$a;

    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_68

    :cond_92
    sget-object v1, Landroidx/camera/core/impl/x$a;->PENDING_OPEN:Landroidx/camera/core/impl/x$a;

    if-ne p2, v1, :cond_aa

    iget p2, p0, Landroidx/camera/core/impl/z;->e:I

    if-lez p2, :cond_aa

    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    iget-object p2, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/camera/core/impl/z$a;

    invoke-virtual {v4, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_aa
    if-eqz v4, :cond_b1

    if-nez p3, :cond_b1

    invoke-interface {v4, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b1
    monitor-exit v0
    :try_end_b2
    .catchall {:try_start_3 .. :try_end_b2} :catchall_50

    if-eqz v4, :cond_cc

    invoke-interface {v4}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_bc
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_cc

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/camera/core/impl/z$a;

    invoke-virtual {p2}, Landroidx/camera/core/impl/z$a;->b()V

    goto :goto_bc

    :cond_cc
    return-void

    :goto_cd
    :try_start_cd
    monitor-exit v0
    :try_end_ce
    .catchall {:try_start_cd .. :try_end_ce} :catchall_50

    throw p1
.end method

.method public final d(Landroidx/camera/core/l;Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/z$b;)V
    .registers 8

    const-string v0, "Camera is already registered: "

    iget-object v1, p0, Landroidx/camera/core/impl/z;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    iget-object v2, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    xor-int/lit8 v2, v2, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    new-instance v2, Landroidx/camera/core/impl/z$a;

    invoke-direct {v2, p2, p3}, Landroidx/camera/core/impl/z$a;-><init>(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/z$b;)V

    invoke-virtual {v0, p1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v1

    return-void

    :catchall_28
    move-exception p1

    monitor-exit v1
    :try_end_2a
    .catchall {:try_start_5 .. :try_end_2a} :catchall_28

    throw p1
.end method

.method public final e(Landroidx/camera/core/l;)Z
    .registers 12

    const-string v0, " --> "

    iget-object v1, p0, Landroidx/camera/core/impl/z;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    iget-object v2, p0, Landroidx/camera/core/impl/z;->d:Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/z$a;

    const-string v3, "Camera must first be registered with registerCamera()"

    invoke-static {v2, v3}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CameraStateRegistry"

    invoke-static {v3}, Landroidx/camera/core/A0;->f(Ljava/lang/String;)Z

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_5b

    iget-object v3, p0, Landroidx/camera/core/impl/z;->a:Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v3, p0, Landroidx/camera/core/impl/z;->a:Ljava/lang/StringBuilder;

    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v7, "tryOpenCamera(%s) [Available Cameras: %d, Already Open: %b (Previous state: %s)]"

    const/4 v8, 0x4

    new-array v8, v8, [Ljava/lang/Object;

    aput-object p1, v8, v4

    iget p1, p0, Landroidx/camera/core/impl/z;->e:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v8, v5

    invoke-virtual {v2}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object p1

    if-eqz p1, :cond_42

    invoke-virtual {p1}, Landroidx/camera/core/impl/x$a;->a()Z

    move-result p1

    if-eqz p1, :cond_42

    const/4 p1, 0x1

    goto :goto_43

    :cond_42
    const/4 p1, 0x0

    :goto_43
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v9, 0x2

    aput-object p1, v8, v9

    invoke-virtual {v2}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object p1

    const/4 v9, 0x3

    aput-object p1, v8, v9

    invoke-static {v6, v7, v8}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_5b

    :catchall_59
    move-exception p1

    goto :goto_9d

    :cond_5b
    :goto_5b
    iget p1, p0, Landroidx/camera/core/impl/z;->e:I

    if-gtz p1, :cond_6b

    invoke-virtual {v2}, Landroidx/camera/core/impl/z$a;->a()Landroidx/camera/core/impl/x$a;

    move-result-object p1

    if-eqz p1, :cond_71

    invoke-virtual {p1}, Landroidx/camera/core/impl/x$a;->a()Z

    move-result p1

    if-eqz p1, :cond_71

    :cond_6b
    sget-object p1, Landroidx/camera/core/impl/x$a;->OPENING:Landroidx/camera/core/impl/x$a;

    invoke-virtual {v2, p1}, Landroidx/camera/core/impl/z$a;->c(Landroidx/camera/core/impl/x$a;)Landroidx/camera/core/impl/x$a;

    const/4 v4, 0x1

    :cond_71
    const-string p1, "CameraStateRegistry"

    invoke-static {p1}, Landroidx/camera/core/A0;->f(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_96

    iget-object p1, p0, Landroidx/camera/core/impl/z;->a:Ljava/lang/StringBuilder;

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    if-eqz v4, :cond_82

    const-string v2, "SUCCESS"

    goto :goto_84

    :cond_82
    const-string v2, "FAIL"

    :goto_84
    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "CameraStateRegistry"

    iget-object v0, p0, Landroidx/camera/core/impl/z;->a:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_96
    if-eqz v4, :cond_9b

    invoke-direct {p0}, Landroidx/camera/core/impl/z;->c()V

    :cond_9b
    monitor-exit v1

    return v4

    :goto_9d
    monitor-exit v1
    :try_end_9e
    .catchall {:try_start_5 .. :try_end_9e} :catchall_59

    throw p1
.end method
