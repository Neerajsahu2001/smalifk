.class final Landroidx/camera/core/impl/s$a;
.super Ljava/lang/Object;
.source "CameraConfigs.java"

# interfaces
.implements Landroidx/camera/core/impl/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/s;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field private final x:Landroidx/camera/core/impl/T;


# direct methods
.method constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    new-instance v1, Landroidx/camera/core/impl/c;

    invoke-direct {v1, v0}, Landroidx/camera/core/impl/c;-><init>(Ljava/lang/Object;)V

    iput-object v1, p0, Landroidx/camera/core/impl/s$a;->x:Landroidx/camera/core/impl/T;

    return-void
.end method


# virtual methods
.method public final A()Landroidx/camera/core/impl/T;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/s$a;->x:Landroidx/camera/core/impl/T;

    return-object v0
.end method

.method public final a()Landroidx/camera/core/impl/F0;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/p;->a:Landroidx/camera/core/impl/H$a;

    sget-object v1, Landroidx/camera/core/impl/F0;->a:Landroidx/camera/core/impl/F0;

    invoke-static {p0, v0, v1}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/F0;

    return-object v0
.end method

.method public final synthetic b(Lt/i;)V
    .registers 2

    invoke-static {p0, p1}, LVk/j;->b(Landroidx/camera/core/impl/t0;Lt/i;)V

    return-void
.end method

.method public final synthetic c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final synthetic e(Landroidx/camera/core/impl/H$a;)Z
    .registers 2

    invoke-static {p0, p1}, LVk/j;->a(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Z

    move-result p1

    return p1
.end method

.method public final synthetic g(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, LVk/j;->h(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final getConfig()Landroidx/camera/core/impl/H;
    .registers 2

    invoke-static {}, Landroidx/camera/core/impl/o0;->C()Landroidx/camera/core/impl/o0;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic h()Ljava/util/Set;
    .registers 2

    invoke-static {p0}, LVk/j;->e(Landroidx/camera/core/impl/t0;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final k()I
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/p;->b:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {p0, v0, v1}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0
.end method

.method public final synthetic l(Landroidx/camera/core/impl/H$a;)Ljava/util/Set;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->d(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/util/Set;

    move-result-object p1

    return-object p1
.end method

.method public final n()Landroidx/camera/core/impl/v0;
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/p;->c:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p0}, Landroidx/camera/core/impl/s$a;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/o0;

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/v0;

    return-object v0
.end method

.method public final r()Ljava/lang/Boolean;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/p;->d:Landroidx/camera/core/impl/H$a;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0, v0, v1}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    return-object v0
.end method

.method public final synthetic w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final synthetic y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->c(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object p1

    return-object p1
.end method
