.class public final Landroidx/camera/core/impl/x0;
.super Ljava/lang/Object;
.source "SingleImageProxyBundle.java"

# interfaces
.implements Landroidx/camera/core/impl/a0;


# instance fields
.field private final a:I

.field private final b:Landroidx/camera/core/r0;


# direct methods
.method public constructor <init>(Landroidx/camera/core/r0;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-interface {p1}, Landroidx/camera/core/r0;->V0()Landroidx/camera/core/o0;

    move-result-object v0

    if-eqz v0, :cond_28

    invoke-interface {v0}, Landroidx/camera/core/o0;->d()Landroidx/camera/core/impl/B0;

    move-result-object v0

    iget-object v0, v0, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    if-eqz p2, :cond_20

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    iput p2, p0, Landroidx/camera/core/impl/x0;->a:I

    iput-object p1, p0, Landroidx/camera/core/impl/x0;->b:Landroidx/camera/core/r0;

    return-void

    :cond_20
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "ImageProxy has no associated tag"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_28
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "ImageProxy has no associated ImageInfo"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    iget v0, p0, Landroidx/camera/core/impl/x0;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final b(I)Lcom/google/common/util/concurrent/o;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/util/concurrent/o<",
            "Landroidx/camera/core/r0;",
            ">;"
        }
    .end annotation

    iget v0, p0, Landroidx/camera/core/impl/x0;->a:I

    if-eq p1, v0, :cond_10

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Capture id does not exist in the bundle"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_10
    iget-object p1, p0, Landroidx/camera/core/impl/x0;->b:Landroidx/camera/core/r0;

    invoke-static {p1}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method public final c()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/x0;->b:Landroidx/camera/core/r0;

    invoke-interface {v0}, Ljava/lang/AutoCloseable;->close()V

    return-void
.end method
