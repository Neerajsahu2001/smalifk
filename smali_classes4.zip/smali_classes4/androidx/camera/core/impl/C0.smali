.class public final Landroidx/camera/core/impl/c0;
.super Landroidx/camera/core/impl/K;
.source "ImmediateSurface.java"


# instance fields
.field private final m:Landroid/view/Surface;


# direct methods
.method public constructor <init>(Landroid/view/Surface;)V
    .registers 2

    invoke-direct {p0}, Landroidx/camera/core/impl/K;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/impl/c0;->m:Landroid/view/Surface;

    return-void
.end method

.method public constructor <init>(Landroid/view/Surface;Landroid/util/Size;I)V
    .registers 4

    invoke-direct {p0, p3, p2}, Landroidx/camera/core/impl/K;-><init>(ILandroid/util/Size;)V

    iput-object p1, p0, Landroidx/camera/core/impl/c0;->m:Landroid/view/Surface;

    return-void
.end method


# virtual methods
.method public final l()Lcom/google/common/util/concurrent/o;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Landroid/view/Surface;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/c0;->m:Landroid/view/Surface;

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    return-object v0
.end method
