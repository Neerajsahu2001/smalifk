.class public final enum Landroidx/camera/core/impl/j;
.super Ljava/lang/Enum;
.source "CameraCaptureMetaData.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/impl/j;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/impl/j;

.field public static final enum CONVERGED:Landroidx/camera/core/impl/j;

.field public static final enum FLASH_REQUIRED:Landroidx/camera/core/impl/j;

.field public static final enum INACTIVE:Landroidx/camera/core/impl/j;

.field public static final enum LOCKED:Landroidx/camera/core/impl/j;

.field public static final enum SEARCHING:Landroidx/camera/core/impl/j;

.field public static final enum UNKNOWN:Landroidx/camera/core/impl/j;


# direct methods
.method static constructor <clinit>()V
    .registers 13

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v6, Landroidx/camera/core/impl/j;

    const-string v7, "UNKNOWN"

    invoke-direct {v6, v7, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Landroidx/camera/core/impl/j;->UNKNOWN:Landroidx/camera/core/impl/j;

    new-instance v7, Landroidx/camera/core/impl/j;

    const-string v8, "INACTIVE"

    invoke-direct {v7, v8, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Landroidx/camera/core/impl/j;->INACTIVE:Landroidx/camera/core/impl/j;

    new-instance v8, Landroidx/camera/core/impl/j;

    const-string v9, "SEARCHING"

    invoke-direct {v8, v9, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Landroidx/camera/core/impl/j;->SEARCHING:Landroidx/camera/core/impl/j;

    new-instance v9, Landroidx/camera/core/impl/j;

    const-string v10, "FLASH_REQUIRED"

    invoke-direct {v9, v10, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Landroidx/camera/core/impl/j;->FLASH_REQUIRED:Landroidx/camera/core/impl/j;

    new-instance v10, Landroidx/camera/core/impl/j;

    const-string v11, "CONVERGED"

    invoke-direct {v10, v11, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Landroidx/camera/core/impl/j;->CONVERGED:Landroidx/camera/core/impl/j;

    new-instance v11, Landroidx/camera/core/impl/j;

    const-string v12, "LOCKED"

    invoke-direct {v11, v12, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Landroidx/camera/core/impl/j;->LOCKED:Landroidx/camera/core/impl/j;

    const/4 v12, 0x6

    new-array v12, v12, [Landroidx/camera/core/impl/j;

    aput-object v6, v12, v5

    aput-object v7, v12, v4

    aput-object v8, v12, v3

    aput-object v9, v12, v2

    aput-object v10, v12, v1

    aput-object v11, v12, v0

    sput-object v12, Landroidx/camera/core/impl/j;->$VALUES:[Landroidx/camera/core/impl/j;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/impl/j;
    .registers 2

    const-class v0, Landroidx/camera/core/impl/j;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/impl/j;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/impl/j;
    .registers 1

    sget-object v0, Landroidx/camera/core/impl/j;->$VALUES:[Landroidx/camera/core/impl/j;

    invoke-virtual {v0}, [Landroidx/camera/core/impl/j;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/impl/j;

    return-object v0
.end method
