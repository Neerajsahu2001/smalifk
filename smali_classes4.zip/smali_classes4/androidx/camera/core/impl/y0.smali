.class public final Landroidx/camera/core/impl/y0;
.super Ljava/lang/Object;
.source "SurfaceCombination.java"


# instance fields
.field private final a:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/y0;->a:Ljava/util/ArrayList;

    return-void
.end method

.method private static b(Ljava/util/ArrayList;I[II)V
    .registers 8

    array-length v0, p2

    if-lt p3, v0, :cond_d

    invoke-virtual {p2}, [I->clone()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [I

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_d
    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_f
    if-ge v1, p1, :cond_26

    const/4 v2, 0x0

    :goto_12
    if-ge v2, p3, :cond_1c

    aget v3, p2, v2

    if-ne v1, v3, :cond_19

    goto :goto_23

    :cond_19
    add-int/lit8 v2, v2, 0x1

    goto :goto_12

    :cond_1c
    aput v1, p2, p3

    add-int/lit8 v2, p3, 0x1

    invoke-static {p0, p1, p2, v2}, Landroidx/camera/core/impl/y0;->b(Ljava/util/ArrayList;I[II)V

    :goto_23
    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_26
    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/z0;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/y0;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final c(Ljava/util/ArrayList;)Z
    .registers 13

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    return v1

    :cond_8
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v2, p0, Landroidx/camera/core/impl/y0;->a:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x0

    if-le v0, v3, :cond_16

    return v4

    :cond_16
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    new-array v5, v0, [I

    invoke-static {v3, v0, v5, v4}, Landroidx/camera/core/impl/y0;->b(Ljava/util/ArrayList;I[II)V

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_28
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_7a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [I

    const/4 v5, 0x0

    const/4 v6, 0x1

    :goto_36
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v5, v7, :cond_77

    aget v7, v3, v5

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_74

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/camera/core/impl/z0;

    aget v8, v3, v5

    invoke-virtual {p1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/camera/core/impl/z0;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8}, Landroidx/camera/core/impl/z0;->c()Landroidx/camera/core/impl/z0$b;

    move-result-object v9

    invoke-virtual {v8}, Landroidx/camera/core/impl/z0;->b()Landroidx/camera/core/impl/z0$a;

    move-result-object v8

    iget v8, v8, Landroidx/camera/core/impl/z0$a;->mId:I

    invoke-virtual {v7}, Landroidx/camera/core/impl/z0;->b()Landroidx/camera/core/impl/z0$a;

    move-result-object v10

    iget v10, v10, Landroidx/camera/core/impl/z0$a;->mId:I

    if-gt v8, v10, :cond_6f

    invoke-virtual {v7}, Landroidx/camera/core/impl/z0;->c()Landroidx/camera/core/impl/z0$b;

    move-result-object v7

    if-ne v9, v7, :cond_6f

    const/4 v7, 0x1

    goto :goto_70

    :cond_6f
    const/4 v7, 0x0

    :goto_70
    and-int/2addr v6, v7

    if-nez v6, :cond_74

    goto :goto_77

    :cond_74
    add-int/lit8 v5, v5, 0x1

    goto :goto_36

    :cond_77
    :goto_77
    if-eqz v6, :cond_28

    goto :goto_7b

    :cond_7a
    const/4 v1, 0x0

    :goto_7b
    return v1
.end method
