.class public final Landroidx/camera/core/impl/h0;
.super Ljava/lang/Object;
.source "LiveDataObservable.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/h0$a;,
        Landroidx/camera/core/impl/h0$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field final a:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "Landroidx/camera/core/impl/h0$b<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/HashMap;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/lifecycle/I;

    invoke-direct {v0}, Landroidx/lifecycle/I;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/h0;->a:Landroidx/lifecycle/I;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/h0;->b:Ljava/util/HashMap;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/m0;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Executor;",
            "Landroidx/camera/core/impl/m0<",
            "-TT;>;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/h0;->b:Ljava/util/HashMap;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/impl/h0;->b:Ljava/util/HashMap;

    invoke-virtual {v1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/h0$a;

    if-eqz v1, :cond_13

    iget-object v2, v1, Landroidx/camera/core/impl/h0$a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_13
    new-instance v2, Landroidx/camera/core/impl/h0$a;

    invoke-direct {v2, p1, p2}, Landroidx/camera/core/impl/h0$a;-><init>(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/m0;)V

    iget-object p1, p0, Landroidx/camera/core/impl/h0;->b:Ljava/util/HashMap;

    invoke-virtual {p1, p2, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p1

    new-instance p2, Landroidx/camera/core/impl/f0;

    invoke-direct {p2, p0, v1, v2}, Landroidx/camera/core/impl/f0;-><init>(Landroidx/camera/core/impl/h0;Landroidx/camera/core/impl/h0$a;Landroidx/camera/core/impl/h0$a;)V

    invoke-interface {p1, p2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    monitor-exit v0

    return-void

    :catchall_2b
    move-exception p1

    monitor-exit v0
    :try_end_2d
    .catchall {:try_start_3 .. :try_end_2d} :catchall_2b

    throw p1
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/h0;->a:Landroidx/lifecycle/I;

    invoke-static {p1}, Landroidx/camera/core/impl/h0$b;->b(Ljava/lang/Object;)Landroidx/camera/core/impl/h0$b;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroidx/lifecycle/I;->postValue(Ljava/lang/Object;)V

    return-void
.end method

.method public final c(Landroidx/camera/core/impl/m0;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/m0<",
            "-TT;>;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/h0;->b:Ljava/util/HashMap;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/impl/h0;->b:Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/camera/core/impl/h0$a;

    if-eqz p1, :cond_22

    iget-object v1, p1, Landroidx/camera/core/impl/h0$a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    new-instance v2, Landroidx/camera/core/impl/e0;

    invoke-direct {v2, p0, p1}, Landroidx/camera/core/impl/e0;-><init>(Landroidx/camera/core/impl/h0;Landroidx/camera/core/impl/h0$a;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_22

    :catchall_20
    move-exception p1

    goto :goto_24

    :cond_22
    :goto_22
    monitor-exit v0

    return-void

    :goto_24
    monitor-exit v0
    :try_end_25
    .catchall {:try_start_3 .. :try_end_25} :catchall_20

    throw p1
.end method
