.class final Landroidx/camera/core/impl/d;
.super Landroidx/camera/core/impl/p0;
.source "AutoValue_OutputSurface.java"


# instance fields
.field private final a:Landroid/view/Surface;

.field private final b:Landroid/util/Size;

.field private final c:I


# direct methods
.method constructor <init>(Landroid/view/Surface;Landroid/util/Size;I)V
    .registers 4

    invoke-direct {p0}, Landroidx/camera/core/impl/p0;-><init>()V

    if-eqz p1, :cond_c

    iput-object p1, p0, Landroidx/camera/core/impl/d;->a:Landroid/view/Surface;

    iput-object p2, p0, Landroidx/camera/core/impl/d;->b:Landroid/util/Size;

    iput p3, p0, Landroidx/camera/core/impl/d;->c:I

    return-void

    :cond_c
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null surface"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final b()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/impl/d;->c:I

    return v0
.end method

.method public final c()Landroid/util/Size;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/d;->b:Landroid/util/Size;

    return-object v0
.end method

.method public final d()Landroid/view/Surface;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/d;->a:Landroid/view/Surface;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Landroidx/camera/core/impl/p0;

    const/4 v2, 0x0

    if-eqz v1, :cond_2e

    check-cast p1, Landroidx/camera/core/impl/p0;

    invoke-virtual {p1}, Landroidx/camera/core/impl/p0;->d()Landroid/view/Surface;

    move-result-object v1

    iget-object v3, p0, Landroidx/camera/core/impl/d;->a:Landroid/view/Surface;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c

    iget-object v1, p0, Landroidx/camera/core/impl/d;->b:Landroid/util/Size;

    invoke-virtual {p1}, Landroidx/camera/core/impl/p0;->c()Landroid/util/Size;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/util/Size;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c

    iget v1, p0, Landroidx/camera/core/impl/d;->c:I

    invoke-virtual {p1}, Landroidx/camera/core/impl/p0;->b()I

    move-result p1

    if-ne v1, p1, :cond_2c

    goto :goto_2d

    :cond_2c
    const/4 v0, 0x0

    :goto_2d
    return v0

    :cond_2e
    return v2
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/d;->a:Landroid/view/Surface;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int v0, v0, v1

    iget-object v2, p0, Landroidx/camera/core/impl/d;->b:Landroid/util/Size;

    invoke-virtual {v2}, Landroid/util/Size;->hashCode()I

    move-result v2

    xor-int/2addr v0, v2

    mul-int v0, v0, v1

    iget v1, p0, Landroidx/camera/core/impl/d;->c:I

    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "OutputSurface{surface="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/core/impl/d;->a:Landroid/view/Surface;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", size="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/camera/core/impl/d;->b:Landroid/util/Size;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", imageFormat="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/camera/core/impl/d;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
