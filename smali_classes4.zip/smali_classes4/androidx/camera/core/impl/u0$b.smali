.class public final Landroidx/camera/core/impl/u0$b;
.super Landroidx/camera/core/impl/u0$a;
.source "SessionConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/u0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroidx/camera/core/impl/u0$a;-><init>()V

    return-void
.end method

.method public static m(Landroidx/camera/core/impl/E0;)Landroidx/camera/core/impl/u0$b;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/E0<",
            "*>;)",
            "Landroidx/camera/core/impl/u0$b;"
        }
    .end annotation

    invoke-interface {p0}, Landroidx/camera/core/impl/E0;->x()Landroidx/camera/core/impl/u0$d;

    move-result-object v0

    if-eqz v0, :cond_f

    new-instance v1, Landroidx/camera/core/impl/u0$b;

    invoke-direct {v1}, Landroidx/camera/core/impl/u0$a;-><init>()V

    invoke-interface {v0, p0, v1}, Landroidx/camera/core/impl/u0$d;->a(Landroidx/camera/core/impl/E0;Landroidx/camera/core/impl/u0$b;)V

    return-object v1

    :cond_f
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Implementation is missing option unpacker for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p0, v2}, Lw/h;->i(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public final a(Ljava/util/List;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    check-cast p1, Ljava/util/List;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/D$a;->a(Ljava/util/List;)V

    return-void
.end method

.method public final b(Landroidx/camera/core/impl/g;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/D$a;->c(Landroidx/camera/core/impl/g;)V

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->f:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_10
    return-void
.end method

.method public final c(Landroid/hardware/camera2/CameraDevice$StateCallback;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->c:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    return-void

    :cond_9
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final d(Landroidx/camera/core/impl/u0$c;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final e(Landroidx/camera/core/impl/H;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    return-void
.end method

.method public final f(Landroidx/camera/core/impl/K;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->a:Ljava/util/LinkedHashSet;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final g(Landroidx/camera/core/impl/g;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/D$a;->c(Landroidx/camera/core/impl/g;)V

    return-void
.end method

.method public final h(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    return-void

    :cond_9
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final i(Landroidx/camera/core/impl/K;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->a:Ljava/util/LinkedHashSet;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/D$a;->f(Landroidx/camera/core/impl/K;)V

    return-void
.end method

.method public final j(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0, p1, p2}, Landroidx/camera/core/impl/D$a;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final k()Landroidx/camera/core/impl/u0;
    .registers 10

    new-instance v8, Landroidx/camera/core/impl/u0;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->a:Ljava/util/LinkedHashSet;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v2, p0, Landroidx/camera/core/impl/u0$a;->c:Ljava/util/ArrayList;

    iget-object v3, p0, Landroidx/camera/core/impl/u0$a;->d:Ljava/util/ArrayList;

    iget-object v4, p0, Landroidx/camera/core/impl/u0$a;->f:Ljava/util/ArrayList;

    iget-object v5, p0, Landroidx/camera/core/impl/u0$a;->e:Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v6

    iget-object v7, p0, Landroidx/camera/core/impl/u0$a;->g:Landroid/hardware/camera2/params/InputConfiguration;

    move-object v0, v8

    invoke-direct/range {v0 .. v7}, Landroidx/camera/core/impl/u0;-><init>(Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Landroidx/camera/core/impl/D;Landroid/hardware/camera2/params/InputConfiguration;)V

    return-object v8
.end method

.method public final l()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->a:Ljava/util/LinkedHashSet;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/D$a;->i()V

    return-void
.end method

.method public final n()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/g;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->f:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final o(Landroidx/camera/core/impl/H;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/D$a;->n(Landroidx/camera/core/impl/H;)V

    return-void
.end method

.method public final p(Landroid/hardware/camera2/params/InputConfiguration;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/core/impl/u0$a;->g:Landroid/hardware/camera2/params/InputConfiguration;

    return-void
.end method

.method public final q(I)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/D$a;->o(I)V

    return-void
.end method
