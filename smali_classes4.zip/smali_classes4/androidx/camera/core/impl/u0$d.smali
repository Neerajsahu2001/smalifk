.class public interface abstract Landroidx/camera/core/impl/u0$d;
.super Ljava/lang/Object;
.source "SessionConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/u0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a(Landroidx/camera/core/impl/E0;Landroidx/camera/core/impl/u0$b;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/E0<",
            "*>;",
            "Landroidx/camera/core/impl/u0$b;",
            ")V"
        }
    .end annotation
.end method
