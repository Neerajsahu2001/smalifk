.class public abstract Landroidx/camera/core/impl/z0;
.super Ljava/lang/Object;
.source "SurfaceConfig.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/z0$a;,
        Landroidx/camera/core/impl/z0$b;
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroidx/camera/core/impl/z0$b;Landroidx/camera/core/impl/z0$a;)Landroidx/camera/core/impl/z0;
    .registers 3

    new-instance v0, Landroidx/camera/core/impl/e;

    invoke-direct {v0, p0, p1}, Landroidx/camera/core/impl/e;-><init>(Landroidx/camera/core/impl/z0$b;Landroidx/camera/core/impl/z0$a;)V

    return-object v0
.end method


# virtual methods
.method public abstract b()Landroidx/camera/core/impl/z0$a;
.end method

.method public abstract c()Landroidx/camera/core/impl/z0$b;
.end method
