.class public interface abstract Landroidx/camera/core/impl/a0;
.super Ljava/lang/Object;
.source "ImageProxyBundle.java"


# virtual methods
.method public abstract a()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end method

.method public abstract b(I)Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/util/concurrent/o<",
            "Landroidx/camera/core/r0;",
            ">;"
        }
    .end annotation
.end method
