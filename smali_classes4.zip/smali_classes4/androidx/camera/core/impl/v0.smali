.class public interface abstract Landroidx/camera/core/impl/v0;
.super Ljava/lang/Object;
.source "SessionProcessor.java"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method

.method public abstract d()Landroidx/camera/core/impl/u0;
.end method

.method public abstract e()V
.end method

.method public abstract f()V
.end method

.method public abstract g()I
.end method
