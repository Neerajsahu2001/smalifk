.class public final Landroidx/camera/core/impl/q0;
.super Ljava/lang/Object;
.source "PreviewConfig.java"

# interfaces
.implements Landroidx/camera/core/impl/E0;
.implements Landroidx/camera/core/impl/Z;
.implements Lw/i;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/camera/core/impl/E0<",
        "Landroidx/camera/core/J0;",
        ">;",
        "Landroidx/camera/core/impl/Z;",
        "Lw/i;"
    }
.end annotation


# static fields
.field public static final A:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public static final y:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/impl/W;",
            ">;"
        }
    .end annotation
.end field

.field public static final z:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/impl/E;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final x:Landroidx/camera/core/impl/o0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "camerax.core.preview.imageInfoProcessor"

    const-class v1, Landroidx/camera/core/impl/W;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/q0;->y:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.preview.captureProcessor"

    const-class v1, Landroidx/camera/core/impl/E;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/q0;->z:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.preview.isRgba8888SurfaceRequired"

    const-class v1, Ljava/lang/Boolean;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/q0;->A:Landroidx/camera/core/impl/H$a;

    return-void
.end method

.method public constructor <init>(Landroidx/camera/core/impl/o0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/impl/q0;->x:Landroidx/camera/core/impl/o0;

    return-void
.end method


# virtual methods
.method public final synthetic B()I
    .registers 2

    invoke-static {p0}, Landroidx/camera/core/impl/Y;->a(Landroidx/camera/core/impl/Z;)I

    move-result v0

    return v0
.end method

.method public final synthetic b(Lt/i;)V
    .registers 2

    invoke-static {p0, p1}, LVk/j;->b(Landroidx/camera/core/impl/t0;Lt/i;)V

    return-void
.end method

.method public final synthetic c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final d()Ljava/util/List;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/Z;->l:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/core/impl/q0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0
.end method

.method public final synthetic e(Landroidx/camera/core/impl/H$a;)Z
    .registers 2

    invoke-static {p0, p1}, LVk/j;->a(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Z

    move-result p1

    return p1
.end method

.method public final f()I
    .registers 2

    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    invoke-static {p0, v0}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0
.end method

.method public final synthetic g(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, LVk/j;->h(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final getConfig()Landroidx/camera/core/impl/H;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/q0;->x:Landroidx/camera/core/impl/o0;

    return-object v0
.end method

.method public final synthetic h()Ljava/util/Set;
    .registers 2

    invoke-static {p0}, LVk/j;->e(Landroidx/camera/core/impl/t0;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic i(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    invoke-static {p0, p1}, Lw/g;->a(Lw/h;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public final j()Landroid/util/Size;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/Z;->j:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/core/impl/q0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Size;

    return-object v0
.end method

.method public final synthetic l(Landroidx/camera/core/impl/H$a;)Ljava/util/Set;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->d(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/util/Set;

    move-result-object p1

    return-object p1
.end method

.method public final m()Landroid/util/Size;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/Z;->i:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/core/impl/q0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Size;

    return-object v0
.end method

.method public final o()Z
    .registers 2

    sget-object v0, Landroidx/camera/core/impl/Z;->f:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p0, v0}, Landroidx/camera/core/impl/q0;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result v0

    return v0
.end method

.method public final p()I
    .registers 2

    sget-object v0, Landroidx/camera/core/impl/Z;->f:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p0, v0}, Landroidx/camera/core/impl/q0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0
.end method

.method public final q()Landroid/util/Size;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/Z;->k:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/core/impl/q0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Size;

    return-object v0
.end method

.method public final synthetic s(I)I
    .registers 2

    invoke-static {p1, p0}, Landroidx/camera/core/impl/Y;->b(ILandroidx/camera/core/impl/Z;)I

    move-result p1

    return p1
.end method

.method public final t()Landroidx/camera/core/j1$b;
    .registers 3

    sget-object v0, Lw/j;->w:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/j1$b;

    return-object v0
.end method

.method public final u()Landroidx/camera/core/impl/u0;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/E0;->m:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/core/impl/q0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/u0;

    return-object v0
.end method

.method public final synthetic v()I
    .registers 2

    invoke-static {p0}, Landroidx/camera/core/impl/D0;->a(Landroidx/camera/core/impl/E0;)I

    move-result v0

    return v0
.end method

.method public final synthetic w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final x()Landroidx/camera/core/impl/u0$d;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/E0;->o:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/core/impl/q0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/u0$d;

    return-object v0
.end method

.method public final synthetic y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->c(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object p1

    return-object p1
.end method

.method public final z()Landroidx/camera/core/s;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/E0;->r:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/core/impl/q0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/s;

    return-object v0
.end method
