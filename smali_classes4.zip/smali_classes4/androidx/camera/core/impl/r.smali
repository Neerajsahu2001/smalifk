.class public interface abstract Landroidx/camera/core/impl/r;
.super Ljava/lang/Object;
.source "CameraConfigProvider.java"


# static fields
.field public static final a:Landroidx/camera/core/impl/q;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/camera/core/impl/q;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/core/impl/r;->a:Landroidx/camera/core/impl/q;

    return-void
.end method
