.class public final Landroidx/camera/core/impl/i;
.super Ljava/lang/Object;
.source "CameraCaptureFailure.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/i$a;
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/i$a;


# direct methods
.method public constructor <init>(Landroidx/camera/core/impl/i$a;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/impl/i;->a:Landroidx/camera/core/impl/i$a;

    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/impl/i$a;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/i;->a:Landroidx/camera/core/impl/i$a;

    return-object v0
.end method
