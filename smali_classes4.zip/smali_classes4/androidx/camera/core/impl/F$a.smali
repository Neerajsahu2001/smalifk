.class public final Landroidx/camera/core/impl/F$a;
.super Ljava/lang/Object;
.source "CaptureStage.java"

# interfaces
.implements Landroidx/camera/core/impl/F;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/D;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/camera/core/impl/D$a;

    invoke-direct {v0}, Landroidx/camera/core/impl/D$a;-><init>()V

    invoke-virtual {v0}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/impl/F$a;->a:Landroidx/camera/core/impl/D;

    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/impl/D;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/F$a;->a:Landroidx/camera/core/impl/D;

    return-object v0
.end method
