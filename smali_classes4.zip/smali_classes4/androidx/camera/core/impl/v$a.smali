.class public interface abstract Landroidx/camera/core/impl/v$a;
.super Ljava/lang/Object;
.source "CameraFactory.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Landroid/content/Context;Landroidx/camera/core/impl/A;Landroidx/camera/core/s;)Landroidx/camera/camera2/internal/v;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/z0;
        }
    .end annotation
.end method
