.class public final enum Landroidx/camera/core/impl/i$a;
.super Ljava/lang/Enum;
.source "CameraCaptureFailure.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/impl/i$a;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/impl/i$a;

.field public static final enum ERROR:Landroidx/camera/core/impl/i$a;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x0

    new-instance v1, Landroidx/camera/core/impl/i$a;

    const-string v2, "ERROR"

    invoke-direct {v1, v2, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Landroidx/camera/core/impl/i$a;->ERROR:Landroidx/camera/core/impl/i$a;

    const/4 v2, 0x1

    new-array v2, v2, [Landroidx/camera/core/impl/i$a;

    aput-object v1, v2, v0

    sput-object v2, Landroidx/camera/core/impl/i$a;->$VALUES:[Landroidx/camera/core/impl/i$a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/impl/i$a;
    .registers 2

    const-class v0, Landroidx/camera/core/impl/i$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/impl/i$a;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/impl/i$a;
    .registers 1

    sget-object v0, Landroidx/camera/core/impl/i$a;->$VALUES:[Landroidx/camera/core/impl/i$a;

    invoke-virtual {v0}, [Landroidx/camera/core/impl/i$a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/impl/i$a;

    return-object v0
.end method
