.class public abstract Landroidx/camera/core/impl/g;
.super Ljava/lang/Object;
.source "CameraCaptureCallback.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .registers 1

    return-void
.end method

.method public b(Landroidx/camera/core/impl/o;)V
    .registers 2

    return-void
.end method

.method public c(Landroidx/camera/core/impl/i;)V
    .registers 2

    return-void
.end method
