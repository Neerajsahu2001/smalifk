.class public final Landroidx/camera/core/impl/utils/e;
.super Ljava/lang/Object;
.source "Exif.java"


# static fields
.field private static final b:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/text/SimpleDateFormat;",
            ">;"
        }
    .end annotation
.end field

.field private static final c:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/text/SimpleDateFormat;",
            ">;"
        }
    .end annotation
.end field

.field private static final d:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/text/SimpleDateFormat;",
            ">;"
        }
    .end annotation
.end field

.field private static final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Landroidx/exifinterface/media/b;


# direct methods
.method static constructor <clinit>()V
    .registers 154

    new-instance v0, Landroidx/camera/core/impl/utils/e$a;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Landroidx/camera/core/impl/utils/e;->b:Ljava/lang/ThreadLocal;

    new-instance v0, Landroidx/camera/core/impl/utils/e$b;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Landroidx/camera/core/impl/utils/e;->c:Ljava/lang/ThreadLocal;

    new-instance v0, Landroidx/camera/core/impl/utils/e$c;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Landroidx/camera/core/impl/utils/e;->d:Ljava/lang/ThreadLocal;

    const-string v150, "JpgFromRaw"

    const-string v151, "Xmp"

    const-string v1, "ImageWidth"

    const-string v2, "ImageLength"

    const-string v3, "BitsPerSample"

    const-string v4, "Compression"

    const-string v5, "PhotometricInterpretation"

    const-string v6, "Orientation"

    const-string v7, "SamplesPerPixel"

    const-string v8, "PlanarConfiguration"

    const-string v9, "YCbCrSubSampling"

    const-string v10, "YCbCrPositioning"

    const-string v11, "XResolution"

    const-string v12, "YResolution"

    const-string v13, "ResolutionUnit"

    const-string v14, "StripOffsets"

    const-string v15, "RowsPerStrip"

    const-string v16, "StripByteCounts"

    const-string v17, "JPEGInterchangeFormat"

    const-string v18, "JPEGInterchangeFormatLength"

    const-string v19, "TransferFunction"

    const-string v20, "WhitePoint"

    const-string v21, "PrimaryChromaticities"

    const-string v22, "YCbCrCoefficients"

    const-string v23, "ReferenceBlackWhite"

    const-string v24, "DateTime"

    const-string v25, "ImageDescription"

    const-string v26, "Make"

    const-string v27, "Model"

    const-string v28, "Software"

    const-string v29, "Artist"

    const-string v30, "Copyright"

    const-string v31, "ExifVersion"

    const-string v32, "FlashpixVersion"

    const-string v33, "ColorSpace"

    const-string v34, "Gamma"

    const-string v35, "PixelXDimension"

    const-string v36, "PixelYDimension"

    const-string v37, "ComponentsConfiguration"

    const-string v38, "CompressedBitsPerPixel"

    const-string v39, "MakerNote"

    const-string v40, "UserComment"

    const-string v41, "RelatedSoundFile"

    const-string v42, "DateTimeOriginal"

    const-string v43, "DateTimeDigitized"

    const-string v44, "OffsetTime"

    const-string v45, "OffsetTimeOriginal"

    const-string v46, "OffsetTimeDigitized"

    const-string v47, "SubSecTime"

    const-string v48, "SubSecTimeOriginal"

    const-string v49, "SubSecTimeDigitized"

    const-string v50, "ExposureTime"

    const-string v51, "FNumber"

    const-string v52, "ExposureProgram"

    const-string v53, "SpectralSensitivity"

    const-string v54, "PhotographicSensitivity"

    const-string v55, "OECF"

    const-string v56, "SensitivityType"

    const-string v57, "StandardOutputSensitivity"

    const-string v58, "RecommendedExposureIndex"

    const-string v59, "ISOSpeed"

    const-string v60, "ISOSpeedLatitudeyyy"

    const-string v61, "ISOSpeedLatitudezzz"

    const-string v62, "ShutterSpeedValue"

    const-string v63, "ApertureValue"

    const-string v64, "BrightnessValue"

    const-string v65, "ExposureBiasValue"

    const-string v66, "MaxApertureValue"

    const-string v67, "SubjectDistance"

    const-string v68, "MeteringMode"

    const-string v69, "LightSource"

    const-string v70, "Flash"

    const-string v71, "SubjectArea"

    const-string v72, "FocalLength"

    const-string v73, "FlashEnergy"

    const-string v74, "SpatialFrequencyResponse"

    const-string v75, "FocalPlaneXResolution"

    const-string v76, "FocalPlaneYResolution"

    const-string v77, "FocalPlaneResolutionUnit"

    const-string v78, "SubjectLocation"

    const-string v79, "ExposureIndex"

    const-string v80, "SensingMethod"

    const-string v81, "FileSource"

    const-string v82, "SceneType"

    const-string v83, "CFAPattern"

    const-string v84, "CustomRendered"

    const-string v85, "ExposureMode"

    const-string v86, "WhiteBalance"

    const-string v87, "DigitalZoomRatio"

    const-string v88, "FocalLengthIn35mmFilm"

    const-string v89, "SceneCaptureType"

    const-string v90, "GainControl"

    const-string v91, "Contrast"

    const-string v92, "Saturation"

    const-string v93, "Sharpness"

    const-string v94, "DeviceSettingDescription"

    const-string v95, "SubjectDistanceRange"

    const-string v96, "ImageUniqueID"

    const-string v97, "CameraOwnerName"

    const-string v98, "BodySerialNumber"

    const-string v99, "LensSpecification"

    const-string v100, "LensMake"

    const-string v101, "LensModel"

    const-string v102, "LensSerialNumber"

    const-string v103, "GPSVersionID"

    const-string v104, "GPSLatitudeRef"

    const-string v105, "GPSLatitude"

    const-string v106, "GPSLongitudeRef"

    const-string v107, "GPSLongitude"

    const-string v108, "GPSAltitudeRef"

    const-string v109, "GPSAltitude"

    const-string v110, "GPSTimeStamp"

    const-string v111, "GPSSatellites"

    const-string v112, "GPSStatus"

    const-string v113, "GPSMeasureMode"

    const-string v114, "GPSDOP"

    const-string v115, "GPSSpeedRef"

    const-string v116, "GPSSpeed"

    const-string v117, "GPSTrackRef"

    const-string v118, "GPSTrack"

    const-string v119, "GPSImgDirectionRef"

    const-string v120, "GPSImgDirection"

    const-string v121, "GPSMapDatum"

    const-string v122, "GPSDestLatitudeRef"

    const-string v123, "GPSDestLatitude"

    const-string v124, "GPSDestLongitudeRef"

    const-string v125, "GPSDestLongitude"

    const-string v126, "GPSDestBearingRef"

    const-string v127, "GPSDestBearing"

    const-string v128, "GPSDestDistanceRef"

    const-string v129, "GPSDestDistance"

    const-string v130, "GPSProcessingMethod"

    const-string v131, "GPSAreaInformation"

    const-string v132, "GPSDateStamp"

    const-string v133, "GPSDifferential"

    const-string v134, "GPSHPositioningError"

    const-string v135, "InteroperabilityIndex"

    const-string v136, "ThumbnailImageLength"

    const-string v137, "ThumbnailImageWidth"

    const-string v138, "ThumbnailOrientation"

    const-string v139, "DNGVersion"

    const-string v140, "DefaultCropSize"

    const-string v141, "ThumbnailImage"

    const-string v142, "PreviewImageStart"

    const-string v143, "PreviewImageLength"

    const-string v144, "AspectFrame"

    const-string v145, "SensorBottomBorder"

    const-string v146, "SensorLeftBorder"

    const-string v147, "SensorRightBorder"

    const-string v148, "SensorTopBorder"

    const-string v149, "ISO"

    const-string v152, "NewSubfileType"

    const-string v153, "SubfileType"

    filled-new-array/range {v1 .. v153}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/utils/e;->e:Ljava/util/List;

    const-string v9, "ThumbnailImageWidth"

    const-string v10, "ThumbnailOrientation"

    const-string v1, "ImageWidth"

    const-string v2, "ImageLength"

    const-string v3, "PixelXDimension"

    const-string v4, "PixelYDimension"

    const-string v5, "Compression"

    const-string v6, "JPEGInterchangeFormat"

    const-string v7, "JPEGInterchangeFormatLength"

    const-string v8, "ThumbnailImageLength"

    filled-new-array/range {v1 .. v10}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/utils/e;->f:Ljava/util/List;

    return-void
.end method

.method private constructor <init>(Landroidx/exifinterface/media/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    return-void
.end method

.method public static b(Ljava/io/File;)Landroidx/camera/core/impl/utils/e;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Ljava/io/File;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Landroidx/camera/core/impl/utils/e;

    new-instance v1, Landroidx/exifinterface/media/b;

    invoke-direct {v1, p0}, Landroidx/exifinterface/media/b;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Landroidx/camera/core/impl/utils/e;-><init>(Landroidx/exifinterface/media/b;)V

    return-object v0
.end method

.method public static c(Ljava/io/ByteArrayInputStream;)Landroidx/camera/core/impl/utils/e;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Landroidx/camera/core/impl/utils/e;

    new-instance v1, Landroidx/exifinterface/media/b;

    invoke-direct {v1, p0}, Landroidx/exifinterface/media/b;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v1}, Landroidx/camera/core/impl/utils/e;-><init>(Landroidx/exifinterface/media/b;)V

    return-object v0
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/utils/e;)V
    .registers 6

    new-instance v0, Ljava/util/ArrayList;

    sget-object v1, Landroidx/camera/core/impl/utils/e;->e:Ljava/util/List;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    sget-object v1, Landroidx/camera/core/impl/utils/e;->f:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_10
    :goto_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    invoke-virtual {v2, v1}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_10

    iget-object v3, p1, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    invoke-virtual {v3, v1, v2}, Landroidx/exifinterface/media/b;->H(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_10

    :cond_2a
    return-void
.end method

.method public final d()I
    .registers 4

    const-string v0, "ImageLength"

    const/4 v1, 0x0

    iget-object v2, p0, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    invoke-virtual {v2, v1, v0}, Landroidx/exifinterface/media/b;->f(ILjava/lang/String;)I

    move-result v0

    return v0
.end method

.method public final e()I
    .registers 4

    const-string v0, "Orientation"

    const/4 v1, 0x0

    iget-object v2, p0, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    invoke-virtual {v2, v1, v0}, Landroidx/exifinterface/media/b;->f(ILjava/lang/String;)I

    move-result v0

    return v0
.end method

.method public final f()I
    .registers 5

    invoke-virtual {p0}, Landroidx/camera/core/impl/utils/e;->e()I

    move-result v0

    const/16 v1, 0xb4

    const/16 v2, 0x5a

    const/16 v3, 0x10e

    packed-switch v0, :pswitch_data_14

    const/4 v0, 0x0

    return v0

    :pswitch_f
    return v3

    :pswitch_10
    return v2

    :pswitch_11
    return v3

    :pswitch_12
    return v1

    nop

    :pswitch_data_14
    .packed-switch 0x3
        :pswitch_12
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_10
        :pswitch_f
    .end packed-switch
.end method

.method public final g()I
    .registers 4

    const-string v0, "ImageWidth"

    const/4 v1, 0x0

    iget-object v2, p0, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    invoke-virtual {v2, v1, v0}, Landroidx/exifinterface/media/b;->f(ILjava/lang/String;)I

    move-result v0

    return v0
.end method

.method public final h(I)V
    .registers 12

    rem-int/lit8 v0, p1, 0x5a

    const-string v1, "Orientation"

    iget-object v2, p0, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    if-eqz v0, :cond_2b

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Can only rotate in right angles (eg. 0, 90, 180, 270). "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " is unsupported."

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "e"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, v1, p1}, Landroidx/exifinterface/media/b;->H(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_2b
    rem-int/lit16 p1, p1, 0x168

    invoke-virtual {p0}, Landroidx/camera/core/impl/utils/e;->e()I

    move-result v0

    :goto_31
    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/16 v8, 0x8

    const/4 v9, 0x6

    if-gez p1, :cond_4f

    add-int/lit8 p1, p1, 0x5a

    packed-switch v0, :pswitch_data_70

    const/16 v0, 0x8

    goto :goto_31

    :pswitch_43
    const/4 v0, 0x6

    goto :goto_31

    :pswitch_45
    const/4 v0, 0x2

    goto :goto_31

    :pswitch_47
    const/4 v0, 0x1

    goto :goto_31

    :pswitch_49
    const/4 v0, 0x4

    goto :goto_31

    :pswitch_4b
    const/4 v0, 0x7

    goto :goto_31

    :pswitch_4d
    const/4 v0, 0x5

    goto :goto_31

    :cond_4f
    :goto_4f
    if-lez p1, :cond_67

    add-int/lit8 p1, p1, -0x5a

    packed-switch v0, :pswitch_data_82

    const/4 v0, 0x6

    goto :goto_4f

    :pswitch_58
    const/4 v0, 0x1

    goto :goto_4f

    :pswitch_5a
    const/4 v0, 0x4

    goto :goto_4f

    :pswitch_5c
    const/4 v0, 0x3

    goto :goto_4f

    :pswitch_5e
    const/4 v0, 0x2

    goto :goto_4f

    :pswitch_60
    const/4 v0, 0x5

    goto :goto_4f

    :pswitch_62
    const/16 v0, 0x8

    goto :goto_4f

    :pswitch_65
    const/4 v0, 0x7

    goto :goto_4f

    :cond_67
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, v1, p1}, Landroidx/exifinterface/media/b;->H(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_70
    .packed-switch 0x2
        :pswitch_4d
        :pswitch_43
        :pswitch_4b
        :pswitch_49
        :pswitch_47
        :pswitch_45
        :pswitch_43
    .end packed-switch

    :pswitch_data_82
    .packed-switch 0x2
        :pswitch_65
        :pswitch_62
        :pswitch_60
        :pswitch_5e
        :pswitch_5c
        :pswitch_5a
        :pswitch_58
    .end packed-switch
.end method

.method public final i()V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sget-object v2, Landroidx/camera/core/impl/utils/e;->d:Ljava/lang/ThreadLocal;

    invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/text/SimpleDateFormat;

    new-instance v4, Ljava/util/Date;

    invoke-direct {v4, v0, v1}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v3, v4}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    const-string v5, "DateTime"

    invoke-virtual {v4, v5, v3}, Landroidx/exifinterface/media/b;->H(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_1c
    invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/text/SimpleDateFormat;

    invoke-virtual {v2, v3}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Date;->getTime()J

    move-result-wide v2

    sub-long/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    const-string v1, "SubSecTime"

    invoke-virtual {v4, v1, v0}, Landroidx/exifinterface/media/b;->H(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_34
    .catch Ljava/text/ParseException; {:try_start_1c .. :try_end_34} :catch_34

    :catch_34
    invoke-virtual {v4}, Landroidx/exifinterface/media/b;->D()V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 22

    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/16 v1, 0x8

    new-array v1, v1, [Ljava/lang/Object;

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/impl/utils/e;->g()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/impl/utils/e;->d()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x1

    aput-object v2, v1, v4

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/impl/utils/e;->f()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x2

    aput-object v2, v1, v5

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/impl/utils/e;->e()I

    move-result v2

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eq v2, v8, :cond_36

    if-eq v2, v7, :cond_36

    if-eq v2, v6, :cond_36

    const/4 v2, 0x0

    goto :goto_37

    :cond_36
    const/4 v2, 0x1

    :goto_37
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v9, 0x3

    aput-object v2, v1, v9

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/impl/utils/e;->e()I

    move-result v2

    if-eq v2, v5, :cond_46

    const/4 v2, 0x0

    goto :goto_47

    :cond_46
    const/4 v2, 0x1

    :goto_47
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    aput-object v2, v1, v8

    move-object/from16 v2, p0

    iget-object v8, v2, Landroidx/camera/core/impl/utils/e;->a:Landroidx/exifinterface/media/b;

    const-string v9, "GPSProcessingMethod"

    invoke-virtual {v8, v9}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8}, Landroidx/exifinterface/media/b;->j()[D

    move-result-object v10

    const-string v11, "GPSAltitude"

    const-wide/high16 v12, -0x4010000000000000L    # -1.0

    invoke-virtual {v8, v11, v12, v13}, Landroidx/exifinterface/media/b;->e(Ljava/lang/String;D)D

    move-result-wide v11

    const-string v13, "GPSAltitudeRef"

    const/4 v14, -0x1

    invoke-virtual {v8, v14, v13}, Landroidx/exifinterface/media/b;->f(ILjava/lang/String;)I

    move-result v13

    const-wide/16 v14, 0x0

    cmpl-double v16, v11, v14

    if-ltz v16, :cond_7b

    if-ltz v13, :cond_7b

    if-ne v13, v4, :cond_76

    const/4 v13, -0x1

    goto :goto_77

    :cond_76
    const/4 v13, 0x1

    :goto_77
    int-to-double v5, v13

    mul-double v11, v11, v5

    goto :goto_7c

    :cond_7b
    move-wide v11, v14

    :goto_7c
    const-string v5, "GPSSpeed"

    invoke-virtual {v8, v5, v14, v15}, Landroidx/exifinterface/media/b;->e(Ljava/lang/String;D)D

    move-result-wide v5

    const-string v13, "GPSSpeedRef"

    invoke-virtual {v8, v13}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v7, "K"

    if-nez v13, :cond_8d

    move-object v13, v7

    :cond_8d
    const-string v14, "GPSDateStamp"

    invoke-virtual {v8, v14}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "GPSTimeStamp"

    invoke-virtual {v8, v15}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    sget-object v17, Landroidx/camera/core/impl/utils/e;->d:Ljava/lang/ThreadLocal;

    const-wide/16 v18, -0x1

    if-nez v14, :cond_a4

    if-nez v15, :cond_a4

    :goto_a1
    move-wide/from16 v14, v18

    goto :goto_f1

    :cond_a4
    if-nez v15, :cond_b9

    :try_start_a6
    sget-object v15, Landroidx/camera/core/impl/utils/e;->b:Ljava/lang/ThreadLocal;

    invoke-virtual {v15}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/text/SimpleDateFormat;

    invoke-virtual {v15, v14}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v14

    invoke-virtual {v14}, Ljava/util/Date;->getTime()J

    move-result-wide v14

    goto :goto_f1

    :catch_b7
    nop

    goto :goto_a1

    :cond_b9
    if-nez v14, :cond_cc

    sget-object v14, Landroidx/camera/core/impl/utils/e;->c:Ljava/lang/ThreadLocal;

    invoke-virtual {v14}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/text/SimpleDateFormat;

    invoke-virtual {v14, v15}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v14

    invoke-virtual {v14}, Ljava/util/Date;->getTime()J

    move-result-wide v14
    :try_end_cb
    .catch Ljava/text/ParseException; {:try_start_a6 .. :try_end_cb} :catch_b7

    goto :goto_f1

    :cond_cc
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, " "

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_e3

    goto :goto_a1

    :cond_e3
    :try_start_e3
    invoke-virtual/range {v17 .. v17}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/text/SimpleDateFormat;

    invoke-virtual {v14, v4}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Date;->getTime()J

    move-result-wide v14
    :try_end_f1
    .catch Ljava/text/ParseException; {:try_start_e3 .. :try_end_f1} :catch_b7

    :goto_f1
    if-nez v10, :cond_f9

    const/4 v3, 0x0

    move-object/from16 v20, v8

    :goto_f6
    const/4 v4, 0x5

    goto/16 :goto_16f

    :cond_f9
    if-nez v9, :cond_fd

    const-string v9, "e"

    :cond_fd
    new-instance v4, Landroid/location/Location;

    invoke-direct {v4, v9}, Landroid/location/Location;-><init>(Ljava/lang/String;)V

    move-object/from16 v20, v8

    aget-wide v8, v10, v3

    invoke-virtual {v4, v8, v9}, Landroid/location/Location;->setLatitude(D)V

    const/4 v8, 0x1

    aget-wide v9, v10, v8

    invoke-virtual {v4, v9, v10}, Landroid/location/Location;->setLongitude(D)V

    const-wide/16 v8, 0x0

    cmpl-double v10, v11, v8

    if-eqz v10, :cond_118

    invoke-virtual {v4, v11, v12}, Landroid/location/Location;->setAltitude(D)V

    :cond_118
    cmpl-double v10, v5, v8

    if-eqz v10, :cond_166

    invoke-virtual {v13}, Ljava/lang/String;->hashCode()I

    move-result v8

    const/16 v9, 0x4b

    if-eq v8, v9, :cond_140

    const/16 v7, 0x4d

    if-eq v8, v7, :cond_137

    const/16 v3, 0x4e

    if-eq v8, v3, :cond_12d

    goto :goto_148

    :cond_12d
    const-string v3, "N"

    invoke-virtual {v13, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_148

    const/4 v3, 0x1

    goto :goto_149

    :cond_137
    const-string v7, "M"

    invoke-virtual {v13, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_148

    goto :goto_149

    :cond_140
    invoke-virtual {v13, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_148

    const/4 v3, 0x2

    goto :goto_149

    :cond_148
    :goto_148
    const/4 v3, -0x1

    :goto_149
    const-wide v7, 0x4001e540cc78e9f7L    # 2.23694

    if-eqz v3, :cond_15a

    const/4 v9, 0x1

    if-eq v3, v9, :cond_15c

    const-wide v9, 0x3fe3e2456f75d9a1L    # 0.621371

    :goto_158
    mul-double v5, v5, v9

    :cond_15a
    div-double/2addr v5, v7

    goto :goto_162

    :cond_15c
    const-wide v9, 0x3ff269984a0e410bL    # 1.15078

    goto :goto_158

    :goto_162
    double-to-float v3, v5

    invoke-virtual {v4, v3}, Landroid/location/Location;->setSpeed(F)V

    :cond_166
    cmp-long v3, v14, v18

    if-eqz v3, :cond_16d

    invoke-virtual {v4, v14, v15}, Landroid/location/Location;->setTime(J)V

    :cond_16d
    move-object v3, v4

    goto :goto_f6

    :goto_16f
    aput-object v3, v1, v4

    const-string v3, "DateTimeOriginal"

    move-object/from16 v4, v20

    invoke-virtual {v4, v3}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_17e

    :goto_17b
    move-wide/from16 v5, v18

    goto :goto_18f

    :cond_17e
    :try_start_17e
    invoke-virtual/range {v17 .. v17}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/text/SimpleDateFormat;

    invoke-virtual {v5, v3}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/Date;->getTime()J

    move-result-wide v5
    :try_end_18c
    .catch Ljava/text/ParseException; {:try_start_17e .. :try_end_18c} :catch_18d

    goto :goto_18f

    :catch_18d
    nop

    goto :goto_17b

    :goto_18f
    cmp-long v3, v5, v18

    if-nez v3, :cond_194

    goto :goto_1ad

    :cond_194
    const-string v3, "SubSecTimeOriginal"

    invoke-virtual {v4, v3}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_1ab

    :try_start_19c
    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    :goto_1a0
    const-wide/16 v9, 0x3e8

    cmp-long v3, v7, v9

    if-lez v3, :cond_1aa

    const-wide/16 v9, 0xa

    div-long/2addr v7, v9
    :try_end_1a9
    .catch Ljava/lang/NumberFormatException; {:try_start_19c .. :try_end_1a9} :catch_1ab

    goto :goto_1a0

    :cond_1aa
    add-long/2addr v5, v7

    :catch_1ab
    :cond_1ab
    move-wide/from16 v18, v5

    :goto_1ad
    invoke-static/range {v18 .. v19}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v5, 0x6

    aput-object v3, v1, v5

    const-string v3, "ImageDescription"

    invoke-virtual {v4, v3}, Landroidx/exifinterface/media/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x7

    aput-object v3, v1, v4

    const-string v3, "Exif{width=%s, height=%s, rotation=%d, isFlippedVertically=%s, isFlippedHorizontally=%s, location=%s, timestamp=%s, description=%s}"

    invoke-static {v0, v3, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
