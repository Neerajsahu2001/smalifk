.class public final Landroidx/camera/core/impl/utils/h;
.super Ljava/io/FilterOutputStream;
.source "ExifOutputStream.java"


# static fields
.field private static final g:[B


# instance fields
.field private final a:Landroidx/camera/core/impl/utils/g;

.field private final b:[B

.field private final c:Ljava/nio/ByteBuffer;

.field private d:I

.field private e:I

.field private f:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "Exif\u0000\u0000"

    sget-object v1, Landroidx/camera/core/impl/utils/f;->d:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/utils/h;->g:[B

    return-void
.end method

.method public constructor <init>(Ljava/io/OutputStream;Landroidx/camera/core/impl/utils/g;)V
    .registers 5

    new-instance v0, Ljava/io/BufferedOutputStream;

    const/high16 v1, 0x10000

    invoke-direct {v0, p1, v1}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;I)V

    invoke-direct {p0, v0}, Ljava/io/FilterOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 p1, 0x1

    new-array p1, p1, [B

    iput-object p1, p0, Landroidx/camera/core/impl/utils/h;->b:[B

    const/4 p1, 0x4

    invoke-static {p1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/impl/utils/h;->c:Ljava/nio/ByteBuffer;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/camera/core/impl/utils/h;->d:I

    iput-object p2, p0, Landroidx/camera/core/impl/utils/h;->a:Landroidx/camera/core/impl/utils/g;

    return-void
.end method


# virtual methods
.method public final write(I)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    and-int/lit16 p1, p1, 0xff

    int-to-byte p1, p1

    iget-object v0, p0, Landroidx/camera/core/impl/utils/h;->b:[B

    const/4 v1, 0x0

    aput-byte p1, v0, v1

    invoke-virtual {p0, v0}, Landroidx/camera/core/impl/utils/h;->write([B)V

    return-void
.end method

.method public final write([B)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    array-length v0, p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0}, Landroidx/camera/core/impl/utils/h;->write([BII)V

    return-void
.end method

.method public final write([BII)V
    .registers 21
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    :goto_8
    iget v4, v0, Landroidx/camera/core/impl/utils/h;->e:I

    const/4 v5, 0x2

    if-gtz v4, :cond_15

    iget v6, v0, Landroidx/camera/core/impl/utils/h;->f:I

    if-gtz v6, :cond_15

    iget v6, v0, Landroidx/camera/core/impl/utils/h;->d:I

    if-eq v6, v5, :cond_382

    :cond_15
    if-lez v3, :cond_382

    if-lez v4, :cond_24

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    sub-int/2addr v3, v4

    iget v6, v0, Landroidx/camera/core/impl/utils/h;->e:I

    sub-int/2addr v6, v4

    iput v6, v0, Landroidx/camera/core/impl/utils/h;->e:I

    add-int/2addr v2, v4

    :cond_24
    iget v4, v0, Landroidx/camera/core/impl/utils/h;->f:I

    if-lez v4, :cond_38

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    iget-object v6, v0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    invoke-virtual {v6, v1, v2, v4}, Ljava/io/OutputStream;->write([BII)V

    sub-int/2addr v3, v4

    iget v6, v0, Landroidx/camera/core/impl/utils/h;->f:I

    sub-int/2addr v6, v4

    iput v6, v0, Landroidx/camera/core/impl/utils/h;->f:I

    add-int/2addr v2, v4

    :cond_38
    if-nez v3, :cond_3b

    return-void

    :cond_3b
    iget v4, v0, Landroidx/camera/core/impl/utils/h;->d:I

    const/4 v6, 0x1

    const/16 v7, -0x1f

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v10, v0, Landroidx/camera/core/impl/utils/h;->c:Ljava/nio/ByteBuffer;

    if-eqz v4, :cond_c6

    if-eq v4, v6, :cond_49

    goto :goto_8

    :cond_49
    invoke-virtual {v10}, Ljava/nio/Buffer;->position()I

    move-result v4

    rsub-int/lit8 v4, v4, 0x4

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual {v10, v1, v2, v4}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    add-int/2addr v2, v4

    sub-int/2addr v3, v4

    invoke-virtual {v10}, Ljava/nio/Buffer;->position()I

    move-result v4

    if-ne v4, v5, :cond_72

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    const/16 v6, -0x27

    if-ne v4, v6, :cond_72

    iget-object v4, v0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v6

    invoke-virtual {v4, v6, v8, v5}, Ljava/io/OutputStream;->write([BII)V

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    :cond_72
    invoke-virtual {v10}, Ljava/nio/Buffer;->position()I

    move-result v4

    if-ge v4, v9, :cond_79

    return-void

    :cond_79
    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    const v6, 0xffff

    if-ne v4, v7, :cond_90

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    and-int/2addr v4, v6

    sub-int/2addr v4, v5

    iput v4, v0, Landroidx/camera/core/impl/utils/h;->e:I

    iput v5, v0, Landroidx/camera/core/impl/utils/h;->d:I

    goto :goto_c1

    :cond_90
    const/16 v7, -0x40

    if-lt v4, v7, :cond_b0

    const/16 v7, -0x31

    if-gt v4, v7, :cond_b0

    const/16 v7, -0x3c

    if-eq v4, v7, :cond_b0

    const/16 v7, -0x38

    if-eq v4, v7, :cond_b0

    const/16 v7, -0x34

    if-eq v4, v7, :cond_b0

    iget-object v4, v0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v6

    invoke-virtual {v4, v6, v8, v9}, Ljava/io/OutputStream;->write([BII)V

    iput v5, v0, Landroidx/camera/core/impl/utils/h;->d:I

    goto :goto_c1

    :cond_b0
    iget-object v4, v0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v7

    invoke-virtual {v4, v7, v8, v9}, Ljava/io/OutputStream;->write([BII)V

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    and-int/2addr v4, v6

    sub-int/2addr v4, v5

    iput v4, v0, Landroidx/camera/core/impl/utils/h;->f:I

    :goto_c1
    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    goto/16 :goto_8

    :cond_c6
    invoke-virtual {v10}, Ljava/nio/Buffer;->position()I

    move-result v4

    rsub-int/lit8 v4, v4, 0x2

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual {v10, v1, v2, v4}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    add-int/2addr v2, v4

    sub-int/2addr v3, v4

    invoke-virtual {v10}, Ljava/nio/Buffer;->position()I

    move-result v4

    if-ge v4, v5, :cond_dc

    return-void

    :cond_dc
    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    const/16 v11, -0x28

    if-ne v4, v11, :cond_37a

    iget-object v4, v0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v11

    invoke-virtual {v4, v11, v8, v5}, Ljava/io/OutputStream;->write([BII)V

    iput v6, v0, Landroidx/camera/core/impl/utils/h;->d:I

    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    new-instance v4, Landroidx/camera/core/impl/utils/a;

    iget-object v10, v0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    sget-object v11, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    invoke-direct {v4, v10, v11}, Landroidx/camera/core/impl/utils/a;-><init>(Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V

    invoke-virtual {v4, v7}, Landroidx/camera/core/impl/utils/a;->f(S)V

    new-array v7, v9, [I

    new-array v10, v9, [I

    sget-object v11, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    const/4 v12, 0x0

    :goto_108
    iget-object v13, v0, Landroidx/camera/core/impl/utils/h;->a:Landroidx/camera/core/impl/utils/g;

    if-ge v12, v9, :cond_126

    aget-object v14, v11, v12

    const/4 v15, 0x0

    :goto_10f
    sget-object v16, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    if-ge v15, v9, :cond_121

    invoke-virtual {v13, v15}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v9

    iget-object v5, v14, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    invoke-interface {v9, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v15, v15, 0x1

    const/4 v5, 0x2

    const/4 v9, 0x4

    goto :goto_10f

    :cond_121
    add-int/lit8 v12, v12, 0x1

    const/4 v5, 0x2

    const/4 v9, 0x4

    goto :goto_108

    :cond_126
    invoke-virtual {v13, v6}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Map;->isEmpty()Z

    move-result v5

    const-wide/16 v11, 0x0

    if-nez v5, :cond_147

    invoke-virtual {v13, v8}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v5

    sget-object v9, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    aget-object v9, v9, v6

    iget-object v9, v9, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v14

    invoke-static {v11, v12, v14}, Landroidx/camera/core/impl/utils/f;->a(JLjava/nio/ByteOrder;)Landroidx/camera/core/impl/utils/f;

    move-result-object v14

    invoke-interface {v5, v9, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_147
    const/4 v5, 0x2

    invoke-virtual {v13, v5}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/Map;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_167

    invoke-virtual {v13, v8}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v9

    sget-object v14, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    aget-object v14, v14, v5

    iget-object v5, v14, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v14

    invoke-static {v11, v12, v14}, Landroidx/camera/core/impl/utils/f;->a(JLjava/nio/ByteOrder;)Landroidx/camera/core/impl/utils/f;

    move-result-object v14

    invoke-interface {v9, v5, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_167
    const/4 v5, 0x3

    invoke-virtual {v13, v5}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/Map;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_187

    invoke-virtual {v13, v6}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v9

    sget-object v14, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    aget-object v14, v14, v5

    iget-object v14, v14, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v15

    invoke-static {v11, v12, v15}, Landroidx/camera/core/impl/utils/f;->a(JLjava/nio/ByteOrder;)Landroidx/camera/core/impl/utils/f;

    move-result-object v15

    invoke-interface {v9, v14, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_187
    const/4 v9, 0x0

    :goto_188
    sget-object v14, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    const/4 v14, 0x4

    if-ge v9, v14, :cond_1cb

    invoke-virtual {v13, v9}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v14

    invoke-interface {v14}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v14

    invoke-interface {v14}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v14

    const/4 v15, 0x0

    :goto_19a
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_1c0

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/util/Map$Entry;

    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v11, v16

    check-cast v11, Landroidx/camera/core/impl/utils/f;

    sget-object v12, Landroidx/camera/core/impl/utils/f;->f:[I

    iget v5, v11, Landroidx/camera/core/impl/utils/f;->a:I

    aget v5, v12, v5

    iget v11, v11, Landroidx/camera/core/impl/utils/f;->b:I

    mul-int v5, v5, v11

    const/4 v11, 0x4

    if-le v5, v11, :cond_1bc

    add-int/2addr v15, v5

    :cond_1bc
    const/4 v5, 0x3

    const-wide/16 v11, 0x0

    goto :goto_19a

    :cond_1c0
    aget v5, v10, v9

    add-int/2addr v5, v15

    aput v5, v10, v9

    add-int/lit8 v9, v9, 0x1

    const/4 v5, 0x3

    const-wide/16 v11, 0x0

    goto :goto_188

    :cond_1cb
    const/16 v5, 0x8

    const/4 v9, 0x0

    :goto_1ce
    sget-object v11, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    const/4 v11, 0x4

    if-ge v9, v11, :cond_1f2

    invoke-virtual {v13, v9}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/Map;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_1ef

    aput v5, v7, v9

    invoke-virtual {v13, v9}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/Map;->size()I

    move-result v11

    mul-int/lit8 v11, v11, 0xc

    add-int/lit8 v11, v11, 0x6

    aget v12, v10, v9

    add-int/2addr v11, v12

    add-int/2addr v5, v11

    :cond_1ef
    add-int/lit8 v9, v9, 0x1

    goto :goto_1ce

    :cond_1f2
    add-int/lit8 v5, v5, 0x8

    invoke-virtual {v13, v6}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/Map;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_216

    invoke-virtual {v13, v8}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v9

    sget-object v10, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    aget-object v10, v10, v6

    iget-object v10, v10, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    aget v11, v7, v6

    int-to-long v11, v11

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v14

    invoke-static {v11, v12, v14}, Landroidx/camera/core/impl/utils/f;->a(JLjava/nio/ByteOrder;)Landroidx/camera/core/impl/utils/f;

    move-result-object v11

    invoke-interface {v9, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_216
    const/4 v9, 0x2

    invoke-virtual {v13, v9}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Map;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_239

    invoke-virtual {v13, v8}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v10

    sget-object v11, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    aget-object v11, v11, v9

    iget-object v11, v11, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    aget v12, v7, v9

    int-to-long v14, v12

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v9

    invoke-static {v14, v15, v9}, Landroidx/camera/core/impl/utils/f;->a(JLjava/nio/ByteOrder;)Landroidx/camera/core/impl/utils/f;

    move-result-object v9

    invoke-interface {v10, v11, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_239
    const/4 v9, 0x3

    invoke-virtual {v13, v9}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Map;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_25c

    invoke-virtual {v13, v6}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v6

    sget-object v10, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    aget-object v10, v10, v9

    iget-object v10, v10, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    aget v9, v7, v9

    int-to-long v11, v9

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v9

    invoke-static {v11, v12, v9}, Landroidx/camera/core/impl/utils/f;->a(JLjava/nio/ByteOrder;)Landroidx/camera/core/impl/utils/f;

    move-result-object v9

    invoke-interface {v6, v10, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_25c
    int-to-short v5, v5

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/utils/a;->f(S)V

    sget-object v5, Landroidx/camera/core/impl/utils/h;->g:[B

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/utils/a;->write([B)V

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v5

    sget-object v6, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    if-ne v5, v6, :cond_270

    const/16 v5, 0x4d4d

    goto :goto_272

    :cond_270
    const/16 v5, 0x4949

    :goto_272
    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/utils/a;->f(S)V

    invoke-virtual {v13}, Landroidx/camera/core/impl/utils/g;->c()Ljava/nio/ByteOrder;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/utils/a;->c(Ljava/nio/ByteOrder;)V

    const/16 v5, 0x2a

    int-to-short v5, v5

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/utils/a;->f(S)V

    const-wide/16 v5, 0x8

    long-to-int v6, v5

    invoke-virtual {v4, v6}, Landroidx/camera/core/impl/utils/a;->e(I)V

    const/4 v5, 0x0

    :goto_289
    sget-object v6, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    const/4 v6, 0x4

    if-ge v5, v6, :cond_373

    invoke-virtual {v13, v5}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Map;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_36c

    invoke-virtual {v13, v5}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Map;->size()I

    move-result v6

    int-to-short v6, v6

    invoke-virtual {v4, v6}, Landroidx/camera/core/impl/utils/a;->f(S)V

    aget v6, v7, v5

    const/4 v9, 0x2

    add-int/2addr v6, v9

    invoke-virtual {v13, v5}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Map;->size()I

    move-result v10

    mul-int/lit8 v10, v10, 0xc

    add-int/2addr v6, v10

    const/4 v10, 0x4

    add-int/2addr v6, v10

    invoke-virtual {v13, v5}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_2c1
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_33b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/util/Map$Entry;

    sget-object v12, Landroidx/camera/core/impl/utils/g$b;->f:Ljava/util/ArrayList;

    invoke-interface {v12, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/util/HashMap;

    invoke-interface {v11}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroidx/camera/core/impl/utils/i;

    new-instance v14, Ljava/lang/StringBuilder;

    const-string v15, "Tag not supported: "

    invoke-direct {v14, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {v11}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v15, ". Tag needs to be ported from ExifInterface to ExifData."

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-static {v12, v14}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v11}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroidx/camera/core/impl/utils/f;

    sget-object v14, Landroidx/camera/core/impl/utils/f;->f:[I

    iget v15, v11, Landroidx/camera/core/impl/utils/f;->a:I

    aget v14, v14, v15

    iget v15, v11, Landroidx/camera/core/impl/utils/f;->b:I

    mul-int v14, v14, v15

    iget v12, v12, Landroidx/camera/core/impl/utils/i;->a:I

    int-to-short v12, v12

    invoke-virtual {v4, v12}, Landroidx/camera/core/impl/utils/a;->f(S)V

    iget v12, v11, Landroidx/camera/core/impl/utils/f;->a:I

    int-to-short v12, v12

    invoke-virtual {v4, v12}, Landroidx/camera/core/impl/utils/a;->f(S)V

    invoke-virtual {v4, v15}, Landroidx/camera/core/impl/utils/a;->e(I)V

    const/4 v12, 0x4

    if-le v14, v12, :cond_325

    move-object v15, v10

    int-to-long v9, v6

    long-to-int v10, v9

    invoke-virtual {v4, v10}, Landroidx/camera/core/impl/utils/a;->e(I)V

    add-int/2addr v6, v14

    goto :goto_338

    :cond_325
    move-object v15, v10

    iget-object v9, v11, Landroidx/camera/core/impl/utils/f;->c:[B

    invoke-virtual {v4, v9}, Landroidx/camera/core/impl/utils/a;->write([B)V

    if-ge v14, v12, :cond_338

    :goto_32d
    if-ge v14, v12, :cond_338

    iget-object v9, v4, Landroidx/camera/core/impl/utils/a;->a:Ljava/io/OutputStream;

    invoke-virtual {v9, v8}, Ljava/io/OutputStream;->write(I)V

    add-int/lit8 v14, v14, 0x1

    const/4 v12, 0x4

    goto :goto_32d

    :cond_338
    :goto_338
    move-object v10, v15

    const/4 v9, 0x2

    goto :goto_2c1

    :cond_33b
    const-wide/16 v9, 0x0

    long-to-int v6, v9

    invoke-virtual {v4, v6}, Landroidx/camera/core/impl/utils/a;->e(I)V

    invoke-virtual {v13, v5}, Landroidx/camera/core/impl/utils/g;->b(I)Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_34d
    :goto_34d
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_36a

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/util/Map$Entry;

    invoke-interface {v11}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroidx/camera/core/impl/utils/f;

    iget-object v11, v11, Landroidx/camera/core/impl/utils/f;->c:[B

    array-length v12, v11

    const/4 v14, 0x4

    if-le v12, v14, :cond_34d

    array-length v12, v11

    invoke-virtual {v4, v11, v8, v12}, Landroidx/camera/core/impl/utils/a;->write([BII)V

    goto :goto_34d

    :cond_36a
    :goto_36a
    const/4 v14, 0x4

    goto :goto_36f

    :cond_36c
    const-wide/16 v9, 0x0

    goto :goto_36a

    :goto_36f
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_289

    :cond_373
    sget-object v5, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/utils/a;->c(Ljava/nio/ByteOrder;)V

    goto/16 :goto_8

    :cond_37a
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Not a valid jpeg image, cannot write exif"

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_382
    if-lez v3, :cond_389

    iget-object v4, v0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    invoke-virtual {v4, v1, v2, v3}, Ljava/io/OutputStream;->write([BII)V

    :cond_389
    return-void
.end method
