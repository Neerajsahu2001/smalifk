.class public final Landroidx/camera/core/impl/utils/g;
.super Ljava/lang/Object;
.source "ExifData.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/utils/g$b;,
        Landroidx/camera/core/impl/utils/g$c;
    }
.end annotation


# static fields
.field static final c:[Landroidx/camera/core/impl/utils/i;

.field static final d:[[Landroidx/camera/core/impl/utils/i;

.field static final e:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroidx/camera/core/impl/utils/f;",
            ">;>;"
        }
    .end annotation
.end field

.field private final b:Ljava/nio/ByteOrder;


# direct methods
.method static constructor <clinit>()V
    .registers 49

    new-instance v0, Landroidx/camera/core/impl/utils/i;

    const-string v1, "ImageWidth"

    const/16 v2, 0x100

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2, v3, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;III)V

    new-instance v1, Landroidx/camera/core/impl/utils/i;

    const-string v2, "ImageLength"

    const/16 v5, 0x101

    invoke-direct {v1, v2, v5, v3, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;III)V

    new-instance v2, Landroidx/camera/core/impl/utils/i;

    const-string v5, "Make"

    const/16 v6, 0x10f

    const/4 v7, 0x2

    invoke-direct {v2, v5, v6, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v5, Landroidx/camera/core/impl/utils/i;

    const-string v6, "Model"

    const/16 v8, 0x110

    invoke-direct {v5, v6, v8, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v6, Landroidx/camera/core/impl/utils/i;

    const-string v8, "Orientation"

    const/16 v9, 0x112

    invoke-direct {v6, v8, v9, v3}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v8, Landroidx/camera/core/impl/utils/i;

    const-string v9, "XResolution"

    const/16 v10, 0x11a

    const/4 v11, 0x5

    invoke-direct {v8, v9, v10, v11}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v9, Landroidx/camera/core/impl/utils/i;

    const-string v10, "YResolution"

    const/16 v12, 0x11b

    invoke-direct {v9, v10, v12, v11}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v10, Landroidx/camera/core/impl/utils/i;

    const-string v12, "ResolutionUnit"

    const/16 v13, 0x128

    invoke-direct {v10, v12, v13, v3}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v12, Landroidx/camera/core/impl/utils/i;

    const-string v13, "Software"

    const/16 v14, 0x131

    invoke-direct {v12, v13, v14, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v14, "DateTime"

    const/16 v15, 0x132

    invoke-direct {v13, v14, v15, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v14, Landroidx/camera/core/impl/utils/i;

    const-string v15, "YCbCrPositioning"

    const/16 v11, 0x213

    invoke-direct {v14, v15, v11, v3}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v11, Landroidx/camera/core/impl/utils/i;

    const-string v15, "SubIFDPointer"

    const/16 v3, 0x14a

    invoke-direct {v11, v15, v3, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v3, Landroidx/camera/core/impl/utils/i;

    const-string v7, "ExifIFDPointer"

    move-object/from16 v16, v15

    const v15, 0x8769

    invoke-direct {v3, v7, v15, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v15, Landroidx/camera/core/impl/utils/i;

    move-object/from16 v17, v7

    const-string v7, "GPSInfoIFDPointer"

    move-object/from16 v18, v3

    const v3, 0x8825

    invoke-direct {v15, v7, v3, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    const/16 v3, 0xe

    new-array v4, v3, [Landroidx/camera/core/impl/utils/i;

    const/4 v3, 0x0

    aput-object v0, v4, v3

    const/4 v0, 0x1

    aput-object v1, v4, v0

    const/4 v1, 0x2

    aput-object v2, v4, v1

    const/4 v1, 0x3

    aput-object v5, v4, v1

    const/4 v1, 0x4

    aput-object v6, v4, v1

    const/4 v1, 0x5

    aput-object v8, v4, v1

    const/4 v1, 0x6

    aput-object v9, v4, v1

    const/4 v2, 0x7

    aput-object v10, v4, v2

    const/16 v5, 0x8

    aput-object v12, v4, v5

    const/16 v6, 0x9

    aput-object v13, v4, v6

    const/16 v8, 0xa

    aput-object v14, v4, v8

    const/16 v9, 0xb

    aput-object v11, v4, v9

    const/16 v10, 0xc

    aput-object v18, v4, v10

    const/16 v11, 0xd

    aput-object v15, v4, v11

    new-instance v12, Landroidx/camera/core/impl/utils/i;

    const-string v13, "ExposureTime"

    const v14, 0x829a

    const/4 v15, 0x5

    invoke-direct {v12, v13, v14, v15}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v14, Landroidx/camera/core/impl/utils/i;

    const-string v11, "FNumber"

    const v10, 0x829d

    invoke-direct {v14, v11, v10, v15}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v10, Landroidx/camera/core/impl/utils/i;

    const-string v15, "ExposureProgram"

    const v9, 0x8822

    const/4 v6, 0x3

    invoke-direct {v10, v15, v9, v6}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v9, Landroidx/camera/core/impl/utils/i;

    const-string v15, "PhotographicSensitivity"

    const v5, 0x8827

    invoke-direct {v9, v15, v5, v6}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v5, Landroidx/camera/core/impl/utils/i;

    const-string v15, "SensitivityType"

    const v1, 0x8830

    invoke-direct {v5, v15, v1, v6}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v1, Landroidx/camera/core/impl/utils/i;

    const-string v6, "ExifVersion"

    const v15, 0x9000

    const/4 v0, 0x2

    invoke-direct {v1, v6, v15, v0}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v6, Landroidx/camera/core/impl/utils/i;

    const-string v15, "DateTimeOriginal"

    const v3, 0x9003

    invoke-direct {v6, v15, v3, v0}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v3, Landroidx/camera/core/impl/utils/i;

    const-string v15, "DateTimeDigitized"

    const v8, 0x9004

    invoke-direct {v3, v15, v8, v0}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v0, Landroidx/camera/core/impl/utils/i;

    const-string v8, "ComponentsConfiguration"

    const v15, 0x9101

    invoke-direct {v0, v8, v15, v2}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v8, Landroidx/camera/core/impl/utils/i;

    const-string v15, "ShutterSpeedValue"

    const v2, 0x9201

    move-object/from16 v20, v11

    const/16 v11, 0xa

    invoke-direct {v8, v15, v2, v11}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v2, Landroidx/camera/core/impl/utils/i;

    const-string v15, "ApertureValue"

    const v11, 0x9202

    move-object/from16 v21, v13

    const/4 v13, 0x5

    invoke-direct {v2, v15, v11, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v11, Landroidx/camera/core/impl/utils/i;

    const-string v13, "BrightnessValue"

    const v15, 0x9203

    move-object/from16 v22, v4

    const/16 v4, 0xa

    invoke-direct {v11, v13, v15, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v15, "ExposureBiasValue"

    move-object/from16 v23, v7

    const v7, 0x9204

    invoke-direct {v13, v15, v7, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v7, "MaxApertureValue"

    const v15, 0x9205

    move-object/from16 v24, v13

    const/4 v13, 0x5

    invoke-direct {v4, v7, v15, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v7, Landroidx/camera/core/impl/utils/i;

    const-string v13, "MeteringMode"

    const v15, 0x9207

    move-object/from16 v25, v4

    const/4 v4, 0x3

    invoke-direct {v7, v13, v15, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v15, "LightSource"

    move-object/from16 v26, v7

    const v7, 0x9208

    invoke-direct {v13, v15, v7, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v7, Landroidx/camera/core/impl/utils/i;

    const-string v15, "Flash"

    move-object/from16 v27, v13

    const v13, 0x9209

    invoke-direct {v7, v15, v13, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v13, "FocalLength"

    const v15, 0x920a

    move-object/from16 v28, v7

    const/4 v7, 0x5

    invoke-direct {v4, v13, v15, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v7, Landroidx/camera/core/impl/utils/i;

    const-string v13, "SubSecTime"

    const v15, 0x9290

    move-object/from16 v29, v4

    const/4 v4, 0x2

    invoke-direct {v7, v13, v15, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v15, "SubSecTimeOriginal"

    move-object/from16 v30, v7

    const v7, 0x9291

    invoke-direct {v13, v15, v7, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v7, Landroidx/camera/core/impl/utils/i;

    const-string v15, "SubSecTimeDigitized"

    move-object/from16 v31, v13

    const v13, 0x9292

    invoke-direct {v7, v15, v13, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v13, "FlashpixVersion"

    const v15, 0xa000

    move-object/from16 v32, v7

    const/4 v7, 0x7

    invoke-direct {v4, v13, v15, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v7, Landroidx/camera/core/impl/utils/i;

    const-string v13, "ColorSpace"

    const v15, 0xa001

    move-object/from16 v33, v4

    const/4 v4, 0x3

    invoke-direct {v7, v13, v15, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v15, "PixelXDimension"

    move-object/from16 v34, v7

    const v7, 0xa002

    move-object/from16 v35, v11

    const/4 v11, 0x4

    invoke-direct {v13, v15, v7, v4, v11}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;III)V

    new-instance v7, Landroidx/camera/core/impl/utils/i;

    const-string v15, "PixelYDimension"

    move-object/from16 v36, v13

    const v13, 0xa003

    invoke-direct {v7, v15, v13, v4, v11}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;III)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v15, "InteroperabilityIFDPointer"

    const v4, 0xa005

    invoke-direct {v13, v15, v4, v11}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v11, Landroidx/camera/core/impl/utils/i;

    const-string v4, "FocalPlaneResolutionUnit"

    move-object/from16 v37, v15

    const v15, 0xa210

    move-object/from16 v38, v13

    const/4 v13, 0x3

    invoke-direct {v11, v4, v15, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v15, "SensingMethod"

    move-object/from16 v39, v11

    const v11, 0xa217

    invoke-direct {v4, v15, v11, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v11, Landroidx/camera/core/impl/utils/i;

    const-string v13, "FileSource"

    const v15, 0xa300

    move-object/from16 v40, v4

    const/4 v4, 0x7

    invoke-direct {v11, v13, v15, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v15, "SceneType"

    move-object/from16 v41, v11

    const v11, 0xa301

    invoke-direct {v13, v15, v11, v4}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v11, "CustomRendered"

    const v15, 0xa401

    move-object/from16 v42, v13

    const/4 v13, 0x3

    invoke-direct {v4, v11, v15, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v11, Landroidx/camera/core/impl/utils/i;

    const-string v15, "ExposureMode"

    move-object/from16 v43, v4

    const v4, 0xa402

    invoke-direct {v11, v15, v4, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v15, "WhiteBalance"

    move-object/from16 v44, v11

    const v11, 0xa403

    invoke-direct {v4, v15, v11, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v11, Landroidx/camera/core/impl/utils/i;

    const-string v15, "SceneCaptureType"

    move-object/from16 v45, v4

    const v4, 0xa406

    invoke-direct {v11, v15, v4, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v15, "Contrast"

    move-object/from16 v46, v11

    const v11, 0xa408

    invoke-direct {v4, v15, v11, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v11, Landroidx/camera/core/impl/utils/i;

    const-string v15, "Saturation"

    move-object/from16 v47, v4

    const v4, 0xa409

    invoke-direct {v11, v15, v4, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v15, "Sharpness"

    move-object/from16 v48, v11

    const v11, 0xa40a

    invoke-direct {v4, v15, v11, v13}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    const/16 v11, 0x25

    new-array v11, v11, [Landroidx/camera/core/impl/utils/i;

    const/4 v15, 0x0

    aput-object v12, v11, v15

    const/4 v12, 0x1

    aput-object v14, v11, v12

    const/4 v12, 0x2

    aput-object v10, v11, v12

    aput-object v9, v11, v13

    const/4 v9, 0x4

    aput-object v5, v11, v9

    const/4 v5, 0x5

    aput-object v1, v11, v5

    const/4 v1, 0x6

    aput-object v6, v11, v1

    const/4 v1, 0x7

    aput-object v3, v11, v1

    const/16 v1, 0x8

    aput-object v0, v11, v1

    const/16 v0, 0x9

    aput-object v8, v11, v0

    const/16 v0, 0xa

    aput-object v2, v11, v0

    const/16 v0, 0xb

    aput-object v35, v11, v0

    const/16 v0, 0xc

    aput-object v24, v11, v0

    const/16 v0, 0xd

    aput-object v25, v11, v0

    const/16 v0, 0xe

    aput-object v26, v11, v0

    const/16 v0, 0xf

    aput-object v27, v11, v0

    const/16 v0, 0x10

    aput-object v28, v11, v0

    const/16 v1, 0x11

    aput-object v29, v11, v1

    const/16 v1, 0x12

    aput-object v30, v11, v1

    const/16 v1, 0x13

    aput-object v31, v11, v1

    const/16 v1, 0x14

    aput-object v32, v11, v1

    const/16 v1, 0x15

    aput-object v33, v11, v1

    const/16 v1, 0x16

    aput-object v34, v11, v1

    const/16 v1, 0x17

    aput-object v36, v11, v1

    const/16 v2, 0x18

    aput-object v7, v11, v2

    const/16 v2, 0x19

    aput-object v38, v11, v2

    const/16 v3, 0x1a

    aput-object v39, v11, v3

    const/16 v3, 0x1b

    aput-object v40, v11, v3

    const/16 v3, 0x1c

    aput-object v41, v11, v3

    const/16 v3, 0x1d

    aput-object v42, v11, v3

    const/16 v3, 0x1e

    aput-object v43, v11, v3

    const/16 v3, 0x1f

    aput-object v44, v11, v3

    const/16 v3, 0x20

    aput-object v45, v11, v3

    const/16 v3, 0x21

    aput-object v46, v11, v3

    const/16 v3, 0x22

    aput-object v47, v11, v3

    const/16 v3, 0x23

    aput-object v48, v11, v3

    const/16 v3, 0x24

    aput-object v4, v11, v3

    new-instance v3, Landroidx/camera/core/impl/utils/i;

    const-string v4, "GPSVersionID"

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v3, v4, v5, v6}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v5, "GPSLatitudeRef"

    const/4 v7, 0x2

    invoke-direct {v4, v5, v6, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v5, Landroidx/camera/core/impl/utils/i;

    const-string v6, "GPSLatitude"

    const/4 v8, 0x5

    const/16 v9, 0xa

    invoke-direct {v5, v6, v7, v8, v9}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;III)V

    new-instance v6, Landroidx/camera/core/impl/utils/i;

    const-string v10, "GPSLongitudeRef"

    const/4 v12, 0x3

    invoke-direct {v6, v10, v12, v7}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v7, Landroidx/camera/core/impl/utils/i;

    const-string v10, "GPSLongitude"

    const/4 v12, 0x4

    invoke-direct {v7, v10, v12, v8, v9}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;III)V

    new-instance v9, Landroidx/camera/core/impl/utils/i;

    const-string v10, "GPSAltitudeRef"

    const/4 v12, 0x1

    invoke-direct {v9, v10, v8, v12}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v10, Landroidx/camera/core/impl/utils/i;

    const-string v12, "GPSAltitude"

    const/4 v13, 0x6

    invoke-direct {v10, v12, v13, v8}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v12, Landroidx/camera/core/impl/utils/i;

    const-string v13, "GPSTimeStamp"

    const/4 v14, 0x7

    invoke-direct {v12, v13, v14, v8}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v8, Landroidx/camera/core/impl/utils/i;

    const-string v14, "GPSSpeedRef"

    const/16 v2, 0xc

    const/4 v15, 0x2

    invoke-direct {v8, v14, v2, v15}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v2, Landroidx/camera/core/impl/utils/i;

    const-string v14, "GPSTrackRef"

    const/16 v1, 0xe

    invoke-direct {v2, v14, v1, v15}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v1, Landroidx/camera/core/impl/utils/i;

    const-string v14, "GPSImgDirectionRef"

    invoke-direct {v1, v14, v0, v15}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v0, Landroidx/camera/core/impl/utils/i;

    const-string v14, "GPSDestBearingRef"

    move-object/from16 v19, v13

    const/16 v13, 0x17

    invoke-direct {v0, v14, v13, v15}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v13, Landroidx/camera/core/impl/utils/i;

    const-string v14, "GPSDestDistanceRef"

    move-object/from16 v24, v11

    const/16 v11, 0x19

    invoke-direct {v13, v14, v11, v15}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    const/16 v11, 0xd

    new-array v11, v11, [Landroidx/camera/core/impl/utils/i;

    const/4 v14, 0x0

    aput-object v3, v11, v14

    const/4 v3, 0x1

    aput-object v4, v11, v3

    aput-object v5, v11, v15

    const/4 v3, 0x3

    aput-object v6, v11, v3

    const/4 v3, 0x4

    aput-object v7, v11, v3

    const/4 v4, 0x5

    aput-object v9, v11, v4

    const/4 v4, 0x6

    aput-object v10, v11, v4

    const/4 v4, 0x7

    aput-object v12, v11, v4

    const/16 v4, 0x8

    aput-object v8, v11, v4

    const/16 v4, 0x9

    aput-object v2, v11, v4

    const/16 v2, 0xa

    aput-object v1, v11, v2

    const/16 v1, 0xb

    aput-object v0, v11, v1

    const/16 v0, 0xc

    aput-object v13, v11, v0

    new-instance v0, Landroidx/camera/core/impl/utils/i;

    move-object/from16 v1, v16

    const/16 v2, 0x14a

    invoke-direct {v0, v1, v2, v3}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v1, Landroidx/camera/core/impl/utils/i;

    move-object/from16 v2, v17

    const v4, 0x8769

    invoke-direct {v1, v2, v4, v3}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v2, Landroidx/camera/core/impl/utils/i;

    move-object/from16 v4, v23

    const v5, 0x8825

    invoke-direct {v2, v4, v5, v3}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    move-object/from16 v5, v37

    const v6, 0xa005

    invoke-direct {v4, v5, v6, v3}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-array v5, v3, [Landroidx/camera/core/impl/utils/i;

    const/4 v6, 0x0

    aput-object v0, v5, v6

    const/4 v0, 0x1

    aput-object v1, v5, v0

    const/4 v1, 0x2

    aput-object v2, v5, v1

    const/4 v2, 0x3

    aput-object v4, v5, v2

    sput-object v5, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    new-instance v4, Landroidx/camera/core/impl/utils/i;

    const-string v5, "InteroperabilityIndex"

    invoke-direct {v4, v5, v0, v1}, Landroidx/camera/core/impl/utils/i;-><init>(Ljava/lang/String;II)V

    new-array v5, v0, [Landroidx/camera/core/impl/utils/i;

    aput-object v4, v5, v6

    new-array v3, v3, [[Landroidx/camera/core/impl/utils/i;

    aput-object v22, v3, v6

    aput-object v24, v3, v0

    aput-object v11, v3, v1

    aput-object v5, v3, v2

    sput-object v3, Landroidx/camera/core/impl/utils/g;->d:[[Landroidx/camera/core/impl/utils/i;

    new-instance v0, Ljava/util/HashSet;

    move-object/from16 v3, v19

    move-object/from16 v2, v20

    move-object/from16 v1, v21

    filled-new-array {v2, v1, v3}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    sput-object v0, Landroidx/camera/core/impl/utils/g;->e:Ljava/util/HashSet;

    return-void
.end method

.method constructor <init>(Ljava/nio/ByteOrder;Ljava/util/ArrayList;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    const-string v1, "Malformed attributes list. Number of IFDs mismatch."

    invoke-static {v0, v1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    iput-object p1, p0, Landroidx/camera/core/impl/utils/g;->b:Ljava/nio/ByteOrder;

    iput-object p2, p0, Landroidx/camera/core/impl/utils/g;->a:Ljava/util/List;

    return-void
.end method

.method public static a()Landroidx/camera/core/impl/utils/g$b;
    .registers 4

    new-instance v0, Landroidx/camera/core/impl/utils/g$b;

    sget-object v1, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    invoke-direct {v0, v1}, Landroidx/camera/core/impl/utils/g$b;-><init>(Ljava/nio/ByteOrder;)V

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "Orientation"

    invoke-virtual {v0, v3, v2}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "XResolution"

    const-string v3, "72/1"

    invoke-virtual {v0, v2, v3}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "YResolution"

    invoke-virtual {v0, v2, v3}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "ResolutionUnit"

    invoke-virtual {v0, v3, v2}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "YCbCrPositioning"

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v2, v1}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "Make"

    sget-object v2, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "Model"

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method final b(I)Ljava/util/Map;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroidx/camera/core/impl/utils/f;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Invalid IFD index: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ". Index should be between [0, EXIF_TAGS.length] "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p1, v1, v0, v2}, Landroidx/core/util/g;->d(IILjava/lang/String;I)V

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g;->a:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    return-object p1
.end method

.method public final c()Ljava/nio/ByteOrder;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g;->b:Ljava/nio/ByteOrder;

    return-object v0
.end method
