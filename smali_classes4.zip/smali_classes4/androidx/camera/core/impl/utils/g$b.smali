.class public final Landroidx/camera/core/impl/utils/g$b;
.super Ljava/lang/Object;
.source "ExifData.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/utils/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field private static final c:Ljava/util/regex/Pattern;

.field private static final d:Ljava/util/regex/Pattern;

.field private static final e:Ljava/util/regex/Pattern;

.field static final f:Ljava/util/ArrayList;


# instance fields
.field final a:Ljava/util/ArrayList;

.field private final b:Ljava/nio/ByteOrder;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "^(\\d{2}):(\\d{2}):(\\d{2})$"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/utils/g$b;->c:Ljava/util/regex/Pattern;

    const-string v0, "^(\\d{4}):(\\d{2}):(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/utils/g$b;->d:Ljava/util/regex/Pattern;

    const-string v0, "^(\\d{4})-(\\d{2})-(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/utils/g$b;->e:Ljava/util/regex/Pattern;

    new-instance v0, Landroidx/camera/core/impl/utils/g$b$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput v1, v0, Landroidx/camera/core/impl/utils/g$b$a;->a:I

    invoke-static {v0}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/utils/g$b;->f:Ljava/util/ArrayList;

    return-void
.end method

.method constructor <init>(Ljava/nio/ByteOrder;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/camera/core/impl/utils/g$b$b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput v1, v0, Landroidx/camera/core/impl/utils/g$b$b;->a:I

    invoke-static {v0}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    iput-object p1, p0, Landroidx/camera/core/impl/utils/g$b;->b:Ljava/nio/ByteOrder;

    return-void
.end method

.method private static b(Ljava/lang/String;)Landroid/util/Pair;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const-string v0, ","

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v6, -0x1

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    if-eqz v1, :cond_a6

    invoke-virtual {p0, v0, v6}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p0

    aget-object v0, p0, v2

    invoke-static {v0}, Landroidx/camera/core/impl/utils/g$b;->b(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v0

    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ne v1, v4, :cond_29

    return-object v0

    :cond_29
    :goto_29
    array-length v1, p0

    if-ge v3, v1, :cond_a5

    aget-object v1, p0, v3

    invoke-static {v1}, Landroidx/camera/core/impl/utils/g$b;->b(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v1

    iget-object v2, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    iget-object v4, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    invoke-virtual {v2, v4}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4d

    iget-object v2, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    iget-object v4, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    invoke-virtual {v2, v4}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4b

    goto :goto_4d

    :cond_4b
    const/4 v2, -0x1

    goto :goto_55

    :cond_4d
    :goto_4d
    iget-object v2, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    :goto_55
    iget-object v4, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    if-eq v4, v6, :cond_80

    iget-object v4, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Integer;

    iget-object v8, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    invoke-virtual {v4, v8}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_77

    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    iget-object v4, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    invoke-virtual {v1, v4}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_80

    :cond_77
    iget-object v1, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    goto :goto_81

    :cond_80
    const/4 v1, -0x1

    :goto_81
    if-ne v2, v6, :cond_8b

    if-ne v1, v6, :cond_8b

    new-instance p0, Landroid/util/Pair;

    invoke-direct {p0, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0

    :cond_8b
    if-ne v2, v6, :cond_97

    new-instance v0, Landroid/util/Pair;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_a2

    :cond_97
    if-ne v1, v6, :cond_a2

    new-instance v0, Landroid/util/Pair;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_a2
    :goto_a2
    add-int/lit8 v3, v3, 0x1

    goto :goto_29

    :cond_a5
    return-object v0

    :cond_a6
    const-string v0, "/"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const-wide/16 v8, 0x0

    if-eqz v1, :cond_105

    invoke-virtual {p0, v0, v6}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p0

    array-length v0, p0

    if-ne v0, v4, :cond_ff

    :try_start_b7
    aget-object v0, p0, v2

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    double-to-long v0, v0

    aget-object p0, p0, v3

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2

    double-to-long v2, v2

    const/16 p0, 0xa

    cmp-long v4, v0, v8

    if-ltz v4, :cond_f5

    cmp-long v4, v2, v8

    if-gez v4, :cond_d0

    goto :goto_f5

    :cond_d0
    const/4 v4, 0x5

    const-wide/32 v8, 0x7fffffff

    cmp-long v6, v0, v8

    if-gtz v6, :cond_eb

    cmp-long v0, v2, v8

    if-lez v0, :cond_dd

    goto :goto_eb

    :cond_dd
    new-instance v0, Landroid/util/Pair;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v0

    :cond_eb
    :goto_eb
    new-instance p0, Landroid/util/Pair;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {p0, v0, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0

    :cond_f5
    :goto_f5
    new-instance v0, Landroid/util/Pair;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-direct {v0, p0, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_fe
    .catch Ljava/lang/NumberFormatException; {:try_start_b7 .. :try_end_fe} :catch_ff

    return-object v0

    :catch_ff
    :cond_ff
    new-instance p0, Landroid/util/Pair;

    invoke-direct {p0, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0

    :cond_105
    :try_start_105
    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v2, 0x4

    cmp-long v3, v0, v8

    if-ltz v3, :cond_124

    const-wide/32 v8, 0xffff

    cmp-long v4, v0, v8

    if-gtz v4, :cond_124

    new-instance v0, Landroid/util/Pair;

    const/4 v1, 0x3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v0

    :cond_124
    if-gez v3, :cond_132

    new-instance v0, Landroid/util/Pair;

    const/16 v1, 0x9

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v0

    :cond_132
    new-instance v0, Landroid/util/Pair;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_13b
    .catch Ljava/lang/NumberFormatException; {:try_start_105 .. :try_end_13b} :catch_13c

    return-object v0

    :catch_13c
    :try_start_13c
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    new-instance p0, Landroid/util/Pair;

    const/16 v0, 0xc

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {p0, v0, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_14a
    .catch Ljava/lang/NumberFormatException; {:try_start_13c .. :try_end_14a} :catch_14b

    return-object p0

    :catch_14b
    new-instance p0, Landroid/util/Pair;

    invoke-direct {p0, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0
.end method

.method private d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V
    .registers 6

    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_17

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    return-void

    :cond_17
    invoke-direct {p0, p1, p2, p3}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method private e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V
    .registers 22

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v5, "DateTime"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string v6, " : "

    const-string v7, "Invalid value for "

    const-string v8, "ExifData"

    if-nez v5, :cond_26

    const-string v5, "DateTimeOriginal"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_26

    const-string v5, "DateTimeDigitized"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6a

    :cond_26
    if-eqz v1, :cond_6a

    sget-object v5, Landroidx/camera/core/impl/utils/g$b;->d:Ljava/util/regex/Pattern;

    invoke-virtual {v5, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/regex/Matcher;->find()Z

    move-result v5

    sget-object v9, Landroidx/camera/core/impl/utils/g$b;->e:Ljava/util/regex/Pattern;

    invoke-virtual {v9, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/regex/Matcher;->find()Z

    move-result v9

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v10

    const/16 v11, 0x13

    if-ne v10, v11, :cond_54

    if-nez v5, :cond_49

    if-nez v9, :cond_49

    goto :goto_54

    :cond_49
    if-eqz v9, :cond_6a

    const-string v5, "-"

    const-string v9, ":"

    invoke-virtual {v1, v5, v9}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_6a

    :cond_54
    :goto_54
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v8, v0}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_6a
    :goto_6a
    const-string v5, "ISOSpeedRatings"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_74

    const-string v0, "PhotographicSensitivity"

    :cond_74
    move-object v5, v0

    const/4 v0, 0x3

    const/4 v9, 0x2

    if-eqz v1, :cond_11b

    sget-object v10, Landroidx/camera/core/impl/utils/g;->e:Ljava/util/HashSet;

    invoke-virtual {v10, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_11b

    const-string v10, "GPSTimeStamp"

    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_ec

    sget-object v10, Landroidx/camera/core/impl/utils/g$b;->c:Ljava/util/regex/Pattern;

    invoke-virtual {v10, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-nez v11, :cond_ab

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v8, v0}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_ab
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "/1,"

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v9}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v0}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "/1"

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_11b

    :cond_ec
    :try_start_ec
    invoke-static {v1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v10

    new-instance v12, Landroidx/camera/core/impl/utils/j;

    const-wide v13, 0x40c3880000000000L    # 10000.0

    mul-double v10, v10, v13

    double-to-long v10, v10

    const-wide/16 v13, 0x2710

    invoke-direct {v12, v10, v11, v13, v14}, Landroidx/camera/core/impl/utils/j;-><init>(JJ)V

    invoke-virtual {v12}, Landroidx/camera/core/impl/utils/j;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_103
    .catch Ljava/lang/NumberFormatException; {:try_start_ec .. :try_end_103} :catch_104

    goto :goto_11b

    :catch_104
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v8, v1, v0}, Landroidx/camera/core/A0;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void

    :cond_11b
    :goto_11b
    const/4 v6, 0x0

    :goto_11c
    sget-object v7, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    const/4 v7, 0x4

    if-ge v6, v7, :cond_3d7

    sget-object v7, Landroidx/camera/core/impl/utils/g$b;->f:Ljava/util/ArrayList;

    invoke-interface {v7, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/HashMap;

    invoke-virtual {v7, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/camera/core/impl/utils/i;

    if-eqz v7, :cond_13c

    if-nez v1, :cond_13f

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map;

    invoke-interface {v7, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_13c
    :goto_13c
    const/4 v8, 0x3

    goto/16 :goto_3d3

    :cond_13f
    invoke-static {v1}, Landroidx/camera/core/impl/utils/g$b;->b(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v8

    iget-object v10, v8, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    const/4 v11, -0x1

    iget v12, v7, Landroidx/camera/core/impl/utils/i;->c:I

    if-eq v12, v10, :cond_17c

    iget-object v10, v8, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    if-ne v12, v10, :cond_15b

    goto :goto_17c

    :cond_15b
    iget v7, v7, Landroidx/camera/core/impl/utils/i;->d:I

    if-eq v7, v11, :cond_175

    iget-object v10, v8, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    if-eq v7, v10, :cond_173

    iget-object v8, v8, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v8, Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    if-ne v7, v8, :cond_175

    :cond_173
    move v12, v7

    goto :goto_17c

    :cond_175
    if-eq v12, v4, :cond_17c

    const/4 v7, 0x7

    if-eq v12, v7, :cond_17c

    if-ne v12, v9, :cond_13c

    :cond_17c
    :goto_17c
    const-string v7, "/"

    move-object/from16 v8, p0

    iget-object v10, v8, Landroidx/camera/core/impl/utils/g$b;->b:Ljava/nio/ByteOrder;

    const-string v13, ","

    packed-switch v12, :pswitch_data_3d8

    :pswitch_187
    goto :goto_13c

    :pswitch_188
    invoke-virtual {v1, v13, v11}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v7

    array-length v11, v7

    new-array v12, v11, [D

    const/4 v13, 0x0

    :goto_190
    array-length v14, v7

    if-ge v13, v14, :cond_19d

    aget-object v14, v7, v13

    invoke-static {v14}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v14

    aput-wide v14, v12, v13

    add-int/2addr v13, v4

    goto :goto_190

    :cond_19d
    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map;

    sget-object v13, Landroidx/camera/core/impl/utils/f;->f:[I

    const/16 v14, 0xc

    aget v13, v13, v14

    mul-int v13, v13, v11

    new-array v13, v13, [B

    invoke-static {v13}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v13

    invoke-virtual {v13, v10}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    const/4 v10, 0x0

    :goto_1b5
    if-ge v10, v11, :cond_1c3

    move-object/from16 p2, v1

    aget-wide v0, v12, v10

    invoke-virtual {v13, v0, v1}, Ljava/nio/ByteBuffer;->putDouble(D)Ljava/nio/ByteBuffer;

    add-int/2addr v10, v4

    move-object/from16 v1, p2

    const/4 v0, 0x3

    goto :goto_1b5

    :cond_1c3
    move-object/from16 p2, v1

    new-instance v0, Landroidx/camera/core/impl/utils/f;

    invoke-virtual {v13}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v1

    invoke-direct {v0, v1, v14, v11}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    invoke-interface {v7, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, p2

    goto/16 :goto_13c

    :pswitch_1d5
    invoke-virtual {v1, v13, v11}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    array-length v12, v0

    new-array v13, v12, [Landroidx/camera/core/impl/utils/j;

    const/4 v14, 0x0

    :goto_1dd
    array-length v15, v0

    if-ge v14, v15, :cond_206

    aget-object v15, v0, v14

    invoke-virtual {v15, v7, v11}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v15

    new-instance v9, Landroidx/camera/core/impl/utils/j;

    aget-object v16, v15, v3

    move/from16 v17, v12

    invoke-static/range {v16 .. v16}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v11

    double-to-long v11, v11

    aget-object v15, v15, v4

    invoke-static {v15}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v3

    double-to-long v3, v3

    invoke-direct {v9, v11, v12, v3, v4}, Landroidx/camera/core/impl/utils/j;-><init>(JJ)V

    aput-object v9, v13, v14

    const/4 v3, 0x1

    add-int/2addr v14, v3

    move/from16 v12, v17

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v9, 0x2

    const/4 v11, -0x1

    goto :goto_1dd

    :cond_206
    move/from16 v17, v12

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    sget-object v3, Landroidx/camera/core/impl/utils/f;->f:[I

    const/16 v4, 0xa

    aget v3, v3, v4

    mul-int v3, v3, v17

    new-array v3, v3, [B

    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v3

    invoke-virtual {v3, v10}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move/from16 v9, v17

    const/4 v7, 0x0

    :goto_222
    if-ge v7, v9, :cond_239

    aget-object v10, v13, v7

    invoke-virtual {v10}, Landroidx/camera/core/impl/utils/j;->b()J

    move-result-wide v11

    long-to-int v12, v11

    invoke-virtual {v3, v12}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    invoke-virtual {v10}, Landroidx/camera/core/impl/utils/j;->a()J

    move-result-wide v10

    long-to-int v11, v10

    invoke-virtual {v3, v11}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    const/4 v10, 0x1

    add-int/2addr v7, v10

    goto :goto_222

    :cond_239
    new-instance v7, Landroidx/camera/core/impl/utils/f;

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v3

    invoke-direct {v7, v3, v4, v9}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    invoke-interface {v0, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_245
    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v8, 0x3

    :goto_248
    const/4 v9, 0x2

    goto/16 :goto_3d3

    :pswitch_24b
    const/4 v0, -0x1

    invoke-virtual {v1, v13, v0}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    array-length v3, v0

    new-array v4, v3, [I

    const/4 v7, 0x0

    :goto_254
    array-length v9, v0

    if-ge v7, v9, :cond_262

    aget-object v9, v0, v7

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    aput v9, v4, v7

    const/4 v9, 0x1

    add-int/2addr v7, v9

    goto :goto_254

    :cond_262
    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    sget-object v7, Landroidx/camera/core/impl/utils/f;->f:[I

    const/16 v9, 0x9

    aget v7, v7, v9

    mul-int v7, v7, v3

    new-array v7, v7, [B

    invoke-static {v7}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v7

    invoke-virtual {v7, v10}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    const/4 v10, 0x0

    :goto_27a
    if-ge v10, v3, :cond_284

    aget v11, v4, v10

    invoke-virtual {v7, v11}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    const/4 v11, 0x1

    add-int/2addr v10, v11

    goto :goto_27a

    :cond_284
    new-instance v4, Landroidx/camera/core/impl/utils/f;

    invoke-virtual {v7}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v7

    invoke-direct {v4, v7, v9, v3}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    invoke-interface {v0, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_245

    :pswitch_291
    const/4 v0, -0x1

    invoke-virtual {v1, v13, v0}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v3

    array-length v4, v3

    new-array v9, v4, [Landroidx/camera/core/impl/utils/j;

    const/4 v11, 0x0

    :goto_29a
    array-length v12, v3

    if-ge v11, v12, :cond_2c3

    aget-object v12, v3, v11

    invoke-virtual {v12, v7, v0}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v12

    new-instance v0, Landroidx/camera/core/impl/utils/j;

    const/4 v13, 0x0

    aget-object v14, v12, v13

    invoke-static {v14}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v13

    double-to-long v13, v13

    const/4 v15, 0x1

    aget-object v12, v12, v15

    move-object/from16 v17, v7

    invoke-static {v12}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v7

    double-to-long v7, v7

    invoke-direct {v0, v13, v14, v7, v8}, Landroidx/camera/core/impl/utils/j;-><init>(JJ)V

    aput-object v0, v9, v11

    add-int/2addr v11, v15

    const/4 v0, -0x1

    move-object/from16 v8, p0

    move-object/from16 v7, v17

    goto :goto_29a

    :cond_2c3
    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    sget-object v3, Landroidx/camera/core/impl/utils/f;->f:[I

    const/4 v7, 0x5

    aget v3, v3, v7

    mul-int v3, v3, v4

    new-array v3, v3, [B

    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v3

    invoke-virtual {v3, v10}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    const/4 v13, 0x0

    :goto_2da
    if-ge v13, v4, :cond_2f1

    aget-object v8, v9, v13

    invoke-virtual {v8}, Landroidx/camera/core/impl/utils/j;->b()J

    move-result-wide v10

    long-to-int v11, v10

    invoke-virtual {v3, v11}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    invoke-virtual {v8}, Landroidx/camera/core/impl/utils/j;->a()J

    move-result-wide v10

    long-to-int v8, v10

    invoke-virtual {v3, v8}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    const/4 v8, 0x1

    add-int/2addr v13, v8

    goto :goto_2da

    :cond_2f1
    new-instance v8, Landroidx/camera/core/impl/utils/f;

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v3

    invoke-direct {v8, v3, v7, v4}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    invoke-interface {v0, v5, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_245

    :pswitch_2ff
    const/4 v0, -0x1

    invoke-virtual {v1, v13, v0}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    array-length v3, v0

    new-array v3, v3, [J

    const/4 v13, 0x0

    :goto_308
    array-length v4, v0

    if-ge v13, v4, :cond_316

    aget-object v4, v0, v13

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    aput-wide v7, v3, v13

    const/4 v4, 0x1

    add-int/2addr v13, v4

    goto :goto_308

    :cond_316
    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    invoke-static {v3, v10}, Landroidx/camera/core/impl/utils/f;->b([JLjava/nio/ByteOrder;)Landroidx/camera/core/impl/utils/f;

    move-result-object v3

    invoke-interface {v0, v5, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_245

    :pswitch_325
    const/4 v0, -0x1

    invoke-virtual {v1, v13, v0}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    array-length v3, v0

    new-array v4, v3, [I

    const/4 v13, 0x0

    :goto_32e
    array-length v7, v0

    if-ge v13, v7, :cond_33c

    aget-object v7, v0, v13

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    aput v7, v4, v13

    const/4 v7, 0x1

    add-int/2addr v13, v7

    goto :goto_32e

    :cond_33c
    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    sget-object v7, Landroidx/camera/core/impl/utils/f;->f:[I

    const/4 v8, 0x3

    aget v7, v7, v8

    mul-int v7, v7, v3

    new-array v7, v7, [B

    invoke-static {v7}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v7

    invoke-virtual {v7, v10}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    const/4 v13, 0x0

    :goto_353
    if-ge v13, v3, :cond_35e

    aget v8, v4, v13

    int-to-short v8, v8

    invoke-virtual {v7, v8}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    const/4 v8, 0x1

    add-int/2addr v13, v8

    goto :goto_353

    :cond_35e
    new-instance v4, Landroidx/camera/core/impl/utils/f;

    invoke-virtual {v7}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v7

    const/4 v8, 0x3

    invoke-direct {v4, v7, v8, v3}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    invoke-interface {v0, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto/16 :goto_248

    :pswitch_36f
    const/4 v8, 0x3

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    sget-object v3, Landroidx/camera/core/impl/utils/f;->d:Ljava/nio/charset/Charset;

    const-string v3, "\u0000"

    invoke-virtual {v1, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    sget-object v4, Landroidx/camera/core/impl/utils/f;->d:Ljava/nio/charset/Charset;

    invoke-virtual {v3, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v3

    new-instance v4, Landroidx/camera/core/impl/utils/f;

    array-length v7, v3

    const/4 v9, 0x2

    invoke-direct {v4, v3, v9, v7}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    invoke-interface {v0, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_3d3

    :pswitch_391
    const/4 v8, 0x3

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    sget-object v3, Landroidx/camera/core/impl/utils/f;->d:Ljava/nio/charset/Charset;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    if-ne v3, v4, :cond_3c2

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/16 v10, 0x30

    if-lt v7, v10, :cond_3c3

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/16 v11, 0x31

    if-gt v7, v11, :cond_3c3

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v7

    sub-int/2addr v7, v10

    int-to-byte v7, v7

    new-array v10, v4, [B

    aput-byte v7, v10, v3

    new-instance v7, Landroidx/camera/core/impl/utils/f;

    invoke-direct {v7, v10, v4, v4}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    goto :goto_3d0

    :cond_3c2
    const/4 v3, 0x0

    :cond_3c3
    sget-object v7, Landroidx/camera/core/impl/utils/f;->d:Ljava/nio/charset/Charset;

    invoke-virtual {v1, v7}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v7

    new-instance v10, Landroidx/camera/core/impl/utils/f;

    array-length v11, v7

    invoke-direct {v10, v7, v4, v11}, Landroidx/camera/core/impl/utils/f;-><init>([BII)V

    move-object v7, v10

    :goto_3d0
    invoke-interface {v0, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_3d3
    add-int/2addr v6, v4

    const/4 v0, 0x3

    goto/16 :goto_11c

    :cond_3d7
    return-void

    :pswitch_data_3d8
    .packed-switch 0x1
        :pswitch_391
        :pswitch_36f
        :pswitch_325
        :pswitch_2ff
        :pswitch_291
        :pswitch_187
        :pswitch_36f
        :pswitch_187
        :pswitch_24b
        :pswitch_1d5
        :pswitch_187
        :pswitch_188
    .end packed-switch
.end method


# virtual methods
.method public final a()Landroidx/camera/core/impl/utils/g;
    .registers 7

    new-instance v0, Landroidx/camera/core/impl/utils/g$b$c;

    invoke-direct {v0, p0}, Landroidx/camera/core/impl/utils/g$b$c;-><init>(Landroidx/camera/core/impl/utils/g$b;)V

    invoke-static {v0}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    const/4 v3, 0x2

    if-nez v2, :cond_91

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    const-string v5, "ExposureProgram"

    invoke-direct {p0, v5, v4, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v4, "ExifVersion"

    const-string v5, "0230"

    invoke-direct {p0, v4, v5, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v4, "ComponentsConfiguration"

    const-string v5, "1,2,3,0"

    invoke-direct {p0, v4, v5, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v4, "MeteringMode"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v4, v5, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v4, "LightSource"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v4, v5, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v4, "FlashpixVersion"

    const-string v5, "0100"

    invoke-direct {p0, v4, v5, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v4, "FocalPlaneResolutionUnit"

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v4, v5, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const/4 v4, 0x3

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    const-string v5, "FileSource"

    invoke-direct {p0, v5, v4, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v4, "SceneType"

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v4, v1, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "CustomRendered"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v1, v4, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "SceneCaptureType"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v1, v4, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "Contrast"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v1, v4, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "Saturation"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v1, v4, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "Sharpness"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v1, v2, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_91
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_c1

    const-string v1, "GPSVersionID"

    const-string v2, "2300"

    invoke-direct {p0, v1, v2, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "GPSSpeedRef"

    const-string v2, "K"

    invoke-direct {p0, v1, v2, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "GPSTrackRef"

    const-string v3, "T"

    invoke-direct {p0, v1, v3, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "GPSImgDirectionRef"

    invoke-direct {p0, v1, v3, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "GPSDestBearingRef"

    invoke-direct {p0, v1, v3, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v1, "GPSDestDistanceRef"

    invoke-direct {p0, v1, v2, v0}, Landroidx/camera/core/impl/utils/g$b;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_c1
    new-instance v1, Landroidx/camera/core/impl/utils/g;

    iget-object v2, p0, Landroidx/camera/core/impl/utils/g$b;->b:Ljava/nio/ByteOrder;

    invoke-direct {v1, v2, v0}, Landroidx/camera/core/impl/utils/g;-><init>(Ljava/nio/ByteOrder;Ljava/util/ArrayList;)V

    return-object v1
.end method

.method public final c(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    invoke-direct {p0, p1, p2, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final f(J)V
    .registers 6

    long-to-double p1, p1

    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v1, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v0

    long-to-double v0, v0

    div-double/2addr p1, v0

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v0, "ExposureTime"

    invoke-direct {p0, v0, p1, p2}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final g(Landroidx/camera/core/impl/n;)V
    .registers 5

    sget-object v0, Landroidx/camera/core/impl/n;->UNKNOWN:Landroidx/camera/core/impl/n;

    if-ne p1, v0, :cond_5

    return-void

    :cond_5
    sget-object v0, Landroidx/camera/core/impl/utils/g$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_2f

    const/4 v2, 0x2

    if-eq v0, v2, :cond_2c

    const/4 v2, 0x3

    if-eq v0, v2, :cond_2a

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Unknown flash state: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "ExifData"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_2a
    const/4 p1, 0x1

    goto :goto_30

    :cond_2c
    const/16 p1, 0x20

    goto :goto_30

    :cond_2f
    const/4 p1, 0x0

    :goto_30
    and-int/lit8 v0, p1, 0x1

    if-ne v0, v1, :cond_3e

    const/4 v0, 0x4

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "LightSource"

    invoke-virtual {p0, v1, v0}, Landroidx/camera/core/impl/utils/g$b;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3e
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v1, "Flash"

    invoke-direct {p0, v1, p1, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final h(F)V
    .registers 7

    new-instance v0, Landroidx/camera/core/impl/utils/j;

    const/high16 v1, 0x447a0000    # 1000.0f

    mul-float p1, p1, v1

    float-to-long v1, p1

    const-wide/16 v3, 0x3e8

    invoke-direct {v0, v1, v2, v3, v4}, Landroidx/camera/core/impl/utils/j;-><init>(JJ)V

    invoke-virtual {v0}, Landroidx/camera/core/impl/utils/j;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v1, "FocalLength"

    invoke-direct {p0, v1, p1, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final i(I)V
    .registers 4

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v1, "ImageLength"

    invoke-direct {p0, v1, p1, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final j(I)V
    .registers 4

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v1, "ImageWidth"

    invoke-direct {p0, v1, p1, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final k(I)V
    .registers 5

    const/4 v0, 0x3

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "SensitivityType"

    iget-object v2, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    invoke-direct {p0, v1, v0, v2}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const v0, 0xffff

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "PhotographicSensitivity"

    invoke-direct {p0, v0, p1, v2}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final l(F)V
    .registers 4

    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v1, "FNumber"

    invoke-direct {p0, v1, p1, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final m(I)V
    .registers 4

    if-eqz p1, :cond_2f

    const/16 v0, 0x5a

    if-eq p1, v0, :cond_2d

    const/16 v0, 0xb4

    if-eq p1, v0, :cond_2b

    const/16 v0, 0x10e

    if-eq p1, v0, :cond_28

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Unexpected orientation value: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ". Must be one of 0, 90, 180, 270."

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "ExifData"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    goto :goto_30

    :cond_28
    const/16 p1, 0x8

    goto :goto_30

    :cond_2b
    const/4 p1, 0x3

    goto :goto_30

    :cond_2d
    const/4 p1, 0x6

    goto :goto_30

    :cond_2f
    const/4 p1, 0x1

    :goto_30
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v1, "Orientation"

    invoke-direct {p0, v1, p1, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final n(Landroidx/camera/core/impl/utils/g$c;)V
    .registers 4

    sget-object v0, Landroidx/camera/core/impl/utils/g$a;->b:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_15

    const/4 v1, 0x2

    if-eq p1, v1, :cond_10

    const/4 p1, 0x0

    goto :goto_1a

    :cond_10
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    goto :goto_1a

    :cond_15
    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    :goto_1a
    iget-object v0, p0, Landroidx/camera/core/impl/utils/g$b;->a:Ljava/util/ArrayList;

    const-string v1, "WhiteBalance"

    invoke-direct {p0, v1, p1, v0}, Landroidx/camera/core/impl/utils/g$b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void
.end method
