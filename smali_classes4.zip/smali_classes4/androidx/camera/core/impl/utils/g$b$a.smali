.class final Landroidx/camera/core/impl/utils/g$b$a;
.super Ljava/lang/Object;
.source "ExifData.java"

# interfaces
.implements Ljava/util/Enumeration;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/utils/g$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Enumeration<",
        "Ljava/util/HashMap<",
        "Ljava/lang/String;",
        "Landroidx/camera/core/impl/utils/i;",
        ">;>;"
    }
.end annotation


# instance fields
.field a:I


# virtual methods
.method public final hasMoreElements()Z
    .registers 3

    iget v0, p0, Landroidx/camera/core/impl/utils/g$b$a;->a:I

    sget-object v1, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    const/4 v1, 0x4

    if-ge v0, v1, :cond_9

    const/4 v0, 0x1

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    return v0
.end method

.method public final nextElement()Ljava/lang/Object;
    .registers 7

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sget-object v1, Landroidx/camera/core/impl/utils/g;->d:[[Landroidx/camera/core/impl/utils/i;

    iget v2, p0, Landroidx/camera/core/impl/utils/g$b$a;->a:I

    aget-object v1, v1, v2

    array-length v2, v1

    const/4 v3, 0x0

    :goto_d
    if-ge v3, v2, :cond_19

    aget-object v4, v1, v3

    iget-object v5, v4, Landroidx/camera/core/impl/utils/i;->b:Ljava/lang/String;

    invoke-virtual {v0, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v3, v3, 0x1

    goto :goto_d

    :cond_19
    iget v1, p0, Landroidx/camera/core/impl/utils/g$b$a;->a:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Landroidx/camera/core/impl/utils/g$b$a;->a:I

    return-object v0
.end method
