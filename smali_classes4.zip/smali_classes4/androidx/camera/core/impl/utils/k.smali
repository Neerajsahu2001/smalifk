.class public final Landroidx/camera/core/impl/utils/k;
.super Ljava/lang/Object;
.source "MainThreadAsyncHandler.java"


# static fields
.field private static volatile a:Landroid/os/Handler;


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()Landroid/os/Handler;
    .registers 2

    sget-object v0, Landroidx/camera/core/impl/utils/k;->a:Landroid/os/Handler;

    if-eqz v0, :cond_7

    sget-object v0, Landroidx/camera/core/impl/utils/k;->a:Landroid/os/Handler;

    return-object v0

    :cond_7
    const-class v0, Landroidx/camera/core/impl/utils/k;

    monitor-enter v0

    :try_start_a
    sget-object v1, Landroidx/camera/core/impl/utils/k;->a:Landroid/os/Handler;

    if-nez v1, :cond_1b

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v1}, Landroidx/core/os/k;->a(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object v1

    sput-object v1, Landroidx/camera/core/impl/utils/k;->a:Landroid/os/Handler;

    goto :goto_1b

    :catchall_19
    move-exception v1

    goto :goto_1f

    :cond_1b
    :goto_1b
    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_a .. :try_end_1c} :catchall_19

    sget-object v0, Landroidx/camera/core/impl/utils/k;->a:Landroid/os/Handler;

    return-object v0

    :goto_1f
    :try_start_1f
    monitor-exit v0
    :try_end_20
    .catchall {:try_start_1f .. :try_end_20} :catchall_19

    throw v1
.end method
