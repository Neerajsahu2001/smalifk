.class final Landroidx/camera/core/impl/utils/g$b$b;
.super Ljava/lang/Object;
.source "ExifData.java"

# interfaces
.implements Ljava/util/Enumeration;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/utils/g$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Enumeration<",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "Landroidx/camera/core/impl/utils/f;",
        ">;>;"
    }
.end annotation


# instance fields
.field a:I


# virtual methods
.method public final hasMoreElements()Z
    .registers 3

    iget v0, p0, Landroidx/camera/core/impl/utils/g$b$b;->a:I

    sget-object v1, Landroidx/camera/core/impl/utils/g;->c:[Landroidx/camera/core/impl/utils/i;

    const/4 v1, 0x4

    if-ge v0, v1, :cond_9

    const/4 v0, 0x1

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    return v0
.end method

.method public final nextElement()Ljava/lang/Object;
    .registers 2

    iget v0, p0, Landroidx/camera/core/impl/utils/g$b$b;->a:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroidx/camera/core/impl/utils/g$b$b;->a:I

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    return-object v0
.end method
