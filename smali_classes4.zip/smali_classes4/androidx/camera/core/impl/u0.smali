.class public final Landroidx/camera/core/impl/u0;
.super Ljava/lang/Object;
.source "SessionConfig.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/u0$e;,
        Landroidx/camera/core/impl/u0$b;,
        Landroidx/camera/core/impl/u0$a;,
        Landroidx/camera/core/impl/u0$d;,
        Landroidx/camera/core/impl/u0$c;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/K;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/hardware/camera2/CameraDevice$StateCallback;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/hardware/camera2/CameraCaptureSession$StateCallback;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/g;",
            ">;"
        }
    .end annotation
.end field

.field private final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/u0$c;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Landroidx/camera/core/impl/D;

.field private g:Landroid/hardware/camera2/params/InputConfiguration;


# direct methods
.method constructor <init>(Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Landroidx/camera/core/impl/D;Landroid/hardware/camera2/params/InputConfiguration;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/impl/u0;->a:Ljava/util/List;

    invoke-static {p2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/impl/u0;->b:Ljava/util/List;

    invoke-static {p3}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/impl/u0;->c:Ljava/util/List;

    invoke-static {p4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/impl/u0;->d:Ljava/util/List;

    invoke-static {p5}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/impl/u0;->e:Ljava/util/List;

    iput-object p6, p0, Landroidx/camera/core/impl/u0;->f:Landroidx/camera/core/impl/D;

    iput-object p7, p0, Landroidx/camera/core/impl/u0;->g:Landroid/hardware/camera2/params/InputConfiguration;

    return-void
.end method

.method public static a()Landroidx/camera/core/impl/u0;
    .registers 9

    new-instance v8, Landroidx/camera/core/impl/u0;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    const/4 v0, 0x0

    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3, v0}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4, v0}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5, v0}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v0, Landroidx/camera/core/impl/D$a;

    invoke-direct {v0}, Landroidx/camera/core/impl/D$a;-><init>()V

    invoke-virtual {v0}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v6

    const/4 v7, 0x0

    move-object v0, v8

    invoke-direct/range {v0 .. v7}, Landroidx/camera/core/impl/u0;-><init>(Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Landroidx/camera/core/impl/D;Landroid/hardware/camera2/params/InputConfiguration;)V

    return-object v8
.end method


# virtual methods
.method public final b()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/hardware/camera2/CameraDevice$StateCallback;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->b:Ljava/util/List;

    return-object v0
.end method

.method public final c()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/u0$c;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->e:Ljava/util/List;

    return-object v0
.end method

.method public final d()Landroidx/camera/core/impl/H;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->f:Landroidx/camera/core/impl/D;

    iget-object v0, v0, Landroidx/camera/core/impl/D;->b:Landroidx/camera/core/impl/H;

    return-object v0
.end method

.method public final e()Landroid/hardware/camera2/params/InputConfiguration;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->g:Landroid/hardware/camera2/params/InputConfiguration;

    return-object v0
.end method

.method public final f()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/g;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->f:Landroidx/camera/core/impl/D;

    iget-object v0, v0, Landroidx/camera/core/impl/D;->d:Ljava/util/List;

    return-object v0
.end method

.method public final g()Landroidx/camera/core/impl/D;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->f:Landroidx/camera/core/impl/D;

    return-object v0
.end method

.method public final h()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/hardware/camera2/CameraCaptureSession$StateCallback;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->c:Ljava/util/List;

    return-object v0
.end method

.method public final i()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/g;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->d:Ljava/util/List;

    return-object v0
.end method

.method public final j()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/K;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->a:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final k()I
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/u0;->f:Landroidx/camera/core/impl/D;

    iget v0, v0, Landroidx/camera/core/impl/D;->c:I

    return v0
.end method
