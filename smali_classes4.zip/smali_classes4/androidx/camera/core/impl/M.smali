.class public final enum Landroidx/camera/core/impl/m;
.super Ljava/lang/Enum;
.source "CameraCaptureMetaData.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/impl/m;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/impl/m;

.field public static final enum CONVERGED:Landroidx/camera/core/impl/m;

.field public static final enum INACTIVE:Landroidx/camera/core/impl/m;

.field public static final enum LOCKED:Landroidx/camera/core/impl/m;

.field public static final enum METERING:Landroidx/camera/core/impl/m;

.field public static final enum UNKNOWN:Landroidx/camera/core/impl/m;


# direct methods
.method static constructor <clinit>()V
    .registers 11

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v5, Landroidx/camera/core/impl/m;

    const-string v6, "UNKNOWN"

    invoke-direct {v5, v6, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Landroidx/camera/core/impl/m;->UNKNOWN:Landroidx/camera/core/impl/m;

    new-instance v6, Landroidx/camera/core/impl/m;

    const-string v7, "INACTIVE"

    invoke-direct {v6, v7, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Landroidx/camera/core/impl/m;->INACTIVE:Landroidx/camera/core/impl/m;

    new-instance v7, Landroidx/camera/core/impl/m;

    const-string v8, "METERING"

    invoke-direct {v7, v8, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Landroidx/camera/core/impl/m;->METERING:Landroidx/camera/core/impl/m;

    new-instance v8, Landroidx/camera/core/impl/m;

    const-string v9, "CONVERGED"

    invoke-direct {v8, v9, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Landroidx/camera/core/impl/m;->CONVERGED:Landroidx/camera/core/impl/m;

    new-instance v9, Landroidx/camera/core/impl/m;

    const-string v10, "LOCKED"

    invoke-direct {v9, v10, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Landroidx/camera/core/impl/m;->LOCKED:Landroidx/camera/core/impl/m;

    const/4 v10, 0x5

    new-array v10, v10, [Landroidx/camera/core/impl/m;

    aput-object v5, v10, v4

    aput-object v6, v10, v3

    aput-object v7, v10, v2

    aput-object v8, v10, v1

    aput-object v9, v10, v0

    sput-object v10, Landroidx/camera/core/impl/m;->$VALUES:[Landroidx/camera/core/impl/m;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/impl/m;
    .registers 2

    const-class v0, Landroidx/camera/core/impl/m;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/impl/m;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/impl/m;
    .registers 1

    sget-object v0, Landroidx/camera/core/impl/m;->$VALUES:[Landroidx/camera/core/impl/m;

    invoke-virtual {v0}, [Landroidx/camera/core/impl/m;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/impl/m;

    return-object v0
.end method
