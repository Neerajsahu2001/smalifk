.class public final synthetic Landroidx/camera/core/impl/f0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/impl/h0;

.field public final synthetic b:Landroidx/camera/core/impl/h0$a;

.field public final synthetic c:Landroidx/camera/core/impl/h0$a;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/impl/h0;Landroidx/camera/core/impl/h0$a;Landroidx/camera/core/impl/h0$a;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/impl/f0;->a:Landroidx/camera/core/impl/h0;

    iput-object p2, p0, Landroidx/camera/core/impl/f0;->b:Landroidx/camera/core/impl/h0$a;

    iput-object p3, p0, Landroidx/camera/core/impl/f0;->c:Landroidx/camera/core/impl/h0$a;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/f0;->a:Landroidx/camera/core/impl/h0;

    iget-object v0, v0, Landroidx/camera/core/impl/h0;->a:Landroidx/lifecycle/I;

    iget-object v1, p0, Landroidx/camera/core/impl/f0;->b:Landroidx/camera/core/impl/h0$a;

    if-eqz v1, :cond_b

    invoke-virtual {v0, v1}, Landroidx/lifecycle/LiveData;->removeObserver(Landroidx/lifecycle/J;)V

    :cond_b
    iget-object v1, p0, Landroidx/camera/core/impl/f0;->c:Landroidx/camera/core/impl/h0$a;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/LiveData;->observeForever(Landroidx/lifecycle/J;)V

    return-void
.end method
