.class final Landroidx/camera/core/impl/F0$a;
.super Ljava/lang/Object;
.source "UseCaseConfigFactory.java"

# interfaces
.implements Landroidx/camera/core/impl/F0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/F0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# virtual methods
.method public final a(Landroidx/camera/core/impl/F0$b;I)Landroidx/camera/core/impl/H;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method
