.class final Landroidx/camera/core/impl/z$a;
.super Ljava/lang/Object;
.source "CameraStateRegistry.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field private a:Landroidx/camera/core/impl/x$a;

.field private final b:Ljava/util/concurrent/Executor;

.field private final c:Landroidx/camera/core/impl/z$b;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/z$b;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/core/impl/z$a;->a:Landroidx/camera/core/impl/x$a;

    iput-object p1, p0, Landroidx/camera/core/impl/z$a;->b:Ljava/util/concurrent/Executor;

    iput-object p2, p0, Landroidx/camera/core/impl/z$a;->c:Landroidx/camera/core/impl/z$b;

    return-void
.end method


# virtual methods
.method final a()Landroidx/camera/core/impl/x$a;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/z$a;->a:Landroidx/camera/core/impl/x$a;

    return-object v0
.end method

.method final b()V
    .registers 5

    :try_start_0
    iget-object v0, p0, Landroidx/camera/core/impl/z$a;->b:Ljava/util/concurrent/Executor;

    iget-object v1, p0, Landroidx/camera/core/impl/z$a;->c:Landroidx/camera/core/impl/z$b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Landroidx/camera/camera2/internal/m;

    const/4 v3, 0x1

    invoke-direct {v2, v3, v1}, Landroidx/camera/camera2/internal/m;-><init>(ILjava/lang/Object;)V

    invoke-interface {v0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_10
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_10} :catch_11

    goto :goto_19

    :catch_11
    move-exception v0

    const-string v1, "CameraStateRegistry"

    const-string v2, "Unable to notify camera."

    invoke-static {v1, v2, v0}, Landroidx/camera/core/A0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_19
    return-void
.end method

.method final c(Landroidx/camera/core/impl/x$a;)Landroidx/camera/core/impl/x$a;
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/z$a;->a:Landroidx/camera/core/impl/x$a;

    iput-object p1, p0, Landroidx/camera/core/impl/z$a;->a:Landroidx/camera/core/impl/x$a;

    return-object v0
.end method
