.class public final Landroidx/camera/core/impl/l0;
.super Landroidx/camera/core/impl/B0;
.source "MutableTagBundle.java"


# direct methods
.method public static d()Landroidx/camera/core/impl/l0;
    .registers 2

    new-instance v0, Landroidx/camera/core/impl/l0;

    new-instance v1, Landroid/util/ArrayMap;

    invoke-direct {v1}, Landroid/util/ArrayMap;-><init>()V

    invoke-direct {v0, v1}, Landroidx/camera/core/impl/B0;-><init>(Landroid/util/ArrayMap;)V

    return-object v0
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
