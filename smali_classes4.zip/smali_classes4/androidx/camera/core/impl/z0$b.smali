.class public final enum Landroidx/camera/core/impl/z0$b;
.super Ljava/lang/Enum;
.source "SurfaceConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/z0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/impl/z0$b;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/impl/z0$b;

.field public static final enum JPEG:Landroidx/camera/core/impl/z0$b;

.field public static final enum PRIV:Landroidx/camera/core/impl/z0$b;

.field public static final enum RAW:Landroidx/camera/core/impl/z0$b;

.field public static final enum YUV:Landroidx/camera/core/impl/z0$b;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v4, Landroidx/camera/core/impl/z0$b;

    const-string v5, "PRIV"

    invoke-direct {v4, v5, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Landroidx/camera/core/impl/z0$b;->PRIV:Landroidx/camera/core/impl/z0$b;

    new-instance v5, Landroidx/camera/core/impl/z0$b;

    const-string v6, "YUV"

    invoke-direct {v5, v6, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Landroidx/camera/core/impl/z0$b;->YUV:Landroidx/camera/core/impl/z0$b;

    new-instance v6, Landroidx/camera/core/impl/z0$b;

    const-string v7, "JPEG"

    invoke-direct {v6, v7, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Landroidx/camera/core/impl/z0$b;->JPEG:Landroidx/camera/core/impl/z0$b;

    new-instance v7, Landroidx/camera/core/impl/z0$b;

    const-string v8, "RAW"

    invoke-direct {v7, v8, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Landroidx/camera/core/impl/z0$b;->RAW:Landroidx/camera/core/impl/z0$b;

    const/4 v8, 0x4

    new-array v8, v8, [Landroidx/camera/core/impl/z0$b;

    aput-object v4, v8, v3

    aput-object v5, v8, v2

    aput-object v6, v8, v1

    aput-object v7, v8, v0

    sput-object v8, Landroidx/camera/core/impl/z0$b;->$VALUES:[Landroidx/camera/core/impl/z0$b;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/impl/z0$b;
    .registers 2

    const-class v0, Landroidx/camera/core/impl/z0$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/impl/z0$b;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/impl/z0$b;
    .registers 1

    sget-object v0, Landroidx/camera/core/impl/z0$b;->$VALUES:[Landroidx/camera/core/impl/z0$b;

    invoke-virtual {v0}, [Landroidx/camera/core/impl/z0$b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/impl/z0$b;

    return-object v0
.end method
