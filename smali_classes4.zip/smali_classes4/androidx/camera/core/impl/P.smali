.class public interface abstract Landroidx/camera/core/impl/p;
.super Ljava/lang/Object;
.source "CameraConfig.java"

# interfaces
.implements Landroidx/camera/core/impl/t0;


# static fields
.field public static final a:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/impl/F0;",
            ">;"
        }
    .end annotation
.end field

.field public static final b:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final c:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/impl/v0;",
            ">;"
        }
    .end annotation
.end field

.field public static final d:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "camerax.core.camera.useCaseConfigFactory"

    const-class v1, Landroidx/camera/core/impl/F0;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/p;->a:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.camera.compatibilityId"

    const-class v1, Landroidx/camera/core/impl/T;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.camera.useCaseCombinationRequiredRule"

    const-class v1, Ljava/lang/Integer;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/p;->b:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.camera.SessionProcessor"

    const-class v1, Landroidx/camera/core/impl/v0;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/p;->c:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.camera.isZslDisabled"

    const-class v1, Ljava/lang/Boolean;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/p;->d:Landroidx/camera/core/impl/H$a;

    return-void
.end method


# virtual methods
.method public abstract A()Landroidx/camera/core/impl/T;
.end method

.method public abstract a()Landroidx/camera/core/impl/F0;
.end method

.method public abstract k()I
.end method

.method public abstract n()Landroidx/camera/core/impl/v0;
.end method

.method public abstract r()Ljava/lang/Boolean;
.end method
