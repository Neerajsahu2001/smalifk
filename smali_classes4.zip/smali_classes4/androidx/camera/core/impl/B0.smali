.class public interface abstract Landroidx/camera/core/impl/b0;
.super Ljava/lang/Object;
.source "ImageReaderProxy.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/b0$a;
    }
.end annotation


# virtual methods
.method public abstract a()Landroid/view/Surface;
.end method

.method public abstract c()Landroidx/camera/core/r0;
.end method

.method public abstract close()V
.end method

.method public abstract d()I
.end method

.method public abstract e()V
.end method

.method public abstract f()I
.end method

.method public abstract g(Landroidx/camera/core/impl/b0$a;Ljava/util/concurrent/Executor;)V
.end method

.method public abstract getHeight()I
.end method

.method public abstract getWidth()I
.end method

.method public abstract h()Landroidx/camera/core/r0;
.end method
