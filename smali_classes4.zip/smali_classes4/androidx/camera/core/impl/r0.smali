.class public interface abstract Landroidx/camera/core/impl/r0;
.super Ljava/lang/Object;
.source "Quirk.java"
