.class public final synthetic Landroidx/camera/core/impl/g0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/impl/h0$a;

.field public final synthetic b:Landroidx/camera/core/impl/h0$b;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/impl/h0$a;Landroidx/camera/core/impl/h0$b;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/impl/g0;->a:Landroidx/camera/core/impl/h0$a;

    iput-object p2, p0, Landroidx/camera/core/impl/g0;->b:Landroidx/camera/core/impl/h0$b;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/g0;->a:Landroidx/camera/core/impl/h0$a;

    iget-object v1, v0, Landroidx/camera/core/impl/h0$a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-nez v1, :cond_b

    goto :goto_27

    :cond_b
    iget-object v1, p0, Landroidx/camera/core/impl/g0;->b:Landroidx/camera/core/impl/h0$b;

    invoke-virtual {v1}, Landroidx/camera/core/impl/h0$b;->a()Z

    move-result v2

    iget-object v0, v0, Landroidx/camera/core/impl/h0$a;->b:Landroidx/camera/core/impl/m0;

    if-eqz v2, :cond_1d

    invoke-virtual {v1}, Landroidx/camera/core/impl/h0$b;->d()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v0, v1}, Landroidx/camera/core/impl/m0;->a(Ljava/lang/Object;)V

    goto :goto_27

    :cond_1d
    invoke-virtual {v1}, Landroidx/camera/core/impl/h0$b;->c()Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0}, Landroidx/camera/core/impl/m0;->onError()V

    :goto_27
    return-void
.end method
