.class public interface abstract Landroidx/camera/core/impl/o;
.super Ljava/lang/Object;
.source "CameraCaptureResult.java"


# virtual methods
.method public abstract a()J
.end method

.method public abstract b()Landroid/hardware/camera2/CaptureResult;
.end method

.method public abstract c(Landroidx/camera/core/impl/utils/g$b;)V
.end method

.method public abstract d()Landroidx/camera/core/impl/B0;
.end method
