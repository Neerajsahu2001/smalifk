.class public interface abstract Landroidx/camera/core/impl/t;
.super Ljava/lang/Object;
.source "CameraControlInternal.java"

# interfaces
.implements Landroidx/camera/core/n;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/t$b;,
        Landroidx/camera/core/impl/t$c;
    }
.end annotation


# static fields
.field public static final a:Landroidx/camera/core/impl/t;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/camera/core/impl/t$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/core/impl/t;->a:Landroidx/camera/core/impl/t;

    return-void
.end method


# virtual methods
.method public abstract a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V
.end method

.method public abstract c(I)V
.end method

.method public abstract f(Ljava/util/ArrayList;II)Lcom/google/common/util/concurrent/o;
.end method
