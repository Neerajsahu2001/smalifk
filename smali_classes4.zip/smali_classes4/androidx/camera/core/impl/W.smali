.class public interface abstract Landroidx/camera/core/impl/w;
.super Ljava/lang/Object;
.source "CameraInfoInternal.java"

# interfaces
.implements Landroidx/camera/core/r;


# virtual methods
.method public abstract b()Ljava/lang/String;
.end method

.method public abstract c(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/g;)V
.end method

.method public abstract d()Ljava/lang/Integer;
.end method

.method public abstract e()Landroidx/camera/core/impl/s0;
.end method

.method public abstract f(Landroidx/camera/core/impl/g;)V
.end method
