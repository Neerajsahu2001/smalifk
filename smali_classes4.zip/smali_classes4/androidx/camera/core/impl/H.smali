.class public final Landroidx/camera/core/impl/h;
.super Landroidx/camera/core/impl/g;
.source "CameraCaptureCallbacks.java"


# virtual methods
.method public final a()V
    .registers 2

    const/4 v0, 0x0

    throw v0
.end method

.method public final b(Landroidx/camera/core/impl/o;)V
    .registers 2

    const/4 p1, 0x0

    throw p1
.end method

.method public final c(Landroidx/camera/core/impl/i;)V
    .registers 2

    const/4 p1, 0x0

    throw p1
.end method
