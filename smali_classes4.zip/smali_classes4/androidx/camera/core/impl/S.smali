.class public final Landroidx/camera/core/impl/s;
.super Ljava/lang/Object;
.source "CameraConfigs.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/s$a;
    }
.end annotation


# static fields
.field private static final a:Landroidx/camera/core/impl/p;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/camera/core/impl/s$a;

    invoke-direct {v0}, Landroidx/camera/core/impl/s$a;-><init>()V

    sput-object v0, Landroidx/camera/core/impl/s;->a:Landroidx/camera/core/impl/p;

    return-void
.end method

.method public static a()Landroidx/camera/core/impl/p;
    .registers 1

    sget-object v0, Landroidx/camera/core/impl/s;->a:Landroidx/camera/core/impl/p;

    return-object v0
.end method
