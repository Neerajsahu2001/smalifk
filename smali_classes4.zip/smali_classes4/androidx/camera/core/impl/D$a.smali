.class public final Landroidx/camera/core/impl/D$a;
.super Ljava/lang/Object;
.source "CaptureConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/util/HashSet;

.field private b:Landroidx/camera/core/impl/k0;

.field private c:I

.field private d:Ljava/util/ArrayList;

.field private e:Z

.field private f:Landroidx/camera/core/impl/l0;

.field private g:Landroidx/camera/core/impl/o;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/D$a;->a:Ljava/util/HashSet;

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/camera/core/impl/D$a;->c:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/D$a;->d:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/core/impl/D$a;->e:Z

    invoke-static {}, Landroidx/camera/core/impl/l0;->d()Landroidx/camera/core/impl/l0;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/impl/D$a;->f:Landroidx/camera/core/impl/l0;

    return-void
.end method

.method private constructor <init>(Landroidx/camera/core/impl/D;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/D$a;->a:Ljava/util/HashSet;

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    const/4 v1, -0x1

    iput v1, p0, Landroidx/camera/core/impl/D$a;->c:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Landroidx/camera/core/impl/D$a;->d:Ljava/util/ArrayList;

    const/4 v2, 0x0

    iput-boolean v2, p0, Landroidx/camera/core/impl/D$a;->e:Z

    invoke-static {}, Landroidx/camera/core/impl/l0;->d()Landroidx/camera/core/impl/l0;

    move-result-object v2

    iput-object v2, p0, Landroidx/camera/core/impl/D$a;->f:Landroidx/camera/core/impl/l0;

    iget-object v2, p1, Landroidx/camera/core/impl/D;->a:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p1, Landroidx/camera/core/impl/D;->b:Landroidx/camera/core/impl/H;

    invoke-static {v0}, Landroidx/camera/core/impl/k0;->F(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/k0;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    iget v0, p1, Landroidx/camera/core/impl/D;->c:I

    iput v0, p0, Landroidx/camera/core/impl/D$a;->c:I

    iget-object v0, p1, Landroidx/camera/core/impl/D;->d:Ljava/util/List;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p1}, Landroidx/camera/core/impl/D;->g()Z

    move-result v0

    iput-boolean v0, p0, Landroidx/camera/core/impl/D$a;->e:Z

    invoke-virtual {p1}, Landroidx/camera/core/impl/D;->e()Landroidx/camera/core/impl/B0;

    move-result-object p1

    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iget-object v1, p1, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_52
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_68

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v3, p1, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_52

    :cond_68
    new-instance p1, Landroidx/camera/core/impl/l0;

    invoke-direct {p1, v0}, Landroidx/camera/core/impl/B0;-><init>(Landroid/util/ArrayMap;)V

    iput-object p1, p0, Landroidx/camera/core/impl/D$a;->f:Landroidx/camera/core/impl/l0;

    return-void
.end method

.method public static j(Landroidx/camera/core/impl/D;)Landroidx/camera/core/impl/D$a;
    .registers 2

    new-instance v0, Landroidx/camera/core/impl/D$a;

    invoke-direct {v0, p0}, Landroidx/camera/core/impl/D$a;-><init>(Landroidx/camera/core/impl/D;)V

    return-object v0
.end method


# virtual methods
.method public final a(Ljava/util/List;)V
    .registers 3

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_14

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/g;

    invoke-virtual {p0, v0}, Landroidx/camera/core/impl/D$a;->c(Landroidx/camera/core/impl/g;)V

    goto :goto_4

    :cond_14
    return-void
.end method

.method public final b(Landroidx/camera/core/impl/B0;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->f:Landroidx/camera/core/impl/l0;

    iget-object v0, v0, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    if-eqz v0, :cond_d

    iget-object p1, p1, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    if-eqz p1, :cond_d

    invoke-interface {v0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    :cond_d
    return-void
.end method

.method public final c(Landroidx/camera/core/impl/g;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    return-void

    :cond_9
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final d(Landroidx/camera/core/impl/H$a;Ljava/lang/Integer;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    invoke-virtual {v0, p1, p2}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final e(Landroidx/camera/core/impl/H;)V
    .registers 7

    invoke-interface {p1}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/H$a;

    iget-object v2, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_19
    invoke-virtual {v2, v1}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v2
    :try_end_1d
    .catch Ljava/lang/IllegalArgumentException; {:try_start_19 .. :try_end_1d} :catch_1e

    goto :goto_1f

    :catch_1e
    const/4 v2, 0x0

    :goto_1f
    invoke-interface {p1, v1}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v2, Landroidx/camera/core/impl/i0;

    if-eqz v4, :cond_33

    check-cast v2, Landroidx/camera/core/impl/i0;

    check-cast v3, Landroidx/camera/core/impl/i0;

    invoke-virtual {v3}, Landroidx/camera/core/impl/i0;->c()Ljava/util/List;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroidx/camera/core/impl/i0;->a(Ljava/util/List;)V

    goto :goto_8

    :cond_33
    instance-of v2, v3, Landroidx/camera/core/impl/i0;

    if-eqz v2, :cond_3d

    check-cast v3, Landroidx/camera/core/impl/i0;

    invoke-virtual {v3}, Landroidx/camera/core/impl/i0;->b()Lo/c;

    move-result-object v3

    :cond_3d
    iget-object v2, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    invoke-interface {p1, v1}, Landroidx/camera/core/impl/H;->y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object v4

    invoke-virtual {v2, v1, v4, v3}, Landroidx/camera/core/impl/k0;->G(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;Ljava/lang/Object;)V

    goto :goto_8

    :cond_47
    return-void
.end method

.method public final f(Landroidx/camera/core/impl/K;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->a:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final g(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->f:Landroidx/camera/core/impl/l0;

    invoke-virtual {v0, p1, p2}, Landroidx/camera/core/impl/l0;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final h()Landroidx/camera/core/impl/D;
    .registers 11

    new-instance v8, Landroidx/camera/core/impl/D;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->a:Ljava/util/HashSet;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    invoke-static {v0}, Landroidx/camera/core/impl/o0;->D(Landroidx/camera/core/impl/j0;)Landroidx/camera/core/impl/o0;

    move-result-object v2

    iget v3, p0, Landroidx/camera/core/impl/D$a;->c:I

    iget-boolean v5, p0, Landroidx/camera/core/impl/D$a;->e:Z

    sget v0, Landroidx/camera/core/impl/B0;->c:I

    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iget-object v4, p0, Landroidx/camera/core/impl/D$a;->f:Landroidx/camera/core/impl/l0;

    iget-object v6, v4, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    invoke-interface {v6}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_26
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_3c

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    iget-object v9, v4, Landroidx/camera/core/impl/B0;->a:Ljava/util/Map;

    invoke-interface {v9, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v0, v7, v9}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_26

    :cond_3c
    new-instance v6, Landroidx/camera/core/impl/B0;

    invoke-direct {v6, v0}, Landroidx/camera/core/impl/B0;-><init>(Landroid/util/ArrayMap;)V

    iget-object v7, p0, Landroidx/camera/core/impl/D$a;->g:Landroidx/camera/core/impl/o;

    iget-object v4, p0, Landroidx/camera/core/impl/D$a;->d:Ljava/util/ArrayList;

    move-object v0, v8

    invoke-direct/range {v0 .. v7}, Landroidx/camera/core/impl/D;-><init>(Ljava/util/ArrayList;Landroidx/camera/core/impl/o0;ILjava/util/List;ZLandroidx/camera/core/impl/B0;Landroidx/camera/core/impl/o;)V

    return-object v8
.end method

.method public final i()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->a:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    return-void
.end method

.method public final k()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Landroidx/camera/core/impl/K;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/impl/D$a;->a:Ljava/util/HashSet;

    return-object v0
.end method

.method public final l()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/impl/D$a;->c:I

    return v0
.end method

.method public final m(Landroidx/camera/core/impl/o;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/core/impl/D$a;->g:Landroidx/camera/core/impl/o;

    return-void
.end method

.method public final n(Landroidx/camera/core/impl/H;)V
    .registers 2

    invoke-static {p1}, Landroidx/camera/core/impl/k0;->F(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/k0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/impl/D$a;->b:Landroidx/camera/core/impl/k0;

    return-void
.end method

.method public final o(I)V
    .registers 2

    iput p1, p0, Landroidx/camera/core/impl/D$a;->c:I

    return-void
.end method

.method public final p()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/camera/core/impl/D$a;->e:Z

    return-void
.end method
