.class public interface abstract Landroidx/camera/core/impl/v;
.super Ljava/lang/Object;
.source "CameraFactory.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/impl/v$a;
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/String;)Landroidx/camera/core/impl/x;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/u;
        }
    .end annotation
.end method

.method public abstract b()Ljava/util/LinkedHashSet;
.end method

.method public abstract c()Ljava/lang/Object;
.end method
