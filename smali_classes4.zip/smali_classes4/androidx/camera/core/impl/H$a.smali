.class public abstract Landroidx/camera/core/impl/H$a;
.super Ljava/lang/Object;
.source "Config.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/H;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;
    .registers 4

    new-instance v0, Landroidx/camera/core/impl/b;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1, p0}, Landroidx/camera/core/impl/b;-><init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V

    return-object v0
.end method

.method public static b(Ljava/lang/String;Ljava/lang/Object;)Landroidx/camera/core/impl/H$a;
    .registers 4

    new-instance v0, Landroidx/camera/core/impl/b;

    const-class v1, Ljava/lang/Object;

    invoke-direct {v0, p0, p1, v1}, Landroidx/camera/core/impl/b;-><init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V

    return-object v0
.end method


# virtual methods
.method public abstract c()Ljava/lang/String;
.end method

.method public abstract d()Ljava/lang/Object;
.end method

.method public abstract e()Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation
.end method
