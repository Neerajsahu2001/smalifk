.class public final Landroidx/camera/core/impl/K$a;
.super Ljava/lang/Exception;
.source "DeferrableSurface.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/K;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field a:Landroidx/camera/core/impl/K;


# direct methods
.method public constructor <init>(Landroidx/camera/core/impl/K;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Landroidx/camera/core/impl/K$a;->a:Landroidx/camera/core/impl/K;

    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/impl/K;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/K$a;->a:Landroidx/camera/core/impl/K;

    return-object v0
.end method
