.class public final Landroidx/camera/core/impl/u0$e;
.super Landroidx/camera/core/impl/u0$a;
.source "SessionConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/impl/u0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# static fields
.field private static final k:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final h:Lz/c;

.field private i:Z

.field private j:Z


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Integer;

    const/4 v4, 0x0

    aput-object v1, v3, v4

    aput-object v2, v3, v0

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/impl/u0$e;->k:Ljava/util/List;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroidx/camera/core/impl/u0$a;-><init>()V

    new-instance v0, Lz/c;

    invoke-direct {v0}, Lz/c;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/impl/u0$e;->h:Lz/c;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/camera/core/impl/u0$e;->i:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/core/impl/u0$e;->j:Z

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/u0;)V
    .registers 9

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->g()Landroidx/camera/core/impl/D;

    move-result-object v0

    iget v1, v0, Landroidx/camera/core/impl/D;->c:I

    const/4 v2, -0x1

    iget-object v3, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    if-eq v1, v2, :cond_2b

    const/4 v2, 0x1

    iput-boolean v2, p0, Landroidx/camera/core/impl/u0$e;->j:Z

    invoke-virtual {v3}, Landroidx/camera/core/impl/D$a;->l()I

    move-result v2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    sget-object v5, Landroidx/camera/core/impl/u0$e;->k:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v5

    if-lt v4, v5, :cond_27

    goto :goto_28

    :cond_27
    move v1, v2

    :goto_28
    invoke-virtual {v3, v1}, Landroidx/camera/core/impl/D$a;->o(I)V

    :cond_2b
    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->g()Landroidx/camera/core/impl/D;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/camera/core/impl/D;->e()Landroidx/camera/core/impl/B0;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroidx/camera/core/impl/D$a;->b(Landroidx/camera/core/impl/B0;)V

    iget-object v1, p0, Landroidx/camera/core/impl/u0$a;->c:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->b()Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Landroidx/camera/core/impl/u0$a;->d:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->h()Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->f()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-virtual {v3, v1}, Landroidx/camera/core/impl/D$a;->a(Ljava/util/List;)V

    iget-object v1, p0, Landroidx/camera/core/impl/u0$a;->f:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->i()Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Landroidx/camera/core/impl/u0$a;->e:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->c()Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->e()Landroid/hardware/camera2/params/InputConfiguration;

    move-result-object v1

    if-eqz v1, :cond_6f

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->e()Landroid/hardware/camera2/params/InputConfiguration;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/impl/u0$a;->g:Landroid/hardware/camera2/params/InputConfiguration;

    :cond_6f
    iget-object v1, p0, Landroidx/camera/core/impl/u0$a;->a:Ljava/util/LinkedHashSet;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->j()Ljava/util/List;

    move-result-object p1

    invoke-interface {v1, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v3}, Landroidx/camera/core/impl/D$a;->k()Ljava/util/Set;

    move-result-object p1

    iget-object v2, v0, Landroidx/camera/core/impl/D;->a:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    invoke-interface {p1, v2}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v3}, Landroidx/camera/core/impl/D$a;->k()Ljava/util/Set;

    move-result-object p1

    invoke-interface {v1, p1}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z

    move-result p1

    if-nez p1, :cond_99

    const-string p1, "Invalid configuration due to capture request surfaces are not a subset of surfaces"

    const-string v1, "ValidatingBuilder"

    invoke-static {v1, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/core/impl/u0$e;->i:Z

    :cond_99
    iget-object p1, v0, Landroidx/camera/core/impl/D;->b:Landroidx/camera/core/impl/H;

    invoke-virtual {v3, p1}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    return-void
.end method

.method public final b()Landroidx/camera/core/impl/u0;
    .registers 10

    iget-boolean v0, p0, Landroidx/camera/core/impl/u0$e;->i:Z

    if-eqz v0, :cond_27

    new-instance v2, Ljava/util/ArrayList;

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->a:Ljava/util/LinkedHashSet;

    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v0, p0, Landroidx/camera/core/impl/u0$e;->h:Lz/c;

    invoke-virtual {v0, v2}, Lz/c;->b(Ljava/util/ArrayList;)V

    new-instance v0, Landroidx/camera/core/impl/u0;

    iget-object v3, p0, Landroidx/camera/core/impl/u0$a;->c:Ljava/util/ArrayList;

    iget-object v4, p0, Landroidx/camera/core/impl/u0$a;->d:Ljava/util/ArrayList;

    iget-object v5, p0, Landroidx/camera/core/impl/u0$a;->f:Ljava/util/ArrayList;

    iget-object v6, p0, Landroidx/camera/core/impl/u0$a;->e:Ljava/util/ArrayList;

    iget-object v1, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v1}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v7

    iget-object v8, p0, Landroidx/camera/core/impl/u0$a;->g:Landroid/hardware/camera2/params/InputConfiguration;

    move-object v1, v0

    invoke-direct/range {v1 .. v8}, Landroidx/camera/core/impl/u0;-><init>(Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Landroidx/camera/core/impl/D;Landroid/hardware/camera2/params/InputConfiguration;)V

    return-object v0

    :cond_27
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Unsupported session configuration combination"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->a:Ljava/util/LinkedHashSet;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    iget-object v0, p0, Landroidx/camera/core/impl/u0$a;->b:Landroidx/camera/core/impl/D$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/D$a;->i()V

    return-void
.end method

.method public final d()Z
    .registers 2

    iget-boolean v0, p0, Landroidx/camera/core/impl/u0$e;->j:Z

    if-eqz v0, :cond_a

    iget-boolean v0, p0, Landroidx/camera/core/impl/u0$e;->i:Z

    if-eqz v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return v0
.end method
