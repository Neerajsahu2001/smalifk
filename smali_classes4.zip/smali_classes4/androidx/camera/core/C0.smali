.class public final synthetic Landroidx/camera/core/c0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/k0$k$b;


# instance fields
.field public final synthetic a:Landroidx/camera/core/k0;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/k0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/c0;->a:Landroidx/camera/core/k0;

    return-void
.end method
