.class public final Landroidx/camera/core/q1$a;
.super Ljava/lang/Object;
.source "ViewPort.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/q1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:I

.field private final b:Landroid/util/Rational;

.field private final c:I

.field private d:I


# direct methods
.method public constructor <init>(ILandroid/util/Rational;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Landroidx/camera/core/q1$a;->a:I

    const/4 v0, 0x0

    iput v0, p0, Landroidx/camera/core/q1$a;->d:I

    iput-object p2, p0, Landroidx/camera/core/q1$a;->b:Landroid/util/Rational;

    iput p1, p0, Landroidx/camera/core/q1$a;->c:I

    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/q1;
    .registers 6

    iget-object v0, p0, Landroidx/camera/core/q1$a;->b:Landroid/util/Rational;

    const-string v1, "The crop aspect ratio must be set."

    invoke-static {v0, v1}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Landroidx/camera/core/q1;

    iget v2, p0, Landroidx/camera/core/q1$a;->a:I

    iget v3, p0, Landroidx/camera/core/q1$a;->c:I

    iget v4, p0, Landroidx/camera/core/q1$a;->d:I

    invoke-direct {v1, v2, v0, v3, v4}, Landroidx/camera/core/q1;-><init>(ILandroid/util/Rational;II)V

    return-object v1
.end method

.method public final b(I)V
    .registers 2

    iput p1, p0, Landroidx/camera/core/q1$a;->d:I

    return-void
.end method

.method public final c(I)V
    .registers 2

    iput p1, p0, Landroidx/camera/core/q1$a;->a:I

    return-void
.end method
