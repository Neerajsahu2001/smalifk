.class public final Landroidx/camera/core/k0$o;
.super Ljava/lang/Object;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "o"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/k0$o$a;
    }
.end annotation


# instance fields
.field private final a:Ljava/io/File;

.field private final b:Landroidx/camera/core/k0$l;


# direct methods
.method constructor <init>(Ljava/io/File;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$o;->a:Ljava/io/File;

    new-instance p1, Landroidx/camera/core/k0$l;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$o;->b:Landroidx/camera/core/k0$l;

    return-void
.end method


# virtual methods
.method final a()Ljava/io/File;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/k0$o;->a:Ljava/io/File;

    return-object v0
.end method

.method public final b()Landroidx/camera/core/k0$l;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/k0$o;->b:Landroidx/camera/core/k0$l;

    return-object v0
.end method
