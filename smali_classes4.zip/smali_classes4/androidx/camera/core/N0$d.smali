.class final Landroidx/camera/core/N0$d;
.super Ljava/lang/Object;
.source "ProcessingImageReader.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/N0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "d"
.end annotation


# instance fields
.field protected final a:Landroidx/camera/core/impl/b0;

.field protected final b:Landroidx/camera/core/impl/C;

.field protected final c:Landroidx/camera/core/impl/E;

.field protected d:I

.field protected e:Ljava/util/concurrent/Executor;


# direct methods
.method constructor <init>(Landroidx/camera/core/impl/b0;Landroidx/camera/core/impl/C;Landroidx/camera/core/impl/E;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/N0$d;->e:Ljava/util/concurrent/Executor;

    iput-object p1, p0, Landroidx/camera/core/N0$d;->a:Landroidx/camera/core/impl/b0;

    iput-object p2, p0, Landroidx/camera/core/N0$d;->b:Landroidx/camera/core/impl/C;

    iput-object p3, p0, Landroidx/camera/core/N0$d;->c:Landroidx/camera/core/impl/E;

    invoke-interface {p1}, Landroidx/camera/core/impl/b0;->d()I

    move-result p1

    iput p1, p0, Landroidx/camera/core/N0$d;->d:I

    return-void
.end method
