.class public final Landroidx/camera/core/z;
.super Ljava/lang/Object;
.source "CameraXConfig.java"

# interfaces
.implements Lw/h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/z$a;,
        Landroidx/camera/core/z$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lw/h<",
        "Landroidx/camera/core/y;",
        ">;"
    }
.end annotation


# static fields
.field static final A:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/impl/F0$c;",
            ">;"
        }
    .end annotation
.end field

.field static final B:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/util/concurrent/Executor;",
            ">;"
        }
    .end annotation
.end field

.field static final C:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroid/os/Handler;",
            ">;"
        }
    .end annotation
.end field

.field static final D:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field static final E:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/s;",
            ">;"
        }
    .end annotation
.end field

.field static final y:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/impl/v$a;",
            ">;"
        }
    .end annotation
.end field

.field static final z:Landroidx/camera/core/impl/H$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/camera/core/impl/H$a<",
            "Landroidx/camera/core/impl/u$a;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final x:Landroidx/camera/core/impl/o0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "camerax.core.appConfig.cameraFactoryProvider"

    const-class v1, Landroidx/camera/core/impl/v$a;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/z;->y:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.appConfig.deviceSurfaceManagerProvider"

    const-class v1, Landroidx/camera/core/impl/u$a;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/z;->z:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.appConfig.useCaseConfigFactoryProvider"

    const-class v1, Landroidx/camera/core/impl/F0$c;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/z;->A:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.appConfig.cameraExecutor"

    const-class v1, Ljava/util/concurrent/Executor;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/z;->B:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.appConfig.schedulerHandler"

    const-class v1, Landroid/os/Handler;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/z;->C:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.appConfig.minimumLoggingLevel"

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/z;->D:Landroidx/camera/core/impl/H$a;

    const-string v0, "camerax.core.appConfig.availableCamerasLimiter"

    const-class v1, Landroidx/camera/core/s;

    invoke-static {v1, v0}, Landroidx/camera/core/impl/H$a;->a(Ljava/lang/Class;Ljava/lang/String;)Landroidx/camera/core/impl/H$a;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/z;->E:Landroidx/camera/core/impl/H$a;

    return-void
.end method

.method constructor <init>(Landroidx/camera/core/impl/o0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    return-void
.end method


# virtual methods
.method public final C()Landroidx/camera/core/s;
    .registers 3

    sget-object v0, Landroidx/camera/core/z;->E:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Landroidx/camera/core/s;

    return-object v0
.end method

.method public final D()Ljava/util/concurrent/Executor;
    .registers 3

    sget-object v0, Landroidx/camera/core/z;->B:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Ljava/util/concurrent/Executor;

    return-object v0
.end method

.method public final E()Landroidx/camera/core/impl/v$a;
    .registers 3

    sget-object v0, Landroidx/camera/core/z;->y:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Landroidx/camera/core/impl/v$a;

    return-object v0
.end method

.method public final F()Landroidx/camera/core/impl/u$a;
    .registers 3

    sget-object v0, Landroidx/camera/core/z;->z:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Landroidx/camera/core/impl/u$a;

    return-object v0
.end method

.method public final G()Landroid/os/Handler;
    .registers 3

    sget-object v0, Landroidx/camera/core/z;->C:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Landroid/os/Handler;

    return-object v0
.end method

.method public final H()Landroidx/camera/core/impl/F0$c;
    .registers 3

    sget-object v0, Landroidx/camera/core/z;->A:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {v1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_b} :catch_c

    goto :goto_d

    :catch_c
    const/4 v0, 0x0

    :goto_d
    check-cast v0, Landroidx/camera/core/impl/F0$c;

    return-object v0
.end method

.method public final synthetic b(Lt/i;)V
    .registers 2

    invoke-static {p0, p1}, LVk/j;->b(Landroidx/camera/core/impl/t0;Lt/i;)V

    return-void
.end method

.method public final synthetic c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final synthetic e(Landroidx/camera/core/impl/H$a;)Z
    .registers 2

    invoke-static {p0, p1}, LVk/j;->a(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Z

    move-result p1

    return p1
.end method

.method public final synthetic g(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, LVk/j;->h(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final getConfig()Landroidx/camera/core/impl/H;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/z;->x:Landroidx/camera/core/impl/o0;

    return-object v0
.end method

.method public final synthetic h()Ljava/util/Set;
    .registers 2

    invoke-static {p0}, LVk/j;->e(Landroidx/camera/core/impl/t0;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic i(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    const/4 p0, 0x0

    throw p0
.end method

.method public final synthetic l(Landroidx/camera/core/impl/H$a;)Ljava/util/Set;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->d(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/util/Set;

    move-result-object p1

    return-object p1
.end method

.method public final synthetic w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final synthetic y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;
    .registers 2

    invoke-static {p0, p1}, LVk/j;->c(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object p1

    return-object p1
.end method
