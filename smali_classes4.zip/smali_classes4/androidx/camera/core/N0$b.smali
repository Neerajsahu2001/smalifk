.class final Landroidx/camera/core/N0$b;
.super Ljava/lang/Object;
.source "ProcessingImageReader.java"

# interfaces
.implements Landroidx/camera/core/impl/b0$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/N0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/N0;


# direct methods
.method constructor <init>(Landroidx/camera/core/N0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/N0$b;->a:Landroidx/camera/core/N0;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/b0;)V
    .registers 5

    iget-object p1, p0, Landroidx/camera/core/N0$b;->a:Landroidx/camera/core/N0;

    iget-object p1, p1, Landroidx/camera/core/N0;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_5
    iget-object v0, p0, Landroidx/camera/core/N0$b;->a:Landroidx/camera/core/N0;

    iget-object v1, v0, Landroidx/camera/core/N0;->i:Landroidx/camera/core/impl/b0$a;

    iget-object v2, v0, Landroidx/camera/core/N0;->j:Ljava/util/concurrent/Executor;

    iget-object v0, v0, Landroidx/camera/core/N0;->q:Landroidx/camera/core/Z0;

    invoke-virtual {v0}, Landroidx/camera/core/Z0;->e()V

    iget-object v0, p0, Landroidx/camera/core/N0$b;->a:Landroidx/camera/core/N0;

    invoke-virtual {v0}, Landroidx/camera/core/N0;->o()V

    monitor-exit p1
    :try_end_16
    .catchall {:try_start_5 .. :try_end_16} :catchall_29

    if-eqz v1, :cond_28

    if-eqz v2, :cond_23

    new-instance p1, Landroidx/camera/core/O0;

    invoke-direct {p1, p0, v1}, Landroidx/camera/core/O0;-><init>(Landroidx/camera/core/N0$b;Landroidx/camera/core/impl/b0$a;)V

    invoke-interface {v2, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_28

    :cond_23
    iget-object p1, p0, Landroidx/camera/core/N0$b;->a:Landroidx/camera/core/N0;

    invoke-interface {v1, p1}, Landroidx/camera/core/impl/b0$a;->a(Landroidx/camera/core/impl/b0;)V

    :cond_28
    :goto_28
    return-void

    :catchall_29
    move-exception v0

    :try_start_2a
    monitor-exit p1
    :try_end_2b
    .catchall {:try_start_2a .. :try_end_2b} :catchall_29

    throw v0
.end method
