.class public interface abstract Landroidx/camera/core/j1$d;
.super Ljava/lang/Object;
.source "UseCase.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/j1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract c(Landroidx/camera/core/j1;)V
.end method

.method public abstract d(Landroidx/camera/core/j1;)V
.end method

.method public abstract f(Landroidx/camera/core/j1;)V
.end method

.method public abstract m(Landroidx/camera/core/j1;)V
.end method
