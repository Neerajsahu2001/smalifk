.class public final synthetic Landroidx/camera/core/u0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/x0;

.field public final synthetic b:Ljava/io/File;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/x0;Ljava/io/File;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/u0;->a:Landroidx/camera/core/x0;

    iput-object p2, p0, Landroidx/camera/core/u0;->b:Ljava/io/File;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/u0;->a:Landroidx/camera/core/x0;

    iget-object v1, p0, Landroidx/camera/core/u0;->b:Ljava/io/File;

    invoke-static {v0, v1}, Landroidx/camera/core/x0;->a(Landroidx/camera/core/x0;Ljava/io/File;)V

    return-void
.end method
