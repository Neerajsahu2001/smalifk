.class final Landroidx/camera/core/g;
.super Landroidx/camera/core/t$a;
.source "AutoValue_CameraState_StateError.java"


# instance fields
.field private final a:I

.field private final b:Ljava/lang/Throwable;


# direct methods
.method constructor <init>(Ljava/lang/Throwable;I)V
    .registers 3

    invoke-direct {p0}, Landroidx/camera/core/t$a;-><init>()V

    iput p2, p0, Landroidx/camera/core/g;->a:I

    iput-object p1, p0, Landroidx/camera/core/g;->b:Ljava/lang/Throwable;

    return-void
.end method


# virtual methods
.method public final c()Ljava/lang/Throwable;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/g;->b:Ljava/lang/Throwable;

    return-object v0
.end method

.method public final d()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/g;->a:I

    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Landroidx/camera/core/t$a;

    const/4 v2, 0x0

    if-eqz v1, :cond_2b

    check-cast p1, Landroidx/camera/core/t$a;

    invoke-virtual {p1}, Landroidx/camera/core/t$a;->d()I

    move-result v1

    iget v3, p0, Landroidx/camera/core/g;->a:I

    if-ne v3, v1, :cond_29

    iget-object v1, p0, Landroidx/camera/core/g;->b:Ljava/lang/Throwable;

    if-nez v1, :cond_1e

    invoke-virtual {p1}, Landroidx/camera/core/t$a;->c()Ljava/lang/Throwable;

    move-result-object p1

    if-nez p1, :cond_29

    goto :goto_2a

    :cond_1e
    invoke-virtual {p1}, Landroidx/camera/core/t$a;->c()Ljava/lang/Throwable;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_29

    goto :goto_2a

    :cond_29
    const/4 v0, 0x0

    :goto_2a
    return v0

    :cond_2b
    return v2
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, Landroidx/camera/core/g;->a:I

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int v0, v0, v1

    iget-object v1, p0, Landroidx/camera/core/g;->b:Ljava/lang/Throwable;

    if-nez v1, :cond_e

    const/4 v1, 0x0

    goto :goto_12

    :cond_e
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_12
    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "StateError{code="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Landroidx/camera/core/g;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", cause="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/camera/core/g;->b:Ljava/lang/Throwable;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
