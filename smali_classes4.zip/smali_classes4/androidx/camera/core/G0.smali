.class public final synthetic Landroidx/camera/core/g0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/k0;

.field public final synthetic b:Landroidx/camera/core/k0$m;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/k0;Landroidx/camera/core/k0$m;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/g0;->a:Landroidx/camera/core/k0;

    iput-object p2, p0, Landroidx/camera/core/g0;->b:Landroidx/camera/core/k0$m;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/g0;->a:Landroidx/camera/core/k0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroidx/camera/core/n0;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Not bound to a valid Camera ["

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "]"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v1, v3, v0, v2}, Landroidx/camera/core/n0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, p0, Landroidx/camera/core/g0;->b:Landroidx/camera/core/k0$m;

    check-cast v0, Landroidx/camera/core/k0$e;

    iget-object v0, v0, Landroidx/camera/core/k0$e;->e:Landroidx/camera/core/k0$n;

    invoke-interface {v0, v1}, Landroidx/camera/core/k0$n;->a(Landroidx/camera/core/n0;)V

    return-void
.end method
