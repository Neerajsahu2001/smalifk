.class public final Landroidx/camera/core/k0;
.super Landroidx/camera/core/j1;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/k0$h;,
        Landroidx/camera/core/k0$j;,
        Landroidx/camera/core/k0$l;,
        Landroidx/camera/core/k0$p;,
        Landroidx/camera/core/k0$o;,
        Landroidx/camera/core/k0$i;,
        Landroidx/camera/core/k0$m;,
        Landroidx/camera/core/k0$n;,
        Landroidx/camera/core/k0$k;
    }
.end annotation


# static fields
.field public static final I:Landroidx/camera/core/k0$i;

.field static final J:Lz/a;


# instance fields
.field A:Landroidx/camera/core/X0;

.field B:Landroidx/camera/core/N0;

.field private C:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private D:Landroidx/camera/core/impl/g;

.field private E:Landroidx/camera/core/impl/c0;

.field private F:Landroidx/camera/core/k0$k;

.field final G:Ljava/util/concurrent/Executor;

.field private H:Landroid/graphics/Matrix;

.field private final l:Landroidx/camera/core/b0;

.field final m:Ljava/util/concurrent/Executor;

.field private final n:I

.field private final o:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final p:I

.field private q:I

.field private r:Landroid/util/Rational;

.field private s:Ljava/util/concurrent/ExecutorService;

.field private t:Landroidx/camera/core/impl/D;

.field private u:Landroidx/camera/core/impl/C;

.field private v:I

.field private w:Landroidx/camera/core/impl/E;

.field private x:Z

.field private y:Z

.field z:Landroidx/camera/core/impl/u0$b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/camera/core/k0$i;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/core/k0;->I:Landroidx/camera/core/k0$i;

    new-instance v0, Lz/a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/core/k0;->J:Lz/a;

    return-void
.end method

.method constructor <init>(Landroidx/camera/core/impl/V;)V
    .registers 6

    invoke-direct {p0, p1}, Landroidx/camera/core/j1;-><init>(Landroidx/camera/core/impl/E0;)V

    new-instance p1, Landroidx/camera/core/b0;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0;->l:Landroidx/camera/core/b0;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 p1, -0x1

    iput p1, p0, Landroidx/camera/core/k0;->q:I

    iput-object v0, p0, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/core/k0;->x:Z

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/camera/core/k0;->y:Z

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/k0;->C:Lcom/google/common/util/concurrent/o;

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/k0;->H:Landroid/graphics/Matrix;

    invoke-virtual {p0}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/V;

    sget-object v2, Landroidx/camera/core/impl/V;->y:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/o0;

    invoke-virtual {v3, v2}, Landroidx/camera/core/impl/o0;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result v3

    if-eqz v3, :cond_4e

    invoke-static {v0, v2}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    iput v1, p0, Landroidx/camera/core/k0;->n:I

    goto :goto_50

    :cond_4e
    iput v1, p0, Landroidx/camera/core/k0;->n:I

    :goto_50
    sget-object v1, Landroidx/camera/core/impl/V;->G:Landroidx/camera/core/impl/H$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/o0;

    invoke-virtual {v2, v1, p1}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iput p1, p0, Landroidx/camera/core/k0;->p:I

    invoke-static {}, Lu/a;->c()Ljava/util/concurrent/Executor;

    move-result-object p1

    sget-object v1, Lw/f;->s:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, v1, p1}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/concurrent/Executor;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Landroidx/camera/core/k0;->m:Ljava/util/concurrent/Executor;

    invoke-static {p1}, Lu/a;->f(Ljava/util/concurrent/Executor;)Ljava/util/concurrent/Executor;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/k0;->G:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public static K(Landroidx/camera/core/k0;Landroidx/camera/core/k0$j;Landroidx/concurrent/futures/b$a;)V
    .registers 6

    iget-object v0, p0, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    new-instance v1, Landroidx/camera/core/j0;

    invoke-direct {v1, p2}, Landroidx/camera/core/j0;-><init>(Landroidx/concurrent/futures/b$a;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroidx/camera/core/X0;->g(Landroidx/camera/core/impl/b0$a;Ljava/util/concurrent/Executor;)V

    iget-object v0, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    monitor-enter v0

    :try_start_11
    iget-object v1, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_1d

    monitor-exit v0

    goto :goto_2b

    :catchall_1b
    move-exception p0

    goto :goto_46

    :cond_1d
    iget-object v1, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p0}, Landroidx/camera/core/k0;->Q()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    monitor-exit v0
    :try_end_2b
    .catchall {:try_start_11 .. :try_end_2b} :catchall_1b

    :goto_2b
    invoke-virtual {p0, p1}, Landroidx/camera/core/k0;->V(Landroidx/camera/core/k0$j;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    new-instance v0, Landroidx/camera/core/l0;

    invoke-direct {v0, p0, p2}, Landroidx/camera/core/l0;-><init>(Landroidx/camera/core/k0;Landroidx/concurrent/futures/b$a;)V

    iget-object p0, p0, Landroidx/camera/core/k0;->s:Ljava/util/concurrent/ExecutorService;

    invoke-static {p1, v0, p0}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    new-instance p0, Landroidx/camera/core/Y;

    invoke-direct {p0, p1}, Landroidx/camera/core/Y;-><init>(Lcom/google/common/util/concurrent/o;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p1

    invoke-virtual {p2, p0, p1}, Landroidx/concurrent/futures/b$a;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void

    :goto_46
    :try_start_46
    monitor-exit v0
    :try_end_47
    .catchall {:try_start_46 .. :try_end_47} :catchall_1b

    throw p0
.end method

.method static M(Landroid/graphics/Rect;Landroid/util/Rational;ILandroid/util/Size;I)Landroid/graphics/Rect;
    .registers 16

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz p0, :cond_89

    new-instance p1, Landroid/graphics/Matrix;

    invoke-direct {p1}, Landroid/graphics/Matrix;-><init>()V

    sub-int/2addr p4, p2

    int-to-float p2, p4

    invoke-virtual {p1, p2}, Landroid/graphics/Matrix;->setRotate(F)V

    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    move-result p2

    int-to-float p2, p2

    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    move-result p4

    int-to-float p4, p4

    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    move-result v9

    int-to-float v9, v9

    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    move-result p3

    int-to-float p3, p3

    const/16 v10, 0x8

    new-array v10, v10, [F

    aput v7, v10, v8

    aput v7, v10, v6

    aput p2, v10, v5

    aput v7, v10, v4

    aput p4, v10, v3

    aput v9, v10, v2

    aput v7, v10, v1

    aput p3, v10, v0

    invoke-virtual {p1, v10}, Landroid/graphics/Matrix;->mapPoints([F)V

    aget p2, v10, v8

    aget p3, v10, v5

    aget p4, v10, v3

    aget v1, v10, v1

    invoke-static {p2, p3}, Ljava/lang/Math;->min(FF)F

    move-result p2

    invoke-static {p4, v1}, Ljava/lang/Math;->min(FF)F

    move-result p3

    invoke-static {p2, p3}, Ljava/lang/Math;->min(FF)F

    move-result p2

    aget p3, v10, v6

    aget p4, v10, v4

    aget v1, v10, v2

    aget v0, v10, v0

    invoke-static {p3, p4}, Ljava/lang/Math;->min(FF)F

    move-result p3

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result p4

    invoke-static {p3, p4}, Ljava/lang/Math;->min(FF)F

    move-result p3

    neg-float p2, p2

    neg-float p3, p3

    invoke-virtual {p1, p2, p3}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    invoke-virtual {p1, p1}, Landroid/graphics/Matrix;->invert(Landroid/graphics/Matrix;)Z

    new-instance p2, Landroid/graphics/RectF;

    invoke-direct {p2}, Landroid/graphics/RectF;-><init>()V

    new-instance p3, Landroid/graphics/RectF;

    invoke-direct {p3, p0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    invoke-virtual {p1, p2, p3}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z

    invoke-virtual {p2}, Landroid/graphics/RectF;->sort()V

    new-instance p0, Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p2, p0}, Landroid/graphics/RectF;->round(Landroid/graphics/Rect;)V

    return-object p0

    :cond_89
    if-eqz p1, :cond_d6

    rem-int/lit16 p4, p4, 0xb4

    if-eqz p4, :cond_9d

    new-instance p0, Landroid/util/Rational;

    invoke-virtual {p1}, Landroid/util/Rational;->getDenominator()I

    move-result p2

    invoke-virtual {p1}, Landroid/util/Rational;->getNumerator()I

    move-result p1

    invoke-direct {p0, p2, p1}, Landroid/util/Rational;-><init>(II)V

    move-object p1, p0

    :cond_9d
    invoke-virtual {p1}, Landroid/util/Rational;->floatValue()F

    move-result p0

    cmpl-float p0, p0, v7

    if-lez p0, :cond_d6

    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    move-result p0

    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    move-result p2

    invoke-virtual {p1}, Landroid/util/Rational;->getNumerator()I

    move-result p4

    invoke-virtual {p1}, Landroid/util/Rational;->getDenominator()I

    move-result v0

    int-to-float v1, p0

    int-to-float p4, p4

    div-float/2addr v1, p4

    int-to-float v0, v0

    mul-float v1, v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    if-ne p2, v1, :cond_cb

    int-to-float p2, p2

    div-float/2addr p2, v0

    mul-float p2, p2, p4

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    if-eq p0, p2, :cond_d6

    :cond_cb
    invoke-virtual {p1}, Landroid/util/Rational;->isNaN()Z

    move-result p0

    if-nez p0, :cond_d6

    invoke-static {p3, p1}, LA/a;->a(Landroid/util/Size;Landroid/util/Rational;)Landroid/graphics/Rect;

    move-result-object p0

    return-object p0

    :cond_d6
    new-instance p0, Landroid/graphics/Rect;

    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    move-result p1

    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    move-result p2

    invoke-direct {p0, v8, v8, p1, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object p0
.end method

.method private O(Landroidx/camera/core/impl/C;)Landroidx/camera/core/impl/C;
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/k0;->u:Landroidx/camera/core/impl/C;

    invoke-interface {v0}, Landroidx/camera/core/impl/C;->a()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_14

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_f

    goto :goto_14

    :cond_f
    new-instance p1, Landroidx/camera/core/A$a;

    invoke-direct {p1, v0}, Landroidx/camera/core/A$a;-><init>(Ljava/util/List;)V

    :cond_14
    :goto_14
    return-object p1
.end method

.method static P(Ljava/lang/Throwable;)I
    .registers 2

    instance-of v0, p0, Landroidx/camera/core/m;

    if-eqz v0, :cond_6

    const/4 p0, 0x3

    return p0

    :cond_6
    instance-of v0, p0, Landroidx/camera/core/n0;

    if-eqz v0, :cond_11

    check-cast p0, Landroidx/camera/core/n0;

    invoke-virtual {p0}, Landroidx/camera/core/n0;->a()I

    move-result p0

    return p0

    :cond_11
    const/4 p0, 0x0

    return p0
.end method

.method private R()I
    .registers 5

    invoke-virtual {p0}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/V;

    sget-object v1, Landroidx/camera/core/impl/V;->H:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1}, LVk/j;->a(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Z

    move-result v2

    if-eqz v2, :cond_1c

    invoke-static {v0, v1}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    :cond_1c
    iget v0, p0, Landroidx/camera/core/k0;->n:I

    if-eqz v0, :cond_43

    const/4 v1, 0x1

    if-eq v0, v1, :cond_40

    const/4 v1, 0x2

    if-ne v0, v1, :cond_27

    goto :goto_40

    :cond_27
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "CaptureMode "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " is invalid"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_40
    :goto_40
    const/16 v0, 0x5f

    return v0

    :cond_43
    const/16 v0, 0x64

    return v0
.end method

.method private static U(ILjava/util/List;)Z
    .registers 4

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Pair;

    iget-object v0, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_20
    const/4 p0, 0x0

    return p0
.end method

.method private Y()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_f

    monitor-exit v0

    return-void

    :catchall_d
    move-exception v1

    goto :goto_1c

    :cond_f
    invoke-virtual {p0}, Landroidx/camera/core/j1;->d()Landroidx/camera/core/impl/t;

    move-result-object v1

    invoke-virtual {p0}, Landroidx/camera/core/k0;->Q()I

    move-result v2

    invoke-interface {v1, v2}, Landroidx/camera/core/impl/t;->c(I)V

    monitor-exit v0

    return-void

    :goto_1c
    monitor-exit v0
    :try_end_1d
    .catchall {:try_start_3 .. :try_end_1d} :catchall_d

    throw v1
.end method


# virtual methods
.method protected final A(Landroidx/camera/core/impl/w;Landroidx/camera/core/impl/E0$a;)Landroidx/camera/core/impl/E0;
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/w;",
            "Landroidx/camera/core/impl/E0$a<",
            "***>;)",
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation

    invoke-interface {p2}, Landroidx/camera/core/impl/E0$a;->d()Landroidx/camera/core/impl/E0;

    move-result-object v0

    sget-object v1, Landroidx/camera/core/impl/V;->B:Landroidx/camera/core/impl/H$a;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "ImageCapture"

    if-eqz v0, :cond_28

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1d

    if-lt v0, v3, :cond_28

    const-string p1, "Requesting software JPEG due to a CaptureProcessor is set."

    invoke-static {v1, p1}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/V;->F:Landroidx/camera/core/impl/H$a;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    check-cast p1, Landroidx/camera/core/impl/k0;

    invoke-virtual {p1, v0, v3}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_67

    :cond_28
    invoke-interface {p1}, Landroidx/camera/core/impl/w;->e()Landroidx/camera/core/impl/s0;

    move-result-object p1

    const-class v0, Ly/d;

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/s0;->a(Ljava/lang/Class;)Z

    move-result p1

    if-eqz p1, :cond_67

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/V;->F:Landroidx/camera/core/impl/H$a;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    check-cast p1, Landroidx/camera/core/impl/o0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_41
    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v3
    :try_end_45
    .catch Ljava/lang/IllegalArgumentException; {:try_start_41 .. :try_end_45} :catch_46

    goto :goto_47

    :catch_46
    nop

    :goto_47
    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_55

    const-string p1, "Device quirk suggests software JPEG encoder, but it has been explicitly disabled."

    invoke-static {v1, p1}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_67

    :cond_55
    const-string p1, "Requesting software JPEG due to device quirk."

    invoke-static {v1, p1}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/V;->F:Landroidx/camera/core/impl/H$a;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    check-cast p1, Landroidx/camera/core/impl/k0;

    invoke-virtual {p1, v0, v3}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    :cond_67
    :goto_67
    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/V;->F:Landroidx/camera/core/impl/H$a;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    move-object v4, p1

    check-cast v4, Landroidx/camera/core/impl/o0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_75
    invoke-virtual {v4, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v3
    :try_end_79
    .catch Ljava/lang/IllegalArgumentException; {:try_start_75 .. :try_end_79} :catch_7a

    goto :goto_7b

    :catch_7a
    nop

    :goto_7b
    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x0

    const/16 v5, 0x100

    const/4 v6, 0x1

    if-eqz v0, :cond_cb

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1a

    if-ge v0, v7, :cond_a0

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "Software JPEG only supported on API 26+, but current API level is "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x0

    goto :goto_a1

    :cond_a0
    const/4 v0, 0x1

    :goto_a1
    sget-object v7, Landroidx/camera/core/impl/V;->C:Landroidx/camera/core/impl/H$a;

    :try_start_a3
    invoke-virtual {v4, v7}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v4
    :try_end_a7
    .catch Ljava/lang/IllegalArgumentException; {:try_start_a3 .. :try_end_a7} :catch_a8

    goto :goto_aa

    :catch_a8
    nop

    move-object v4, v2

    :goto_aa
    check-cast v4, Ljava/lang/Integer;

    if-eqz v4, :cond_ba

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    if-eq v4, v5, :cond_ba

    const-string v0, "Software JPEG cannot be used with non-JPEG output buffer format."

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x0

    :cond_ba
    if-nez v0, :cond_cc

    const-string v4, "Unable to support software JPEG. Disabling."

    invoke-static {v1, v4}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v1, Landroidx/camera/core/impl/V;->F:Landroidx/camera/core/impl/H$a;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    check-cast p1, Landroidx/camera/core/impl/k0;

    invoke-virtual {p1, v1, v4}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_cc

    :cond_cb
    const/4 v0, 0x0

    :cond_cc
    :goto_cc
    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v1, Landroidx/camera/core/impl/V;->C:Landroidx/camera/core/impl/H$a;

    check-cast p1, Landroidx/camera/core/impl/o0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_d7
    invoke-virtual {p1, v1}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1
    :try_end_db
    .catch Ljava/lang/IllegalArgumentException; {:try_start_d7 .. :try_end_db} :catch_dc

    goto :goto_de

    :catch_dc
    nop

    move-object p1, v2

    :goto_de
    check-cast p1, Ljava/lang/Integer;

    const/16 v1, 0x23

    if-eqz p1, :cond_117

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object v4

    sget-object v5, Landroidx/camera/core/impl/V;->B:Landroidx/camera/core/impl/H$a;

    check-cast v4, Landroidx/camera/core/impl/o0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_ef
    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v2
    :try_end_f3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_ef .. :try_end_f3} :catch_f4

    goto :goto_f5

    :catch_f4
    nop

    :goto_f5
    if-nez v2, :cond_f9

    const/4 v2, 0x1

    goto :goto_fa

    :cond_f9
    const/4 v2, 0x0

    :goto_fa
    const-string v4, "Cannot set buffer format with CaptureProcessor defined."

    invoke-static {v2, v4}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object v2

    sget-object v4, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    if-eqz v0, :cond_108

    goto :goto_10c

    :cond_108
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    :goto_10c
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    check-cast v2, Landroidx/camera/core/impl/k0;

    invoke-virtual {v2, v4, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto/16 :goto_18e

    :cond_117
    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v4, Landroidx/camera/core/impl/V;->B:Landroidx/camera/core/impl/H$a;

    check-cast p1, Landroidx/camera/core/impl/o0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_122
    invoke-virtual {p1, v4}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1
    :try_end_126
    .catch Ljava/lang/IllegalArgumentException; {:try_start_122 .. :try_end_126} :catch_127

    goto :goto_129

    :catch_127
    nop

    move-object p1, v2

    :goto_129
    if-nez p1, :cond_17f

    if-eqz v0, :cond_12e

    goto :goto_17f

    :cond_12e
    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/Z;->l:Landroidx/camera/core/impl/H$a;

    check-cast p1, Landroidx/camera/core/impl/o0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_139
    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v2
    :try_end_13d
    .catch Ljava/lang/IllegalArgumentException; {:try_start_139 .. :try_end_13d} :catch_13e

    goto :goto_13f

    :catch_13e
    nop

    :goto_13f
    check-cast v2, Ljava/util/List;

    if-nez v2, :cond_153

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, Landroidx/camera/core/impl/k0;

    invoke-virtual {p1, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_18e

    :cond_153
    invoke-static {v5, v2}, Landroidx/camera/core/k0;->U(ILjava/util/List;)Z

    move-result p1

    if-eqz p1, :cond_169

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, Landroidx/camera/core/impl/k0;

    invoke-virtual {p1, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_18e

    :cond_169
    invoke-static {v1, v2}, Landroidx/camera/core/k0;->U(ILjava/util/List;)Z

    move-result p1

    if-eqz p1, :cond_18e

    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, Landroidx/camera/core/impl/k0;

    invoke-virtual {p1, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_18e

    :cond_17f
    :goto_17f
    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, Landroidx/camera/core/impl/k0;

    invoke-virtual {p1, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    :cond_18e
    :goto_18e
    invoke-interface {p2}, Landroidx/camera/core/H;->a()Landroidx/camera/core/impl/j0;

    move-result-object p1

    sget-object v0, Landroidx/camera/core/impl/V;->D:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p1, Landroidx/camera/core/impl/o0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_19e
    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v1
    :try_end_1a2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_19e .. :try_end_1a2} :catch_1a3

    goto :goto_1a4

    :catch_1a3
    nop

    :goto_1a4
    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    if-lt p1, v6, :cond_1ad

    const/4 v3, 0x1

    :cond_1ad
    const-string p1, "Maximum outstanding image count must be at least 1"

    invoke-static {v3, p1}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    invoke-interface {p2}, Landroidx/camera/core/impl/E0$a;->d()Landroidx/camera/core/impl/E0;

    move-result-object p1

    return-object p1
.end method

.method public final C()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    if-eqz v0, :cond_10

    new-instance v0, Landroidx/camera/core/m;

    const-string v1, "Camera is closed."

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    invoke-virtual {v1, v0}, Landroidx/camera/core/k0$k;->a(Ljava/lang/RuntimeException;)V

    :cond_10
    return-void
.end method

.method protected final D(Landroid/util/Size;)Landroid/util/Size;
    .registers 4

    invoke-virtual {p0}, Landroidx/camera/core/j1;->e()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/V;

    invoke-virtual {p0, v0, v1, p1}, Landroidx/camera/core/k0;->N(Ljava/lang/String;Landroidx/camera/core/impl/V;Landroid/util/Size;)Landroidx/camera/core/impl/u0$b;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/k0;->z:Landroidx/camera/core/impl/u0$b;

    invoke-virtual {v0}, Landroidx/camera/core/impl/u0$b;->k()Landroidx/camera/core/impl/u0;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/camera/core/j1;->I(Landroidx/camera/core/impl/u0;)V

    invoke-virtual {p0}, Landroidx/camera/core/j1;->q()V

    return-object p1
.end method

.method public final E(Landroid/graphics/Matrix;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/core/k0;->H:Landroid/graphics/Matrix;

    return-void
.end method

.method public final F(I)V
    .registers 4

    invoke-virtual {p0}, Landroidx/camera/core/j1;->l()I

    move-result v0

    invoke-virtual {p0, p1}, Landroidx/camera/core/j1;->G(I)Z

    move-result v1

    if-eqz v1, :cond_23

    iget-object v1, p0, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    if-eqz v1, :cond_23

    invoke-static {v0}, Landroidx/camera/core/impl/utils/b;->b(I)I

    move-result v0

    invoke-static {p1}, Landroidx/camera/core/impl/utils/b;->b(I)I

    move-result p1

    sub-int/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    iget-object v0, p0, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    invoke-static {p1, v0}, LA/a;->b(ILandroid/util/Rational;)Landroid/util/Rational;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    :cond_23
    return-void
.end method

.method final L()V
    .registers 5

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    iget-object v0, p0, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    const/4 v1, 0x0

    if-eqz v0, :cond_14

    new-instance v2, Ljava/util/concurrent/CancellationException;

    const-string v3, "Request is canceled."

    invoke-direct {v2, v3}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Landroidx/camera/core/k0$k;->a(Ljava/lang/RuntimeException;)V

    iput-object v1, p0, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    :cond_14
    iget-object v0, p0, Landroidx/camera/core/k0;->E:Landroidx/camera/core/impl/c0;

    iput-object v1, p0, Landroidx/camera/core/k0;->E:Landroidx/camera/core/impl/c0;

    iput-object v1, p0, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    iput-object v1, p0, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    invoke-static {v1}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/k0;->C:Lcom/google/common/util/concurrent/o;

    if-eqz v0, :cond_27

    invoke-virtual {v0}, Landroidx/camera/core/impl/K;->c()V

    :cond_27
    return-void
.end method

.method final N(Ljava/lang/String;Landroidx/camera/core/impl/V;Landroid/util/Size;)Landroidx/camera/core/impl/u0$b;
    .registers 20

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    move-object/from16 v2, p3

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-static/range {p2 .. p2}, Landroidx/camera/core/impl/u0$b;->m(Landroidx/camera/core/impl/E0;)Landroidx/camera/core/impl/u0$b;

    move-result-object v3

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x17

    const/4 v6, 0x2

    if-lt v4, v5, :cond_1f

    iget v5, v1, Landroidx/camera/core/k0;->n:I

    if-ne v5, v6, :cond_1f

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->d()Landroidx/camera/core/impl/t;

    move-result-object v5

    invoke-interface {v5, v2, v3}, Landroidx/camera/core/impl/t;->a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V

    :cond_1f
    sget-object v5, Landroidx/camera/core/impl/V;->E:Landroidx/camera/core/impl/H$a;

    const/4 v7, 0x0

    invoke-static {v0, v5, v7}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/camera/core/s0;

    const/4 v9, 0x0

    if-eqz v8, :cond_4e

    new-instance v4, Landroidx/camera/core/X0;

    invoke-static {v0, v5, v7}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/camera/core/s0;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    invoke-interface {v5}, Landroidx/camera/core/s0;->a()Landroidx/camera/core/impl/b0;

    move-result-object v5

    invoke-direct {v4, v5}, Landroidx/camera/core/X0;-><init>(Landroidx/camera/core/impl/b0;)V

    iput-object v4, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    new-instance v4, Landroidx/camera/core/k0$a;

    invoke-direct {v4}, Landroidx/camera/core/impl/g;-><init>()V

    iput-object v4, v1, Landroidx/camera/core/k0;->D:Landroidx/camera/core/impl/g;

    goto/16 :goto_123

    :cond_4e
    iget-boolean v5, v1, Landroidx/camera/core/k0;->y:Z

    const/16 v8, 0x1a

    const/16 v10, 0x100

    if-eqz v5, :cond_fc

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    move-result v5

    if-ne v5, v10, :cond_73

    new-instance v4, Landroidx/camera/core/d;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    move-result v5

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    move-result v8

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    move-result v10

    invoke-static {v5, v8, v10, v6}, Landroid/media/ImageReader;->newInstance(IIII)Landroid/media/ImageReader;

    move-result-object v5

    invoke-direct {v4, v5}, Landroidx/camera/core/d;-><init>(Landroid/media/ImageReader;)V

    move-object v5, v7

    goto :goto_cc

    :cond_73
    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    move-result v5

    const/16 v11, 0x23

    if-ne v5, v11, :cond_e4

    if-lt v4, v8, :cond_dc

    new-instance v4, Lw/n;

    invoke-direct/range {p0 .. p0}, Landroidx/camera/core/k0;->R()I

    move-result v5

    invoke-direct {v4, v5, v6}, Lw/n;-><init>(II)V

    new-instance v5, Landroidx/camera/core/F0;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    move-result v8

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    move-result v12

    invoke-static {v8, v12, v11, v6}, Landroid/media/ImageReader;->newInstance(IIII)Landroid/media/ImageReader;

    move-result-object v6

    invoke-direct {v5, v6}, Landroidx/camera/core/F0;-><init>(Landroid/media/ImageReader;)V

    invoke-static {}, Landroidx/camera/core/A;->a()Landroidx/camera/core/impl/C;

    move-result-object v6

    new-instance v8, Landroidx/camera/core/N0$d;

    invoke-direct {v8, v5, v6, v4}, Landroidx/camera/core/N0$d;-><init>(Landroidx/camera/core/impl/b0;Landroidx/camera/core/impl/C;Landroidx/camera/core/impl/E;)V

    iget-object v11, v1, Landroidx/camera/core/k0;->s:Ljava/util/concurrent/ExecutorService;

    iput-object v11, v8, Landroidx/camera/core/N0$d;->e:Ljava/util/concurrent/Executor;

    iput v10, v8, Landroidx/camera/core/N0$d;->d:I

    new-instance v10, Landroidx/camera/core/N0;

    invoke-direct {v10, v8}, Landroidx/camera/core/N0;-><init>(Landroidx/camera/core/N0$d;)V

    invoke-static {}, Landroidx/camera/core/impl/l0;->d()Landroidx/camera/core/impl/l0;

    move-result-object v8

    invoke-virtual {v10}, Landroidx/camera/core/N0;->l()Ljava/lang/String;

    move-result-object v11

    check-cast v6, Landroidx/camera/core/A$a;

    iget-object v6, v6, Landroidx/camera/core/A$a;->a:Ljava/util/List;

    invoke-interface {v6, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/camera/core/impl/F;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v8, v6, v11}, Landroidx/camera/core/impl/l0;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v5, v8}, Landroidx/camera/core/F0;->i(Landroidx/camera/core/impl/l0;)V

    move-object v5, v4

    move-object v4, v10

    :goto_cc
    new-instance v6, Landroidx/camera/core/k0$b;

    invoke-direct {v6}, Landroidx/camera/core/impl/g;-><init>()V

    iput-object v6, v1, Landroidx/camera/core/k0;->D:Landroidx/camera/core/impl/g;

    new-instance v6, Landroidx/camera/core/X0;

    invoke-direct {v6, v4}, Landroidx/camera/core/X0;-><init>(Landroidx/camera/core/impl/b0;)V

    iput-object v6, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    goto/16 :goto_1bc

    :cond_dc
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v2, "Does not support API level < 26"

    invoke-direct {v0, v2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Unsupported image format:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_fc
    iget-object v5, v1, Landroidx/camera/core/k0;->w:Landroidx/camera/core/impl/E;

    if-nez v5, :cond_126

    iget-boolean v11, v1, Landroidx/camera/core/k0;->x:Z

    if-eqz v11, :cond_105

    goto :goto_126

    :cond_105
    new-instance v4, Landroidx/camera/core/C0;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    move-result v5

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    move-result v8

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    move-result v10

    invoke-direct {v4, v5, v8, v10, v6}, Landroidx/camera/core/C0;-><init>(IIII)V

    invoke-virtual {v4}, Landroidx/camera/core/C0;->l()Landroidx/camera/core/impl/g;

    move-result-object v5

    iput-object v5, v1, Landroidx/camera/core/k0;->D:Landroidx/camera/core/impl/g;

    new-instance v5, Landroidx/camera/core/X0;

    invoke-direct {v5, v4}, Landroidx/camera/core/X0;-><init>(Landroidx/camera/core/impl/b0;)V

    iput-object v5, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    :goto_123
    move-object v5, v7

    goto/16 :goto_1bc

    :cond_126
    :goto_126
    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    move-result v6

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->h()I

    move-result v11

    iget-boolean v12, v1, Landroidx/camera/core/k0;->x:Z

    if-eqz v12, :cond_16b

    if-lt v4, v8, :cond_163

    const-string v4, "ImageCapture"

    const-string v5, "Using software JPEG encoder."

    invoke-static {v4, v5}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v4, v1, Landroidx/camera/core/k0;->w:Landroidx/camera/core/impl/E;

    if-eqz v4, :cond_156

    new-instance v4, Lw/n;

    invoke-direct/range {p0 .. p0}, Landroidx/camera/core/k0;->R()I

    move-result v5

    iget v8, v1, Landroidx/camera/core/k0;->v:I

    invoke-direct {v4, v5, v8}, Lw/n;-><init>(II)V

    new-instance v5, Landroidx/camera/core/G;

    iget-object v8, v1, Landroidx/camera/core/k0;->w:Landroidx/camera/core/impl/E;

    iget v11, v1, Landroidx/camera/core/k0;->v:I

    iget-object v12, v1, Landroidx/camera/core/k0;->s:Ljava/util/concurrent/ExecutorService;

    invoke-direct {v5, v8, v11, v4, v12}, Landroidx/camera/core/G;-><init>(Landroidx/camera/core/impl/E;ILw/n;Ljava/util/concurrent/ExecutorService;)V

    goto :goto_16d

    :cond_156
    new-instance v4, Lw/n;

    invoke-direct/range {p0 .. p0}, Landroidx/camera/core/k0;->R()I

    move-result v5

    iget v8, v1, Landroidx/camera/core/k0;->v:I

    invoke-direct {v4, v5, v8}, Lw/n;-><init>(II)V

    move-object v5, v4

    goto :goto_16d

    :cond_163
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Software JPEG only supported on API 26+"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_16b
    move-object v4, v7

    move v10, v11

    :goto_16d
    new-instance v8, Landroidx/camera/core/N0$d;

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual/range {p3 .. p3}, Landroid/util/Size;->getHeight()I

    move-result v12

    iget v13, v1, Landroidx/camera/core/k0;->v:I

    invoke-static {}, Landroidx/camera/core/A;->a()Landroidx/camera/core/impl/C;

    move-result-object v14

    invoke-direct {v1, v14}, Landroidx/camera/core/k0;->O(Landroidx/camera/core/impl/C;)Landroidx/camera/core/impl/C;

    move-result-object v14

    new-instance v15, Landroidx/camera/core/C0;

    invoke-direct {v15, v11, v12, v6, v13}, Landroidx/camera/core/C0;-><init>(IIII)V

    invoke-direct {v8, v15, v14, v5}, Landroidx/camera/core/N0$d;-><init>(Landroidx/camera/core/impl/b0;Landroidx/camera/core/impl/C;Landroidx/camera/core/impl/E;)V

    iget-object v5, v1, Landroidx/camera/core/k0;->s:Ljava/util/concurrent/ExecutorService;

    iput-object v5, v8, Landroidx/camera/core/N0$d;->e:Ljava/util/concurrent/Executor;

    iput v10, v8, Landroidx/camera/core/N0$d;->d:I

    new-instance v5, Landroidx/camera/core/N0;

    invoke-direct {v5, v8}, Landroidx/camera/core/N0;-><init>(Landroidx/camera/core/N0$d;)V

    iput-object v5, v1, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    iget-object v6, v5, Landroidx/camera/core/N0;->a:Ljava/lang/Object;

    monitor-enter v6

    :try_start_199
    iget-object v5, v5, Landroidx/camera/core/N0;->g:Landroidx/camera/core/impl/b0;

    instance-of v8, v5, Landroidx/camera/core/C0;

    if-eqz v8, :cond_1aa

    check-cast v5, Landroidx/camera/core/C0;

    invoke-virtual {v5}, Landroidx/camera/core/C0;->l()Landroidx/camera/core/impl/g;

    move-result-object v5

    monitor-exit v6

    goto :goto_1b0

    :catchall_1a7
    move-exception v0

    goto/16 :goto_24b

    :cond_1aa
    new-instance v5, Landroidx/camera/core/Q0;

    invoke-direct {v5}, Landroidx/camera/core/impl/g;-><init>()V

    monitor-exit v6
    :try_end_1b0
    .catchall {:try_start_199 .. :try_end_1b0} :catchall_1a7

    :goto_1b0
    iput-object v5, v1, Landroidx/camera/core/k0;->D:Landroidx/camera/core/impl/g;

    new-instance v5, Landroidx/camera/core/X0;

    iget-object v6, v1, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    invoke-direct {v5, v6}, Landroidx/camera/core/X0;-><init>(Landroidx/camera/core/impl/b0;)V

    iput-object v5, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    move-object v5, v4

    :goto_1bc
    iget-object v4, v1, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    if-eqz v4, :cond_1ca

    new-instance v6, Ljava/util/concurrent/CancellationException;

    const-string v8, "Request is canceled."

    invoke-direct {v6, v8}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v6}, Landroidx/camera/core/k0$k;->a(Ljava/lang/RuntimeException;)V

    :cond_1ca
    new-instance v4, Landroidx/camera/core/k0$k;

    new-instance v6, Landroidx/camera/core/c0;

    invoke-direct {v6, v1}, Landroidx/camera/core/c0;-><init>(Landroidx/camera/core/k0;)V

    if-nez v5, :cond_1d5

    move-object v8, v7

    goto :goto_1da

    :cond_1d5
    new-instance v8, Landroidx/camera/core/k0$c;

    invoke-direct {v8, v5}, Landroidx/camera/core/k0$c;-><init>(Lw/n;)V

    :goto_1da
    invoke-direct {v4, v6, v8}, Landroidx/camera/core/k0$k;-><init>(Landroidx/camera/core/c0;Landroidx/camera/core/k0$c;)V

    iput-object v4, v1, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    iget-object v4, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    iget-object v5, v1, Landroidx/camera/core/k0;->l:Landroidx/camera/core/b0;

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Landroidx/camera/core/X0;->g(Landroidx/camera/core/impl/b0$a;Ljava/util/concurrent/Executor;)V

    iget-object v4, v1, Landroidx/camera/core/k0;->E:Landroidx/camera/core/impl/c0;

    if-eqz v4, :cond_1f1

    invoke-virtual {v4}, Landroidx/camera/core/impl/K;->c()V

    :cond_1f1
    new-instance v4, Landroidx/camera/core/impl/c0;

    iget-object v5, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    invoke-virtual {v5}, Landroidx/camera/core/X0;->a()Landroid/view/Surface;

    move-result-object v5

    new-instance v6, Landroid/util/Size;

    iget-object v8, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    invoke-virtual {v8}, Landroidx/camera/core/X0;->getWidth()I

    move-result v8

    iget-object v10, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    invoke-virtual {v10}, Landroidx/camera/core/X0;->getHeight()I

    move-result v10

    invoke-direct {v6, v8, v10}, Landroid/util/Size;-><init>(II)V

    iget-object v8, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    invoke-virtual {v8}, Landroidx/camera/core/X0;->d()I

    move-result v8

    invoke-direct {v4, v5, v6, v8}, Landroidx/camera/core/impl/c0;-><init>(Landroid/view/Surface;Landroid/util/Size;I)V

    iput-object v4, v1, Landroidx/camera/core/k0;->E:Landroidx/camera/core/impl/c0;

    iget-object v4, v1, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    if-eqz v4, :cond_21e

    invoke-virtual {v4}, Landroidx/camera/core/N0;->k()Lcom/google/common/util/concurrent/o;

    move-result-object v4

    goto :goto_222

    :cond_21e
    invoke-static {v7}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v4

    :goto_222
    iput-object v4, v1, Landroidx/camera/core/k0;->C:Lcom/google/common/util/concurrent/o;

    iget-object v4, v1, Landroidx/camera/core/k0;->E:Landroidx/camera/core/impl/c0;

    invoke-virtual {v4}, Landroidx/camera/core/impl/K;->i()Lcom/google/common/util/concurrent/o;

    move-result-object v4

    iget-object v5, v1, Landroidx/camera/core/k0;->A:Landroidx/camera/core/X0;

    invoke-static {v5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, Landroidx/camera/core/d0;

    invoke-direct {v6, v9, v5}, Landroidx/camera/core/d0;-><init>(ILjava/lang/Object;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v5

    invoke-interface {v4, v6, v5}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    iget-object v4, v1, Landroidx/camera/core/k0;->E:Landroidx/camera/core/impl/c0;

    invoke-virtual {v3, v4}, Landroidx/camera/core/impl/u0$b;->f(Landroidx/camera/core/impl/K;)V

    new-instance v4, Landroidx/camera/core/e0;

    move-object/from16 v5, p1

    invoke-direct {v4, v1, v5, v0, v2}, Landroidx/camera/core/e0;-><init>(Landroidx/camera/core/k0;Ljava/lang/String;Landroidx/camera/core/impl/V;Landroid/util/Size;)V

    invoke-virtual {v3, v4}, Landroidx/camera/core/impl/u0$b;->d(Landroidx/camera/core/impl/u0$c;)V

    return-object v3

    :goto_24b
    :try_start_24b
    monitor-exit v6
    :try_end_24c
    .catchall {:try_start_24b .. :try_end_24c} :catchall_1a7

    throw v0
.end method

.method public final Q()I
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    monitor-enter v0

    :try_start_3
    iget v1, p0, Landroidx/camera/core/k0;->q:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_9

    goto :goto_23

    :cond_9
    invoke-virtual {p0}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/V;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Landroidx/camera/core/impl/V;->z:Landroidx/camera/core/impl/H$a;

    const/4 v3, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v1, v2, v3}, LVk/j;->g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    :goto_23
    monitor-exit v0

    return v1

    :catchall_25
    move-exception v1

    monitor-exit v0
    :try_end_27
    .catchall {:try_start_3 .. :try_end_27} :catchall_25

    throw v1
.end method

.method public final S()Landroidx/camera/core/U0;
    .registers 2

    invoke-virtual {p0}, Landroidx/camera/core/k0;->T()Landroidx/camera/core/U0;

    move-result-object v0

    return-object v0
.end method

.method protected final T()Landroidx/camera/core/U0;
    .registers 7

    invoke-virtual {p0}, Landroidx/camera/core/j1;->c()Landroidx/camera/core/impl/x;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/camera/core/j1;->b()Landroid/util/Size;

    move-result-object v1

    if-eqz v0, :cond_3c

    if-nez v1, :cond_d

    goto :goto_3c

    :cond_d
    invoke-virtual {p0}, Landroidx/camera/core/j1;->n()Landroid/graphics/Rect;

    move-result-object v2

    iget-object v3, p0, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    if-nez v2, :cond_2a

    if-eqz v3, :cond_1c

    invoke-static {v1, v3}, LA/a;->a(Landroid/util/Size;Landroid/util/Rational;)Landroid/graphics/Rect;

    move-result-object v2

    goto :goto_2a

    :cond_1c
    new-instance v2, Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/util/Size;->getWidth()I

    move-result v3

    invoke-virtual {v1}, Landroid/util/Size;->getHeight()I

    move-result v4

    const/4 v5, 0x0

    invoke-direct {v2, v5, v5, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    :cond_2a
    :goto_2a
    invoke-interface {v0}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/camera/core/j1;->l()I

    move-result v3

    invoke-virtual {v0, v3}, Landroidx/camera/camera2/internal/K;->h(I)I

    move-result v0

    new-instance v3, Landroidx/camera/core/i;

    invoke-direct {v3, v1, v2, v0}, Landroidx/camera/core/i;-><init>(Landroid/util/Size;Landroid/graphics/Rect;I)V

    return-object v3

    :cond_3c
    :goto_3c
    const/4 v0, 0x0

    return-object v0
.end method

.method final V(Landroidx/camera/core/k0$j;)Lcom/google/common/util/concurrent/o;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/k0$j;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const-string v0, "ImageCapture"

    const-string v1, "issueTakePicture"

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    const/4 v2, 0x1

    if-eqz v1, :cond_6f

    invoke-static {}, Landroidx/camera/core/A;->a()Landroidx/camera/core/impl/C;

    move-result-object v1

    invoke-direct {p0, v1}, Landroidx/camera/core/k0;->O(Landroidx/camera/core/impl/C;)Landroidx/camera/core/impl/C;

    move-result-object v1

    iget-object v3, p0, Landroidx/camera/core/k0;->w:Landroidx/camera/core/impl/E;

    if-nez v3, :cond_34

    move-object v3, v1

    check-cast v3, Landroidx/camera/core/A$a;

    iget-object v3, v3, Landroidx/camera/core/A$a;->a:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-le v3, v2, :cond_34

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "No CaptureProcessor can be found to process the images captured for multiple CaptureStages."

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_34
    move-object v2, v1

    check-cast v2, Landroidx/camera/core/A$a;

    iget-object v2, v2, Landroidx/camera/core/A$a;->a:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    iget v3, p0, Landroidx/camera/core/k0;->v:I

    if-le v2, v3, :cond_4d

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "ImageCapture has CaptureStages > Max CaptureStage size"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_4d
    iget-object v2, p0, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    invoke-virtual {v2, v1}, Landroidx/camera/core/N0;->n(Landroidx/camera/core/impl/C;)V

    iget-object v2, p0, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v3

    new-instance v4, Landroidx/camera/core/Z;

    invoke-direct {v4, p1}, Landroidx/camera/core/Z;-><init>(Landroidx/camera/core/k0$j;)V

    iget-object v5, v2, Landroidx/camera/core/N0;->a:Ljava/lang/Object;

    monitor-enter v5

    :try_start_60
    iput-object v3, v2, Landroidx/camera/core/N0;->u:Ljava/util/concurrent/Executor;

    iput-object v4, v2, Landroidx/camera/core/N0;->t:Landroidx/camera/core/N0$e;

    monitor-exit v5
    :try_end_65
    .catchall {:try_start_60 .. :try_end_65} :catchall_6c

    iget-object v2, p0, Landroidx/camera/core/k0;->B:Landroidx/camera/core/N0;

    invoke-virtual {v2}, Landroidx/camera/core/N0;->l()Ljava/lang/String;

    move-result-object v2

    goto :goto_8f

    :catchall_6c
    move-exception p1

    :try_start_6d
    monitor-exit v5
    :try_end_6e
    .catchall {:try_start_6d .. :try_end_6e} :catchall_6c

    throw p1

    :cond_6f
    invoke-static {}, Landroidx/camera/core/A;->a()Landroidx/camera/core/impl/C;

    move-result-object v1

    invoke-direct {p0, v1}, Landroidx/camera/core/k0;->O(Landroidx/camera/core/impl/C;)Landroidx/camera/core/impl/C;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Landroidx/camera/core/A$a;

    iget-object v3, v3, Landroidx/camera/core/A$a;->a:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-le v3, v2, :cond_8e

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "ImageCapture have no CaptureProcess set with CaptureBundle size > 1."

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_8e
    const/4 v2, 0x0

    :goto_8f
    check-cast v1, Landroidx/camera/core/A$a;

    iget-object v1, v1, Landroidx/camera/core/A$a;->a:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_97
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_11d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/F;

    new-instance v4, Landroidx/camera/core/impl/D$a;

    invoke-direct {v4}, Landroidx/camera/core/impl/D$a;-><init>()V

    iget-object v5, p0, Landroidx/camera/core/k0;->t:Landroidx/camera/core/impl/D;

    invoke-virtual {v5}, Landroidx/camera/core/impl/D;->f()I

    move-result v5

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/D$a;->o(I)V

    iget-object v5, p0, Landroidx/camera/core/k0;->t:Landroidx/camera/core/impl/D;

    invoke-virtual {v5}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    iget-object v5, p0, Landroidx/camera/core/k0;->z:Landroidx/camera/core/impl/u0$b;

    invoke-virtual {v5}, Landroidx/camera/core/impl/u0$b;->n()Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/D$a;->a(Ljava/util/List;)V

    iget-object v5, p0, Landroidx/camera/core/k0;->E:Landroidx/camera/core/impl/c0;

    invoke-virtual {v4, v5}, Landroidx/camera/core/impl/D$a;->f(Landroidx/camera/core/impl/K;)V

    invoke-virtual {p0}, Landroidx/camera/core/j1;->h()I

    move-result v5

    const/16 v6, 0x100

    if-ne v5, v6, :cond_fa

    sget-object v5, Landroidx/camera/core/k0;->J:Lz/a;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v5, Ly/b;

    invoke-static {v5}, Ly/a;->a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object v5

    check-cast v5, Ly/b;

    if-eqz v5, :cond_e4

    sget-object v5, Landroidx/camera/core/impl/D;->h:Landroidx/camera/core/impl/H$a;

    goto :goto_ef

    :cond_e4
    sget-object v5, Landroidx/camera/core/impl/D;->h:Landroidx/camera/core/impl/H$a;

    iget v6, p1, Landroidx/camera/core/k0$j;->a:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Landroidx/camera/core/impl/D$a;->d(Landroidx/camera/core/impl/H$a;Ljava/lang/Integer;)V

    :goto_ef
    sget-object v5, Landroidx/camera/core/impl/D;->i:Landroidx/camera/core/impl/H$a;

    iget v6, p1, Landroidx/camera/core/k0$j;->b:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Landroidx/camera/core/impl/D$a;->d(Landroidx/camera/core/impl/H$a;Ljava/lang/Integer;)V

    :cond_fa
    invoke-interface {v3}, Landroidx/camera/core/impl/F;->a()Landroidx/camera/core/impl/D;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    if-eqz v2, :cond_10f

    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v4, v3, v2}, Landroidx/camera/core/impl/D$a;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_10f
    iget-object v3, p0, Landroidx/camera/core/k0;->D:Landroidx/camera/core/impl/g;

    invoke-virtual {v4, v3}, Landroidx/camera/core/impl/D$a;->c(Landroidx/camera/core/impl/g;)V

    invoke-virtual {v4}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_97

    :cond_11d
    invoke-virtual {p0}, Landroidx/camera/core/j1;->d()Landroidx/camera/core/impl/t;

    move-result-object p1

    iget v1, p0, Landroidx/camera/core/k0;->n:I

    iget v2, p0, Landroidx/camera/core/k0;->p:I

    invoke-interface {p1, v0, v1, v2}, Landroidx/camera/core/impl/t;->f(Ljava/util/ArrayList;II)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    new-instance v0, Landroidx/camera/core/a0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lv/f;->m(Lcom/google/common/util/concurrent/o;Lm/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method public final W(Landroid/util/Rational;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    return-void
.end method

.method public final X(Landroidx/camera/core/k0$o;Ljava/util/concurrent/Executor;Landroidx/camera/core/k0$n;)V
    .registers 20

    move-object/from16 v7, p0

    move-object/from16 v6, p3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_1f

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    new-instance v1, Landroidx/camera/core/X;

    move-object/from16 v2, p1

    move-object/from16 v4, p2

    invoke-direct {v1, v7, v2, v4, v6}, Landroidx/camera/core/X;-><init>(Landroidx/camera/core/k0;Landroidx/camera/core/k0$o;Ljava/util/concurrent/Executor;Landroidx/camera/core/k0$n;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_1f
    move-object/from16 v2, p1

    move-object/from16 v4, p2

    new-instance v5, Landroidx/camera/core/k0$d;

    invoke-direct {v5, v6}, Landroidx/camera/core/k0$d;-><init>(Landroidx/camera/core/k0$n;)V

    invoke-direct/range {p0 .. p0}, Landroidx/camera/core/k0;->R()I

    move-result v3

    new-instance v15, Landroidx/camera/core/k0$e;

    move-object v0, v15

    move-object/from16 v1, p0

    move-object/from16 v6, p3

    invoke-direct/range {v0 .. v6}, Landroidx/camera/core/k0$e;-><init>(Landroidx/camera/core/k0;Landroidx/camera/core/k0$o;ILjava/util/concurrent/Executor;Landroidx/camera/core/x0$b;Landroidx/camera/core/k0$n;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v14

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->c()Landroidx/camera/core/impl/x;

    move-result-object v0

    if-nez v0, :cond_49

    new-instance v0, Landroidx/camera/core/g0;

    invoke-direct {v0, v7, v15}, Landroidx/camera/core/g0;-><init>(Landroidx/camera/core/k0;Landroidx/camera/core/k0$m;)V

    invoke-interface {v14, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_b2

    :cond_49
    iget-object v1, v7, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    if-nez v1, :cond_56

    new-instance v0, Landroidx/camera/core/h0;

    invoke-direct {v0, v15}, Landroidx/camera/core/h0;-><init>(Landroidx/camera/core/k0$m;)V

    invoke-interface {v14, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_b2

    :cond_56
    new-instance v2, Landroidx/camera/core/k0$j;

    invoke-interface {v0}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->l()I

    move-result v4

    invoke-virtual {v3, v4}, Landroidx/camera/camera2/internal/K;->h(I)I

    move-result v9

    invoke-interface {v0}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->l()I

    move-result v3

    invoke-virtual {v0, v3}, Landroidx/camera/camera2/internal/K;->h(I)I

    move-result v0

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->b()Landroid/util/Size;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->n()Landroid/graphics/Rect;

    move-result-object v4

    iget-object v5, v7, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    invoke-static {v4, v5, v0, v3, v0}, Landroidx/camera/core/k0;->M(Landroid/graphics/Rect;Landroid/util/Rational;ILandroid/util/Size;I)Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {v3}, Landroid/util/Size;->getWidth()I

    move-result v4

    invoke-virtual {v3}, Landroid/util/Size;->getHeight()I

    move-result v3

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v5

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    if-ne v4, v5, :cond_99

    if-eq v3, v0, :cond_93

    goto :goto_99

    :cond_93
    invoke-direct/range {p0 .. p0}, Landroidx/camera/core/k0;->R()I

    move-result v0

    :goto_97
    move v10, v0

    goto :goto_a3

    :cond_99
    :goto_99
    iget v0, v7, Landroidx/camera/core/k0;->n:I

    if-nez v0, :cond_a0

    const/16 v0, 0x64

    goto :goto_97

    :cond_a0
    const/16 v0, 0x5f

    goto :goto_97

    :goto_a3
    iget-object v11, v7, Landroidx/camera/core/k0;->r:Landroid/util/Rational;

    invoke-virtual/range {p0 .. p0}, Landroidx/camera/core/j1;->n()Landroid/graphics/Rect;

    move-result-object v12

    iget-object v13, v7, Landroidx/camera/core/k0;->H:Landroid/graphics/Matrix;

    move-object v8, v2

    invoke-direct/range {v8 .. v15}, Landroidx/camera/core/k0$j;-><init>(IILandroid/util/Rational;Landroid/graphics/Rect;Landroid/graphics/Matrix;Ljava/util/concurrent/ScheduledExecutorService;Landroidx/camera/core/k0$m;)V

    invoke-virtual {v1, v2}, Landroidx/camera/core/k0$k;->d(Landroidx/camera/core/k0$j;)V

    :goto_b2
    return-void
.end method

.method final Z()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/k0;->o:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    if-nez v1, :cond_12

    monitor-exit v0

    return-void

    :catchall_10
    move-exception v1

    goto :goto_21

    :cond_12
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {p0}, Landroidx/camera/core/k0;->Q()I

    move-result v2

    if-eq v1, v2, :cond_1f

    invoke-direct {p0}, Landroidx/camera/core/k0;->Y()V

    :cond_1f
    monitor-exit v0

    return-void

    :goto_21
    monitor-exit v0
    :try_end_22
    .catchall {:try_start_3 .. :try_end_22} :catchall_10

    throw v1
.end method

.method public final g(ZLandroidx/camera/core/impl/F0;)Landroidx/camera/core/impl/E0;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Landroidx/camera/core/impl/F0;",
            ")",
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation

    sget-object v0, Landroidx/camera/core/impl/F0$b;->IMAGE_CAPTURE:Landroidx/camera/core/impl/F0$b;

    iget v1, p0, Landroidx/camera/core/k0;->n:I

    invoke-interface {p2, v0, v1}, Landroidx/camera/core/impl/F0;->a(Landroidx/camera/core/impl/F0$b;I)Landroidx/camera/core/impl/H;

    move-result-object p2

    if-eqz p1, :cond_17

    sget-object p1, Landroidx/camera/core/k0;->I:Landroidx/camera/core/k0$i;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroidx/camera/core/k0$i;->a()Landroidx/camera/core/impl/V;

    move-result-object p1

    invoke-static {p2, p1}, Landroidx/camera/core/impl/G;->a(Landroidx/camera/core/impl/H;Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/o0;

    move-result-object p2

    :cond_17
    if-nez p2, :cond_1b

    const/4 p1, 0x0

    goto :goto_23

    :cond_1b
    invoke-static {p2}, Landroidx/camera/core/k0$h;->f(Landroidx/camera/core/impl/H;)Landroidx/camera/core/k0$h;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/camera/core/k0$h;->g()Landroidx/camera/core/impl/V;

    move-result-object p1

    :goto_23
    return-object p1
.end method

.method public final m(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/E0$a;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/H;",
            ")",
            "Landroidx/camera/core/impl/E0$a<",
            "***>;"
        }
    .end annotation

    invoke-static {p1}, Landroidx/camera/core/k0$h;->f(Landroidx/camera/core/impl/H;)Landroidx/camera/core/k0$h;

    move-result-object p1

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ImageCapture:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/camera/core/j1;->i()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final w()V
    .registers 5

    invoke-virtual {p0}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/V;

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->C()Landroidx/camera/core/impl/D$b;

    move-result-object v1

    if-eqz v1, :cond_98

    new-instance v2, Landroidx/camera/core/impl/D$a;

    invoke-direct {v2}, Landroidx/camera/core/impl/D$a;-><init>()V

    invoke-interface {v1, v0, v2}, Landroidx/camera/core/impl/D$b;->a(Landroidx/camera/core/impl/V;Landroidx/camera/core/impl/D$a;)V

    invoke-virtual {v2}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/k0;->t:Landroidx/camera/core/impl/D;

    sget-object v1, Landroidx/camera/core/impl/V;->B:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/o0;

    const/4 v3, 0x0

    invoke-virtual {v2, v1, v3}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/E;

    iput-object v1, p0, Landroidx/camera/core/k0;->w:Landroidx/camera/core/impl/E;

    sget-object v1, Landroidx/camera/core/impl/V;->D:Landroidx/camera/core/impl/H$a;

    const/4 v2, 0x2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/o0;

    invoke-virtual {v3, v1, v2}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    iput v1, p0, Landroidx/camera/core/k0;->v:I

    invoke-static {}, Landroidx/camera/core/A;->a()Landroidx/camera/core/impl/C;

    move-result-object v1

    sget-object v2, Landroidx/camera/core/impl/V;->A:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/o0;

    invoke-virtual {v3, v2, v1}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/C;

    iput-object v1, p0, Landroidx/camera/core/k0;->u:Landroidx/camera/core/impl/C;

    sget-object v1, Landroidx/camera/core/impl/V;->F:Landroidx/camera/core/impl/H$a;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/o0;

    invoke-virtual {v3, v1, v2}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iput-boolean v1, p0, Landroidx/camera/core/k0;->x:Z

    sget-object v1, Landroidx/camera/core/impl/V;->I:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/V;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, v1, v2}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, p0, Landroidx/camera/core/k0;->y:Z

    invoke-virtual {p0}, Landroidx/camera/core/j1;->c()Landroidx/camera/core/impl/x;

    move-result-object v0

    const-string v1, "Attached camera cannot be null"

    invoke-static {v0, v1}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Landroidx/camera/core/k0$f;

    invoke-direct {v0}, Landroidx/camera/core/k0$f;-><init>()V

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/k0;->s:Ljava/util/concurrent/ExecutorService;

    return-void

    :cond_98
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Implementation is missing option unpacker for "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lw/g;->a(Lw/h;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method protected final x()V
    .registers 1

    invoke-direct {p0}, Landroidx/camera/core/k0;->Y()V

    return-void
.end method

.method public final z()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/k0;->C:Lcom/google/common/util/concurrent/o;

    iget-object v1, p0, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    if-eqz v1, :cond_12

    new-instance v1, Landroidx/camera/core/m;

    const-string v2, "Camera is closed."

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/camera/core/k0;->F:Landroidx/camera/core/k0$k;

    invoke-virtual {v2, v1}, Landroidx/camera/core/k0$k;->a(Ljava/lang/RuntimeException;)V

    :cond_12
    invoke-virtual {p0}, Landroidx/camera/core/k0;->L()V

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/camera/core/k0;->x:Z

    iget-object v1, p0, Landroidx/camera/core/k0;->s:Ljava/util/concurrent/ExecutorService;

    new-instance v2, Landroidx/camera/core/f0;

    invoke-direct {v2, v1}, Landroidx/camera/core/f0;-><init>(Ljava/util/concurrent/ExecutorService;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-interface {v0, v2, v1}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method
