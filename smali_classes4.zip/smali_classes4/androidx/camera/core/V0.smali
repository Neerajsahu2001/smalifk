.class public final synthetic Landroidx/camera/core/v0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/x0;

.field public final synthetic b:Landroidx/camera/core/x0$c;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Ljava/lang/Throwable;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/x0;Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/v0;->a:Landroidx/camera/core/x0;

    iput-object p2, p0, Landroidx/camera/core/v0;->b:Landroidx/camera/core/x0$c;

    iput-object p3, p0, Landroidx/camera/core/v0;->c:Ljava/lang/String;

    iput-object p4, p0, Landroidx/camera/core/v0;->d:Ljava/lang/Throwable;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/v0;->c:Ljava/lang/String;

    iget-object v1, p0, Landroidx/camera/core/v0;->d:Ljava/lang/Throwable;

    iget-object v2, p0, Landroidx/camera/core/v0;->a:Landroidx/camera/core/x0;

    iget-object v3, p0, Landroidx/camera/core/v0;->b:Landroidx/camera/core/x0$c;

    invoke-static {v2, v3, v0, v1}, Landroidx/camera/core/x0;->b(Landroidx/camera/core/x0;Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
