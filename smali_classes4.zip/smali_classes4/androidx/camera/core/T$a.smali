.class public abstract Landroidx/camera/core/t$a;
.super Ljava/lang/Object;
.source "CameraState.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/t;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(I)Landroidx/camera/core/t$a;
    .registers 3

    new-instance v0, Landroidx/camera/core/g;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p0}, Landroidx/camera/core/g;-><init>(Ljava/lang/Throwable;I)V

    return-object v0
.end method

.method public static b(Ljava/lang/Throwable;I)Landroidx/camera/core/t$a;
    .registers 3

    new-instance v0, Landroidx/camera/core/g;

    invoke-direct {v0, p0, p1}, Landroidx/camera/core/g;-><init>(Ljava/lang/Throwable;I)V

    return-object v0
.end method


# virtual methods
.method public abstract c()Ljava/lang/Throwable;
.end method

.method public abstract d()I
.end method
