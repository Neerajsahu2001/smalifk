.class public final synthetic Landroidx/camera/core/w0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/x0;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/x0;Landroid/net/Uri;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/w0;->a:Landroidx/camera/core/x0;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/w0;->a:Landroidx/camera/core/x0;

    invoke-static {v0}, Landroidx/camera/core/x0;->c(Landroidx/camera/core/x0;)V

    return-void
.end method
