.class public interface abstract Landroidx/camera/core/q;
.super Ljava/lang/Object;
.source "CameraFilter.java"


# static fields
.field public static final a:Landroidx/camera/core/impl/T;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {v0}, Landroidx/camera/core/impl/T;->a(Ljava/lang/Object;)Landroidx/camera/core/impl/T;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/q;->a:Landroidx/camera/core/impl/T;

    return-void
.end method


# virtual methods
.method public abstract a(Ljava/util/List;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/camera/core/r;",
            ">;)",
            "Ljava/util/List<",
            "Landroidx/camera/core/r;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getIdentifier()Landroidx/camera/core/impl/T;
.end method
