.class final Landroidx/camera/core/o1;
.super Ljava/lang/Object;
.source "VideoCapture.java"

# interfaces
.implements Landroidx/camera/core/impl/u0$c;


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/util/Size;

.field final synthetic c:Landroidx/camera/core/p1;


# direct methods
.method constructor <init>(Landroidx/camera/core/p1;Ljava/lang/String;Landroid/util/Size;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/o1;->c:Landroidx/camera/core/p1;

    iput-object p2, p0, Landroidx/camera/core/o1;->a:Ljava/lang/String;

    iput-object p3, p0, Landroidx/camera/core/o1;->b:Landroid/util/Size;

    return-void
.end method


# virtual methods
.method public final onError()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/o1;->c:Landroidx/camera/core/p1;

    iget-object v1, p0, Landroidx/camera/core/o1;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroidx/camera/core/j1;->o(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_12

    iget-object v2, p0, Landroidx/camera/core/o1;->b:Landroid/util/Size;

    invoke-virtual {v0, v2, v1}, Landroidx/camera/core/p1;->N(Landroid/util/Size;Ljava/lang/String;)V

    invoke-virtual {v0}, Landroidx/camera/core/j1;->s()V

    :cond_12
    return-void
.end method
