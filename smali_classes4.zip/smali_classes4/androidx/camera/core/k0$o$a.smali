.class public final Landroidx/camera/core/k0$o$a;
.super Ljava/lang/Object;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k0$o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:Ljava/io/File;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$o$a;->a:Ljava/io/File;

    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/k0$o;
    .registers 3

    new-instance v0, Landroidx/camera/core/k0$o;

    iget-object v1, p0, Landroidx/camera/core/k0$o$a;->a:Ljava/io/File;

    invoke-direct {v0, v1}, Landroidx/camera/core/k0$o;-><init>(Ljava/io/File;)V

    return-object v0
.end method
