.class public interface abstract Landroidx/camera/core/r1;
.super Ljava/lang/Object;
.source "ZoomState.java"


# virtual methods
.method public abstract a()F
.end method

.method public abstract b()F
.end method

.method public abstract c()F
.end method

.method public abstract d()F
.end method
