.class final Landroidx/camera/core/k0$k;
.super Ljava/lang/Object;
.source "ImageCapture.java"

# interfaces
.implements Landroidx/camera/core/K$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/k0$k$c;,
        Landroidx/camera/core/k0$k$b;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/ArrayDeque;

.field b:Landroidx/camera/core/k0$j;

.field c:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Landroidx/camera/core/r0;",
            ">;"
        }
    .end annotation
.end field

.field d:I

.field private final e:Landroidx/camera/core/k0$k$b;

.field private final f:I

.field private final g:Landroidx/camera/core/k0$k$c;

.field final h:Ljava/lang/Object;


# direct methods
.method constructor <init>(Landroidx/camera/core/c0;Landroidx/camera/core/k0$c;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/k0$k;->a:Ljava/util/ArrayDeque;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    iput-object v0, p0, Landroidx/camera/core/k0$k;->c:Lcom/google/common/util/concurrent/o;

    const/4 v0, 0x0

    iput v0, p0, Landroidx/camera/core/k0$k;->d:I

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/k0$k;->h:Ljava/lang/Object;

    const/4 v0, 0x2

    iput v0, p0, Landroidx/camera/core/k0$k;->f:I

    iput-object p1, p0, Landroidx/camera/core/k0$k;->e:Landroidx/camera/core/k0$k$b;

    iput-object p2, p0, Landroidx/camera/core/k0$k;->g:Landroidx/camera/core/k0$k$c;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/RuntimeException;)V
    .registers 7

    iget-object v0, p0, Landroidx/camera/core/k0$k;->h:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    iget-object v3, p0, Landroidx/camera/core/k0$k;->c:Lcom/google/common/util/concurrent/o;

    iput-object v2, p0, Landroidx/camera/core/k0$k;->c:Lcom/google/common/util/concurrent/o;

    new-instance v2, Ljava/util/ArrayList;

    iget-object v4, p0, Landroidx/camera/core/k0$k;->a:Ljava/util/ArrayDeque;

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v4, p0, Landroidx/camera/core/k0$k;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v4}, Ljava/util/ArrayDeque;->clear()V

    monitor-exit v0
    :try_end_19
    .catchall {:try_start_3 .. :try_end_19} :catchall_49

    if-eqz v1, :cond_2c

    if-eqz v3, :cond_2c

    invoke-static {p1}, Landroidx/camera/core/k0;->P(Ljava/lang/Throwable;)I

    move-result v0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v0, v4, p1}, Landroidx/camera/core/k0$j;->d(ILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v0, 0x1

    invoke-interface {v3, v0}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_2c
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_30
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_48

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/k0$j;

    invoke-static {p1}, Landroidx/camera/core/k0;->P(Ljava/lang/Throwable;)I

    move-result v2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3, p1}, Landroidx/camera/core/k0$j;->d(ILjava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_30

    :cond_48
    return-void

    :catchall_49
    move-exception p1

    :try_start_4a
    monitor-exit v0
    :try_end_4b
    .catchall {:try_start_4a .. :try_end_4b} :catchall_49

    throw p1
.end method

.method public final b(Landroidx/camera/core/r0;)V
    .registers 3

    iget-object p1, p0, Landroidx/camera/core/k0$k;->h:Ljava/lang/Object;

    monitor-enter p1

    :try_start_3
    iget v0, p0, Landroidx/camera/core/k0$k;->d:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Landroidx/camera/core/k0$k;->d:I

    invoke-virtual {p0}, Landroidx/camera/core/k0$k;->c()V

    monitor-exit p1

    return-void

    :catchall_e
    move-exception v0

    monitor-exit p1
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_e

    throw v0
.end method

.method final c()V
    .registers 6

    iget-object v0, p0, Landroidx/camera/core/k0$k;->h:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    if-eqz v1, :cond_b

    monitor-exit v0

    return-void

    :catchall_9
    move-exception v1

    goto :goto_62

    :cond_b
    iget v1, p0, Landroidx/camera/core/k0$k;->d:I

    iget v2, p0, Landroidx/camera/core/k0$k;->f:I

    if-lt v1, v2, :cond_1a

    const-string v1, "ImageCapture"

    const-string v2, "Too many acquire images. Close image to be able to process next."

    invoke-static {v1, v2}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v0

    return-void

    :cond_1a
    iget-object v1, p0, Landroidx/camera/core/k0$k;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/k0$j;

    if-nez v1, :cond_26

    monitor-exit v0

    return-void

    :cond_26
    iput-object v1, p0, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    iget-object v2, p0, Landroidx/camera/core/k0$k;->g:Landroidx/camera/core/k0$k$c;

    if-eqz v2, :cond_40

    check-cast v2, Landroidx/camera/core/k0$c;

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    if-lt v3, v4, :cond_40

    iget v3, v1, Landroidx/camera/core/k0$j;->b:I

    iget-object v2, v2, Landroidx/camera/core/k0$c;->a:Lw/n;

    invoke-virtual {v2, v3}, Lw/n;->g(I)V

    iget v3, v1, Landroidx/camera/core/k0$j;->a:I

    invoke-virtual {v2, v3}, Lw/n;->h(I)V

    :cond_40
    iget-object v2, p0, Landroidx/camera/core/k0$k;->e:Landroidx/camera/core/k0$k$b;

    check-cast v2, Landroidx/camera/core/c0;

    iget-object v2, v2, Landroidx/camera/core/c0;->a:Landroidx/camera/core/k0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Landroidx/camera/core/i0;

    invoke-direct {v3, v2, v1}, Landroidx/camera/core/i0;-><init>(Landroidx/camera/core/k0;Landroidx/camera/core/k0$j;)V

    invoke-static {v3}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v2

    iput-object v2, p0, Landroidx/camera/core/k0$k;->c:Lcom/google/common/util/concurrent/o;

    new-instance v3, Landroidx/camera/core/k0$k$a;

    invoke-direct {v3, p0, v1}, Landroidx/camera/core/k0$k$a;-><init>(Landroidx/camera/core/k0$k;Landroidx/camera/core/k0$j;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-static {v2, v3, v1}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    monitor-exit v0

    return-void

    :goto_62
    monitor-exit v0
    :try_end_63
    .catchall {:try_start_3 .. :try_end_63} :catchall_9

    throw v1
.end method

.method public final d(Landroidx/camera/core/k0$j;)V
    .registers 7

    const-string v0, "Send image capture request [current, pending] = ["

    iget-object v1, p0, Landroidx/camera/core/k0$k;->h:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    iget-object v2, p0, Landroidx/camera/core/k0$k;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v2, p1}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    const-string p1, "ImageCapture"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    iget-object v2, p0, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    goto :goto_15

    :cond_14
    const/4 v2, 0x0

    :goto_15
    iget-object v3, p0, Landroidx/camera/core/k0$k;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v3}, Ljava/util/ArrayDeque;->size()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", "

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "]"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/camera/core/k0$k;->c()V

    monitor-exit v1

    return-void

    :catchall_3c
    move-exception p1

    monitor-exit v1
    :try_end_3e
    .catchall {:try_start_5 .. :try_end_3e} :catchall_3c

    throw p1
.end method
