.class public final Landroidx/camera/core/J0$c;
.super Ljava/lang/Object;
.source "Preview.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/J0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field private static final a:Landroidx/camera/core/impl/q0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroidx/camera/core/J0$b;

    invoke-direct {v0}, Landroidx/camera/core/J0$b;-><init>()V

    invoke-virtual {v0}, Landroidx/camera/core/J0$b;->h()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/camera/core/J0$b;->i(I)V

    invoke-virtual {v0}, Landroidx/camera/core/J0$b;->g()Landroidx/camera/core/impl/q0;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/J0$c;->a:Landroidx/camera/core/impl/q0;

    return-void
.end method

.method public static a()Landroidx/camera/core/impl/q0;
    .registers 1

    sget-object v0, Landroidx/camera/core/J0$c;->a:Landroidx/camera/core/impl/q0;

    return-object v0
.end method
