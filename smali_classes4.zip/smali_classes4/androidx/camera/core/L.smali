.class public interface abstract Landroidx/camera/core/l;
.super Ljava/lang/Object;
.source "Camera.java"


# virtual methods
.method public abstract a()Landroidx/camera/core/r;
.end method

.method public abstract b()Landroidx/camera/core/n;
.end method
