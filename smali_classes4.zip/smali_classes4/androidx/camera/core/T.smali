.class public abstract Landroidx/camera/core/t;
.super Ljava/lang/Object;
.source "CameraState.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/t$a;,
        Landroidx/camera/core/t$b;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroidx/camera/core/t$b;)Landroidx/camera/core/t;
    .registers 3

    new-instance v0, Landroidx/camera/core/f;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroidx/camera/core/f;-><init>(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)V

    return-object v0
.end method

.method public static b(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)Landroidx/camera/core/t;
    .registers 3

    new-instance v0, Landroidx/camera/core/f;

    invoke-direct {v0, p0, p1}, Landroidx/camera/core/f;-><init>(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)V

    return-object v0
.end method


# virtual methods
.method public abstract c()Landroidx/camera/core/t$a;
.end method

.method public abstract d()Landroidx/camera/core/t$b;
.end method
