.class public final synthetic Landroidx/camera/core/e1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/concurrent/futures/b$c;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p3, p0, Landroidx/camera/core/e1;->a:I

    iput-object p1, p0, Landroidx/camera/core/e1;->b:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/camera/core/e1;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/concurrent/futures/b$a;)Ljava/lang/String;
    .registers 5

    iget v0, p0, Landroidx/camera/core/e1;->a:I

    iget-object v1, p0, Landroidx/camera/core/e1;->c:Ljava/lang/Object;

    iget-object v2, p0, Landroidx/camera/core/e1;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_2c

    check-cast v2, Landroidx/camera/lifecycle/e;

    check-cast v1, Landroidx/camera/core/y;

    invoke-static {v1, v2, p1}, Landroidx/camera/lifecycle/e;->a(Landroidx/camera/core/y;Landroidx/camera/lifecycle/e;Landroidx/concurrent/futures/b$a;)V

    const-string p1, "ProcessCameraProvider-initializeCameraX"

    return-object p1

    :pswitch_13
    check-cast v2, Ljava/util/concurrent/atomic/AtomicReference;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "-status"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_13
    .end packed-switch
.end method
