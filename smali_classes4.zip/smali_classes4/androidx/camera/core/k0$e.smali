.class final Landroidx/camera/core/k0$e;
.super Landroidx/camera/core/k0$m;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/k0;->X(Landroidx/camera/core/k0$o;Ljava/util/concurrent/Executor;Landroidx/camera/core/k0$n;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/k0$o;

.field final synthetic b:I

.field final synthetic c:Ljava/util/concurrent/Executor;

.field final synthetic d:Landroidx/camera/core/x0$b;

.field final synthetic e:Landroidx/camera/core/k0$n;

.field final synthetic f:Landroidx/camera/core/k0;


# direct methods
.method constructor <init>(Landroidx/camera/core/k0;Landroidx/camera/core/k0$o;ILjava/util/concurrent/Executor;Landroidx/camera/core/x0$b;Landroidx/camera/core/k0$n;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$e;->f:Landroidx/camera/core/k0;

    iput-object p2, p0, Landroidx/camera/core/k0$e;->a:Landroidx/camera/core/k0$o;

    iput p3, p0, Landroidx/camera/core/k0$e;->b:I

    iput-object p4, p0, Landroidx/camera/core/k0$e;->c:Ljava/util/concurrent/Executor;

    iput-object p5, p0, Landroidx/camera/core/k0$e;->d:Landroidx/camera/core/x0$b;

    iput-object p6, p0, Landroidx/camera/core/k0$e;->e:Landroidx/camera/core/k0$n;

    return-void
.end method
