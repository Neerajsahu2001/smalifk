.class final Landroidx/camera/core/f;
.super Landroidx/camera/core/t;
.source "AutoValue_CameraState.java"


# instance fields
.field private final a:Landroidx/camera/core/t$b;

.field private final b:Landroidx/camera/core/t$a;


# direct methods
.method constructor <init>(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)V
    .registers 3

    invoke-direct {p0}, Landroidx/camera/core/t;-><init>()V

    if-eqz p1, :cond_a

    iput-object p1, p0, Landroidx/camera/core/f;->a:Landroidx/camera/core/t$b;

    iput-object p2, p0, Landroidx/camera/core/f;->b:Landroidx/camera/core/t$a;

    return-void

    :cond_a
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null type"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final c()Landroidx/camera/core/t$a;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/f;->b:Landroidx/camera/core/t$a;

    return-object v0
.end method

.method public final d()Landroidx/camera/core/t$b;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/f;->a:Landroidx/camera/core/t$b;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Landroidx/camera/core/t;

    const/4 v2, 0x0

    if-eqz v1, :cond_2f

    check-cast p1, Landroidx/camera/core/t;

    invoke-virtual {p1}, Landroidx/camera/core/t;->d()Landroidx/camera/core/t$b;

    move-result-object v1

    iget-object v3, p0, Landroidx/camera/core/f;->a:Landroidx/camera/core/t$b;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    iget-object v1, p0, Landroidx/camera/core/f;->b:Landroidx/camera/core/t$a;

    if-nez v1, :cond_22

    invoke-virtual {p1}, Landroidx/camera/core/t;->c()Landroidx/camera/core/t$a;

    move-result-object p1

    if-nez p1, :cond_2d

    goto :goto_2e

    :cond_22
    invoke-virtual {p1}, Landroidx/camera/core/t;->c()Landroidx/camera/core/t$a;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2d

    goto :goto_2e

    :cond_2d
    const/4 v0, 0x0

    :goto_2e
    return v0

    :cond_2f
    return v2
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/f;->a:Landroidx/camera/core/t$b;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int v0, v0, v1

    iget-object v1, p0, Landroidx/camera/core/f;->b:Landroidx/camera/core/t$a;

    if-nez v1, :cond_12

    const/4 v1, 0x0

    goto :goto_16

    :cond_12
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_16
    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "CameraState{type="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/core/f;->a:Landroidx/camera/core/t$b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", error="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/camera/core/f;->b:Landroidx/camera/core/t$a;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
