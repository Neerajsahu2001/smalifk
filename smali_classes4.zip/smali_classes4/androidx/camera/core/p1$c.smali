.class public final Landroidx/camera/core/p1$c;
.super Ljava/lang/Object;
.source "VideoCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/p1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field private static final a:Landroidx/camera/core/impl/G0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Landroid/util/Size;

    const/16 v1, 0x780

    const/16 v2, 0x438

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    new-instance v1, Landroidx/camera/core/p1$b;

    invoke-direct {v1}, Landroidx/camera/core/p1$b;-><init>()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->q()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->l()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->m()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->h()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->k()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->i()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->j()V

    invoke-virtual {v1, v0}, Landroidx/camera/core/p1$b;->n(Landroid/util/Size;)V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->o()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->p()V

    invoke-virtual {v1}, Landroidx/camera/core/p1$b;->g()Landroidx/camera/core/impl/G0;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/p1$c;->a:Landroidx/camera/core/impl/G0;

    return-void
.end method

.method public static a()Landroidx/camera/core/impl/G0;
    .registers 1

    sget-object v0, Landroidx/camera/core/p1$c;->a:Landroidx/camera/core/impl/G0;

    return-object v0
.end method
