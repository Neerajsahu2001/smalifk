.class public final Landroidx/camera/core/k1;
.super Ljava/lang/Object;
.source "UseCaseGroup.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/k1$a;
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/q1;

.field private final b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/camera/core/j1;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroidx/camera/core/q1;Ljava/util/ArrayList;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k1;->a:Landroidx/camera/core/q1;

    iput-object p2, p0, Landroidx/camera/core/k1;->b:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/j1;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/k1;->b:Ljava/util/List;

    return-object v0
.end method

.method public final b()Landroidx/camera/core/q1;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/k1;->a:Landroidx/camera/core/q1;

    return-object v0
.end method
