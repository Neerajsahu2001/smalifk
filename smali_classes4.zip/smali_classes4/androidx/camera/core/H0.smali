.class public final synthetic Landroidx/camera/core/h0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/k0$m;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/k0$m;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/h0;->a:Landroidx/camera/core/k0$m;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    new-instance v0, Landroidx/camera/core/n0;

    const-string v1, "Request is canceled"

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v3, v1, v2}, Landroidx/camera/core/n0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    iget-object v1, p0, Landroidx/camera/core/h0;->a:Landroidx/camera/core/k0$m;

    check-cast v1, Landroidx/camera/core/k0$e;

    iget-object v1, v1, Landroidx/camera/core/k0$e;->e:Landroidx/camera/core/k0$n;

    invoke-interface {v1, v0}, Landroidx/camera/core/k0$n;->a(Landroidx/camera/core/n0;)V

    return-void
.end method
