.class final Landroidx/camera/core/k0$d;
.super Ljava/lang/Object;
.source "ImageCapture.java"

# interfaces
.implements Landroidx/camera/core/x0$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/k0;->X(Landroidx/camera/core/k0$o;Ljava/util/concurrent/Executor;Landroidx/camera/core/k0$n;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/k0$n;


# direct methods
.method constructor <init>(Landroidx/camera/core/k0$n;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$d;->a:Landroidx/camera/core/k0$n;

    return-void
.end method
