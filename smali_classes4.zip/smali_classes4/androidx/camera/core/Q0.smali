.class public final synthetic Landroidx/camera/core/q0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/K$a;


# instance fields
.field public final synthetic a:Landroidx/camera/core/r0;

.field public final synthetic b:Landroidx/camera/core/r0;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/r0;Landroidx/camera/core/r0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/q0;->a:Landroidx/camera/core/r0;

    iput-object p2, p0, Landroidx/camera/core/q0;->b:Landroidx/camera/core/r0;

    return-void
.end method


# virtual methods
.method public final b(Landroidx/camera/core/r0;)V
    .registers 2

    sget p1, Landroidx/camera/core/ImageProcessingUtil;->b:I

    iget-object p1, p0, Landroidx/camera/core/q0;->a:Landroidx/camera/core/r0;

    if-eqz p1, :cond_d

    iget-object p1, p0, Landroidx/camera/core/q0;->b:Landroidx/camera/core/r0;

    if-eqz p1, :cond_d

    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    :cond_d
    return-void
.end method
