.class final Landroidx/camera/core/i1$a;
.super Ljava/lang/Object;
.source "SurfaceRequest.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/i1;-><init>(Landroid/util/Size;Landroidx/camera/core/impl/x;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/concurrent/futures/b$a;

.field final synthetic b:Lcom/google/common/util/concurrent/o;


# direct methods
.method constructor <init>(Landroidx/concurrent/futures/b$a;Lcom/google/common/util/concurrent/o;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/i1$a;->a:Landroidx/concurrent/futures/b$a;

    iput-object p2, p0, Landroidx/camera/core/i1$a;->b:Lcom/google/common/util/concurrent/o;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 4

    instance-of p1, p1, Landroidx/camera/core/i1$e;

    const/4 v0, 0x0

    if-eqz p1, :cond_10

    iget-object p1, p0, Landroidx/camera/core/i1$a;->b:Lcom/google/common/util/concurrent/o;

    const/4 v1, 0x0

    invoke-interface {p1, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    move-result p1

    invoke-static {p1, v0}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    goto :goto_19

    :cond_10
    iget-object p1, p0, Landroidx/camera/core/i1$a;->a:Landroidx/concurrent/futures/b$a;

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    move-result p1

    invoke-static {p1, v0}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    :goto_19
    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Ljava/lang/Void;

    iget-object p1, p0, Landroidx/camera/core/i1$a;->a:Landroidx/concurrent/futures/b$a;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    move-result p1

    invoke-static {p1, v0}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    return-void
.end method
