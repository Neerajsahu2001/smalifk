.class public final Landroidx/camera/core/k0$i;
.super Ljava/lang/Object;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "i"
.end annotation


# static fields
.field private static final a:Landroidx/camera/core/impl/V;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroidx/camera/core/k0$h;

    invoke-direct {v0}, Landroidx/camera/core/k0$h;-><init>()V

    invoke-virtual {v0}, Landroidx/camera/core/k0$h;->i()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/camera/core/k0$h;->j(I)V

    invoke-virtual {v0}, Landroidx/camera/core/k0$h;->g()Landroidx/camera/core/impl/V;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/k0$i;->a:Landroidx/camera/core/impl/V;

    return-void
.end method

.method public static a()Landroidx/camera/core/impl/V;
    .registers 1

    sget-object v0, Landroidx/camera/core/k0$i;->a:Landroidx/camera/core/impl/V;

    return-object v0
.end method
