.class final Landroidx/camera/core/l0;
.super Ljava/lang/Object;
.source "ImageCapture.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/concurrent/futures/b$a;

.field final synthetic b:Landroidx/camera/core/k0;


# direct methods
.method constructor <init>(Landroidx/camera/core/k0;Landroidx/concurrent/futures/b$a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/l0;->b:Landroidx/camera/core/k0;

    iput-object p2, p0, Landroidx/camera/core/l0;->a:Landroidx/concurrent/futures/b$a;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/l0;->b:Landroidx/camera/core/k0;

    invoke-virtual {v0}, Landroidx/camera/core/k0;->Z()V

    iget-object v0, p0, Landroidx/camera/core/l0;->a:Landroidx/concurrent/futures/b$a;

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/Void;

    iget-object p1, p0, Landroidx/camera/core/l0;->b:Landroidx/camera/core/k0;

    invoke-virtual {p1}, Landroidx/camera/core/k0;->Z()V

    return-void
.end method
