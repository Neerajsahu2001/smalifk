.class public final synthetic Landroidx/camera/core/j0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/impl/b0$a;


# instance fields
.field public final synthetic a:Landroidx/concurrent/futures/b$a;


# direct methods
.method public synthetic constructor <init>(Landroidx/concurrent/futures/b$a;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/j0;->a:Landroidx/concurrent/futures/b$a;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/b0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/j0;->a:Landroidx/concurrent/futures/b$a;

    :try_start_2
    invoke-interface {p1}, Landroidx/camera/core/impl/b0;->c()Landroidx/camera/core/r0;

    move-result-object p1

    if-eqz p1, :cond_14

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    goto :goto_22

    :catch_12
    move-exception p1

    goto :goto_1f

    :cond_14
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v1, "Unable to acquire image"

    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z
    :try_end_1e
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_1e} :catch_12

    goto :goto_22

    :goto_1f
    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    :cond_22
    :goto_22
    return-void
.end method
