.class public final Landroidx/camera/core/z$a;
.super Ljava/lang/Object;
.source "CameraXConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/k0;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/core/z$a;->a:Landroidx/camera/core/impl/k0;

    sget-object v1, Lw/h;->u:Landroidx/camera/core/impl/H$a;

    const/4 v2, 0x0

    :try_start_c
    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0
    :try_end_10
    .catch Ljava/lang/IllegalArgumentException; {:try_start_c .. :try_end_10} :catch_11

    goto :goto_13

    :catch_11
    nop

    move-object v0, v2

    :goto_13
    check-cast v0, Ljava/lang/Class;

    const-class v1, Landroidx/camera/core/y;

    if-eqz v0, :cond_3c

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_20

    goto :goto_3c

    :cond_20
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Invalid target class configuration for "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_3c
    :goto_3c
    sget-object v0, Lw/h;->u:Landroidx/camera/core/impl/H$a;

    iget-object v3, p0, Landroidx/camera/core/z$a;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v3, v0, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    sget-object v0, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    :try_start_45
    invoke-virtual {v3, v0}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v2
    :try_end_49
    .catch Ljava/lang/IllegalArgumentException; {:try_start_45 .. :try_end_49} :catch_4a

    goto :goto_4b

    :catch_4a
    nop

    :goto_4b
    if-nez v2, :cond_6e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lw/h;->t:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v3, v1, v0}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    :cond_6e
    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/z;
    .registers 3

    new-instance v0, Landroidx/camera/core/z;

    iget-object v1, p0, Landroidx/camera/core/z$a;->a:Landroidx/camera/core/impl/k0;

    invoke-static {v1}, Landroidx/camera/core/impl/o0;->D(Landroidx/camera/core/impl/j0;)Landroidx/camera/core/impl/o0;

    move-result-object v1

    invoke-direct {v0, v1}, Landroidx/camera/core/z;-><init>(Landroidx/camera/core/impl/o0;)V

    return-object v0
.end method

.method public final b(Ln/a;)V
    .registers 4

    sget-object v0, Landroidx/camera/core/z;->y:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z$a;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final c(Ln/b;)V
    .registers 4

    sget-object v0, Landroidx/camera/core/z;->z:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z$a;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method

.method public final d(Ln/c;)V
    .registers 4

    sget-object v0, Landroidx/camera/core/z;->A:Landroidx/camera/core/impl/H$a;

    iget-object v1, p0, Landroidx/camera/core/z$a;->a:Landroidx/camera/core/impl/k0;

    invoke-virtual {v1, v0, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    return-void
.end method
