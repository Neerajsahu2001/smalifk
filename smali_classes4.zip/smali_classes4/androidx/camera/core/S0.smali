.class public interface abstract Landroidx/camera/core/s0;
.super Ljava/lang/Object;
.source "ImageReaderProxyProvider.java"


# virtual methods
.method public abstract a()Landroidx/camera/core/impl/b0;
.end method
