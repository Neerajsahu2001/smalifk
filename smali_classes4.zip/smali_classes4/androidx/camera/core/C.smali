.class public final synthetic Landroidx/camera/core/c;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p3, p0, Landroidx/camera/core/c;->a:I

    iput-object p1, p0, Landroidx/camera/core/c;->b:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/camera/core/c;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget v0, p0, Landroidx/camera/core/c;->a:I

    iget-object v1, p0, Landroidx/camera/core/c;->c:Ljava/lang/Object;

    iget-object v2, p0, Landroidx/camera/core/c;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_1c

    check-cast v2, Landroidx/camera/core/k0$j;

    check-cast v1, Landroidx/camera/core/r0;

    invoke-static {v2, v1}, Landroidx/camera/core/k0$j;->a(Landroidx/camera/core/k0$j;Landroidx/camera/core/r0;)V

    return-void

    :pswitch_11
    check-cast v2, Landroidx/camera/core/d;

    check-cast v1, Landroidx/camera/core/impl/b0$a;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v1, v2}, Landroidx/camera/core/impl/b0$a;->a(Landroidx/camera/core/impl/b0;)V

    return-void

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method
