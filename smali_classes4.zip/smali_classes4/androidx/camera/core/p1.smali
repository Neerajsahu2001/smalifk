.class public final Landroidx/camera/core/p1;
.super Landroidx/camera/core/j1;
.source "VideoCapture.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/p1$a;,
        Landroidx/camera/core/p1$b;,
        Landroidx/camera/core/p1$c;
    }
.end annotation


# static fields
.field public static final y:Landroidx/camera/core/p1$c;

.field private static final z:[I


# instance fields
.field private final l:Ljava/lang/Object;

.field private m:Landroid/os/HandlerThread;

.field private n:Landroid/os/HandlerThread;

.field o:Landroid/media/MediaCodec;

.field private p:Landroid/media/MediaCodec;

.field private q:Landroidx/camera/core/impl/u0$b;

.field r:Landroid/view/Surface;

.field private volatile s:Landroid/media/AudioRecord;

.field private t:I

.field private u:I

.field private v:I

.field private w:Landroidx/camera/core/impl/c0;

.field private final x:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Landroidx/camera/core/p1$c;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/core/p1;->y:Landroidx/camera/core/p1$c;

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/16 v2, 0x8

    const/4 v3, 0x6

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Landroidx/camera/core/p1;->z:[I

    return-void
.end method

.method constructor <init>(Landroidx/camera/core/impl/G0;)V
    .registers 4

    invoke-direct {p0, p1}, Landroidx/camera/core/j1;-><init>(Landroidx/camera/core/impl/E0;)V

    new-instance p1, Landroid/media/MediaCodec$BufferInfo;

    invoke-direct {p1}, Landroid/media/MediaCodec$BufferInfo;-><init>()V

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/p1;->l:Ljava/lang/Object;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    new-instance p1, Landroid/media/MediaCodec$BufferInfo;

    invoke-direct {p1}, Landroid/media/MediaCodec$BufferInfo;-><init>()V

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {p1, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    new-instance p1, Landroidx/camera/core/impl/u0$b;

    invoke-direct {p1}, Landroidx/camera/core/impl/u0$b;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Landroidx/camera/core/p1;->x:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method private static K(Landroidx/camera/core/impl/G0;Landroid/util/Size;)Landroid/media/MediaFormat;
    .registers 4

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result v0

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result p1

    const-string v1, "video/avc"

    invoke-static {v1, v0, p1}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object p1

    const-string v0, "color-format"

    const v1, 0x7f000789

    invoke-virtual {p1, v0, v1}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/camera/core/impl/G0;->z:Landroidx/camera/core/impl/H$a;

    invoke-static {p0, v0}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const-string v1, "bitrate"

    invoke-virtual {p1, v1, v0}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    sget-object v0, Landroidx/camera/core/impl/G0;->y:Landroidx/camera/core/impl/H$a;

    invoke-static {p0, v0}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const-string v1, "frame-rate"

    invoke-virtual {p1, v1, v0}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    sget-object v0, Landroidx/camera/core/impl/G0;->A:Landroidx/camera/core/impl/H$a;

    invoke-static {p0, v0}, LVk/j;->f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const-string v0, "i-frame-interval"

    invoke-virtual {p1, v0, p0}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    return-object p1
.end method

.method private L(Z)V
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/p1;->w:Landroidx/camera/core/impl/c0;

    if-nez v0, :cond_5

    return-void

    :cond_5
    iget-object v1, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroidx/camera/core/impl/K;->c()V

    iget-object v0, p0, Landroidx/camera/core/p1;->w:Landroidx/camera/core/impl/c0;

    invoke-virtual {v0}, Landroidx/camera/core/impl/K;->i()Lcom/google/common/util/concurrent/o;

    move-result-object v0

    new-instance v2, Landroidx/camera/core/l1;

    invoke-direct {v2, p1, v1}, Landroidx/camera/core/l1;-><init>(ZLandroid/media/MediaCodec;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    invoke-interface {v0, v2, v1}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    const/4 v0, 0x0

    if-eqz p1, :cond_21

    iput-object v0, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    :cond_21
    iput-object v0, p0, Landroidx/camera/core/p1;->r:Landroid/view/Surface;

    iput-object v0, p0, Landroidx/camera/core/p1;->w:Landroidx/camera/core/impl/c0;

    return-void
.end method

.method private M()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/p1;->m:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    iget-object v0, p0, Landroidx/camera/core/p1;->n:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    iget-object v0, p0, Landroidx/camera/core/p1;->p:Landroid/media/MediaCodec;

    const/4 v1, 0x0

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    iput-object v1, p0, Landroidx/camera/core/p1;->p:Landroid/media/MediaCodec;

    :cond_14
    iget-object v0, p0, Landroidx/camera/core/p1;->s:Landroid/media/AudioRecord;

    if-eqz v0, :cond_1f

    iget-object v0, p0, Landroidx/camera/core/p1;->s:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->release()V

    iput-object v1, p0, Landroidx/camera/core/p1;->s:Landroid/media/AudioRecord;

    :cond_1f
    iget-object v0, p0, Landroidx/camera/core/p1;->r:Landroid/view/Surface;

    if-eqz v0, :cond_27

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroidx/camera/core/p1;->L(Z)V

    :cond_27
    return-void
.end method


# virtual methods
.method public final C()V
    .registers 1

    invoke-virtual {p0}, Landroidx/camera/core/p1;->O()V

    return-void
.end method

.method protected final D(Landroid/util/Size;)Landroid/util/Size;
    .registers 5

    iget-object v0, p0, Landroidx/camera/core/p1;->r:Landroid/view/Surface;

    if-eqz v0, :cond_1c

    iget-object v0, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->stop()V

    iget-object v0, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    iget-object v0, p0, Landroidx/camera/core/p1;->p:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->stop()V

    iget-object v0, p0, Landroidx/camera/core/p1;->p:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Landroidx/camera/core/p1;->L(Z)V

    :cond_1c
    :try_start_1c
    const-string v0, "video/avc"

    invoke-static {v0}, Landroid/media/MediaCodec;->createEncoderByType(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    const-string v0, "audio/mp4a-latm"

    invoke-static {v0}, Landroid/media/MediaCodec;->createEncoderByType(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/core/p1;->p:Landroid/media/MediaCodec;
    :try_end_2c
    .catch Ljava/io/IOException; {:try_start_1c .. :try_end_2c} :catch_37

    invoke-virtual {p0}, Landroidx/camera/core/j1;->e()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Landroidx/camera/core/p1;->N(Landroid/util/Size;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/camera/core/j1;->q()V

    return-object p1

    :catch_37
    move-exception p1

    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to create MediaCodec due to: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method final N(Landroid/util/Size;Ljava/lang/String;)V
    .registers 16

    invoke-virtual {p0}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/G0;

    iget-object v1, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    invoke-virtual {v1}, Landroid/media/MediaCodec;->reset()V

    :try_start_b
    iget-object v1, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    invoke-static {v0, p1}, Landroidx/camera/core/p1;->K(Landroidx/camera/core/impl/G0;Landroid/util/Size;)Landroid/media/MediaFormat;

    move-result-object v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v4, v4, v3}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V
    :try_end_16
    .catch Landroid/media/MediaCodec$CodecException; {:try_start_b .. :try_end_16} :catch_19f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b .. :try_end_16} :catch_1a1
    .catch Ljava/lang/IllegalStateException; {:try_start_b .. :try_end_16} :catch_1a1

    iget-object v1, p0, Landroidx/camera/core/p1;->r:Landroid/view/Surface;

    const/4 v2, 0x0

    if-eqz v1, :cond_1e

    invoke-direct {p0, v2}, Landroidx/camera/core/p1;->L(Z)V

    :cond_1e
    iget-object v1, p0, Landroidx/camera/core/p1;->o:Landroid/media/MediaCodec;

    invoke-virtual {v1}, Landroid/media/MediaCodec;->createInputSurface()Landroid/view/Surface;

    move-result-object v1

    iput-object v1, p0, Landroidx/camera/core/p1;->r:Landroid/view/Surface;

    invoke-static {v0}, Landroidx/camera/core/impl/u0$b;->m(Landroidx/camera/core/impl/E0;)Landroidx/camera/core/impl/u0$b;

    move-result-object v5

    iput-object v5, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    iget-object v5, p0, Landroidx/camera/core/p1;->w:Landroidx/camera/core/impl/c0;

    if-eqz v5, :cond_33

    invoke-virtual {v5}, Landroidx/camera/core/impl/K;->c()V

    :cond_33
    new-instance v5, Landroidx/camera/core/impl/c0;

    iget-object v6, p0, Landroidx/camera/core/p1;->r:Landroid/view/Surface;

    invoke-virtual {p0}, Landroidx/camera/core/j1;->h()I

    move-result v7

    invoke-direct {v5, v6, p1, v7}, Landroidx/camera/core/impl/c0;-><init>(Landroid/view/Surface;Landroid/util/Size;I)V

    iput-object v5, p0, Landroidx/camera/core/p1;->w:Landroidx/camera/core/impl/c0;

    invoke-virtual {v5}, Landroidx/camera/core/impl/K;->i()Lcom/google/common/util/concurrent/o;

    move-result-object v5

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, Landroidx/camera/core/m1;

    invoke-direct {v6, v1}, Landroidx/camera/core/m1;-><init>(Landroid/view/Surface;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    invoke-interface {v5, v6, v1}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    iget-object v1, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    iget-object v5, p0, Landroidx/camera/core/p1;->w:Landroidx/camera/core/impl/c0;

    invoke-virtual {v1, v5}, Landroidx/camera/core/impl/u0$b;->f(Landroidx/camera/core/impl/K;)V

    iget-object v1, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    new-instance v5, Landroidx/camera/core/o1;

    invoke-direct {v5, p0, p2, p1}, Landroidx/camera/core/o1;-><init>(Landroidx/camera/core/p1;Ljava/lang/String;Landroid/util/Size;)V

    invoke-virtual {v1, v5}, Landroidx/camera/core/impl/u0$b;->d(Landroidx/camera/core/impl/u0$c;)V

    iget-object v1, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    invoke-virtual {v1}, Landroidx/camera/core/impl/u0$b;->k()Landroidx/camera/core/impl/u0;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroidx/camera/core/j1;->I(Landroidx/camera/core/impl/u0;)V

    iget-object v1, p0, Landroidx/camera/core/p1;->x:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :try_start_72
    sget-object v1, Landroidx/camera/core/p1;->z:[I

    array-length v5, v1

    const/4 v6, 0x0

    :goto_76
    if-ge v6, v5, :cond_b3

    aget v7, v1, v6

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    invoke-static {v8, v7}, Landroid/media/CamcorderProfile;->hasProfile(II)Z

    move-result v8

    if-eqz v8, :cond_a9

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    invoke-static {v8, v7}, Landroid/media/CamcorderProfile;->get(II)Landroid/media/CamcorderProfile;

    move-result-object v7

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result v8

    iget v9, v7, Landroid/media/CamcorderProfile;->videoFrameWidth:I

    if-ne v8, v9, :cond_a9

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result v8

    iget v9, v7, Landroid/media/CamcorderProfile;->videoFrameHeight:I

    if-ne v8, v9, :cond_a9

    iget p1, v7, Landroid/media/CamcorderProfile;->audioChannels:I

    iput p1, p0, Landroidx/camera/core/p1;->t:I

    iget p1, v7, Landroid/media/CamcorderProfile;->audioSampleRate:I

    iput p1, p0, Landroidx/camera/core/p1;->u:I

    iget p1, v7, Landroid/media/CamcorderProfile;->audioBitRate:I

    iput p1, p0, Landroidx/camera/core/p1;->v:I
    :try_end_a8
    .catch Ljava/lang/NumberFormatException; {:try_start_72 .. :try_end_a8} :catch_ac

    goto :goto_f8

    :cond_a9
    add-int/lit8 v6, v6, 0x1

    goto :goto_76

    :catch_ac
    const-string p1, "VideoCapture"

    const-string p2, "The camera Id is not an integer because the camera may be a removable device. Use the default values for the audio related settings."

    invoke-static {p1, p2}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_b3
    invoke-virtual {p0}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object p1

    check-cast p1, Landroidx/camera/core/impl/G0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Landroidx/camera/core/impl/G0;->D:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p1}, Landroidx/camera/core/impl/G0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/o0;

    invoke-virtual {v1, p2}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    iput p2, p0, Landroidx/camera/core/p1;->t:I

    sget-object p2, Landroidx/camera/core/impl/G0;->C:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p1}, Landroidx/camera/core/impl/G0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/o0;

    invoke-virtual {v1, p2}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    iput p2, p0, Landroidx/camera/core/p1;->u:I

    sget-object p2, Landroidx/camera/core/impl/G0;->B:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p1}, Landroidx/camera/core/impl/G0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p1

    check-cast p1, Landroidx/camera/core/impl/o0;

    invoke-virtual {p1, p2}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iput p1, p0, Landroidx/camera/core/p1;->v:I

    :goto_f8
    iget-object p1, p0, Landroidx/camera/core/p1;->p:Landroid/media/MediaCodec;

    invoke-virtual {p1}, Landroid/media/MediaCodec;->reset()V

    iget-object p1, p0, Landroidx/camera/core/p1;->p:Landroid/media/MediaCodec;

    iget p2, p0, Landroidx/camera/core/p1;->u:I

    iget v1, p0, Landroidx/camera/core/p1;->t:I

    const-string v5, "audio/mp4a-latm"

    invoke-static {v5, p2, v1}, Landroid/media/MediaFormat;->createAudioFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object p2

    const-string v1, "aac-profile"

    const/4 v5, 0x2

    invoke-virtual {p2, v1, v5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v1, "bitrate"

    iget v6, p0, Landroidx/camera/core/p1;->v:I

    invoke-virtual {p2, v1, v6}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    invoke-virtual {p1, p2, v4, v4, v3}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    iget-object p1, p0, Landroidx/camera/core/p1;->s:Landroid/media/AudioRecord;

    if-eqz p1, :cond_122

    iget-object p1, p0, Landroidx/camera/core/p1;->s:Landroid/media/AudioRecord;

    invoke-virtual {p1}, Landroid/media/AudioRecord;->release()V

    :cond_122
    const-string p1, "VideoCapture"

    const-string p2, " audioFormat: 2 bufferSize: "

    const-string v1, "source: 5 audioSampleRate: "

    iget v6, p0, Landroidx/camera/core/p1;->t:I

    if-ne v6, v3, :cond_12f

    const/16 v6, 0x10

    goto :goto_131

    :cond_12f
    const/16 v6, 0xc

    :goto_131
    :try_start_131
    iget v7, p0, Landroidx/camera/core/p1;->u:I

    invoke-static {v7, v6, v5}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result v5

    if-gtz v5, :cond_14b

    sget-object v5, Landroidx/camera/core/impl/G0;->E:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Landroidx/camera/core/impl/G0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, v5}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v5

    :cond_14b
    new-instance v0, Landroid/media/AudioRecord;

    iget v9, p0, Landroidx/camera/core/p1;->u:I

    mul-int/lit8 v12, v5, 0x2

    const/4 v8, 0x5

    const/4 v11, 0x2

    move-object v7, v0

    move v10, v6

    invoke-direct/range {v7 .. v12}, Landroid/media/AudioRecord;-><init>(IIIII)V

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getState()I

    move-result v7

    if-ne v7, v3, :cond_185

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Landroidx/camera/core/p1;->u:I

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " channelConfig: "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_17d
    .catch Ljava/lang/Exception; {:try_start_131 .. :try_end_17d} :catch_17f

    move-object v4, v0

    goto :goto_185

    :catch_17f
    move-exception p2

    const-string v0, "Exception, keep trying."

    invoke-static {p1, v0, p2}, Landroidx/camera/core/A0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_185
    :goto_185
    iput-object v4, p0, Landroidx/camera/core/p1;->s:Landroid/media/AudioRecord;

    iget-object p1, p0, Landroidx/camera/core/p1;->s:Landroid/media/AudioRecord;

    if-nez p1, :cond_197

    const-string p1, "VideoCapture"

    const-string p2, "AudioRecord object cannot initialized correctly!"

    invoke-static {p1, p2}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/core/p1;->x:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_197
    iget-object p1, p0, Landroidx/camera/core/p1;->l:Ljava/lang/Object;

    monitor-enter p1

    :try_start_19a
    monitor-exit p1

    return-void

    :catchall_19c
    move-exception p2

    monitor-exit p1
    :try_end_19e
    .catchall {:try_start_19a .. :try_end_19e} :catchall_19c

    throw p2

    :catch_19f
    move-exception p1

    goto :goto_1a2

    :catch_1a1
    return-void

    :goto_1a2
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x17

    if-lt p2, v0, :cond_1ef

    invoke-static {p1}, Landroidx/camera/core/p1$a;->a(Landroid/media/MediaCodec$CodecException;)I

    move-result p2

    invoke-virtual {p1}, Landroid/media/MediaCodec$CodecException;->getDiagnosticInfo()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x44c

    if-ne p2, v0, :cond_1d0

    const-string v0, "VideoCapture"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "CodecException: code: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " diagnostic: "

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1ef

    :cond_1d0
    const/16 v0, 0x44d

    if-ne p2, v0, :cond_1ef

    const-string v0, "VideoCapture"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "CodecException: code: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " diagnostic: "

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1ef
    :goto_1ef
    return-void
.end method

.method public final O()V
    .registers 3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_17

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    new-instance v1, Landroidx/camera/core/n1;

    invoke-direct {v1, p0}, Landroidx/camera/core/n1;-><init>(Landroidx/camera/core/p1;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_17
    const-string v0, "VideoCapture"

    const-string v1, "stopRecording"

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->e(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    invoke-virtual {v0}, Landroidx/camera/core/impl/u0$b;->l()V

    iget-object v0, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    iget-object v1, p0, Landroidx/camera/core/p1;->w:Landroidx/camera/core/impl/c0;

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/u0$b;->f(Landroidx/camera/core/impl/K;)V

    iget-object v0, p0, Landroidx/camera/core/p1;->q:Landroidx/camera/core/impl/u0$b;

    invoke-virtual {v0}, Landroidx/camera/core/impl/u0$b;->k()Landroidx/camera/core/impl/u0;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/camera/core/j1;->I(Landroidx/camera/core/impl/u0;)V

    invoke-virtual {p0}, Landroidx/camera/core/j1;->u()V

    return-void
.end method

.method public final g(ZLandroidx/camera/core/impl/F0;)Landroidx/camera/core/impl/E0;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Landroidx/camera/core/impl/F0;",
            ")",
            "Landroidx/camera/core/impl/E0<",
            "*>;"
        }
    .end annotation

    sget-object v0, Landroidx/camera/core/impl/F0$b;->VIDEO_CAPTURE:Landroidx/camera/core/impl/F0$b;

    const/4 v1, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/camera/core/impl/F0;->a(Landroidx/camera/core/impl/F0$b;I)Landroidx/camera/core/impl/H;

    move-result-object p2

    if-eqz p1, :cond_16

    sget-object p1, Landroidx/camera/core/p1;->y:Landroidx/camera/core/p1$c;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroidx/camera/core/p1$c;->a()Landroidx/camera/core/impl/G0;

    move-result-object p1

    invoke-static {p2, p1}, Landroidx/camera/core/impl/G;->a(Landroidx/camera/core/impl/H;Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/o0;

    move-result-object p2

    :cond_16
    if-nez p2, :cond_1a

    const/4 p1, 0x0

    goto :goto_22

    :cond_1a
    invoke-static {p2}, Landroidx/camera/core/p1$b;->f(Landroidx/camera/core/impl/H;)Landroidx/camera/core/p1$b;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/camera/core/p1$b;->g()Landroidx/camera/core/impl/G0;

    move-result-object p1

    :goto_22
    return-object p1
.end method

.method public final m(Landroidx/camera/core/impl/H;)Landroidx/camera/core/impl/E0$a;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/H;",
            ")",
            "Landroidx/camera/core/impl/E0$a<",
            "***>;"
        }
    .end annotation

    invoke-static {p1}, Landroidx/camera/core/p1$b;->f(Landroidx/camera/core/impl/H;)Landroidx/camera/core/p1$b;

    move-result-object p1

    return-object p1
.end method

.method public final w()V
    .registers 3

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "CameraX-video encoding thread"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Landroidx/camera/core/p1;->m:Landroid/os/HandlerThread;

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "CameraX-audio encoding thread"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Landroidx/camera/core/p1;->n:Landroid/os/HandlerThread;

    iget-object v0, p0, Landroidx/camera/core/p1;->m:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Landroidx/camera/core/p1;->m:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iget-object v0, p0, Landroidx/camera/core/p1;->n:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Landroidx/camera/core/p1;->n:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method

.method public final z()V
    .registers 1

    invoke-virtual {p0}, Landroidx/camera/core/p1;->O()V

    invoke-direct {p0}, Landroidx/camera/core/p1;->M()V

    return-void
.end method
