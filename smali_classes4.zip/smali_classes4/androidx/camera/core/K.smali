.class final Landroidx/camera/core/k;
.super Landroidx/camera/core/i1$g;
.source "AutoValue_SurfaceRequest_TransformationInfo.java"


# instance fields
.field private final a:Landroid/graphics/Rect;

.field private final b:I

.field private final c:I


# direct methods
.method constructor <init>(Landroid/graphics/Rect;II)V
    .registers 4

    invoke-direct {p0}, Landroidx/camera/core/i1$g;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k;->a:Landroid/graphics/Rect;

    iput p2, p0, Landroidx/camera/core/k;->b:I

    iput p3, p0, Landroidx/camera/core/k;->c:I

    return-void
.end method


# virtual methods
.method public final a()Landroid/graphics/Rect;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/k;->a:Landroid/graphics/Rect;

    return-object v0
.end method

.method public final b()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/k;->b:I

    return v0
.end method

.method public final c()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/k;->c:I

    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Landroidx/camera/core/i1$g;

    const/4 v2, 0x0

    if-eqz v1, :cond_2a

    check-cast p1, Landroidx/camera/core/i1$g;

    invoke-virtual {p1}, Landroidx/camera/core/i1$g;->a()Landroid/graphics/Rect;

    move-result-object v1

    iget-object v3, p0, Landroidx/camera/core/k;->a:Landroid/graphics/Rect;

    invoke-virtual {v3, v1}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_28

    iget v1, p0, Landroidx/camera/core/k;->b:I

    invoke-virtual {p1}, Landroidx/camera/core/i1$g;->b()I

    move-result v3

    if-ne v1, v3, :cond_28

    iget v1, p0, Landroidx/camera/core/k;->c:I

    invoke-virtual {p1}, Landroidx/camera/core/i1$g;->c()I

    move-result p1

    if-ne v1, p1, :cond_28

    goto :goto_29

    :cond_28
    const/4 v0, 0x0

    :goto_29
    return v0

    :cond_2a
    return v2
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/k;->a:Landroid/graphics/Rect;

    invoke-virtual {v0}, Landroid/graphics/Rect;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int v0, v0, v1

    iget v2, p0, Landroidx/camera/core/k;->b:I

    xor-int/2addr v0, v2

    mul-int v0, v0, v1

    iget v1, p0, Landroidx/camera/core/k;->c:I

    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "TransformationInfo{cropRect="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/core/k;->a:Landroid/graphics/Rect;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", rotationDegrees="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/camera/core/k;->b:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", targetRotation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/camera/core/k;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
