.class public final synthetic Landroidx/camera/core/i0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/concurrent/futures/b$c;


# instance fields
.field public final synthetic a:Landroidx/camera/core/k0;

.field public final synthetic b:Landroidx/camera/core/k0$j;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/k0;Landroidx/camera/core/k0$j;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/i0;->a:Landroidx/camera/core/k0;

    iput-object p2, p0, Landroidx/camera/core/i0;->b:Landroidx/camera/core/k0$j;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/concurrent/futures/b$a;)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Landroidx/camera/core/i0;->a:Landroidx/camera/core/k0;

    iget-object v1, p0, Landroidx/camera/core/i0;->b:Landroidx/camera/core/k0$j;

    invoke-static {v0, v1, p1}, Landroidx/camera/core/k0;->K(Landroidx/camera/core/k0;Landroidx/camera/core/k0$j;Landroidx/concurrent/futures/b$a;)V

    const-string p1, "takePictureInternal"

    return-object p1
.end method
