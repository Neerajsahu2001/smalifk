.class public interface abstract Landroidx/camera/core/k0$n;
.super Ljava/lang/Object;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/k0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "n"
.end annotation


# virtual methods
.method public abstract a(Landroidx/camera/core/n0;)V
.end method

.method public abstract b(Landroidx/camera/core/k0$p;)V
.end method
