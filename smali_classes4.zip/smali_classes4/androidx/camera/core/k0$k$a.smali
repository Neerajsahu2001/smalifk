.class final Landroidx/camera/core/k0$k$a;
.super Ljava/lang/Object;
.source "ImageCapture.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/k0$k;->c()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Landroidx/camera/core/r0;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/k0$j;

.field final synthetic b:Landroidx/camera/core/k0$k;


# direct methods
.method constructor <init>(Landroidx/camera/core/k0$k;Landroidx/camera/core/k0$j;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/k0$k$a;->b:Landroidx/camera/core/k0$k;

    iput-object p2, p0, Landroidx/camera/core/k0$k$a;->a:Landroidx/camera/core/k0$j;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 6

    iget-object v0, p0, Landroidx/camera/core/k0$k$a;->b:Landroidx/camera/core/k0$k;

    iget-object v0, v0, Landroidx/camera/core/k0$k;->h:Ljava/lang/Object;

    monitor-enter v0

    :try_start_5
    instance-of v1, p1, Ljava/util/concurrent/CancellationException;

    if-eqz v1, :cond_a

    goto :goto_1e

    :cond_a
    iget-object v1, p0, Landroidx/camera/core/k0$k$a;->a:Landroidx/camera/core/k0$j;

    invoke-static {p1}, Landroidx/camera/core/k0;->P(Ljava/lang/Throwable;)I

    move-result v2

    if-eqz p1, :cond_19

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    goto :goto_1b

    :catchall_17
    move-exception p1

    goto :goto_2a

    :cond_19
    const-string v3, "Unknown error"

    :goto_1b
    invoke-virtual {v1, v2, v3, p1}, Landroidx/camera/core/k0$j;->d(ILjava/lang/String;Ljava/lang/Throwable;)V

    :goto_1e
    iget-object p1, p0, Landroidx/camera/core/k0$k$a;->b:Landroidx/camera/core/k0$k;

    const/4 v1, 0x0

    iput-object v1, p1, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    iput-object v1, p1, Landroidx/camera/core/k0$k;->c:Lcom/google/common/util/concurrent/o;

    invoke-virtual {p1}, Landroidx/camera/core/k0$k;->c()V

    monitor-exit v0

    return-void

    :goto_2a
    monitor-exit v0
    :try_end_2b
    .catchall {:try_start_5 .. :try_end_2b} :catchall_17

    throw p1
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 5

    check-cast p1, Landroidx/camera/core/r0;

    iget-object v0, p0, Landroidx/camera/core/k0$k$a;->b:Landroidx/camera/core/k0$k;

    iget-object v0, v0, Landroidx/camera/core/k0$k;->h:Ljava/lang/Object;

    monitor-enter v0

    :try_start_7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroidx/camera/core/a1;

    invoke-direct {v1, p1}, Landroidx/camera/core/a1;-><init>(Landroidx/camera/core/r0;)V

    iget-object p1, p0, Landroidx/camera/core/k0$k$a;->b:Landroidx/camera/core/k0$k;

    invoke-virtual {v1, p1}, Landroidx/camera/core/K;->c(Landroidx/camera/core/K$a;)V

    iget-object p1, p0, Landroidx/camera/core/k0$k$a;->b:Landroidx/camera/core/k0$k;

    iget v2, p1, Landroidx/camera/core/k0$k;->d:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p1, Landroidx/camera/core/k0$k;->d:I

    iget-object p1, p0, Landroidx/camera/core/k0$k$a;->a:Landroidx/camera/core/k0$j;

    invoke-virtual {p1, v1}, Landroidx/camera/core/k0$j;->c(Landroidx/camera/core/r0;)V

    iget-object p1, p0, Landroidx/camera/core/k0$k$a;->b:Landroidx/camera/core/k0$k;

    const/4 v1, 0x0

    iput-object v1, p1, Landroidx/camera/core/k0$k;->b:Landroidx/camera/core/k0$j;

    iput-object v1, p1, Landroidx/camera/core/k0$k;->c:Lcom/google/common/util/concurrent/o;

    invoke-virtual {p1}, Landroidx/camera/core/k0$k;->c()V

    monitor-exit v0

    return-void

    :catchall_2d
    move-exception p1

    monitor-exit v0
    :try_end_2f
    .catchall {:try_start_7 .. :try_end_2f} :catchall_2d

    throw p1
.end method
