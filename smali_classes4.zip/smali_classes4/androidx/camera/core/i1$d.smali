.class final Landroidx/camera/core/i1$d;
.super Ljava/lang/Object;
.source "SurfaceRequest.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/i1;->h(Landroid/view/Surface;Ljava/util/concurrent/Executor;Landroidx/core/util/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/core/util/a;

.field final synthetic b:Landroid/view/Surface;


# direct methods
.method constructor <init>(Landroidx/core/util/a;Landroid/view/Surface;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/i1$d;->a:Landroidx/core/util/a;

    iput-object p2, p0, Landroidx/camera/core/i1$d;->b:Landroid/view/Surface;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 5

    instance-of v0, p1, Landroidx/camera/core/i1$e;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Camera surface session should only fail with request cancellation. Instead failed due to:\n"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    new-instance p1, Landroidx/camera/core/j;

    const/4 v0, 0x1

    iget-object v1, p0, Landroidx/camera/core/i1$d;->b:Landroid/view/Surface;

    invoke-direct {p1, v0, v1}, Landroidx/camera/core/j;-><init>(ILandroid/view/Surface;)V

    iget-object v0, p0, Landroidx/camera/core/i1$d;->a:Landroidx/core/util/a;

    invoke-interface {v0, p1}, Landroidx/core/util/a;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Ljava/lang/Void;

    new-instance p1, Landroidx/camera/core/j;

    const/4 v0, 0x0

    iget-object v1, p0, Landroidx/camera/core/i1$d;->b:Landroid/view/Surface;

    invoke-direct {p1, v0, v1}, Landroidx/camera/core/j;-><init>(ILandroid/view/Surface;)V

    iget-object v0, p0, Landroidx/camera/core/i1$d;->a:Landroidx/core/util/a;

    invoke-interface {v0, p1}, Landroidx/core/util/a;->accept(Ljava/lang/Object;)V

    return-void
.end method
