.class final enum Landroidx/camera/core/y$a;
.super Ljava/lang/Enum;
.source "CameraX.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/y$a;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/y$a;

.field public static final enum INITIALIZED:Landroidx/camera/core/y$a;

.field public static final enum INITIALIZING:Landroidx/camera/core/y$a;

.field public static final enum INITIALIZING_ERROR:Landroidx/camera/core/y$a;

.field public static final enum SHUTDOWN:Landroidx/camera/core/y$a;

.field public static final enum UNINITIALIZED:Landroidx/camera/core/y$a;


# direct methods
.method static constructor <clinit>()V
    .registers 11

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v5, Landroidx/camera/core/y$a;

    const-string v6, "UNINITIALIZED"

    invoke-direct {v5, v6, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Landroidx/camera/core/y$a;->UNINITIALIZED:Landroidx/camera/core/y$a;

    new-instance v6, Landroidx/camera/core/y$a;

    const-string v7, "INITIALIZING"

    invoke-direct {v6, v7, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Landroidx/camera/core/y$a;->INITIALIZING:Landroidx/camera/core/y$a;

    new-instance v7, Landroidx/camera/core/y$a;

    const-string v8, "INITIALIZING_ERROR"

    invoke-direct {v7, v8, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Landroidx/camera/core/y$a;->INITIALIZING_ERROR:Landroidx/camera/core/y$a;

    new-instance v8, Landroidx/camera/core/y$a;

    const-string v9, "INITIALIZED"

    invoke-direct {v8, v9, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Landroidx/camera/core/y$a;->INITIALIZED:Landroidx/camera/core/y$a;

    new-instance v9, Landroidx/camera/core/y$a;

    const-string v10, "SHUTDOWN"

    invoke-direct {v9, v10, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Landroidx/camera/core/y$a;->SHUTDOWN:Landroidx/camera/core/y$a;

    const/4 v10, 0x5

    new-array v10, v10, [Landroidx/camera/core/y$a;

    aput-object v5, v10, v4

    aput-object v6, v10, v3

    aput-object v7, v10, v2

    aput-object v8, v10, v1

    aput-object v9, v10, v0

    sput-object v10, Landroidx/camera/core/y$a;->$VALUES:[Landroidx/camera/core/y$a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/y$a;
    .registers 2

    const-class v0, Landroidx/camera/core/y$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/y$a;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/y$a;
    .registers 1

    sget-object v0, Landroidx/camera/core/y$a;->$VALUES:[Landroidx/camera/core/y$a;

    invoke-virtual {v0}, [Landroidx/camera/core/y$a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/y$a;

    return-object v0
.end method
