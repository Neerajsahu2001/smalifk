.class public final Landroidx/camera/core/z0;
.super Ljava/lang/Exception;
.source "InitializationException.java"
