.class public final Landroidx/camera/core/q1;
.super Ljava/lang/Object;
.source "ViewPort.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/q1$a;
    }
.end annotation


# instance fields
.field private a:I

.field private b:Landroid/util/Rational;

.field private c:I

.field private d:I


# direct methods
.method constructor <init>(ILandroid/util/Rational;II)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroidx/camera/core/q1;->a:I

    iput-object p2, p0, Landroidx/camera/core/q1;->b:Landroid/util/Rational;

    iput p3, p0, Landroidx/camera/core/q1;->c:I

    iput p4, p0, Landroidx/camera/core/q1;->d:I

    return-void
.end method


# virtual methods
.method public final a()Landroid/util/Rational;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/q1;->b:Landroid/util/Rational;

    return-object v0
.end method

.method public final b()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/q1;->d:I

    return v0
.end method

.method public final c()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/q1;->c:I

    return v0
.end method

.method public final d()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/q1;->a:I

    return v0
.end method
