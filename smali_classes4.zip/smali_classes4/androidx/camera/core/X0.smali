.class final Landroidx/camera/core/x0;
.super Ljava/lang/Object;
.source "ImageSaver.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/core/x0$b;,
        Landroidx/camera/core/x0$c;
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/r0;

.field private final b:I

.field private final c:I

.field private final d:Landroidx/camera/core/k0$o;

.field private final e:Ljava/util/concurrent/Executor;

.field private final f:Landroidx/camera/core/x0$b;

.field private final g:Ljava/util/concurrent/Executor;


# direct methods
.method constructor <init>(Landroidx/camera/core/r0;Landroidx/camera/core/k0$o;IILjava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Landroidx/camera/core/x0$b;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/x0;->a:Landroidx/camera/core/r0;

    iput-object p2, p0, Landroidx/camera/core/x0;->d:Landroidx/camera/core/k0$o;

    iput p3, p0, Landroidx/camera/core/x0;->b:I

    iput p4, p0, Landroidx/camera/core/x0;->c:I

    iput-object p7, p0, Landroidx/camera/core/x0;->f:Landroidx/camera/core/x0$b;

    iput-object p5, p0, Landroidx/camera/core/x0;->e:Ljava/util/concurrent/Executor;

    iput-object p6, p0, Landroidx/camera/core/x0;->g:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public static a(Landroidx/camera/core/x0;Ljava/io/File;)V
    .registers 7

    iget-object v0, p0, Landroidx/camera/core/x0;->d:Landroidx/camera/core/k0$o;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    :try_start_6
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, p0, Landroidx/camera/core/x0;->d:Landroidx/camera/core/k0$o;

    invoke-virtual {v2}, Landroidx/camera/core/k0$o;->a()Ljava/io/File;

    move-result-object v2

    if-eqz v2, :cond_37

    invoke-virtual {v0}, Landroidx/camera/core/k0$o;->a()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_25

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    goto :goto_25

    :catchall_1f
    move-exception p0

    goto :goto_61

    :catch_21
    move-exception v0

    goto :goto_41

    :catch_23
    move-exception v0

    goto :goto_41

    :cond_25
    :goto_25
    invoke-virtual {p1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v2

    if-nez v2, :cond_30

    sget-object v2, Landroidx/camera/core/x0$c;->FILE_IO_FAILED:Landroidx/camera/core/x0$c;

    const-string v3, "Failed to rename file."

    goto :goto_32

    :cond_30
    move-object v2, v1

    move-object v3, v2

    :goto_32
    invoke-static {v0}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v0
    :try_end_36
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_36} :catch_23
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_36} :catch_21
    .catchall {:try_start_6 .. :try_end_36} :catchall_1f

    goto :goto_3a

    :cond_37
    move-object v0, v1

    move-object v2, v0

    move-object v3, v2

    :goto_3a
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    move-object v4, v1

    move-object v1, v0

    move-object v0, v4

    goto :goto_48

    :goto_41
    :try_start_41
    sget-object v2, Landroidx/camera/core/x0$c;->FILE_IO_FAILED:Landroidx/camera/core/x0$c;

    const-string v3, "Failed to write destination file."
    :try_end_45
    .catchall {:try_start_41 .. :try_end_45} :catchall_1f

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    :goto_48
    if-eqz v2, :cond_4e

    invoke-direct {p0, v2, v3, v0}, Landroidx/camera/core/x0;->e(Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_60

    :cond_4e
    :try_start_4e
    iget-object p1, p0, Landroidx/camera/core/x0;->e:Ljava/util/concurrent/Executor;

    new-instance v0, Landroidx/camera/core/w0;

    invoke-direct {v0, p0, v1}, Landroidx/camera/core/w0;-><init>(Landroidx/camera/core/x0;Landroid/net/Uri;)V

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_58
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_4e .. :try_end_58} :catch_59

    goto :goto_60

    :catch_59
    const-string p0, "ImageSaver"

    const-string p1, "Application executor rejected executing OnImageSavedCallback.onImageSaved callback. Skipping."

    invoke-static {p0, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    :goto_60
    return-void

    :goto_61
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    throw p0
.end method

.method public static b(Landroidx/camera/core/x0;Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Throwable;)V
    .registers 5

    iget-object p0, p0, Landroidx/camera/core/x0;->f:Landroidx/camera/core/x0$b;

    check-cast p0, Landroidx/camera/core/k0$d;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/camera/core/k0$g;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_13

    const/4 v0, 0x0

    :cond_13
    new-instance p1, Landroidx/camera/core/n0;

    invoke-direct {p1, v0, p2, p3}, Landroidx/camera/core/n0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Landroidx/camera/core/k0$d;->a:Landroidx/camera/core/k0$n;

    invoke-interface {p0, p1}, Landroidx/camera/core/k0$n;->a(Landroidx/camera/core/n0;)V

    return-void
.end method

.method public static c(Landroidx/camera/core/x0;)V
    .registers 2

    new-instance v0, Landroidx/camera/core/k0$p;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iget-object p0, p0, Landroidx/camera/core/x0;->f:Landroidx/camera/core/x0$b;

    check-cast p0, Landroidx/camera/core/k0$d;

    iget-object p0, p0, Landroidx/camera/core/k0$d;->a:Landroidx/camera/core/k0$n;

    invoke-interface {p0, v0}, Landroidx/camera/core/k0$n;->b(Landroidx/camera/core/k0$p;)V

    return-void
.end method

.method private static d(Landroidx/camera/core/r0;I)[B
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            LA/a$a;
        }
    .end annotation

    invoke-interface {p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v0

    invoke-interface {p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result v1

    invoke-interface {p0}, Landroidx/camera/core/r0;->getCropRect()Landroid/graphics/Rect;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v2

    invoke-interface {p0}, Landroidx/camera/core/r0;->getCropRect()Landroid/graphics/Rect;

    move-result-object v3

    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    move-result v3

    if-ne v0, v2, :cond_1f

    if-eq v1, v3, :cond_1d

    goto :goto_1f

    :cond_1d
    const/4 v0, 0x0

    goto :goto_20

    :cond_1f
    :goto_1f
    const/4 v0, 0x1

    :goto_20
    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result v1

    const/16 v2, 0x100

    if-ne v1, v2, :cond_38

    if-nez v0, :cond_2f

    invoke-static {p0}, LA/a;->c(Landroidx/camera/core/r0;)[B

    move-result-object p0

    return-object p0

    :cond_2f
    invoke-interface {p0}, Landroidx/camera/core/r0;->getCropRect()Landroid/graphics/Rect;

    move-result-object v0

    invoke-static {p0, v0, p1}, LA/a;->d(Landroidx/camera/core/r0;Landroid/graphics/Rect;I)[B

    move-result-object p0

    return-object p0

    :cond_38
    const/16 v2, 0x23

    const/4 v3, 0x0

    if-ne v1, v2, :cond_48

    if-eqz v0, :cond_43

    invoke-interface {p0}, Landroidx/camera/core/r0;->getCropRect()Landroid/graphics/Rect;

    move-result-object v3

    :cond_43
    invoke-static {p0, v3, p1}, LA/a;->e(Landroidx/camera/core/r0;Landroid/graphics/Rect;I)[B

    move-result-object p0

    return-object p0

    :cond_48
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "Unrecognized image format: "

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "ImageSaver"

    invoke-static {p1, p0}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    return-object v3
.end method

.method private e(Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 6

    :try_start_0
    iget-object v0, p0, Landroidx/camera/core/x0;->e:Ljava/util/concurrent/Executor;

    new-instance v1, Landroidx/camera/core/v0;

    invoke-direct {v1, p0, p1, p2, p3}, Landroidx/camera/core/v0;-><init>(Landroidx/camera/core/x0;Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_a
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_a} :catch_b

    goto :goto_12

    :catch_b
    const-string p1, "ImageSaver"

    const-string p2, "Application executor rejected executing OnImageSavedCallback.onError callback. Skipping."

    invoke-static {p1, p2}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    :goto_12
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 11

    iget-object v0, p0, Landroidx/camera/core/x0;->d:Landroidx/camera/core/k0$o;

    iget-object v1, p0, Landroidx/camera/core/x0;->a:Landroidx/camera/core/r0;

    const/4 v2, 0x0

    :try_start_5
    invoke-virtual {v0}, Landroidx/camera/core/k0$o;->a()Ljava/io/File;

    move-result-object v3
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_9} :catch_3b

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_f

    const/4 v3, 0x1

    goto :goto_10

    :cond_f
    const/4 v3, 0x0

    :goto_10
    const-string v6, ".tmp"

    const-string v7, "CameraX"

    if-eqz v3, :cond_3e

    :try_start_16
    new-instance v3, Ljava/io/File;

    invoke-virtual {v0}, Landroidx/camera/core/k0$o;->a()Ljava/io/File;

    move-result-object v8

    invoke-virtual {v8}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v3, v8, v6}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_42

    :catch_3b
    move-exception v0

    goto/16 :goto_f3

    :cond_3e
    invoke-static {v7, v6}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object v3
    :try_end_42
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_42} :catch_3b

    :goto_42
    :try_start_42
    new-instance v6, Ljava/io/FileOutputStream;

    invoke-direct {v6, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_47
    .catchall {:try_start_42 .. :try_end_47} :catchall_ad

    :try_start_47
    iget v7, p0, Landroidx/camera/core/x0;->c:I

    invoke-static {v1, v7}, Landroidx/camera/core/x0;->d(Landroidx/camera/core/r0;I)[B

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/io/FileOutputStream;->write([B)V

    invoke-static {v3}, Landroidx/camera/core/impl/utils/e;->b(Ljava/io/File;)Landroidx/camera/core/impl/utils/e;

    move-result-object v7

    invoke-interface {v1}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v8

    aget-object v4, v8, v4

    check-cast v4, Landroidx/camera/core/a$a;

    invoke-virtual {v4}, Landroidx/camera/core/a$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {v4}, Ljava/nio/Buffer;->capacity()I

    move-result v8

    new-array v8, v8, [B

    invoke-virtual {v4, v8}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    new-instance v4, Ljava/io/ByteArrayInputStream;

    invoke-direct {v4, v8}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {v4}, Landroidx/camera/core/impl/utils/e;->c(Ljava/io/ByteArrayInputStream;)Landroidx/camera/core/impl/utils/e;

    move-result-object v4

    invoke-virtual {v4, v7}, Landroidx/camera/core/impl/utils/e;->a(Landroidx/camera/core/impl/utils/e;)V

    const-class v4, Ly/b;

    invoke-static {v4}, Ly/a;->a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object v4

    check-cast v4, Ly/b;

    if-eqz v4, :cond_85

    sget-object v4, Landroidx/camera/core/impl/D;->h:Landroidx/camera/core/impl/H$a;

    goto :goto_8e

    :cond_85
    invoke-interface {v1}, Landroidx/camera/core/r0;->getFormat()I

    move-result v4

    const/16 v8, 0x100

    if-ne v4, v8, :cond_8e

    goto :goto_93

    :cond_8e
    :goto_8e
    iget v4, p0, Landroidx/camera/core/x0;->b:I

    invoke-virtual {v7, v4}, Landroidx/camera/core/impl/utils/e;->h(I)V

    :goto_93
    invoke-virtual {v0}, Landroidx/camera/core/k0$o;->b()Landroidx/camera/core/k0$l;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v7}, Landroidx/camera/core/impl/utils/e;->i()V
    :try_end_9d
    .catchall {:try_start_47 .. :try_end_9d} :catchall_af

    :try_start_9d
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V
    :try_end_a0
    .catchall {:try_start_9d .. :try_end_a0} :catchall_ad

    :try_start_a0
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V
    :try_end_a3
    .catch Ljava/io/IOException; {:try_start_a0 .. :try_end_a3} :catch_ab
    .catch Ljava/lang/IllegalArgumentException; {:try_start_a0 .. :try_end_a3} :catch_a9
    .catch LA/a$a; {:try_start_a0 .. :try_end_a3} :catch_a7

    move-object v0, v2

    move-object v1, v0

    move-object v4, v1

    goto :goto_e8

    :catch_a7
    move-exception v0

    goto :goto_c4

    :catch_a9
    move-exception v0

    goto :goto_e4

    :catch_ab
    move-exception v0

    goto :goto_e4

    :catchall_ad
    move-exception v0

    goto :goto_b9

    :catchall_af
    move-exception v0

    :try_start_b0
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V
    :try_end_b3
    .catchall {:try_start_b0 .. :try_end_b3} :catchall_b4

    goto :goto_b8

    :catchall_b4
    move-exception v4

    :try_start_b5
    invoke-virtual {v0, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_b8
    throw v0
    :try_end_b9
    .catchall {:try_start_b5 .. :try_end_b9} :catchall_ad

    :goto_b9
    if-eqz v1, :cond_c3

    :try_start_bb
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V
    :try_end_be
    .catchall {:try_start_bb .. :try_end_be} :catchall_bf

    goto :goto_c3

    :catchall_bf
    move-exception v1

    :try_start_c0
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_c3
    :goto_c3
    throw v0
    :try_end_c4
    .catch Ljava/io/IOException; {:try_start_c0 .. :try_end_c4} :catch_ab
    .catch Ljava/lang/IllegalArgumentException; {:try_start_c0 .. :try_end_c4} :catch_a9
    .catch LA/a$a; {:try_start_c0 .. :try_end_c4} :catch_a7

    :goto_c4
    sget-object v1, Landroidx/camera/core/x0$a;->a:[I

    invoke-virtual {v0}, LA/a$a;->a()LA/a$a$a;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aget v1, v1, v4

    if-eq v1, v5, :cond_df

    const/4 v4, 0x2

    if-eq v1, v4, :cond_da

    sget-object v1, Landroidx/camera/core/x0$c;->UNKNOWN:Landroidx/camera/core/x0$c;

    const-string v4, "Failed to transcode mImage"

    goto :goto_e8

    :cond_da
    sget-object v1, Landroidx/camera/core/x0$c;->CROP_FAILED:Landroidx/camera/core/x0$c;

    const-string v4, "Failed to crop mImage"

    goto :goto_e8

    :cond_df
    sget-object v1, Landroidx/camera/core/x0$c;->ENCODE_FAILED:Landroidx/camera/core/x0$c;

    const-string v4, "Failed to encode mImage"

    goto :goto_e8

    :goto_e4
    sget-object v1, Landroidx/camera/core/x0$c;->FILE_IO_FAILED:Landroidx/camera/core/x0$c;

    const-string v4, "Failed to write temp file"

    :goto_e8
    if-eqz v1, :cond_f1

    invoke-direct {p0, v1, v4, v0}, Landroidx/camera/core/x0;->e(Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    goto :goto_fa

    :cond_f1
    move-object v2, v3

    goto :goto_fa

    :goto_f3
    sget-object v1, Landroidx/camera/core/x0$c;->FILE_IO_FAILED:Landroidx/camera/core/x0$c;

    const-string v3, "Failed to create temp file"

    invoke-direct {p0, v1, v3, v0}, Landroidx/camera/core/x0;->e(Landroidx/camera/core/x0$c;Ljava/lang/String;Ljava/lang/Exception;)V

    :goto_fa
    if-eqz v2, :cond_106

    new-instance v0, Landroidx/camera/core/u0;

    invoke-direct {v0, p0, v2}, Landroidx/camera/core/u0;-><init>(Landroidx/camera/core/x0;Ljava/io/File;)V

    iget-object v1, p0, Landroidx/camera/core/x0;->g:Ljava/util/concurrent/Executor;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_106
    return-void
.end method
