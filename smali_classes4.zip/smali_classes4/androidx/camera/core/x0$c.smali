.class public final enum Landroidx/camera/core/x0$c;
.super Ljava/lang/Enum;
.source "ImageSaver.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/x0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/core/x0$c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/core/x0$c;

.field public static final enum CROP_FAILED:Landroidx/camera/core/x0$c;

.field public static final enum ENCODE_FAILED:Landroidx/camera/core/x0$c;

.field public static final enum FILE_IO_FAILED:Landroidx/camera/core/x0$c;

.field public static final enum UNKNOWN:Landroidx/camera/core/x0$c;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v4, Landroidx/camera/core/x0$c;

    const-string v5, "FILE_IO_FAILED"

    invoke-direct {v4, v5, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Landroidx/camera/core/x0$c;->FILE_IO_FAILED:Landroidx/camera/core/x0$c;

    new-instance v5, Landroidx/camera/core/x0$c;

    const-string v6, "ENCODE_FAILED"

    invoke-direct {v5, v6, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Landroidx/camera/core/x0$c;->ENCODE_FAILED:Landroidx/camera/core/x0$c;

    new-instance v6, Landroidx/camera/core/x0$c;

    const-string v7, "CROP_FAILED"

    invoke-direct {v6, v7, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Landroidx/camera/core/x0$c;->CROP_FAILED:Landroidx/camera/core/x0$c;

    new-instance v7, Landroidx/camera/core/x0$c;

    const-string v8, "UNKNOWN"

    invoke-direct {v7, v8, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Landroidx/camera/core/x0$c;->UNKNOWN:Landroidx/camera/core/x0$c;

    const/4 v8, 0x4

    new-array v8, v8, [Landroidx/camera/core/x0$c;

    aput-object v4, v8, v3

    aput-object v5, v8, v2

    aput-object v6, v8, v1

    aput-object v7, v8, v0

    sput-object v8, Landroidx/camera/core/x0$c;->$VALUES:[Landroidx/camera/core/x0$c;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/core/x0$c;
    .registers 2

    const-class v0, Landroidx/camera/core/x0$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/x0$c;

    return-object p0
.end method

.method public static values()[Landroidx/camera/core/x0$c;
    .registers 1

    sget-object v0, Landroidx/camera/core/x0$c;->$VALUES:[Landroidx/camera/core/x0$c;

    invoke-virtual {v0}, [Landroidx/camera/core/x0$c;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/core/x0$c;

    return-object v0
.end method
