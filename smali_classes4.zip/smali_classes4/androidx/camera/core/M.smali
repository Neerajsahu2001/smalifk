.class final Landroidx/camera/core/m;
.super Ljava/lang/RuntimeException;
.source "CameraClosedException.java"
