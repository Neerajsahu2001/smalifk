.class final Landroidx/camera/core/h;
.super Landroidx/camera/core/y0;
.source "AutoValue_ImmutableImageInfo.java"


# instance fields
.field private final a:Landroidx/camera/core/impl/B0;

.field private final b:J

.field private final c:I

.field private final d:Landroid/graphics/Matrix;


# direct methods
.method constructor <init>(Landroidx/camera/core/impl/B0;JILandroid/graphics/Matrix;)V
    .registers 6

    invoke-direct {p0}, Landroidx/camera/core/y0;-><init>()V

    if-eqz p1, :cond_18

    iput-object p1, p0, Landroidx/camera/core/h;->a:Landroidx/camera/core/impl/B0;

    iput-wide p2, p0, Landroidx/camera/core/h;->b:J

    iput p4, p0, Landroidx/camera/core/h;->c:I

    if-eqz p5, :cond_10

    iput-object p5, p0, Landroidx/camera/core/h;->d:Landroid/graphics/Matrix;

    return-void

    :cond_10
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null sensorToBufferTransformMatrix"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_18
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null tagBundle"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()J
    .registers 3

    iget-wide v0, p0, Landroidx/camera/core/h;->b:J

    return-wide v0
.end method

.method public final b()I
    .registers 2

    iget v0, p0, Landroidx/camera/core/h;->c:I

    return v0
.end method

.method public final d()Landroidx/camera/core/impl/B0;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/h;->a:Landroidx/camera/core/impl/B0;

    return-object v0
.end method

.method public final e()Landroid/graphics/Matrix;
    .registers 2

    iget-object v0, p0, Landroidx/camera/core/h;->d:Landroid/graphics/Matrix;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Landroidx/camera/core/y0;

    const/4 v2, 0x0

    if-eqz v1, :cond_35

    check-cast p1, Landroidx/camera/core/y0;

    move-object v1, p1

    check-cast v1, Landroidx/camera/core/h;

    iget-object v1, v1, Landroidx/camera/core/h;->a:Landroidx/camera/core/impl/B0;

    iget-object v3, p0, Landroidx/camera/core/h;->a:Landroidx/camera/core/impl/B0;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_33

    check-cast p1, Landroidx/camera/core/h;

    iget-wide v3, p0, Landroidx/camera/core/h;->b:J

    iget-wide v5, p1, Landroidx/camera/core/h;->b:J

    cmp-long v1, v3, v5

    if-nez v1, :cond_33

    iget v1, p0, Landroidx/camera/core/h;->c:I

    iget v3, p1, Landroidx/camera/core/h;->c:I

    if-ne v1, v3, :cond_33

    iget-object v1, p0, Landroidx/camera/core/h;->d:Landroid/graphics/Matrix;

    iget-object p1, p1, Landroidx/camera/core/h;->d:Landroid/graphics/Matrix;

    invoke-virtual {v1, p1}, Landroid/graphics/Matrix;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_33

    goto :goto_34

    :cond_33
    const/4 v0, 0x0

    :goto_34
    return v0

    :cond_35
    return v2
.end method

.method public final hashCode()I
    .registers 8

    iget-object v0, p0, Landroidx/camera/core/h;->a:Landroidx/camera/core/impl/B0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int v0, v0, v1

    const/16 v2, 0x20

    iget-wide v3, p0, Landroidx/camera/core/h;->b:J

    ushr-long v5, v3, v2

    xor-long v2, v5, v3

    long-to-int v3, v2

    xor-int/2addr v0, v3

    mul-int v0, v0, v1

    iget v2, p0, Landroidx/camera/core/h;->c:I

    xor-int/2addr v0, v2

    mul-int v0, v0, v1

    iget-object v1, p0, Landroidx/camera/core/h;->d:Landroid/graphics/Matrix;

    invoke-virtual {v1}, Landroid/graphics/Matrix;->hashCode()I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ImmutableImageInfo{tagBundle="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/core/h;->a:Landroidx/camera/core/impl/B0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", timestamp="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Landroidx/camera/core/h;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", rotationDegrees="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/camera/core/h;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", sensorToBufferTransformMatrix="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/camera/core/h;->d:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
