.class public final Landroidx/camera/core/O$d;
.super Ljava/lang/Object;
.source "ImageAnalysis.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/O;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# static fields
.field private static final a:Landroidx/camera/core/impl/U;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Landroid/util/Size;

    const/16 v1, 0x280

    const/16 v2, 0x1e0

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    new-instance v1, Landroidx/camera/core/O$c;

    invoke-direct {v1}, Landroidx/camera/core/O$c;-><init>()V

    invoke-virtual {v1, v0}, Landroidx/camera/core/O$c;->h(Landroid/util/Size;)V

    invoke-virtual {v1}, Landroidx/camera/core/O$c;->i()V

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, Landroidx/camera/core/O$c;->j(I)V

    invoke-virtual {v1}, Landroidx/camera/core/O$c;->g()Landroidx/camera/core/impl/U;

    move-result-object v0

    sput-object v0, Landroidx/camera/core/O$d;->a:Landroidx/camera/core/impl/U;

    return-void
.end method

.method public static a()Landroidx/camera/core/impl/U;
    .registers 1

    sget-object v0, Landroidx/camera/core/O$d;->a:Landroidx/camera/core/impl/U;

    return-object v0
.end method
