.class public final synthetic Landroidx/camera/core/b0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/impl/b0$a;


# virtual methods
.method public final a(Landroidx/camera/core/impl/b0;)V
    .registers 5

    const-string v0, "ImageCapture"

    const-string v1, "Discarding ImageProxy which was inadvertently acquired: "

    :try_start_4
    invoke-interface {p1}, Landroidx/camera/core/impl/b0;->c()Landroidx/camera/core/r0;

    move-result-object p1
    :try_end_8
    .catch Ljava/lang/IllegalStateException; {:try_start_4 .. :try_end_8} :catch_1d

    :try_start_8
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_17
    .catchall {:try_start_8 .. :try_end_17} :catchall_1f

    if-eqz p1, :cond_30

    :try_start_19
    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V
    :try_end_1c
    .catch Ljava/lang/IllegalStateException; {:try_start_19 .. :try_end_1c} :catch_1d

    goto :goto_30

    :catch_1d
    move-exception p1

    goto :goto_2b

    :catchall_1f
    move-exception v1

    if-eqz p1, :cond_2a

    :try_start_22
    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V
    :try_end_25
    .catchall {:try_start_22 .. :try_end_25} :catchall_26

    goto :goto_2a

    :catchall_26
    move-exception p1

    :try_start_27
    invoke-virtual {v1, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2a
    :goto_2a
    throw v1
    :try_end_2b
    .catch Ljava/lang/IllegalStateException; {:try_start_27 .. :try_end_2b} :catch_1d

    :goto_2b
    const-string v1, "Failed to acquire latest image."

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_30
    :goto_30
    return-void
.end method
