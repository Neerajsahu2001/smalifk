.class public final synthetic Landroidx/camera/core/w;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/y;

.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:Ljava/util/concurrent/Executor;

.field public final synthetic d:Landroidx/concurrent/futures/b$a;

.field public final synthetic e:J


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/y;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/b$a;J)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/w;->a:Landroidx/camera/core/y;

    iput-object p2, p0, Landroidx/camera/core/w;->b:Landroid/content/Context;

    iput-object p3, p0, Landroidx/camera/core/w;->c:Ljava/util/concurrent/Executor;

    iput-object p4, p0, Landroidx/camera/core/w;->d:Landroidx/concurrent/futures/b$a;

    iput-wide p5, p0, Landroidx/camera/core/w;->e:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    iget-object v3, p0, Landroidx/camera/core/w;->d:Landroidx/concurrent/futures/b$a;

    iget-wide v4, p0, Landroidx/camera/core/w;->e:J

    iget-object v0, p0, Landroidx/camera/core/w;->a:Landroidx/camera/core/y;

    iget-object v1, p0, Landroidx/camera/core/w;->b:Landroid/content/Context;

    iget-object v2, p0, Landroidx/camera/core/w;->c:Ljava/util/concurrent/Executor;

    invoke-static/range {v0 .. v5}, Landroidx/camera/core/y;->a(Landroidx/camera/core/y;Landroid/content/Context;Ljava/util/concurrent/Executor;Landroidx/concurrent/futures/b$a;J)V

    return-void
.end method
