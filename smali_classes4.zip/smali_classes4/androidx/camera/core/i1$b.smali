.class final Landroidx/camera/core/i1$b;
.super Landroidx/camera/core/impl/K;
.source "SurfaceRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/i1;-><init>(Landroid/util/Size;Landroidx/camera/core/impl/x;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic m:Landroidx/camera/core/i1;


# direct methods
.method constructor <init>(Landroidx/camera/core/i1;Landroid/util/Size;)V
    .registers 3

    iput-object p1, p0, Landroidx/camera/core/i1$b;->m:Landroidx/camera/core/i1;

    const/16 p1, 0x22

    invoke-direct {p0, p1, p2}, Landroidx/camera/core/impl/K;-><init>(ILandroid/util/Size;)V

    return-void
.end method


# virtual methods
.method protected final l()Lcom/google/common/util/concurrent/o;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Landroid/view/Surface;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/core/i1$b;->m:Landroidx/camera/core/i1;

    iget-object v0, v0, Landroidx/camera/core/i1;->e:Lcom/google/common/util/concurrent/o;

    return-object v0
.end method
