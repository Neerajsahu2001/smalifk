.class final Landroidx/camera/core/k0$a;
.super Landroidx/camera/core/impl/g;
.source "ImageCapture.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/core/k0;->N(Ljava/lang/String;Landroidx/camera/core/impl/V;Landroid/util/Size;)Landroidx/camera/core/impl/u0$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation
