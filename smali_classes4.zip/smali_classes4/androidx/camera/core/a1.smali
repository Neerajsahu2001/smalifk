.class final Landroidx/camera/core/a1;
.super Landroidx/camera/core/K;
.source "SingleCloseImageProxy.java"


# instance fields
.field private c:Z


# direct methods
.method constructor <init>(Landroidx/camera/core/r0;)V
    .registers 2

    invoke-direct {p0, p1}, Landroidx/camera/core/K;-><init>(Landroidx/camera/core/r0;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/core/a1;->c:Z

    return-void
.end method


# virtual methods
.method public final declared-synchronized close()V
    .registers 2

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Landroidx/camera/core/a1;->c:Z

    if-nez v0, :cond_e

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/camera/core/a1;->c:Z

    invoke-super {p0}, Landroidx/camera/core/K;->close()V
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_c

    goto :goto_e

    :catchall_c
    move-exception v0

    goto :goto_10

    :cond_e
    :goto_e
    monitor-exit p0

    return-void

    :goto_10
    monitor-exit p0

    throw v0
.end method
