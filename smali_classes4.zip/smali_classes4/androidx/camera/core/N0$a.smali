.class final Landroidx/camera/core/N0$a;
.super Ljava/lang/Object;
.source "ProcessingImageReader.java"

# interfaces
.implements Landroidx/camera/core/impl/b0$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/core/N0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/core/N0;


# direct methods
.method constructor <init>(Landroidx/camera/core/N0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/core/N0$a;->a:Landroidx/camera/core/N0;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/b0;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/core/N0$a;->a:Landroidx/camera/core/N0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/N0;->m(Landroidx/camera/core/impl/b0;)V

    return-void
.end method
