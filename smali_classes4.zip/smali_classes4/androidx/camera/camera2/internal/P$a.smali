.class final Landroidx/camera/camera2/internal/P$a;
.super Ljava/lang/Object;
.source "Camera2CapturePipeline.java"

# interfaces
.implements Landroidx/camera/camera2/internal/P$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/P;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/camera/camera2/internal/t;

.field private final b:Ls/k;

.field private final c:I

.field private d:Z


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/t;ILs/k;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/camera2/internal/P$a;->d:Z

    iput-object p1, p0, Landroidx/camera/camera2/internal/P$a;->a:Landroidx/camera/camera2/internal/t;

    iput p2, p0, Landroidx/camera/camera2/internal/P$a;->c:I

    iput-object p3, p0, Landroidx/camera/camera2/internal/P$a;->b:Ls/k;

    return-void
.end method

.method public static synthetic d(Landroidx/camera/camera2/internal/P$a;Landroidx/concurrent/futures/b$a;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/P$a;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/t;->q()Landroidx/camera/camera2/internal/J0;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/J0;->j(Landroidx/concurrent/futures/b$a;)V

    iget-object p0, p0, Landroidx/camera/camera2/internal/P$a;->b:Ls/k;

    invoke-virtual {p0}, Ls/k;->b()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/TotalCaptureResult;)Lcom/google/common/util/concurrent/o;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/hardware/camera2/TotalCaptureResult;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    iget v0, p0, Landroidx/camera/camera2/internal/P$a;->c:I

    invoke-static {v0, p1}, Landroidx/camera/camera2/internal/P;->a(ILandroid/hardware/camera2/TotalCaptureResult;)Z

    move-result p1

    if-eqz p1, :cond_32

    const-string p1, "Camera2CapturePipeline"

    const-string v0, "Trigger AE"

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/P$a;->d:Z

    new-instance p1, Landroidx/camera/camera2/internal/N;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/N;-><init>(Ljava/lang/Object;)V

    invoke-static {p1}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    invoke-static {p1}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object p1

    new-instance v0, Landroidx/camera/camera2/internal/O;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v0, v1}, Lv/f;->m(Lcom/google/common/util/concurrent/o;Lm/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    check-cast p1, Lv/d;

    return-object p1

    :cond_32
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method public final b()Z
    .registers 2

    iget v0, p0, Landroidx/camera/camera2/internal/P$a;->c:I

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public final c()V
    .registers 4

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/P$a;->d:Z

    if-eqz v0, :cond_1b

    const-string v0, "Camera2CapturePipeline"

    const-string v1, "cancel TriggerAePreCapture"

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/P$a;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/t;->q()Landroidx/camera/camera2/internal/J0;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroidx/camera/camera2/internal/J0;->d(ZZ)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/P$a;->b:Ls/k;

    invoke-virtual {v0}, Ls/k;->a()V

    :cond_1b
    return-void
.end method
