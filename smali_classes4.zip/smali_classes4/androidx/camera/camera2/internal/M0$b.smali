.class final Landroidx/camera/camera2/internal/M0$b;
.super Ljava/lang/Object;
.source "MeteringRepeatingSession.java"

# interfaces
.implements Landroidx/camera/core/impl/E0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/M0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/camera/core/impl/E0<",
        "Landroidx/camera/core/j1;",
        ">;"
    }
.end annotation


# instance fields
.field private final x:Landroidx/camera/core/impl/k0;


# direct methods
.method constructor <init>()V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    sget-object v1, Landroidx/camera/core/impl/E0;->o:Landroidx/camera/core/impl/H$a;

    new-instance v2, Landroidx/camera/camera2/internal/e0;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v0, v1, v2}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    iput-object v0, p0, Landroidx/camera/camera2/internal/M0$b;->x:Landroidx/camera/core/impl/k0;

    return-void
.end method


# virtual methods
.method public final b(Lt/i;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/M0$b;->x:Landroidx/camera/core/impl/k0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/o0;->b(Lt/i;)V

    return-void
.end method

.method public final c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;
    .registers 3

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/M0$b;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final e(Landroidx/camera/core/impl/H$a;)Z
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/M0$b;->x:Landroidx/camera/core/impl/k0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/o0;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result p1

    return p1
.end method

.method public final f()I
    .registers 2

    sget-object v0, Landroidx/camera/core/impl/X;->e:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/M0$b;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0
.end method

.method public final g(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;
    .registers 4

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/M0$b;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, p1, p2}, Landroidx/camera/core/impl/o0;->g(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final getConfig()Landroidx/camera/core/impl/H;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/M0$b;->x:Landroidx/camera/core/impl/k0;

    return-object v0
.end method

.method public final h()Ljava/util/Set;
    .registers 2

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/M0$b;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0}, Landroidx/camera/core/impl/o0;->h()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic i(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    invoke-static {p0, p1}, Lw/g;->a(Lw/h;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public final l(Landroidx/camera/core/impl/H$a;)Ljava/util/Set;
    .registers 3

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/M0$b;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/o0;->l(Landroidx/camera/core/impl/H$a;)Ljava/util/Set;

    move-result-object p1

    return-object p1
.end method

.method public final t()Landroidx/camera/core/j1$b;
    .registers 3

    sget-object v0, Lw/j;->w:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/j1$b;

    return-object v0
.end method

.method public final u()Landroidx/camera/core/impl/u0;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/E0;->m:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/camera2/internal/M0$b;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/u0;

    return-object v0
.end method

.method public final synthetic v()I
    .registers 2

    invoke-static {p0}, Landroidx/camera/core/impl/D0;->a(Landroidx/camera/core/impl/E0;)I

    move-result v0

    return v0
.end method

.method public final w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/M0$b;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, p1, p2}, Landroidx/camera/core/impl/o0;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final x()Landroidx/camera/core/impl/u0$d;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/E0;->o:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/camera2/internal/M0$b;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/u0$d;

    return-object v0
.end method

.method public final y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;
    .registers 3

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/M0$b;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/impl/o0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/impl/o0;->y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object p1

    return-object p1
.end method

.method public final z()Landroidx/camera/core/s;
    .registers 3

    sget-object v0, Landroidx/camera/core/impl/E0;->r:Landroidx/camera/core/impl/H$a;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/camera/camera2/internal/M0$b;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/s;

    return-object v0
.end method
