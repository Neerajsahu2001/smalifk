.class public final synthetic Landroidx/camera/camera2/internal/m;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroidx/camera/camera2/internal/m;->a:I

    iput-object p2, p0, Landroidx/camera/camera2/internal/m;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget v0, p0, Landroidx/camera/camera2/internal/m;->a:I

    packed-switch v0, :pswitch_data_22

    iget-object v0, p0, Landroidx/camera/camera2/internal/m;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/camera/core/impl/z$b;

    check-cast v0, Landroidx/camera/camera2/internal/H$c;

    iget-object v1, v0, Landroidx/camera/camera2/internal/H$c;->c:Landroidx/camera/camera2/internal/H;

    iget-object v1, v1, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    sget-object v2, Landroidx/camera/camera2/internal/H$e;->PENDING_OPEN:Landroidx/camera/camera2/internal/H$e;

    if-ne v1, v2, :cond_19

    iget-object v0, v0, Landroidx/camera/camera2/internal/H$c;->c:Landroidx/camera/camera2/internal/H;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/H;->Q(Z)V

    :cond_19
    return-void

    :pswitch_1a
    iget-object v0, p0, Landroidx/camera/camera2/internal/m;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/camera/camera2/internal/t;

    invoke-static {v0}, Landroidx/camera/camera2/internal/t;->g(Landroidx/camera/camera2/internal/t;)V

    return-void

    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_1a
    .end packed-switch
.end method
