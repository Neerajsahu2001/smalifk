.class final Landroidx/camera/camera2/internal/v0$a;
.super Landroid/hardware/camera2/CameraDevice$StateCallback;
.source "CaptureSessionRepository.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/v0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/v0;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/v0;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    invoke-direct {p0}, Landroid/hardware/camera2/CameraDevice$StateCallback;-><init>()V

    return-void
.end method

.method private a()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v0, v0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_5
    iget-object v1, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    invoke-virtual {v1}, Landroidx/camera/camera2/internal/v0;->e()Ljava/util/ArrayList;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/v0;->e:Ljava/util/LinkedHashSet;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    iget-object v2, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/v0;->c:Ljava/util/LinkedHashSet;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    iget-object v2, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/v0;->d:Ljava/util/LinkedHashSet;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    monitor-exit v0
    :try_end_21
    .catchall {:try_start_5 .. :try_end_21} :catchall_36

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_25
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_35

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0;

    invoke-interface {v1}, Landroidx/camera/camera2/internal/U0;->c()V

    goto :goto_25

    :cond_35
    return-void

    :catchall_36
    move-exception v1

    :try_start_37
    monitor-exit v0
    :try_end_38
    .catchall {:try_start_37 .. :try_end_38} :catchall_36

    throw v1
.end method

.method private b()V
    .registers 4

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_a
    iget-object v2, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/v0;->e:Ljava/util/LinkedHashSet;

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    iget-object v2, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/v0;->c:Ljava/util/LinkedHashSet;

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    monitor-exit v1
    :try_end_19
    .catchall {:try_start_a .. :try_end_19} :catchall_26

    iget-object v1, p0, Landroidx/camera/camera2/internal/v0$a;->a:Landroidx/camera/camera2/internal/v0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/v0;->a:Ljava/util/concurrent/Executor;

    new-instance v2, Landroidx/camera/camera2/internal/u0;

    invoke-direct {v2, v0}, Landroidx/camera/camera2/internal/u0;-><init>(Ljava/util/LinkedHashSet;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :catchall_26
    move-exception v0

    :try_start_27
    monitor-exit v1
    :try_end_28
    .catchall {:try_start_27 .. :try_end_28} :catchall_26

    throw v0
.end method


# virtual methods
.method public final onClosed(Landroid/hardware/camera2/CameraDevice;)V
    .registers 2

    invoke-direct {p0}, Landroidx/camera/camera2/internal/v0$a;->a()V

    return-void
.end method

.method public final onDisconnected(Landroid/hardware/camera2/CameraDevice;)V
    .registers 2

    invoke-direct {p0}, Landroidx/camera/camera2/internal/v0$a;->b()V

    invoke-direct {p0}, Landroidx/camera/camera2/internal/v0$a;->a()V

    return-void
.end method

.method public final onError(Landroid/hardware/camera2/CameraDevice;I)V
    .registers 3

    invoke-direct {p0}, Landroidx/camera/camera2/internal/v0$a;->b()V

    invoke-direct {p0}, Landroidx/camera/camera2/internal/v0$a;->a()V

    return-void
.end method

.method public final onOpened(Landroid/hardware/camera2/CameraDevice;)V
    .registers 2

    return-void
.end method
