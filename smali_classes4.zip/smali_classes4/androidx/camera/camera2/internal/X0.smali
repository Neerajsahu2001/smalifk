.class public final Landroidx/camera/camera2/internal/x0;
.super Ljava/lang/Object;
.source "DisplayInfoManager.java"


# static fields
.field private static final d:Landroid/util/Size;

.field private static final e:Ljava/lang/Object;

.field private static volatile f:Landroidx/camera/camera2/internal/x0;


# instance fields
.field private final a:Landroid/hardware/display/DisplayManager;

.field private volatile b:Landroid/util/Size;

.field private final c:Ls/i;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Landroid/util/Size;

    const/16 v1, 0x780

    const/16 v2, 0x438

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    sput-object v0, Landroidx/camera/camera2/internal/x0;->d:Landroid/util/Size;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/camera2/internal/x0;->e:Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/camera2/internal/x0;->b:Landroid/util/Size;

    new-instance v0, Ls/i;

    invoke-direct {v0}, Ls/i;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/x0;->c:Ls/i;

    const-string v0, "display"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/display/DisplayManager;

    iput-object p1, p0, Landroidx/camera/camera2/internal/x0;->a:Landroid/hardware/display/DisplayManager;

    return-void
.end method

.method private a()Landroid/util/Size;
    .registers 6

    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/x0;->c()Landroid/view/Display;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v1, v0, Landroid/graphics/Point;->x:I

    iget v2, v0, Landroid/graphics/Point;->y:I

    if-le v1, v2, :cond_1c

    new-instance v1, Landroid/util/Size;

    iget v2, v0, Landroid/graphics/Point;->x:I

    iget v0, v0, Landroid/graphics/Point;->y:I

    invoke-direct {v1, v2, v0}, Landroid/util/Size;-><init>(II)V

    goto :goto_25

    :cond_1c
    new-instance v1, Landroid/util/Size;

    iget v2, v0, Landroid/graphics/Point;->y:I

    iget v0, v0, Landroid/graphics/Point;->x:I

    invoke-direct {v1, v2, v0}, Landroid/util/Size;-><init>(II)V

    :goto_25
    invoke-virtual {v1}, Landroid/util/Size;->getWidth()I

    move-result v0

    invoke-virtual {v1}, Landroid/util/Size;->getHeight()I

    move-result v2

    mul-int v0, v0, v2

    sget-object v2, Landroidx/camera/camera2/internal/x0;->d:Landroid/util/Size;

    invoke-virtual {v2}, Landroid/util/Size;->getWidth()I

    move-result v3

    invoke-virtual {v2}, Landroid/util/Size;->getHeight()I

    move-result v4

    mul-int v3, v3, v4

    if-le v0, v3, :cond_3e

    move-object v1, v2

    :cond_3e
    iget-object v0, p0, Landroidx/camera/camera2/internal/x0;->c:Ls/i;

    invoke-virtual {v0, v1}, Ls/i;->a(Landroid/util/Size;)Landroid/util/Size;

    move-result-object v0

    return-object v0
.end method

.method public static b(Landroid/content/Context;)Landroidx/camera/camera2/internal/x0;
    .registers 3

    sget-object v0, Landroidx/camera/camera2/internal/x0;->f:Landroidx/camera/camera2/internal/x0;

    if-nez v0, :cond_19

    sget-object v0, Landroidx/camera/camera2/internal/x0;->e:Ljava/lang/Object;

    monitor-enter v0

    :try_start_7
    sget-object v1, Landroidx/camera/camera2/internal/x0;->f:Landroidx/camera/camera2/internal/x0;

    if-nez v1, :cond_15

    new-instance v1, Landroidx/camera/camera2/internal/x0;

    invoke-direct {v1, p0}, Landroidx/camera/camera2/internal/x0;-><init>(Landroid/content/Context;)V

    sput-object v1, Landroidx/camera/camera2/internal/x0;->f:Landroidx/camera/camera2/internal/x0;

    goto :goto_15

    :catchall_13
    move-exception p0

    goto :goto_17

    :cond_15
    :goto_15
    monitor-exit v0

    goto :goto_19

    :goto_17
    monitor-exit v0
    :try_end_18
    .catchall {:try_start_7 .. :try_end_18} :catchall_13

    throw p0

    :cond_19
    :goto_19
    sget-object p0, Landroidx/camera/camera2/internal/x0;->f:Landroidx/camera/camera2/internal/x0;

    return-object p0
.end method


# virtual methods
.method public final c()Landroid/view/Display;
    .registers 11

    iget-object v0, p0, Landroidx/camera/camera2/internal/x0;->a:Landroid/hardware/display/DisplayManager;

    invoke-virtual {v0}, Landroid/hardware/display/DisplayManager;->getDisplays()[Landroid/view/Display;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v1, v3, :cond_e

    aget-object v0, v0, v2

    return-object v0

    :cond_e
    array-length v1, v0

    const/4 v4, 0x0

    const/4 v5, -0x1

    :goto_11
    if-ge v2, v1, :cond_32

    aget-object v6, v0, v2

    invoke-virtual {v6}, Landroid/view/Display;->getState()I

    move-result v7

    if-eq v7, v3, :cond_2f

    new-instance v7, Landroid/graphics/Point;

    invoke-direct {v7}, Landroid/graphics/Point;-><init>()V

    invoke-virtual {v6, v7}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v8, v7, Landroid/graphics/Point;->x:I

    iget v7, v7, Landroid/graphics/Point;->y:I

    mul-int v9, v8, v7

    if-le v9, v5, :cond_2f

    mul-int v8, v8, v7

    move-object v4, v6

    move v5, v8

    :cond_2f
    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    :cond_32
    if-eqz v4, :cond_35

    return-object v4

    :cond_35
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "No display can be found from the input display manager!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method final d()Landroid/util/Size;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/x0;->b:Landroid/util/Size;

    if-eqz v0, :cond_7

    iget-object v0, p0, Landroidx/camera/camera2/internal/x0;->b:Landroid/util/Size;

    return-object v0

    :cond_7
    invoke-direct {p0}, Landroidx/camera/camera2/internal/x0;->a()Landroid/util/Size;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/x0;->b:Landroid/util/Size;

    iget-object v0, p0, Landroidx/camera/camera2/internal/x0;->b:Landroid/util/Size;

    return-object v0
.end method

.method final e()V
    .registers 2

    invoke-direct {p0}, Landroidx/camera/camera2/internal/x0;->a()Landroid/util/Size;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/x0;->b:Landroid/util/Size;

    return-void
.end method
