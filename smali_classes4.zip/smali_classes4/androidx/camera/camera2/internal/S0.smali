.class final Landroidx/camera/camera2/internal/s0;
.super Ljava/lang/Object;
.source "CaptureSession.java"

# interfaces
.implements Landroidx/camera/camera2/internal/t0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/s0$e;,
        Landroidx/camera/camera2/internal/s0$d;
    }
.end annotation


# instance fields
.field final a:Ljava/lang/Object;

.field private final b:Ljava/util/ArrayList;

.field private final c:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

.field private final d:Landroidx/camera/camera2/internal/s0$e;

.field e:Landroidx/camera/camera2/internal/e1;

.field f:Landroidx/camera/camera2/internal/U0;

.field g:Landroidx/camera/core/impl/u0;

.field h:Landroidx/camera/core/impl/o0;

.field i:Lo/c;

.field private final j:Ljava/util/HashMap;

.field k:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/K;",
            ">;"
        }
    .end annotation
.end field

.field l:Landroidx/camera/camera2/internal/s0$d;

.field m:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field n:Landroidx/concurrent/futures/b$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/concurrent/futures/b$a<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field final o:Ls/m;


# direct methods
.method constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    new-instance v0, Landroidx/camera/camera2/internal/s0$a;

    invoke-direct {v0}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->c:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    invoke-static {}, Landroidx/camera/core/impl/o0;->C()Landroidx/camera/core/impl/o0;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->h:Landroidx/camera/core/impl/o0;

    invoke-static {}, Lo/c;->e()Lo/c;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->i:Lo/c;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->j:Ljava/util/HashMap;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->k:Ljava/util/List;

    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->UNINITIALIZED:Landroidx/camera/camera2/internal/s0$d;

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    new-instance v0, Ls/m;

    invoke-direct {v0}, Ls/m;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->o:Ls/m;

    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->INITIALIZED:Landroidx/camera/camera2/internal/s0$d;

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    new-instance v0, Landroidx/camera/camera2/internal/s0$e;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/s0$e;-><init>(Landroidx/camera/camera2/internal/s0;)V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->d:Landroidx/camera/camera2/internal/s0$e;

    return-void
.end method

.method public static g(Landroidx/camera/camera2/internal/s0;Landroidx/camera/core/impl/u0;Landroid/hardware/camera2/CameraDevice;Ljava/util/List;)Lcom/google/common/util/concurrent/o;
    .registers 12

    const-string v0, "openCaptureSession() not execute in state: "

    const-string v1, "openCaptureSession() should not be possible in state: "

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v2

    :try_start_7
    sget-object v3, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v4, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aget v3, v3, v4

    const/4 v4, 0x1

    if-eq v3, v4, :cond_123

    const/4 v5, 0x2

    if-eq v3, v5, :cond_123

    const/4 v6, 0x3

    if-eq v3, v6, :cond_3a

    const/4 p1, 0x5

    if-eq v3, p1, :cond_123

    new-instance p1, Ljava/util/concurrent/CancellationException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    monitor-exit v2

    goto/16 :goto_13b

    :catchall_37
    move-exception p0

    goto/16 :goto_13c

    :cond_3a
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->j:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_41
    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v1, v3, :cond_5d

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->j:Ljava/util/HashMap;

    iget-object v6, p0, Landroidx/camera/camera2/internal/s0;->k:Ljava/util/List;

    invoke-interface {v6, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/camera/core/impl/K;

    invoke-interface {p3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/view/Surface;

    invoke-virtual {v3, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v1, v1, 0x1

    goto :goto_41

    :cond_5d
    new-instance v1, Ljava/util/ArrayList;

    new-instance v3, Ljava/util/LinkedHashSet;

    invoke-direct {v3, p3}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    sget-object p3, Landroidx/camera/camera2/internal/s0$d;->OPENING:Landroidx/camera/camera2/internal/s0$d;

    iput-object p3, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    const-string p3, "CaptureSession"

    const-string v3, "Opening capture session."

    invoke-static {p3, v3}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    new-array p3, v5, [Landroidx/camera/camera2/internal/U0$a;

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->d:Landroidx/camera/camera2/internal/s0$e;

    aput-object v3, p3, v0

    new-instance v0, Landroidx/camera/camera2/internal/f1$a;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->h()Ljava/util/List;

    move-result-object v3

    invoke-direct {v0, v3}, Landroidx/camera/camera2/internal/f1$a;-><init>(Ljava/util/List;)V

    aput-object v0, p3, v4

    new-instance v0, Landroidx/camera/camera2/internal/f1;

    invoke-static {p3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p3

    invoke-direct {v0, p3}, Landroidx/camera/camera2/internal/f1;-><init>(Ljava/util/List;)V

    new-instance p3, Lo/a;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->d()Landroidx/camera/core/impl/H;

    move-result-object v3

    invoke-direct {p3, v3}, Lt/j;-><init>(Landroidx/camera/core/impl/H;)V

    invoke-static {}, Lo/c;->e()Lo/c;

    move-result-object v3

    invoke-virtual {p3}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v4

    sget-object v5, Lo/a;->C:Landroidx/camera/core/impl/H$a;

    invoke-interface {v4, v5, v3}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lo/c;

    iput-object v3, p0, Landroidx/camera/camera2/internal/s0;->i:Lo/c;

    invoke-virtual {v3}, Lo/c;->d()Lo/c$a;

    move-result-object v3

    invoke-virtual {v3}, Lo/c$a;->c()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->g()Landroidx/camera/core/impl/D;

    move-result-object p1

    invoke-static {p1}, Landroidx/camera/core/impl/D$a;->j(Landroidx/camera/core/impl/D;)Landroidx/camera/core/impl/D$a;

    move-result-object p1

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_bb
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_cf

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/camera/core/impl/D;

    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v4

    invoke-virtual {p1, v4}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    goto :goto_bb

    :cond_cf
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_d8
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_fd

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/view/Surface;

    new-instance v5, Lq/c;

    invoke-direct {v5, v4}, Lq/c;-><init>(Landroid/view/Surface;)V

    invoke-virtual {p3}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v4

    sget-object v6, Lo/a;->E:Landroidx/camera/core/impl/H$a;

    const/4 v7, 0x0

    invoke-interface {v4, v6, v7}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v5, v4}, Lq/c;->c(Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_d8

    :cond_fd
    iget-object p3, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {p3, v3, v0}, Landroidx/camera/camera2/internal/e1;->a(Ljava/util/ArrayList;Landroidx/camera/camera2/internal/U0$a;)Lq/i;

    move-result-object p3
    :try_end_103
    .catchall {:try_start_7 .. :try_end_103} :catchall_37

    :try_start_103
    invoke-virtual {p1}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object p1

    invoke-static {p1, p2}, Landroidx/camera/camera2/internal/b0;->c(Landroidx/camera/core/impl/D;Landroid/hardware/camera2/CameraDevice;)Landroid/hardware/camera2/CaptureRequest;

    move-result-object p1

    if-eqz p1, :cond_113

    invoke-virtual {p3, p1}, Lq/i;->f(Landroid/hardware/camera2/CaptureRequest;)V
    :try_end_110
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_103 .. :try_end_110} :catch_111
    .catchall {:try_start_103 .. :try_end_110} :catchall_37

    goto :goto_113

    :catch_111
    move-exception p0

    goto :goto_11d

    :cond_113
    :goto_113
    :try_start_113
    iget-object p1, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    iget-object p0, p0, Landroidx/camera/camera2/internal/s0;->k:Ljava/util/List;

    invoke-virtual {p1, p2, p3, p0}, Landroidx/camera/camera2/internal/e1;->c(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    monitor-exit v2

    goto :goto_13b

    :goto_11d
    invoke-static {p0}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    monitor-exit v2

    goto :goto_13b

    :cond_123
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    monitor-exit v2

    :goto_13b
    return-object p0

    :goto_13c
    monitor-exit v2
    :try_end_13d
    .catchall {:try_start_113 .. :try_end_13d} :catchall_37

    throw p0
.end method

.method private static varargs h(Ljava/util/List;[Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;
    .registers 6

    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    array-length v2, p1

    add-int/2addr v1, v2

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3f

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/g;

    if-nez v1, :cond_1f

    const/4 v1, 0x0

    goto :goto_3b

    :cond_1f
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-static {v1, v2}, Landroidx/camera/camera2/internal/o0;->a(Landroidx/camera/core/impl/g;Ljava/util/ArrayList;)V

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x1

    if-ne v1, v3, :cond_36

    const/4 v1, 0x0

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    goto :goto_3b

    :cond_36
    new-instance v1, Landroidx/camera/camera2/internal/L$a;

    invoke-direct {v1, v2}, Landroidx/camera/camera2/internal/L$a;-><init>(Ljava/util/List;)V

    :goto_3b
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_f

    :cond_3f
    invoke-static {v0, p1}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    new-instance p0, Landroidx/camera/camera2/internal/L$a;

    invoke-direct {p0, v0}, Landroidx/camera/camera2/internal/L$a;-><init>(Ljava/util/List;)V

    return-object p0
.end method

.method private static m(Ljava/util/ArrayList;)Landroidx/camera/core/impl/k0;
    .registers 9

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_8
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6f

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/D;

    invoke-virtual {v1}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v1

    invoke-interface {v1}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_20
    :goto_20
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/H$a;

    const/4 v4, 0x0

    invoke-interface {v1, v3, v4}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v3}, Landroidx/camera/core/impl/o0;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result v6

    if-eqz v6, :cond_6b

    :try_start_37
    invoke-virtual {v0, v3}, Landroidx/camera/core/impl/o0;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v4
    :try_end_3b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_37 .. :try_end_3b} :catch_3c

    goto :goto_3d

    :catch_3c
    nop

    :goto_3d
    invoke-static {v4, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_20

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "Detect conflicting option "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Landroidx/camera/core/impl/H$a;->c()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " : "

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, " != "

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "CaptureSession"

    invoke-static {v4, v3}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_20

    :cond_6b
    invoke-virtual {v0, v3, v5}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    goto :goto_20

    :cond_6f
    return-object v0
.end method


# virtual methods
.method public final a(Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/D;",
            ">;)V"
        }
    .end annotation

    const-string v0, "issueCaptureRequests() should not be possible in state: "

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    sget-object v2, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v2, v2, v3

    packed-switch v2, :pswitch_data_44

    goto :goto_2b

    :pswitch_13
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Cannot issue capture request on a closed/released session."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_1b
    move-exception p1

    goto :goto_41

    :pswitch_1d
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/s0;->k()V

    goto :goto_2b

    :pswitch_26
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :goto_2b
    monitor-exit v1

    return-void

    :pswitch_2d
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_41
    monitor-exit v1
    :try_end_42
    .catchall {:try_start_5 .. :try_end_42} :catchall_1b

    throw p1

    nop

    :pswitch_data_44
    .packed-switch 0x1
        :pswitch_2d
        :pswitch_26
        :pswitch_26
        :pswitch_26
        :pswitch_1d
        :pswitch_13
        :pswitch_13
        :pswitch_13
    .end packed-switch
.end method

.method public final b()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1a

    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    goto :goto_1b

    :catchall_18
    move-exception v1

    goto :goto_47

    :cond_1a
    const/4 v1, 0x0

    :goto_1b
    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_18

    if-eqz v1, :cond_46

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_22
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_46

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/D;

    invoke-virtual {v1}, Landroidx/camera/core/impl/D;->a()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_36
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_22

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/g;

    invoke-virtual {v2}, Landroidx/camera/core/impl/g;->a()V

    goto :goto_36

    :cond_46
    return-void

    :goto_47
    :try_start_47
    monitor-exit v0
    :try_end_48
    .catchall {:try_start_47 .. :try_end_48} :catchall_18

    throw v1
.end method

.method public final c()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/D;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    monitor-exit v0

    return-object v1

    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public final close()V
    .registers 7

    const-string v0, "close() should not be possible in state: "

    const-string v1, "The Opener shouldn\'t null in state:"

    const-string v2, "The Opener shouldn\'t null in state:"

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v3

    :try_start_9
    sget-object v4, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v5, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    aget v4, v4, v5

    const/4 v5, 0x1

    if-eq v4, v5, :cond_87

    const/4 v0, 0x2

    if-eq v4, v0, :cond_81

    const/4 v0, 0x3

    if-eq v4, v0, :cond_69

    const/4 v0, 0x4

    if-eq v4, v0, :cond_49

    const/4 v0, 0x5

    if-eq v4, v0, :cond_23

    goto :goto_85

    :cond_23
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    if-eqz v0, :cond_49

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->i:Lo/c;

    invoke-virtual {v0}, Lo/c;->d()Lo/c$a;

    move-result-object v0

    invoke-virtual {v0}, Lo/c$a;->a()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1
    :try_end_35
    .catchall {:try_start_9 .. :try_end_35} :catchall_3f

    if-nez v1, :cond_49

    :try_start_37
    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/s0;->n(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/s0;->a(Ljava/util/List;)V
    :try_end_3e
    .catch Ljava/lang/IllegalStateException; {:try_start_37 .. :try_end_3e} :catch_41
    .catchall {:try_start_37 .. :try_end_3e} :catchall_3f

    goto :goto_49

    :catchall_3f
    move-exception v0

    goto :goto_9b

    :catch_41
    move-exception v0

    :try_start_42
    const-string v1, "CaptureSession"

    const-string v4, "Unable to issue the request before close the capture session"

    invoke-static {v1, v4, v0}, Landroidx/camera/core/A0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_49
    :goto_49
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/e1;->e()Z

    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->CLOSED:Landroidx/camera/camera2/internal/s0$d;

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    goto :goto_85

    :cond_69
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/e1;->e()Z

    :cond_81
    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->RELEASED:Landroidx/camera/camera2/internal/s0$d;

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    :goto_85
    monitor-exit v3

    return-void

    :cond_87
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_9b
    monitor-exit v3
    :try_end_9c
    .catchall {:try_start_42 .. :try_end_9c} :catchall_3f

    throw v0
.end method

.method public final d()Landroidx/camera/core/impl/u0;
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    monitor-exit v0

    return-object v1

    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public final e(Landroidx/camera/core/impl/u0;)V
    .registers 6

    const-string v0, "setSessionConfig() should not be possible in state: "

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    sget-object v2, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v2, v2, v3

    packed-switch v2, :pswitch_data_64

    goto :goto_4b

    :pswitch_13
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Session configuration cannot be set on a closed/released session."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_1b
    move-exception p1

    goto :goto_61

    :pswitch_1d
    iput-object p1, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    if-nez p1, :cond_23

    monitor-exit v1

    return-void

    :cond_23
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->j:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->j()Ljava/util/List;

    move-result-object p1

    invoke-interface {v0, p1}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z

    move-result p1

    if-nez p1, :cond_3c

    const-string p1, "CaptureSession"

    const-string v0, "Does not have the proper configured lists"

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v1

    return-void

    :cond_3c
    const-string p1, "CaptureSession"

    const-string v0, "Attempting to submit CaptureRequest after setting"

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    invoke-virtual {p0, p1}, Landroidx/camera/camera2/internal/s0;->l(Landroidx/camera/core/impl/u0;)V

    goto :goto_4b

    :pswitch_49
    iput-object p1, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    :goto_4b
    monitor-exit v1

    return-void

    :pswitch_4d
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_61
    monitor-exit v1
    :try_end_62
    .catchall {:try_start_5 .. :try_end_62} :catchall_1b

    throw p1

    nop

    :pswitch_data_64
    .packed-switch 0x1
        :pswitch_4d
        :pswitch_49
        :pswitch_49
        :pswitch_49
        :pswitch_1d
        :pswitch_13
        :pswitch_13
        :pswitch_13
    .end packed-switch
.end method

.method public final f(Landroidx/camera/core/impl/u0;Landroid/hardware/camera2/CameraDevice;Landroidx/camera/camera2/internal/e1;)Lcom/google/common/util/concurrent/o;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/u0;",
            "Landroid/hardware/camera2/CameraDevice;",
            "Landroidx/camera/camera2/internal/e1;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const-string v0, "open() should not allow the state: "

    const-string v1, "Open not allowed in state: "

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v2

    :try_start_7
    sget-object v3, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v4, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aget v3, v3, v4

    const/4 v4, 0x2

    if-eq v3, v4, :cond_42

    const-string p1, "CaptureSession"

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p3, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p3, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    monitor-exit v2

    return-object p1

    :catchall_40
    move-exception p1

    goto :goto_83

    :cond_42
    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->GET_SURFACE:Landroidx/camera/camera2/internal/s0$d;

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->j()Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v1, p0, Landroidx/camera/camera2/internal/s0;->k:Ljava/util/List;

    iput-object p3, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {p3, v1}, Landroidx/camera/camera2/internal/e1;->d(Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;

    move-result-object p3

    invoke-static {p3}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object p3

    new-instance v0, Landroidx/camera/camera2/internal/r0;

    invoke-direct {v0, p0, p1, p2}, Landroidx/camera/camera2/internal/r0;-><init>(Landroidx/camera/camera2/internal/s0;Landroidx/camera/core/impl/u0;Landroid/hardware/camera2/CameraDevice;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/e1;->b()Ljava/util/concurrent/Executor;

    move-result-object p1

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p3, v0, p1}, Lv/f;->n(Lcom/google/common/util/concurrent/o;Lv/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    check-cast p1, Lv/d;

    new-instance p2, Landroidx/camera/camera2/internal/s0$b;

    invoke-direct {p2, p0}, Landroidx/camera/camera2/internal/s0$b;-><init>(Landroidx/camera/camera2/internal/s0;)V

    iget-object p3, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {p3}, Landroidx/camera/camera2/internal/e1;->b()Ljava/util/concurrent/Executor;

    move-result-object p3

    invoke-static {p1, p2, p3}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    invoke-static {p1}, Lv/f;->i(Lcom/google/common/util/concurrent/o;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    monitor-exit v2

    return-object p1

    :goto_83
    monitor-exit v2
    :try_end_84
    .catchall {:try_start_7 .. :try_end_84} :catchall_40

    throw p1
.end method

.method final i()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    sget-object v1, Landroidx/camera/camera2/internal/s0$d;->RELEASED:Landroidx/camera/camera2/internal/s0$d;

    if-ne v0, v1, :cond_e

    const-string v0, "CaptureSession"

    const-string v1, "Skipping finishClose due to being state RELEASED."

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_e
    iput-object v1, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->n:Landroidx/concurrent/futures/b$a;

    if-eqz v1, :cond_1c

    invoke-virtual {v1, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->n:Landroidx/concurrent/futures/b$a;

    :cond_1c
    return-void
.end method

.method final j(Ljava/util/ArrayList;)V
    .registers 10

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_e

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_3 .. :try_end_a} :catchall_b

    return-void

    :catchall_b
    move-exception p1

    goto/16 :goto_13b

    :cond_e
    :try_start_e
    new-instance v1, Landroidx/camera/camera2/internal/f0;

    invoke-direct {v1}, Landroidx/camera/camera2/internal/f0;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const-string v3, "CaptureSession"

    const-string v4, "Issuing capture request."

    invoke-static {v3, v4}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v3, 0x0

    :goto_24
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_f3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/camera/core/impl/D;

    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->d()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_45

    const-string v4, "CaptureSession"

    const-string v5, "Skipping issuing empty capture request."

    invoke-static {v4, v5}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_24

    :catch_42
    move-exception p1

    goto/16 :goto_11c

    :cond_45
    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->d()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4d
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_78

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/camera/core/impl/K;

    iget-object v7, p0, Landroidx/camera/camera2/internal/s0;->j:Ljava/util/HashMap;

    invoke-virtual {v7, v6}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_4d

    const-string v4, "CaptureSession"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Skipping capture request with invalid surface: "

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_24

    :cond_78
    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->f()I

    move-result v5

    const/4 v6, 0x2

    if-ne v5, v6, :cond_80

    const/4 v3, 0x1

    :cond_80
    invoke-static {v4}, Landroidx/camera/core/impl/D$a;->j(Landroidx/camera/core/impl/D;)Landroidx/camera/core/impl/D$a;

    move-result-object v5

    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->f()I

    move-result v6

    const/4 v7, 0x5

    if-ne v6, v7, :cond_98

    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->b()Landroidx/camera/core/impl/o;

    move-result-object v6

    if-eqz v6, :cond_98

    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->b()Landroidx/camera/core/impl/o;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroidx/camera/core/impl/D$a;->m(Landroidx/camera/core/impl/o;)V

    :cond_98
    iget-object v6, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    if-eqz v6, :cond_a7

    invoke-virtual {v6}, Landroidx/camera/core/impl/u0;->g()Landroidx/camera/core/impl/D;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    :cond_a7
    iget-object v6, p0, Landroidx/camera/camera2/internal/s0;->h:Landroidx/camera/core/impl/o0;

    invoke-virtual {v5, v6}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    invoke-virtual {v5}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v5

    iget-object v6, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    invoke-interface {v6}, Landroidx/camera/camera2/internal/U0;->e()Landroid/hardware/camera2/CameraDevice;

    move-result-object v6

    iget-object v7, p0, Landroidx/camera/camera2/internal/s0;->j:Ljava/util/HashMap;

    invoke-static {v5, v6, v7}, Landroidx/camera/camera2/internal/b0;->b(Landroidx/camera/core/impl/D;Landroid/hardware/camera2/CameraDevice;Ljava/util/HashMap;)Landroid/hardware/camera2/CaptureRequest;

    move-result-object v5

    if-nez v5, :cond_ce

    const-string p1, "CaptureSession"

    const-string v1, "Skipping issuing request without surface."

    invoke-static {p1, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_cc
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_e .. :try_end_cc} :catch_42
    .catchall {:try_start_e .. :try_end_cc} :catchall_b

    :try_start_cc
    monitor-exit v0
    :try_end_cd
    .catchall {:try_start_cc .. :try_end_cd} :catchall_b

    return-void

    :cond_ce
    :try_start_ce
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v4}, Landroidx/camera/core/impl/D;->a()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_db
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_eb

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/camera/core/impl/g;

    invoke-static {v7, v6}, Landroidx/camera/camera2/internal/o0;->a(Landroidx/camera/core/impl/g;Ljava/util/ArrayList;)V

    goto :goto_db

    :cond_eb
    invoke-virtual {v1, v5, v6}, Landroidx/camera/camera2/internal/f0;->a(Landroid/hardware/camera2/CaptureRequest;Ljava/util/ArrayList;)V

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_24

    :cond_f3
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_114

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0;->o:Ls/m;

    invoke-virtual {p1, v2, v3}, Ls/m;->a(Ljava/util/ArrayList;Z)Z

    move-result p1

    if-eqz p1, :cond_10d

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    invoke-interface {p1}, Landroidx/camera/camera2/internal/U0;->i()V

    new-instance p1, Landroidx/camera/camera2/internal/p0;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/p0;-><init>(Ljava/lang/Object;)V

    iput-object p1, v1, Landroidx/camera/camera2/internal/f0;->b:Landroidx/camera/camera2/internal/f0$a;

    :cond_10d
    iget-object p1, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    invoke-interface {p1, v2, v1}, Landroidx/camera/camera2/internal/U0;->d(Ljava/util/ArrayList;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I
    :try_end_112
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_ce .. :try_end_112} :catch_42
    .catchall {:try_start_ce .. :try_end_112} :catchall_b

    :try_start_112
    monitor-exit v0
    :try_end_113
    .catchall {:try_start_112 .. :try_end_113} :catchall_b

    return-void

    :cond_114
    :try_start_114
    const-string p1, "CaptureSession"

    const-string v1, "Skipping issuing burst request due to no valid request elements"

    invoke-static {p1, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_11b
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_114 .. :try_end_11b} :catch_42
    .catchall {:try_start_114 .. :try_end_11b} :catchall_b

    goto :goto_139

    :goto_11c
    :try_start_11c
    const-string v1, "CaptureSession"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unable to access camera: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/Thread;->dumpStack()V

    :goto_139
    monitor-exit v0

    return-void

    :goto_13b
    monitor-exit v0
    :try_end_13c
    .catchall {:try_start_11c .. :try_end_13c} :catchall_b

    throw p1
.end method

.method final k()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->b:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_9

    return-void

    :cond_9
    :try_start_9
    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/s0;->j(Ljava/util/ArrayList;)V
    :try_end_c
    .catchall {:try_start_9 .. :try_end_c} :catchall_10

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void

    :catchall_10
    move-exception v1

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    throw v1
.end method

.method final l(Landroidx/camera/core/impl/u0;)V
    .registers 8

    const-string v0, "Unable to access camera: "

    const-string v1, "Unable to access camera: "

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v2

    if-nez p1, :cond_15

    :try_start_9
    const-string p1, "CaptureSession"

    const-string v0, "Skipping issueRepeatingCaptureRequests for no configuration case."

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v2

    return-void

    :catchall_12
    move-exception p1

    goto/16 :goto_b7

    :cond_15
    invoke-virtual {p1}, Landroidx/camera/core/impl/u0;->g()Landroidx/camera/core/impl/D;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/camera/core/impl/D;->d()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_4b

    const-string p1, "CaptureSession"

    const-string v0, "Skipping issueRepeatingCaptureRequests for no surface."

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2a
    .catchall {:try_start_9 .. :try_end_2a} :catchall_12

    :try_start_2a
    iget-object p1, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    invoke-interface {p1}, Landroidx/camera/camera2/internal/U0;->i()V
    :try_end_2f
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_2a .. :try_end_2f} :catch_30
    .catchall {:try_start_2a .. :try_end_2f} :catchall_12

    goto :goto_49

    :catch_30
    move-exception p1

    :try_start_31
    const-string v0, "CaptureSession"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/Thread;->dumpStack()V

    :goto_49
    monitor-exit v2
    :try_end_4a
    .catchall {:try_start_31 .. :try_end_4a} :catchall_12

    return-void

    :cond_4b
    :try_start_4b
    const-string v1, "CaptureSession"

    const-string v3, "Issuing request for session."

    invoke-static {v1, v3}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p1}, Landroidx/camera/core/impl/D$a;->j(Landroidx/camera/core/impl/D;)Landroidx/camera/core/impl/D$a;

    move-result-object v1

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->i:Lo/c;

    invoke-virtual {v3}, Lo/c;->d()Lo/c$a;

    move-result-object v3

    invoke-virtual {v3}, Lo/c$a;->d()Ljava/util/ArrayList;

    move-result-object v3

    invoke-static {v3}, Landroidx/camera/camera2/internal/s0;->m(Ljava/util/ArrayList;)Landroidx/camera/core/impl/k0;

    move-result-object v3

    iput-object v3, p0, Landroidx/camera/camera2/internal/s0;->h:Landroidx/camera/core/impl/o0;

    invoke-virtual {v1, v3}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    invoke-virtual {v1}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v1

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    invoke-interface {v3}, Landroidx/camera/camera2/internal/U0;->e()Landroid/hardware/camera2/CameraDevice;

    move-result-object v3

    iget-object v4, p0, Landroidx/camera/camera2/internal/s0;->j:Ljava/util/HashMap;

    invoke-static {v1, v3, v4}, Landroidx/camera/camera2/internal/b0;->b(Landroidx/camera/core/impl/D;Landroid/hardware/camera2/CameraDevice;Ljava/util/HashMap;)Landroid/hardware/camera2/CaptureRequest;

    move-result-object v1

    if-nez v1, :cond_86

    const-string p1, "CaptureSession"

    const-string v1, "Skipping issuing empty request for session."

    invoke-static {p1, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_82
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_4b .. :try_end_82} :catch_84
    .catchall {:try_start_4b .. :try_end_82} :catchall_12

    :try_start_82
    monitor-exit v2
    :try_end_83
    .catchall {:try_start_82 .. :try_end_83} :catchall_12

    return-void

    :catch_84
    move-exception p1

    goto :goto_9d

    :cond_86
    :try_start_86
    invoke-virtual {p1}, Landroidx/camera/core/impl/D;->a()Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x1

    new-array v3, v3, [Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    iget-object v4, p0, Landroidx/camera/camera2/internal/s0;->c:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-static {p1, v3}, Landroidx/camera/camera2/internal/s0;->h(Ljava/util/List;[Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    move-result-object p1

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    invoke-interface {v3, v1, p1}, Landroidx/camera/camera2/internal/U0;->f(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I
    :try_end_9b
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_86 .. :try_end_9b} :catch_84
    .catchall {:try_start_86 .. :try_end_9b} :catchall_12

    :try_start_9b
    monitor-exit v2

    return-void

    :goto_9d
    const-string v1, "CaptureSession"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/Thread;->dumpStack()V

    monitor-exit v2

    return-void

    :goto_b7
    monitor-exit v2
    :try_end_b8
    .catchall {:try_start_9b .. :try_end_b8} :catchall_12

    throw p1
.end method

.method final n(Ljava/util/ArrayList;)Ljava/util/ArrayList;
    .registers 6

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_9
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_43

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/D;

    invoke-static {v1}, Landroidx/camera/core/impl/D$a;->j(Landroidx/camera/core/impl/D;)Landroidx/camera/core/impl/D$a;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroidx/camera/core/impl/D$a;->o(I)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    invoke-virtual {v2}, Landroidx/camera/core/impl/u0;->g()Landroidx/camera/core/impl/D;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/camera/core/impl/D;->d()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/K;

    invoke-virtual {v1, v3}, Landroidx/camera/core/impl/D$a;->f(Landroidx/camera/core/impl/K;)V

    goto :goto_2b

    :cond_3b
    invoke-virtual {v1}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_9

    :cond_43
    return-object v0
.end method

.method public final release()Lcom/google/common/util/concurrent/o;
    .registers 7

    const-string v0, "release() should not be possible in state: "

    const-string v1, "The Opener shouldn\'t null in state:"

    const-string v2, "The Opener shouldn\'t null in state:"

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v3

    :try_start_9
    sget-object v4, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v5, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    aget v4, v4, v5

    packed-switch v4, :pswitch_data_90

    goto :goto_73

    :pswitch_17
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    if-eqz v0, :cond_21

    invoke-interface {v0}, Landroidx/camera/camera2/internal/U0;->close()V

    goto :goto_21

    :catchall_1f
    move-exception v0

    goto :goto_8e

    :cond_21
    :goto_21
    :pswitch_21
    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->RELEASING:Landroidx/camera/camera2/internal/s0$d;

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/e1;->e()Z

    move-result v0

    if-eqz v0, :cond_44

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/s0;->i()V

    goto :goto_73

    :cond_44
    :pswitch_44
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->m:Lcom/google/common/util/concurrent/o;

    if-nez v0, :cond_53

    new-instance v0, Landroidx/camera/camera2/internal/q0;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/q0;-><init>(Landroidx/camera/camera2/internal/s0;)V

    invoke-static {v0}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->m:Lcom/google/common/util/concurrent/o;

    :cond_53
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->m:Lcom/google/common/util/concurrent/o;

    monitor-exit v3

    return-object v0

    :pswitch_57
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/e1;->e()Z

    :pswitch_6f
    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->RELEASED:Landroidx/camera/camera2/internal/s0$d;

    iput-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    :goto_73
    monitor-exit v3
    :try_end_74
    .catchall {:try_start_9 .. :try_end_74} :catchall_1f

    const/4 v0, 0x0

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    return-object v0

    :pswitch_7a
    :try_start_7a
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_8e
    monitor-exit v3
    :try_end_8f
    .catchall {:try_start_7a .. :try_end_8f} :catchall_1f

    throw v0

    :pswitch_data_90
    .packed-switch 0x1
        :pswitch_7a
        :pswitch_6f
        :pswitch_57
        :pswitch_21
        :pswitch_17
        :pswitch_17
        :pswitch_44
    .end packed-switch
.end method
