.class final Landroidx/camera/camera2/internal/H$f;
.super Landroid/hardware/camera2/CameraDevice$StateCallback;
.source "Camera2CameraImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/H;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/H$f$a;,
        Landroidx/camera/camera2/internal/H$f$b;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/concurrent/Executor;

.field private final b:Ljava/util/concurrent/ScheduledExecutorService;

.field private c:Landroidx/camera/camera2/internal/H$f$b;

.field d:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field private final e:Landroidx/camera/camera2/internal/H$f$a;

.field final synthetic f:Landroidx/camera/camera2/internal/H;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/H;Ljava/util/concurrent/Executor;Ljava/util/concurrent/ScheduledExecutorService;)V
    .registers 4

    iput-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-direct {p0}, Landroid/hardware/camera2/CameraDevice$StateCallback;-><init>()V

    new-instance p1, Landroidx/camera/camera2/internal/H$f$a;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/H$f$a;-><init>(Landroidx/camera/camera2/internal/H$f;)V

    iput-object p1, p0, Landroidx/camera/camera2/internal/H$f;->e:Landroidx/camera/camera2/internal/H$f$a;

    iput-object p2, p0, Landroidx/camera/camera2/internal/H$f;->a:Ljava/util/concurrent/Executor;

    iput-object p3, p0, Landroidx/camera/camera2/internal/H$f;->b:Ljava/util/concurrent/ScheduledExecutorService;

    return-void
.end method


# virtual methods
.method final a()Z
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->d:Ljava/util/concurrent/ScheduledFuture;

    const/4 v1, 0x0

    if-eqz v0, :cond_2a

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Cancelling scheduled re-open: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/H$f;->c:Landroidx/camera/camera2/internal/H$f$b;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {v2, v0}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->c:Landroidx/camera/camera2/internal/H$f$b;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f$b;->b()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/camera2/internal/H$f;->c:Landroidx/camera/camera2/internal/H$f$b;

    iget-object v2, p0, Landroidx/camera/camera2/internal/H$f;->d:Ljava/util/concurrent/ScheduledFuture;

    invoke-interface {v2, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    iput-object v0, p0, Landroidx/camera/camera2/internal/H$f;->d:Ljava/util/concurrent/ScheduledFuture;

    const/4 v1, 0x1

    :cond_2a
    return v1
.end method

.method final b()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->e:Landroidx/camera/camera2/internal/H$f$a;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f$a;->c()V

    return-void
.end method

.method final c()V
    .registers 7

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->c:Landroidx/camera/camera2/internal/H$f$b;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_8

    const/4 v0, 0x1

    goto :goto_9

    :cond_8
    const/4 v0, 0x0

    :goto_9
    const/4 v3, 0x0

    invoke-static {v0, v3}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->d:Ljava/util/concurrent/ScheduledFuture;

    if-nez v0, :cond_12

    goto :goto_13

    :cond_12
    const/4 v1, 0x0

    :goto_13
    invoke-static {v1, v3}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->e:Landroidx/camera/camera2/internal/H$f$a;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f$a;->a()Z

    move-result v1

    iget-object v4, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    if-eqz v1, :cond_64

    new-instance v1, Landroidx/camera/camera2/internal/H$f$b;

    iget-object v2, p0, Landroidx/camera/camera2/internal/H$f;->a:Ljava/util/concurrent/Executor;

    invoke-direct {v1, p0, v2}, Landroidx/camera/camera2/internal/H$f$b;-><init>(Landroidx/camera/camera2/internal/H$f;Ljava/util/concurrent/Executor;)V

    iput-object v1, p0, Landroidx/camera/camera2/internal/H$f;->c:Landroidx/camera/camera2/internal/H$f$b;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Attempting camera re-open in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f$a;->b()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "ms: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Landroidx/camera/camera2/internal/H$f;->c:Landroidx/camera/camera2/internal/H$f$b;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " activeResuming = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, v4, Landroidx/camera/camera2/internal/H;->x:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/H$f;->c:Landroidx/camera/camera2/internal/H$f$b;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f$a;->b()I

    move-result v0

    int-to-long v2, v0

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    iget-object v4, p0, Landroidx/camera/camera2/internal/H$f;->b:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v4, v1, v2, v3, v0}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/H$f;->d:Ljava/util/concurrent/ScheduledFuture;

    goto :goto_8f

    :cond_64
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v5, "Camera reopening attempted for "

    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, Landroidx/camera/camera2/internal/H$f$a;->b:Landroidx/camera/camera2/internal/H$f;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f;->d()Z

    move-result v0

    if-nez v0, :cond_76

    const/16 v0, 0x2710

    goto :goto_79

    :cond_76
    const v0, 0x1b7740

    :goto_79
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "ms without success."

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Camera2CameraImpl"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Landroidx/camera/camera2/internal/H$e;->PENDING_OPEN:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v4, v0, v3, v2}, Landroidx/camera/camera2/internal/H;->L(Landroidx/camera/camera2/internal/H$e;Landroidx/camera/core/t$a;Z)V

    :goto_8f
    return-void
.end method

.method final d()Z
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-boolean v1, v0, Landroidx/camera/camera2/internal/H;->x:Z

    if-eqz v1, :cond_f

    iget v0, v0, Landroidx/camera/camera2/internal/H;->l:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_10

    const/4 v2, 0x2

    if-ne v0, v2, :cond_f

    goto :goto_10

    :cond_f
    const/4 v1, 0x0

    :cond_10
    :goto_10
    return v1
.end method

.method public final onClosed(Landroid/hardware/camera2/CameraDevice;)V
    .registers 6

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    const-string v1, "CameraDevice.onClosed()"

    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->k:Landroid/hardware/camera2/CameraDevice;

    const/4 v1, 0x0

    if-nez v0, :cond_10

    const/4 v0, 0x1

    goto :goto_11

    :cond_10
    const/4 v0, 0x0

    :goto_11
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Unexpected onClose callback on camera device: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    sget-object p1, Landroidx/camera/camera2/internal/H$b;->a:[I

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget p1, p1, v0

    const/4 v0, 0x3

    if-eq p1, v0, :cond_6b

    const/4 v0, 0x6

    if-eq p1, v0, :cond_50

    const/4 v0, 0x7

    if-ne p1, v0, :cond_38

    goto :goto_6b

    :cond_38
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Camera closed while in state: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v1, v1, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_50
    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget v0, p1, Landroidx/camera/camera2/internal/H;->l:I

    if-eqz v0, :cond_67

    invoke-static {v0}, Landroidx/camera/camera2/internal/H;->A(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "Camera closed due to error: "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/H$f;->c()V

    goto :goto_7a

    :cond_67
    invoke-virtual {p1, v1}, Landroidx/camera/camera2/internal/H;->Q(Z)V

    goto :goto_7a

    :cond_6b
    :goto_6b
    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/H;->C()Z

    move-result p1

    const/4 v0, 0x0

    invoke-static {p1, v0}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/H;->z()V

    :goto_7a
    return-void
.end method

.method public final onDisconnected(Landroid/hardware/camera2/CameraDevice;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    const-string v1, "CameraDevice.onDisconnected()"

    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Landroidx/camera/camera2/internal/H$f;->onError(Landroid/hardware/camera2/CameraDevice;I)V

    return-void
.end method

.method public final onError(Landroid/hardware/camera2/CameraDevice;I)V
    .registers 15

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iput-object p1, v0, Landroidx/camera/camera2/internal/H;->k:Landroid/hardware/camera2/CameraDevice;

    iput p2, v0, Landroidx/camera/camera2/internal/H;->l:I

    sget-object v1, Landroidx/camera/camera2/internal/H$b;->a:[I

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const-string v1, " while in "

    const-string v2, " failed with "

    const-string v3, "CameraDevice.onError(): "

    const/4 v4, 0x3

    const-string v5, "Camera2CameraImpl"

    if-eq v0, v4, :cond_12d

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eq v0, v8, :cond_41

    if-eq v0, v7, :cond_41

    if-eq v0, v6, :cond_41

    const/4 v4, 0x7

    if-ne v0, v4, :cond_29

    goto/16 :goto_12d

    :cond_29
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "onError() should not be possible from state: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_41
    invoke-virtual {p1}, Landroid/hardware/camera2/CameraDevice;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-static {p2}, Landroidx/camera/camera2/internal/H;->A(I)Ljava/lang/String;

    move-result-object v9

    iget-object v10, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v10, v10, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " state. Will attempt recovering from error."

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    sget-object v1, Landroidx/camera/camera2/internal/H$e;->OPENING:Landroidx/camera/camera2/internal/H$e;

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_8e

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    sget-object v1, Landroidx/camera/camera2/internal/H$e;->OPENED:Landroidx/camera/camera2/internal/H$e;

    if-eq v0, v1, :cond_8e

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    sget-object v1, Landroidx/camera/camera2/internal/H$e;->REOPENING:Landroidx/camera/camera2/internal/H$e;

    if-ne v0, v1, :cond_8c

    goto :goto_8e

    :cond_8c
    const/4 v0, 0x0

    goto :goto_8f

    :cond_8e
    :goto_8e
    const/4 v0, 0x1

    :goto_8f
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v9, "Attempt to handle open error from non open state: "

    invoke-direct {v1, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v9, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v9, v9, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    const/4 v0, 0x2

    if-eq p2, v3, :cond_e6

    if-eq p2, v0, :cond_e6

    if-eq p2, v8, :cond_e6

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error observed on open (or opening) camera device "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/hardware/camera2/CameraDevice;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ": "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Landroidx/camera/camera2/internal/H;->A(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " closing camera."

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v5, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    if-ne p2, v4, :cond_d4

    const/4 v6, 0x5

    :cond_d4
    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    sget-object p2, Landroidx/camera/camera2/internal/H$e;->CLOSING:Landroidx/camera/camera2/internal/H$e;

    invoke-static {v6}, Landroidx/camera/core/t$a;->a(I)Landroidx/camera/core/t$a;

    move-result-object v0

    invoke-virtual {p1, p2, v0, v3}, Landroidx/camera/camera2/internal/H;->L(Landroidx/camera/camera2/internal/H$e;Landroidx/camera/core/t$a;Z)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/H;->u()V

    goto/16 :goto_162

    :cond_e6
    invoke-virtual {p1}, Landroid/hardware/camera2/CameraDevice;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2}, Landroidx/camera/camera2/internal/H;->A(I)Ljava/lang/String;

    move-result-object v1

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "Attempt to reopen camera["

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "] after error["

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "]"

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v5, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget v1, p1, Landroidx/camera/camera2/internal/H;->l:I

    if-eqz v1, :cond_113

    const/4 v2, 0x1

    :cond_113
    const-string v1, "Can only reopen camera device after error if the camera device is actually in an error state."

    invoke-static {v2, v1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    if-eq p2, v3, :cond_11f

    if-eq p2, v0, :cond_11d

    goto :goto_120

    :cond_11d
    const/4 v4, 0x1

    goto :goto_120

    :cond_11f
    const/4 v4, 0x2

    :goto_120
    sget-object p2, Landroidx/camera/camera2/internal/H$e;->REOPENING:Landroidx/camera/camera2/internal/H$e;

    invoke-static {v4}, Landroidx/camera/core/t$a;->a(I)Landroidx/camera/core/t$a;

    move-result-object v0

    invoke-virtual {p1, p2, v0, v3}, Landroidx/camera/camera2/internal/H;->L(Landroidx/camera/camera2/internal/H$e;Landroidx/camera/core/t$a;Z)V

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/H;->u()V

    goto :goto_162

    :cond_12d
    :goto_12d
    invoke-virtual {p1}, Landroid/hardware/camera2/CameraDevice;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2}, Landroidx/camera/camera2/internal/H;->A(I)Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " state. Will finish closing camera."

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v5, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/H;->u()V

    :goto_162
    return-void
.end method

.method public final onOpened(Landroid/hardware/camera2/CameraDevice;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    const-string v1, "CameraDevice.onOpened()"

    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iput-object p1, v0, Landroidx/camera/camera2/internal/H;->k:Landroid/hardware/camera2/CameraDevice;

    const/4 p1, 0x0

    iput p1, v0, Landroidx/camera/camera2/internal/H;->l:I

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/H$f;->b()V

    sget-object p1, Landroidx/camera/camera2/internal/H$b;->a:[I

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget p1, p1, v0

    const/4 v0, 0x3

    if-eq p1, v0, :cond_4f

    const/4 v0, 0x5

    if-eq p1, v0, :cond_42

    const/4 v0, 0x6

    if-eq p1, v0, :cond_42

    const/4 v0, 0x7

    if-ne p1, v0, :cond_2a

    goto :goto_4f

    :cond_2a
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "onOpened() should not be possible from state: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v1, v1, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_42
    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    sget-object v0, Landroidx/camera/camera2/internal/H$e;->OPENED:Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {p1, v0}, Landroidx/camera/camera2/internal/H;->K(Landroidx/camera/camera2/internal/H$e;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/H;->F()V

    goto :goto_64

    :cond_4f
    :goto_4f
    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/H;->C()Z

    move-result p1

    const/4 v0, 0x0

    invoke-static {p1, v0}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object p1, p1, Landroidx/camera/camera2/internal/H;->k:Landroid/hardware/camera2/CameraDevice;

    invoke-virtual {p1}, Landroid/hardware/camera2/CameraDevice;->close()V

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iput-object v0, p1, Landroidx/camera/camera2/internal/H;->k:Landroid/hardware/camera2/CameraDevice;

    :goto_64
    return-void
.end method
