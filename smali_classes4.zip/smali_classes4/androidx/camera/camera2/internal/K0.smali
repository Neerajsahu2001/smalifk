.class final Landroidx/camera/camera2/internal/k0;
.super Ljava/lang/Object;
.source "CameraSelectionOptimizer.java"


# direct methods
.method private static a(Lp/S;Ljava/lang/Integer;Ljava/util/List;)Ljava/lang/String;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lp/S;",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lp/k;
        }
    .end annotation

    const/4 v0, 0x0

    if-nez p1, :cond_4

    return-object v0

    :cond_4
    const-string v1, "0"

    invoke-interface {p2, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_49

    const-string v2, "1"

    invoke-interface {p2, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_15

    goto :goto_49

    :cond_15
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v3, 0x1

    if-ne p2, v3, :cond_30

    invoke-virtual {p0, v1}, Lp/S;->b(Ljava/lang/String;)Lp/E;

    move-result-object p0

    sget-object p1, Landroid/hardware/camera2/CameraCharacteristics;->LENS_FACING:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {p0, p1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    if-ne p0, v3, :cond_49

    move-object v0, v2

    goto :goto_49

    :cond_30
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    if-nez p1, :cond_49

    invoke-virtual {p0, v2}, Lp/S;->b(Ljava/lang/String;)Lp/E;

    move-result-object p0

    sget-object p1, Landroid/hardware/camera2/CameraCharacteristics;->LENS_FACING:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {p0, p1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    if-nez p0, :cond_49

    move-object v0, v1

    :cond_49
    :goto_49
    return-object v0
.end method

.method static b(Landroidx/camera/camera2/internal/v;Landroidx/camera/core/s;)Ljava/util/ArrayList;
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/z0;
        }
    .end annotation

    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/v;->e()Lp/S;

    move-result-object v1

    invoke-virtual {v1}, Lp/S;->c()[Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    if-nez p1, :cond_2c

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_17
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_26
    .catch Lp/k; {:try_start_0 .. :try_end_26} :catch_29
    .catch Landroidx/camera/core/u; {:try_start_0 .. :try_end_26} :catch_27

    goto :goto_17

    :catch_27
    move-exception p0

    goto :goto_7d

    :catch_29
    move-exception p0

    goto :goto_83

    :cond_2b
    return-object v0

    :cond_2c
    :try_start_2c
    invoke-virtual {p1}, Landroidx/camera/core/s;->d()Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/v;->e()Lp/S;

    move-result-object v3

    invoke-static {v3, v2, v1}, Landroidx/camera/camera2/internal/k0;->a(Lp/S;Ljava/lang/Integer;Ljava/util/List;)Ljava/lang/String;

    move-result-object v2
    :try_end_38
    .catch Ljava/lang/IllegalStateException; {:try_start_2c .. :try_end_38} :catch_39
    .catch Lp/k; {:try_start_2c .. :try_end_38} :catch_29
    .catch Landroidx/camera/core/u; {:try_start_2c .. :try_end_38} :catch_27

    goto :goto_3a

    :catch_39
    const/4 v2, 0x0

    :goto_3a
    :try_start_3a
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_43
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_56

    goto :goto_43

    :cond_56
    invoke-virtual {p0, v4}, Landroidx/camera/camera2/internal/v;->d(Ljava/lang/String;)Landroidx/camera/camera2/internal/K;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_43

    :cond_5e
    invoke-virtual {p1, v3}, Landroidx/camera/core/s;->b(Ljava/util/ArrayList;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_66
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_7c

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/camera/core/r;

    check-cast p1, Landroidx/camera/core/impl/w;

    invoke-interface {p1}, Landroidx/camera/core/impl/w;->b()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_7b
    .catch Lp/k; {:try_start_3a .. :try_end_7b} :catch_29
    .catch Landroidx/camera/core/u; {:try_start_3a .. :try_end_7b} :catch_27

    goto :goto_66

    :cond_7c
    return-object v0

    :goto_7d
    new-instance p1, Landroidx/camera/core/z0;

    invoke-direct {p1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :goto_83
    new-instance p1, Landroidx/camera/core/z0;

    new-instance v0, Landroidx/camera/core/u;

    invoke-direct {v0, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method
