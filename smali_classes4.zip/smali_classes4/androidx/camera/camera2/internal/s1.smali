.class final Landroidx/camera/camera2/internal/s1;
.super Ljava/lang/Object;
.source "ZslControlImpl.java"

# interfaces
.implements Landroidx/camera/camera2/internal/m1;


# instance fields
.field final a:Ljava/util/LinkedList;

.field final b:Ljava/util/LinkedList;

.field private c:Z

.field private d:Z

.field private e:Z

.field f:Landroidx/camera/core/X0;

.field private g:Landroidx/camera/core/impl/c0;

.field h:Landroid/media/ImageWriter;


# direct methods
.method constructor <init>(Lp/E;)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s1;->a:Ljava/util/LinkedList;

    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/s1;->b:Ljava/util/LinkedList;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/camera2/internal/s1;->c:Z

    iput-boolean v0, p0, Landroidx/camera/camera2/internal/s1;->d:Z

    iput-boolean v0, p0, Landroidx/camera/camera2/internal/s1;->e:Z

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->REQUEST_AVAILABLE_CAPABILITIES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {p1, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [I

    const/4 v2, 0x1

    if-eqz v1, :cond_31

    array-length v3, v1

    const/4 v4, 0x0

    :goto_25
    if-ge v4, v3, :cond_31

    aget v5, v1, v4

    const/4 v6, 0x7

    if-ne v5, v6, :cond_2e

    const/4 v1, 0x1

    goto :goto_32

    :cond_2e
    add-int/lit8 v4, v4, 0x1

    goto :goto_25

    :cond_31
    const/4 v1, 0x0

    :goto_32
    iput-boolean v1, p0, Landroidx/camera/camera2/internal/s1;->d:Z

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->REQUEST_AVAILABLE_CAPABILITIES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {p1, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [I

    if-eqz p1, :cond_4c

    array-length v1, p1

    const/4 v3, 0x0

    :goto_40
    if-ge v3, v1, :cond_4c

    aget v4, p1, v3

    const/4 v5, 0x4

    if-ne v4, v5, :cond_49

    const/4 v0, 0x1

    goto :goto_4c

    :cond_49
    add-int/lit8 v3, v3, 0x1

    goto :goto_40

    :cond_4c
    :goto_4c
    iput-boolean v0, p0, Landroidx/camera/camera2/internal/s1;->e:Z

    return-void
.end method


# virtual methods
.method public final a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V
    .registers 8

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/s1;->c:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-boolean v0, p0, Landroidx/camera/camera2/internal/s1;->d:Z

    if-nez v0, :cond_e

    iget-boolean v1, p0, Landroidx/camera/camera2/internal/s1;->e:Z

    if-nez v1, :cond_e

    return-void

    :cond_e
    iget-object v1, p0, Landroidx/camera/camera2/internal/s1;->a:Ljava/util/LinkedList;

    :goto_10
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_20

    invoke-virtual {v1}, Ljava/util/LinkedList;->remove()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/r0;

    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    goto :goto_10

    :cond_20
    iget-object v1, p0, Landroidx/camera/camera2/internal/s1;->b:Ljava/util/LinkedList;

    invoke-virtual {v1}, Ljava/util/LinkedList;->clear()V

    iget-object v1, p0, Landroidx/camera/camera2/internal/s1;->g:Landroidx/camera/core/impl/c0;

    if-eqz v1, :cond_40

    iget-object v2, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    if-eqz v2, :cond_3d

    invoke-virtual {v1}, Landroidx/camera/core/impl/K;->i()Lcom/google/common/util/concurrent/o;

    move-result-object v3

    new-instance v4, Landroidx/camera/camera2/internal/r1;

    invoke-direct {v4, v2}, Landroidx/camera/camera2/internal/r1;-><init>(Landroidx/camera/core/X0;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v2

    invoke-interface {v3, v4, v2}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_3d
    invoke-virtual {v1}, Landroidx/camera/core/impl/K;->c()V

    :cond_40
    iget-object v1, p0, Landroidx/camera/camera2/internal/s1;->h:Landroid/media/ImageWriter;

    if-eqz v1, :cond_4a

    invoke-static {v1}, Landroidx/camera/camera2/internal/p1;->b(Landroid/media/ImageWriter;)V

    const/4 v1, 0x0

    iput-object v1, p0, Landroidx/camera/camera2/internal/s1;->h:Landroid/media/ImageWriter;

    :cond_4a
    if-eqz v0, :cond_4f

    const/16 v0, 0x23

    goto :goto_51

    :cond_4f
    const/16 v0, 0x22

    :goto_51
    new-instance v1, Landroidx/camera/core/X0;

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result v2

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result p1

    const/4 v3, 0x2

    invoke-static {v2, p1, v0, v3}, Landroidx/camera/core/t0;->a(IIII)Landroidx/camera/core/impl/b0;

    move-result-object p1

    invoke-direct {v1, p1}, Landroidx/camera/core/X0;-><init>(Landroidx/camera/core/impl/b0;)V

    iput-object v1, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    new-instance p1, Landroidx/camera/camera2/internal/q1;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/q1;-><init>(Landroidx/camera/camera2/internal/s1;)V

    invoke-static {}, Lu/a;->c()Ljava/util/concurrent/Executor;

    move-result-object v2

    invoke-virtual {v1, p1, v2}, Landroidx/camera/core/X0;->g(Landroidx/camera/core/impl/b0$a;Ljava/util/concurrent/Executor;)V

    new-instance p1, Landroidx/camera/core/impl/c0;

    iget-object v1, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    invoke-virtual {v1}, Landroidx/camera/core/X0;->a()Landroid/view/Surface;

    move-result-object v1

    new-instance v2, Landroid/util/Size;

    iget-object v3, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    invoke-virtual {v3}, Landroidx/camera/core/X0;->getWidth()I

    move-result v3

    iget-object v4, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    invoke-virtual {v4}, Landroidx/camera/core/X0;->getHeight()I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/util/Size;-><init>(II)V

    invoke-direct {p1, v1, v2, v0}, Landroidx/camera/core/impl/c0;-><init>(Landroid/view/Surface;Landroid/util/Size;I)V

    iput-object p1, p0, Landroidx/camera/camera2/internal/s1;->g:Landroidx/camera/core/impl/c0;

    iget-object v0, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    invoke-virtual {p1}, Landroidx/camera/core/impl/K;->i()Lcom/google/common/util/concurrent/o;

    move-result-object p1

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Landroidx/camera/camera2/internal/r1;

    invoke-direct {v1, v0}, Landroidx/camera/camera2/internal/r1;-><init>(Landroidx/camera/core/X0;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    invoke-interface {p1, v1, v0}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s1;->g:Landroidx/camera/core/impl/c0;

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->i(Landroidx/camera/core/impl/K;)V

    new-instance p1, Landroidx/camera/camera2/internal/s1$a;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/s1$a;-><init>(Landroidx/camera/camera2/internal/s1;)V

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->b(Landroidx/camera/core/impl/g;)V

    new-instance p1, Landroidx/camera/camera2/internal/s1$b;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/s1$b;-><init>(Landroidx/camera/camera2/internal/s1;)V

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->h(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;)V

    invoke-static {}, Landroidx/camera/camera2/internal/o1;->a()V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    invoke-virtual {p1}, Landroidx/camera/core/X0;->getWidth()I

    move-result p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    invoke-virtual {v0}, Landroidx/camera/core/X0;->getHeight()I

    move-result v0

    iget-object v1, p0, Landroidx/camera/camera2/internal/s1;->f:Landroidx/camera/core/X0;

    invoke-virtual {v1}, Landroidx/camera/core/X0;->d()I

    move-result v1

    invoke-static {p1, v0, v1}, Landroidx/camera/camera2/internal/n1;->a(III)Landroid/hardware/camera2/params/InputConfiguration;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->p(Landroid/hardware/camera2/params/InputConfiguration;)V

    return-void
.end method

.method public final b()Landroidx/camera/core/r0;
    .registers 2

    :try_start_0
    iget-object v0, p0, Landroidx/camera/camera2/internal/s1;->a:Ljava/util/LinkedList;

    invoke-virtual {v0}, Ljava/util/LinkedList;->remove()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/r0;
    :try_end_8
    .catch Ljava/util/NoSuchElementException; {:try_start_0 .. :try_end_8} :catch_9

    goto :goto_a

    :catch_9
    const/4 v0, 0x0

    :goto_a
    return-object v0
.end method

.method public final c(Landroidx/camera/core/r0;)Z
    .registers 4

    invoke-interface {p1}, Landroidx/camera/core/r0;->c1()Landroid/media/Image;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_15

    iget-object v0, p0, Landroidx/camera/camera2/internal/s1;->h:Landroid/media/ImageWriter;

    if-eqz v0, :cond_15

    if-eqz p1, :cond_15

    invoke-static {v0, p1}, Lx/a;->e(Landroid/media/ImageWriter;Landroid/media/Image;)V

    const/4 p1, 0x1

    return p1

    :cond_15
    const/4 p1, 0x0

    return p1
.end method

.method public final d(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/s1;->c:Z

    return-void
.end method
