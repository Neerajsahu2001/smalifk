.class public final synthetic Landroidx/camera/camera2/internal/q;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/impl/g;

.field public final synthetic b:Landroidx/camera/core/impl/o;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/impl/g;Landroidx/camera/core/impl/o;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/q;->a:Landroidx/camera/core/impl/g;

    iput-object p2, p0, Landroidx/camera/camera2/internal/q;->b:Landroidx/camera/core/impl/o;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/q;->a:Landroidx/camera/core/impl/g;

    iget-object v1, p0, Landroidx/camera/camera2/internal/q;->b:Landroidx/camera/core/impl/o;

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/g;->b(Landroidx/camera/core/impl/o;)V

    return-void
.end method
