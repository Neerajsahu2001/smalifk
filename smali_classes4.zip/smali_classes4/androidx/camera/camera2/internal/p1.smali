.class public final synthetic Landroidx/camera/camera2/internal/p1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static bridge synthetic a(Landroid/media/ImageWriter;)Landroid/media/Image;
    .registers 1

    invoke-virtual {p0}, Landroid/media/ImageWriter;->dequeueInputImage()Landroid/media/Image;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic b(Landroid/media/ImageWriter;)V
    .registers 1

    invoke-virtual {p0}, Landroid/media/ImageWriter;->close()V

    return-void
.end method
