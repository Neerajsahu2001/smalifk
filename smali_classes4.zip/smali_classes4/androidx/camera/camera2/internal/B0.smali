.class final Landroidx/camera/camera2/internal/b0;
.super Ljava/lang/Object;
.source "Camera2CaptureRequestBuilder.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/b0$a;
    }
.end annotation


# direct methods
.method private static a(Landroid/hardware/camera2/CaptureRequest$Builder;Landroidx/camera/core/impl/H;)V
    .registers 6

    invoke-static {p1}, Lt/j$a;->e(Landroidx/camera/core/impl/H;)Lt/j$a;

    move-result-object p1

    invoke-virtual {p1}, Lt/j$a;->c()Lt/j;

    move-result-object p1

    invoke-virtual {p1}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    invoke-interface {v0}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_14
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_46

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1}, Landroidx/camera/core/impl/H$a;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/hardware/camera2/CaptureRequest$Key;

    :try_start_26
    invoke-virtual {p1}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v3

    invoke-interface {v3, v1}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p0, v2, v1}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V
    :try_end_31
    .catch Ljava/lang/IllegalArgumentException; {:try_start_26 .. :try_end_31} :catch_32

    goto :goto_14

    :catch_32
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "CaptureRequest.Key is not supported: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "CaptureRequestBuilder"

    invoke-static {v2, v1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_14

    :cond_46
    return-void
.end method

.method public static b(Landroidx/camera/core/impl/D;Landroid/hardware/camera2/CameraDevice;Ljava/util/HashMap;)Landroid/hardware/camera2/CaptureRequest;
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/hardware/camera2/CameraAccessException;
        }
    .end annotation

    const/4 v0, 0x0

    if-nez p1, :cond_4

    return-object v0

    :cond_4
    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->d()Ljava/util/List;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_11
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_31

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/camera/core/impl/K;

    invoke-virtual {p2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/Surface;

    if-eqz v3, :cond_29

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_11

    :cond_29
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "DeferrableSurface not in configuredSurfaceMap"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_31
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_38

    return-object v0

    :cond_38
    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->b()Landroidx/camera/core/impl/o;

    move-result-object p2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_5e

    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->f()I

    move-result v0

    const/4 v1, 0x5

    if-ne v0, v1, :cond_5e

    if-eqz p2, :cond_5e

    invoke-interface {p2}, Landroidx/camera/core/impl/o;->b()Landroid/hardware/camera2/CaptureResult;

    move-result-object v0

    instance-of v0, v0, Landroid/hardware/camera2/TotalCaptureResult;

    if-eqz v0, :cond_5e

    invoke-interface {p2}, Landroidx/camera/core/impl/o;->b()Landroid/hardware/camera2/CaptureResult;

    move-result-object p2

    check-cast p2, Landroid/hardware/camera2/TotalCaptureResult;

    invoke-static {p1, p2}, Landroidx/camera/camera2/internal/b0$a;->a(Landroid/hardware/camera2/CameraDevice;Landroid/hardware/camera2/TotalCaptureResult;)Landroid/hardware/camera2/CaptureRequest$Builder;

    move-result-object p1

    goto :goto_66

    :cond_5e
    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->f()I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/hardware/camera2/CameraDevice;->createCaptureRequest(I)Landroid/hardware/camera2/CaptureRequest$Builder;

    move-result-object p1

    :goto_66
    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object p2

    invoke-static {p1, p2}, Landroidx/camera/camera2/internal/b0;->a(Landroid/hardware/camera2/CaptureRequest$Builder;Landroidx/camera/core/impl/H;)V

    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object p2

    sget-object v0, Landroidx/camera/core/impl/D;->h:Landroidx/camera/core/impl/H$a;

    invoke-interface {p2, v0}, Landroidx/camera/core/impl/H;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result p2

    if-eqz p2, :cond_88

    sget-object p2, Landroid/hardware/camera2/CaptureRequest;->JPEG_ORIENTATION:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v1

    invoke-interface {v1, v0}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {p1, p2, v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    :cond_88
    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object p2

    sget-object v0, Landroidx/camera/core/impl/D;->i:Landroidx/camera/core/impl/H$a;

    invoke-interface {p2, v0}, Landroidx/camera/core/impl/H;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result p2

    if-eqz p2, :cond_ab

    sget-object p2, Landroid/hardware/camera2/CaptureRequest;->JPEG_QUALITY:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object v1

    invoke-interface {v1, v0}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->byteValue()B

    move-result v0

    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    :cond_ab
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_af
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_bf

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/Surface;

    invoke-virtual {p1, v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->addTarget(Landroid/view/Surface;)V

    goto :goto_af

    :cond_bf
    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->e()Landroidx/camera/core/impl/B0;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/hardware/camera2/CaptureRequest$Builder;->setTag(Ljava/lang/Object;)V

    invoke-virtual {p1}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object p0

    return-object p0
.end method

.method public static c(Landroidx/camera/core/impl/D;Landroid/hardware/camera2/CameraDevice;)Landroid/hardware/camera2/CaptureRequest;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/hardware/camera2/CameraAccessException;
        }
    .end annotation

    if-nez p1, :cond_4

    const/4 p0, 0x0

    return-object p0

    :cond_4
    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->f()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/hardware/camera2/CameraDevice;->createCaptureRequest(I)Landroid/hardware/camera2/CaptureRequest$Builder;

    move-result-object p1

    invoke-virtual {p0}, Landroidx/camera/core/impl/D;->c()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-static {p1, p0}, Landroidx/camera/camera2/internal/b0;->a(Landroid/hardware/camera2/CaptureRequest$Builder;Landroidx/camera/core/impl/H;)V

    invoke-virtual {p1}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object p0

    return-object p0
.end method
