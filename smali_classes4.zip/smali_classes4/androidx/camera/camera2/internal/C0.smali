.class public final Landroidx/camera/camera2/internal/c0;
.super Ljava/lang/Object;
.source "Camera2DeviceSurfaceManager.java"

# interfaces
.implements Landroidx/camera/core/impl/u;


# instance fields
.field private final a:Ljava/util/HashMap;

.field private final b:Landroidx/camera/camera2/internal/e;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/Object;Ljava/util/Set;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/Object;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/u;
        }
    .end annotation

    new-instance v0, Landroidx/camera/camera2/internal/c0$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Landroidx/camera/camera2/internal/c0;->a:Ljava/util/HashMap;

    iput-object v0, p0, Landroidx/camera/camera2/internal/c0;->b:Landroidx/camera/camera2/internal/e;

    instance-of v0, p2, Lp/S;

    if-eqz v0, :cond_18

    check-cast p2, Lp/S;

    goto :goto_20

    :cond_18
    invoke-static {}, Landroidx/camera/core/impl/utils/k;->a()Landroid/os/Handler;

    move-result-object p2

    invoke-static {p1, p2}, Lp/S;->a(Landroid/content/Context;Landroid/os/Handler;)Lp/S;

    move-result-object p2

    :goto_20
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_27
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_40

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    new-instance v1, Landroidx/camera/camera2/internal/T0;

    iget-object v2, p0, Landroidx/camera/camera2/internal/c0;->b:Landroidx/camera/camera2/internal/e;

    invoke-direct {v1, p1, v0, p2, v2}, Landroidx/camera/camera2/internal/T0;-><init>(Landroid/content/Context;Ljava/lang/String;Lp/S;Landroidx/camera/camera2/internal/e;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/c0;->a:Ljava/util/HashMap;

    invoke-virtual {v2, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_27

    :cond_40
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;)Ljava/util/HashMap;
    .registers 6

    invoke-virtual {p3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    const-string v1, "No new use cases to be bound."

    invoke-static {v0, v1}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/c0;->a:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/camera2/internal/T0;

    if-eqz v0, :cond_1a

    invoke-virtual {v0, p2, p3}, Landroidx/camera/camera2/internal/T0;->e(Ljava/util/ArrayList;Ljava/util/ArrayList;)Ljava/util/HashMap;

    move-result-object p1

    return-object p1

    :cond_1a
    new-instance p2, Ljava/lang/IllegalArgumentException;

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "No such camera id in supported combination list: "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public final b(Ljava/lang/String;ILandroid/util/Size;)Landroidx/camera/core/impl/z0;
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/c0;->a:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/camera/camera2/internal/T0;

    if-eqz p1, :cond_f

    invoke-virtual {p1, p2, p3}, Landroidx/camera/camera2/internal/T0;->i(ILandroid/util/Size;)Landroidx/camera/core/impl/z0;

    move-result-object p1

    goto :goto_10

    :cond_f
    const/4 p1, 0x0

    :goto_10
    return-object p1
.end method
