.class public final synthetic Landroidx/camera/camera2/internal/c1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ls/r$b;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/d1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/d1;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/c1;->a:Landroidx/camera/camera2/internal/d1;

    return-void
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/c1;->a:Landroidx/camera/camera2/internal/d1;

    invoke-static {v0, p1, p2, p3}, Landroidx/camera/camera2/internal/d1;->x(Landroidx/camera/camera2/internal/d1;Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method
