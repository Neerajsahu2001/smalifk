.class public final synthetic Landroidx/camera/camera2/internal/g1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/concurrent/futures/b$c;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/j1;

.field public final synthetic b:Z


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/j1;Z)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/g1;->a:Landroidx/camera/camera2/internal/j1;

    iput-boolean p2, p0, Landroidx/camera/camera2/internal/g1;->b:Z

    return-void
.end method


# virtual methods
.method public final a(Landroidx/concurrent/futures/b$a;)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/g1;->a:Landroidx/camera/camera2/internal/j1;

    iget-boolean v1, p0, Landroidx/camera/camera2/internal/g1;->b:Z

    invoke-static {v0, p1, v1}, Landroidx/camera/camera2/internal/j1;->a(Landroidx/camera/camera2/internal/j1;Landroidx/concurrent/futures/b$a;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method
