.class final Landroidx/camera/camera2/internal/f1;
.super Landroidx/camera/camera2/internal/U0$a;
.source "SynchronizedCaptureSessionStateCallbacks.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/f1$a;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/camera/camera2/internal/U0$a;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Landroidx/camera/camera2/internal/U0$a;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    return-void
.end method


# virtual methods
.method public final k(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/U0$a;->k(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final l(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/U0$a;->l(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final m(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/U0$a;->m(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final n(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/U0$a;->n(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final o(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/U0$a;->o(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final p(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/U0$a;->p(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method final q(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/U0$a;->q(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final r(Landroidx/camera/camera2/internal/U0;Landroid/view/Surface;)V
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0$a;

    invoke-virtual {v1, p1, p2}, Landroidx/camera/camera2/internal/U0$a;->r(Landroidx/camera/camera2/internal/U0;Landroid/view/Surface;)V

    goto :goto_6

    :cond_16
    return-void
.end method
