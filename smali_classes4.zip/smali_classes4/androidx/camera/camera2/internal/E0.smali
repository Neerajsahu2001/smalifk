.class final Landroidx/camera/camera2/internal/e0;
.super Ljava/lang/Object;
.source "Camera2SessionOptionUnpacker.java"

# interfaces
.implements Landroidx/camera/core/impl/u0$d;


# static fields
.field static final a:Landroidx/camera/camera2/internal/e0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/camera/camera2/internal/e0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/camera/camera2/internal/e0;->a:Landroidx/camera/camera2/internal/e0;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/E0;Landroidx/camera/core/impl/u0$b;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/E0<",
            "*>;",
            "Landroidx/camera/core/impl/u0$b;",
            ")V"
        }
    .end annotation

    invoke-interface {p1}, Landroidx/camera/core/impl/E0;->u()Landroidx/camera/core/impl/u0;

    move-result-object v0

    invoke-static {}, Landroidx/camera/core/impl/o0;->C()Landroidx/camera/core/impl/o0;

    move-result-object v1

    invoke-static {}, Landroidx/camera/core/impl/u0;->a()Landroidx/camera/core/impl/u0;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/camera/core/impl/u0;->k()I

    move-result v2

    if-eqz v0, :cond_53

    invoke-virtual {v0}, Landroidx/camera/core/impl/u0;->k()I

    move-result v2

    invoke-virtual {v0}, Landroidx/camera/core/impl/u0;->b()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/hardware/camera2/CameraDevice$StateCallback;

    invoke-virtual {p2, v3}, Landroidx/camera/core/impl/u0$b;->c(Landroid/hardware/camera2/CameraDevice$StateCallback;)V

    goto :goto_1e

    :cond_2e
    invoke-virtual {v0}, Landroidx/camera/core/impl/u0;->h()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_36
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_46

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {p2, v3}, Landroidx/camera/core/impl/u0$b;->h(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;)V

    goto :goto_36

    :cond_46
    invoke-virtual {v0}, Landroidx/camera/core/impl/u0;->f()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-virtual {p2, v1}, Landroidx/camera/core/impl/u0$b;->a(Ljava/util/List;)V

    invoke-virtual {v0}, Landroidx/camera/core/impl/u0;->d()Landroidx/camera/core/impl/H;

    move-result-object v1

    :cond_53
    invoke-virtual {p2, v1}, Landroidx/camera/core/impl/u0$b;->o(Landroidx/camera/core/impl/H;)V

    new-instance v0, Lo/a;

    invoke-direct {v0, p1}, Lt/j;-><init>(Landroidx/camera/core/impl/H;)V

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p1

    sget-object v1, Lo/a;->y:Landroidx/camera/core/impl/H$a;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p1, v1, v2}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->q(I)V

    new-instance p1, Landroidx/camera/camera2/internal/j0;

    invoke-direct {p1}, Landroid/hardware/camera2/CameraDevice$StateCallback;-><init>()V

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v1

    sget-object v2, Lo/a;->z:Landroidx/camera/core/impl/H$a;

    invoke-interface {v1, v2, p1}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/camera2/CameraDevice$StateCallback;

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->c(Landroid/hardware/camera2/CameraDevice$StateCallback;)V

    new-instance p1, Landroidx/camera/camera2/internal/h0;

    invoke-direct {p1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;-><init>()V

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v1

    sget-object v2, Lo/a;->A:Landroidx/camera/core/impl/H$a;

    invoke-interface {v1, v2, p1}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->h(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;)V

    new-instance p1, Landroidx/camera/camera2/internal/L$b;

    invoke-direct {p1}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;-><init>()V

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v1

    sget-object v2, Lo/a;->B:Landroidx/camera/core/impl/H$a;

    invoke-interface {v1, v2, p1}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    invoke-static {p1}, Landroidx/camera/camera2/internal/n0;->d(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)Landroidx/camera/camera2/internal/n0;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->b(Landroidx/camera/core/impl/g;)V

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object p1

    sget-object v1, Lo/a;->C:Landroidx/camera/core/impl/H$a;

    invoke-static {}, Lo/c;->e()Lo/c;

    move-result-object v2

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v3

    invoke-interface {v3, v1, v2}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/c;

    invoke-virtual {p1, v1, v2}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    sget-object v1, Lo/a;->E:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v2

    const/4 v3, 0x0

    invoke-interface {v2, v1, v3}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v1, v2}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->e(Landroidx/camera/core/impl/H;)V

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p1

    invoke-static {p1}, Lt/j$a;->e(Landroidx/camera/core/impl/H;)Lt/j$a;

    move-result-object p1

    invoke-virtual {p1}, Lt/j$a;->c()Lt/j;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/u0$b;->e(Landroidx/camera/core/impl/H;)V

    return-void
.end method
