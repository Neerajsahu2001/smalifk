.class final Landroidx/camera/camera2/internal/s0$b;
.super Ljava/lang/Object;
.source "CaptureSession.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/camera2/internal/s0;->f(Landroidx/camera/core/impl/u0;Landroid/hardware/camera2/CameraDevice;Landroidx/camera/camera2/internal/e1;)Lcom/google/common/util/concurrent/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/s0;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/s0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/s0$b;->a:Landroidx/camera/camera2/internal/s0;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 6

    const-string v0, "Opening session with fail "

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$b;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_7
    iget-object v2, p0, Landroidx/camera/camera2/internal/s0$b;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/s0;->e:Landroidx/camera/camera2/internal/e1;

    invoke-virtual {v2}, Landroidx/camera/camera2/internal/e1;->e()Z

    sget-object v2, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0$b;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v3, v3, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v2, v2, v3

    const/4 v3, 0x4

    if-eq v2, v3, :cond_24

    const/4 v3, 0x6

    if-eq v2, v3, :cond_24

    const/4 v3, 0x7

    if-eq v2, v3, :cond_24

    goto :goto_45

    :cond_24
    instance-of v2, p1, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_45

    const-string v2, "CaptureSession"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0$b;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v0, v0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, p1}, Landroidx/camera/core/A0;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0$b;->a:Landroidx/camera/camera2/internal/s0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/s0;->i()V

    goto :goto_45

    :catchall_43
    move-exception p1

    goto :goto_47

    :cond_45
    :goto_45
    monitor-exit v1

    return-void

    :goto_47
    monitor-exit v1
    :try_end_48
    .catchall {:try_start_7 .. :try_end_48} :catchall_43

    throw p1
.end method

.method public final bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/Void;

    return-void
.end method
