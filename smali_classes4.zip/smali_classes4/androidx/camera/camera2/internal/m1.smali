.class interface abstract Landroidx/camera/camera2/internal/m1;
.super Ljava/lang/Object;
.source "ZslControl.java"


# virtual methods
.method public abstract a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V
.end method

.method public abstract b()Landroidx/camera/core/r0;
.end method

.method public abstract c(Landroidx/camera/core/r0;)Z
.end method

.method public abstract d(Z)V
.end method
