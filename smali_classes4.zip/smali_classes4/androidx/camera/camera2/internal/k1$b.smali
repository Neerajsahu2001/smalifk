.class interface abstract Landroidx/camera/camera2/internal/k1$b;
.super Ljava/lang/Object;
.source "ZoomControl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/k1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/hardware/camera2/TotalCaptureResult;)V
.end method

.method public abstract b()F
.end method

.method public abstract c()V
.end method

.method public abstract d()F
.end method

.method public abstract e()Landroid/graphics/Rect;
.end method

.method public abstract f(Lo/a$a;)V
.end method
