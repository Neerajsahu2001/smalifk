.class public final synthetic Landroidx/camera/camera2/internal/q1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/impl/b0$a;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/s1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/s1;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/q1;->a:Landroidx/camera/camera2/internal/s1;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/b0;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/q1;->a:Landroidx/camera/camera2/internal/s1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Landroidx/camera/core/impl/b0;->c()Landroidx/camera/core/r0;

    move-result-object p1

    if-eqz p1, :cond_10

    iget-object v0, v0, Landroidx/camera/camera2/internal/s1;->a:Ljava/util/LinkedList;

    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    :cond_10
    return-void
.end method
