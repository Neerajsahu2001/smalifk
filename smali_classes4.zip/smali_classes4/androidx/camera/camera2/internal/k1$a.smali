.class final Landroidx/camera/camera2/internal/k1$a;
.super Ljava/lang/Object;
.source "ZoomControl.java"

# interfaces
.implements Landroidx/camera/camera2/internal/t$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/k1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/k1;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/k1;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/k1$a;->a:Landroidx/camera/camera2/internal/k1;

    return-void
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/TotalCaptureResult;)Z
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/k1$a;->a:Landroidx/camera/camera2/internal/k1;

    iget-object v0, v0, Landroidx/camera/camera2/internal/k1;->e:Landroidx/camera/camera2/internal/k1$b;

    invoke-interface {v0, p1}, Landroidx/camera/camera2/internal/k1$b;->a(Landroid/hardware/camera2/TotalCaptureResult;)V

    const/4 p1, 0x0

    return p1
.end method
