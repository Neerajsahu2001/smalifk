.class public final synthetic Landroidx/camera/camera2/internal/j;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lv/a;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/t;

.field public final synthetic b:Ljava/util/List;

.field public final synthetic c:I

.field public final synthetic d:I

.field public final synthetic e:I


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/t;Ljava/util/ArrayList;III)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/j;->a:Landroidx/camera/camera2/internal/t;

    iput-object p2, p0, Landroidx/camera/camera2/internal/j;->b:Ljava/util/List;

    iput p3, p0, Landroidx/camera/camera2/internal/j;->c:I

    iput p4, p0, Landroidx/camera/camera2/internal/j;->d:I

    iput p5, p0, Landroidx/camera/camera2/internal/j;->e:I

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;
    .registers 6

    check-cast p1, Ljava/lang/Void;

    iget p1, p0, Landroidx/camera/camera2/internal/j;->c:I

    iget v0, p0, Landroidx/camera/camera2/internal/j;->d:I

    iget-object v1, p0, Landroidx/camera/camera2/internal/j;->a:Landroidx/camera/camera2/internal/t;

    iget-object v2, p0, Landroidx/camera/camera2/internal/j;->b:Ljava/util/List;

    iget v3, p0, Landroidx/camera/camera2/internal/j;->e:I

    invoke-static {v1, v2, p1, v0, v3}, Landroidx/camera/camera2/internal/t;->j(Landroidx/camera/camera2/internal/t;Ljava/util/List;III)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method
