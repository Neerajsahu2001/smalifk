.class final Landroidx/camera/camera2/internal/P$f;
.super Ljava/lang/Object;
.source "Camera2CapturePipeline.java"

# interfaces
.implements Landroidx/camera/camera2/internal/P$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/P;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "f"
.end annotation


# instance fields
.field private final a:Landroidx/camera/camera2/internal/t;

.field private final b:I

.field private c:Z


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/t;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/camera2/internal/P$f;->c:Z

    iput-object p1, p0, Landroidx/camera/camera2/internal/P$f;->a:Landroidx/camera/camera2/internal/t;

    iput p2, p0, Landroidx/camera/camera2/internal/P$f;->b:I

    return-void
.end method

.method public static synthetic d(Landroidx/camera/camera2/internal/P$f;Landroidx/concurrent/futures/b$a;)V
    .registers 3

    iget-object p0, p0, Landroidx/camera/camera2/internal/P$f;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/t;->z()Landroidx/camera/camera2/internal/j1;

    move-result-object p0

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Landroidx/camera/camera2/internal/j1;->c(Landroidx/concurrent/futures/b$a;Z)V

    return-void
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/TotalCaptureResult;)Lcom/google/common/util/concurrent/o;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/hardware/camera2/TotalCaptureResult;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    iget v0, p0, Landroidx/camera/camera2/internal/P$f;->b:I

    invoke-static {v0, p1}, Landroidx/camera/camera2/internal/P;->a(ILandroid/hardware/camera2/TotalCaptureResult;)Z

    move-result p1

    if-eqz p1, :cond_40

    iget-object p1, p0, Landroidx/camera/camera2/internal/P$f;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/t;->F()Z

    move-result p1

    const-string v0, "Camera2CapturePipeline"

    if-eqz p1, :cond_18

    const-string p1, "Torch already on, not turn on"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_40

    :cond_18
    const-string p1, "Turn on torch"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/P$f;->c:Z

    new-instance p1, Landroidx/camera/camera2/internal/a0;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/a0;-><init>(Landroidx/camera/camera2/internal/P$f;)V

    invoke-static {p1}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    invoke-static {p1}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object p1

    new-instance v0, Landroidx/camera/camera2/internal/O;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v0, v1}, Lv/f;->m(Lcom/google/common/util/concurrent/o;Lm/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    check-cast p1, Lv/d;

    return-object p1

    :cond_40
    :goto_40
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method public final b()Z
    .registers 2

    iget v0, p0, Landroidx/camera/camera2/internal/P$f;->b:I

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public final c()V
    .registers 4

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/P$f;->c:Z

    if-eqz v0, :cond_16

    iget-object v0, p0, Landroidx/camera/camera2/internal/P$f;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/t;->z()Landroidx/camera/camera2/internal/j1;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroidx/camera/camera2/internal/j1;->c(Landroidx/concurrent/futures/b$a;Z)V

    const-string v0, "Camera2CapturePipeline"

    const-string v1, "Turn off torch"

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_16
    return-void
.end method
