.class final Landroidx/camera/camera2/internal/K$a;
.super Landroidx/lifecycle/H;
.source "Camera2CameraInfoImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/K;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Landroidx/lifecycle/H<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private b:Landroidx/lifecycle/LiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/LiveData<",
            "TT;>;"
        }
    .end annotation
.end field

.field private c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    invoke-direct {p0}, Landroidx/lifecycle/H;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/K$a;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method final a(Landroidx/lifecycle/I;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/K$a;->b:Landroidx/lifecycle/LiveData;

    if-eqz v0, :cond_7

    invoke-super {p0, v0}, Landroidx/lifecycle/H;->removeSource(Landroidx/lifecycle/LiveData;)V

    :cond_7
    iput-object p1, p0, Landroidx/camera/camera2/internal/K$a;->b:Landroidx/lifecycle/LiveData;

    new-instance v0, Landroidx/camera/camera2/internal/J;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/J;-><init>(Landroidx/camera/camera2/internal/K$a;)V

    invoke-super {p0, p1, v0}, Landroidx/lifecycle/H;->addSource(Landroidx/lifecycle/LiveData;Landroidx/lifecycle/J;)V

    return-void
.end method

.method public final addSource(Landroidx/lifecycle/LiveData;Landroidx/lifecycle/J;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S:",
            "Ljava/lang/Object;",
            ">(",
            "Landroidx/lifecycle/LiveData<",
            "TS;>;",
            "Landroidx/lifecycle/J<",
            "-TS;>;)V"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final getValue()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/K$a;->b:Landroidx/lifecycle/LiveData;

    if-nez v0, :cond_7

    iget-object v0, p0, Landroidx/camera/camera2/internal/K$a;->c:Ljava/lang/Object;

    goto :goto_b

    :cond_7
    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    :goto_b
    return-object v0
.end method
