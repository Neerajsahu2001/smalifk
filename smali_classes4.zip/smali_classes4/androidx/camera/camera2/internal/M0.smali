.class final Landroidx/camera/camera2/internal/m0;
.super Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;
.source "CaptureCallbackAdapter.java"


# instance fields
.field private final a:Landroidx/camera/core/impl/g;


# direct methods
.method constructor <init>(Landroidx/camera/core/impl/g;)V
    .registers 3

    invoke-direct {p0}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;-><init>()V

    if-eqz p1, :cond_8

    iput-object p1, p0, Landroidx/camera/camera2/internal/m0;->a:Landroidx/camera/core/impl/g;

    return-void

    :cond_8
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "cameraCaptureCallback is null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final onCaptureCompleted(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/TotalCaptureResult;)V
    .registers 5

    invoke-super {p0, p1, p2, p3}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureCompleted(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/TotalCaptureResult;)V

    invoke-virtual {p2}, Landroid/hardware/camera2/CaptureRequest;->getTag()Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_13

    instance-of p2, p1, Landroidx/camera/core/impl/B0;

    const-string v0, "The tagBundle object from the CaptureResult is not a TagBundle object."

    invoke-static {p2, v0}, Landroidx/core/util/g;->c(ZLjava/lang/String;)V

    check-cast p1, Landroidx/camera/core/impl/B0;

    goto :goto_17

    :cond_13
    invoke-static {}, Landroidx/camera/core/impl/B0;->a()Landroidx/camera/core/impl/B0;

    move-result-object p1

    :goto_17
    new-instance p2, Landroidx/camera/camera2/internal/g;

    invoke-direct {p2, p1, p3}, Landroidx/camera/camera2/internal/g;-><init>(Landroidx/camera/core/impl/B0;Landroid/hardware/camera2/CaptureResult;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/m0;->a:Landroidx/camera/core/impl/g;

    invoke-virtual {p1, p2}, Landroidx/camera/core/impl/g;->b(Landroidx/camera/core/impl/o;)V

    return-void
.end method

.method public final onCaptureFailed(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CaptureFailure;)V
    .registers 4

    invoke-super {p0, p1, p2, p3}, Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;->onCaptureFailed(Landroid/hardware/camera2/CameraCaptureSession;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CaptureFailure;)V

    new-instance p1, Landroidx/camera/core/impl/i;

    sget-object p2, Landroidx/camera/core/impl/i$a;->ERROR:Landroidx/camera/core/impl/i$a;

    invoke-direct {p1, p2}, Landroidx/camera/core/impl/i;-><init>(Landroidx/camera/core/impl/i$a;)V

    iget-object p2, p0, Landroidx/camera/camera2/internal/m0;->a:Landroidx/camera/core/impl/g;

    invoke-virtual {p2, p1}, Landroidx/camera/core/impl/g;->c(Landroidx/camera/core/impl/i;)V

    return-void
.end method
