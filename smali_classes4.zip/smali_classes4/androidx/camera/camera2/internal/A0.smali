.class public final synthetic Landroidx/camera/camera2/internal/a0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/concurrent/futures/b$c;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/P$f;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/P$f;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/a0;->a:Landroidx/camera/camera2/internal/P$f;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/concurrent/futures/b$a;)Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/a0;->a:Landroidx/camera/camera2/internal/P$f;

    invoke-static {v0, p1}, Landroidx/camera/camera2/internal/P$f;->d(Landroidx/camera/camera2/internal/P$f;Landroidx/concurrent/futures/b$a;)V

    const-string p1, "TorchOn"

    return-object p1
.end method
