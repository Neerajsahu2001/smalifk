.class final enum Landroidx/camera/camera2/internal/H$e;
.super Ljava/lang/Enum;
.source "Camera2CameraImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/H;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/camera2/internal/H$e;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/camera2/internal/H$e;

.field public static final enum CLOSING:Landroidx/camera/camera2/internal/H$e;

.field public static final enum INITIALIZED:Landroidx/camera/camera2/internal/H$e;

.field public static final enum OPENED:Landroidx/camera/camera2/internal/H$e;

.field public static final enum OPENING:Landroidx/camera/camera2/internal/H$e;

.field public static final enum PENDING_OPEN:Landroidx/camera/camera2/internal/H$e;

.field public static final enum RELEASED:Landroidx/camera/camera2/internal/H$e;

.field public static final enum RELEASING:Landroidx/camera/camera2/internal/H$e;

.field public static final enum REOPENING:Landroidx/camera/camera2/internal/H$e;


# direct methods
.method static constructor <clinit>()V
    .registers 16

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v8, Landroidx/camera/camera2/internal/H$e;

    const-string v9, "INITIALIZED"

    invoke-direct {v8, v9, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Landroidx/camera/camera2/internal/H$e;->INITIALIZED:Landroidx/camera/camera2/internal/H$e;

    new-instance v9, Landroidx/camera/camera2/internal/H$e;

    const-string v10, "PENDING_OPEN"

    invoke-direct {v9, v10, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Landroidx/camera/camera2/internal/H$e;->PENDING_OPEN:Landroidx/camera/camera2/internal/H$e;

    new-instance v10, Landroidx/camera/camera2/internal/H$e;

    const-string v11, "OPENING"

    invoke-direct {v10, v11, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Landroidx/camera/camera2/internal/H$e;->OPENING:Landroidx/camera/camera2/internal/H$e;

    new-instance v11, Landroidx/camera/camera2/internal/H$e;

    const-string v12, "OPENED"

    invoke-direct {v11, v12, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Landroidx/camera/camera2/internal/H$e;->OPENED:Landroidx/camera/camera2/internal/H$e;

    new-instance v12, Landroidx/camera/camera2/internal/H$e;

    const-string v13, "CLOSING"

    invoke-direct {v12, v13, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v12, Landroidx/camera/camera2/internal/H$e;->CLOSING:Landroidx/camera/camera2/internal/H$e;

    new-instance v13, Landroidx/camera/camera2/internal/H$e;

    const-string v14, "REOPENING"

    invoke-direct {v13, v14, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v13, Landroidx/camera/camera2/internal/H$e;->REOPENING:Landroidx/camera/camera2/internal/H$e;

    new-instance v14, Landroidx/camera/camera2/internal/H$e;

    const-string v15, "RELEASING"

    invoke-direct {v14, v15, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v14, Landroidx/camera/camera2/internal/H$e;->RELEASING:Landroidx/camera/camera2/internal/H$e;

    new-instance v15, Landroidx/camera/camera2/internal/H$e;

    const-string v1, "RELEASED"

    invoke-direct {v15, v1, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v15, Landroidx/camera/camera2/internal/H$e;->RELEASED:Landroidx/camera/camera2/internal/H$e;

    const/16 v1, 0x8

    new-array v1, v1, [Landroidx/camera/camera2/internal/H$e;

    aput-object v8, v1, v7

    aput-object v9, v1, v6

    aput-object v10, v1, v5

    aput-object v11, v1, v4

    aput-object v12, v1, v3

    aput-object v13, v1, v2

    const/4 v2, 0x6

    aput-object v14, v1, v2

    aput-object v15, v1, v0

    sput-object v1, Landroidx/camera/camera2/internal/H$e;->$VALUES:[Landroidx/camera/camera2/internal/H$e;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/camera2/internal/H$e;
    .registers 2

    const-class v0, Landroidx/camera/camera2/internal/H$e;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/camera2/internal/H$e;

    return-object p0
.end method

.method public static values()[Landroidx/camera/camera2/internal/H$e;
    .registers 1

    sget-object v0, Landroidx/camera/camera2/internal/H$e;->$VALUES:[Landroidx/camera/camera2/internal/H$e;

    invoke-virtual {v0}, [Landroidx/camera/camera2/internal/H$e;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/camera2/internal/H$e;

    return-object v0
.end method
