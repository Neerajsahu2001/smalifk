.class public final synthetic Landroidx/camera/camera2/internal/i1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/j1;

.field public final synthetic b:Landroidx/concurrent/futures/b$a;

.field public final synthetic c:Z


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/j1;Landroidx/concurrent/futures/b$a;Z)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/i1;->a:Landroidx/camera/camera2/internal/j1;

    iput-object p2, p0, Landroidx/camera/camera2/internal/i1;->b:Landroidx/concurrent/futures/b$a;

    iput-boolean p3, p0, Landroidx/camera/camera2/internal/i1;->c:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/i1;->a:Landroidx/camera/camera2/internal/j1;

    iget-object v1, p0, Landroidx/camera/camera2/internal/i1;->b:Landroidx/concurrent/futures/b$a;

    iget-boolean v2, p0, Landroidx/camera/camera2/internal/i1;->c:Z

    invoke-virtual {v0, v1, v2}, Landroidx/camera/camera2/internal/j1;->c(Landroidx/concurrent/futures/b$a;Z)V

    return-void
.end method
