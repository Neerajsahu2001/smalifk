.class final synthetic Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory$a;
.super Ljava/lang/Object;
.source "Camera2UseCaseConfigFactory.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic a:[I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    invoke-static {}, Landroidx/camera/core/impl/F0$b;->values()[Landroidx/camera/core/impl/F0$b;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory$a;->a:[I

    :try_start_9
    sget-object v1, Landroidx/camera/core/impl/F0$b;->IMAGE_CAPTURE:Landroidx/camera/core/impl/F0$b;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_12
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_12} :catch_12

    :catch_12
    :try_start_12
    sget-object v0, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory$a;->a:[I

    sget-object v1, Landroidx/camera/core/impl/F0$b;->PREVIEW:Landroidx/camera/core/impl/F0$b;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_1d} :catch_1d

    :catch_1d
    :try_start_1d
    sget-object v0, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory$a;->a:[I

    sget-object v1, Landroidx/camera/core/impl/F0$b;->IMAGE_ANALYSIS:Landroidx/camera/core/impl/F0$b;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_28
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1d .. :try_end_28} :catch_28

    :catch_28
    :try_start_28
    sget-object v0, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory$a;->a:[I

    sget-object v1, Landroidx/camera/core/impl/F0$b;->VIDEO_CAPTURE:Landroidx/camera/core/impl/F0$b;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_33
    .catch Ljava/lang/NoSuchFieldError; {:try_start_28 .. :try_end_33} :catch_33

    :catch_33
    return-void
.end method
