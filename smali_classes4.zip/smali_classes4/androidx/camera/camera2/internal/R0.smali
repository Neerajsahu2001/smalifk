.class public final synthetic Landroidx/camera/camera2/internal/r0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lv/a;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/s0;

.field public final synthetic b:Landroidx/camera/core/impl/u0;

.field public final synthetic c:Landroid/hardware/camera2/CameraDevice;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/s0;Landroidx/camera/core/impl/u0;Landroid/hardware/camera2/CameraDevice;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/r0;->a:Landroidx/camera/camera2/internal/s0;

    iput-object p2, p0, Landroidx/camera/camera2/internal/r0;->b:Landroidx/camera/core/impl/u0;

    iput-object p3, p0, Landroidx/camera/camera2/internal/r0;->c:Landroid/hardware/camera2/CameraDevice;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;
    .registers 5

    check-cast p1, Ljava/util/List;

    iget-object v0, p0, Landroidx/camera/camera2/internal/r0;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v1, p0, Landroidx/camera/camera2/internal/r0;->b:Landroidx/camera/core/impl/u0;

    iget-object v2, p0, Landroidx/camera/camera2/internal/r0;->c:Landroid/hardware/camera2/CameraDevice;

    invoke-static {v0, v1, v2, p1}, Landroidx/camera/camera2/internal/s0;->g(Landroidx/camera/camera2/internal/s0;Landroidx/camera/core/impl/u0;Landroid/hardware/camera2/CameraDevice;Ljava/util/List;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method
