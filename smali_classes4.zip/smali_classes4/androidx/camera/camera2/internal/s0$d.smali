.class final enum Landroidx/camera/camera2/internal/s0$d;
.super Ljava/lang/Enum;
.source "CaptureSession.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/s0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/camera2/internal/s0$d;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/camera2/internal/s0$d;

.field public static final enum CLOSED:Landroidx/camera/camera2/internal/s0$d;

.field public static final enum GET_SURFACE:Landroidx/camera/camera2/internal/s0$d;

.field public static final enum INITIALIZED:Landroidx/camera/camera2/internal/s0$d;

.field public static final enum OPENED:Landroidx/camera/camera2/internal/s0$d;

.field public static final enum OPENING:Landroidx/camera/camera2/internal/s0$d;

.field public static final enum RELEASED:Landroidx/camera/camera2/internal/s0$d;

.field public static final enum RELEASING:Landroidx/camera/camera2/internal/s0$d;

.field public static final enum UNINITIALIZED:Landroidx/camera/camera2/internal/s0$d;


# direct methods
.method static constructor <clinit>()V
    .registers 16

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v8, Landroidx/camera/camera2/internal/s0$d;

    const-string v9, "UNINITIALIZED"

    invoke-direct {v8, v9, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Landroidx/camera/camera2/internal/s0$d;->UNINITIALIZED:Landroidx/camera/camera2/internal/s0$d;

    new-instance v9, Landroidx/camera/camera2/internal/s0$d;

    const-string v10, "INITIALIZED"

    invoke-direct {v9, v10, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Landroidx/camera/camera2/internal/s0$d;->INITIALIZED:Landroidx/camera/camera2/internal/s0$d;

    new-instance v10, Landroidx/camera/camera2/internal/s0$d;

    const-string v11, "GET_SURFACE"

    invoke-direct {v10, v11, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Landroidx/camera/camera2/internal/s0$d;->GET_SURFACE:Landroidx/camera/camera2/internal/s0$d;

    new-instance v11, Landroidx/camera/camera2/internal/s0$d;

    const-string v12, "OPENING"

    invoke-direct {v11, v12, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Landroidx/camera/camera2/internal/s0$d;->OPENING:Landroidx/camera/camera2/internal/s0$d;

    new-instance v12, Landroidx/camera/camera2/internal/s0$d;

    const-string v13, "OPENED"

    invoke-direct {v12, v13, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v12, Landroidx/camera/camera2/internal/s0$d;->OPENED:Landroidx/camera/camera2/internal/s0$d;

    new-instance v13, Landroidx/camera/camera2/internal/s0$d;

    const-string v14, "CLOSED"

    invoke-direct {v13, v14, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v13, Landroidx/camera/camera2/internal/s0$d;->CLOSED:Landroidx/camera/camera2/internal/s0$d;

    new-instance v14, Landroidx/camera/camera2/internal/s0$d;

    const-string v15, "RELEASING"

    invoke-direct {v14, v15, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v14, Landroidx/camera/camera2/internal/s0$d;->RELEASING:Landroidx/camera/camera2/internal/s0$d;

    new-instance v15, Landroidx/camera/camera2/internal/s0$d;

    const-string v1, "RELEASED"

    invoke-direct {v15, v1, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v15, Landroidx/camera/camera2/internal/s0$d;->RELEASED:Landroidx/camera/camera2/internal/s0$d;

    const/16 v1, 0x8

    new-array v1, v1, [Landroidx/camera/camera2/internal/s0$d;

    aput-object v8, v1, v7

    aput-object v9, v1, v6

    aput-object v10, v1, v5

    aput-object v11, v1, v4

    aput-object v12, v1, v3

    aput-object v13, v1, v2

    const/4 v2, 0x6

    aput-object v14, v1, v2

    aput-object v15, v1, v0

    sput-object v1, Landroidx/camera/camera2/internal/s0$d;->$VALUES:[Landroidx/camera/camera2/internal/s0$d;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/camera2/internal/s0$d;
    .registers 2

    const-class v0, Landroidx/camera/camera2/internal/s0$d;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/camera2/internal/s0$d;

    return-object p0
.end method

.method public static values()[Landroidx/camera/camera2/internal/s0$d;
    .registers 1

    sget-object v0, Landroidx/camera/camera2/internal/s0$d;->$VALUES:[Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v0}, [Landroidx/camera/camera2/internal/s0$d;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/camera2/internal/s0$d;

    return-object v0
.end method
