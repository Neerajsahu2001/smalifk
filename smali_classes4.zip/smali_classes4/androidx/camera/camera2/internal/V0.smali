.class final Landroidx/camera/camera2/internal/v0;
.super Ljava/lang/Object;
.source "CaptureSessionRepository.java"


# instance fields
.field final a:Ljava/util/concurrent/Executor;

.field final b:Ljava/lang/Object;

.field final c:Ljava/util/LinkedHashSet;

.field final d:Ljava/util/LinkedHashSet;

.field final e:Ljava/util/LinkedHashSet;

.field private final f:Landroid/hardware/camera2/CameraDevice$StateCallback;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/v0;->c:Ljava/util/LinkedHashSet;

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/v0;->d:Ljava/util/LinkedHashSet;

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/v0;->e:Ljava/util/LinkedHashSet;

    new-instance v0, Landroidx/camera/camera2/internal/v0$a;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/v0$a;-><init>(Landroidx/camera/camera2/internal/v0;)V

    iput-object v0, p0, Landroidx/camera/camera2/internal/v0;->f:Landroid/hardware/camera2/CameraDevice$StateCallback;

    iput-object p1, p0, Landroidx/camera/camera2/internal/v0;->a:Ljava/util/concurrent/Executor;

    return-void
.end method


# virtual methods
.method final a()Landroid/hardware/camera2/CameraDevice$StateCallback;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->f:Landroid/hardware/camera2/CameraDevice$StateCallback;

    return-object v0
.end method

.method final b()Ljava/util/ArrayList;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, Landroidx/camera/camera2/internal/v0;->c:Ljava/util/LinkedHashSet;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    monitor-exit v0

    return-object v1

    :catchall_c
    move-exception v1

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_c

    throw v1
.end method

.method final c()Ljava/util/ArrayList;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, Landroidx/camera/camera2/internal/v0;->d:Ljava/util/LinkedHashSet;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    monitor-exit v0

    return-object v1

    :catchall_c
    move-exception v1

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_c

    throw v1
.end method

.method final d()Ljava/util/ArrayList;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, Landroidx/camera/camera2/internal/v0;->e:Ljava/util/LinkedHashSet;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    monitor-exit v0

    return-object v1

    :catchall_c
    move-exception v1

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_c

    throw v1
.end method

.method final e()Ljava/util/ArrayList;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/v0;->b()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/v0;->d()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    monitor-exit v0

    return-object v1

    :catchall_18
    move-exception v1

    monitor-exit v0
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_18

    throw v1
.end method

.method final f(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/v0;->e()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0;

    if-ne v1, p1, :cond_17

    goto :goto_1b

    :cond_17
    invoke-interface {v1}, Landroidx/camera/camera2/internal/U0;->c()V

    goto :goto_8

    :cond_1b
    :goto_1b
    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_1e
    iget-object v1, p0, Landroidx/camera/camera2/internal/v0;->e:Ljava/util/LinkedHashSet;

    invoke-interface {v1, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :catchall_25
    move-exception p1

    monitor-exit v0
    :try_end_27
    .catchall {:try_start_1e .. :try_end_27} :catchall_25

    throw p1
.end method

.method final g(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/camera2/internal/v0;->c:Ljava/util/LinkedHashSet;

    invoke-interface {v1, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Landroidx/camera/camera2/internal/v0;->e:Ljava/util/LinkedHashSet;

    invoke-interface {v1, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_2a

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/v0;->e()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_29

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/U0;

    if-ne v1, p1, :cond_25

    goto :goto_29

    :cond_25
    invoke-interface {v1}, Landroidx/camera/camera2/internal/U0;->c()V

    goto :goto_16

    :cond_29
    :goto_29
    return-void

    :catchall_2a
    move-exception p1

    :try_start_2b
    monitor-exit v0
    :try_end_2c
    .catchall {:try_start_2b .. :try_end_2c} :catchall_2a

    throw p1
.end method

.method final h(Landroidx/camera/camera2/internal/U0;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/v0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/camera2/internal/v0;->e:Ljava/util/LinkedHashSet;

    invoke-interface {v1, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit v0
    :try_end_c
    .catchall {:try_start_3 .. :try_end_c} :catchall_a

    throw p1
.end method
