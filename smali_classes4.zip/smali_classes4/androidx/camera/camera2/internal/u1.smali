.class public final Landroidx/camera/camera2/internal/u1;
.super Ljava/lang/Object;
.source "ZslControlNoOpImpl.java"

# interfaces
.implements Landroidx/camera/camera2/internal/m1;


# virtual methods
.method public final a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V
    .registers 3

    return-void
.end method

.method public final b()Landroidx/camera/core/r0;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public final c(Landroidx/camera/core/r0;)Z
    .registers 2

    const/4 p1, 0x0

    return p1
.end method

.method public final d(Z)V
    .registers 2

    return-void
.end method
