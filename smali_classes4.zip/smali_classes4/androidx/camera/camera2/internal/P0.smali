.class public final synthetic Landroidx/camera/camera2/internal/p0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/camera2/internal/f0$a;
.implements Landroidx/concurrent/futures/b$c;


# instance fields
.field public final synthetic a:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/p0;->a:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/concurrent/futures/b$a;)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/p0;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroidx/camera/camera2/internal/n;

    invoke-direct {v1, v0, p1}, Landroidx/camera/camera2/internal/n;-><init>(Landroidx/camera/camera2/internal/t;Landroidx/concurrent/futures/b$a;)V

    iget-object p1, v0, Landroidx/camera/camera2/internal/t;->c:Ljava/util/concurrent/Executor;

    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const-string p1, "updateSessionConfigAsync"

    return-object p1
.end method

.method public final b()V
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/p0;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/camera/camera2/internal/s0;

    iget-object v1, v0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_7
    iget-object v2, v0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    sget-object v3, Landroidx/camera/camera2/internal/s0$d;->OPENED:Landroidx/camera/camera2/internal/s0$d;

    if-ne v2, v3, :cond_15

    iget-object v2, v0, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    invoke-virtual {v0, v2}, Landroidx/camera/camera2/internal/s0;->l(Landroidx/camera/core/impl/u0;)V

    goto :goto_15

    :catchall_13
    move-exception v0

    goto :goto_17

    :cond_15
    :goto_15
    monitor-exit v1

    return-void

    :goto_17
    monitor-exit v1
    :try_end_18
    .catchall {:try_start_7 .. :try_end_18} :catchall_13

    throw v0
.end method
