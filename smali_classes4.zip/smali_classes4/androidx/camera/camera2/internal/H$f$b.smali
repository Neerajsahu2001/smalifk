.class final Landroidx/camera/camera2/internal/H$f$b;
.super Ljava/lang/Object;
.source "Camera2CameraImpl.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/H$f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation


# instance fields
.field private a:Ljava/util/concurrent/Executor;

.field private b:Z

.field final synthetic c:Landroidx/camera/camera2/internal/H$f;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/H$f;Ljava/util/concurrent/Executor;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/H$f$b;->c:Landroidx/camera/camera2/internal/H$f;

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/H$f$b;->b:Z

    iput-object p2, p0, Landroidx/camera/camera2/internal/H$f$b;->a:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public static a(Landroidx/camera/camera2/internal/H$f$b;)V
    .registers 4

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/H$f$b;->b:Z

    if-nez v0, :cond_2d

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f$b;->c:Landroidx/camera/camera2/internal/H$f;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    sget-object v1, Landroidx/camera/camera2/internal/H$e;->REOPENING:Landroidx/camera/camera2/internal/H$e;

    const/4 v2, 0x1

    if-ne v0, v1, :cond_11

    const/4 v0, 0x1

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f$b;->c:Landroidx/camera/camera2/internal/H$f;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f;->d()Z

    move-result v0

    if-eqz v0, :cond_26

    iget-object p0, p0, Landroidx/camera/camera2/internal/H$f$b;->c:Landroidx/camera/camera2/internal/H$f;

    iget-object p0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p0, v2}, Landroidx/camera/camera2/internal/H;->P(Z)V

    goto :goto_2d

    :cond_26
    iget-object p0, p0, Landroidx/camera/camera2/internal/H$f$b;->c:Landroidx/camera/camera2/internal/H$f;

    iget-object p0, p0, Landroidx/camera/camera2/internal/H$f;->f:Landroidx/camera/camera2/internal/H;

    invoke-virtual {p0, v2}, Landroidx/camera/camera2/internal/H;->Q(Z)V

    :cond_2d
    :goto_2d
    return-void
.end method


# virtual methods
.method final b()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/camera/camera2/internal/H$f$b;->b:Z

    return-void
.end method

.method public final run()V
    .registers 3

    new-instance v0, Landroidx/camera/camera2/internal/I;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/I;-><init>(Landroidx/camera/camera2/internal/H$f$b;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/H$f$b;->a:Ljava/util/concurrent/Executor;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
