.class final Landroidx/camera/camera2/internal/a1;
.super Landroid/hardware/camera2/CameraCaptureSession$StateCallback;
.source "SynchronizedCaptureSessionBaseImpl.java"


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/Z0;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/Z0;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-direct {p0}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onActive(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/Z0;->s(Landroid/hardware/camera2/CameraCaptureSession;)V

    invoke-virtual {v0, v0}, Landroidx/camera/camera2/internal/Z0;->k(Landroidx/camera/camera2/internal/U0;)V

    return-void
.end method

.method public final onCaptureQueueEmpty(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/Z0;->s(Landroid/hardware/camera2/CameraCaptureSession;)V

    invoke-virtual {v0, v0}, Landroidx/camera/camera2/internal/Z0;->l(Landroidx/camera/camera2/internal/U0;)V

    return-void
.end method

.method public final onClosed(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/Z0;->s(Landroid/hardware/camera2/CameraCaptureSession;)V

    invoke-virtual {v0, v0}, Landroidx/camera/camera2/internal/Z0;->m(Landroidx/camera/camera2/internal/U0;)V

    return-void
.end method

.method public final onConfigureFailed(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 6

    const/4 v0, 0x0

    :try_start_1
    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/Z0;->s(Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1, p1}, Landroidx/camera/camera2/internal/Z0;->n(Landroidx/camera/camera2/internal/U0;)V
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_2e

    iget-object p1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object p1, p1, Landroidx/camera/camera2/internal/Z0;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_10
    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    const-string v2, "OpenCaptureSession completer should not null"

    invoke-static {v1, v2}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v2, v1, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    iput-object v0, v1, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    monitor-exit p1
    :try_end_20
    .catchall {:try_start_10 .. :try_end_20} :catchall_2b

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "onConfigureFailed"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    return-void

    :catchall_2b
    move-exception v0

    :try_start_2c
    monitor-exit p1
    :try_end_2d
    .catchall {:try_start_2c .. :try_end_2d} :catchall_2b

    throw v0

    :catchall_2e
    move-exception p1

    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/Z0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_34
    iget-object v2, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    const-string v3, "OpenCaptureSession completer should not null"

    invoke-static {v2, v3}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v3, v2, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    iput-object v0, v2, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    monitor-exit v1
    :try_end_44
    .catchall {:try_start_34 .. :try_end_44} :catchall_4f

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "onConfigureFailed"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    throw p1

    :catchall_4f
    move-exception p1

    :try_start_50
    monitor-exit v1
    :try_end_51
    .catchall {:try_start_50 .. :try_end_51} :catchall_4f

    throw p1
.end method

.method public final onConfigured(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 6

    const/4 v0, 0x0

    :try_start_1
    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/Z0;->s(Landroid/hardware/camera2/CameraCaptureSession;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1, p1}, Landroidx/camera/camera2/internal/Z0;->o(Landroidx/camera/camera2/internal/U0;)V
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_27

    iget-object p1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object p1, p1, Landroidx/camera/camera2/internal/Z0;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_10
    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    const-string v2, "OpenCaptureSession completer should not null"

    invoke-static {v1, v2}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v2, v1, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    iput-object v0, v1, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    monitor-exit p1
    :try_end_20
    .catchall {:try_start_10 .. :try_end_20} :catchall_24

    invoke-virtual {v2, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    return-void

    :catchall_24
    move-exception v0

    :try_start_25
    monitor-exit p1
    :try_end_26
    .catchall {:try_start_25 .. :try_end_26} :catchall_24

    throw v0

    :catchall_27
    move-exception p1

    iget-object v1, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/Z0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_2d
    iget-object v2, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    const-string v3, "OpenCaptureSession completer should not null"

    invoke-static {v2, v3}, Landroidx/core/util/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    iget-object v3, v2, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    iput-object v0, v2, Landroidx/camera/camera2/internal/Z0;->i:Landroidx/concurrent/futures/b$a;

    monitor-exit v1
    :try_end_3d
    .catchall {:try_start_2d .. :try_end_3d} :catchall_41

    invoke-virtual {v3, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    throw p1

    :catchall_41
    move-exception p1

    :try_start_42
    monitor-exit v1
    :try_end_43
    .catchall {:try_start_42 .. :try_end_43} :catchall_41

    throw p1
.end method

.method public final onReady(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/Z0;->s(Landroid/hardware/camera2/CameraCaptureSession;)V

    invoke-virtual {v0, v0}, Landroidx/camera/camera2/internal/Z0;->p(Landroidx/camera/camera2/internal/U0;)V

    return-void
.end method

.method public final onSurfacePrepared(Landroid/hardware/camera2/CameraCaptureSession;Landroid/view/Surface;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/a1;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/Z0;->s(Landroid/hardware/camera2/CameraCaptureSession;)V

    invoke-virtual {v0, v0, p2}, Landroidx/camera/camera2/internal/Z0;->r(Landroidx/camera/camera2/internal/U0;Landroid/view/Surface;)V

    return-void
.end method
