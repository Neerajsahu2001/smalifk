.class final Landroidx/camera/camera2/internal/l0;
.super Ljava/lang/Object;
.source "CameraStateMachine.java"


# instance fields
.field private final a:Landroidx/camera/core/impl/z;

.field private final b:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "Landroidx/camera/core/t;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroidx/camera/core/impl/z;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/l0;->a:Landroidx/camera/core/impl/z;

    new-instance p1, Landroidx/lifecycle/I;

    invoke-direct {p1}, Landroidx/lifecycle/I;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/l0;->b:Landroidx/lifecycle/I;

    sget-object v0, Landroidx/camera/core/t$b;->CLOSED:Landroidx/camera/core/t$b;

    invoke-static {v0}, Landroidx/camera/core/t;->a(Landroidx/camera/core/t$b;)Landroidx/camera/core/t;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroidx/lifecycle/I;->postValue(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final a()Landroidx/lifecycle/I;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/l0;->b:Landroidx/lifecycle/I;

    return-object v0
.end method

.method public final b(Landroidx/camera/core/impl/x$a;Landroidx/camera/core/t$a;)V
    .registers 6

    sget-object v0, Landroidx/camera/camera2/internal/l0$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_96

    new-instance p2, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Unknown internal camera state: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :pswitch_1f
    sget-object v0, Landroidx/camera/core/t$b;->CLOSED:Landroidx/camera/core/t$b;

    invoke-static {v0, p2}, Landroidx/camera/core/t;->b(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)Landroidx/camera/core/t;

    move-result-object v0

    goto :goto_50

    :pswitch_26
    sget-object v0, Landroidx/camera/core/t$b;->CLOSING:Landroidx/camera/core/t$b;

    invoke-static {v0, p2}, Landroidx/camera/core/t;->b(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)Landroidx/camera/core/t;

    move-result-object v0

    goto :goto_50

    :pswitch_2d
    sget-object v0, Landroidx/camera/core/t$b;->OPEN:Landroidx/camera/core/t$b;

    invoke-static {v0, p2}, Landroidx/camera/core/t;->b(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)Landroidx/camera/core/t;

    move-result-object v0

    goto :goto_50

    :pswitch_34
    sget-object v0, Landroidx/camera/core/t$b;->OPENING:Landroidx/camera/core/t$b;

    invoke-static {v0, p2}, Landroidx/camera/core/t;->b(Landroidx/camera/core/t$b;Landroidx/camera/core/t$a;)Landroidx/camera/core/t;

    move-result-object v0

    goto :goto_50

    :pswitch_3b
    iget-object v0, p0, Landroidx/camera/camera2/internal/l0;->a:Landroidx/camera/core/impl/z;

    invoke-virtual {v0}, Landroidx/camera/core/impl/z;->a()Z

    move-result v0

    if-eqz v0, :cond_4a

    sget-object v0, Landroidx/camera/core/t$b;->OPENING:Landroidx/camera/core/t$b;

    invoke-static {v0}, Landroidx/camera/core/t;->a(Landroidx/camera/core/t$b;)Landroidx/camera/core/t;

    move-result-object v0

    goto :goto_50

    :cond_4a
    sget-object v0, Landroidx/camera/core/t$b;->PENDING_OPEN:Landroidx/camera/core/t$b;

    invoke-static {v0}, Landroidx/camera/core/t;->a(Landroidx/camera/core/t$b;)Landroidx/camera/core/t;

    move-result-object v0

    :goto_50
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "New public camera state "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " from "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " and "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "CameraStateMachine"

    invoke-static {p2, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/l0;->b:Landroidx/lifecycle/I;

    invoke-virtual {p1}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/t;

    invoke-static {v1, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_95

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Publishing new public camera state "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p2, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Landroidx/lifecycle/I;->postValue(Ljava/lang/Object;)V

    :cond_95
    return-void

    :pswitch_data_96
    .packed-switch 0x1
        :pswitch_3b
        :pswitch_34
        :pswitch_2d
        :pswitch_26
        :pswitch_26
        :pswitch_1f
        :pswitch_1f
    .end packed-switch
.end method
