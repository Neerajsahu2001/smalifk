.class interface abstract Landroidx/camera/camera2/internal/e1$b;
.super Ljava/lang/Object;
.source "SynchronizedCaptureSessionOpener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/e1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/hardware/camera2/CameraDevice;",
            "Lq/i;",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/K;",
            ">;)",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end method

.method public abstract g(Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;
.end method

.method public abstract stop()Z
.end method
