.class final Landroidx/camera/camera2/internal/e1$a;
.super Ljava/lang/Object;
.source "SynchronizedCaptureSessionOpener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/e1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/util/concurrent/Executor;

.field private final b:Ljava/util/concurrent/ScheduledExecutorService;

.field private final c:Landroid/os/Handler;

.field private final d:Landroidx/camera/camera2/internal/v0;

.field private final e:Landroidx/camera/core/impl/s0;

.field private final f:Landroidx/camera/core/impl/s0;

.field private final g:Z


# direct methods
.method constructor <init>(Landroid/os/Handler;Landroidx/camera/camera2/internal/v0;Landroidx/camera/core/impl/s0;Landroidx/camera/core/impl/s0;Ljava/util/concurrent/Executor;Ljava/util/concurrent/ScheduledExecutorService;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p5, p0, Landroidx/camera/camera2/internal/e1$a;->a:Ljava/util/concurrent/Executor;

    iput-object p6, p0, Landroidx/camera/camera2/internal/e1$a;->b:Ljava/util/concurrent/ScheduledExecutorService;

    iput-object p1, p0, Landroidx/camera/camera2/internal/e1$a;->c:Landroid/os/Handler;

    iput-object p2, p0, Landroidx/camera/camera2/internal/e1$a;->d:Landroidx/camera/camera2/internal/v0;

    iput-object p3, p0, Landroidx/camera/camera2/internal/e1$a;->e:Landroidx/camera/core/impl/s0;

    iput-object p4, p0, Landroidx/camera/camera2/internal/e1$a;->f:Landroidx/camera/core/impl/s0;

    new-instance p1, Ls/f;

    invoke-direct {p1, p3, p4}, Ls/f;-><init>(Landroidx/camera/core/impl/s0;Landroidx/camera/core/impl/s0;)V

    invoke-virtual {p1}, Ls/f;->b()Z

    move-result p1

    if-nez p1, :cond_33

    new-instance p1, Ls/r;

    invoke-direct {p1, p3}, Ls/r;-><init>(Landroidx/camera/core/impl/s0;)V

    invoke-virtual {p1}, Ls/r;->e()Z

    move-result p1

    if-nez p1, :cond_33

    new-instance p1, Ls/e;

    invoke-direct {p1, p4}, Ls/e;-><init>(Landroidx/camera/core/impl/s0;)V

    invoke-virtual {p1}, Ls/e;->a()Z

    move-result p1

    if-eqz p1, :cond_31

    goto :goto_33

    :cond_31
    const/4 p1, 0x0

    goto :goto_34

    :cond_33
    :goto_33
    const/4 p1, 0x1

    :goto_34
    iput-boolean p1, p0, Landroidx/camera/camera2/internal/e1$a;->g:Z

    return-void
.end method


# virtual methods
.method final a()Landroidx/camera/camera2/internal/e1;
    .registers 10

    new-instance v0, Landroidx/camera/camera2/internal/e1;

    iget-boolean v1, p0, Landroidx/camera/camera2/internal/e1$a;->g:Z

    if-eqz v1, :cond_19

    new-instance v1, Landroidx/camera/camera2/internal/d1;

    iget-object v6, p0, Landroidx/camera/camera2/internal/e1$a;->f:Landroidx/camera/core/impl/s0;

    iget-object v7, p0, Landroidx/camera/camera2/internal/e1$a;->a:Ljava/util/concurrent/Executor;

    iget-object v3, p0, Landroidx/camera/camera2/internal/e1$a;->c:Landroid/os/Handler;

    iget-object v4, p0, Landroidx/camera/camera2/internal/e1$a;->d:Landroidx/camera/camera2/internal/v0;

    iget-object v5, p0, Landroidx/camera/camera2/internal/e1$a;->e:Landroidx/camera/core/impl/s0;

    iget-object v8, p0, Landroidx/camera/camera2/internal/e1$a;->b:Ljava/util/concurrent/ScheduledExecutorService;

    move-object v2, v1

    invoke-direct/range {v2 .. v8}, Landroidx/camera/camera2/internal/d1;-><init>(Landroid/os/Handler;Landroidx/camera/camera2/internal/v0;Landroidx/camera/core/impl/s0;Landroidx/camera/core/impl/s0;Ljava/util/concurrent/Executor;Ljava/util/concurrent/ScheduledExecutorService;)V

    goto :goto_26

    :cond_19
    new-instance v1, Landroidx/camera/camera2/internal/Z0;

    iget-object v2, p0, Landroidx/camera/camera2/internal/e1$a;->d:Landroidx/camera/camera2/internal/v0;

    iget-object v3, p0, Landroidx/camera/camera2/internal/e1$a;->a:Ljava/util/concurrent/Executor;

    iget-object v4, p0, Landroidx/camera/camera2/internal/e1$a;->b:Ljava/util/concurrent/ScheduledExecutorService;

    iget-object v5, p0, Landroidx/camera/camera2/internal/e1$a;->c:Landroid/os/Handler;

    invoke-direct {v1, v2, v3, v4, v5}, Landroidx/camera/camera2/internal/Z0;-><init>(Landroidx/camera/camera2/internal/v0;Ljava/util/concurrent/Executor;Ljava/util/concurrent/ScheduledExecutorService;Landroid/os/Handler;)V

    :goto_26
    invoke-direct {v0, v1}, Landroidx/camera/camera2/internal/e1;-><init>(Landroidx/camera/camera2/internal/Z0;)V

    return-object v0
.end method
