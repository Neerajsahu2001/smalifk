.class final Landroidx/camera/camera2/internal/s1$a;
.super Landroidx/camera/core/impl/g;
.source "ZslControlImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/camera2/internal/s1;->a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/s1;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/s1;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/camera2/internal/s1$a;->a:Landroidx/camera/camera2/internal/s1;

    invoke-direct {p0}, Landroidx/camera/core/impl/g;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Landroidx/camera/core/impl/o;)V
    .registers 3

    invoke-interface {p1}, Landroidx/camera/core/impl/o;->b()Landroid/hardware/camera2/CaptureResult;

    move-result-object p1

    if-eqz p1, :cond_13

    instance-of v0, p1, Landroid/hardware/camera2/TotalCaptureResult;

    if-eqz v0, :cond_13

    iget-object v0, p0, Landroidx/camera/camera2/internal/s1$a;->a:Landroidx/camera/camera2/internal/s1;

    iget-object v0, v0, Landroidx/camera/camera2/internal/s1;->b:Ljava/util/LinkedList;

    check-cast p1, Landroid/hardware/camera2/TotalCaptureResult;

    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    :cond_13
    return-void
.end method
