.class final Landroidx/camera/camera2/internal/H$c;
.super Landroid/hardware/camera2/CameraManager$AvailabilityCallback;
.source "Camera2CameraImpl.java"

# interfaces
.implements Landroidx/camera/core/impl/z$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/H;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "c"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private b:Z

.field final synthetic c:Landroidx/camera/camera2/internal/H;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/H;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Landroidx/camera/camera2/internal/H$c;->c:Landroidx/camera/camera2/internal/H;

    invoke-direct {p0}, Landroid/hardware/camera2/CameraManager$AvailabilityCallback;-><init>()V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/H$c;->b:Z

    iput-object p2, p0, Landroidx/camera/camera2/internal/H$c;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method final a()Z
    .registers 2

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/H$c;->b:Z

    return v0
.end method

.method public final onCameraAvailable(Ljava/lang/String;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$c;->a:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_9

    return-void

    :cond_9
    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/H$c;->b:Z

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$c;->c:Landroidx/camera/camera2/internal/H;

    iget-object p1, p1, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    sget-object v0, Landroidx/camera/camera2/internal/H$e;->PENDING_OPEN:Landroidx/camera/camera2/internal/H$e;

    if-ne p1, v0, :cond_1a

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$c;->c:Landroidx/camera/camera2/internal/H;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/camera/camera2/internal/H;->Q(Z)V

    :cond_1a
    return-void
.end method

.method public final onCameraUnavailable(Ljava/lang/String;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$c;->a:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_9

    return-void

    :cond_9
    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/H$c;->b:Z

    return-void
.end method
