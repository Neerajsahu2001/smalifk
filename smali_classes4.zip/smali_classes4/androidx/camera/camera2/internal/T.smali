.class public final Landroidx/camera/camera2/internal/t;
.super Ljava/lang/Object;
.source "Camera2CameraControlImpl.java"

# interfaces
.implements Landroidx/camera/core/impl/t;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/t$a;,
        Landroidx/camera/camera2/internal/t$b;,
        Landroidx/camera/camera2/internal/t$c;
    }
.end annotation


# instance fields
.field final b:Landroidx/camera/camera2/internal/t$b;

.field final c:Ljava/util/concurrent/Executor;

.field private final d:Ljava/lang/Object;

.field private final e:Lp/E;

.field private final f:Landroidx/camera/core/impl/t$c;

.field private final g:Landroidx/camera/core/impl/u0$b;

.field private final h:Landroidx/camera/camera2/internal/J0;

.field private final i:Landroidx/camera/camera2/internal/k1;

.field private final j:Landroidx/camera/camera2/internal/j1;

.field private final k:Landroidx/camera/camera2/internal/y0;

.field l:Landroidx/camera/camera2/internal/m1;

.field private final m:Lt/g;

.field private final n:Landroidx/camera/camera2/internal/P;

.field private o:I

.field private volatile p:Z

.field private volatile q:I

.field private final r:Ls/a;

.field private final s:Landroidx/camera/core/impl/utils/l;

.field private final t:Ljava/util/concurrent/atomic/AtomicLong;

.field private volatile u:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private v:I

.field private w:J

.field private final x:Landroidx/camera/camera2/internal/t$a;


# direct methods
.method constructor <init>(Lp/E;Ljava/util/concurrent/ScheduledExecutorService;Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/t$c;Landroidx/camera/core/impl/s0;)V
    .registers 11

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/t;->d:Ljava/lang/Object;

    new-instance v0, Landroidx/camera/core/impl/u0$b;

    invoke-direct {v0}, Landroidx/camera/core/impl/u0$b;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/t;->g:Landroidx/camera/core/impl/u0$b;

    const/4 v1, 0x0

    iput v1, p0, Landroidx/camera/camera2/internal/t;->o:I

    iput-boolean v1, p0, Landroidx/camera/camera2/internal/t;->p:Z

    const/4 v2, 0x2

    iput v2, p0, Landroidx/camera/camera2/internal/t;->q:I

    new-instance v2, Landroidx/camera/core/impl/utils/l;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v2, p0, Landroidx/camera/camera2/internal/t;->s:Landroidx/camera/core/impl/utils/l;

    new-instance v2, Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 v3, 0x0

    invoke-direct {v2, v3, v4}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    iput-object v2, p0, Landroidx/camera/camera2/internal/t;->t:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    invoke-static {v2}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v2

    iput-object v2, p0, Landroidx/camera/camera2/internal/t;->u:Lcom/google/common/util/concurrent/o;

    const/4 v2, 0x1

    iput v2, p0, Landroidx/camera/camera2/internal/t;->v:I

    iput-wide v3, p0, Landroidx/camera/camera2/internal/t;->w:J

    new-instance v2, Landroidx/camera/camera2/internal/t$a;

    invoke-direct {v2}, Landroidx/camera/camera2/internal/t$a;-><init>()V

    iput-object v2, p0, Landroidx/camera/camera2/internal/t;->x:Landroidx/camera/camera2/internal/t$a;

    iput-object p1, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    iput-object p4, p0, Landroidx/camera/camera2/internal/t;->f:Landroidx/camera/core/impl/t$c;

    iput-object p3, p0, Landroidx/camera/camera2/internal/t;->c:Ljava/util/concurrent/Executor;

    new-instance p4, Landroidx/camera/camera2/internal/t$b;

    invoke-direct {p4, p3}, Landroidx/camera/camera2/internal/t$b;-><init>(Ljava/util/concurrent/Executor;)V

    iput-object p4, p0, Landroidx/camera/camera2/internal/t;->b:Landroidx/camera/camera2/internal/t$b;

    iget v3, p0, Landroidx/camera/camera2/internal/t;->v:I

    invoke-virtual {v0, v3}, Landroidx/camera/core/impl/u0$b;->q(I)V

    invoke-static {p4}, Landroidx/camera/camera2/internal/n0;->d(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)Landroidx/camera/camera2/internal/n0;

    move-result-object p4

    invoke-virtual {v0, p4}, Landroidx/camera/core/impl/u0$b;->g(Landroidx/camera/core/impl/g;)V

    invoke-virtual {v0, v2}, Landroidx/camera/core/impl/u0$b;->g(Landroidx/camera/core/impl/g;)V

    new-instance p4, Landroidx/camera/camera2/internal/y0;

    invoke-direct {p4, p0, p3}, Landroidx/camera/camera2/internal/y0;-><init>(Landroidx/camera/camera2/internal/t;Ljava/util/concurrent/Executor;)V

    iput-object p4, p0, Landroidx/camera/camera2/internal/t;->k:Landroidx/camera/camera2/internal/y0;

    new-instance p4, Landroidx/camera/camera2/internal/J0;

    invoke-direct {p4, p0, p2, p3, p5}, Landroidx/camera/camera2/internal/J0;-><init>(Landroidx/camera/camera2/internal/t;Ljava/util/concurrent/ScheduledExecutorService;Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/s0;)V

    iput-object p4, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    new-instance p2, Landroidx/camera/camera2/internal/k1;

    invoke-direct {p2, p0, p1, p3}, Landroidx/camera/camera2/internal/k1;-><init>(Landroidx/camera/camera2/internal/t;Lp/E;Ljava/util/concurrent/Executor;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/t;->i:Landroidx/camera/camera2/internal/k1;

    new-instance p2, Landroidx/camera/camera2/internal/j1;

    invoke-direct {p2, p0, p1, p3}, Landroidx/camera/camera2/internal/j1;-><init>(Landroidx/camera/camera2/internal/t;Lp/E;Ljava/util/concurrent/Executor;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/t;->j:Landroidx/camera/camera2/internal/j1;

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p4, 0x17

    if-lt p2, p4, :cond_82

    new-instance p2, Landroidx/camera/camera2/internal/s1;

    invoke-direct {p2, p1}, Landroidx/camera/camera2/internal/s1;-><init>(Lp/E;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/t;->l:Landroidx/camera/camera2/internal/m1;

    goto :goto_89

    :cond_82
    new-instance p2, Landroidx/camera/camera2/internal/u1;

    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/camera/camera2/internal/t;->l:Landroidx/camera/camera2/internal/m1;

    :goto_89
    new-instance p2, Ls/a;

    invoke-direct {p2, p5}, Ls/a;-><init>(Landroidx/camera/core/impl/s0;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/t;->r:Ls/a;

    new-instance p2, Lt/g;

    invoke-direct {p2, p0, p3}, Lt/g;-><init>(Landroidx/camera/camera2/internal/t;Ljava/util/concurrent/Executor;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    new-instance p2, Landroidx/camera/camera2/internal/P;

    invoke-direct {p2, p0, p1, p5, p3}, Landroidx/camera/camera2/internal/P;-><init>(Landroidx/camera/camera2/internal/t;Lp/E;Landroidx/camera/core/impl/s0;Ljava/util/concurrent/Executor;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/t;->n:Landroidx/camera/camera2/internal/P;

    new-instance p1, Landroidx/camera/camera2/internal/m;

    invoke-direct {p1, v1, p0}, Landroidx/camera/camera2/internal/m;-><init>(ILjava/lang/Object;)V

    invoke-interface {p3, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private C()Z
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->d:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget v1, p0, Landroidx/camera/camera2/internal/t;->o:I

    monitor-exit v0

    if-lez v1, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return v0

    :catchall_c
    move-exception v1

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_c

    throw v1
.end method

.method private static D(I[I)Z
    .registers 6

    array-length v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_3
    if-ge v2, v0, :cond_e

    aget v3, p1, v2

    if-ne p0, v3, :cond_b

    const/4 p0, 0x1

    return p0

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_e
    return v1
.end method

.method static E(Landroid/hardware/camera2/TotalCaptureResult;J)Z
    .registers 7

    invoke-virtual {p0}, Landroid/hardware/camera2/CaptureResult;->getRequest()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    invoke-virtual {p0}, Landroid/hardware/camera2/CaptureResult;->getRequest()Landroid/hardware/camera2/CaptureRequest;

    move-result-object p0

    invoke-virtual {p0}, Landroid/hardware/camera2/CaptureRequest;->getTag()Ljava/lang/Object;

    move-result-object p0

    instance-of v0, p0, Landroidx/camera/core/impl/B0;

    if-eqz v0, :cond_2b

    check-cast p0, Landroidx/camera/core/impl/B0;

    const-string v0, "CameraControlSessionUpdateId"

    invoke-virtual {p0, v0}, Landroidx/camera/core/impl/B0;->b(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    if-nez p0, :cond_21

    return v1

    :cond_21
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    cmp-long p0, v2, p1

    if-ltz p0, :cond_2b

    const/4 p0, 0x1

    return p0

    :cond_2b
    return v1
.end method

.method public static synthetic g(Landroidx/camera/camera2/internal/t;)V
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    invoke-virtual {v0}, Lt/g;->g()Lt/c;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/t;->k(Landroidx/camera/camera2/internal/t$c;)V

    return-void
.end method

.method public static h(Landroidx/camera/camera2/internal/t;Landroidx/camera/core/impl/g;)V
    .registers 3

    iget-object p0, p0, Landroidx/camera/camera2/internal/t;->x:Landroidx/camera/camera2/internal/t$a;

    iget-object v0, p0, Landroidx/camera/camera2/internal/t$a;->a:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/camera/camera2/internal/t$a;->b:Landroid/util/ArrayMap;

    invoke-virtual {p0, p1}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static i(Landroidx/camera/camera2/internal/t;Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/g;)V
    .registers 4

    iget-object p0, p0, Landroidx/camera/camera2/internal/t;->x:Landroidx/camera/camera2/internal/t$a;

    iget-object v0, p0, Landroidx/camera/camera2/internal/t$a;->a:Ljava/util/HashSet;

    invoke-virtual {v0, p2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/camera/camera2/internal/t$a;->b:Landroid/util/ArrayMap;

    invoke-virtual {p0, p2, p1}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static synthetic j(Landroidx/camera/camera2/internal/t;Ljava/util/List;III)Lcom/google/common/util/concurrent/o;
    .registers 5

    iget-object p0, p0, Landroidx/camera/camera2/internal/t;->n:Landroidx/camera/camera2/internal/P;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/camera/camera2/internal/P;->c(Ljava/util/List;III)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final A()Landroidx/camera/camera2/internal/k1;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->i:Landroidx/camera/camera2/internal/k1;

    return-object v0
.end method

.method final B()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->d:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget v1, p0, Landroidx/camera/camera2/internal/t;->o:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Landroidx/camera/camera2/internal/t;->o:I

    monitor-exit v0

    return-void

    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method final F()Z
    .registers 2

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/t;->p:Z

    return v0
.end method

.method final G(Z)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/J0;->g(Z)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->i:Landroidx/camera/camera2/internal/k1;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/k1;->d(Z)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->j:Landroidx/camera/camera2/internal/j1;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/j1;->e(Z)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->k:Landroidx/camera/camera2/internal/y0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/y0;->a(Z)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    invoke-virtual {v0, p1}, Lt/g;->h(Z)V

    return-void
.end method

.method public final H(Landroid/util/Rational;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/J0;->h(Landroid/util/Rational;)V

    return-void
.end method

.method final I(I)V
    .registers 3

    iput p1, p0, Landroidx/camera/camera2/internal/t;->v:I

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/J0;->i(I)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/t;->n:Landroidx/camera/camera2/internal/P;

    iget v0, p0, Landroidx/camera/camera2/internal/t;->v:I

    invoke-virtual {p1, v0}, Landroidx/camera/camera2/internal/P;->b(I)V

    return-void
.end method

.method final J(Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/D;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->f:Landroidx/camera/core/impl/t$c;

    check-cast v0, Landroidx/camera/camera2/internal/H$d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Ljava/util/List;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H$d;->a:Landroidx/camera/camera2/internal/H;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/H;->M(Ljava/util/List;)V

    return-void
.end method

.method public final K()V
    .registers 3

    new-instance v0, Landroidx/camera/camera2/internal/p;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/p;-><init>(Landroidx/camera/camera2/internal/t;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/t;->c:Ljava/util/concurrent/Executor;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method final L()J
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->t:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    move-result-wide v0

    iput-wide v0, p0, Landroidx/camera/camera2/internal/t;->w:J

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->f:Landroidx/camera/core/impl/t$c;

    check-cast v0, Landroidx/camera/camera2/internal/H$d;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H$d;->a:Landroidx/camera/camera2/internal/H;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H;->R()V

    iget-wide v0, p0, Landroidx/camera/camera2/internal/t;->w:J

    return-wide v0
.end method

.method public final a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->l:Landroidx/camera/camera2/internal/m1;

    invoke-interface {v0, p1, p2}, Landroidx/camera/camera2/internal/m1;->a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V

    return-void
.end method

.method public final b()Lcom/google/common/util/concurrent/o;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, Landroidx/camera/camera2/internal/t;->C()Z

    move-result v0

    if-nez v0, :cond_12

    new-instance v0, Landroidx/camera/core/n$a;

    const-string v1, "Camera is not active."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    return-object v0

    :cond_12
    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroidx/camera/camera2/internal/F0;

    invoke-direct {v1, v0}, Landroidx/camera/camera2/internal/F0;-><init>(Landroidx/camera/camera2/internal/J0;)V

    invoke-static {v1}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    invoke-static {v0}, Lv/f;->i(Lcom/google/common/util/concurrent/o;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    return-object v0
.end method

.method public final c(I)V
    .registers 3

    invoke-direct {p0}, Landroidx/camera/camera2/internal/t;->C()Z

    move-result v0

    if-nez v0, :cond_e

    const-string p1, "Camera2CameraControlImp"

    const-string v0, "Camera is not active."

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_e
    iput p1, p0, Landroidx/camera/camera2/internal/t;->q:I

    new-instance p1, Landroidx/camera/camera2/internal/p0;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/p0;-><init>(Ljava/lang/Object;)V

    invoke-static {p1}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    invoke-static {p1}, Lv/f;->i(Lcom/google/common/util/concurrent/o;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/camera2/internal/t;->u:Lcom/google/common/util/concurrent/o;

    return-void
.end method

.method public final d(Z)Lcom/google/common/util/concurrent/o;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, Landroidx/camera/camera2/internal/t;->C()Z

    move-result v0

    if-nez v0, :cond_12

    new-instance p1, Landroidx/camera/core/n$a;

    const-string v0, "Camera is not active."

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_12
    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->j:Landroidx/camera/camera2/internal/j1;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/j1;->b(Z)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    invoke-static {p1}, Lv/f;->i(Lcom/google/common/util/concurrent/o;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method public final e(Landroidx/camera/core/I;)Lcom/google/common/util/concurrent/o;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/I;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Landroidx/camera/core/J;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, Landroidx/camera/camera2/internal/t;->C()Z

    move-result v0

    if-nez v0, :cond_12

    new-instance p1, Landroidx/camera/core/n$a;

    const-string v0, "Camera is not active."

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_12
    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroidx/camera/camera2/internal/D0;

    invoke-direct {v1, v0, p1}, Landroidx/camera/camera2/internal/D0;-><init>(Landroidx/camera/camera2/internal/J0;Landroidx/camera/core/I;)V

    invoke-static {v1}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    invoke-static {p1}, Lv/f;->i(Lcom/google/common/util/concurrent/o;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method public final f(Ljava/util/ArrayList;II)Lcom/google/common/util/concurrent/o;
    .registers 12

    invoke-direct {p0}, Landroidx/camera/camera2/internal/t;->C()Z

    move-result v0

    if-nez v0, :cond_17

    const-string p1, "Camera2CameraControlImp"

    const-string p2, "Camera is not active."

    invoke-static {p1, p2}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Landroidx/camera/core/n$a;

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_17
    iget v4, p0, Landroidx/camera/camera2/internal/t;->q:I

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->u:Lcom/google/common/util/concurrent/o;

    invoke-static {v0}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object v6

    new-instance v7, Landroidx/camera/camera2/internal/j;

    move-object v0, v7

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move v5, p3

    invoke-direct/range {v0 .. v5}, Landroidx/camera/camera2/internal/j;-><init>(Landroidx/camera/camera2/internal/t;Ljava/util/ArrayList;III)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/t;->c:Ljava/util/concurrent/Executor;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v6, v7, p1}, Lv/f;->n(Lcom/google/common/util/concurrent/o;Lv/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    check-cast p1, Lv/d;

    return-object p1
.end method

.method final k(Landroidx/camera/camera2/internal/t$c;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->b:Landroidx/camera/camera2/internal/t$b;

    iget-object v0, v0, Landroidx/camera/camera2/internal/t$b;->a:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final l(Landroidx/camera/core/impl/H;)V
    .registers 4

    invoke-static {p1}, Lt/j$a;->e(Landroidx/camera/core/impl/H;)Lt/j$a;

    move-result-object p1

    invoke-virtual {p1}, Lt/j$a;->c()Lt/j;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    invoke-virtual {v0, p1}, Lt/g;->d(Lt/j;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    new-instance v0, Landroidx/camera/camera2/internal/l;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-interface {p1, v0, v1}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public final m()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    invoke-virtual {v0}, Lt/g;->e()Lcom/google/common/util/concurrent/o;

    move-result-object v0

    new-instance v1, Landroidx/camera/camera2/internal/l;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method final n()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->d:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget v1, p0, Landroidx/camera/camera2/internal/t;->o:I

    if-eqz v1, :cond_f

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Landroidx/camera/camera2/internal/t;->o:I

    monitor-exit v0

    return-void

    :catchall_d
    move-exception v1

    goto :goto_17

    :cond_f
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Decrementing use count occurs more times than incrementing"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_17
    monitor-exit v0
    :try_end_18
    .catchall {:try_start_3 .. :try_end_18} :catchall_d

    throw v1
.end method

.method final o(Z)V
    .registers 5

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/t;->p:Z

    if-nez p1, :cond_40

    new-instance p1, Landroidx/camera/core/impl/D$a;

    invoke-direct {p1}, Landroidx/camera/core/impl/D$a;-><init>()V

    iget v0, p0, Landroidx/camera/camera2/internal/t;->v:I

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/D$a;->o(I)V

    invoke-virtual {p1}, Landroidx/camera/core/impl/D$a;->p()V

    new-instance v0, Lo/a$a;

    invoke-direct {v0}, Lo/a$a;-><init>()V

    sget-object v1, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Landroidx/camera/camera2/internal/t;->x(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    sget-object v1, Landroid/hardware/camera2/CaptureRequest;->FLASH_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    invoke-virtual {v0}, Lo/a$a;->b()Lo/a;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    invoke-virtual {p1}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/camera/camera2/internal/t;->J(Ljava/util/List;)V

    :cond_40
    invoke-virtual {p0}, Landroidx/camera/camera2/internal/t;->L()J

    return-void
.end method

.method final p()Landroid/graphics/Rect;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->i:Landroidx/camera/camera2/internal/k1;

    iget-object v0, v0, Landroidx/camera/camera2/internal/k1;->e:Landroidx/camera/camera2/internal/k1$b;

    invoke-interface {v0}, Landroidx/camera/camera2/internal/k1$b;->e()Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public final q()Landroidx/camera/camera2/internal/J0;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    return-object v0
.end method

.method public final r()Landroidx/camera/core/impl/H;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    invoke-virtual {v0}, Lt/g;->f()Lo/a;

    move-result-object v0

    return-object v0
.end method

.method final s()I
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_e

    const/4 v0, 0x0

    goto :goto_12

    :cond_e
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    :goto_12
    return v0
.end method

.method final t()I
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AF:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_e

    const/4 v0, 0x0

    goto :goto_12

    :cond_e
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    :goto_12
    return v0
.end method

.method final u()I
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AWB:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_e

    const/4 v0, 0x0

    goto :goto_12

    :cond_e
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    :goto_12
    return v0
.end method

.method public final v()Landroid/graphics/Rect;
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->SENSOR_INFO_ACTIVE_ARRAY_SIZE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Rect;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0
.end method

.method public final w()Landroidx/camera/core/impl/u0;
    .registers 9

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->g:Landroidx/camera/core/impl/u0$b;

    iget v1, p0, Landroidx/camera/camera2/internal/t;->v:I

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/u0$b;->q(I)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->g:Landroidx/camera/core/impl/u0$b;

    new-instance v1, Lo/a$a;

    invoke-direct {v1}, Lo/a$a;-><init>()V

    sget-object v2, Landroid/hardware/camera2/CaptureRequest;->CONTROL_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v3, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v2, v4}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/t;->h:Landroidx/camera/camera2/internal/J0;

    invoke-virtual {v2, v1}, Landroidx/camera/camera2/internal/J0;->c(Lo/a$a;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/t;->r:Ls/a;

    invoke-virtual {v2, v1}, Ls/a;->a(Lo/a$a;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/t;->i:Landroidx/camera/camera2/internal/k1;

    iget-object v2, v2, Landroidx/camera/camera2/internal/k1;->e:Landroidx/camera/camera2/internal/k1$b;

    invoke-interface {v2, v1}, Landroidx/camera/camera2/internal/k1$b;->f(Lo/a$a;)V

    iget-boolean v2, p0, Landroidx/camera/camera2/internal/t;->p:Z

    const/4 v4, 0x2

    if-eqz v2, :cond_38

    sget-object v2, Landroid/hardware/camera2/CaptureRequest;->FLASH_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v2, v4}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    goto :goto_3e

    :cond_38
    iget v2, p0, Landroidx/camera/camera2/internal/t;->q:I

    if-eqz v2, :cond_42

    if-eq v2, v3, :cond_40

    :goto_3e
    const/4 v2, 0x1

    goto :goto_53

    :cond_40
    const/4 v2, 0x3

    goto :goto_53

    :cond_42
    iget-object v2, p0, Landroidx/camera/camera2/internal/t;->s:Landroidx/camera/core/impl/utils/l;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v2, Lr/k;

    invoke-static {v2}, Lr/l;->a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object v2

    check-cast v2, Lr/k;

    if-eqz v2, :cond_52

    const/4 v4, 0x1

    :cond_52
    move v2, v4

    :goto_53
    sget-object v4, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {p0, v2}, Landroidx/camera/camera2/internal/t;->x(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v4, v2}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    sget-object v2, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AWB_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    iget-object v4, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    sget-object v5, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_AWB_AVAILABLE_MODES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v4, v5}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [I

    const/4 v5, 0x0

    if-nez v4, :cond_71

    :cond_6f
    const/4 v3, 0x0

    goto :goto_7e

    :cond_71
    invoke-static {v3, v4}, Landroidx/camera/camera2/internal/t;->D(I[I)Z

    move-result v6

    if-eqz v6, :cond_78

    goto :goto_7e

    :cond_78
    invoke-static {v3, v4}, Landroidx/camera/camera2/internal/t;->D(I[I)Z

    move-result v4

    if-eqz v4, :cond_6f

    :goto_7e
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/t;->k:Landroidx/camera/camera2/internal/y0;

    invoke-virtual {v2, v1}, Landroidx/camera/camera2/internal/y0;->b(Lo/a$a;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    invoke-virtual {v2}, Lt/g;->f()Lo/a;

    move-result-object v2

    invoke-virtual {v2}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v3

    invoke-interface {v3}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_9c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_bc

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1}, Lo/a$a;->a()Landroidx/camera/core/impl/j0;

    move-result-object v5

    sget-object v6, Landroidx/camera/core/impl/H$b;->ALWAYS_OVERRIDE:Landroidx/camera/core/impl/H$b;

    invoke-virtual {v2}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v7

    invoke-interface {v7, v4}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object v7

    check-cast v5, Landroidx/camera/core/impl/k0;

    invoke-virtual {v5, v4, v6, v7}, Landroidx/camera/core/impl/k0;->G(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;Ljava/lang/Object;)V

    goto :goto_9c

    :cond_bc
    invoke-virtual {v1}, Lo/a$a;->b()Lo/a;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/u0$b;->o(Landroidx/camera/core/impl/H;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->m:Lt/g;

    invoke-virtual {v0}, Lt/g;->f()Lo/a;

    move-result-object v0

    invoke-virtual {v0}, Lt/j;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object v0

    sget-object v1, Lo/a;->D:Landroidx/camera/core/impl/H$a;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_e1

    instance-of v1, v0, Ljava/lang/Integer;

    if-eqz v1, :cond_e1

    iget-object v1, p0, Landroidx/camera/camera2/internal/t;->g:Landroidx/camera/core/impl/u0$b;

    const-string v2, "Camera2CameraControl"

    invoke-virtual {v1, v0, v2}, Landroidx/camera/core/impl/u0$b;->j(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_e1
    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->g:Landroidx/camera/core/impl/u0$b;

    iget-wide v1, p0, Landroidx/camera/camera2/internal/t;->w:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "CameraControlSessionUpdateId"

    invoke-virtual {v0, v1, v2}, Landroidx/camera/core/impl/u0$b;->j(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->g:Landroidx/camera/core/impl/u0$b;

    invoke-virtual {v0}, Landroidx/camera/core/impl/u0$b;->k()Landroidx/camera/core/impl/u0;

    move-result-object v0

    return-object v0
.end method

.method final x(I)I
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_AE_AVAILABLE_MODES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    const/4 v1, 0x0

    if-nez v0, :cond_e

    return v1

    :cond_e
    invoke-static {p1, v0}, Landroidx/camera/camera2/internal/t;->D(I[I)Z

    move-result v2

    if-eqz v2, :cond_15

    return p1

    :cond_15
    const/4 p1, 0x1

    invoke-static {p1, v0}, Landroidx/camera/camera2/internal/t;->D(I[I)Z

    move-result v0

    if-eqz v0, :cond_1d

    return p1

    :cond_1d
    return v1
.end method

.method final y(I)I
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->e:Lp/E;

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_AF_AVAILABLE_MODES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    const/4 v1, 0x0

    if-nez v0, :cond_e

    return v1

    :cond_e
    invoke-static {p1, v0}, Landroidx/camera/camera2/internal/t;->D(I[I)Z

    move-result v2

    if-eqz v2, :cond_15

    return p1

    :cond_15
    const/4 p1, 0x4

    invoke-static {p1, v0}, Landroidx/camera/camera2/internal/t;->D(I[I)Z

    move-result v2

    if-eqz v2, :cond_1d

    return p1

    :cond_1d
    const/4 p1, 0x1

    invoke-static {p1, v0}, Landroidx/camera/camera2/internal/t;->D(I[I)Z

    move-result v0

    if-eqz v0, :cond_25

    return p1

    :cond_25
    return v1
.end method

.method public final z()Landroidx/camera/camera2/internal/j1;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/t;->j:Landroidx/camera/camera2/internal/j1;

    return-object v0
.end method
