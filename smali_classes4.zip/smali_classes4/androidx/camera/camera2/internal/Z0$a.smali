.class final Landroidx/camera/camera2/internal/Z0$a;
.super Ljava/lang/Object;
.source "SynchronizedCaptureSessionBaseImpl.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/camera2/internal/Z0;->a(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/Z0;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/Z0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/Z0$a;->a:Landroidx/camera/camera2/internal/Z0;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 3

    iget-object p1, p0, Landroidx/camera/camera2/internal/Z0$a;->a:Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/Z0;->v()V

    iget-object v0, p1, Landroidx/camera/camera2/internal/Z0;->b:Landroidx/camera/camera2/internal/v0;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/v0;->f(Landroidx/camera/camera2/internal/U0;)V

    return-void
.end method

.method public final bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/Void;

    return-void
.end method
