.class final Landroidx/camera/camera2/internal/k1;
.super Ljava/lang/Object;
.source "ZoomControl.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/k1$b;
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/camera2/internal/t;

.field private final b:Ljava/util/concurrent/Executor;

.field private final c:Landroidx/camera/camera2/internal/l1;

.field private final d:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "Landroidx/camera/core/r1;",
            ">;"
        }
    .end annotation
.end field

.field final e:Landroidx/camera/camera2/internal/k1$b;

.field private f:Z

.field private g:Landroidx/camera/camera2/internal/t$c;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/t;Lp/E;Ljava/util/concurrent/Executor;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/camera2/internal/k1;->f:Z

    new-instance v0, Landroidx/camera/camera2/internal/k1$a;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/k1$a;-><init>(Landroidx/camera/camera2/internal/k1;)V

    iput-object p1, p0, Landroidx/camera/camera2/internal/k1;->a:Landroidx/camera/camera2/internal/t;

    iput-object p3, p0, Landroidx/camera/camera2/internal/k1;->b:Ljava/util/concurrent/Executor;

    invoke-static {p2}, Landroidx/camera/camera2/internal/k1;->a(Lp/E;)Landroidx/camera/camera2/internal/k1$b;

    move-result-object p2

    iput-object p2, p0, Landroidx/camera/camera2/internal/k1;->e:Landroidx/camera/camera2/internal/k1$b;

    new-instance p3, Landroidx/camera/camera2/internal/l1;

    invoke-interface {p2}, Landroidx/camera/camera2/internal/k1$b;->d()F

    move-result v1

    invoke-interface {p2}, Landroidx/camera/camera2/internal/k1$b;->b()F

    move-result p2

    invoke-direct {p3, v1, p2}, Landroidx/camera/camera2/internal/l1;-><init>(FF)V

    iput-object p3, p0, Landroidx/camera/camera2/internal/k1;->c:Landroidx/camera/camera2/internal/l1;

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-virtual {p3, p2}, Landroidx/camera/camera2/internal/l1;->e(F)V

    new-instance p2, Landroidx/lifecycle/I;

    invoke-static {p3}, Lw/e;->e(Landroidx/camera/core/r1;)Landroidx/camera/core/r1;

    move-result-object p3

    invoke-direct {p2, p3}, Landroidx/lifecycle/I;-><init>(Ljava/lang/Object;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/k1;->d:Landroidx/lifecycle/I;

    invoke-virtual {p1, v0}, Landroidx/camera/camera2/internal/t;->k(Landroidx/camera/camera2/internal/t$c;)V

    return-void
.end method

.method private static a(Lp/E;)Landroidx/camera/camera2/internal/k1$b;
    .registers 4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_22

    :try_start_6
    invoke-static {}, Landroidx/camera/camera2/internal/a;->a()Landroid/hardware/camera2/CameraCharacteristics$Key;

    move-result-object v0

    invoke-virtual {p0, v0}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Range;
    :try_end_10
    .catch Ljava/lang/AssertionError; {:try_start_6 .. :try_end_10} :catch_11

    goto :goto_1a

    :catch_11
    move-exception v0

    const-string v1, "ZoomControl"

    const-string v2, "AssertionError, fail to get camera characteristic."

    invoke-static {v1, v2, v0}, Landroidx/camera/core/A0;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v0, 0x0

    :goto_1a
    if-eqz v0, :cond_22

    new-instance v0, Landroidx/camera/camera2/internal/c;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/c;-><init>(Lp/E;)V

    return-object v0

    :cond_22
    new-instance v0, Landroidx/camera/camera2/internal/w0;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/w0;-><init>(Lp/E;)V

    return-object v0
.end method

.method static b(Lp/E;)Landroidx/camera/core/r1;
    .registers 3

    invoke-static {p0}, Landroidx/camera/camera2/internal/k1;->a(Lp/E;)Landroidx/camera/camera2/internal/k1$b;

    move-result-object p0

    new-instance v0, Landroidx/camera/camera2/internal/l1;

    invoke-interface {p0}, Landroidx/camera/camera2/internal/k1$b;->d()F

    move-result v1

    invoke-interface {p0}, Landroidx/camera/camera2/internal/k1$b;->b()F

    move-result p0

    invoke-direct {v0, v1, p0}, Landroidx/camera/camera2/internal/l1;-><init>(FF)V

    const/high16 p0, 0x3f800000    # 1.0f

    invoke-virtual {v0, p0}, Landroidx/camera/camera2/internal/l1;->e(F)V

    invoke-static {v0}, Lw/e;->e(Landroidx/camera/core/r1;)Landroidx/camera/core/r1;

    move-result-object p0

    return-object p0
.end method

.method private e(Landroidx/camera/core/r1;)V
    .registers 5

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/camera2/internal/k1;->d:Landroidx/lifecycle/I;

    if-ne v0, v1, :cond_10

    invoke-virtual {v2, p1}, Landroidx/lifecycle/I;->setValue(Ljava/lang/Object;)V

    goto :goto_13

    :cond_10
    invoke-virtual {v2, p1}, Landroidx/lifecycle/I;->postValue(Ljava/lang/Object;)V

    :goto_13
    return-void
.end method


# virtual methods
.method final c()Landroidx/lifecycle/I;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/k1;->d:Landroidx/lifecycle/I;

    return-object v0
.end method

.method final d(Z)V
    .registers 4

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/k1;->f:Z

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Landroidx/camera/camera2/internal/k1;->f:Z

    if-nez p1, :cond_2b

    iget-object p1, p0, Landroidx/camera/camera2/internal/k1;->c:Landroidx/camera/camera2/internal/l1;

    monitor-enter p1

    :try_start_c
    iget-object v0, p0, Landroidx/camera/camera2/internal/k1;->c:Landroidx/camera/camera2/internal/l1;

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/l1;->e(F)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/k1;->c:Landroidx/camera/camera2/internal/l1;

    invoke-static {v0}, Lw/e;->e(Landroidx/camera/core/r1;)Landroidx/camera/core/r1;

    move-result-object v0

    monitor-exit p1
    :try_end_1a
    .catchall {:try_start_c .. :try_end_1a} :catchall_28

    invoke-direct {p0, v0}, Landroidx/camera/camera2/internal/k1;->e(Landroidx/camera/core/r1;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/k1;->e:Landroidx/camera/camera2/internal/k1$b;

    invoke-interface {p1}, Landroidx/camera/camera2/internal/k1$b;->c()V

    iget-object p1, p0, Landroidx/camera/camera2/internal/k1;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/t;->L()J

    goto :goto_2b

    :catchall_28
    move-exception v0

    :try_start_29
    monitor-exit p1
    :try_end_2a
    .catchall {:try_start_29 .. :try_end_2a} :catchall_28

    throw v0

    :cond_2b
    :goto_2b
    return-void
.end method
