.class public final synthetic Landroidx/camera/camera2/internal/w;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/H;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Landroidx/camera/core/impl/u0;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/H;Ljava/lang/String;Landroidx/camera/core/impl/u0;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/w;->a:Landroidx/camera/camera2/internal/H;

    iput-object p2, p0, Landroidx/camera/camera2/internal/w;->b:Ljava/lang/String;

    iput-object p3, p0, Landroidx/camera/camera2/internal/w;->c:Landroidx/camera/core/impl/u0;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/w;->b:Ljava/lang/String;

    iget-object v1, p0, Landroidx/camera/camera2/internal/w;->c:Landroidx/camera/core/impl/u0;

    iget-object v2, p0, Landroidx/camera/camera2/internal/w;->a:Landroidx/camera/camera2/internal/H;

    invoke-static {v2, v0, v1}, Landroidx/camera/camera2/internal/H;->n(Landroidx/camera/camera2/internal/H;Ljava/lang/String;Landroidx/camera/core/impl/u0;)V

    return-void
.end method
