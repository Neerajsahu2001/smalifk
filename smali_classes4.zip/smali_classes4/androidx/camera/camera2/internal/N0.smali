.class final Landroidx/camera/camera2/internal/n0;
.super Landroidx/camera/core/impl/g;
.source "CaptureCallbackContainer.java"


# instance fields
.field private final a:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;


# direct methods
.method private constructor <init>(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)V
    .registers 3

    invoke-direct {p0}, Landroidx/camera/core/impl/g;-><init>()V

    if-eqz p1, :cond_8

    iput-object p1, p0, Landroidx/camera/camera2/internal/n0;->a:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    return-void

    :cond_8
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "captureCallback is null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method static d(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)Landroidx/camera/camera2/internal/n0;
    .registers 2

    new-instance v0, Landroidx/camera/camera2/internal/n0;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/n0;-><init>(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)V

    return-object v0
.end method


# virtual methods
.method final e()Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/n0;->a:Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    return-object v0
.end method
