.class interface abstract Landroidx/camera/camera2/internal/t0;
.super Ljava/lang/Object;
.source "CaptureSessionInterface.java"


# virtual methods
.method public abstract a(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/D;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract b()V
.end method

.method public abstract c()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/D;",
            ">;"
        }
    .end annotation
.end method

.method public abstract close()V
.end method

.method public abstract d()Landroidx/camera/core/impl/u0;
.end method

.method public abstract e(Landroidx/camera/core/impl/u0;)V
.end method

.method public abstract f(Landroidx/camera/core/impl/u0;Landroid/hardware/camera2/CameraDevice;Landroidx/camera/camera2/internal/e1;)Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/u0;",
            "Landroid/hardware/camera2/CameraDevice;",
            "Landroidx/camera/camera2/internal/e1;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end method

.method public abstract release()Lcom/google/common/util/concurrent/o;
.end method
