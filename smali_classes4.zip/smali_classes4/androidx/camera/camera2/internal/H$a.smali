.class final Landroidx/camera/camera2/internal/H$a;
.super Ljava/lang/Object;
.source "Camera2CameraImpl.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/camera2/internal/H;->F()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/H;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/H;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 6

    instance-of v0, p1, Landroidx/camera/core/impl/K$a;

    if-eqz v0, :cond_18

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    check-cast p1, Landroidx/camera/core/impl/K$a;

    invoke-virtual {p1}, Landroidx/camera/core/impl/K$a;->a()Landroidx/camera/core/impl/K;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/H;->y(Landroidx/camera/core/impl/K;)Landroidx/camera/core/impl/u0;

    move-result-object p1

    if-eqz p1, :cond_17

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/H;->G(Landroidx/camera/core/impl/u0;)V

    :cond_17
    return-void

    :cond_18
    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    if-eqz v0, :cond_24

    iget-object p1, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    const-string v0, "Unable to configure camera cancelled"

    invoke-virtual {p1, v0}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    return-void

    :cond_24
    iget-object v0, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->e:Landroidx/camera/camera2/internal/H$e;

    sget-object v1, Landroidx/camera/camera2/internal/H$e;->OPENED:Landroidx/camera/camera2/internal/H$e;

    if-ne v0, v1, :cond_37

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    const/4 v2, 0x4

    invoke-static {p1, v2}, Landroidx/camera/core/t$a;->b(Ljava/lang/Throwable;I)Landroidx/camera/core/t$a;

    move-result-object v2

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2, v3}, Landroidx/camera/camera2/internal/H;->L(Landroidx/camera/camera2/internal/H$e;Landroidx/camera/core/t$a;Z)V

    :cond_37
    instance-of v0, p1, Landroid/hardware/camera2/CameraAccessException;

    if-eqz v0, :cond_53

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to configure camera due to "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/H;->w(Ljava/lang/String;)V

    goto :goto_77

    :cond_53
    instance-of p1, p1, Ljava/util/concurrent/TimeoutException;

    if-eqz p1, :cond_77

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Unable to configure camera "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$a;->a:Landroidx/camera/camera2/internal/H;

    iget-object v0, v0, Landroidx/camera/camera2/internal/H;->j:Landroidx/camera/camera2/internal/K;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/K;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", timeout!"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "Camera2CameraImpl"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_77
    :goto_77
    return-void
.end method

.method public final bridge synthetic onSuccess(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/Void;

    return-void
.end method
