.class final Landroidx/camera/camera2/internal/s1$b;
.super Landroid/hardware/camera2/CameraCaptureSession$StateCallback;
.source "ZslControlImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/camera2/internal/s1;->a(Landroid/util/Size;Landroidx/camera/core/impl/u0$b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/s1;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/s1;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/camera2/internal/s1$b;->a:Landroidx/camera/camera2/internal/s1;

    invoke-direct {p0}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onConfigureFailed(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 2

    return-void
.end method

.method public final onConfigured(Landroid/hardware/camera2/CameraCaptureSession;)V
    .registers 3

    invoke-static {p1}, Landroidx/camera/camera2/internal/t1;->a(Landroid/hardware/camera2/CameraCaptureSession;)Landroid/view/Surface;

    move-result-object p1

    if-eqz p1, :cond_f

    const/4 v0, 0x1

    invoke-static {v0, p1}, Lx/a;->c(ILandroid/view/Surface;)Landroid/media/ImageWriter;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/s1$b;->a:Landroidx/camera/camera2/internal/s1;

    iput-object p1, v0, Landroidx/camera/camera2/internal/s1;->h:Landroid/media/ImageWriter;

    :cond_f
    return-void
.end method
