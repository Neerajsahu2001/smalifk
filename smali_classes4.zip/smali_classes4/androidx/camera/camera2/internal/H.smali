.class public final synthetic Landroidx/camera/camera2/internal/h;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/camera2/internal/t$c;


# instance fields
.field public final synthetic a:J

.field public final synthetic b:Landroidx/concurrent/futures/b$a;


# direct methods
.method public synthetic constructor <init>(JLandroidx/concurrent/futures/b$a;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Landroidx/camera/camera2/internal/h;->a:J

    iput-object p3, p0, Landroidx/camera/camera2/internal/h;->b:Landroidx/concurrent/futures/b$a;

    return-void
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/TotalCaptureResult;)Z
    .registers 4

    iget-wide v0, p0, Landroidx/camera/camera2/internal/h;->a:J

    invoke-static {p1, v0, v1}, Landroidx/camera/camera2/internal/t;->E(Landroid/hardware/camera2/TotalCaptureResult;J)Z

    move-result p1

    if-eqz p1, :cond_10

    const/4 p1, 0x0

    iget-object v0, p0, Landroidx/camera/camera2/internal/h;->b:Landroidx/concurrent/futures/b$a;

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    const/4 p1, 0x1

    goto :goto_11

    :cond_10
    const/4 p1, 0x0

    :goto_11
    return p1
.end method
