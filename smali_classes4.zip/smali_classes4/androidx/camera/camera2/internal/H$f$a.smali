.class final Landroidx/camera/camera2/internal/H$f$a;
.super Ljava/lang/Object;
.source "Camera2CameraImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/H$f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field private a:J

.field final synthetic b:Landroidx/camera/camera2/internal/H$f;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/H$f;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/H$f$a;->b:Landroidx/camera/camera2/internal/H$f;

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    return-void
.end method


# virtual methods
.method final a()Z
    .registers 8

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    const-wide/16 v4, -0x1

    cmp-long v6, v2, v4

    if-nez v6, :cond_e

    iput-wide v0, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    :cond_e
    iget-wide v2, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    sub-long/2addr v0, v2

    iget-object v2, p0, Landroidx/camera/camera2/internal/H$f$a;->b:Landroidx/camera/camera2/internal/H$f;

    invoke-virtual {v2}, Landroidx/camera/camera2/internal/H$f;->d()Z

    move-result v2

    if-nez v2, :cond_1c

    const/16 v2, 0x2710

    goto :goto_1f

    :cond_1c
    const v2, 0x1b7740

    :goto_1f
    int-to-long v2, v2

    cmp-long v6, v0, v2

    if-ltz v6, :cond_28

    iput-wide v4, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    const/4 v0, 0x0

    return v0

    :cond_28
    const/4 v0, 0x1

    return v0
.end method

.method final b()I
    .registers 8

    iget-object v0, p0, Landroidx/camera/camera2/internal/H$f$a;->b:Landroidx/camera/camera2/internal/H$f;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/H$f;->d()Z

    move-result v0

    if-nez v0, :cond_b

    const/16 v0, 0x2bc

    return v0

    :cond_b
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    const-wide/16 v4, -0x1

    cmp-long v6, v2, v4

    if-nez v6, :cond_19

    iput-wide v0, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    :cond_19
    iget-wide v2, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    sub-long/2addr v0, v2

    const-wide/32 v2, 0x1d4c0

    cmp-long v4, v0, v2

    if-gtz v4, :cond_26

    const/16 v0, 0x3e8

    return v0

    :cond_26
    const-wide/32 v2, 0x493e0

    cmp-long v4, v0, v2

    if-gtz v4, :cond_30

    const/16 v0, 0x7d0

    return v0

    :cond_30
    const/16 v0, 0xfa0

    return v0
.end method

.method final c()V
    .registers 3

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Landroidx/camera/camera2/internal/H$f$a;->a:J

    return-void
.end method
