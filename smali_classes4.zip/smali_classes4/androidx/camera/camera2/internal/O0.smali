.class final Landroidx/camera/camera2/internal/o0;
.super Ljava/lang/Object;
.source "CaptureCallbackConverter.java"


# direct methods
.method static a(Landroidx/camera/core/impl/g;Ljava/util/ArrayList;)V
    .registers 3

    instance-of v0, p0, Landroidx/camera/core/impl/h;

    if-nez v0, :cond_1b

    instance-of v0, p0, Landroidx/camera/camera2/internal/n0;

    if-eqz v0, :cond_12

    check-cast p0, Landroidx/camera/camera2/internal/n0;

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/n0;->e()Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1a

    :cond_12
    new-instance v0, Landroidx/camera/camera2/internal/m0;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/m0;-><init>(Landroidx/camera/core/impl/g;)V

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1a
    return-void

    :cond_1b
    check-cast p0, Landroidx/camera/core/impl/h;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    throw p0
.end method
