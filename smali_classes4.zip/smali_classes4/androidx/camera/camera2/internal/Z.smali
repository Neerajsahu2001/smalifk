.class public final synthetic Landroidx/camera/camera2/internal/z;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/H;

.field public final synthetic b:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/H;Ljava/util/ArrayList;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/z;->a:Landroidx/camera/camera2/internal/H;

    iput-object p2, p0, Landroidx/camera/camera2/internal/z;->b:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/z;->a:Landroidx/camera/camera2/internal/H;

    iget-object v1, p0, Landroidx/camera/camera2/internal/z;->b:Ljava/util/List;

    invoke-static {v0, v1}, Landroidx/camera/camera2/internal/H;->o(Landroidx/camera/camera2/internal/H;Ljava/util/List;)V

    return-void
.end method
