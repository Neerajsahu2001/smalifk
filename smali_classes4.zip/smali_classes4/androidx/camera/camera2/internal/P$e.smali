.class final Landroidx/camera/camera2/internal/P$e;
.super Ljava/lang/Object;
.source "Camera2CapturePipeline.java"

# interfaces
.implements Landroidx/camera/camera2/internal/t$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/P;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/P$e$a;
    }
.end annotation


# instance fields
.field private a:Landroidx/concurrent/futures/b$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/concurrent/futures/b$a<",
            "Landroid/hardware/camera2/TotalCaptureResult;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Landroid/hardware/camera2/TotalCaptureResult;",
            ">;"
        }
    .end annotation
.end field

.field private final c:J

.field private final d:Landroidx/camera/camera2/internal/P$e$a;

.field private volatile e:Ljava/lang/Long;


# direct methods
.method constructor <init>(JLandroidx/camera/camera2/internal/W;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroidx/camera/camera2/internal/Z;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/Z;-><init>(Landroidx/camera/camera2/internal/P$e;)V

    invoke-static {v0}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/camera2/internal/P$e;->b:Lcom/google/common/util/concurrent/o;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/camera2/internal/P$e;->e:Ljava/lang/Long;

    iput-wide p1, p0, Landroidx/camera/camera2/internal/P$e;->c:J

    iput-object p3, p0, Landroidx/camera/camera2/internal/P$e;->d:Landroidx/camera/camera2/internal/P$e$a;

    return-void
.end method

.method public static synthetic b(Landroidx/camera/camera2/internal/P$e;Landroidx/concurrent/futures/b$a;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/camera2/internal/P$e;->a:Landroidx/concurrent/futures/b$a;

    return-void
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/TotalCaptureResult;)Z
    .registers 11

    sget-object v0, Landroid/hardware/camera2/CaptureResult;->SENSOR_TIMESTAMP:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {p1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    if-eqz v0, :cond_10

    iget-object v1, p0, Landroidx/camera/camera2/internal/P$e;->e:Ljava/lang/Long;

    if-nez v1, :cond_10

    iput-object v0, p0, Landroidx/camera/camera2/internal/P$e;->e:Ljava/lang/Long;

    :cond_10
    iget-object v1, p0, Landroidx/camera/camera2/internal/P$e;->e:Ljava/lang/Long;

    iget-wide v2, p0, Landroidx/camera/camera2/internal/P$e;->c:J

    const-wide/16 v4, 0x0

    const-string v6, "Camera2CapturePipeline"

    const/4 v7, 0x1

    cmp-long v8, v4, v2

    if-eqz v8, :cond_50

    if-eqz v1, :cond_50

    if-eqz v0, :cond_50

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    sub-long/2addr v2, v4

    iget-wide v4, p0, Landroidx/camera/camera2/internal/P$e;->c:J

    cmp-long v8, v2, v4

    if-lez v8, :cond_50

    iget-object p1, p0, Landroidx/camera/camera2/internal/P$e;->a:Landroidx/concurrent/futures/b$a;

    const/4 v2, 0x0

    invoke-virtual {p1, v2}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v2, "Wait for capture result timeout, current:"

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " first: "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v6, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    return v7

    :cond_50
    iget-object v0, p0, Landroidx/camera/camera2/internal/P$e;->d:Landroidx/camera/camera2/internal/P$e$a;

    if-eqz v0, :cond_fe

    check-cast v0, Landroidx/camera/camera2/internal/W;

    iget-object v0, v0, Landroidx/camera/camera2/internal/W;->a:Landroidx/camera/camera2/internal/P$c;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroidx/camera/camera2/internal/g;

    invoke-static {}, Landroidx/camera/core/impl/B0;->a()Landroidx/camera/core/impl/B0;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Landroidx/camera/camera2/internal/g;-><init>(Landroidx/camera/core/impl/B0;Landroid/hardware/camera2/CaptureResult;)V

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->f()Landroidx/camera/core/impl/k;

    move-result-object v1

    sget-object v2, Landroidx/camera/core/impl/k;->OFF:Landroidx/camera/core/impl/k;

    const/4 v3, 0x0

    if-eq v1, v2, :cond_98

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->f()Landroidx/camera/core/impl/k;

    move-result-object v1

    sget-object v2, Landroidx/camera/core/impl/k;->UNKNOWN:Landroidx/camera/core/impl/k;

    if-eq v1, v2, :cond_98

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->g()Landroidx/camera/core/impl/l;

    move-result-object v1

    sget-object v2, Landroidx/camera/core/impl/l;->PASSIVE_FOCUSED:Landroidx/camera/core/impl/l;

    if-eq v1, v2, :cond_98

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->g()Landroidx/camera/core/impl/l;

    move-result-object v1

    sget-object v2, Landroidx/camera/core/impl/l;->PASSIVE_NOT_FOCUSED:Landroidx/camera/core/impl/l;

    if-eq v1, v2, :cond_98

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->g()Landroidx/camera/core/impl/l;

    move-result-object v1

    sget-object v2, Landroidx/camera/core/impl/l;->LOCKED_FOCUSED:Landroidx/camera/core/impl/l;

    if-eq v1, v2, :cond_98

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->g()Landroidx/camera/core/impl/l;

    move-result-object v1

    sget-object v2, Landroidx/camera/core/impl/l;->LOCKED_NOT_FOCUSED:Landroidx/camera/core/impl/l;

    if-ne v1, v2, :cond_96

    goto :goto_98

    :cond_96
    const/4 v1, 0x0

    goto :goto_99

    :cond_98
    :goto_98
    const/4 v1, 0x1

    :goto_99
    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->e()Landroidx/camera/core/impl/j;

    move-result-object v2

    sget-object v4, Landroidx/camera/core/impl/j;->CONVERGED:Landroidx/camera/core/impl/j;

    if-eq v2, v4, :cond_b4

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->e()Landroidx/camera/core/impl/j;

    move-result-object v2

    sget-object v4, Landroidx/camera/core/impl/j;->FLASH_REQUIRED:Landroidx/camera/core/impl/j;

    if-eq v2, v4, :cond_b4

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->e()Landroidx/camera/core/impl/j;

    move-result-object v2

    sget-object v4, Landroidx/camera/core/impl/j;->UNKNOWN:Landroidx/camera/core/impl/j;

    if-ne v2, v4, :cond_b2

    goto :goto_b4

    :cond_b2
    const/4 v2, 0x0

    goto :goto_b5

    :cond_b4
    :goto_b4
    const/4 v2, 0x1

    :goto_b5
    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->h()Landroidx/camera/core/impl/m;

    move-result-object v4

    sget-object v5, Landroidx/camera/core/impl/m;->CONVERGED:Landroidx/camera/core/impl/m;

    if-eq v4, v5, :cond_c8

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->h()Landroidx/camera/core/impl/m;

    move-result-object v4

    sget-object v5, Landroidx/camera/core/impl/m;->UNKNOWN:Landroidx/camera/core/impl/m;

    if-ne v4, v5, :cond_c6

    goto :goto_c8

    :cond_c6
    const/4 v4, 0x0

    goto :goto_c9

    :cond_c8
    :goto_c8
    const/4 v4, 0x1

    :goto_c9
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "checkCaptureResult, AE="

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->e()Landroidx/camera/core/impl/j;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v8, " AF ="

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->g()Landroidx/camera/core/impl/l;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v8, " AWB="

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/g;->h()Landroidx/camera/core/impl/m;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v6, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v1, :cond_fd

    if-eqz v2, :cond_fd

    if-eqz v4, :cond_fd

    goto :goto_fe

    :cond_fd
    return v3

    :cond_fe
    :goto_fe
    iget-object v0, p0, Landroidx/camera/camera2/internal/P$e;->a:Landroidx/concurrent/futures/b$a;

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    return v7
.end method

.method public final c()Lcom/google/common/util/concurrent/o;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Landroid/hardware/camera2/TotalCaptureResult;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/P$e;->b:Lcom/google/common/util/concurrent/o;

    return-object v0
.end method
