.class public final synthetic Landroidx/camera/camera2/internal/r1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/X0;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/X0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/r1;->a:Landroidx/camera/core/X0;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/r1;->a:Landroidx/camera/core/X0;

    invoke-virtual {v0}, Landroidx/camera/core/X0;->i()V

    return-void
.end method
