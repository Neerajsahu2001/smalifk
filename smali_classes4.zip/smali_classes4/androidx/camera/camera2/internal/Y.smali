.class public final synthetic Landroidx/camera/camera2/internal/y;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/H;

.field public final synthetic b:Landroidx/camera/camera2/internal/s0;

.field public final synthetic c:Landroidx/camera/core/impl/K;

.field public final synthetic d:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/H;Landroidx/camera/camera2/internal/s0;Landroidx/camera/core/impl/c0;Ljava/lang/Runnable;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/y;->a:Landroidx/camera/camera2/internal/H;

    iput-object p2, p0, Landroidx/camera/camera2/internal/y;->b:Landroidx/camera/camera2/internal/s0;

    iput-object p3, p0, Landroidx/camera/camera2/internal/y;->c:Landroidx/camera/core/impl/K;

    iput-object p4, p0, Landroidx/camera/camera2/internal/y;->d:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/y;->a:Landroidx/camera/camera2/internal/H;

    iget-object v1, v0, Landroidx/camera/camera2/internal/H;->q:Ljava/util/HashSet;

    iget-object v2, p0, Landroidx/camera/camera2/internal/y;->b:Landroidx/camera/camera2/internal/s0;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0, v2}, Landroidx/camera/camera2/internal/H;->H(Landroidx/camera/camera2/internal/t0;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    iget-object v1, p0, Landroidx/camera/camera2/internal/y;->c:Landroidx/camera/core/impl/K;

    invoke-virtual {v1}, Landroidx/camera/core/impl/K;->c()V

    invoke-virtual {v1}, Landroidx/camera/core/impl/K;->i()Lcom/google/common/util/concurrent/o;

    move-result-object v1

    const/4 v2, 0x2

    new-array v2, v2, [Lcom/google/common/util/concurrent/o;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v0, 0x1

    aput-object v1, v2, v0

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-static {v0}, Lv/f;->l(Ljava/util/List;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/camera2/internal/y;->d:Ljava/lang/Runnable;

    invoke-interface {v0, v2, v1}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method
