.class final Landroidx/camera/camera2/internal/J0$a;
.super Landroidx/camera/core/impl/g;
.source "FocusMeteringControl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/camera2/internal/J0;->j(Landroidx/concurrent/futures/b$a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/concurrent/futures/b$a;


# direct methods
.method constructor <init>(Landroidx/concurrent/futures/b$a;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/camera2/internal/J0$a;->a:Landroidx/concurrent/futures/b$a;

    invoke-direct {p0}, Landroidx/camera/core/impl/g;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/J0$a;->a:Landroidx/concurrent/futures/b$a;

    if-eqz v0, :cond_e

    new-instance v1, Landroidx/camera/core/n$a;

    const-string v2, "Camera is closed"

    invoke-direct {v1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    :cond_e
    return-void
.end method

.method public final b(Landroidx/camera/core/impl/o;)V
    .registers 3

    iget-object p1, p0, Landroidx/camera/camera2/internal/J0$a;->a:Landroidx/concurrent/futures/b$a;

    if-eqz p1, :cond_8

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    :cond_8
    return-void
.end method

.method public final c(Landroidx/camera/core/impl/i;)V
    .registers 3

    iget-object p1, p0, Landroidx/camera/camera2/internal/J0$a;->a:Landroidx/concurrent/futures/b$a;

    if-eqz p1, :cond_c

    new-instance v0, Landroidx/camera/core/impl/t$b;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    :cond_c
    return-void
.end method
