.class final Landroidx/camera/camera2/internal/s0$e;
.super Landroidx/camera/camera2/internal/U0$a;
.source "CaptureSession.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/s0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "e"
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/camera2/internal/s0;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/s0;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    invoke-direct {p0}, Landroidx/camera/camera2/internal/U0$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final n(Landroidx/camera/camera2/internal/U0;)V
    .registers 6

    const-string p1, "CameraCaptureSession.onConfigureFailed() "

    const-string v0, "onConfigureFailed() should not be possible in state: "

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_9
    sget-object v2, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v3, v3, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v2, v2, v3

    packed-switch v2, :pswitch_data_58

    goto :goto_28

    :pswitch_19
    const-string v0, "CaptureSession"

    const-string v2, "ConfigureFailed callback after change to RELEASED state"

    invoke-static {v0, v2}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_28

    :catchall_21
    move-exception p1

    goto :goto_55

    :pswitch_23
    iget-object v0, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/s0;->i()V

    :goto_28
    const-string v0, "CaptureSession"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object p1, p1, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v1

    return-void

    :pswitch_3f
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v0, v0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_55
    monitor-exit v1
    :try_end_56
    .catchall {:try_start_9 .. :try_end_56} :catchall_21

    throw p1

    nop

    :pswitch_data_58
    .packed-switch 0x1
        :pswitch_3f
        :pswitch_3f
        :pswitch_3f
        :pswitch_23
        :pswitch_3f
        :pswitch_23
        :pswitch_23
        :pswitch_19
    .end packed-switch
.end method

.method public final o(Landroidx/camera/camera2/internal/U0;)V
    .registers 7

    const-string v0, "CameraCaptureSession.onConfigured() mState="

    const-string v1, "onConfigured() should not be possible in state: "

    iget-object v2, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v2, v2, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v2

    :try_start_9
    sget-object v3, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v4, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v4, v4, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aget v3, v3, v4

    packed-switch v3, :pswitch_data_8c

    goto :goto_5c

    :pswitch_19
    invoke-interface {p1}, Landroidx/camera/camera2/internal/U0;->close()V

    goto :goto_5c

    :catchall_1d
    move-exception p1

    goto :goto_89

    :pswitch_1f
    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iput-object p1, v1, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    goto :goto_5c

    :pswitch_24
    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    sget-object v3, Landroidx/camera/camera2/internal/s0$d;->OPENED:Landroidx/camera/camera2/internal/s0$d;

    iput-object v3, v1, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    iput-object p1, v1, Landroidx/camera/camera2/internal/s0;->f:Landroidx/camera/camera2/internal/U0;

    iget-object p1, v1, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    if-eqz p1, :cond_49

    iget-object p1, v1, Landroidx/camera/camera2/internal/s0;->i:Lo/c;

    invoke-virtual {p1}, Lo/c;->d()Lo/c$a;

    move-result-object p1

    invoke-virtual {p1}, Lo/c$a;->b()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_49

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/s0;->n(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroidx/camera/camera2/internal/s0;->j(Ljava/util/ArrayList;)V

    :cond_49
    const-string p1, "CaptureSession"

    const-string v1, "Attempting to send capture request onConfigured"

    invoke-static {p1, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v1, p1, Landroidx/camera/camera2/internal/s0;->g:Landroidx/camera/core/impl/u0;

    invoke-virtual {p1, v1}, Landroidx/camera/camera2/internal/s0;->l(Landroidx/camera/core/impl/u0;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/s0;->k()V

    :goto_5c
    const-string p1, "CaptureSession"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v0, v0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v2

    return-void

    :pswitch_73
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_89
    monitor-exit v2
    :try_end_8a
    .catchall {:try_start_9 .. :try_end_8a} :catchall_1d

    throw p1

    nop

    :pswitch_data_8c
    .packed-switch 0x1
        :pswitch_73
        :pswitch_73
        :pswitch_73
        :pswitch_24
        :pswitch_73
        :pswitch_1f
        :pswitch_19
        :pswitch_73
    .end packed-switch
.end method

.method public final p(Landroidx/camera/camera2/internal/U0;)V
    .registers 6

    const-string p1, "CameraCaptureSession.onReady() "

    const-string v0, "onReady() should not be possible in state: "

    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_9
    sget-object v2, Landroidx/camera/camera2/internal/s0$c;->a:[I

    iget-object v3, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v3, v3, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v2, v2, v3

    const/4 v3, 0x1

    if-eq v2, v3, :cond_31

    const-string v0, "CaptureSession"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object p1, p1, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v1

    return-void

    :catchall_2f
    move-exception p1

    goto :goto_47

    :cond_31
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v0, v0, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_47
    monitor-exit v1
    :try_end_48
    .catchall {:try_start_9 .. :try_end_48} :catchall_2f

    throw p1
.end method

.method public final q(Landroidx/camera/camera2/internal/U0;)V
    .registers 5

    const-string p1, "onSessionFinished() should not be possible in state: "

    iget-object v0, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v0, v0, Landroidx/camera/camera2/internal/s0;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_7
    iget-object v1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object v1, v1, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    sget-object v2, Landroidx/camera/camera2/internal/s0$d;->UNINITIALIZED:Landroidx/camera/camera2/internal/s0$d;

    if-eq v1, v2, :cond_1f

    const-string p1, "CaptureSession"

    const-string v1, "onSessionFinished()"

    invoke-static {p1, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/s0;->i()V

    monitor-exit v0

    return-void

    :catchall_1d
    move-exception p1

    goto :goto_35

    :cond_1f
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/camera2/internal/s0$e;->a:Landroidx/camera/camera2/internal/s0;

    iget-object p1, p1, Landroidx/camera/camera2/internal/s0;->l:Landroidx/camera/camera2/internal/s0$d;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_35
    monitor-exit v0
    :try_end_36
    .catchall {:try_start_7 .. :try_end_36} :catchall_1d

    throw p1
.end method
