.class public final Landroidx/camera/camera2/internal/v;
.super Ljava/lang/Object;
.source "Camera2CameraFactory.java"

# interfaces
.implements Landroidx/camera/core/impl/v;


# instance fields
.field private final a:Landroidx/camera/core/impl/A;

.field private final b:Landroidx/camera/core/impl/z;

.field private final c:Lp/S;

.field private final d:Ljava/util/ArrayList;

.field private final e:Landroidx/camera/camera2/internal/x0;

.field private final f:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/camera/core/impl/A;Landroidx/camera/core/s;)V
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/z0;
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/v;->f:Ljava/util/HashMap;

    iput-object p2, p0, Landroidx/camera/camera2/internal/v;->a:Landroidx/camera/core/impl/A;

    new-instance v0, Landroidx/camera/core/impl/z;

    invoke-direct {v0}, Landroidx/camera/core/impl/z;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/v;->b:Landroidx/camera/core/impl/z;

    invoke-virtual {p2}, Landroidx/camera/core/impl/A;->c()Landroid/os/Handler;

    move-result-object p2

    invoke-static {p1, p2}, Lp/S;->a(Landroid/content/Context;Landroid/os/Handler;)Lp/S;

    move-result-object p2

    iput-object p2, p0, Landroidx/camera/camera2/internal/v;->c:Lp/S;

    invoke-static {p1}, Landroidx/camera/camera2/internal/x0;->b(Landroid/content/Context;)Landroidx/camera/camera2/internal/x0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/camera2/internal/v;->e:Landroidx/camera/camera2/internal/x0;

    invoke-static {p0, p3}, Landroidx/camera/camera2/internal/k0;->b(Landroidx/camera/camera2/internal/v;Landroidx/camera/core/s;)Ljava/util/ArrayList;

    move-result-object p1

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_30
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_a0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    const-string v0, "0"

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9c

    const-string v0, "1"

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4d

    goto :goto_9c

    :cond_4d
    const-string v0, "robolectric"

    sget-object v1, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_58

    goto :goto_70

    :cond_58
    :try_start_58
    iget-object v0, p0, Landroidx/camera/camera2/internal/v;->c:Lp/S;

    invoke-virtual {v0, p3}, Lp/S;->b(Ljava/lang/String;)Lp/E;

    move-result-object v0

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->REQUEST_AVAILABLE_CAPABILITIES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v1}, Lp/E;->a(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I
    :try_end_66
    .catch Lp/k; {:try_start_58 .. :try_end_66} :catch_90

    if-eqz v0, :cond_77

    array-length v1, v0

    const/4 v2, 0x0

    :goto_6a
    if-ge v2, v1, :cond_77

    aget v3, v0, v2

    if-nez v3, :cond_74

    :goto_70
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_30

    :cond_74
    add-int/lit8 v2, v2, 0x1

    goto :goto_6a

    :cond_77
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Camera "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, " is filtered out because its capabilities do not contain REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE."

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const-string v0, "Camera2CameraFactory"

    invoke-static {v0, p3}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_30

    :catch_90
    move-exception p1

    new-instance p2, Landroidx/camera/core/z0;

    new-instance p3, Landroidx/camera/core/u;

    invoke-direct {p3, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    invoke-direct {p2, p3}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_9c
    :goto_9c
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_30

    :cond_a0
    iput-object p2, p0, Landroidx/camera/camera2/internal/v;->d:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Landroidx/camera/core/impl/x;
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/u;
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/v;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_24

    new-instance v0, Landroidx/camera/camera2/internal/H;

    invoke-virtual {p0, p1}, Landroidx/camera/camera2/internal/v;->d(Ljava/lang/String;)Landroidx/camera/camera2/internal/K;

    move-result-object v4

    iget-object v1, p0, Landroidx/camera/camera2/internal/v;->a:Landroidx/camera/core/impl/A;

    invoke-virtual {v1}, Landroidx/camera/core/impl/A;->b()Ljava/util/concurrent/Executor;

    move-result-object v6

    invoke-virtual {v1}, Landroidx/camera/core/impl/A;->c()Landroid/os/Handler;

    move-result-object v7

    iget-object v2, p0, Landroidx/camera/camera2/internal/v;->c:Lp/S;

    iget-object v5, p0, Landroidx/camera/camera2/internal/v;->b:Landroidx/camera/core/impl/z;

    iget-object v8, p0, Landroidx/camera/camera2/internal/v;->e:Landroidx/camera/camera2/internal/x0;

    move-object v1, v0

    move-object v3, p1

    invoke-direct/range {v1 .. v8}, Landroidx/camera/camera2/internal/H;-><init>(Lp/S;Ljava/lang/String;Landroidx/camera/camera2/internal/K;Landroidx/camera/core/impl/z;Ljava/util/concurrent/Executor;Landroid/os/Handler;Landroidx/camera/camera2/internal/x0;)V

    return-object v0

    :cond_24
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "The given camera id is not on the available camera id list."

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b()Ljava/util/LinkedHashSet;
    .registers 3

    new-instance v0, Ljava/util/LinkedHashSet;

    iget-object v1, p0, Landroidx/camera/camera2/internal/v;->d:Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    return-object v0
.end method

.method public final c()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/v;->c:Lp/S;

    return-object v0
.end method

.method final d(Ljava/lang/String;)Landroidx/camera/camera2/internal/K;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroidx/camera/core/u;
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/v;->f:Ljava/util/HashMap;

    :try_start_2
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/camera2/internal/K;

    if-nez v1, :cond_17

    new-instance v1, Landroidx/camera/camera2/internal/K;

    iget-object v2, p0, Landroidx/camera/camera2/internal/v;->c:Lp/S;

    invoke-direct {v1, p1, v2}, Landroidx/camera/camera2/internal/K;-><init>(Ljava/lang/String;Lp/S;)V

    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_14
    .catch Lp/k; {:try_start_2 .. :try_end_14} :catch_15

    goto :goto_17

    :catch_15
    move-exception p1

    goto :goto_18

    :cond_17
    :goto_17
    return-object v1

    :goto_18
    new-instance v0, Landroidx/camera/core/u;

    invoke-direct {v0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final e()Lp/S;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/v;->c:Lp/S;

    return-object v0
.end method
