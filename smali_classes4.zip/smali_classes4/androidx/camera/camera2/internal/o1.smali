.class public final synthetic Landroidx/camera/camera2/internal/o1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static synthetic a()V
    .registers 1

    new-instance v0, Landroid/hardware/camera2/params/InputConfiguration;

    return-void
.end method

.method public static bridge synthetic b(Landroid/media/ImageWriter;)V
    .registers 1

    invoke-virtual {p0}, Landroid/media/ImageWriter;->close()V

    return-void
.end method
