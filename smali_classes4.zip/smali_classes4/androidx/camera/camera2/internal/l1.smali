.class final Landroidx/camera/camera2/internal/l1;
.super Ljava/lang/Object;
.source "ZoomStateImpl.java"

# interfaces
.implements Landroidx/camera/core/r1;


# instance fields
.field private a:F

.field private final b:F

.field private final c:F

.field private d:F


# direct methods
.method constructor <init>(FF)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroidx/camera/camera2/internal/l1;->b:F

    iput p2, p0, Landroidx/camera/camera2/internal/l1;->c:F

    return-void
.end method


# virtual methods
.method public final a()F
    .registers 2

    iget v0, p0, Landroidx/camera/camera2/internal/l1;->b:F

    return v0
.end method

.method public final b()F
    .registers 2

    iget v0, p0, Landroidx/camera/camera2/internal/l1;->d:F

    return v0
.end method

.method public final c()F
    .registers 2

    iget v0, p0, Landroidx/camera/camera2/internal/l1;->c:F

    return v0
.end method

.method public final d()F
    .registers 2

    iget v0, p0, Landroidx/camera/camera2/internal/l1;->a:F

    return v0
.end method

.method final e(F)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    iget v0, p0, Landroidx/camera/camera2/internal/l1;->c:F

    iget v1, p0, Landroidx/camera/camera2/internal/l1;->b:F

    cmpl-float v2, p1, v1

    if-gtz v2, :cond_2e

    cmpg-float v2, p1, v0

    if-ltz v2, :cond_2e

    iput p1, p0, Landroidx/camera/camera2/internal/l1;->a:F

    const/4 v2, 0x0

    cmpl-float v3, v1, v0

    if-nez v3, :cond_14

    goto :goto_2b

    :cond_14
    const/high16 v3, 0x3f800000    # 1.0f

    cmpl-float v4, p1, v1

    if-nez v4, :cond_1d

    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_2b

    :cond_1d
    cmpl-float v4, p1, v0

    if-nez v4, :cond_22

    goto :goto_2b

    :cond_22
    div-float p1, v3, p1

    div-float v1, v3, v1

    div-float/2addr v3, v0

    sub-float/2addr p1, v3

    sub-float/2addr v1, v3

    div-float v2, p1, v1

    :goto_2b
    iput v2, p0, Landroidx/camera/camera2/internal/l1;->d:F

    return-void

    :cond_2e
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Requested zoomRatio "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string p1, " is not within valid range ["

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string p1, " , "

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string p1, "]"

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
