.class final Landroidx/camera/camera2/internal/d1;
.super Landroidx/camera/camera2/internal/Z0;
.source "SynchronizedCaptureSessionImpl.java"


# instance fields
.field private final o:Ljava/lang/Object;

.field private p:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/K;",
            ">;"
        }
    .end annotation
.end field

.field q:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private final r:Ls/f;

.field private final s:Ls/r;

.field private final t:Ls/e;


# direct methods
.method constructor <init>(Landroid/os/Handler;Landroidx/camera/camera2/internal/v0;Landroidx/camera/core/impl/s0;Landroidx/camera/core/impl/s0;Ljava/util/concurrent/Executor;Ljava/util/concurrent/ScheduledExecutorService;)V
    .registers 7

    invoke-direct {p0, p2, p5, p6, p1}, Landroidx/camera/camera2/internal/Z0;-><init>(Landroidx/camera/camera2/internal/v0;Ljava/util/concurrent/Executor;Ljava/util/concurrent/ScheduledExecutorService;Landroid/os/Handler;)V

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/d1;->o:Ljava/lang/Object;

    new-instance p1, Ls/f;

    invoke-direct {p1, p3, p4}, Ls/f;-><init>(Landroidx/camera/core/impl/s0;Landroidx/camera/core/impl/s0;)V

    iput-object p1, p0, Landroidx/camera/camera2/internal/d1;->r:Ls/f;

    new-instance p1, Ls/r;

    invoke-direct {p1, p3}, Ls/r;-><init>(Landroidx/camera/core/impl/s0;)V

    iput-object p1, p0, Landroidx/camera/camera2/internal/d1;->s:Ls/r;

    new-instance p1, Ls/e;

    invoke-direct {p1, p4}, Ls/e;-><init>(Landroidx/camera/core/impl/s0;)V

    iput-object p1, p0, Landroidx/camera/camera2/internal/d1;->t:Ls/e;

    return-void
.end method

.method public static synthetic w(Landroidx/camera/camera2/internal/d1;)V
    .registers 2

    const-string v0, "Session call super.close()"

    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/d1;->z(Ljava/lang/String;)V

    invoke-super {p0}, Landroidx/camera/camera2/internal/Z0;->close()V

    return-void
.end method

.method public static synthetic x(Landroidx/camera/camera2/internal/d1;Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Landroidx/camera/camera2/internal/Z0;->a(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic y(Landroidx/camera/camera2/internal/d1;Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I
    .registers 3

    invoke-super {p0, p1, p2}, Landroidx/camera/camera2/internal/Z0;->f(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/hardware/camera2/CameraDevice;",
            "Lq/i;",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/K;",
            ">;)",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/d1;->o:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/camera2/internal/d1;->s:Ls/r;

    iget-object v2, p0, Landroidx/camera/camera2/internal/Z0;->b:Landroidx/camera/camera2/internal/v0;

    invoke-virtual {v2}, Landroidx/camera/camera2/internal/v0;->c()Ljava/util/ArrayList;

    move-result-object v2

    new-instance v3, Landroidx/camera/camera2/internal/c1;

    invoke-direct {v3, p0}, Landroidx/camera/camera2/internal/c1;-><init>(Landroidx/camera/camera2/internal/d1;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p2, v3, p3, v2}, Ls/r;->c(Landroid/hardware/camera2/CameraDevice;Lq/i;Landroidx/camera/camera2/internal/c1;Ljava/util/List;Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/camera2/internal/d1;->q:Lcom/google/common/util/concurrent/o;

    invoke-static {p1}, Lv/f;->i(Lcom/google/common/util/concurrent/o;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    monitor-exit v0

    return-object p1

    :catchall_1f
    move-exception p1

    monitor-exit v0
    :try_end_21
    .catchall {:try_start_3 .. :try_end_21} :catchall_1f

    throw p1
.end method

.method public final close()V
    .registers 4

    const-string v0, "Session call close()"

    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/d1;->z(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/d1;->s:Ls/r;

    invoke-virtual {v0}, Ls/r;->b()V

    invoke-virtual {v0}, Ls/r;->a()Lcom/google/common/util/concurrent/o;

    move-result-object v0

    new-instance v1, Landroidx/camera/camera2/internal/b1;

    invoke-direct {v1, p0}, Landroidx/camera/camera2/internal/b1;-><init>(Landroidx/camera/camera2/internal/d1;)V

    iget-object v2, p0, Landroidx/camera/camera2/internal/Z0;->d:Ljava/util/concurrent/Executor;

    invoke-interface {v0, v1, v2}, Lcom/google/common/util/concurrent/o;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public final f(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)I
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/hardware/camera2/CameraAccessException;
        }
    .end annotation

    new-instance v0, Landroidx/camera/camera2/internal/N;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/N;-><init>(Ljava/lang/Object;)V

    iget-object v1, p0, Landroidx/camera/camera2/internal/d1;->s:Ls/r;

    invoke-virtual {v1, p1, p2, v0}, Ls/r;->d(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroidx/camera/camera2/internal/N;)I

    move-result p1

    return p1
.end method

.method public final g(Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/d1;->o:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iput-object p1, p0, Landroidx/camera/camera2/internal/d1;->p:Ljava/util/List;

    invoke-super {p0, p1}, Landroidx/camera/camera2/internal/Z0;->g(Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    monitor-exit v0

    return-object p1

    :catchall_b
    move-exception p1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw p1
.end method

.method public final j()Lcom/google/common/util/concurrent/o;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/d1;->s:Ls/r;

    invoke-virtual {v0}, Ls/r;->a()Lcom/google/common/util/concurrent/o;

    move-result-object v0

    return-object v0
.end method

.method public final m(Landroidx/camera/camera2/internal/U0;)V
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/d1;->o:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/camera2/internal/d1;->r:Ls/f;

    iget-object v2, p0, Landroidx/camera/camera2/internal/d1;->p:Ljava/util/List;

    invoke-virtual {v1, v2}, Ls/f;->a(Ljava/util/List;)V

    monitor-exit v0
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_14

    const-string v0, "onClosed()"

    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/d1;->z(Ljava/lang/String;)V

    invoke-super {p0, p1}, Landroidx/camera/camera2/internal/Z0;->m(Landroidx/camera/camera2/internal/U0;)V

    return-void

    :catchall_14
    move-exception p1

    :try_start_15
    monitor-exit v0
    :try_end_16
    .catchall {:try_start_15 .. :try_end_16} :catchall_14

    throw p1
.end method

.method public final o(Landroidx/camera/camera2/internal/U0;)V
    .registers 7

    const-string v0, "Session onConfigured()"

    invoke-virtual {p0, v0}, Landroidx/camera/camera2/internal/d1;->z(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/Z0;->b:Landroidx/camera/camera2/internal/v0;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/v0;->d()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/v0;->b()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v2, p0, Landroidx/camera/camera2/internal/d1;->t:Ls/e;

    invoke-virtual {v2}, Ls/e;->a()Z

    move-result v3

    if-eqz v3, :cond_4b

    new-instance v3, Ljava/util/LinkedHashSet;

    invoke-direct {v3}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_20
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_33

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/camera/camera2/internal/U0;

    if-ne v4, p1, :cond_2f

    goto :goto_33

    :cond_2f
    invoke-interface {v3, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_20

    :cond_33
    :goto_33
    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_37
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/camera/camera2/internal/U0;

    invoke-interface {v3}, Landroidx/camera/camera2/internal/U0;->b()Landroidx/camera/camera2/internal/U0$a;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroidx/camera/camera2/internal/U0$a;->n(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_37

    :cond_4b
    invoke-super {p0, p1}, Landroidx/camera/camera2/internal/Z0;->o(Landroidx/camera/camera2/internal/U0;)V

    invoke-virtual {v2}, Ls/e;->a()Z

    move-result v1

    if-eqz v1, :cond_88

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_5d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_70

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/camera2/internal/U0;

    if-ne v2, p1, :cond_6c

    goto :goto_70

    :cond_6c
    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_5d

    :cond_70
    :goto_70
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_74
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_88

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/camera2/internal/U0;

    invoke-interface {v0}, Landroidx/camera/camera2/internal/U0;->b()Landroidx/camera/camera2/internal/U0$a;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroidx/camera/camera2/internal/U0$a;->m(Landroidx/camera/camera2/internal/U0;)V

    goto :goto_74

    :cond_88
    return-void
.end method

.method public final stop()Z
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/d1;->o:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p0}, Landroidx/camera/camera2/internal/Z0;->u()Z

    move-result v1

    if-eqz v1, :cond_13

    iget-object v1, p0, Landroidx/camera/camera2/internal/d1;->r:Ls/f;

    iget-object v2, p0, Landroidx/camera/camera2/internal/d1;->p:Ljava/util/List;

    invoke-virtual {v1, v2}, Ls/f;->a(Ljava/util/List;)V

    goto :goto_1b

    :catchall_11
    move-exception v1

    goto :goto_21

    :cond_13
    iget-object v1, p0, Landroidx/camera/camera2/internal/d1;->q:Lcom/google/common/util/concurrent/o;

    if-eqz v1, :cond_1b

    const/4 v2, 0x1

    invoke-interface {v1, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_1b
    :goto_1b
    invoke-super {p0}, Landroidx/camera/camera2/internal/Z0;->stop()Z

    move-result v1

    monitor-exit v0

    return v1

    :goto_21
    monitor-exit v0
    :try_end_22
    .catchall {:try_start_3 .. :try_end_22} :catchall_11

    throw v1
.end method

.method final z(Ljava/lang/String;)V
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "["

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "] "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "SyncCaptureSessionImpl"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
