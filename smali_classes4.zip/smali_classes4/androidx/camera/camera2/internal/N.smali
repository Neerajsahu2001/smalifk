.class public final synthetic Landroidx/camera/camera2/internal/n;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/t;

.field public final synthetic b:Landroidx/concurrent/futures/b$a;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/t;Landroidx/concurrent/futures/b$a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/n;->a:Landroidx/camera/camera2/internal/t;

    iput-object p2, p0, Landroidx/camera/camera2/internal/n;->b:Landroidx/concurrent/futures/b$a;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/n;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0}, Landroidx/camera/camera2/internal/t;->L()J

    move-result-wide v1

    new-instance v3, Landroidx/camera/camera2/internal/o;

    invoke-direct {v3, v0, v1, v2}, Landroidx/camera/camera2/internal/o;-><init>(Landroidx/camera/camera2/internal/t;J)V

    invoke-static {v3}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    iget-object v1, p0, Landroidx/camera/camera2/internal/n;->b:Landroidx/concurrent/futures/b$a;

    invoke-static {v0, v1}, Lv/f;->j(Lcom/google/common/util/concurrent/o;Landroidx/concurrent/futures/b$a;)V

    return-void
.end method
