.class public final synthetic Landroidx/camera/camera2/internal/h1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/camera2/internal/t$c;


# instance fields
.field public final synthetic a:Landroidx/camera/camera2/internal/j1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/camera2/internal/j1;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/h1;->a:Landroidx/camera/camera2/internal/j1;

    return-void
.end method


# virtual methods
.method public final a(Landroid/hardware/camera2/TotalCaptureResult;)Z
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/h1;->a:Landroidx/camera/camera2/internal/j1;

    iget-object v1, v0, Landroidx/camera/camera2/internal/j1;->f:Landroidx/concurrent/futures/b$a;

    const/4 v2, 0x0

    if-eqz v1, :cond_2b

    invoke-virtual {p1}, Landroid/hardware/camera2/CaptureResult;->getRequest()Landroid/hardware/camera2/CaptureRequest;

    move-result-object p1

    sget-object v1, Landroid/hardware/camera2/CaptureRequest;->FLASH_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {p1, v1}, Landroid/hardware/camera2/CaptureRequest;->get(Landroid/hardware/camera2/CaptureRequest$Key;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    if-eqz p1, :cond_1e

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v1, 0x2

    if-ne p1, v1, :cond_1e

    const/4 p1, 0x1

    goto :goto_1f

    :cond_1e
    const/4 p1, 0x0

    :goto_1f
    iget-boolean v1, v0, Landroidx/camera/camera2/internal/j1;->g:Z

    if-ne p1, v1, :cond_2b

    iget-object p1, v0, Landroidx/camera/camera2/internal/j1;->f:Landroidx/concurrent/futures/b$a;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    iput-object v1, v0, Landroidx/camera/camera2/internal/j1;->f:Landroidx/concurrent/futures/b$a;

    :cond_2b
    return v2
.end method
