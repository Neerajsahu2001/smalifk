.class final Landroidx/camera/camera2/internal/j1;
.super Ljava/lang/Object;
.source "TorchControl.java"


# instance fields
.field private final a:Landroidx/camera/camera2/internal/t;

.field private final b:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Z

.field private final d:Ljava/util/concurrent/Executor;

.field private e:Z

.field f:Landroidx/concurrent/futures/b$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/concurrent/futures/b$a<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field g:Z


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/t;Lp/E;Ljava/util/concurrent/Executor;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/j1;->a:Landroidx/camera/camera2/internal/t;

    iput-object p3, p0, Landroidx/camera/camera2/internal/j1;->d:Ljava/util/concurrent/Executor;

    invoke-static {p2}, Ls/d;->a(Lp/E;)Z

    move-result p2

    iput-boolean p2, p0, Landroidx/camera/camera2/internal/j1;->c:Z

    new-instance p2, Landroidx/lifecycle/I;

    const/4 p3, 0x0

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-direct {p2, p3}, Landroidx/lifecycle/I;-><init>(Ljava/lang/Object;)V

    iput-object p2, p0, Landroidx/camera/camera2/internal/j1;->b:Landroidx/lifecycle/I;

    new-instance p2, Landroidx/camera/camera2/internal/h1;

    invoke-direct {p2, p0}, Landroidx/camera/camera2/internal/h1;-><init>(Landroidx/camera/camera2/internal/j1;)V

    invoke-virtual {p1, p2}, Landroidx/camera/camera2/internal/t;->k(Landroidx/camera/camera2/internal/t$c;)V

    return-void
.end method

.method public static synthetic a(Landroidx/camera/camera2/internal/j1;Landroidx/concurrent/futures/b$a;Z)Ljava/lang/String;
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroidx/camera/camera2/internal/i1;

    invoke-direct {v0, p0, p1, p2}, Landroidx/camera/camera2/internal/i1;-><init>(Landroidx/camera/camera2/internal/j1;Landroidx/concurrent/futures/b$a;Z)V

    iget-object p0, p0, Landroidx/camera/camera2/internal/j1;->d:Ljava/util/concurrent/Executor;

    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "enableTorch: "

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static f(Landroidx/lifecycle/I;Ljava/lang/Integer;)V
    .registers 4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    if-ne v0, v1, :cond_12

    invoke-virtual {p0, p1}, Landroidx/lifecycle/I;->setValue(Ljava/lang/Object;)V

    goto :goto_15

    :cond_12
    invoke-virtual {p0, p1}, Landroidx/lifecycle/I;->postValue(Ljava/lang/Object;)V

    :goto_15
    return-void
.end method


# virtual methods
.method final b(Z)Lcom/google/common/util/concurrent/o;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/j1;->c:Z

    if-nez v0, :cond_17

    const-string p1, "TorchControl"

    const-string v0, "Unable to enableTorch due to there is no flash unit."

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "No flash unit"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lv/f;->f(Ljava/lang/Exception;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1

    :cond_17
    iget-object v0, p0, Landroidx/camera/camera2/internal/j1;->b:Landroidx/lifecycle/I;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/camera/camera2/internal/j1;->f(Landroidx/lifecycle/I;Ljava/lang/Integer;)V

    new-instance v0, Landroidx/camera/camera2/internal/g1;

    invoke-direct {v0, p0, p1}, Landroidx/camera/camera2/internal/g1;-><init>(Landroidx/camera/camera2/internal/j1;Z)V

    invoke-static {v0}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method final c(Landroidx/concurrent/futures/b$a;Z)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/concurrent/futures/b$a<",
            "Ljava/lang/Void;",
            ">;Z)V"
        }
    .end annotation

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/j1;->c:Z

    if-nez v0, :cond_11

    if-eqz p1, :cond_10

    new-instance p2, Ljava/lang/IllegalStateException;

    const-string v0, "No flash unit"

    invoke-direct {p2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    :cond_10
    return-void

    :cond_11
    iget-boolean v0, p0, Landroidx/camera/camera2/internal/j1;->e:Z

    iget-object v1, p0, Landroidx/camera/camera2/internal/j1;->b:Landroidx/lifecycle/I;

    if-nez v0, :cond_2c

    const/4 p2, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-static {v1, p2}, Landroidx/camera/camera2/internal/j1;->f(Landroidx/lifecycle/I;Ljava/lang/Integer;)V

    if-eqz p1, :cond_2b

    new-instance p2, Landroidx/camera/core/n$a;

    const-string v0, "Camera is not active."

    invoke-direct {p2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    :cond_2b
    return-void

    :cond_2c
    iput-boolean p2, p0, Landroidx/camera/camera2/internal/j1;->g:Z

    iget-object v0, p0, Landroidx/camera/camera2/internal/j1;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0, p2}, Landroidx/camera/camera2/internal/t;->o(Z)V

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-static {v1, p2}, Landroidx/camera/camera2/internal/j1;->f(Landroidx/lifecycle/I;Ljava/lang/Integer;)V

    iget-object p2, p0, Landroidx/camera/camera2/internal/j1;->f:Landroidx/concurrent/futures/b$a;

    if-eqz p2, :cond_48

    new-instance v0, Landroidx/camera/core/n$a;

    const-string v1, "There is a new enableTorch being set"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v0}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    :cond_48
    iput-object p1, p0, Landroidx/camera/camera2/internal/j1;->f:Landroidx/concurrent/futures/b$a;

    return-void
.end method

.method final d()Landroidx/lifecycle/I;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/j1;->b:Landroidx/lifecycle/I;

    return-object v0
.end method

.method final e(Z)V
    .registers 4

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/j1;->e:Z

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Landroidx/camera/camera2/internal/j1;->e:Z

    if-nez p1, :cond_2f

    iget-boolean p1, p0, Landroidx/camera/camera2/internal/j1;->g:Z

    if-eqz p1, :cond_1e

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/j1;->g:Z

    iget-object v0, p0, Landroidx/camera/camera2/internal/j1;->a:Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/t;->o(Z)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/j1;->b:Landroidx/lifecycle/I;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/camera/camera2/internal/j1;->f(Landroidx/lifecycle/I;Ljava/lang/Integer;)V

    :cond_1e
    iget-object p1, p0, Landroidx/camera/camera2/internal/j1;->f:Landroidx/concurrent/futures/b$a;

    if-eqz p1, :cond_2f

    new-instance v0, Landroidx/camera/core/n$a;

    const-string v1, "Camera is not active."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/camera/camera2/internal/j1;->f:Landroidx/concurrent/futures/b$a;

    :cond_2f
    return-void
.end method
