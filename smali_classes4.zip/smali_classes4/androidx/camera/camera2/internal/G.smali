.class public final Landroidx/camera/camera2/internal/g;
.super Ljava/lang/Object;
.source "Camera2CameraCaptureResult.java"

# interfaces
.implements Landroidx/camera/core/impl/o;


# instance fields
.field private final a:Landroidx/camera/core/impl/B0;

.field private final b:Landroid/hardware/camera2/CaptureResult;


# direct methods
.method public constructor <init>(Landroidx/camera/core/impl/B0;Landroid/hardware/camera2/CaptureResult;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/g;->a:Landroidx/camera/core/impl/B0;

    iput-object p2, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    return-void
.end method


# virtual methods
.method public final a()J
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    sget-object v1, Landroid/hardware/camera2/CaptureResult;->SENSOR_TIMESTAMP:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    if-nez v0, :cond_f

    const-wide/16 v0, -0x1

    return-wide v0

    :cond_f
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0
.end method

.method public final b()Landroid/hardware/camera2/CaptureResult;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    return-object v0
.end method

.method public final c(Landroidx/camera/core/impl/utils/g$b;)V
    .registers 6

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/g;->i()Landroidx/camera/core/impl/n;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/g$b;->g(Landroidx/camera/core/impl/n;)V

    sget-object v0, Landroid/hardware/camera2/CaptureResult;->SCALER_CROP_REGION:Landroid/hardware/camera2/CaptureResult$Key;

    iget-object v1, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    invoke-virtual {v1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Rect;

    if-eqz v0, :cond_21

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v2

    invoke-virtual {p1, v2}, Landroidx/camera/core/impl/utils/g$b;->j(I)V

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/g$b;->i(I)V

    :cond_21
    sget-object v0, Landroid/hardware/camera2/CaptureResult;->JPEG_ORIENTATION:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_32

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/g$b;->m(I)V

    :cond_32
    sget-object v0, Landroid/hardware/camera2/CaptureResult;->SENSOR_EXPOSURE_TIME:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    if-eqz v0, :cond_43

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Landroidx/camera/core/impl/utils/g$b;->f(J)V

    :cond_43
    sget-object v0, Landroid/hardware/camera2/CaptureResult;->LENS_APERTURE:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    if-eqz v0, :cond_54

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/g$b;->l(F)V

    :cond_54
    sget-object v0, Landroid/hardware/camera2/CaptureResult;->SENSOR_SENSITIVITY:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_8a

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x18

    if-lt v2, v3, :cond_83

    invoke-static {}, Landroidx/camera/camera2/internal/f;->a()Landroid/hardware/camera2/CaptureResult$Key;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    if-eqz v2, :cond_83

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x42c80000    # 100.0f

    div-float/2addr v2, v3

    float-to-int v2, v2

    mul-int v0, v0, v2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    :cond_83
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/g$b;->k(I)V

    :cond_8a
    sget-object v0, Landroid/hardware/camera2/CaptureResult;->LENS_FOCAL_LENGTH:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    if-eqz v0, :cond_9b

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/g$b;->h(F)V

    :cond_9b
    sget-object v0, Landroid/hardware/camera2/CaptureResult;->CONTROL_AWB_MODE:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v1, v0}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_b2

    sget-object v1, Landroidx/camera/core/impl/utils/g$c;->AUTO:Landroidx/camera/core/impl/utils/g$c;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-nez v0, :cond_af

    sget-object v1, Landroidx/camera/core/impl/utils/g$c;->MANUAL:Landroidx/camera/core/impl/utils/g$c;

    :cond_af
    invoke-virtual {p1, v1}, Landroidx/camera/core/impl/utils/g$b;->n(Landroidx/camera/core/impl/utils/g$c;)V

    :cond_b2
    return-void
.end method

.method public final d()Landroidx/camera/core/impl/B0;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->a:Landroidx/camera/core/impl/B0;

    return-object v0
.end method

.method public final e()Landroidx/camera/core/impl/j;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    sget-object v1, Landroid/hardware/camera2/CaptureResult;->CONTROL_AE_STATE:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_f

    sget-object v0, Landroidx/camera/core/impl/j;->UNKNOWN:Landroidx/camera/core/impl/j;

    return-object v0

    :cond_f
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-eqz v1, :cond_46

    const/4 v2, 0x1

    if-eq v1, v2, :cond_43

    const/4 v2, 0x2

    if-eq v1, v2, :cond_40

    const/4 v2, 0x3

    if-eq v1, v2, :cond_3d

    const/4 v2, 0x4

    if-eq v1, v2, :cond_3a

    const/4 v2, 0x5

    if-eq v1, v2, :cond_43

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Undefined ae state: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "C2CameraCaptureResult"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Landroidx/camera/core/impl/j;->UNKNOWN:Landroidx/camera/core/impl/j;

    return-object v0

    :cond_3a
    sget-object v0, Landroidx/camera/core/impl/j;->FLASH_REQUIRED:Landroidx/camera/core/impl/j;

    return-object v0

    :cond_3d
    sget-object v0, Landroidx/camera/core/impl/j;->LOCKED:Landroidx/camera/core/impl/j;

    return-object v0

    :cond_40
    sget-object v0, Landroidx/camera/core/impl/j;->CONVERGED:Landroidx/camera/core/impl/j;

    return-object v0

    :cond_43
    sget-object v0, Landroidx/camera/core/impl/j;->SEARCHING:Landroidx/camera/core/impl/j;

    return-object v0

    :cond_46
    sget-object v0, Landroidx/camera/core/impl/j;->INACTIVE:Landroidx/camera/core/impl/j;

    return-object v0
.end method

.method public final f()Landroidx/camera/core/impl/k;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    sget-object v1, Landroid/hardware/camera2/CaptureResult;->CONTROL_AF_MODE:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_f

    sget-object v0, Landroidx/camera/core/impl/k;->UNKNOWN:Landroidx/camera/core/impl/k;

    return-object v0

    :cond_f
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-eqz v1, :cond_40

    const/4 v2, 0x1

    if-eq v1, v2, :cond_3d

    const/4 v2, 0x2

    if-eq v1, v2, :cond_3d

    const/4 v2, 0x3

    if-eq v1, v2, :cond_3a

    const/4 v2, 0x4

    if-eq v1, v2, :cond_3a

    const/4 v2, 0x5

    if-eq v1, v2, :cond_40

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Undefined af mode: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "C2CameraCaptureResult"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Landroidx/camera/core/impl/k;->UNKNOWN:Landroidx/camera/core/impl/k;

    return-object v0

    :cond_3a
    sget-object v0, Landroidx/camera/core/impl/k;->ON_CONTINUOUS_AUTO:Landroidx/camera/core/impl/k;

    return-object v0

    :cond_3d
    sget-object v0, Landroidx/camera/core/impl/k;->ON_MANUAL_AUTO:Landroidx/camera/core/impl/k;

    return-object v0

    :cond_40
    sget-object v0, Landroidx/camera/core/impl/k;->OFF:Landroidx/camera/core/impl/k;

    return-object v0
.end method

.method public final g()Landroidx/camera/core/impl/l;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    sget-object v1, Landroid/hardware/camera2/CaptureResult;->CONTROL_AF_STATE:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_f

    sget-object v0, Landroidx/camera/core/impl/l;->UNKNOWN:Landroidx/camera/core/impl/l;

    return-object v0

    :cond_f
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    packed-switch v1, :pswitch_data_3e

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Undefined af state: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "C2CameraCaptureResult"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Landroidx/camera/core/impl/l;->UNKNOWN:Landroidx/camera/core/impl/l;

    return-object v0

    :pswitch_2c
    sget-object v0, Landroidx/camera/core/impl/l;->PASSIVE_NOT_FOCUSED:Landroidx/camera/core/impl/l;

    return-object v0

    :pswitch_2f
    sget-object v0, Landroidx/camera/core/impl/l;->LOCKED_NOT_FOCUSED:Landroidx/camera/core/impl/l;

    return-object v0

    :pswitch_32
    sget-object v0, Landroidx/camera/core/impl/l;->LOCKED_FOCUSED:Landroidx/camera/core/impl/l;

    return-object v0

    :pswitch_35
    sget-object v0, Landroidx/camera/core/impl/l;->PASSIVE_FOCUSED:Landroidx/camera/core/impl/l;

    return-object v0

    :pswitch_38
    sget-object v0, Landroidx/camera/core/impl/l;->SCANNING:Landroidx/camera/core/impl/l;

    return-object v0

    :pswitch_3b
    sget-object v0, Landroidx/camera/core/impl/l;->INACTIVE:Landroidx/camera/core/impl/l;

    return-object v0

    :pswitch_data_3e
    .packed-switch 0x0
        :pswitch_3b
        :pswitch_38
        :pswitch_35
        :pswitch_38
        :pswitch_32
        :pswitch_2f
        :pswitch_2c
    .end packed-switch
.end method

.method public final h()Landroidx/camera/core/impl/m;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    sget-object v1, Landroid/hardware/camera2/CaptureResult;->CONTROL_AWB_STATE:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_f

    sget-object v0, Landroidx/camera/core/impl/m;->UNKNOWN:Landroidx/camera/core/impl/m;

    return-object v0

    :cond_f
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-eqz v1, :cond_3d

    const/4 v2, 0x1

    if-eq v1, v2, :cond_3a

    const/4 v2, 0x2

    if-eq v1, v2, :cond_37

    const/4 v2, 0x3

    if-eq v1, v2, :cond_34

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Undefined awb state: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "C2CameraCaptureResult"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Landroidx/camera/core/impl/m;->UNKNOWN:Landroidx/camera/core/impl/m;

    return-object v0

    :cond_34
    sget-object v0, Landroidx/camera/core/impl/m;->LOCKED:Landroidx/camera/core/impl/m;

    return-object v0

    :cond_37
    sget-object v0, Landroidx/camera/core/impl/m;->CONVERGED:Landroidx/camera/core/impl/m;

    return-object v0

    :cond_3a
    sget-object v0, Landroidx/camera/core/impl/m;->METERING:Landroidx/camera/core/impl/m;

    return-object v0

    :cond_3d
    sget-object v0, Landroidx/camera/core/impl/m;->INACTIVE:Landroidx/camera/core/impl/m;

    return-object v0
.end method

.method public final i()Landroidx/camera/core/impl/n;
    .registers 4

    iget-object v0, p0, Landroidx/camera/camera2/internal/g;->b:Landroid/hardware/camera2/CaptureResult;

    sget-object v1, Landroid/hardware/camera2/CaptureResult;->FLASH_STATE:Landroid/hardware/camera2/CaptureResult$Key;

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CaptureResult;->get(Landroid/hardware/camera2/CaptureResult$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_f

    sget-object v0, Landroidx/camera/core/impl/n;->UNKNOWN:Landroidx/camera/core/impl/n;

    return-object v0

    :cond_f
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-eqz v1, :cond_3d

    const/4 v2, 0x1

    if-eq v1, v2, :cond_3d

    const/4 v2, 0x2

    if-eq v1, v2, :cond_3a

    const/4 v2, 0x3

    if-eq v1, v2, :cond_37

    const/4 v2, 0x4

    if-eq v1, v2, :cond_37

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Undefined flash state: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "C2CameraCaptureResult"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Landroidx/camera/core/impl/n;->UNKNOWN:Landroidx/camera/core/impl/n;

    return-object v0

    :cond_37
    sget-object v0, Landroidx/camera/core/impl/n;->FIRED:Landroidx/camera/core/impl/n;

    return-object v0

    :cond_3a
    sget-object v0, Landroidx/camera/core/impl/n;->READY:Landroidx/camera/core/impl/n;

    return-object v0

    :cond_3d
    sget-object v0, Landroidx/camera/core/impl/n;->NONE:Landroidx/camera/core/impl/n;

    return-object v0
.end method
