.class interface abstract Landroidx/camera/camera2/internal/e;
.super Ljava/lang/Object;
.source "CamcorderProfileHelper.java"


# virtual methods
.method public abstract a(II)Landroid/media/CamcorderProfile;
.end method

.method public abstract b(II)Z
.end method
