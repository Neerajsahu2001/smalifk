.class final Landroidx/camera/camera2/internal/e1;
.super Ljava/lang/Object;
.source "SynchronizedCaptureSessionOpener.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/camera2/internal/e1$b;,
        Landroidx/camera/camera2/internal/e1$a;
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/camera2/internal/e1$b;


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/Z0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/e1;->a:Landroidx/camera/camera2/internal/e1$b;

    return-void
.end method


# virtual methods
.method final a(Ljava/util/ArrayList;Landroidx/camera/camera2/internal/U0$a;)Lq/i;
    .registers 5

    iget-object v0, p0, Landroidx/camera/camera2/internal/e1;->a:Landroidx/camera/camera2/internal/e1$b;

    check-cast v0, Landroidx/camera/camera2/internal/Z0;

    iput-object p2, v0, Landroidx/camera/camera2/internal/Z0;->f:Landroidx/camera/camera2/internal/U0$a;

    new-instance p2, Lq/i;

    new-instance v1, Landroidx/camera/camera2/internal/a1;

    invoke-direct {v1, v0}, Landroidx/camera/camera2/internal/a1;-><init>(Landroidx/camera/camera2/internal/Z0;)V

    iget-object v0, v0, Landroidx/camera/camera2/internal/Z0;->d:Ljava/util/concurrent/Executor;

    invoke-direct {p2, p1, v0, v1}, Lq/i;-><init>(Ljava/util/ArrayList;Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCaptureSession$StateCallback;)V

    return-object p2
.end method

.method public final b()Ljava/util/concurrent/Executor;
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/e1;->a:Landroidx/camera/camera2/internal/e1$b;

    check-cast v0, Landroidx/camera/camera2/internal/Z0;

    iget-object v0, v0, Landroidx/camera/camera2/internal/Z0;->d:Ljava/util/concurrent/Executor;

    return-object v0
.end method

.method final c(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/hardware/camera2/CameraDevice;",
            "Lq/i;",
            "Ljava/util/List<",
            "Landroidx/camera/core/impl/K;",
            ">;)",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/camera2/internal/e1;->a:Landroidx/camera/camera2/internal/e1$b;

    invoke-interface {v0, p1, p2, p3}, Landroidx/camera/camera2/internal/e1$b;->a(Landroid/hardware/camera2/CameraDevice;Lq/i;Ljava/util/List;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method final d(Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;
    .registers 3

    iget-object v0, p0, Landroidx/camera/camera2/internal/e1;->a:Landroidx/camera/camera2/internal/e1$b;

    invoke-interface {v0, p1}, Landroidx/camera/camera2/internal/e1$b;->g(Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method

.method final e()Z
    .registers 2

    iget-object v0, p0, Landroidx/camera/camera2/internal/e1;->a:Landroidx/camera/camera2/internal/e1$b;

    invoke-interface {v0}, Landroidx/camera/camera2/internal/e1$b;->stop()Z

    move-result v0

    return v0
.end method
