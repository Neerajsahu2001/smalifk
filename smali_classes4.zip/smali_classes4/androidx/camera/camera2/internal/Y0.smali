.class public final Landroidx/camera/camera2/internal/y0;
.super Ljava/lang/Object;
.source "ExposureControl.java"


# instance fields
.field private final a:Landroidx/camera/camera2/internal/z0;

.field private final b:Ljava/util/concurrent/Executor;

.field private c:Z


# direct methods
.method constructor <init>(Landroidx/camera/camera2/internal/t;Ljava/util/concurrent/Executor;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/camera2/internal/y0;->c:Z

    new-instance p1, Landroidx/camera/camera2/internal/z0;

    invoke-direct {p1}, Landroidx/camera/camera2/internal/z0;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/y0;->a:Landroidx/camera/camera2/internal/z0;

    iput-object p2, p0, Landroidx/camera/camera2/internal/y0;->b:Ljava/util/concurrent/Executor;

    return-void
.end method


# virtual methods
.method final a(Z)V
    .registers 3

    iget-boolean v0, p0, Landroidx/camera/camera2/internal/y0;->c:Z

    if-ne p1, v0, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Landroidx/camera/camera2/internal/y0;->c:Z

    if-nez p1, :cond_e

    iget-object p1, p0, Landroidx/camera/camera2/internal/y0;->a:Landroidx/camera/camera2/internal/z0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/z0;->b()V

    :cond_e
    return-void
.end method

.method final b(Lo/a$a;)V
    .registers 4

    sget-object v0, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_EXPOSURE_COMPENSATION:Landroid/hardware/camera2/CaptureRequest$Key;

    iget-object v1, p0, Landroidx/camera/camera2/internal/y0;->a:Landroidx/camera/camera2/internal/z0;

    invoke-virtual {v1}, Landroidx/camera/camera2/internal/z0;->a()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    return-void
.end method
