.class final Landroidx/camera/camera2/internal/P$c;
.super Ljava/lang/Object;
.source "Camera2CapturePipeline.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/P;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation


# static fields
.field private static final i:J

.field private static final j:J


# instance fields
.field private final a:I

.field private final b:Ljava/util/concurrent/Executor;

.field private final c:Landroidx/camera/camera2/internal/t;

.field private final d:Ls/k;

.field private final e:Z

.field private f:J

.field final g:Ljava/util/ArrayList;

.field private final h:Landroidx/camera/camera2/internal/P$c$a;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v1, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v1

    sput-wide v1, Landroidx/camera/camera2/internal/P$c;->i:J

    const-wide/16 v1, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v0

    sput-wide v0, Landroidx/camera/camera2/internal/P$c;->j:J

    return-void
.end method

.method constructor <init>(ILjava/util/concurrent/Executor;Landroidx/camera/camera2/internal/t;ZLs/k;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-wide v0, Landroidx/camera/camera2/internal/P$c;->i:J

    iput-wide v0, p0, Landroidx/camera/camera2/internal/P$c;->f:J

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/camera/camera2/internal/P$c;->g:Ljava/util/ArrayList;

    new-instance v0, Landroidx/camera/camera2/internal/P$c$a;

    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/P$c$a;-><init>(Landroidx/camera/camera2/internal/P$c;)V

    iput-object v0, p0, Landroidx/camera/camera2/internal/P$c;->h:Landroidx/camera/camera2/internal/P$c$a;

    iput p1, p0, Landroidx/camera/camera2/internal/P$c;->a:I

    iput-object p2, p0, Landroidx/camera/camera2/internal/P$c;->b:Ljava/util/concurrent/Executor;

    iput-object p3, p0, Landroidx/camera/camera2/internal/P$c;->c:Landroidx/camera/camera2/internal/t;

    iput-boolean p4, p0, Landroidx/camera/camera2/internal/P$c;->e:Z

    iput-object p5, p0, Landroidx/camera/camera2/internal/P$c;->d:Ls/k;

    return-void
.end method

.method public static a(Landroidx/camera/camera2/internal/P$c;ILandroid/hardware/camera2/TotalCaptureResult;)Lcom/google/common/util/concurrent/o;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p2}, Landroidx/camera/camera2/internal/P;->a(ILandroid/hardware/camera2/TotalCaptureResult;)Z

    move-result p1

    if-eqz p1, :cond_d

    sget-wide v0, Landroidx/camera/camera2/internal/P$c;->j:J

    iput-wide v0, p0, Landroidx/camera/camera2/internal/P$c;->f:J

    :cond_d
    iget-object p0, p0, Landroidx/camera/camera2/internal/P$c;->h:Landroidx/camera/camera2/internal/P$c$a;

    invoke-virtual {p0, p2}, Landroidx/camera/camera2/internal/P$c$a;->a(Landroid/hardware/camera2/TotalCaptureResult;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    return-object p0
.end method

.method public static b(Landroidx/camera/camera2/internal/P$c;Ljava/lang/Boolean;)Lcom/google/common/util/concurrent/o;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1f

    iget-wide v0, p0, Landroidx/camera/camera2/internal/P$c;->f:J

    new-instance p1, Landroidx/camera/camera2/internal/W;

    invoke-direct {p1, p0}, Landroidx/camera/camera2/internal/W;-><init>(Landroidx/camera/camera2/internal/P$c;)V

    new-instance v2, Landroidx/camera/camera2/internal/P$e;

    invoke-direct {v2, v0, v1, p1}, Landroidx/camera/camera2/internal/P$e;-><init>(JLandroidx/camera/camera2/internal/W;)V

    iget-object p0, p0, Landroidx/camera/camera2/internal/P$c;->c:Landroidx/camera/camera2/internal/t;

    invoke-virtual {p0, v2}, Landroidx/camera/camera2/internal/t;->k(Landroidx/camera/camera2/internal/t$c;)V

    invoke-virtual {v2}, Landroidx/camera/camera2/internal/P$e;->c()Lcom/google/common/util/concurrent/o;

    move-result-object p0

    goto :goto_24

    :cond_1f
    const/4 p0, 0x0

    invoke-static {p0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    :goto_24
    return-object p0
.end method

.method public static synthetic c(Landroidx/camera/camera2/internal/P$c;)V
    .registers 1

    iget-object p0, p0, Landroidx/camera/camera2/internal/P$c;->h:Landroidx/camera/camera2/internal/P$c$a;

    invoke-virtual {p0}, Landroidx/camera/camera2/internal/P$c$a;->c()V

    return-void
.end method

.method public static d(Landroidx/camera/camera2/internal/P$c;Ljava/util/List;I)Lcom/google/common/util/concurrent/o;
    .registers 11

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_11
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    iget-object v3, p0, Landroidx/camera/camera2/internal/P$c;->c:Landroidx/camera/camera2/internal/t;

    if-eqz v2, :cond_a2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/D;

    invoke-static {v2}, Landroidx/camera/core/impl/D$a;->j(Landroidx/camera/core/impl/D;)Landroidx/camera/core/impl/D$a;

    move-result-object v4

    invoke-virtual {v2}, Landroidx/camera/core/impl/D;->f()I

    move-result v5

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ne v5, v6, :cond_49

    iget-object v5, v3, Landroidx/camera/camera2/internal/t;->l:Landroidx/camera/camera2/internal/m1;

    invoke-interface {v5}, Landroidx/camera/camera2/internal/m1;->b()Landroidx/camera/core/r0;

    move-result-object v5

    if-eqz v5, :cond_49

    iget-object v3, v3, Landroidx/camera/camera2/internal/t;->l:Landroidx/camera/camera2/internal/m1;

    invoke-interface {v3, v5}, Landroidx/camera/camera2/internal/m1;->c(Landroidx/camera/core/r0;)Z

    move-result v3

    if-eqz v3, :cond_49

    invoke-interface {v5}, Landroidx/camera/core/r0;->V0()Landroidx/camera/core/o0;

    move-result-object v3

    instance-of v5, v3, Lw/b;

    if-eqz v5, :cond_49

    check-cast v3, Lw/b;

    invoke-virtual {v3}, Lw/b;->e()Landroidx/camera/core/impl/o;

    move-result-object v7

    :cond_49
    const/4 v3, 0x3

    if-eqz v7, :cond_50

    invoke-virtual {v4, v7}, Landroidx/camera/core/impl/D$a;->m(Landroidx/camera/core/impl/o;)V

    goto :goto_70

    :cond_50
    iget v5, p0, Landroidx/camera/camera2/internal/P$c;->a:I

    const/4 v7, -0x1

    if-ne v5, v3, :cond_5b

    iget-boolean v5, p0, Landroidx/camera/camera2/internal/P$c;->e:Z

    if-nez v5, :cond_5b

    const/4 v2, 0x4

    goto :goto_6b

    :cond_5b
    invoke-virtual {v2}, Landroidx/camera/core/impl/D;->f()I

    move-result v5

    if-eq v5, v7, :cond_6a

    invoke-virtual {v2}, Landroidx/camera/core/impl/D;->f()I

    move-result v2

    if-ne v2, v6, :cond_68

    goto :goto_6a

    :cond_68
    const/4 v2, -0x1

    goto :goto_6b

    :cond_6a
    :goto_6a
    const/4 v2, 0x2

    :goto_6b
    if-eq v2, v7, :cond_70

    invoke-virtual {v4, v2}, Landroidx/camera/core/impl/D$a;->o(I)V

    :cond_70
    :goto_70
    iget-object v2, p0, Landroidx/camera/camera2/internal/P$c;->d:Ls/k;

    invoke-virtual {v2, p2}, Ls/k;->c(I)Z

    move-result v2

    if-eqz v2, :cond_8d

    new-instance v2, Lo/a$a;

    invoke-direct {v2}, Lo/a$a;-><init>()V

    sget-object v5, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v5, v3}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    invoke-virtual {v2}, Lo/a$a;->b()Lo/a;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroidx/camera/core/impl/D$a;->e(Landroidx/camera/core/impl/H;)V

    :cond_8d
    new-instance v2, Landroidx/camera/camera2/internal/V;

    invoke-direct {v2, p0, v4}, Landroidx/camera/camera2/internal/V;-><init>(Landroidx/camera/camera2/internal/P$c;Landroidx/camera/core/impl/D$a;)V

    invoke-static {v2}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_11

    :cond_a2
    invoke-virtual {v3, v1}, Landroidx/camera/camera2/internal/t;->J(Ljava/util/List;)V

    invoke-static {v0}, Lv/f;->c(Ljava/util/ArrayList;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method final e(ILjava/util/List;)Lcom/google/common/util/concurrent/o;
    .registers 9

    const/4 v0, 0x0

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v1

    iget-object v2, p0, Landroidx/camera/camera2/internal/P$c;->g:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    iget-object v3, p0, Landroidx/camera/camera2/internal/P$c;->b:Ljava/util/concurrent/Executor;

    if-nez v2, :cond_4a

    iget-object v1, p0, Landroidx/camera/camera2/internal/P$c;->h:Landroidx/camera/camera2/internal/P$c$a;

    invoke-virtual {v1}, Landroidx/camera/camera2/internal/P$c$a;->b()Z

    move-result v1

    if-eqz v1, :cond_28

    new-instance v1, Landroidx/camera/camera2/internal/P$e;

    const-wide/16 v4, 0x0

    invoke-direct {v1, v4, v5, v0}, Landroidx/camera/camera2/internal/P$e;-><init>(JLandroidx/camera/camera2/internal/W;)V

    iget-object v0, p0, Landroidx/camera/camera2/internal/P$c;->c:Landroidx/camera/camera2/internal/t;

    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/t;->k(Landroidx/camera/camera2/internal/t$c;)V

    invoke-virtual {v1}, Landroidx/camera/camera2/internal/P$e;->c()Lcom/google/common/util/concurrent/o;

    move-result-object v0

    goto :goto_2c

    :cond_28
    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    :goto_2c
    invoke-static {v0}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object v0

    new-instance v1, Landroidx/camera/camera2/internal/Q;

    invoke-direct {v1, p0, p1}, Landroidx/camera/camera2/internal/Q;-><init>(Landroidx/camera/camera2/internal/P$c;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1, v3}, Lv/f;->n(Lcom/google/common/util/concurrent/o;Lv/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    check-cast v0, Lv/d;

    new-instance v1, Landroidx/camera/camera2/internal/S;

    invoke-direct {v1, p0}, Landroidx/camera/camera2/internal/S;-><init>(Landroidx/camera/camera2/internal/P$c;)V

    invoke-static {v0, v1, v3}, Lv/f;->n(Lcom/google/common/util/concurrent/o;Lv/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lv/d;

    :cond_4a
    invoke-static {v1}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object v0

    new-instance v1, Landroidx/camera/camera2/internal/T;

    invoke-direct {v1, p0, p2, p1}, Landroidx/camera/camera2/internal/T;-><init>(Landroidx/camera/camera2/internal/P$c;Ljava/util/List;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1, v3}, Lv/f;->n(Lcom/google/common/util/concurrent/o;Lv/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    check-cast p1, Lv/d;

    new-instance p2, Landroidx/camera/camera2/internal/U;

    invoke-direct {p2, p0}, Landroidx/camera/camera2/internal/U;-><init>(Landroidx/camera/camera2/internal/P$c;)V

    invoke-virtual {p1, p2, v3}, Lv/d;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-object p1
.end method
