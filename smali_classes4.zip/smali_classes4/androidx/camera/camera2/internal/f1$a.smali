.class final Landroidx/camera/camera2/internal/f1$a;
.super Landroidx/camera/camera2/internal/U0$a;
.source "SynchronizedCaptureSessionStateCallbacks.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/f1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private final a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;


# direct methods
.method constructor <init>(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/hardware/camera2/CameraCaptureSession$StateCallback;",
            ">;)V"
        }
    .end annotation

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_c

    new-instance p1, Landroidx/camera/camera2/internal/h0;

    invoke-direct {p1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;-><init>()V

    goto :goto_21

    :cond_c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1b

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    goto :goto_21

    :cond_1b
    new-instance v0, Landroidx/camera/camera2/internal/g0;

    invoke-direct {v0, p1}, Landroidx/camera/camera2/internal/g0;-><init>(Ljava/util/List;)V

    move-object p1, v0

    :goto_21
    invoke-direct {p0}, Landroidx/camera/camera2/internal/U0$a;-><init>()V

    iput-object p1, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    return-void
.end method


# virtual methods
.method public final k(Landroidx/camera/camera2/internal/U0;)V
    .registers 3

    check-cast p1, Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/Z0;->h()Lp/l;

    move-result-object p1

    invoke-virtual {p1}, Lp/l;->c()Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {v0, p1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onActive(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void
.end method

.method public final l(Landroidx/camera/camera2/internal/U0;)V
    .registers 3

    check-cast p1, Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/Z0;->h()Lp/l;

    move-result-object p1

    invoke-virtual {p1}, Lp/l;->c()Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-static {v0, p1}, Lp/h;->b(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void
.end method

.method public final m(Landroidx/camera/camera2/internal/U0;)V
    .registers 3

    invoke-interface {p1}, Landroidx/camera/camera2/internal/U0;->h()Lp/l;

    move-result-object p1

    invoke-virtual {p1}, Lp/l;->c()Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {v0, p1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onClosed(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void
.end method

.method public final n(Landroidx/camera/camera2/internal/U0;)V
    .registers 3

    invoke-interface {p1}, Landroidx/camera/camera2/internal/U0;->h()Lp/l;

    move-result-object p1

    invoke-virtual {p1}, Lp/l;->c()Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {v0, p1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onConfigureFailed(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void
.end method

.method public final o(Landroidx/camera/camera2/internal/U0;)V
    .registers 3

    check-cast p1, Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/Z0;->h()Lp/l;

    move-result-object p1

    invoke-virtual {p1}, Lp/l;->c()Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {v0, p1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onConfigured(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void
.end method

.method public final p(Landroidx/camera/camera2/internal/U0;)V
    .registers 3

    check-cast p1, Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/Z0;->h()Lp/l;

    move-result-object p1

    invoke-virtual {p1}, Lp/l;->c()Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-virtual {v0, p1}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;->onReady(Landroid/hardware/camera2/CameraCaptureSession;)V

    return-void
.end method

.method final q(Landroidx/camera/camera2/internal/U0;)V
    .registers 2

    return-void
.end method

.method public final r(Landroidx/camera/camera2/internal/U0;Landroid/view/Surface;)V
    .registers 4

    check-cast p1, Landroidx/camera/camera2/internal/Z0;

    invoke-virtual {p1}, Landroidx/camera/camera2/internal/Z0;->h()Lp/l;

    move-result-object p1

    invoke-virtual {p1}, Lp/l;->c()Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    iget-object v0, p0, Landroidx/camera/camera2/internal/f1$a;->a:Landroid/hardware/camera2/CameraCaptureSession$StateCallback;

    invoke-static {v0, p1, p2}, Lp/c;->a(Landroid/hardware/camera2/CameraCaptureSession$StateCallback;Landroid/hardware/camera2/CameraCaptureSession;Landroid/view/Surface;)V

    return-void
.end method
