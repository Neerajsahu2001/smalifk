.class interface abstract Landroidx/camera/camera2/internal/f0$a;
.super Ljava/lang/Object;
.source "CameraBurstCaptureCallback.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/camera2/internal/f0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation
