.class public final Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;
.super Ljava/lang/Object;
.source "Camera2UseCaseConfigFactory.java"

# interfaces
.implements Landroidx/camera/core/impl/F0;


# instance fields
.field final b:Landroidx/camera/camera2/internal/x0;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Landroidx/camera/camera2/internal/x0;->b(Landroid/content/Context;)Landroidx/camera/camera2/internal/x0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;->b:Landroidx/camera/camera2/internal/x0;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/impl/F0$b;I)Landroidx/camera/core/impl/H;
    .registers 15

    invoke-static {}, Landroidx/camera/core/impl/k0;->E()Landroidx/camera/core/impl/k0;

    move-result-object v0

    new-instance v1, Landroidx/camera/core/impl/u0$b;

    invoke-direct {v1}, Landroidx/camera/core/impl/u0$b;-><init>()V

    sget-object v2, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v3, v2, v3

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eq v3, v7, :cond_27

    if-eq v3, v8, :cond_23

    if-eq v3, v6, :cond_23

    if-eq v3, v5, :cond_1f

    goto :goto_2f

    :cond_1f
    invoke-virtual {v1, v6}, Landroidx/camera/core/impl/u0$b;->q(I)V

    goto :goto_2f

    :cond_23
    invoke-virtual {v1, v7}, Landroidx/camera/core/impl/u0$b;->q(I)V

    goto :goto_2f

    :cond_27
    if-ne p2, v8, :cond_2b

    const/4 v3, 0x5

    goto :goto_2c

    :cond_2b
    const/4 v3, 0x1

    :goto_2c
    invoke-virtual {v1, v3}, Landroidx/camera/core/impl/u0$b;->q(I)V

    :goto_2f
    sget-object v3, Landroidx/camera/core/impl/F0$b;->PREVIEW:Landroidx/camera/core/impl/F0$b;

    if-ne p1, v3, :cond_53

    const-class v9, Lr/w;

    invoke-static {v9}, Lr/l;->a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object v9

    check-cast v9, Lr/w;

    if-nez v9, :cond_3e

    goto :goto_53

    :cond_3e
    new-instance v9, Lo/a$a;

    invoke-direct {v9}, Lo/a$a;-><init>()V

    sget-object v10, Landroid/hardware/camera2/CaptureRequest;->TONEMAP_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v9, v10, v11}, Lo/a$a;->e(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    invoke-virtual {v9}, Lo/a$a;->b()Lo/a;

    move-result-object v9

    invoke-virtual {v1, v9}, Landroidx/camera/core/impl/u0$b;->e(Landroidx/camera/core/impl/H;)V

    :cond_53
    :goto_53
    sget-object v9, Landroidx/camera/core/impl/E0;->m:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1}, Landroidx/camera/core/impl/u0$b;->k()Landroidx/camera/core/impl/u0;

    move-result-object v1

    invoke-virtual {v0, v9, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    sget-object v1, Landroidx/camera/core/impl/E0;->o:Landroidx/camera/core/impl/H$a;

    sget-object v9, Landroidx/camera/camera2/internal/e0;->a:Landroidx/camera/camera2/internal/e0;

    invoke-virtual {v0, v1, v9}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    new-instance v1, Landroidx/camera/core/impl/D$a;

    invoke-direct {v1}, Landroidx/camera/core/impl/D$a;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    aget v2, v2, v9

    if-eq v2, v7, :cond_7f

    if-eq v2, v8, :cond_7b

    if-eq v2, v6, :cond_7b

    if-eq v2, v5, :cond_77

    goto :goto_86

    :cond_77
    invoke-virtual {v1, v6}, Landroidx/camera/core/impl/D$a;->o(I)V

    goto :goto_86

    :cond_7b
    invoke-virtual {v1, v7}, Landroidx/camera/core/impl/D$a;->o(I)V

    goto :goto_86

    :cond_7f
    if-ne p2, v8, :cond_82

    goto :goto_83

    :cond_82
    const/4 v4, 0x2

    :goto_83
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/D$a;->o(I)V

    :goto_86
    sget-object p2, Landroidx/camera/core/impl/E0;->n:Landroidx/camera/core/impl/H$a;

    invoke-virtual {v1}, Landroidx/camera/core/impl/D$a;->h()Landroidx/camera/core/impl/D;

    move-result-object v1

    invoke-virtual {v0, p2, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    sget-object p2, Landroidx/camera/core/impl/E0;->p:Landroidx/camera/core/impl/H$a;

    sget-object v1, Landroidx/camera/core/impl/F0$b;->IMAGE_CAPTURE:Landroidx/camera/core/impl/F0$b;

    if-ne p1, v1, :cond_98

    sget-object v1, Landroidx/camera/camera2/internal/K0;->c:Landroidx/camera/camera2/internal/K0;

    goto :goto_9a

    :cond_98
    sget-object v1, Landroidx/camera/camera2/internal/M;->a:Landroidx/camera/camera2/internal/M;

    :goto_9a
    invoke-virtual {v0, p2, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    iget-object p2, p0, Landroidx/camera/camera2/internal/Camera2UseCaseConfigFactory;->b:Landroidx/camera/camera2/internal/x0;

    if-ne p1, v3, :cond_aa

    sget-object p1, Landroidx/camera/core/impl/Z;->k:Landroidx/camera/core/impl/H$a;

    invoke-virtual {p2}, Landroidx/camera/camera2/internal/x0;->d()Landroid/util/Size;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    :cond_aa
    invoke-virtual {p2}, Landroidx/camera/camera2/internal/x0;->c()Landroid/view/Display;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Display;->getRotation()I

    move-result p1

    sget-object p2, Landroidx/camera/core/impl/Z;->g:Landroidx/camera/core/impl/H$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p2, p1}, Landroidx/camera/core/impl/k0;->H(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)V

    invoke-static {v0}, Landroidx/camera/core/impl/o0;->D(Landroidx/camera/core/impl/j0;)Landroidx/camera/core/impl/o0;

    move-result-object p1

    return-object p1
.end method
