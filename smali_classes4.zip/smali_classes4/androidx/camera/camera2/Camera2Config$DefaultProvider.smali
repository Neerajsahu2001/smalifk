.class public final Landroidx/camera/camera2/Camera2Config$DefaultProvider;
.super Ljava/lang/Object;
.source "Camera2Config.java"

# interfaces
.implements Landroidx/camera/core/z$b;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getCameraXConfig()Landroidx/camera/core/z;
    .registers 5

    new-instance v0, Ln/a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    new-instance v1, Ln/b;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    new-instance v2, Ln/c;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    new-instance v3, Landroidx/camera/core/z$a;

    invoke-direct {v3}, Landroidx/camera/core/z$a;-><init>()V

    invoke-virtual {v3, v0}, Landroidx/camera/core/z$a;->b(Ln/a;)V

    invoke-virtual {v3, v1}, Landroidx/camera/core/z$a;->c(Ln/b;)V

    invoke-virtual {v3, v2}, Landroidx/camera/core/z$a;->d(Ln/c;)V

    invoke-virtual {v3}, Landroidx/camera/core/z$a;->a()Landroidx/camera/core/z;

    move-result-object v0

    return-object v0
.end method
