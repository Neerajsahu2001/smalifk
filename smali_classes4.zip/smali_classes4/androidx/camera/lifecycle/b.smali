.class public final synthetic Landroidx/camera/lifecycle/b;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lm/a;


# instance fields
.field public final synthetic a:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/lifecycle/b;->a:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Landroidx/camera/lifecycle/b;->a:Landroid/content/Context;

    check-cast p1, Landroidx/camera/core/y;

    invoke-static {v0, p1}, Landroidx/camera/lifecycle/e;->b(Landroid/content/Context;Landroidx/camera/core/y;)Landroidx/camera/lifecycle/e;

    move-result-object p1

    return-object p1
.end method
