.class public final Landroidx/camera/lifecycle/e;
.super Ljava/lang/Object;
.source "ProcessCameraProvider.java"


# static fields
.field private static final f:Landroidx/camera/lifecycle/e;


# instance fields
.field private final a:Ljava/lang/Object;

.field private b:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Landroidx/camera/core/y;",
            ">;"
        }
    .end annotation
.end field

.field private c:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Landroidx/camera/lifecycle/LifecycleCameraRepository;

.field private e:Landroidx/camera/core/y;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/camera/lifecycle/e;

    invoke-direct {v0}, Landroidx/camera/lifecycle/e;-><init>()V

    sput-object v0, Landroidx/camera/lifecycle/e;->f:Landroidx/camera/lifecycle/e;

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/lifecycle/e;->a:Ljava/lang/Object;

    const/4 v0, 0x0

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/lifecycle/e;->c:Lcom/google/common/util/concurrent/o;

    new-instance v0, Landroidx/camera/lifecycle/LifecycleCameraRepository;

    invoke-direct {v0}, Landroidx/camera/lifecycle/LifecycleCameraRepository;-><init>()V

    iput-object v0, p0, Landroidx/camera/lifecycle/e;->d:Landroidx/camera/lifecycle/LifecycleCameraRepository;

    return-void
.end method

.method public static a(Landroidx/camera/core/y;Landroidx/camera/lifecycle/e;Landroidx/concurrent/futures/b$a;)V
    .registers 6

    iget-object v0, p1, Landroidx/camera/lifecycle/e;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object p1, p1, Landroidx/camera/lifecycle/e;->c:Lcom/google/common/util/concurrent/o;

    invoke-static {p1}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object p1

    new-instance v1, Landroidx/camera/lifecycle/c;

    invoke-direct {v1, p0}, Landroidx/camera/lifecycle/c;-><init>(Landroidx/camera/core/y;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v1, v2}, Lv/f;->n(Lcom/google/common/util/concurrent/o;Lv/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    check-cast p1, Lv/d;

    new-instance v1, Landroidx/camera/lifecycle/d;

    invoke-direct {v1, p0, p2}, Landroidx/camera/lifecycle/d;-><init>(Landroidx/camera/core/y;Landroidx/concurrent/futures/b$a;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p0

    invoke-static {p1, v1, p0}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    monitor-exit v0

    return-void

    :catchall_29
    move-exception p0

    monitor-exit v0
    :try_end_2b
    .catchall {:try_start_3 .. :try_end_2b} :catchall_29

    throw p0
.end method

.method public static b(Landroid/content/Context;Landroidx/camera/core/y;)Landroidx/camera/lifecycle/e;
    .registers 3

    sget-object v0, Landroidx/camera/lifecycle/e;->f:Landroidx/camera/lifecycle/e;

    iput-object p1, v0, Landroidx/camera/lifecycle/e;->e:Landroidx/camera/core/y;

    invoke-static {p0}, Landroidx/camera/core/impl/utils/d;->a(Landroid/content/Context;)Landroid/content/Context;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0
.end method

.method public static e(Landroid/content/Context;)Lcom/google/common/util/concurrent/o;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Lcom/google/common/util/concurrent/o<",
            "Landroidx/camera/lifecycle/e;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/camera/lifecycle/e;->f:Landroidx/camera/lifecycle/e;

    iget-object v1, v0, Landroidx/camera/lifecycle/e;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_8
    iget-object v2, v0, Landroidx/camera/lifecycle/e;->b:Lcom/google/common/util/concurrent/o;

    if-eqz v2, :cond_10

    monitor-exit v1

    goto :goto_22

    :catchall_e
    move-exception p0

    goto :goto_30

    :cond_10
    new-instance v2, Landroidx/camera/core/y;

    invoke-direct {v2, p0}, Landroidx/camera/core/y;-><init>(Landroid/content/Context;)V

    new-instance v3, Landroidx/camera/core/e1;

    const/4 v4, 0x1

    invoke-direct {v3, v0, v2, v4}, Landroidx/camera/core/e1;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v3}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v2

    iput-object v2, v0, Landroidx/camera/lifecycle/e;->b:Lcom/google/common/util/concurrent/o;

    monitor-exit v1
    :try_end_22
    .catchall {:try_start_8 .. :try_end_22} :catchall_e

    :goto_22
    new-instance v0, Landroidx/camera/lifecycle/b;

    invoke-direct {v0, p0}, Landroidx/camera/lifecycle/b;-><init>(Landroid/content/Context;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p0

    invoke-static {v2, v0, p0}, Lv/f;->m(Lcom/google/common/util/concurrent/o;Lm/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p0

    return-object p0

    :goto_30
    :try_start_30
    monitor-exit v1
    :try_end_31
    .catchall {:try_start_30 .. :try_end_31} :catchall_e

    throw p0
.end method


# virtual methods
.method public final c(Landroidx/lifecycle/A;Landroidx/camera/core/s;Landroidx/camera/core/k1;)Landroidx/camera/core/l;
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v2, 0x1

    invoke-virtual/range {p3 .. p3}, Landroidx/camera/core/k1;->b()Landroidx/camera/core/q1;

    move-result-object v3

    invoke-virtual/range {p3 .. p3}, Landroidx/camera/core/k1;->a()Ljava/util/List;

    move-result-object v4

    const/4 v5, 0x0

    new-array v6, v5, [Landroidx/camera/core/j1;

    invoke-interface {v4, v6}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Landroidx/camera/core/j1;

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-static/range {p2 .. p2}, Landroidx/camera/core/s$a;->c(Landroidx/camera/core/s;)Landroidx/camera/core/s$a;

    move-result-object v6

    array-length v7, v4

    const/4 v8, 0x0

    :goto_1f
    if-ge v8, v7, :cond_47

    aget-object v9, v4, v8

    invoke-virtual {v9}, Landroidx/camera/core/j1;->f()Landroidx/camera/core/impl/E0;

    move-result-object v9

    invoke-interface {v9}, Landroidx/camera/core/impl/E0;->z()Landroidx/camera/core/s;

    move-result-object v9

    if-eqz v9, :cond_45

    invoke-virtual {v9}, Landroidx/camera/core/s;->c()Ljava/util/LinkedHashSet;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_35
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_45

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroidx/camera/core/q;

    invoke-virtual {v6, v10}, Landroidx/camera/core/s$a;->a(Landroidx/camera/core/q;)V

    goto :goto_35

    :cond_45
    add-int/2addr v8, v2

    goto :goto_1f

    :cond_47
    invoke-virtual {v6}, Landroidx/camera/core/s$a;->b()Landroidx/camera/core/s;

    move-result-object v6

    iget-object v7, v0, Landroidx/camera/lifecycle/e;->e:Landroidx/camera/core/y;

    invoke-virtual {v7}, Landroidx/camera/core/y;->e()Landroidx/camera/core/impl/y;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/camera/core/impl/y;->a()Ljava/util/LinkedHashSet;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroidx/camera/core/s;->a(Ljava/util/LinkedHashSet;)Ljava/util/LinkedHashSet;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_ee

    invoke-static {v6}, Lw/d;->r(Ljava/util/LinkedHashSet;)Lw/d$b;

    move-result-object v7

    iget-object v8, v0, Landroidx/camera/lifecycle/e;->d:Landroidx/camera/lifecycle/LifecycleCameraRepository;

    invoke-virtual {v8, v1, v7}, Landroidx/camera/lifecycle/LifecycleCameraRepository;->c(Landroidx/lifecycle/A;Lw/d$b;)Landroidx/camera/lifecycle/LifecycleCamera;

    move-result-object v7

    invoke-virtual {v8}, Landroidx/camera/lifecycle/LifecycleCameraRepository;->e()Ljava/util/Collection;

    move-result-object v9

    array-length v10, v4

    const/4 v11, 0x0

    :goto_6f
    if-ge v11, v10, :cond_9e

    aget-object v12, v4, v11

    invoke-interface {v9}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :cond_77
    :goto_77
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_9c

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/camera/lifecycle/LifecycleCamera;

    invoke-virtual {v14, v12}, Landroidx/camera/lifecycle/LifecycleCamera;->o(Landroidx/camera/core/j1;)Z

    move-result v15

    if-eqz v15, :cond_77

    if-ne v14, v7, :cond_8c

    goto :goto_77

    :cond_8c
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v3, "Use case %s already bound to a different lifecycle."

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v12, v2, v5

    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_9c
    add-int/2addr v11, v2

    goto :goto_6f

    :cond_9e
    if-nez v7, :cond_b5

    new-instance v2, Lw/d;

    iget-object v5, v0, Landroidx/camera/lifecycle/e;->e:Landroidx/camera/core/y;

    invoke-virtual {v5}, Landroidx/camera/core/y;->d()Landroidx/camera/core/impl/u;

    move-result-object v5

    iget-object v7, v0, Landroidx/camera/lifecycle/e;->e:Landroidx/camera/core/y;

    invoke-virtual {v7}, Landroidx/camera/core/y;->f()Landroidx/camera/core/impl/F0;

    move-result-object v7

    invoke-direct {v2, v6, v5, v7}, Lw/d;-><init>(Ljava/util/LinkedHashSet;Landroidx/camera/core/impl/u;Landroidx/camera/core/impl/F0;)V

    invoke-virtual {v8, v1, v2}, Landroidx/camera/lifecycle/LifecycleCameraRepository;->b(Landroidx/lifecycle/A;Lw/d;)Landroidx/camera/lifecycle/LifecycleCamera;

    move-result-object v7

    :cond_b5
    invoke-virtual/range {p2 .. p2}, Landroidx/camera/core/s;->c()Ljava/util/LinkedHashSet;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_bd
    :goto_bd
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_dc

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/q;

    invoke-interface {v2}, Landroidx/camera/core/q;->getIdentifier()Landroidx/camera/core/impl/T;

    move-result-object v5

    sget-object v6, Landroidx/camera/core/q;->a:Landroidx/camera/core/impl/T;

    if-eq v5, v6, :cond_bd

    invoke-interface {v2}, Landroidx/camera/core/q;->getIdentifier()Landroidx/camera/core/impl/T;

    move-result-object v2

    invoke-static {v2}, Landroidx/camera/core/impl/S;->a(Ljava/lang/Object;)Landroidx/camera/core/impl/r;

    invoke-virtual {v7}, Landroidx/camera/lifecycle/LifecycleCamera;->a()Landroidx/camera/core/r;

    goto :goto_bd

    :cond_dc
    const/4 v1, 0x0

    invoke-virtual {v7, v1}, Landroidx/camera/lifecycle/LifecycleCamera;->j(Landroidx/camera/core/impl/p;)V

    array-length v1, v4

    if-nez v1, :cond_e4

    goto :goto_ed

    :cond_e4
    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-virtual {v8, v7, v3, v1}, Landroidx/camera/lifecycle/LifecycleCameraRepository;->a(Landroidx/camera/lifecycle/LifecycleCamera;Landroidx/camera/core/q1;Ljava/util/List;)V

    :goto_ed
    return-object v7

    :cond_ee
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Provided camera selector unable to resolve a camera for the given use case"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final d()Ljava/util/ArrayList;
    .registers 4

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Landroidx/camera/lifecycle/e;->e:Landroidx/camera/core/y;

    invoke-virtual {v1}, Landroidx/camera/core/y;->e()Landroidx/camera/core/impl/y;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/camera/core/impl/y;->a()Ljava/util/LinkedHashSet;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_27

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/impl/x;

    invoke-interface {v2}, Landroidx/camera/core/impl/x;->a()Landroidx/camera/core/r;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_13

    :cond_27
    return-object v0
.end method

.method public final f(Landroidx/camera/core/j1;)Z
    .registers 4

    iget-object v0, p0, Landroidx/camera/lifecycle/e;->d:Landroidx/camera/lifecycle/LifecycleCameraRepository;

    invoke-virtual {v0}, Landroidx/camera/lifecycle/LifecycleCameraRepository;->e()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/lifecycle/LifecycleCamera;

    invoke-virtual {v1, p1}, Landroidx/camera/lifecycle/LifecycleCamera;->o(Landroidx/camera/core/j1;)Z

    move-result v1

    if-eqz v1, :cond_a

    const/4 p1, 0x1

    return p1

    :cond_1e
    const/4 p1, 0x0

    return p1
.end method

.method public final varargs g([Landroidx/camera/core/j1;)V
    .registers 3

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    iget-object v0, p0, Landroidx/camera/lifecycle/e;->d:Landroidx/camera/lifecycle/LifecycleCameraRepository;

    invoke-virtual {v0, p1}, Landroidx/camera/lifecycle/LifecycleCameraRepository;->k(Ljava/util/List;)V

    return-void
.end method

.method public final h()V
    .registers 2

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    iget-object v0, p0, Landroidx/camera/lifecycle/e;->d:Landroidx/camera/lifecycle/LifecycleCameraRepository;

    invoke-virtual {v0}, Landroidx/camera/lifecycle/LifecycleCameraRepository;->l()V

    return-void
.end method
