.class final Landroidx/camera/lifecycle/d;
.super Ljava/lang/Object;
.source "ProcessCameraProvider.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/concurrent/futures/b$a;

.field final synthetic b:Landroidx/camera/core/y;


# direct methods
.method constructor <init>(Landroidx/camera/core/y;Landroidx/concurrent/futures/b$a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/camera/lifecycle/d;->a:Landroidx/concurrent/futures/b$a;

    iput-object p1, p0, Landroidx/camera/lifecycle/d;->b:Landroidx/camera/core/y;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/lifecycle/d;->a:Landroidx/concurrent/futures/b$a;

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/b$a;->e(Ljava/lang/Throwable;)Z

    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Ljava/lang/Void;

    iget-object p1, p0, Landroidx/camera/lifecycle/d;->a:Landroidx/concurrent/futures/b$a;

    iget-object v0, p0, Landroidx/camera/lifecycle/d;->b:Landroidx/camera/core/y;

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    return-void
.end method
