.class final Landroidx/camera/lifecycle/LifecycleCamera;
.super Ljava/lang/Object;
.source "LifecycleCamera.java"

# interfaces
.implements Landroidx/lifecycle/z;
.implements Landroidx/camera/core/l;


# instance fields
.field private final a:Ljava/lang/Object;

.field private final b:Landroidx/lifecycle/A;

.field private final c:Lw/d;

.field private d:Z


# direct methods
.method constructor <init>(Landroidx/lifecycle/A;Lw/d;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->d:Z

    iput-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->b:Landroidx/lifecycle/A;

    iput-object p2, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-interface {p1}, Landroidx/lifecycle/A;->getLifecycle()Landroidx/lifecycle/q;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/lifecycle/q;->b()Landroidx/lifecycle/q$b;

    move-result-object v0

    sget-object v1, Landroidx/lifecycle/q$b;->STARTED:Landroidx/lifecycle/q$b;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/q$b;->a(Landroidx/lifecycle/q$b;)Z

    move-result v0

    if-eqz v0, :cond_25

    invoke-virtual {p2}, Lw/d;->d()V

    goto :goto_28

    :cond_25
    invoke-virtual {p2}, Lw/d;->q()V

    :goto_28
    invoke-interface {p1}, Landroidx/lifecycle/A;->getLifecycle()Landroidx/lifecycle/q;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroidx/lifecycle/q;->a(Landroidx/lifecycle/z;)V

    return-void
.end method


# virtual methods
.method public final a()Landroidx/camera/core/r;
    .registers 2

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v0}, Lw/d;->a()Landroidx/camera/core/r;

    move-result-object v0

    return-object v0
.end method

.method public final b()Landroidx/camera/core/n;
    .registers 2

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v0}, Lw/d;->b()Landroidx/camera/core/n;

    move-result-object v0

    return-object v0
.end method

.method final c(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lw/d$a;
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    check-cast p1, Ljava/util/List;

    invoke-virtual {v1, p1}, Lw/d;->c(Ljava/util/List;)V

    monitor-exit v0

    return-void

    :catchall_c
    move-exception p1

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_c

    throw p1
.end method

.method public final d()Lw/d;
    .registers 2

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    return-object v0
.end method

.method public final j(Landroidx/camera/core/impl/p;)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v0, p1}, Lw/d;->j(Landroidx/camera/core/impl/p;)V

    return-void
.end method

.method public final m()Landroidx/lifecycle/A;
    .registers 3

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->b:Landroidx/lifecycle/A;

    monitor-exit v0

    return-object v1

    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public final n()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/camera/core/j1;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v1}, Lw/d;->t()Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    monitor-exit v0

    return-object v1

    :catchall_f
    move-exception v1

    monitor-exit v0
    :try_end_11
    .catchall {:try_start_3 .. :try_end_11} :catchall_f

    throw v1
.end method

.method public final o(Landroidx/camera/core/j1;)Z
    .registers 4

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v1}, Lw/d;->t()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    monitor-exit v0

    return p1

    :catchall_11
    move-exception p1

    monitor-exit v0
    :try_end_13
    .catchall {:try_start_3 .. :try_end_13} :catchall_11

    throw p1
.end method

.method public onDestroy(Landroidx/lifecycle/A;)V
    .registers 4
    .annotation runtime Landroidx/lifecycle/K;
        value = .enum Landroidx/lifecycle/q$a;->ON_DESTROY:Landroidx/lifecycle/q$a;
    .end annotation

    iget-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_3
    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v0}, Lw/d;->t()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Lw/d;->v(Ljava/util/ArrayList;)V

    monitor-exit p1

    return-void

    :catchall_10
    move-exception v0

    monitor-exit p1
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_10

    throw v0
.end method

.method public onPause(Landroidx/lifecycle/A;)V
    .registers 3
    .annotation runtime Landroidx/lifecycle/K;
        value = .enum Landroidx/lifecycle/q$a;->ON_PAUSE:Landroidx/lifecycle/q$a;
    .end annotation

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x18

    if-lt p1, v0, :cond_c

    iget-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lw/d;->g(Z)V

    :cond_c
    return-void
.end method

.method public onResume(Landroidx/lifecycle/A;)V
    .registers 3
    .annotation runtime Landroidx/lifecycle/K;
        value = .enum Landroidx/lifecycle/q$a;->ON_RESUME:Landroidx/lifecycle/q$a;
    .end annotation

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x18

    if-lt p1, v0, :cond_c

    iget-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lw/d;->g(Z)V

    :cond_c
    return-void
.end method

.method public onStart(Landroidx/lifecycle/A;)V
    .registers 3
    .annotation runtime Landroidx/lifecycle/K;
        value = .enum Landroidx/lifecycle/q$a;->ON_START:Landroidx/lifecycle/q$a;
    .end annotation

    iget-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_3
    iget-boolean v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->d:Z

    if-nez v0, :cond_f

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v0}, Lw/d;->d()V

    goto :goto_f

    :catchall_d
    move-exception v0

    goto :goto_11

    :cond_f
    :goto_f
    monitor-exit p1

    return-void

    :goto_11
    monitor-exit p1
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_d

    throw v0
.end method

.method public onStop(Landroidx/lifecycle/A;)V
    .registers 3
    .annotation runtime Landroidx/lifecycle/K;
        value = .enum Landroidx/lifecycle/q$a;->ON_STOP:Landroidx/lifecycle/q$a;
    .end annotation

    iget-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter p1

    :try_start_3
    iget-boolean v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->d:Z

    if-nez v0, :cond_f

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v0}, Lw/d;->q()V

    goto :goto_f

    :catchall_d
    move-exception v0

    goto :goto_11

    :cond_f
    :goto_f
    monitor-exit p1

    return-void

    :goto_11
    monitor-exit p1
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_d

    throw v0
.end method

.method public final p()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->d:Z

    if-eqz v1, :cond_b

    monitor-exit v0

    return-void

    :catchall_9
    move-exception v1

    goto :goto_15

    :cond_b
    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->b:Landroidx/lifecycle/A;

    invoke-virtual {p0, v1}, Landroidx/camera/lifecycle/LifecycleCamera;->onStop(Landroidx/lifecycle/A;)V

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->d:Z

    monitor-exit v0

    return-void

    :goto_15
    monitor-exit v0
    :try_end_16
    .catchall {:try_start_3 .. :try_end_16} :catchall_9

    throw v1
.end method

.method final q(Ljava/util/List;)V
    .registers 4

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {p1}, Lw/d;->t()Ljava/util/List;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->retainAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {p1, v1}, Lw/d;->v(Ljava/util/ArrayList;)V

    monitor-exit v0

    return-void

    :catchall_18
    move-exception p1

    monitor-exit v0
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_18

    throw p1
.end method

.method final r()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->c:Lw/d;

    invoke-virtual {v1}, Lw/d;->t()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Lw/d;->v(Ljava/util/ArrayList;)V

    monitor-exit v0

    return-void

    :catchall_10
    move-exception v1

    monitor-exit v0
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_10

    throw v1
.end method

.method public final s()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/lifecycle/LifecycleCamera;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->d:Z

    if-nez v1, :cond_b

    monitor-exit v0

    return-void

    :catchall_9
    move-exception v1

    goto :goto_27

    :cond_b
    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->d:Z

    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->b:Landroidx/lifecycle/A;

    invoke-interface {v1}, Landroidx/lifecycle/A;->getLifecycle()Landroidx/lifecycle/q;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/lifecycle/q;->b()Landroidx/lifecycle/q$b;

    move-result-object v1

    sget-object v2, Landroidx/lifecycle/q$b;->STARTED:Landroidx/lifecycle/q$b;

    invoke-virtual {v1, v2}, Landroidx/lifecycle/q$b;->a(Landroidx/lifecycle/q$b;)Z

    move-result v1

    if-eqz v1, :cond_25

    iget-object v1, p0, Landroidx/camera/lifecycle/LifecycleCamera;->b:Landroidx/lifecycle/A;

    invoke-virtual {p0, v1}, Landroidx/camera/lifecycle/LifecycleCamera;->onStart(Landroidx/lifecycle/A;)V

    :cond_25
    monitor-exit v0

    return-void

    :goto_27
    monitor-exit v0
    :try_end_28
    .catchall {:try_start_3 .. :try_end_28} :catchall_9

    throw v1
.end method
