.class final Landroidx/camera/lifecycle/a;
.super Landroidx/camera/lifecycle/LifecycleCameraRepository$a;
.source "AutoValue_LifecycleCameraRepository_Key.java"


# instance fields
.field private final a:Landroidx/lifecycle/A;

.field private final b:Lw/d$b;


# direct methods
.method constructor <init>(Landroidx/lifecycle/A;Lw/d$b;)V
    .registers 3

    invoke-direct {p0}, Landroidx/camera/lifecycle/LifecycleCameraRepository$a;-><init>()V

    if-eqz p1, :cond_14

    iput-object p1, p0, Landroidx/camera/lifecycle/a;->a:Landroidx/lifecycle/A;

    if-eqz p2, :cond_c

    iput-object p2, p0, Landroidx/camera/lifecycle/a;->b:Lw/d$b;

    return-void

    :cond_c
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null cameraId"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_14
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "Null lifecycleOwner"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()Lw/d$b;
    .registers 2

    iget-object v0, p0, Landroidx/camera/lifecycle/a;->b:Lw/d$b;

    return-object v0
.end method

.method public final b()Landroidx/lifecycle/A;
    .registers 2

    iget-object v0, p0, Landroidx/camera/lifecycle/a;->a:Landroidx/lifecycle/A;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Landroidx/camera/lifecycle/LifecycleCameraRepository$a;

    const/4 v2, 0x0

    if-eqz v1, :cond_26

    check-cast p1, Landroidx/camera/lifecycle/LifecycleCameraRepository$a;

    invoke-virtual {p1}, Landroidx/camera/lifecycle/LifecycleCameraRepository$a;->b()Landroidx/lifecycle/A;

    move-result-object v1

    iget-object v3, p0, Landroidx/camera/lifecycle/a;->a:Landroidx/lifecycle/A;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_24

    iget-object v1, p0, Landroidx/camera/lifecycle/a;->b:Lw/d$b;

    invoke-virtual {p1}, Landroidx/camera/lifecycle/LifecycleCameraRepository$a;->a()Lw/d$b;

    move-result-object p1

    invoke-virtual {v1, p1}, Lw/d$b;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_24

    goto :goto_25

    :cond_24
    const/4 v0, 0x0

    :goto_25
    return v0

    :cond_26
    return v2
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Landroidx/camera/lifecycle/a;->a:Landroidx/lifecycle/A;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int v0, v0, v1

    iget-object v1, p0, Landroidx/camera/lifecycle/a;->b:Lw/d$b;

    invoke-virtual {v1}, Lw/d$b;->hashCode()I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Key{lifecycleOwner="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/lifecycle/a;->a:Landroidx/lifecycle/A;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", cameraId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/camera/lifecycle/a;->b:Lw/d$b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
