.class public final enum Landroidx/camera/view/PreviewView$f;
.super Ljava/lang/Enum;
.source "PreviewView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/view/PreviewView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/view/PreviewView$f;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/view/PreviewView$f;

.field public static final enum FILL_CENTER:Landroidx/camera/view/PreviewView$f;

.field public static final enum FILL_END:Landroidx/camera/view/PreviewView$f;

.field public static final enum FILL_START:Landroidx/camera/view/PreviewView$f;

.field public static final enum FIT_CENTER:Landroidx/camera/view/PreviewView$f;

.field public static final enum FIT_END:Landroidx/camera/view/PreviewView$f;

.field public static final enum FIT_START:Landroidx/camera/view/PreviewView$f;


# instance fields
.field private final mId:I


# direct methods
.method static constructor <clinit>()V
    .registers 13

    new-instance v0, Landroidx/camera/view/PreviewView$f;

    const-string v1, "FILL_START"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Landroidx/camera/view/PreviewView$f;-><init>(Ljava/lang/String;II)V

    sput-object v0, Landroidx/camera/view/PreviewView$f;->FILL_START:Landroidx/camera/view/PreviewView$f;

    new-instance v1, Landroidx/camera/view/PreviewView$f;

    const-string v3, "FILL_CENTER"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Landroidx/camera/view/PreviewView$f;-><init>(Ljava/lang/String;II)V

    sput-object v1, Landroidx/camera/view/PreviewView$f;->FILL_CENTER:Landroidx/camera/view/PreviewView$f;

    new-instance v3, Landroidx/camera/view/PreviewView$f;

    const-string v5, "FILL_END"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Landroidx/camera/view/PreviewView$f;-><init>(Ljava/lang/String;II)V

    sput-object v3, Landroidx/camera/view/PreviewView$f;->FILL_END:Landroidx/camera/view/PreviewView$f;

    new-instance v5, Landroidx/camera/view/PreviewView$f;

    const-string v7, "FIT_START"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Landroidx/camera/view/PreviewView$f;-><init>(Ljava/lang/String;II)V

    sput-object v5, Landroidx/camera/view/PreviewView$f;->FIT_START:Landroidx/camera/view/PreviewView$f;

    new-instance v7, Landroidx/camera/view/PreviewView$f;

    const-string v9, "FIT_CENTER"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Landroidx/camera/view/PreviewView$f;-><init>(Ljava/lang/String;II)V

    sput-object v7, Landroidx/camera/view/PreviewView$f;->FIT_CENTER:Landroidx/camera/view/PreviewView$f;

    new-instance v9, Landroidx/camera/view/PreviewView$f;

    const-string v11, "FIT_END"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Landroidx/camera/view/PreviewView$f;-><init>(Ljava/lang/String;II)V

    sput-object v9, Landroidx/camera/view/PreviewView$f;->FIT_END:Landroidx/camera/view/PreviewView$f;

    const/4 v11, 0x6

    new-array v11, v11, [Landroidx/camera/view/PreviewView$f;

    aput-object v0, v11, v2

    aput-object v1, v11, v4

    aput-object v3, v11, v6

    aput-object v5, v11, v8

    aput-object v7, v11, v10

    aput-object v9, v11, v12

    sput-object v11, Landroidx/camera/view/PreviewView$f;->$VALUES:[Landroidx/camera/view/PreviewView$f;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Landroidx/camera/view/PreviewView$f;->mId:I

    return-void
.end method

.method static a(I)Landroidx/camera/view/PreviewView$f;
    .registers 6

    invoke-static {}, Landroidx/camera/view/PreviewView$f;->values()[Landroidx/camera/view/PreviewView$f;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_12

    aget-object v3, v0, v2

    iget v4, v3, Landroidx/camera/view/PreviewView$f;->mId:I

    if-ne v4, p0, :cond_f

    return-object v3

    :cond_f
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_12
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unknown scale type id "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/view/PreviewView$f;
    .registers 2

    const-class v0, Landroidx/camera/view/PreviewView$f;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/view/PreviewView$f;

    return-object p0
.end method

.method public static values()[Landroidx/camera/view/PreviewView$f;
    .registers 1

    sget-object v0, Landroidx/camera/view/PreviewView$f;->$VALUES:[Landroidx/camera/view/PreviewView$f;

    invoke-virtual {v0}, [Landroidx/camera/view/PreviewView$f;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/view/PreviewView$f;

    return-object v0
.end method


# virtual methods
.method final b()I
    .registers 2

    iget v0, p0, Landroidx/camera/view/PreviewView$f;->mId:I

    return v0
.end method
