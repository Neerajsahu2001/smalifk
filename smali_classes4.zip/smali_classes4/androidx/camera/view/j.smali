.class final Landroidx/camera/view/j;
.super Ljava/lang/Object;
.source "PreviewTransformation.java"


# static fields
.field private static final g:Landroidx/camera/view/PreviewView$f;


# instance fields
.field private a:Landroid/util/Size;

.field private b:Landroid/graphics/Rect;

.field private c:I

.field private d:I

.field private e:Z

.field private f:Landroidx/camera/view/PreviewView$f;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Landroidx/camera/view/PreviewView$f;->FILL_CENTER:Landroidx/camera/view/PreviewView$f;

    sput-object v0, Landroidx/camera/view/j;->g:Landroidx/camera/view/PreviewView$f;

    return-void
.end method

.method constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Landroidx/camera/view/j;->g:Landroidx/camera/view/PreviewView$f;

    iput-object v0, p0, Landroidx/camera/view/j;->f:Landroidx/camera/view/PreviewView$f;

    return-void
.end method

.method private b()Landroid/util/Size;
    .registers 4

    iget v0, p0, Landroidx/camera/view/j;->c:I

    invoke-static {v0}, Landroidx/camera/view/D;->b(I)Z

    move-result v0

    if-eqz v0, :cond_1a

    new-instance v0, Landroid/util/Size;

    iget-object v1, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v1

    iget-object v2, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v2

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    return-object v0

    :cond_1a
    new-instance v0, Landroid/util/Size;

    iget-object v1, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    iget-object v2, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    return-object v0
.end method

.method private e()Z
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    if-eqz v0, :cond_f

    iget-object v0, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    if-eqz v0, :cond_f

    iget v0, p0, Landroidx/camera/view/j;->d:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_f

    const/4 v0, 0x1

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    return v0
.end method


# virtual methods
.method final a(ILandroid/util/Size;)Landroid/graphics/Matrix;
    .registers 7

    invoke-direct {p0}, Landroidx/camera/view/j;->e()Z

    move-result v0

    if-nez v0, :cond_8

    const/4 p1, 0x0

    return-object p1

    :cond_8
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    invoke-virtual {p0, p1, p2}, Landroidx/camera/view/j;->d(ILandroid/util/Size;)Landroid/graphics/Matrix;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->invert(Landroid/graphics/Matrix;)Z

    new-instance p1, Landroid/graphics/Matrix;

    invoke-direct {p1}, Landroid/graphics/Matrix;-><init>()V

    new-instance p2, Landroid/graphics/RectF;

    iget-object v1, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v1}, Landroid/util/Size;->getWidth()I

    move-result v1

    int-to-float v1, v1

    iget-object v2, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v2}, Landroid/util/Size;->getHeight()I

    move-result v2

    int-to-float v2, v2

    const/4 v3, 0x0

    invoke-direct {p2, v3, v3, v1, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    new-instance v1, Landroid/graphics/RectF;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v1, v3, v3, v2, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    sget-object v2, Landroid/graphics/Matrix$ScaleToFit;->FILL:Landroid/graphics/Matrix$ScaleToFit;

    invoke-virtual {p1, p2, v1, v2}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->postConcat(Landroid/graphics/Matrix;)Z

    return-object v0
.end method

.method final c()Landroidx/camera/view/PreviewView$f;
    .registers 2

    iget-object v0, p0, Landroidx/camera/view/j;->f:Landroidx/camera/view/PreviewView$f;

    return-object v0
.end method

.method final d(ILandroid/util/Size;)Landroid/graphics/Matrix;
    .registers 10

    invoke-direct {p0}, Landroidx/camera/view/j;->e()Z

    move-result v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    invoke-direct {p0}, Landroidx/camera/view/j;->b()Landroid/util/Size;

    move-result-object v0

    invoke-virtual {p2}, Landroid/util/Size;->getWidth()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p2}, Landroid/util/Size;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x3f800000    # 1.0f

    add-float/2addr v2, v3

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v4, v3

    div-float/2addr v2, v4

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v4, v3

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr v0, v3

    div-float/2addr v4, v0

    const/4 v0, 0x0

    cmpl-float v4, v1, v4

    if-ltz v4, :cond_4d

    cmpl-float v1, v2, v1

    if-ltz v1, :cond_4d

    new-instance p1, Landroid/graphics/RectF;

    invoke-virtual {p2}, Landroid/util/Size;->getWidth()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p2}, Landroid/util/Size;->getHeight()I

    move-result p2

    int-to-float p2, p2

    invoke-direct {p1, v0, v0, v1, p2}, Landroid/graphics/RectF;-><init>(FFFF)V

    goto/16 :goto_d8

    :cond_4d
    new-instance v1, Landroid/graphics/RectF;

    invoke-virtual {p2}, Landroid/util/Size;->getWidth()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {p2}, Landroid/util/Size;->getHeight()I

    move-result v4

    int-to-float v4, v4

    invoke-direct {v1, v0, v0, v2, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-direct {p0}, Landroidx/camera/view/j;->b()Landroid/util/Size;

    move-result-object v2

    new-instance v4, Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/util/Size;->getWidth()I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v2}, Landroid/util/Size;->getHeight()I

    move-result v2

    int-to-float v2, v2

    invoke-direct {v4, v0, v0, v5, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iget-object v2, p0, Landroidx/camera/view/j;->f:Landroidx/camera/view/PreviewView$f;

    sget-object v5, Landroidx/camera/view/j$a;->a:[I

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    aget v5, v5, v6

    packed-switch v5, :pswitch_data_118

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Unexpected crop rect: "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, "PreviewTransform"

    invoke-static {v6, v5}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v5, Landroid/graphics/Matrix$ScaleToFit;->FILL:Landroid/graphics/Matrix$ScaleToFit;

    goto :goto_9f

    :pswitch_97
    sget-object v5, Landroid/graphics/Matrix$ScaleToFit;->START:Landroid/graphics/Matrix$ScaleToFit;

    goto :goto_9f

    :pswitch_9a
    sget-object v5, Landroid/graphics/Matrix$ScaleToFit;->END:Landroid/graphics/Matrix$ScaleToFit;

    goto :goto_9f

    :pswitch_9d
    sget-object v5, Landroid/graphics/Matrix$ScaleToFit;->CENTER:Landroid/graphics/Matrix$ScaleToFit;

    :goto_9f
    sget-object v6, Landroidx/camera/view/PreviewView$f;->FIT_CENTER:Landroidx/camera/view/PreviewView$f;

    if-eq v2, v6, :cond_b3

    sget-object v6, Landroidx/camera/view/PreviewView$f;->FIT_START:Landroidx/camera/view/PreviewView$f;

    if-eq v2, v6, :cond_b3

    sget-object v6, Landroidx/camera/view/PreviewView$f;->FIT_END:Landroidx/camera/view/PreviewView$f;

    if-ne v2, v6, :cond_ac

    goto :goto_b3

    :cond_ac
    invoke-virtual {v0, v1, v4, v5}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    invoke-virtual {v0, v0}, Landroid/graphics/Matrix;->invert(Landroid/graphics/Matrix;)Z

    goto :goto_b6

    :cond_b3
    :goto_b3
    invoke-virtual {v0, v4, v1, v5}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    :goto_b6
    invoke-virtual {v0, v4}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    const/4 v0, 0x1

    if-ne p1, v0, :cond_d7

    invoke-virtual {p2}, Landroid/util/Size;->getWidth()I

    move-result p1

    int-to-float p1, p1

    const/high16 p2, 0x40000000    # 2.0f

    div-float/2addr p1, p2

    new-instance p2, Landroid/graphics/RectF;

    add-float/2addr p1, p1

    iget v0, v4, Landroid/graphics/RectF;->right:F

    sub-float v0, p1, v0

    iget v1, v4, Landroid/graphics/RectF;->top:F

    iget v2, v4, Landroid/graphics/RectF;->left:F

    sub-float/2addr p1, v2

    iget v2, v4, Landroid/graphics/RectF;->bottom:F

    invoke-direct {p2, v0, v1, p1, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    move-object p1, p2

    goto :goto_d8

    :cond_d7
    move-object p1, v4

    :goto_d8
    new-instance p2, Landroid/graphics/RectF;

    iget-object v0, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-direct {p2, v0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    iget v0, p0, Landroidx/camera/view/j;->c:I

    invoke-static {p2, p1, v0}, Landroidx/camera/view/D;->a(Landroid/graphics/RectF;Landroid/graphics/RectF;I)Landroid/graphics/Matrix;

    move-result-object p1

    iget-boolean p2, p0, Landroidx/camera/view/j;->e:Z

    if-eqz p2, :cond_116

    iget p2, p0, Landroidx/camera/view/j;->c:I

    invoke-static {p2}, Landroidx/camera/view/D;->b(I)Z

    move-result p2

    const/high16 v0, -0x40800000    # -1.0f

    if-eqz p2, :cond_105

    iget-object p2, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {p2}, Landroid/graphics/Rect;->centerX()I

    move-result p2

    int-to-float p2, p2

    iget-object v1, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->centerY()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p1, v3, v0, p2, v1}, Landroid/graphics/Matrix;->preScale(FFFF)Z

    goto :goto_116

    :cond_105
    iget-object p2, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {p2}, Landroid/graphics/Rect;->centerX()I

    move-result p2

    int-to-float p2, p2

    iget-object v1, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->centerY()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p1, v0, v3, p2, v1}, Landroid/graphics/Matrix;->preScale(FFFF)Z

    :cond_116
    :goto_116
    return-object p1

    nop

    :pswitch_data_118
    .packed-switch 0x1
        :pswitch_9d
        :pswitch_9d
        :pswitch_9a
        :pswitch_9a
        :pswitch_97
        :pswitch_97
    .end packed-switch
.end method

.method final f(II)V
    .registers 3

    iput p1, p0, Landroidx/camera/view/j;->c:I

    iput p2, p0, Landroidx/camera/view/j;->d:I

    return-void
.end method

.method final g(Landroidx/camera/view/PreviewView$f;)V
    .registers 2

    iput-object p1, p0, Landroidx/camera/view/j;->f:Landroidx/camera/view/PreviewView$f;

    return-void
.end method

.method final h(Landroidx/camera/core/i1$g;Landroid/util/Size;Z)V
    .registers 6

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Transformation info set: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "PreviewTransform"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, Landroidx/camera/core/i1$g;->a()Landroid/graphics/Rect;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/view/j;->b:Landroid/graphics/Rect;

    invoke-virtual {p1}, Landroidx/camera/core/i1$g;->b()I

    move-result v0

    iput v0, p0, Landroidx/camera/view/j;->c:I

    invoke-virtual {p1}, Landroidx/camera/core/i1$g;->c()I

    move-result p1

    iput p1, p0, Landroidx/camera/view/j;->d:I

    iput-object p2, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    iput-boolean p3, p0, Landroidx/camera/view/j;->e:Z

    return-void
.end method

.method final i(Landroid/util/Size;ILandroid/view/View;)V
    .registers 10

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result v0

    const-string v1, "PreviewTransform"

    if-eqz v0, :cond_df

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result v0

    if-nez v0, :cond_10

    goto/16 :goto_df

    :cond_10
    invoke-direct {p0}, Landroidx/camera/view/j;->e()Z

    move-result v0

    if-nez v0, :cond_17

    return-void

    :cond_17
    instance-of v0, p3, Landroid/view/TextureView;

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_70

    move-object v0, p3

    check-cast v0, Landroid/view/TextureView;

    invoke-direct {p0}, Landroidx/camera/view/j;->e()Z

    move-result v1

    invoke-static {v1, v2}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    new-instance v1, Landroid/graphics/RectF;

    iget-object v4, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v4}, Landroid/util/Size;->getWidth()I

    move-result v4

    int-to-float v4, v4

    iget-object v5, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v5}, Landroid/util/Size;->getHeight()I

    move-result v5

    int-to-float v5, v5

    invoke-direct {v1, v3, v3, v4, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget v4, p0, Landroidx/camera/view/j;->d:I

    sget-object v5, Landroidx/camera/view/D;->a:Landroid/graphics/RectF;

    if-eqz v4, :cond_66

    const/4 v5, 0x1

    if-eq v4, v5, :cond_63

    const/4 v5, 0x2

    if-eq v4, v5, :cond_60

    const/4 v5, 0x3

    if-ne v4, v5, :cond_4c

    const/16 v4, 0x10e

    goto :goto_67

    :cond_4c
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Unexpected rotation value "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_60
    const/16 v4, 0xb4

    goto :goto_67

    :cond_63
    const/16 v4, 0x5a

    goto :goto_67

    :cond_66
    const/4 v4, 0x0

    :goto_67
    neg-int v4, v4

    invoke-static {v1, v1, v4}, Landroidx/camera/view/D;->a(Landroid/graphics/RectF;Landroid/graphics/RectF;I)Landroid/graphics/Matrix;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/TextureView;->setTransform(Landroid/graphics/Matrix;)V

    goto :goto_83

    :cond_70
    invoke-virtual {p3}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v0

    if-eqz v0, :cond_83

    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    move-result v0

    iget v4, p0, Landroidx/camera/view/j;->d:I

    if-eq v0, v4, :cond_83

    const-string v0, "Non-display rotation not supported with SurfaceView / PERFORMANCE mode."

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_83
    :goto_83
    invoke-direct {p0}, Landroidx/camera/view/j;->e()Z

    move-result v0

    invoke-static {v0, v2}, Landroidx/core/util/g;->f(ZLjava/lang/String;)V

    invoke-virtual {p0, p2, p1}, Landroidx/camera/view/j;->d(ILandroid/util/Size;)Landroid/graphics/Matrix;

    move-result-object p1

    new-instance p2, Landroid/graphics/RectF;

    iget-object v0, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v0

    int-to-float v0, v0

    iget-object v1, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v1}, Landroid/util/Size;->getHeight()I

    move-result v1

    int-to-float v1, v1

    invoke-direct {p2, v3, v3, v0, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {p1, p2}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    invoke-virtual {p3, v3}, Landroid/view/View;->setPivotX(F)V

    invoke-virtual {p3, v3}, Landroid/view/View;->setPivotY(F)V

    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result p1

    iget-object v0, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr p1, v0

    invoke-virtual {p3, p1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result p1

    iget-object v0, p0, Landroidx/camera/view/j;->a:Landroid/util/Size;

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr p1, v0

    invoke-virtual {p3, p1}, Landroid/view/View;->setScaleY(F)V

    iget p1, p2, Landroid/graphics/RectF;->left:F

    invoke-virtual {p3}, Landroid/view/View;->getLeft()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr p1, v0

    invoke-virtual {p3, p1}, Landroid/view/View;->setTranslationX(F)V

    iget p1, p2, Landroid/graphics/RectF;->top:F

    invoke-virtual {p3}, Landroid/view/View;->getTop()I

    move-result p2

    int-to-float p2, p2

    sub-float/2addr p1, p2

    invoke-virtual {p3, p1}, Landroid/view/View;->setTranslationY(F)V

    return-void

    :cond_df
    :goto_df
    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Transform not applied due to PreviewView size: "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
