.class public final synthetic Landroidx/camera/view/t;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/view/v;

.field public final synthetic b:Landroidx/camera/core/i1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/v;Landroidx/camera/core/i1;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/t;->a:Landroidx/camera/view/v;

    iput-object p2, p0, Landroidx/camera/view/t;->b:Landroidx/camera/core/i1;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/t;->a:Landroidx/camera/view/v;

    iget-object v0, v0, Landroidx/camera/view/v;->f:Landroidx/camera/view/v$a;

    iget-object v1, p0, Landroidx/camera/view/t;->b:Landroidx/camera/core/i1;

    invoke-virtual {v0, v1}, Landroidx/camera/view/v$a;->b(Landroidx/camera/core/i1;)V

    return-void
.end method
