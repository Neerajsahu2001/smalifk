.class final Landroidx/camera/view/RotationProvider$a;
.super Landroid/view/OrientationEventListener;
.source "RotationProvider.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/camera/view/RotationProvider;-><init>(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private a:I

.field final synthetic b:Landroidx/camera/view/RotationProvider;


# direct methods
.method constructor <init>(Landroidx/camera/view/RotationProvider;Landroid/content/Context;)V
    .registers 3

    iput-object p1, p0, Landroidx/camera/view/RotationProvider$a;->b:Landroidx/camera/view/RotationProvider;

    invoke-direct {p0, p2}, Landroid/view/OrientationEventListener;-><init>(Landroid/content/Context;)V

    const/4 p1, -0x1

    iput p1, p0, Landroidx/camera/view/RotationProvider$a;->a:I

    return-void
.end method


# virtual methods
.method public final onOrientationChanged(I)V
    .registers 5

    const/4 v0, -0x1

    if-ne p1, v0, :cond_4

    return-void

    :cond_4
    const/16 v0, 0x13b

    if-ge p1, v0, :cond_1b

    const/16 v0, 0x2d

    if-ge p1, v0, :cond_d

    goto :goto_1b

    :cond_d
    const/16 v0, 0xe1

    if-lt p1, v0, :cond_13

    const/4 p1, 0x1

    goto :goto_1c

    :cond_13
    const/16 v0, 0x87

    if-lt p1, v0, :cond_19

    const/4 p1, 0x2

    goto :goto_1c

    :cond_19
    const/4 p1, 0x3

    goto :goto_1c

    :cond_1b
    :goto_1b
    const/4 p1, 0x0

    :goto_1c
    iget v0, p0, Landroidx/camera/view/RotationProvider$a;->a:I

    if-eq v0, p1, :cond_52

    iput p1, p0, Landroidx/camera/view/RotationProvider$a;->a:I

    iget-object v0, p0, Landroidx/camera/view/RotationProvider$a;->b:Landroidx/camera/view/RotationProvider;

    iget-object v0, v0, Landroidx/camera/view/RotationProvider;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_27
    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, Landroidx/camera/view/RotationProvider$a;->b:Landroidx/camera/view/RotationProvider;

    iget-object v2, v2, Landroidx/camera/view/RotationProvider;->b:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    monitor-exit v0
    :try_end_35
    .catchall {:try_start_27 .. :try_end_35} :catchall_4f

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_52

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_52

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/view/RotationProvider$b;

    invoke-virtual {v1, p1}, Landroidx/camera/view/RotationProvider$b;->b(I)V

    goto :goto_3f

    :catchall_4f
    move-exception p1

    :try_start_50
    monitor-exit v0
    :try_end_51
    .catchall {:try_start_50 .. :try_end_51} :catchall_4f

    throw p1

    :cond_52
    return-void
.end method
