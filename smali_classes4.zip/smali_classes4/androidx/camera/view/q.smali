.class public final Landroidx/camera/view/q;
.super Ljava/lang/Object;


# static fields
.field public static final PreviewView:[I

.field public static final PreviewView_implementationMode:I = 0x0

.field public static final PreviewView_scaleType:I = 0x1


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    const/high16 v0, 0x78010000

    const v1, 0x78010001

    filled-new-array {v0, v1}, [I

    move-result-object v0

    sput-object v0, Landroidx/camera/view/q;->PreviewView:[I

    return-void
.end method
