.class public abstract Landroidx/camera/view/b;
.super Ljava/lang/Object;
.source "CameraController.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/view/b$a;
    }
.end annotation


# instance fields
.field a:Landroidx/camera/core/k0;

.field b:Landroidx/camera/core/O;

.field c:Landroidx/camera/core/p1;

.field private final d:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Landroidx/camera/core/s;->b:Landroidx/camera/core/s;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    new-instance v0, Landroidx/camera/view/c;

    invoke-direct {v0}, Landroidx/lifecycle/H;-><init>()V

    new-instance v0, Landroidx/camera/view/c;

    invoke-direct {v0}, Landroidx/lifecycle/H;-><init>()V

    new-instance v0, Landroidx/lifecycle/I;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, v1}, Landroidx/lifecycle/I;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_32

    invoke-static {p1}, Landroidx/camera/view/b$a;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_32

    invoke-static {v0, p1}, Landroidx/camera/view/b$a;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Context;

    move-result-object v0

    :cond_32
    new-instance p1, Landroidx/camera/core/J0$b;

    invoke-direct {p1}, Landroidx/camera/core/J0$b;-><init>()V

    invoke-virtual {p1}, Landroidx/camera/core/J0$b;->e()Landroidx/camera/core/J0;

    new-instance p1, Landroidx/camera/core/k0$h;

    invoke-direct {p1}, Landroidx/camera/core/k0$h;-><init>()V

    invoke-virtual {p1}, Landroidx/camera/core/k0$h;->e()Landroidx/camera/core/k0;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/view/b;->a:Landroidx/camera/core/k0;

    new-instance p1, Landroidx/camera/core/O$c;

    invoke-direct {p1}, Landroidx/camera/core/O$c;-><init>()V

    invoke-virtual {p1}, Landroidx/camera/core/O$c;->e()Landroidx/camera/core/O;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/view/b;->b:Landroidx/camera/core/O;

    new-instance p1, Landroidx/camera/core/p1$b;

    invoke-direct {p1}, Landroidx/camera/core/p1$b;-><init>()V

    invoke-virtual {p1}, Landroidx/camera/core/p1$b;->e()Landroidx/camera/core/p1;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/view/b;->c:Landroidx/camera/core/p1;

    invoke-static {v0}, Landroidx/camera/lifecycle/e;->e(Landroid/content/Context;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    new-instance v1, Landroidx/camera/view/a;

    invoke-direct {v1, p0}, Landroidx/camera/view/a;-><init>(Landroidx/camera/view/b;)V

    invoke-static {}, Lu/a;->d()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v2

    invoke-static {p1, v1, v2}, Lv/f;->m(Lcom/google/common/util/concurrent/o;Lm/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/view/b;->d:Lcom/google/common/util/concurrent/o;

    new-instance p1, Landroidx/camera/view/RotationProvider;

    invoke-direct {p1, v0}, Landroidx/camera/view/RotationProvider;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public static synthetic a(Landroidx/camera/view/b;I)V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/b;->b:Landroidx/camera/core/O;

    invoke-virtual {v0, p1}, Landroidx/camera/core/O;->F(I)V

    iget-object v0, p0, Landroidx/camera/view/b;->a:Landroidx/camera/core/k0;

    invoke-virtual {v0, p1}, Landroidx/camera/core/k0;->F(I)V

    iget-object p0, p0, Landroidx/camera/view/b;->c:Landroidx/camera/core/p1;

    invoke-virtual {p0, p1}, Landroidx/camera/core/p1;->F(I)V

    return-void
.end method


# virtual methods
.method final b()V
    .registers 4

    :try_start_0
    const-string v0, "CamLifecycleController"

    const-string v1, "Lifecycle is not set."

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_7
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_7} :catch_f

    const-string v0, "CameraController"

    const-string v1, "Use cases not attached to camera."

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catch_f
    move-exception v0

    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "The selected camera does not support the enabled use cases. Please disable use case and/or select a different camera. e.g. #setVideoCaptureEnabled(false)"

    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method
