.class public final synthetic Landroidx/camera/view/l;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/view/PreviewView$a;

.field public final synthetic b:Landroidx/camera/core/i1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/PreviewView$a;Landroidx/camera/core/i1;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/l;->a:Landroidx/camera/view/PreviewView$a;

    iput-object p2, p0, Landroidx/camera/view/l;->b:Landroidx/camera/core/i1;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/l;->a:Landroidx/camera/view/PreviewView$a;

    iget-object v0, v0, Landroidx/camera/view/PreviewView$a;->a:Landroidx/camera/view/PreviewView;

    iget-object v0, v0, Landroidx/camera/view/PreviewView;->k:Landroidx/camera/core/J0$d;

    check-cast v0, Landroidx/camera/view/PreviewView$a;

    iget-object v1, p0, Landroidx/camera/view/l;->b:Landroidx/camera/core/i1;

    invoke-virtual {v0, v1}, Landroidx/camera/view/PreviewView$a;->a(Landroidx/camera/core/i1;)V

    return-void
.end method
