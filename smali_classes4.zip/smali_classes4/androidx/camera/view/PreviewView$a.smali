.class final Landroidx/camera/view/PreviewView$a;
.super Ljava/lang/Object;
.source "PreviewView.java"

# interfaces
.implements Landroidx/camera/core/J0$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/view/PreviewView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/camera/view/PreviewView;


# direct methods
.method constructor <init>(Landroidx/camera/view/PreviewView;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/PreviewView$a;->a:Landroidx/camera/view/PreviewView;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/i1;)V
    .registers 12

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v1, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    iget-object v1, p0, Landroidx/camera/view/PreviewView$a;->a:Landroidx/camera/view/PreviewView;

    if-nez v0, :cond_28

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object v0

    new-instance v1, Landroidx/camera/view/l;

    invoke-direct {v1, p0, p1}, Landroidx/camera/view/l;-><init>(Landroidx/camera/view/PreviewView$a;Landroidx/camera/core/i1;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_28
    const-string v0, "PreviewView"

    const-string v4, "Surface requested by Preview."

    invoke-static {v0, v4}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, Landroidx/camera/core/i1;->d()Landroidx/camera/core/impl/x;

    move-result-object v0

    invoke-interface {v0}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v4

    iput-object v4, v1, Landroidx/camera/view/PreviewView;->h:Landroidx/camera/core/impl/w;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object v4

    new-instance v5, Landroidx/camera/view/m;

    invoke-direct {v5, p0, v0, p1}, Landroidx/camera/view/m;-><init>(Landroidx/camera/view/PreviewView$a;Landroidx/camera/core/impl/x;Landroidx/camera/core/i1;)V

    invoke-virtual {p1, v4, v5}, Landroidx/camera/core/i1;->i(Ljava/util/concurrent/Executor;Landroidx/camera/view/m;)V

    iget-object v4, v1, Landroidx/camera/view/PreviewView;->a:Landroidx/camera/view/PreviewView$d;

    invoke-virtual {p1}, Landroidx/camera/core/i1;->d()Landroidx/camera/core/impl/x;

    move-result-object v5

    invoke-interface {v5}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/camera/camera2/internal/K;->l()Ljava/lang/String;

    move-result-object v5

    const-string v6, "androidx.camera.camera2.legacy"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-class v6, LB/c;

    invoke-static {v6}, LB/a;->a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object v6

    if-nez v6, :cond_70

    const-class v6, LB/b;

    invoke-static {v6}, LB/a;->a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object v6

    if-eqz v6, :cond_6e

    goto :goto_70

    :cond_6e
    const/4 v6, 0x0

    goto :goto_71

    :cond_70
    :goto_70
    const/4 v6, 0x1

    :goto_71
    invoke-virtual {p1}, Landroidx/camera/core/i1;->g()Z

    move-result v7

    iget-object v8, v1, Landroidx/camera/view/PreviewView;->c:Landroidx/camera/view/j;

    if-nez v7, :cond_ab

    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x18

    if-le v7, v9, :cond_ab

    if-nez v5, :cond_ab

    if-eqz v6, :cond_84

    goto :goto_ab

    :cond_84
    sget-object v5, Landroidx/camera/view/PreviewView$b;->b:[I

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    aget v5, v5, v6

    if-eq v5, v3, :cond_ab

    const/4 v2, 0x2

    if-ne v5, v2, :cond_97

    new-instance v2, Landroidx/camera/view/v;

    invoke-direct {v2, v1, v8}, Landroidx/camera/view/v;-><init>(Landroid/widget/FrameLayout;Landroidx/camera/view/j;)V

    goto :goto_ba

    :cond_97
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Invalid implementation mode: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_ab
    :goto_ab
    new-instance v3, Landroidx/camera/view/C;

    invoke-direct {v3, v1, v8}, Landroidx/camera/view/o;-><init>(Landroid/widget/FrameLayout;Landroidx/camera/view/j;)V

    iput-boolean v2, v3, Landroidx/camera/view/C;->i:Z

    new-instance v2, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object v2, v3, Landroidx/camera/view/C;->k:Ljava/util/concurrent/atomic/AtomicReference;

    move-object v2, v3

    :goto_ba
    iput-object v2, v1, Landroidx/camera/view/PreviewView;->b:Landroidx/camera/view/o;

    new-instance v2, Landroidx/camera/view/i;

    invoke-interface {v0}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v3

    iget-object v4, v1, Landroidx/camera/view/PreviewView;->e:Landroidx/lifecycle/I;

    iget-object v5, v1, Landroidx/camera/view/PreviewView;->b:Landroidx/camera/view/o;

    invoke-direct {v2, v3, v4, v5}, Landroidx/camera/view/i;-><init>(Landroidx/camera/core/impl/w;Landroidx/lifecycle/I;Landroidx/camera/view/o;)V

    iget-object v3, v1, Landroidx/camera/view/PreviewView;->f:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v3, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-interface {v0}, Landroidx/camera/core/impl/x;->k()Landroidx/camera/core/impl/h0;

    move-result-object v3

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object v4

    invoke-virtual {v3, v4, v2}, Landroidx/camera/core/impl/h0;->a(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/m0;)V

    iget-object v1, v1, Landroidx/camera/view/PreviewView;->b:Landroidx/camera/view/o;

    new-instance v3, Landroidx/camera/view/n;

    invoke-direct {v3, p0, v2, v0}, Landroidx/camera/view/n;-><init>(Landroidx/camera/view/PreviewView$a;Landroidx/camera/view/i;Landroidx/camera/core/impl/x;)V

    invoke-virtual {v1, p1, v3}, Landroidx/camera/view/o;->e(Landroidx/camera/core/i1;Landroidx/camera/view/n;)V

    return-void
.end method
