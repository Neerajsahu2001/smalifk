.class public final synthetic Landroidx/camera/view/r;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/view/RotationProvider$b;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/RotationProvider$b;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/r;->a:Landroidx/camera/view/RotationProvider$b;

    iput p2, p0, Landroidx/camera/view/r;->b:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/r;->a:Landroidx/camera/view/RotationProvider$b;

    iget v1, p0, Landroidx/camera/view/r;->b:I

    invoke-static {v0, v1}, Landroidx/camera/view/RotationProvider$b;->a(Landroidx/camera/view/RotationProvider$b;I)V

    return-void
.end method
