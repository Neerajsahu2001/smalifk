.class public final Landroidx/camera/view/LifecycleCameraController;
.super Landroidx/camera/view/b;
.source "LifecycleCameraController.java"


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Landroidx/camera/view/b;-><init>(Landroid/content/Context;)V

    return-void
.end method
