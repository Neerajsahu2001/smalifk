.class public final synthetic Landroidx/camera/view/a;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lm/a;


# instance fields
.field public final synthetic a:Landroidx/camera/view/b;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/a;->a:Landroidx/camera/view/b;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Landroidx/camera/lifecycle/e;

    iget-object p1, p0, Landroidx/camera/view/a;->a:Landroidx/camera/view/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Landroidx/camera/view/b;->b()V

    const/4 p1, 0x0

    return-object p1
.end method
