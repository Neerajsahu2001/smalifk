.class public final synthetic Landroidx/camera/view/s;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/view/v;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/v;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/s;->a:Landroidx/camera/view/v;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/view/s;->a:Landroidx/camera/view/v;

    invoke-virtual {v0}, Landroidx/camera/view/v;->h()V

    return-void
.end method
