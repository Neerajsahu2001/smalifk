.class final Landroidx/camera/view/v;
.super Landroidx/camera/view/o;
.source "SurfaceViewImplementation.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/view/v$a;
    }
.end annotation


# instance fields
.field e:Landroid/view/SurfaceView;

.field final f:Landroidx/camera/view/v$a;

.field private g:Landroidx/camera/view/o$a;


# direct methods
.method constructor <init>(Landroid/widget/FrameLayout;Landroidx/camera/view/j;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Landroidx/camera/view/o;-><init>(Landroid/widget/FrameLayout;Landroidx/camera/view/j;)V

    new-instance p1, Landroidx/camera/view/v$a;

    invoke-direct {p1, p0}, Landroidx/camera/view/v$a;-><init>(Landroidx/camera/view/v;)V

    iput-object p1, p0, Landroidx/camera/view/v;->f:Landroidx/camera/view/v$a;

    return-void
.end method


# virtual methods
.method final a()Landroid/view/View;
    .registers 2

    iget-object v0, p0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    return-object v0
.end method

.method final b()V
    .registers 1

    return-void
.end method

.method final c()V
    .registers 1

    return-void
.end method

.method final e(Landroidx/camera/core/i1;Landroidx/camera/view/n;)V
    .registers 7

    invoke-virtual {p1}, Landroidx/camera/core/i1;->f()Landroid/util/Size;

    move-result-object v0

    iput-object v0, p0, Landroidx/camera/view/o;->a:Landroid/util/Size;

    iput-object p2, p0, Landroidx/camera/view/v;->g:Landroidx/camera/view/o$a;

    iget-object p2, p0, Landroidx/camera/view/o;->b:Landroid/widget/FrameLayout;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Landroidx/camera/view/o;->a:Landroid/util/Size;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroid/view/SurfaceView;

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    iget-object v2, p0, Landroidx/camera/view/o;->a:Landroid/util/Size;

    invoke-virtual {v2}, Landroid/util/Size;->getWidth()I

    move-result v2

    iget-object v3, p0, Landroidx/camera/view/o;->a:Landroid/util/Size;

    invoke-virtual {v3}, Landroid/util/Size;->getHeight()I

    move-result v3

    invoke-direct {v1, v2, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p2}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object v0, p0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    invoke-virtual {p2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object p2, p0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    invoke-virtual {p2}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object p2

    iget-object v0, p0, Landroidx/camera/view/v;->f:Landroidx/camera/view/v$a;

    invoke-interface {p2, v0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    iget-object p2, p0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object p2

    new-instance v0, Landroidx/camera/view/s;

    invoke-direct {v0, p0}, Landroidx/camera/view/s;-><init>(Landroidx/camera/view/v;)V

    invoke-virtual {p1, v0, p2}, Landroidx/camera/core/i1;->c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    iget-object p2, p0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    new-instance v0, Landroidx/camera/view/t;

    invoke-direct {v0, p0, p1}, Landroidx/camera/view/t;-><init>(Landroidx/camera/view/v;Landroidx/camera/core/i1;)V

    invoke-virtual {p2, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method final g()Lcom/google/common/util/concurrent/o;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    invoke-static {v0}, Lv/f;->h(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    return-object v0
.end method

.method final h()V
    .registers 2

    iget-object v0, p0, Landroidx/camera/view/v;->g:Landroidx/camera/view/o$a;

    if-eqz v0, :cond_c

    check-cast v0, Landroidx/camera/view/n;

    invoke-virtual {v0}, Landroidx/camera/view/n;->a()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/view/v;->g:Landroidx/camera/view/o$a;

    :cond_c
    return-void
.end method
