.class public final synthetic Landroidx/camera/view/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/concurrent/futures/b$c;


# instance fields
.field public final synthetic a:Landroidx/camera/view/i;

.field public final synthetic b:Landroidx/camera/core/r;

.field public final synthetic c:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/impl/w;Landroidx/camera/view/i;Ljava/util/ArrayList;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/camera/view/d;->a:Landroidx/camera/view/i;

    iput-object p1, p0, Landroidx/camera/view/d;->b:Landroidx/camera/core/r;

    iput-object p3, p0, Landroidx/camera/view/d;->c:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/concurrent/futures/b$a;)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Landroidx/camera/view/d;->a:Landroidx/camera/view/i;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroidx/camera/view/h;

    iget-object v1, p0, Landroidx/camera/view/d;->b:Landroidx/camera/core/r;

    invoke-direct {v0, p1, v1}, Landroidx/camera/view/h;-><init>(Landroidx/concurrent/futures/b$a;Landroidx/camera/core/r;)V

    iget-object p1, p0, Landroidx/camera/view/d;->c:Ljava/util/List;

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    check-cast v1, Landroidx/camera/core/impl/w;

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p1

    invoke-interface {v1, p1, v0}, Landroidx/camera/core/impl/w;->c(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/g;)V

    const-string p1, "waitForCaptureResult"

    return-object p1
.end method
