.class public final enum Landroidx/camera/view/PreviewView$g;
.super Ljava/lang/Enum;
.source "PreviewView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/view/PreviewView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Landroidx/camera/view/PreviewView$g;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Landroidx/camera/view/PreviewView$g;

.field public static final enum IDLE:Landroidx/camera/view/PreviewView$g;

.field public static final enum STREAMING:Landroidx/camera/view/PreviewView$g;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance v2, Landroidx/camera/view/PreviewView$g;

    const-string v3, "IDLE"

    invoke-direct {v2, v3, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Landroidx/camera/view/PreviewView$g;->IDLE:Landroidx/camera/view/PreviewView$g;

    new-instance v3, Landroidx/camera/view/PreviewView$g;

    const-string v4, "STREAMING"

    invoke-direct {v3, v4, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Landroidx/camera/view/PreviewView$g;->STREAMING:Landroidx/camera/view/PreviewView$g;

    const/4 v4, 0x2

    new-array v4, v4, [Landroidx/camera/view/PreviewView$g;

    aput-object v2, v4, v1

    aput-object v3, v4, v0

    sput-object v4, Landroidx/camera/view/PreviewView$g;->$VALUES:[Landroidx/camera/view/PreviewView$g;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Landroidx/camera/view/PreviewView$g;
    .registers 2

    const-class v0, Landroidx/camera/view/PreviewView$g;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Landroidx/camera/view/PreviewView$g;

    return-object p0
.end method

.method public static values()[Landroidx/camera/view/PreviewView$g;
    .registers 1

    sget-object v0, Landroidx/camera/view/PreviewView$g;->$VALUES:[Landroidx/camera/view/PreviewView$g;

    invoke-virtual {v0}, [Landroidx/camera/view/PreviewView$g;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroidx/camera/view/PreviewView$g;

    return-object v0
.end method
