.class final Landroidx/camera/view/i;
.super Ljava/lang/Object;
.source "PreviewStreamStateObserver.java"

# interfaces
.implements Landroidx/camera/core/impl/m0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/camera/core/impl/m0<",
        "Landroidx/camera/core/impl/x$a;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Landroidx/camera/core/impl/w;

.field private final b:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "Landroidx/camera/view/PreviewView$g;",
            ">;"
        }
    .end annotation
.end field

.field private c:Landroidx/camera/view/PreviewView$g;

.field private final d:Landroidx/camera/view/o;

.field e:Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field private f:Z


# direct methods
.method constructor <init>(Landroidx/camera/core/impl/w;Landroidx/lifecycle/I;Landroidx/camera/view/o;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/camera/core/impl/w;",
            "Landroidx/lifecycle/I<",
            "Landroidx/camera/view/PreviewView$g;",
            ">;",
            "Landroidx/camera/view/o;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/view/i;->f:Z

    iput-object p1, p0, Landroidx/camera/view/i;->a:Landroidx/camera/core/impl/w;

    iput-object p2, p0, Landroidx/camera/view/i;->b:Landroidx/lifecycle/I;

    iput-object p3, p0, Landroidx/camera/view/i;->d:Landroidx/camera/view/o;

    monitor-enter p0

    :try_start_d
    invoke-virtual {p2}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/camera/view/PreviewView$g;

    iput-object p1, p0, Landroidx/camera/view/i;->c:Landroidx/camera/view/PreviewView$g;

    monitor-exit p0

    return-void

    :catchall_17
    move-exception p1

    monitor-exit p0
    :try_end_19
    .catchall {:try_start_d .. :try_end_19} :catchall_17

    throw p1
.end method

.method public static synthetic b(Landroidx/camera/view/i;)Lcom/google/common/util/concurrent/o;
    .registers 1

    iget-object p0, p0, Landroidx/camera/view/i;->d:Landroidx/camera/view/o;

    invoke-virtual {p0}, Landroidx/camera/view/o;->g()Lcom/google/common/util/concurrent/o;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .registers 6

    check-cast p1, Landroidx/camera/core/impl/x$a;

    sget-object v0, Landroidx/camera/core/impl/x$a;->CLOSING:Landroidx/camera/core/impl/x$a;

    if-eq p1, v0, :cond_6f

    sget-object v0, Landroidx/camera/core/impl/x$a;->CLOSED:Landroidx/camera/core/impl/x$a;

    if-eq p1, v0, :cond_6f

    sget-object v0, Landroidx/camera/core/impl/x$a;->RELEASING:Landroidx/camera/core/impl/x$a;

    if-eq p1, v0, :cond_6f

    sget-object v0, Landroidx/camera/core/impl/x$a;->RELEASED:Landroidx/camera/core/impl/x$a;

    if-ne p1, v0, :cond_13

    goto :goto_6f

    :cond_13
    sget-object v0, Landroidx/camera/core/impl/x$a;->OPENING:Landroidx/camera/core/impl/x$a;

    if-eq p1, v0, :cond_1f

    sget-object v0, Landroidx/camera/core/impl/x$a;->OPEN:Landroidx/camera/core/impl/x$a;

    if-eq p1, v0, :cond_1f

    sget-object v0, Landroidx/camera/core/impl/x$a;->PENDING_OPEN:Landroidx/camera/core/impl/x$a;

    if-ne p1, v0, :cond_85

    :cond_1f
    iget-boolean p1, p0, Landroidx/camera/view/i;->f:Z

    if-nez p1, :cond_85

    sget-object p1, Landroidx/camera/view/PreviewView$g;->IDLE:Landroidx/camera/view/PreviewView$g;

    invoke-virtual {p0, p1}, Landroidx/camera/view/i;->d(Landroidx/camera/view/PreviewView$g;)V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    new-instance v0, Landroidx/camera/view/d;

    iget-object v1, p0, Landroidx/camera/view/i;->a:Landroidx/camera/core/impl/w;

    invoke-direct {v0, v1, p0, p1}, Landroidx/camera/view/d;-><init>(Landroidx/camera/core/impl/w;Landroidx/camera/view/i;Ljava/util/ArrayList;)V

    invoke-static {v0}, Landroidx/concurrent/futures/b;->a(Landroidx/concurrent/futures/b$c;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    invoke-static {v0}, Lv/d;->a(Lcom/google/common/util/concurrent/o;)Lv/d;

    move-result-object v0

    new-instance v2, Landroidx/camera/view/e;

    invoke-direct {v2, p0}, Landroidx/camera/view/e;-><init>(Landroidx/camera/view/i;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v2, v3}, Lv/f;->n(Lcom/google/common/util/concurrent/o;Lv/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    check-cast v0, Lv/d;

    new-instance v2, Landroidx/camera/view/f;

    invoke-direct {v2, p0}, Landroidx/camera/view/f;-><init>(Landroidx/camera/view/i;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object v3

    invoke-static {v0, v2, v3}, Lv/f;->m(Lcom/google/common/util/concurrent/o;Lm/a;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    check-cast v0, Lv/d;

    iput-object v0, p0, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    new-instance v2, Landroidx/camera/view/g;

    invoke-direct {v2, v1, p0, p1}, Landroidx/camera/view/g;-><init>(Landroidx/camera/core/impl/w;Landroidx/camera/view/i;Ljava/util/ArrayList;)V

    invoke-static {}, Lu/a;->a()Ljava/util/concurrent/Executor;

    move-result-object p1

    invoke-static {v0, v2, p1}, Lv/f;->b(Lcom/google/common/util/concurrent/o;Lv/c;Ljava/util/concurrent/Executor;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/camera/view/i;->f:Z

    goto :goto_85

    :cond_6f
    :goto_6f
    sget-object p1, Landroidx/camera/view/PreviewView$g;->IDLE:Landroidx/camera/view/PreviewView$g;

    invoke-virtual {p0, p1}, Landroidx/camera/view/i;->d(Landroidx/camera/view/PreviewView$g;)V

    iget-boolean p1, p0, Landroidx/camera/view/i;->f:Z

    if-eqz p1, :cond_85

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/view/i;->f:Z

    iget-object v0, p0, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    if-eqz v0, :cond_85

    invoke-interface {v0, p1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    :cond_85
    :goto_85
    return-void
.end method

.method final c()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    if-eqz v0, :cond_b

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    :cond_b
    return-void
.end method

.method final d(Landroidx/camera/view/PreviewView$g;)V
    .registers 5

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Landroidx/camera/view/i;->c:Landroidx/camera/view/PreviewView$g;

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    monitor-exit p0

    return-void

    :catchall_b
    move-exception p1

    goto :goto_29

    :cond_d
    iput-object p1, p0, Landroidx/camera/view/i;->c:Landroidx/camera/view/PreviewView$g;

    monitor-exit p0
    :try_end_10
    .catchall {:try_start_1 .. :try_end_10} :catchall_b

    const-string v0, "StreamStateObserver"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Update Preview stream state to "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/view/i;->b:Landroidx/lifecycle/I;

    invoke-virtual {v0, p1}, Landroidx/lifecycle/I;->postValue(Ljava/lang/Object;)V

    return-void

    :goto_29
    :try_start_29
    monitor-exit p0
    :try_end_2a
    .catchall {:try_start_29 .. :try_end_2a} :catchall_b

    throw p1
.end method

.method public final onError()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    if-eqz v0, :cond_b

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    :cond_b
    sget-object v0, Landroidx/camera/view/PreviewView$g;->IDLE:Landroidx/camera/view/PreviewView$g;

    invoke-virtual {p0, v0}, Landroidx/camera/view/i;->d(Landroidx/camera/view/PreviewView$g;)V

    return-void
.end method
