.class public final Landroidx/camera/view/PreviewView;
.super Landroid/widget/FrameLayout;
.source "PreviewView.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/view/PreviewView$c;,
        Landroidx/camera/view/PreviewView$e;,
        Landroidx/camera/view/PreviewView$g;,
        Landroidx/camera/view/PreviewView$f;,
        Landroidx/camera/view/PreviewView$d;
    }
.end annotation


# static fields
.field private static final l:Landroidx/camera/view/PreviewView$d;


# instance fields
.field a:Landroidx/camera/view/PreviewView$d;

.field b:Landroidx/camera/view/o;

.field final c:Landroidx/camera/view/j;

.field d:Z

.field final e:Landroidx/lifecycle/I;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/I<",
            "Landroidx/camera/view/PreviewView$g;",
            ">;"
        }
    .end annotation
.end field

.field final f:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Landroidx/camera/view/i;",
            ">;"
        }
    .end annotation
.end field

.field g:Landroidx/camera/view/p;

.field h:Landroidx/camera/core/impl/w;

.field private final i:Landroidx/camera/view/PreviewView$c;

.field private final j:Landroid/view/View$OnLayoutChangeListener;

.field final k:Landroidx/camera/core/J0$d;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Landroidx/camera/view/PreviewView$d;->PERFORMANCE:Landroidx/camera/view/PreviewView$d;

    sput-object v0, Landroidx/camera/view/PreviewView;->l:Landroidx/camera/view/PreviewView$d;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/camera/view/PreviewView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Landroidx/camera/view/PreviewView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 5

    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, p3, v0}, Landroidx/camera/view/PreviewView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .registers 15

    invoke-direct {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    sget-object v0, Landroidx/camera/view/PreviewView;->l:Landroidx/camera/view/PreviewView$d;

    iput-object v0, p0, Landroidx/camera/view/PreviewView;->a:Landroidx/camera/view/PreviewView$d;

    new-instance v1, Landroidx/camera/view/j;

    invoke-direct {v1}, Landroidx/camera/view/j;-><init>()V

    iput-object v1, p0, Landroidx/camera/view/PreviewView;->c:Landroidx/camera/view/j;

    const/4 v2, 0x1

    iput-boolean v2, p0, Landroidx/camera/view/PreviewView;->d:Z

    new-instance v2, Landroidx/lifecycle/I;

    sget-object v3, Landroidx/camera/view/PreviewView$g;->IDLE:Landroidx/camera/view/PreviewView$g;

    invoke-direct {v2, v3}, Landroidx/lifecycle/I;-><init>(Ljava/lang/Object;)V

    iput-object v2, p0, Landroidx/camera/view/PreviewView;->e:Landroidx/lifecycle/I;

    new-instance v2, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object v2, p0, Landroidx/camera/view/PreviewView;->f:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v2, Landroidx/camera/view/p;

    invoke-direct {v2, v1}, Landroidx/camera/view/p;-><init>(Landroidx/camera/view/j;)V

    iput-object v2, p0, Landroidx/camera/view/PreviewView;->g:Landroidx/camera/view/p;

    new-instance v2, Landroidx/camera/view/PreviewView$c;

    invoke-direct {v2, p0}, Landroidx/camera/view/PreviewView$c;-><init>(Landroidx/camera/view/PreviewView;)V

    iput-object v2, p0, Landroidx/camera/view/PreviewView;->i:Landroidx/camera/view/PreviewView$c;

    new-instance v2, Landroidx/camera/view/k;

    invoke-direct {v2, p0}, Landroidx/camera/view/k;-><init>(Landroidx/camera/view/PreviewView;)V

    iput-object v2, p0, Landroidx/camera/view/PreviewView;->j:Landroid/view/View$OnLayoutChangeListener;

    new-instance v2, Landroidx/camera/view/PreviewView$a;

    invoke-direct {v2, p0}, Landroidx/camera/view/PreviewView$a;-><init>(Landroidx/camera/view/PreviewView;)V

    iput-object v2, p0, Landroidx/camera/view/PreviewView;->k:Landroidx/camera/core/J0$d;

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v2

    sget-object v5, Landroidx/camera/view/q;->PreviewView:[I

    invoke-virtual {v2, p2, v5, p3, p4}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v2

    move-object v3, p0

    move-object v4, p1

    move-object v6, p2

    move-object v7, v2

    move v8, p3

    move v9, p4

    invoke-static/range {v3 .. v9}, Landroidx/core/view/L;->Y(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    :try_start_53
    sget p2, Landroidx/camera/view/q;->PreviewView_scaleType:I

    invoke-virtual {v1}, Landroidx/camera/view/j;->c()Landroidx/camera/view/PreviewView$f;

    move-result-object p3

    invoke-virtual {p3}, Landroidx/camera/view/PreviewView$f;->b()I

    move-result p3

    invoke-virtual {v2, p2, p3}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result p2

    invoke-static {p2}, Landroidx/camera/view/PreviewView$f;->a(I)Landroidx/camera/view/PreviewView$f;

    move-result-object p2

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-virtual {v1, p2}, Landroidx/camera/view/j;->g(Landroidx/camera/view/PreviewView$f;)V

    invoke-virtual {p0}, Landroidx/camera/view/PreviewView;->e()V

    invoke-direct {p0}, Landroidx/camera/view/PreviewView;->b()V

    sget p2, Landroidx/camera/view/q;->PreviewView_implementationMode:I

    invoke-virtual {v0}, Landroidx/camera/view/PreviewView$d;->b()I

    move-result p3

    invoke-virtual {v2, p2, p3}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result p2

    invoke-static {p2}, Landroidx/camera/view/PreviewView$d;->a(I)Landroidx/camera/view/PreviewView$d;

    move-result-object p2

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    iput-object p2, p0, Landroidx/camera/view/PreviewView;->a:Landroidx/camera/view/PreviewView$d;
    :try_end_84
    .catchall {:try_start_53 .. :try_end_84} :catchall_a6

    invoke-virtual {v2}, Landroid/content/res/TypedArray;->recycle()V

    new-instance p2, Landroid/view/ScaleGestureDetector;

    new-instance p3, Landroidx/camera/view/PreviewView$e;

    invoke-direct {p3, p0}, Landroidx/camera/view/PreviewView$e;-><init>(Landroidx/camera/view/PreviewView;)V

    invoke-direct {p2, p1, p3}, Landroid/view/ScaleGestureDetector;-><init>(Landroid/content/Context;Landroid/view/ScaleGestureDetector$OnScaleGestureListener;)V

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-nez p1, :cond_a5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const p2, 0x106000c

    invoke-static {p1, p2}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_a5
    return-void

    :catchall_a6
    move-exception p1

    invoke-virtual {v2}, Landroid/content/res/TypedArray;->recycle()V

    throw p1
.end method

.method public static synthetic a(Landroidx/camera/view/PreviewView;IIIIIIII)V
    .registers 9

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sub-int/2addr p3, p1

    sub-int/2addr p7, p5

    if-ne p3, p7, :cond_b

    sub-int/2addr p4, p2

    sub-int/2addr p8, p6

    if-eq p4, p8, :cond_11

    :cond_b
    invoke-virtual {p0}, Landroidx/camera/view/PreviewView;->e()V

    invoke-direct {p0}, Landroidx/camera/view/PreviewView;->b()V

    :cond_11
    return-void
.end method

.method private b()V
    .registers 6

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-virtual {p0}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-virtual {p0}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v0

    if-nez v0, :cond_10

    goto :goto_7d

    :cond_10
    invoke-virtual {p0}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    move-result v0

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    if-eqz v1, :cond_7d

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    if-nez v1, :cond_28

    goto :goto_7d

    :cond_28
    new-instance v1, Landroidx/camera/core/q1$a;

    new-instance v2, Landroid/util/Rational;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/util/Rational;-><init>(II)V

    invoke-direct {v1, v0, v2}, Landroidx/camera/core/q1$a;-><init>(ILandroid/util/Rational;)V

    sget-object v0, Landroidx/camera/view/PreviewView$b;->a:[I

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    iget-object v2, p0, Landroidx/camera/view/PreviewView;->c:Landroidx/camera/view/j;

    invoke-virtual {v2}, Landroidx/camera/view/j;->c()Landroidx/camera/view/PreviewView$f;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v0, v0, v3

    packed-switch v0, :pswitch_data_7e

    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "Unexpected scale type: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    invoke-virtual {v2}, Landroidx/camera/view/j;->c()Landroidx/camera/view/PreviewView$f;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_69
    const/4 v0, 0x3

    goto :goto_70

    :pswitch_6b
    const/4 v0, 0x0

    goto :goto_70

    :pswitch_6d
    const/4 v0, 0x1

    goto :goto_70

    :pswitch_6f
    const/4 v0, 0x2

    :goto_70
    invoke-virtual {v1, v0}, Landroidx/camera/core/q1$a;->c(I)V

    invoke-virtual {p0}, Landroid/view/View;->getLayoutDirection()I

    move-result v0

    invoke-virtual {v1, v0}, Landroidx/camera/core/q1$a;->b(I)V

    invoke-virtual {v1}, Landroidx/camera/core/q1$a;->a()Landroidx/camera/core/q1;

    :cond_7d
    :goto_7d
    return-void

    :pswitch_data_7e
    .packed-switch 0x1
        :pswitch_6f
        :pswitch_6d
        :pswitch_6b
        :pswitch_69
        :pswitch_69
        :pswitch_69
    .end packed-switch
.end method


# virtual methods
.method public final c()Landroidx/lifecycle/I;
    .registers 2

    iget-object v0, p0, Landroidx/camera/view/PreviewView;->e:Landroidx/lifecycle/I;

    return-object v0
.end method

.method public final d()Landroidx/camera/core/J0$d;
    .registers 2

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    iget-object v0, p0, Landroidx/camera/view/PreviewView;->k:Landroidx/camera/core/J0$d;

    return-object v0
.end method

.method final e()V
    .registers 4

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    iget-object v0, p0, Landroidx/camera/view/PreviewView;->b:Landroidx/camera/view/o;

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Landroidx/camera/view/o;->f()V

    :cond_a
    new-instance v0, Landroid/util/Size;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    invoke-virtual {p0}, Landroid/view/View;->getLayoutDirection()I

    move-result v1

    iget-object v2, p0, Landroidx/camera/view/PreviewView;->g:Landroidx/camera/view/p;

    invoke-virtual {v2, v1, v0}, Landroidx/camera/view/p;->d(ILandroid/util/Size;)V

    return-void
.end method

.method final f()V
    .registers 4

    iget-boolean v0, p0, Landroidx/camera/view/PreviewView;->d:Z

    if-eqz v0, :cond_1f

    invoke-virtual {p0}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v0

    if-eqz v0, :cond_1f

    iget-object v1, p0, Landroidx/camera/view/PreviewView;->h:Landroidx/camera/core/impl/w;

    if-eqz v1, :cond_1f

    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    move-result v2

    invoke-interface {v1, v2}, Landroidx/camera/core/r;->h(I)I

    move-result v1

    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    move-result v0

    iget-object v2, p0, Landroidx/camera/view/PreviewView;->c:Landroidx/camera/view/j;

    invoke-virtual {v2, v1, v0}, Landroidx/camera/view/j;->f(II)V

    :cond_1f
    return-void
.end method

.method protected final onAttachedToWindow()V
    .registers 4

    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    invoke-virtual {p0}, Landroidx/camera/view/PreviewView;->f()V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_e

    const/4 v0, 0x0

    goto :goto_1a

    :cond_e
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "display"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/display/DisplayManager;

    :goto_1a
    if-nez v0, :cond_1d

    goto :goto_2b

    :cond_1d
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iget-object v2, p0, Landroidx/camera/view/PreviewView;->i:Landroidx/camera/view/PreviewView$c;

    invoke-virtual {v0, v2, v1}, Landroid/hardware/display/DisplayManager;->registerDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;Landroid/os/Handler;)V

    :goto_2b
    iget-object v0, p0, Landroidx/camera/view/PreviewView;->j:Landroid/view/View$OnLayoutChangeListener;

    invoke-virtual {p0, v0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    iget-object v0, p0, Landroidx/camera/view/PreviewView;->b:Landroidx/camera/view/o;

    if-eqz v0, :cond_37

    invoke-virtual {v0}, Landroidx/camera/view/o;->b()V

    :cond_37
    invoke-direct {p0}, Landroidx/camera/view/PreviewView;->b()V

    return-void
.end method

.method protected final onDetachedFromWindow()V
    .registers 3

    invoke-super {p0}, Landroid/widget/FrameLayout;->onDetachedFromWindow()V

    iget-object v0, p0, Landroidx/camera/view/PreviewView;->j:Landroid/view/View$OnLayoutChangeListener;

    invoke-virtual {p0, v0}, Landroid/view/View;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    iget-object v0, p0, Landroidx/camera/view/PreviewView;->b:Landroidx/camera/view/o;

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Landroidx/camera/view/o;->c()V

    :cond_f
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_17

    const/4 v0, 0x0

    goto :goto_23

    :cond_17
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "display"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/display/DisplayManager;

    :goto_23
    if-nez v0, :cond_26

    goto :goto_2b

    :cond_26
    iget-object v1, p0, Landroidx/camera/view/PreviewView;->i:Landroidx/camera/view/PreviewView$c;

    invoke-virtual {v0, v1}, Landroid/hardware/display/DisplayManager;->unregisterDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;)V

    :goto_2b
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 2

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public final performClick()Z
    .registers 2

    invoke-super {p0}, Landroid/widget/FrameLayout;->performClick()Z

    move-result v0

    return v0
.end method
