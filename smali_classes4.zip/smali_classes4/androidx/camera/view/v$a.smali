.class final Landroidx/camera/view/v$a;
.super Ljava/lang/Object;
.source "SurfaceViewImplementation.java"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/camera/view/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field private a:Landroid/util/Size;

.field private b:Landroidx/camera/core/i1;

.field private c:Landroid/util/Size;

.field private d:Z

.field final synthetic e:Landroidx/camera/view/v;


# direct methods
.method constructor <init>(Landroidx/camera/view/v;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/v$a;->e:Landroidx/camera/view/v;

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/view/v$a;->d:Z

    return-void
.end method

.method private a()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    if-eqz v0, :cond_1e

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Request canceled: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "SurfaceViewImpl"

    invoke-static {v1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    invoke-virtual {v0}, Landroidx/camera/core/i1;->k()V

    :cond_1e
    return-void
.end method

.method private c()Z
    .registers 6

    iget-object v0, p0, Landroidx/camera/view/v$a;->e:Landroidx/camera/view/v;

    iget-object v1, v0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    invoke-virtual {v1}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object v1

    iget-boolean v2, p0, Landroidx/camera/view/v$a;->d:Z

    if-nez v2, :cond_42

    iget-object v2, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    if-eqz v2, :cond_42

    iget-object v2, p0, Landroidx/camera/view/v$a;->a:Landroid/util/Size;

    if-eqz v2, :cond_42

    iget-object v3, p0, Landroidx/camera/view/v$a;->c:Landroid/util/Size;

    invoke-virtual {v2, v3}, Landroid/util/Size;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_42

    const-string v2, "SurfaceViewImpl"

    const-string v3, "Surface set on Preview."

    invoke-static {v2, v3}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    iget-object v3, v0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object v3

    new-instance v4, Landroidx/camera/view/u;

    invoke-direct {v4, p0}, Landroidx/camera/view/u;-><init>(Landroidx/camera/view/v$a;)V

    invoke-virtual {v2, v1, v3, v4}, Landroidx/camera/core/i1;->h(Landroid/view/Surface;Ljava/util/concurrent/Executor;Landroidx/core/util/a;)V

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/camera/view/v$a;->d:Z

    invoke-virtual {v0}, Landroidx/camera/view/o;->d()V

    return v1

    :cond_42
    const/4 v0, 0x0

    return v0
.end method


# virtual methods
.method final b(Landroidx/camera/core/i1;)V
    .registers 4

    invoke-direct {p0}, Landroidx/camera/view/v$a;->a()V

    iput-object p1, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    invoke-virtual {p1}, Landroidx/camera/core/i1;->f()Landroid/util/Size;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/view/v$a;->a:Landroid/util/Size;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/view/v$a;->d:Z

    invoke-direct {p0}, Landroidx/camera/view/v$a;->c()Z

    move-result v0

    if-nez v0, :cond_2e

    const-string v0, "SurfaceViewImpl"

    const-string v1, "Wait for new Surface creation."

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/camera/view/v$a;->e:Landroidx/camera/view/v;

    iget-object v0, v0, Landroidx/camera/view/v;->e:Landroid/view/SurfaceView;

    invoke-virtual {v0}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v0

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result v1

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result p1

    invoke-interface {v0, v1, p1}, Landroid/view/SurfaceHolder;->setFixedSize(II)V

    :cond_2e
    return-void
.end method

.method public final surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .registers 5

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Surface changed. Size: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "x"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "SurfaceViewImpl"

    invoke-static {p2, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Landroid/util/Size;

    invoke-direct {p1, p3, p4}, Landroid/util/Size;-><init>(II)V

    iput-object p1, p0, Landroidx/camera/view/v$a;->c:Landroid/util/Size;

    invoke-direct {p0}, Landroidx/camera/view/v$a;->c()Z

    return-void
.end method

.method public final surfaceCreated(Landroid/view/SurfaceHolder;)V
    .registers 3

    const-string p1, "SurfaceViewImpl"

    const-string v0, "Surface created."

    invoke-static {p1, v0}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public final surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .registers 4

    const-string p1, "Surface destroyed."

    const-string v0, "SurfaceViewImpl"

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-boolean p1, p0, Landroidx/camera/view/v$a;->d:Z

    if-eqz p1, :cond_2c

    iget-object p1, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    if-eqz p1, :cond_2f

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "Surface invalidated "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    invoke-virtual {p1}, Landroidx/camera/core/i1;->e()Landroidx/camera/core/impl/K;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/camera/core/impl/K;->c()V

    goto :goto_2f

    :cond_2c
    invoke-direct {p0}, Landroidx/camera/view/v$a;->a()V

    :cond_2f
    :goto_2f
    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/camera/view/v$a;->d:Z

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/camera/view/v$a;->b:Landroidx/camera/core/i1;

    iput-object p1, p0, Landroidx/camera/view/v$a;->c:Landroid/util/Size;

    iput-object p1, p0, Landroidx/camera/view/v$a;->a:Landroid/util/Size;

    return-void
.end method
