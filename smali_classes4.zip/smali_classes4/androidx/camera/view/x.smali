.class public final synthetic Landroidx/camera/view/x;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/view/C;

.field public final synthetic b:Landroidx/camera/core/i1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/C;Landroidx/camera/core/i1;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/x;->a:Landroidx/camera/view/C;

    iput-object p2, p0, Landroidx/camera/view/x;->b:Landroidx/camera/core/i1;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Landroidx/camera/view/x;->a:Landroidx/camera/view/C;

    iget-object v1, p0, Landroidx/camera/view/x;->b:Landroidx/camera/core/i1;

    invoke-static {v0, v1}, Landroidx/camera/view/C;->i(Landroidx/camera/view/C;Landroidx/camera/core/i1;)V

    return-void
.end method
