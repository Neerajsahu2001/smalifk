.class public final synthetic Landroidx/camera/view/f;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lm/a;


# instance fields
.field public final synthetic a:Landroidx/camera/view/i;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/f;->a:Landroidx/camera/view/i;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/lang/Void;

    sget-object p1, Landroidx/camera/view/PreviewView$g;->STREAMING:Landroidx/camera/view/PreviewView$g;

    iget-object v0, p0, Landroidx/camera/view/f;->a:Landroidx/camera/view/i;

    invoke-virtual {v0, p1}, Landroidx/camera/view/i;->d(Landroidx/camera/view/PreviewView$g;)V

    const/4 p1, 0x0

    return-object p1
.end method
