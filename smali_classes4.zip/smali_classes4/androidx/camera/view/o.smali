.class abstract Landroidx/camera/view/o;
.super Ljava/lang/Object;
.source "PreviewViewImplementation.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/view/o$a;
    }
.end annotation


# instance fields
.field a:Landroid/util/Size;

.field b:Landroid/widget/FrameLayout;

.field private final c:Landroidx/camera/view/j;

.field private d:Z


# direct methods
.method constructor <init>(Landroid/widget/FrameLayout;Landroidx/camera/view/j;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/camera/view/o;->d:Z

    iput-object p1, p0, Landroidx/camera/view/o;->b:Landroid/widget/FrameLayout;

    iput-object p2, p0, Landroidx/camera/view/o;->c:Landroidx/camera/view/j;

    return-void
.end method


# virtual methods
.method abstract a()Landroid/view/View;
.end method

.method abstract b()V
.end method

.method abstract c()V
.end method

.method final d()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/camera/view/o;->d:Z

    invoke-virtual {p0}, Landroidx/camera/view/o;->f()V

    return-void
.end method

.method abstract e(Landroidx/camera/core/i1;Landroidx/camera/view/n;)V
.end method

.method final f()V
    .registers 6

    invoke-virtual {p0}, Landroidx/camera/view/o;->a()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_23

    iget-boolean v1, p0, Landroidx/camera/view/o;->d:Z

    if-nez v1, :cond_b

    goto :goto_23

    :cond_b
    new-instance v1, Landroid/util/Size;

    iget-object v2, p0, Landroidx/camera/view/o;->b:Landroid/widget/FrameLayout;

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    move-result v4

    invoke-direct {v1, v3, v4}, Landroid/util/Size;-><init>(II)V

    invoke-virtual {v2}, Landroid/view/View;->getLayoutDirection()I

    move-result v2

    iget-object v3, p0, Landroidx/camera/view/o;->c:Landroidx/camera/view/j;

    invoke-virtual {v3, v1, v2, v0}, Landroidx/camera/view/j;->i(Landroid/util/Size;ILandroid/view/View;)V

    :cond_23
    :goto_23
    return-void
.end method

.method abstract g()Lcom/google/common/util/concurrent/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/util/concurrent/o<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end method
