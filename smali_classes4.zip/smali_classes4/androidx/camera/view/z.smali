.class public final synthetic Landroidx/camera/view/z;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/view/C;

.field public final synthetic b:Landroid/view/Surface;

.field public final synthetic c:Lcom/google/common/util/concurrent/o;

.field public final synthetic d:Landroidx/camera/core/i1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/C;Landroid/view/Surface;Lcom/google/common/util/concurrent/o;Landroidx/camera/core/i1;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/z;->a:Landroidx/camera/view/C;

    iput-object p2, p0, Landroidx/camera/view/z;->b:Landroid/view/Surface;

    iput-object p3, p0, Landroidx/camera/view/z;->c:Lcom/google/common/util/concurrent/o;

    iput-object p4, p0, Landroidx/camera/view/z;->d:Landroidx/camera/core/i1;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Landroidx/camera/view/z;->c:Lcom/google/common/util/concurrent/o;

    iget-object v1, p0, Landroidx/camera/view/z;->d:Landroidx/camera/core/i1;

    iget-object v2, p0, Landroidx/camera/view/z;->a:Landroidx/camera/view/C;

    iget-object v3, p0, Landroidx/camera/view/z;->b:Landroid/view/Surface;

    invoke-static {v2, v3, v0, v1}, Landroidx/camera/view/C;->h(Landroidx/camera/view/C;Landroid/view/Surface;Lcom/google/common/util/concurrent/o;Landroidx/camera/core/i1;)V

    return-void
.end method
