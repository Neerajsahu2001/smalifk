.class public final synthetic Landroidx/camera/view/e;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lv/a;


# instance fields
.field public final synthetic a:Landroidx/camera/view/i;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/i;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/e;->a:Landroidx/camera/view/i;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Lcom/google/common/util/concurrent/o;
    .registers 2

    check-cast p1, Ljava/lang/Void;

    iget-object p1, p0, Landroidx/camera/view/e;->a:Landroidx/camera/view/i;

    invoke-static {p1}, Landroidx/camera/view/i;->b(Landroidx/camera/view/i;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    return-object p1
.end method
