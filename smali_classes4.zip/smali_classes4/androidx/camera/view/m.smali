.class public final synthetic Landroidx/camera/view/m;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/core/i1$h;


# instance fields
.field public final synthetic a:Landroidx/camera/view/PreviewView$a;

.field public final synthetic b:Landroidx/camera/core/impl/x;

.field public final synthetic c:Landroidx/camera/core/i1;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/PreviewView$a;Landroidx/camera/core/impl/x;Landroidx/camera/core/i1;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/m;->a:Landroidx/camera/view/PreviewView$a;

    iput-object p2, p0, Landroidx/camera/view/m;->b:Landroidx/camera/core/impl/x;

    iput-object p3, p0, Landroidx/camera/view/m;->c:Landroidx/camera/core/i1;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/i1$g;)V
    .registers 8

    iget-object v0, p0, Landroidx/camera/view/m;->a:Landroidx/camera/view/PreviewView$a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Preview transformation info updated. "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "PreviewView"

    invoke-static {v2, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/camera/view/m;->b:Landroidx/camera/core/impl/x;

    invoke-interface {v1}, Landroidx/camera/core/impl/x;->i()Landroidx/camera/camera2/internal/K;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/camera/camera2/internal/K;->d()Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_2c

    const/4 v1, 0x1

    goto :goto_2d

    :cond_2c
    const/4 v1, 0x0

    :goto_2d
    iget-object v0, v0, Landroidx/camera/view/PreviewView$a;->a:Landroidx/camera/view/PreviewView;

    iget-object v4, v0, Landroidx/camera/view/PreviewView;->c:Landroidx/camera/view/j;

    iget-object v5, p0, Landroidx/camera/view/m;->c:Landroidx/camera/core/i1;

    invoke-virtual {v5}, Landroidx/camera/core/i1;->f()Landroid/util/Size;

    move-result-object v5

    invoke-virtual {v4, p1, v5, v1}, Landroidx/camera/view/j;->h(Landroidx/camera/core/i1$g;Landroid/util/Size;Z)V

    invoke-virtual {p1}, Landroidx/camera/core/i1$g;->c()I

    move-result p1

    const/4 v1, -0x1

    if-eq p1, v1, :cond_4d

    iget-object p1, v0, Landroidx/camera/view/PreviewView;->b:Landroidx/camera/view/o;

    if-eqz p1, :cond_4a

    instance-of p1, p1, Landroidx/camera/view/v;

    if-eqz p1, :cond_4a

    goto :goto_4d

    :cond_4a
    iput-boolean v2, v0, Landroidx/camera/view/PreviewView;->d:Z

    goto :goto_4f

    :cond_4d
    :goto_4d
    iput-boolean v3, v0, Landroidx/camera/view/PreviewView;->d:Z

    :goto_4f
    invoke-virtual {v0}, Landroidx/camera/view/PreviewView;->f()V

    invoke-virtual {v0}, Landroidx/camera/view/PreviewView;->e()V

    return-void
.end method
