.class final Landroidx/camera/view/g;
.super Ljava/lang/Object;
.source "PreviewStreamStateObserver.java"

# interfaces
.implements Lv/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv/c<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/util/List;

.field final synthetic b:Landroidx/camera/core/r;

.field final synthetic c:Landroidx/camera/view/i;


# direct methods
.method constructor <init>(Landroidx/camera/core/impl/w;Landroidx/camera/view/i;Ljava/util/ArrayList;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/camera/view/g;->c:Landroidx/camera/view/i;

    iput-object p3, p0, Landroidx/camera/view/g;->a:Ljava/util/List;

    iput-object p1, p0, Landroidx/camera/view/g;->b:Landroidx/camera/core/r;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Throwable;)V
    .registers 5

    iget-object p1, p0, Landroidx/camera/view/g;->c:Landroidx/camera/view/i;

    const/4 v0, 0x0

    iput-object v0, p1, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    iget-object p1, p0, Landroidx/camera/view/g;->a:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_28

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_25

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/camera/core/impl/g;

    iget-object v2, p0, Landroidx/camera/view/g;->b:Landroidx/camera/core/r;

    check-cast v2, Landroidx/camera/core/impl/w;

    invoke-interface {v2, v1}, Landroidx/camera/core/impl/w;->f(Landroidx/camera/core/impl/g;)V

    goto :goto_11

    :cond_25
    invoke-interface {p1}, Ljava/util/List;->clear()V

    :cond_28
    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Ljava/lang/Void;

    iget-object p1, p0, Landroidx/camera/view/g;->c:Landroidx/camera/view/i;

    const/4 v0, 0x0

    iput-object v0, p1, Landroidx/camera/view/i;->e:Lcom/google/common/util/concurrent/o;

    return-void
.end method
