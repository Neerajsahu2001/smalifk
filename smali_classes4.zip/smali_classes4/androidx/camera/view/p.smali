.class final Landroidx/camera/view/p;
.super Landroidx/camera/core/E0;
.source "PreviewViewMeteringPointFactory.java"


# static fields
.field static final d:Landroid/graphics/PointF;


# instance fields
.field private final b:Landroidx/camera/view/j;

.field private c:Landroid/graphics/Matrix;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroid/graphics/PointF;

    const/high16 v1, 0x40000000    # 2.0f

    invoke-direct {v0, v1, v1}, Landroid/graphics/PointF;-><init>(FF)V

    sput-object v0, Landroidx/camera/view/p;->d:Landroid/graphics/PointF;

    return-void
.end method

.method constructor <init>(Landroidx/camera/view/j;)V
    .registers 2

    invoke-direct {p0}, Landroidx/camera/core/E0;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/p;->b:Landroidx/camera/view/j;

    return-void
.end method


# virtual methods
.method protected final a()Landroid/graphics/PointF;
    .registers 5

    const/4 v0, 0x2

    new-array v0, v0, [F

    fill-array-data v0, :array_24

    monitor-enter p0

    :try_start_7
    iget-object v1, p0, Landroidx/camera/view/p;->c:Landroid/graphics/Matrix;

    if-nez v1, :cond_11

    sget-object v0, Landroidx/camera/view/p;->d:Landroid/graphics/PointF;

    monitor-exit p0

    return-object v0

    :catchall_f
    move-exception v0

    goto :goto_21

    :cond_11
    invoke-virtual {v1, v0}, Landroid/graphics/Matrix;->mapPoints([F)V

    monitor-exit p0
    :try_end_15
    .catchall {:try_start_7 .. :try_end_15} :catchall_f

    new-instance v1, Landroid/graphics/PointF;

    const/4 v2, 0x0

    aget v2, v0, v2

    const/4 v3, 0x1

    aget v0, v0, v3

    invoke-direct {v1, v2, v0}, Landroid/graphics/PointF;-><init>(FF)V

    return-object v1

    :goto_21
    :try_start_21
    monitor-exit p0
    :try_end_22
    .catchall {:try_start_21 .. :try_end_22} :catchall_f

    throw v0

    nop

    :array_24
    .array-data 4
        0x3f000000    # 0.5f
        0x3f000000    # 0.5f
    .end array-data
.end method

.method final d(ILandroid/util/Size;)V
    .registers 4

    invoke-static {}, Landroidx/camera/core/impl/utils/l;->a()V

    monitor-enter p0

    :try_start_4
    invoke-virtual {p2}, Landroid/util/Size;->getWidth()I

    move-result v0

    if-eqz v0, :cond_1d

    invoke-virtual {p2}, Landroid/util/Size;->getHeight()I

    move-result v0

    if-nez v0, :cond_11

    goto :goto_1d

    :cond_11
    iget-object v0, p0, Landroidx/camera/view/p;->b:Landroidx/camera/view/j;

    invoke-virtual {v0, p1, p2}, Landroidx/camera/view/j;->a(ILandroid/util/Size;)Landroid/graphics/Matrix;

    move-result-object p1

    iput-object p1, p0, Landroidx/camera/view/p;->c:Landroid/graphics/Matrix;

    monitor-exit p0

    return-void

    :catchall_1b
    move-exception p1

    goto :goto_22

    :cond_1d
    :goto_1d
    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/camera/view/p;->c:Landroid/graphics/Matrix;

    monitor-exit p0

    return-void

    :goto_22
    monitor-exit p0
    :try_end_23
    .catchall {:try_start_4 .. :try_end_23} :catchall_1b

    throw p1
.end method
