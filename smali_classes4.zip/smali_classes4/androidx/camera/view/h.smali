.class final Landroidx/camera/view/h;
.super Landroidx/camera/core/impl/g;
.source "PreviewStreamStateObserver.java"


# instance fields
.field final synthetic a:Landroidx/concurrent/futures/b$a;

.field final synthetic b:Landroidx/camera/core/r;


# direct methods
.method constructor <init>(Landroidx/concurrent/futures/b$a;Landroidx/camera/core/r;)V
    .registers 3

    iput-object p1, p0, Landroidx/camera/view/h;->a:Landroidx/concurrent/futures/b$a;

    iput-object p2, p0, Landroidx/camera/view/h;->b:Landroidx/camera/core/r;

    invoke-direct {p0}, Landroidx/camera/core/impl/g;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Landroidx/camera/core/impl/o;)V
    .registers 3

    iget-object p1, p0, Landroidx/camera/view/h;->a:Landroidx/concurrent/futures/b$a;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/b$a;->c(Ljava/lang/Object;)Z

    iget-object p1, p0, Landroidx/camera/view/h;->b:Landroidx/camera/core/r;

    check-cast p1, Landroidx/camera/core/impl/w;

    invoke-interface {p1, p0}, Landroidx/camera/core/impl/w;->f(Landroidx/camera/core/impl/g;)V

    return-void
.end method
