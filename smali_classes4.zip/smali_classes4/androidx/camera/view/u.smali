.class public final synthetic Landroidx/camera/view/u;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/core/util/a;


# instance fields
.field public final synthetic a:Landroidx/camera/view/v$a;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/v$a;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/u;->a:Landroidx/camera/view/v$a;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Landroidx/camera/core/i1$f;

    iget-object p1, p0, Landroidx/camera/view/u;->a:Landroidx/camera/view/v$a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "SurfaceViewImpl"

    const-string v1, "Safe to release surface."

    invoke-static {v0, v1}, Landroidx/camera/core/A0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p1, Landroidx/camera/view/v$a;->e:Landroidx/camera/view/v;

    invoke-virtual {p1}, Landroidx/camera/view/v;->h()V

    return-void
.end method
