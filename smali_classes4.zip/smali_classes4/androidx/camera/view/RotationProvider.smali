.class public final Landroidx/camera/view/RotationProvider;
.super Ljava/lang/Object;
.source "RotationProvider.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/camera/view/RotationProvider$b;
    }
.end annotation


# instance fields
.field final a:Ljava/lang/Object;

.field final b:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/camera/view/RotationProvider;->a:Ljava/lang/Object;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/camera/view/RotationProvider;->b:Ljava/util/HashMap;

    new-instance v0, Landroidx/camera/view/RotationProvider$a;

    invoke-direct {v0, p0, p1}, Landroidx/camera/view/RotationProvider$a;-><init>(Landroidx/camera/view/RotationProvider;Landroid/content/Context;)V

    return-void
.end method
