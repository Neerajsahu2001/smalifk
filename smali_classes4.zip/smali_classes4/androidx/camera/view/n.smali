.class public final synthetic Landroidx/camera/view/n;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/camera/view/o$a;


# instance fields
.field public final synthetic a:Landroidx/camera/view/PreviewView$a;

.field public final synthetic b:Landroidx/camera/view/i;

.field public final synthetic c:Landroidx/camera/core/impl/x;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/view/PreviewView$a;Landroidx/camera/view/i;Landroidx/camera/core/impl/x;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/camera/view/n;->a:Landroidx/camera/view/PreviewView$a;

    iput-object p2, p0, Landroidx/camera/view/n;->b:Landroidx/camera/view/i;

    iput-object p3, p0, Landroidx/camera/view/n;->c:Landroidx/camera/core/impl/x;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    iget-object v0, p0, Landroidx/camera/view/n;->a:Landroidx/camera/view/PreviewView$a;

    iget-object v0, v0, Landroidx/camera/view/PreviewView$a;->a:Landroidx/camera/view/PreviewView;

    iget-object v0, v0, Landroidx/camera/view/PreviewView;->f:Ljava/util/concurrent/atomic/AtomicReference;

    :cond_6
    iget-object v1, p0, Landroidx/camera/view/n;->b:Landroidx/camera/view/i;

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_15

    sget-object v0, Landroidx/camera/view/PreviewView$g;->IDLE:Landroidx/camera/view/PreviewView$g;

    invoke-virtual {v1, v0}, Landroidx/camera/view/i;->d(Landroidx/camera/view/PreviewView$g;)V

    goto :goto_1b

    :cond_15
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    if-eq v2, v1, :cond_6

    :goto_1b
    invoke-virtual {v1}, Landroidx/camera/view/i;->c()V

    iget-object v0, p0, Landroidx/camera/view/n;->c:Landroidx/camera/core/impl/x;

    invoke-interface {v0}, Landroidx/camera/core/impl/x;->k()Landroidx/camera/core/impl/h0;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/h0;->c(Landroidx/camera/core/impl/m0;)V

    return-void
.end method
