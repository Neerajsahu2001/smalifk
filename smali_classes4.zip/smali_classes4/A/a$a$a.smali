.class public final enum LA/a$a$a;
.super Ljava/lang/Enum;
.source "ImageUtil.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LA/a$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LA/a$a$a;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LA/a$a$a;

.field public static final enum DECODE_FAILED:LA/a$a$a;

.field public static final enum ENCODE_FAILED:LA/a$a$a;

.field public static final enum UNKNOWN:LA/a$a$a;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v3, LA/a$a$a;

    const-string v4, "ENCODE_FAILED"

    invoke-direct {v3, v4, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LA/a$a$a;->ENCODE_FAILED:LA/a$a$a;

    new-instance v4, LA/a$a$a;

    const-string v5, "DECODE_FAILED"

    invoke-direct {v4, v5, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, LA/a$a$a;->DECODE_FAILED:LA/a$a$a;

    new-instance v5, LA/a$a$a;

    const-string v6, "UNKNOWN"

    invoke-direct {v5, v6, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LA/a$a$a;->UNKNOWN:LA/a$a$a;

    const/4 v6, 0x3

    new-array v6, v6, [LA/a$a$a;

    aput-object v3, v6, v2

    aput-object v4, v6, v1

    aput-object v5, v6, v0

    sput-object v6, LA/a$a$a;->$VALUES:[LA/a$a$a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)LA/a$a$a;
    .registers 2

    const-class v0, LA/a$a$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LA/a$a$a;

    return-object p0
.end method

.method public static values()[LA/a$a$a;
    .registers 1

    sget-object v0, LA/a$a$a;->$VALUES:[LA/a$a$a;

    invoke-virtual {v0}, [LA/a$a$a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LA/a$a$a;

    return-object v0
.end method
