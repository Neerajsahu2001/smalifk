.class public final LA/a$a;
.super Ljava/lang/Exception;
.source "ImageUtil.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LA/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LA/a$a$a;
    }
.end annotation


# instance fields
.field private a:LA/a$a$a;


# direct methods
.method constructor <init>(Ljava/lang/String;LA/a$a$a;)V
    .registers 3

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    iput-object p2, p0, LA/a$a;->a:LA/a$a$a;

    return-void
.end method


# virtual methods
.method public final a()LA/a$a$a;
    .registers 2

    iget-object v0, p0, LA/a$a;->a:LA/a$a$a;

    return-object v0
.end method
