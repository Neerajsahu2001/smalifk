.class public final LA/a;
.super Ljava/lang/Object;
.source "ImageUtil.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LA/a$a;
    }
.end annotation


# direct methods
.method public static a(Landroid/util/Size;Landroid/util/Rational;)Landroid/graphics/Rect;
    .registers 10

    invoke-virtual {p1}, Landroid/util/Rational;->floatValue()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-lez v0, :cond_53

    invoke-virtual {p1}, Landroid/util/Rational;->isNaN()Z

    move-result v0

    if-nez v0, :cond_53

    invoke-virtual {p0}, Landroid/util/Size;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/util/Size;->getHeight()I

    move-result p0

    int-to-float v1, v0

    int-to-float v2, p0

    div-float v3, v1, v2

    invoke-virtual {p1}, Landroid/util/Rational;->getNumerator()I

    move-result v4

    invoke-virtual {p1}, Landroid/util/Rational;->getDenominator()I

    move-result v5

    invoke-virtual {p1}, Landroid/util/Rational;->floatValue()F

    move-result p1

    const/4 v6, 0x0

    cmpl-float p1, p1, v3

    if-lez p1, :cond_3c

    int-to-float p1, v4

    div-float/2addr v1, p1

    int-to-float p1, v5

    mul-float v1, v1, p1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result p1

    sub-int/2addr p0, p1

    div-int/lit8 p0, p0, 0x2

    move v7, p1

    move p1, p0

    move p0, v7

    goto :goto_4b

    :cond_3c
    int-to-float p1, v5

    div-float/2addr v2, p1

    int-to-float p1, v4

    mul-float v2, v2, p1

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result p1

    sub-int/2addr v0, p1

    div-int/lit8 v0, v0, 0x2

    move v6, v0

    move v0, p1

    const/4 p1, 0x0

    :goto_4b
    new-instance v1, Landroid/graphics/Rect;

    add-int/2addr v0, v6

    add-int/2addr p0, p1

    invoke-direct {v1, v6, p1, v0, p0}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object v1

    :cond_53
    const-string p0, "ImageUtil"

    const-string p1, "Invalid view ratio."

    invoke-static {p0, p1}, Landroidx/camera/core/A0;->k(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static b(ILandroid/util/Rational;)Landroid/util/Rational;
    .registers 3

    const/16 v0, 0x5a

    if-eq p0, v0, :cond_17

    const/16 v0, 0x10e

    if-ne p0, v0, :cond_9

    goto :goto_17

    :cond_9
    new-instance p0, Landroid/util/Rational;

    invoke-virtual {p1}, Landroid/util/Rational;->getNumerator()I

    move-result v0

    invoke-virtual {p1}, Landroid/util/Rational;->getDenominator()I

    move-result p1

    invoke-direct {p0, v0, p1}, Landroid/util/Rational;-><init>(II)V

    return-object p0

    :cond_17
    :goto_17
    if-nez p1, :cond_1a

    goto :goto_28

    :cond_1a
    new-instance p0, Landroid/util/Rational;

    invoke-virtual {p1}, Landroid/util/Rational;->getDenominator()I

    move-result v0

    invoke-virtual {p1}, Landroid/util/Rational;->getNumerator()I

    move-result p1

    invoke-direct {p0, v0, p1}, Landroid/util/Rational;-><init>(II)V

    move-object p1, p0

    :goto_28
    return-object p1
.end method

.method public static c(Landroidx/camera/core/r0;)[B
    .registers 4

    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result v0

    const/16 v1, 0x100

    if-ne v0, v1, :cond_20

    invoke-interface {p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object p0

    const/4 v0, 0x0

    aget-object p0, p0, v0

    invoke-interface {p0}, Landroidx/camera/core/r0$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/nio/Buffer;->capacity()I

    move-result v0

    new-array v0, v0, [B

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    return-object v0

    :cond_20
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Incorrect image format of the input image proxy: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static d(Landroidx/camera/core/r0;Landroid/graphics/Rect;I)[B
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            LA/a$a;
        }
    .end annotation

    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result v0

    const/16 v1, 0x100

    if-ne v0, v1, :cond_69

    invoke-static {p0}, LA/a;->c(Landroidx/camera/core/r0;)[B

    move-result-object p0

    const-string v0, "Decode byte array failed."

    :try_start_e
    array-length v1, p0

    const/4 v2, 0x0

    invoke-static {p0, v2, v1, v2}, Landroid/graphics/BitmapRegionDecoder;->newInstance([BIIZ)Landroid/graphics/BitmapRegionDecoder;

    move-result-object p0

    new-instance v1, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v1}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    invoke-virtual {p0, p1, v1}, Landroid/graphics/BitmapRegionDecoder;->decodeRegion(Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p1

    invoke-virtual {p0}, Landroid/graphics/BitmapRegionDecoder;->recycle()V
    :try_end_20
    .catch Ljava/lang/IllegalArgumentException; {:try_start_e .. :try_end_20} :catch_49
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_20} :catch_4b

    if-eqz p1, :cond_41

    new-instance p0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    invoke-virtual {p1, v0, p2, p0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    move-result p2

    if-eqz p2, :cond_37

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    return-object p0

    :cond_37
    new-instance p0, LA/a$a;

    const-string p1, "Encode bitmap failed."

    sget-object p2, LA/a$a$a;->ENCODE_FAILED:LA/a$a$a;

    invoke-direct {p0, p1, p2}, LA/a$a;-><init>(Ljava/lang/String;LA/a$a$a;)V

    throw p0

    :cond_41
    new-instance p0, LA/a$a;

    sget-object p1, LA/a$a$a;->DECODE_FAILED:LA/a$a$a;

    invoke-direct {p0, v0, p1}, LA/a$a;-><init>(Ljava/lang/String;LA/a$a$a;)V

    throw p0

    :catch_49
    move-exception p0

    goto :goto_53

    :catch_4b
    new-instance p0, LA/a$a;

    sget-object p1, LA/a$a$a;->DECODE_FAILED:LA/a$a$a;

    invoke-direct {p0, v0, p1}, LA/a$a;-><init>(Ljava/lang/String;LA/a$a$a;)V

    throw p0

    :goto_53
    new-instance p1, LA/a$a;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Decode byte array failed with illegal argument."

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    sget-object p2, LA/a$a$a;->DECODE_FAILED:LA/a$a$a;

    invoke-direct {p1, p0, p2}, LA/a$a;-><init>(Ljava/lang/String;LA/a$a$a;)V

    throw p1

    :cond_69
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Incorrect image format of the input image proxy: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result p0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static e(Landroidx/camera/core/r0;Landroid/graphics/Rect;I)[B
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            LA/a$a;
        }
    .end annotation

    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result v0

    const/16 v1, 0x23

    if-ne v0, v1, :cond_41

    invoke-static {p0}, LA/a;->f(Landroidx/camera/core/r0;)[B

    move-result-object v3

    invoke-interface {p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v0

    invoke-interface {p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result p0

    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v8, Landroid/graphics/YuvImage;

    const/16 v4, 0x11

    const/4 v7, 0x0

    move-object v2, v8

    move v5, v0

    move v6, p0

    invoke-direct/range {v2 .. v7}, Landroid/graphics/YuvImage;-><init>([BIII[I)V

    if-nez p1, :cond_2c

    new-instance p1, Landroid/graphics/Rect;

    const/4 v2, 0x0

    invoke-direct {p1, v2, v2, v0, p0}, Landroid/graphics/Rect;-><init>(IIII)V

    :cond_2c
    invoke-virtual {v8, p1, p2, v1}, Landroid/graphics/YuvImage;->compressToJpeg(Landroid/graphics/Rect;ILjava/io/OutputStream;)Z

    move-result p0

    if-eqz p0, :cond_37

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    return-object p0

    :cond_37
    new-instance p0, LA/a$a;

    const-string p1, "YuvImage failed to encode jpeg."

    sget-object p2, LA/a$a$a;->ENCODE_FAILED:LA/a$a$a;

    invoke-direct {p0, p1, p2}, LA/a$a;-><init>(Ljava/lang/String;LA/a$a$a;)V

    throw p0

    :cond_41
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Incorrect image format of the input image proxy: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {p0}, Landroidx/camera/core/r0;->getFormat()I

    move-result p0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static f(Landroidx/camera/core/r0;)[B
    .registers 20

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v2

    const/4 v3, 0x1

    aget-object v2, v2, v3

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->B0()[Landroidx/camera/core/r0$a;

    move-result-object v3

    const/4 v4, 0x2

    aget-object v3, v3, v4

    invoke-interface {v0}, Landroidx/camera/core/r0$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v5

    invoke-interface {v2}, Landroidx/camera/core/r0$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v6

    invoke-interface {v3}, Landroidx/camera/core/r0$a;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v7

    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {v7}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    invoke-virtual {v5}, Ljava/nio/Buffer;->remaining()I

    move-result v8

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v9

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result v10

    mul-int v9, v9, v10

    div-int/2addr v9, v4

    add-int/2addr v9, v8

    new-array v9, v9, [B

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_3e
    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result v12

    if-ge v10, v12, :cond_68

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v12

    invoke-virtual {v5, v9, v11, v12}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v12

    add-int/2addr v11, v12

    invoke-virtual {v5}, Ljava/nio/Buffer;->position()I

    move-result v12

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v13

    sub-int/2addr v12, v13

    invoke-interface {v0}, Landroidx/camera/core/r0$a;->a()I

    move-result v13

    add-int/2addr v12, v13

    invoke-static {v8, v12}, Ljava/lang/Math;->min(II)I

    move-result v12

    invoke-virtual {v5, v12}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    add-int/lit8 v10, v10, 0x1

    goto :goto_3e

    :cond_68
    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getHeight()I

    move-result v0

    div-int/2addr v0, v4

    invoke-interface/range {p0 .. p0}, Landroidx/camera/core/r0;->getWidth()I

    move-result v5

    div-int/2addr v5, v4

    invoke-interface {v3}, Landroidx/camera/core/r0$a;->a()I

    move-result v4

    invoke-interface {v2}, Landroidx/camera/core/r0$a;->a()I

    move-result v8

    invoke-interface {v3}, Landroidx/camera/core/r0$a;->b()I

    move-result v3

    invoke-interface {v2}, Landroidx/camera/core/r0$a;->b()I

    move-result v2

    new-array v10, v4, [B

    new-array v12, v8, [B

    const/4 v13, 0x0

    :goto_87
    if-ge v13, v0, :cond_ba

    invoke-virtual {v7}, Ljava/nio/Buffer;->remaining()I

    move-result v14

    invoke-static {v4, v14}, Ljava/lang/Math;->min(II)I

    move-result v14

    invoke-virtual {v7, v10, v1, v14}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    invoke-virtual {v6}, Ljava/nio/Buffer;->remaining()I

    move-result v14

    invoke-static {v8, v14}, Ljava/lang/Math;->min(II)I

    move-result v14

    invoke-virtual {v6, v12, v1, v14}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    :goto_a3
    if-ge v14, v5, :cond_b7

    add-int/lit8 v17, v11, 0x1

    aget-byte v18, v10, v15

    aput-byte v18, v9, v11

    add-int/lit8 v11, v11, 0x2

    aget-byte v18, v12, v16

    aput-byte v18, v9, v17

    add-int/2addr v15, v3

    add-int v16, v16, v2

    add-int/lit8 v14, v14, 0x1

    goto :goto_a3

    :cond_b7
    add-int/lit8 v13, v13, 0x1

    goto :goto_87

    :cond_ba
    return-object v9
.end method
