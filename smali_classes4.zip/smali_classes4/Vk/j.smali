.class public final synthetic LVk/j;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lzj/f;


# direct methods
.method public static a(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Z
    .registers 2

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0, p1}, Landroidx/camera/core/impl/H;->e(Landroidx/camera/core/impl/H$a;)Z

    move-result p0

    return p0
.end method

.method public static b(Landroidx/camera/core/impl/t0;Lt/i;)V
    .registers 2

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0, p1}, Landroidx/camera/core/impl/H;->b(Lt/i;)V

    return-void
.end method

.method public static c(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;
    .registers 2

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0, p1}, Landroidx/camera/core/impl/H;->y(Landroidx/camera/core/impl/H$a;)Landroidx/camera/core/impl/H$b;

    move-result-object p0

    return-object p0
.end method

.method public static d(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/util/Set;
    .registers 2

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0, p1}, Landroidx/camera/core/impl/H;->l(Landroidx/camera/core/impl/H$a;)Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public static e(Landroidx/camera/core/impl/t0;)Ljava/util/Set;
    .registers 1

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0}, Landroidx/camera/core/impl/H;->h()Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public static f(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;
    .registers 2

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0, p1}, Landroidx/camera/core/impl/H;->c(Landroidx/camera/core/impl/H$a;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static g(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0, p1, p2}, Landroidx/camera/core/impl/H;->w(Landroidx/camera/core/impl/H$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static h(Landroidx/camera/core/impl/t0;Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;
    .registers 3

    invoke-interface {p0}, Landroidx/camera/core/impl/t0;->getConfig()Landroidx/camera/core/impl/H;

    move-result-object p0

    invoke-interface {p0, p1, p2}, Landroidx/camera/core/impl/H;->g(Landroidx/camera/core/impl/H$a;Landroidx/camera/core/impl/H$b;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public onFailure(Ljava/lang/Exception;)V
    .registers 3

    sget v0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->o:I

    const-string v0, "e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, LO7/c;->logException(Ljava/lang/Throwable;)V

    return-void
.end method
