.class public final synthetic LVk/h;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Leo/l;

.field public final synthetic b:Lcom/google/common/util/concurrent/o;


# direct methods
.method public synthetic constructor <init>(Leo/l;Lcom/google/common/util/concurrent/o;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LVk/h;->a:Leo/l;

    iput-object p2, p0, LVk/h;->b:Lcom/google/common/util/concurrent/o;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    sget v0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->o:I

    const-string v0, "$block"

    iget-object v1, p0, LVk/h;->a:Leo/l;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$cameraProviderFuture"

    iget-object v2, p0, LVk/h;->b:Lcom/google/common/util/concurrent/o;

    invoke-static {v2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v2}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const-string v2, "cameraProviderFuture.get()"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1, v0}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
