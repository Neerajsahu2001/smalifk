.class public final synthetic LVk/g;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;


# direct methods
.method public synthetic constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LVk/g;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, LVk/g;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    invoke-static {v0}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->b(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V

    return-void
.end method
