.class public final synthetic LVk/f;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LVk/f;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    iput-object p2, p0, LVk/f;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, LVk/f;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    iget-object v1, p0, LVk/f;->b:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->a(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Ljava/lang/String;)V

    return-void
.end method
