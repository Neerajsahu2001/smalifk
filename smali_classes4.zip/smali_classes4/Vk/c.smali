.class public final synthetic LVk/c;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/google/common/util/concurrent/o;

.field public final synthetic b:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/util/concurrent/o;Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LVk/c;->a:Lcom/google/common/util/concurrent/o;

    iput-object p2, p0, LVk/c;->b:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, LVk/c;->a:Lcom/google/common/util/concurrent/o;

    iget-object v1, p0, LVk/c;->b:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    invoke-static {v0, v1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->a(Lcom/google/common/util/concurrent/o;Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V

    return-void
.end method
