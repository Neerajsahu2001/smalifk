.class public final synthetic LVk/b;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;


# direct methods
.method public synthetic constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LVk/b;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    sget v0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->m:I

    const-string v0, "this$0"

    iget-object v1, p0, LVk/b;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroidx/camera/lifecycle/e;->e(Landroid/content/Context;)Lcom/google/common/util/concurrent/o;

    move-result-object v0

    new-instance v2, LVk/c;

    invoke-direct {v2, v0, v1}, LVk/c;-><init>(Lcom/google/common/util/concurrent/o;Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object v1

    check-cast v0, Lv/d;

    invoke-virtual {v0, v2, v1}, Lv/d;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method
