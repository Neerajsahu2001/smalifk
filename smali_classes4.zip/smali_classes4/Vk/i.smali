.class public final synthetic LVk/i;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lzj/g;


# instance fields
.field public final synthetic a:Leo/l;


# direct methods
.method public synthetic constructor <init>(Leo/l;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LVk/i;->a:Leo/l;

    return-void
.end method


# virtual methods
.method public final onSuccess(Ljava/lang/Object;)V
    .registers 4

    sget v0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->o:I

    const-string v0, "$tmp0"

    iget-object v1, p0, LVk/i;->a:Leo/l;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
