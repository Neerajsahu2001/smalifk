.class public final synthetic LVk/k;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lzj/e;


# instance fields
.field public final synthetic a:Landroidx/camera/core/r0;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/r0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LVk/k;->a:Landroidx/camera/core/r0;

    return-void
.end method


# virtual methods
.method public final onComplete(Lzj/k;)V
    .registers 3

    sget v0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->o:I

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LVk/k;->a:Landroidx/camera/core/r0;

    if-eqz p1, :cond_e

    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    :cond_e
    return-void
.end method
