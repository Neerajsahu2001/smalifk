.class public final LB/a;
.super Ljava/lang/Object;
.source "DeviceQuirks.java"


# static fields
.field private static final a:Landroidx/camera/core/impl/s0;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    new-instance v0, Landroidx/camera/core/impl/s0;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    sget-object v2, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const-string v3, "SAMSUNG"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_24

    sget-object v3, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v4, "F2Q"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_36

    const-string v4, "Q2Q"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_24

    goto :goto_36

    :cond_24
    const-string v3, "OPPO"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3e

    const-string v3, "OP4E75L1"

    sget-object v4, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3e

    :cond_36
    :goto_36
    new-instance v3, LB/c;

    invoke-direct {v3}, LB/c;-><init>()V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3e
    const-string v3, "XIAOMI"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_58

    const-string v2, "M2101K7AG"

    sget-object v3, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_58

    new-instance v2, LB/b;

    invoke-direct {v2}, LB/b;-><init>()V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_58
    invoke-direct {v0, v1}, Landroidx/camera/core/impl/s0;-><init>(Ljava/util/ArrayList;)V

    sput-object v0, LB/a;->a:Landroidx/camera/core/impl/s0;

    return-void
.end method

.method public static a(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Landroidx/camera/core/impl/r0;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    sget-object v0, LB/a;->a:Landroidx/camera/core/impl/s0;

    invoke-virtual {v0, p0}, Landroidx/camera/core/impl/s0;->b(Ljava/lang/Class;)Landroidx/camera/core/impl/r0;

    move-result-object p0

    return-object p0
.end method
