.class public final LB/b;
.super Ljava/lang/Object;
.source "SurfaceViewNotCroppedByParentQuirk.java"

# interfaces
.implements Landroidx/camera/core/impl/r0;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
