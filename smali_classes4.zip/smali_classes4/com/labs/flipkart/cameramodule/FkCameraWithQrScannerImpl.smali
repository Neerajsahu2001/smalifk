.class public final Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;
.super Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;
.source "FkCameraWithQrScannerImpl.kt"

# interfaces
.implements Landroidx/lifecycle/j;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0018\u00002\u00020\u00012\u00020\u0002B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0005\u0010\u0006\u00a8\u0006\u0007"
    }
    d2 = {
        "Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;",
        "Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;",
        "Landroidx/lifecycle/j;",
        "Landroid/content/Context;",
        "context",
        "<init>",
        "(Landroid/content/Context;)V",
        "cameramodule_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
.end annotation


# static fields
.field private static final n:[Ljava/lang/String;

.field public static final synthetic o:I


# instance fields
.field private c:Landroidx/camera/core/l;

.field private d:Landroidx/camera/core/k1;

.field private e:Landroidx/lifecycle/A;

.field private f:Landroidx/camera/view/PreviewView;

.field private g:Ljava/util/concurrent/ExecutorService;

.field private h:Lcom/google/mlkit/vision/barcode/internal/BarcodeScannerImpl;

.field private i:Leo/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/p<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Boolean;",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private j:Leo/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/l<",
            "-",
            "Ljava/lang/Boolean;",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private k:Leo/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/l<",
            "-",
            "Ljava/lang/Exception;",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private l:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private final m:Ljava/lang/Runnable;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "android.permission.CAMERA"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->H([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    sput-object v0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->n:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 8

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1, v0, v1, v0}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;ILkotlin/jvm/internal/i;)V

    new-instance v0, Lcom/google/mlkit/common/internal/CommonComponentRegistrar;

    invoke-direct {v0}, Lcom/google/mlkit/common/internal/CommonComponentRegistrar;-><init>()V

    new-instance v2, Lcom/google/mlkit/vision/common/internal/VisionCommonRegistrar;

    invoke-direct {v2}, Lcom/google/mlkit/vision/common/internal/VisionCommonRegistrar;-><init>()V

    new-instance v3, Lcom/google/mlkit/vision/barcode/internal/BarcodeRegistrar;

    invoke-direct {v3}, Lcom/google/mlkit/vision/barcode/internal/BarcodeRegistrar;-><init>()V

    const/4 v4, 0x3

    new-array v4, v4, [Lcom/google/firebase/components/ComponentRegistrar;

    const/4 v5, 0x0

    aput-object v0, v4, v5

    const/4 v0, 0x1

    aput-object v2, v4, v0

    aput-object v3, v4, v1

    invoke-static {v4}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    :try_start_28
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1, v1}, LGk/i;->d(Landroid/content/Context;Ljava/util/List;)V
    :try_end_2f
    .catch Ljava/lang/IllegalStateException; {:try_start_28 .. :try_end_2f} :catch_2f

    :catch_2f
    new-instance p1, Landroidx/camera/core/d0;

    invoke-direct {p1, v0, p0}, Landroidx/camera/core/d0;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->m:Ljava/lang/Runnable;

    return-void
.end method

.method public static a(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Ljava/lang/String;)V
    .registers 4

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$imagePath"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-static {v0, p1}, LMk/a;->a(Landroid/content/Context;Landroid/net/Uri;)LMk/a;

    move-result-object p1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->l(LMk/a;ZLandroidx/camera/core/r0;)V

    return-void
.end method

.method public static b(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V
    .registers 4

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/labs/flipkart/cameramodule/d;

    invoke-direct {v0, p0}, Lcom/labs/flipkart/cameramodule/d;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroidx/camera/lifecycle/e;->e(Landroid/content/Context;)Lcom/google/common/util/concurrent/o;

    move-result-object v1

    new-instance v2, LVk/h;

    invoke-direct {v2, v0, v1}, LVk/h;-><init>(Leo/l;Lcom/google/common/util/concurrent/o;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object p0

    check-cast v1, Lv/d;

    invoke-virtual {v1, v2, p0}, Lv/d;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public static d(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Landroidx/camera/core/r0;)V
    .registers 4

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, Landroidx/camera/core/r0;->c1()Landroid/media/Image;

    move-result-object v0

    if-nez v0, :cond_c

    goto :goto_1c

    :cond_c
    invoke-interface {p1}, Landroidx/camera/core/r0;->V0()Landroidx/camera/core/o0;

    move-result-object v1

    invoke-interface {v1}, Landroidx/camera/core/o0;->b()I

    move-result v1

    invoke-static {v0, v1}, LMk/a;->b(Landroid/media/Image;I)LMk/a;

    move-result-object v0

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1, p1}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->l(LMk/a;ZLandroidx/camera/core/r0;)V

    :goto_1c
    return-void
.end method

.method public static final synthetic e(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)Leo/l;
    .registers 1

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->j:Leo/l;

    return-object p0
.end method

.method public static final synthetic g(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)Landroidx/camera/core/k1;
    .registers 1

    invoke-direct {p0}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->k()Landroidx/camera/core/k1;

    move-result-object p0

    return-object p0
.end method

.method public static final h(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Landroidx/camera/lifecycle/e;)V
    .registers 6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Landroidx/camera/lifecycle/e;->h()V

    :try_start_6
    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->e:Landroidx/lifecycle/A;

    const/4 v1, 0x0

    if-eqz v0, :cond_24

    sget-object v2, Landroidx/camera/core/s;->c:Landroidx/camera/core/s;

    const-string v3, "DEFAULT_BACK_CAMERA"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->k()Landroidx/camera/core/k1;

    move-result-object v3

    invoke-virtual {p1, v0, v2, v3}, Landroidx/camera/lifecycle/e;->c(Landroidx/lifecycle/A;Landroidx/camera/core/s;Landroidx/camera/core/k1;)Landroidx/camera/core/l;

    move-result-object p1

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->c:Landroidx/camera/core/l;

    invoke-virtual {p0, v1}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;->setLastDetectedQrDisplayValue(Ljava/lang/String;)V

    goto :goto_3f

    :catch_20
    move-exception p1

    goto :goto_2a

    :catch_22
    move-exception p1

    goto :goto_35

    :cond_24
    const-string p1, "lifecycleOwner"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1
    :try_end_2a
    .catch Ljava/lang/IllegalStateException; {:try_start_6 .. :try_end_2a} :catch_22
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_2a} :catch_20

    :goto_2a
    invoke-static {p1}, LO7/c;->logException(Ljava/lang/Throwable;)V

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->k:Leo/l;

    if-eqz p0, :cond_3f

    invoke-interface {p0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3f

    :goto_35
    invoke-static {p1}, LO7/c;->logException(Ljava/lang/Throwable;)V

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->k:Leo/l;

    if-eqz p0, :cond_3f

    invoke-interface {p0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3f
    :goto_3f
    return-void
.end method

.method public static final i(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Z)V
    .registers 4

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->i:Leo/p;

    const/4 v1, 0x0

    if-eqz v0, :cond_c

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-interface {v0, v1, p1}, Leo/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_c
    invoke-virtual {p0, v1}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;->setLastDetectedQrDisplayValue(Ljava/lang/String;)V

    return-void
.end method

.method public static final j(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;LJk/a;Z)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, LJk/a;->a()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_29

    invoke-static {p1}, Lvp/k;->B(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_10

    goto :goto_29

    :cond_10
    invoke-virtual {p0}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;->getLastDetectedQrDisplayValue()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1d

    invoke-virtual {p0, p1}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;->setLastDetectedQrDisplayValue(Ljava/lang/String;)V

    :cond_1d
    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->i:Leo/p;

    if-eqz p0, :cond_38

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Leo/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_38

    :cond_29
    :goto_29
    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->i:Leo/p;

    const/4 v0, 0x0

    if-eqz p1, :cond_35

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-interface {p1, v0, p2}, Leo/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_35
    invoke-virtual {p0, v0}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;->setLastDetectedQrDisplayValue(Ljava/lang/String;)V

    :cond_38
    :goto_38
    return-void
.end method

.method private final k()Landroidx/camera/core/k1;
    .registers 11

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->d:Landroidx/camera/core/k1;

    if-nez v0, :cond_134

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v1, 0x0

    const/16 v2, 0x1e

    const-string v3, "previewView"

    if-lt v0, v2, :cond_39

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v2, "window"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const-string v2, "null cannot be cast to non-null type android.view.WindowManager"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/view/WindowManager;

    invoke-static {v0}, LVk/d;->a(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    move-result-object v0

    invoke-static {v0}, LVk/e;->a(Landroid/view/WindowMetrics;)Landroid/graphics/Rect;

    move-result-object v0

    const-string v2, "context.getSystemService\u2026rrentWindowMetrics.bounds"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Landroid/util/Size;

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v4

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    invoke-direct {v2, v4, v0}, Landroid/util/Size;-><init>(II)V

    goto :goto_54

    :cond_39
    new-instance v0, Landroid/util/DisplayMetrics;

    invoke-direct {v0}, Landroid/util/DisplayMetrics;-><init>()V

    iget-object v2, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->f:Landroidx/camera/view/PreviewView;

    if-eqz v2, :cond_130

    invoke-virtual {v2}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v2

    if-eqz v2, :cond_4b

    invoke-virtual {v2, v0}, Landroid/view/Display;->getRealMetrics(Landroid/util/DisplayMetrics;)V

    :cond_4b
    new-instance v2, Landroid/util/Size;

    iget v4, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-direct {v2, v4, v0}, Landroid/util/Size;-><init>(II)V

    :goto_54
    invoke-virtual {v2}, Landroid/util/Size;->getWidth()I

    move-result v0

    invoke-virtual {v2}, Landroid/util/Size;->getHeight()I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v4

    int-to-double v4, v4

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    int-to-double v6, v0

    div-double/2addr v4, v6

    const-wide v6, 0x3ff5555555555555L    # 1.3333333333333333

    sub-double v6, v4, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->abs(D)D

    move-result-wide v6

    const-wide v8, 0x3ffc71c71c71c71cL    # 1.7777777777777777

    sub-double/2addr v4, v8

    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    const/4 v0, 0x1

    const/4 v2, 0x0

    cmpg-double v8, v6, v4

    if-gtz v8, :cond_84

    const/4 v4, 0x0

    goto :goto_85

    :cond_84
    const/4 v4, 0x1

    :goto_85
    new-instance v5, Landroidx/camera/core/J0$b;

    invoke-direct {v5}, Landroidx/camera/core/J0$b;-><init>()V

    invoke-virtual {v5, v4}, Landroidx/camera/core/J0$b;->i(I)V

    iget-object v6, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->f:Landroidx/camera/view/PreviewView;

    if-eqz v6, :cond_12c

    invoke-virtual {v6}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v6

    if-eqz v6, :cond_9c

    invoke-virtual {v6}, Landroid/view/Display;->getRotation()I

    move-result v6

    goto :goto_9d

    :cond_9c
    const/4 v6, 0x0

    :goto_9d
    invoke-virtual {v5, v6}, Landroidx/camera/core/J0$b;->k(I)V

    invoke-virtual {v5}, Landroidx/camera/core/J0$b;->e()Landroidx/camera/core/J0;

    move-result-object v5

    iget-object v6, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->f:Landroidx/camera/view/PreviewView;

    if-eqz v6, :cond_128

    invoke-virtual {v6}, Landroidx/camera/view/PreviewView;->d()Landroidx/camera/core/J0$d;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroidx/camera/core/J0;->M(Landroidx/camera/core/J0$d;)V

    new-instance v6, LIk/b$a;

    invoke-direct {v6}, LIk/b$a;-><init>()V

    const/16 v7, 0x1000

    filled-new-array {v7}, [I

    move-result-object v7

    invoke-virtual {v6, v7}, LIk/b$a;->b([I)V

    invoke-virtual {v6}, LIk/b$a;->a()LIk/b;

    move-result-object v6

    const-string v7, "You must provide a valid BarcodeScannerOptions."

    invoke-static {v6, v7}, Lcom/google/android/gms/common/internal/Preconditions;->checkNotNull(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, LGk/i;->c()LGk/i;

    move-result-object v7

    const-class v8, LLk/e;

    invoke-virtual {v7, v8}, LGk/i;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LLk/e;

    invoke-virtual {v7, v6}, LLk/e;->a(LIk/b;)Lcom/google/mlkit/vision/barcode/internal/BarcodeScannerImpl;

    move-result-object v6

    iput-object v6, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->h:Lcom/google/mlkit/vision/barcode/internal/BarcodeScannerImpl;

    iget-object v6, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->g:Ljava/util/concurrent/ExecutorService;

    if-eqz v6, :cond_e2

    invoke-interface {v6}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    move-result v6

    if-ne v6, v0, :cond_e8

    :cond_e2
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->g:Ljava/util/concurrent/ExecutorService;

    :cond_e8
    new-instance v0, Landroidx/camera/core/O$c;

    invoke-direct {v0}, Landroidx/camera/core/O$c;-><init>()V

    invoke-virtual {v0, v4}, Landroidx/camera/core/O$c;->j(I)V

    iget-object v4, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->f:Landroidx/camera/view/PreviewView;

    if-eqz v4, :cond_124

    invoke-virtual {v4}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v1

    if-eqz v1, :cond_fe

    invoke-virtual {v1}, Landroid/view/Display;->getRotation()I

    move-result v2

    :cond_fe
    invoke-virtual {v0, v2}, Landroidx/camera/core/O$c;->k(I)V

    invoke-virtual {v0}, Landroidx/camera/core/O$c;->e()Landroidx/camera/core/O;

    move-result-object v0

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->g:Ljava/util/concurrent/ExecutorService;

    if-nez v1, :cond_10a

    goto :goto_112

    :cond_10a
    new-instance v2, Lt/a;

    invoke-direct {v2, p0}, Lt/a;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, v1, v2}, Landroidx/camera/core/O;->N(Ljava/util/concurrent/ExecutorService;Lt/a;)V

    :goto_112
    new-instance v1, Landroidx/camera/core/k1$a;

    invoke-direct {v1}, Landroidx/camera/core/k1$a;-><init>()V

    invoke-virtual {v1, v5}, Landroidx/camera/core/k1$a;->a(Landroidx/camera/core/j1;)V

    invoke-virtual {v1, v0}, Landroidx/camera/core/k1$a;->a(Landroidx/camera/core/j1;)V

    invoke-virtual {v1}, Landroidx/camera/core/k1$a;->b()Landroidx/camera/core/k1;

    move-result-object v0

    iput-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->d:Landroidx/camera/core/k1;

    goto :goto_134

    :cond_124
    invoke-static {v3}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_128
    invoke-static {v3}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_12c
    invoke-static {v3}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_130
    invoke-static {v3}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_134
    :goto_134
    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->d:Landroidx/camera/core/k1;

    const-string v1, "null cannot be cast to non-null type androidx.camera.core.UseCaseGroup"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method private final l(LMk/a;ZLandroidx/camera/core/r0;)V
    .registers 6

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->h:Lcom/google/mlkit/vision/barcode/internal/BarcodeScannerImpl;

    if-eqz v0, :cond_25

    invoke-virtual {v0, p1}, Lcom/google/mlkit/vision/common/internal/MobileVisionBase;->c(LMk/a;)Lzj/k;

    move-result-object p1

    new-instance v1, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;

    invoke-direct {v1, v0, p3, p0, p2}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;-><init>(Lcom/google/mlkit/vision/barcode/internal/BarcodeScannerImpl;Landroidx/camera/core/r0;Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Z)V

    new-instance p2, LVk/i;

    invoke-direct {p2, v1}, LVk/i;-><init>(Leo/l;)V

    invoke-virtual {p1, p2}, Lzj/k;->g(Lzj/g;)Lzj/k;

    new-instance p2, LVk/j;

    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1, p2}, Lzj/k;->e(Lzj/f;)Lzj/k;

    new-instance p2, LVk/k;

    invoke-direct {p2, p3}, LVk/k;-><init>(Landroidx/camera/core/r0;)V

    invoke-virtual {p1, p2}, Lzj/k;->c(Lzj/e;)V

    :cond_25
    return-void
.end method


# virtual methods
.method public final dispose()V
    .registers 2

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->g:Ljava/util/concurrent/ExecutorService;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    :cond_7
    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->e:Landroidx/lifecycle/A;

    if-eqz v0, :cond_13

    invoke-interface {v0}, Landroidx/lifecycle/A;->getLifecycle()Landroidx/lifecycle/q;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroidx/lifecycle/q;->d(Landroidx/lifecycle/z;)V

    return-void

    :cond_13
    const-string v0, "lifecycleOwner"

    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method public final isTorchOn()Z
    .registers 4

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->c:Landroidx/camera/core/l;

    const/4 v1, 0x0

    if-eqz v0, :cond_22

    invoke-interface {v0}, Landroidx/camera/core/l;->a()Landroidx/camera/core/r;

    move-result-object v0

    if-eqz v0, :cond_22

    invoke-interface {v0}, Landroidx/camera/core/r;->g()Landroidx/lifecycle/I;

    move-result-object v0

    if-eqz v0, :cond_22

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_1a

    goto :goto_22

    :cond_1a
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_22

    const/4 v1, 0x1

    :cond_22
    :goto_22
    return v1
.end method

.method public final onCreate(Landroidx/lifecycle/A;)V
    .registers 2

    return-void
.end method

.method public final onPause(Landroidx/lifecycle/A;)V
    .registers 2

    return-void
.end method

.method public final onResume(Landroidx/lifecycle/A;)V
    .registers 2

    return-void
.end method

.method public final onStart(Landroidx/lifecycle/A;)V
    .registers 2

    return-void
.end method

.method public final onStop(Landroidx/lifecycle/A;)V
    .registers 2

    return-void
.end method

.method public final processImageFromPath(Ljava/lang/String;)V
    .registers 3

    const-string v0, "imagePath"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LVk/f;

    invoke-direct {v0, p0, p1}, LVk/f;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final requestLayout()V
    .registers 4

    invoke-super {p0}, Landroid/widget/FrameLayout;->requestLayout()V

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->m:Ljava/lang/Runnable;

    const-wide/16 v1, 0x64

    invoke-virtual {p0, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final setLifecycleOwner(Landroidx/lifecycle/A;)V
    .registers 7

    const-string v0, "lifecycleOwner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->e:Landroidx/lifecycle/A;

    invoke-interface {p1}, Landroidx/lifecycle/A;->getLifecycle()Landroidx/lifecycle/q;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroidx/lifecycle/q;->a(Landroidx/lifecycle/z;)V

    sget-object p1, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->n:[Ljava/lang/String;

    array-length v1, p1

    const/4 v2, 0x0

    :goto_12
    if-ge v2, v1, :cond_2b

    aget-object v3, p1, v2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, v3}, Landroidx/core/content/c;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    if-nez v3, :cond_23

    add-int/lit8 v2, v2, 0x1

    goto :goto_12

    :cond_23
    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->l:Leo/a;

    if-eqz p1, :cond_6b

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    goto :goto_6b

    :cond_2b
    new-instance p1, Landroidx/camera/view/PreviewView;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {p1, v1}, Landroidx/camera/view/PreviewView;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->f:Landroidx/camera/view/PreviewView;

    invoke-virtual {p1}, Landroidx/camera/view/PreviewView;->c()Landroidx/lifecycle/I;

    move-result-object p1

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->e:Landroidx/lifecycle/A;

    const/4 v2, 0x0

    if-eqz v1, :cond_72

    new-instance v0, Lcom/labs/flipkart/cameramodule/c;

    invoke-direct {v0, p0}, Lcom/labs/flipkart/cameramodule/c;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V

    new-instance v3, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$b;

    invoke-direct {v3, v0}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$b;-><init>(Leo/l;)V

    invoke-virtual {p1, v1, v3}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    invoke-virtual {p0}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->f:Landroidx/camera/view/PreviewView;

    if-eqz p1, :cond_6c

    const/4 v0, -0x1

    invoke-virtual {p0, p1, v0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;II)V

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->g:Ljava/util/concurrent/ExecutorService;

    new-instance p1, LVk/g;

    invoke-direct {p1, p0}, LVk/g;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V

    const-wide/16 v0, 0x64

    invoke-virtual {p0, p1, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_6b
    :goto_6b
    return-void

    :cond_6c
    const-string p1, "previewView"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v2

    :cond_72
    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v2
.end method

.method public final setOnInitFailed(Leo/l;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/l<",
            "-",
            "Ljava/lang/Exception;",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->k:Leo/l;

    return-void
.end method

.method public final setOnPermissionDenied(Leo/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->l:Leo/a;

    return-void
.end method

.method public final setOnQrDetected(Leo/p;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/p<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Boolean;",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->i:Leo/p;

    return-void
.end method

.method public final setPreviewStateChange(Leo/l;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/l<",
            "-",
            "Ljava/lang/Boolean;",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->j:Leo/l;

    return-void
.end method

.method public final toggleCameraState(Z)V
    .registers 4

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_38

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->f:Landroidx/camera/view/PreviewView;

    if-eqz v0, :cond_31

    invoke-virtual {v0}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v0

    if-nez v0, :cond_11

    goto :goto_38

    :cond_11
    new-instance v0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$c;

    invoke-direct {v0, p0, p1}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$c;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Z)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Landroidx/camera/lifecycle/e;->e(Landroid/content/Context;)Lcom/google/common/util/concurrent/o;

    move-result-object p1

    new-instance v1, LVk/h;

    invoke-direct {v1, v0, p1}, LVk/h;-><init>(Leo/l;Lcom/google/common/util/concurrent/o;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object v0

    check-cast p1, Lv/d;

    invoke-virtual {p1, v1, v0}, Lv/d;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void

    :cond_31
    const-string p1, "previewView"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    :cond_38
    :goto_38
    return-void
.end method

.method public final toggleTorch()Z
    .registers 6

    invoke-virtual {p0}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->isTorchOn()Z

    move-result v0

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    iget-object v2, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->c:Landroidx/camera/core/l;

    const/4 v3, 0x0

    if-eqz v2, :cond_19

    invoke-interface {v2}, Landroidx/camera/core/l;->b()Landroidx/camera/core/n;

    move-result-object v2

    if-eqz v2, :cond_19

    if-ne v0, v1, :cond_15

    const/4 v4, 0x1

    goto :goto_16

    :cond_15
    const/4 v4, 0x0

    :goto_16
    invoke-interface {v2, v4}, Landroidx/camera/core/n;->d(Z)Lcom/google/common/util/concurrent/o;

    :cond_19
    if-ne v0, v1, :cond_1c

    goto :goto_1d

    :cond_1c
    const/4 v1, 0x0

    :goto_1d
    return v1
.end method
