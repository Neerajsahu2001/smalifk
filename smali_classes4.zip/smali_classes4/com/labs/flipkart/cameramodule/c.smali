.class final Lcom/labs/flipkart/cameramodule/c;
.super Lkotlin/jvm/internal/p;
.source "FkCameraWithQrScannerImpl.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Landroidx/camera/view/PreviewView$g;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;


# direct methods
.method constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V
    .registers 2

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/c;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Landroidx/camera/view/PreviewView$g;

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/c;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    invoke-static {v0}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->e(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)Leo/l;

    move-result-object v0

    if-eqz v0, :cond_18

    sget-object v1, Landroidx/camera/view/PreviewView$g;->STREAMING:Landroidx/camera/view/PreviewView$g;

    if-ne p1, v1, :cond_10

    const/4 p1, 0x1

    goto :goto_11

    :cond_10
    const/4 p1, 0x0

    :goto_11
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_18
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
