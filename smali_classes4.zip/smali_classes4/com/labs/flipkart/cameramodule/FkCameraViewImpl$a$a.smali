.class final Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;
.super Lkotlin/coroutines/jvm/internal/i;
.source "FkCameraViewImpl.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;->b(Landroidx/camera/core/k0$p;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lkotlinx/coroutines/G;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "com.labs.flipkart.cameramodule.FkCameraViewImpl$capture$1$onImageSaved$1"
    f = "FkCameraViewImpl.kt"
    l = {}
    m = "invokeSuspend"
.end annotation


# instance fields
.field final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

.field final synthetic b:Ljava/io/File;

.field final synthetic c:Landroid/util/Size;


# direct methods
.method constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;Ljava/io/File;Landroid/util/Size;LXn/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;",
            "Ljava/io/File;",
            "Landroid/util/Size;",
            "LXn/d<",
            "-",
            "Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    iput-object p2, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->b:Ljava/io/File;

    iput-object p3, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->c:Landroid/util/Size;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance p1, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->b:Ljava/io/File;

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->c:Landroid/util/Size;

    iget-object v2, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    invoke-direct {p1, v2, v0, v1, p2}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;Ljava/io/File;Landroid/util/Size;LXn/d;)V

    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/G;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    invoke-static {p1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->g(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Landroid/util/Size;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->b:Ljava/io/File;

    invoke-static {v1}, Landroidx/camera/core/impl/utils/e;->b(Ljava/io/File;)Landroidx/camera/core/impl/utils/e;

    move-result-object v2

    new-instance v8, Landroid/graphics/Matrix;

    invoke-direct {v8}, Landroid/graphics/Matrix;-><init>()V

    invoke-virtual {v2}, Landroidx/camera/core/impl/utils/e;->f()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v8, v2}, Landroid/graphics/Matrix;->preRotate(F)Z

    invoke-virtual {v1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v3}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    iget-object v4, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;->c:Landroid/util/Size;

    invoke-virtual {v4}, Landroid/util/Size;->getHeight()I

    move-result v5

    if-eqz v0, :cond_35

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v0

    goto :goto_39

    :cond_35
    invoke-virtual {v4}, Landroid/util/Size;->getHeight()I

    move-result v0

    :goto_39
    div-int/2addr v5, v0

    iput v5, v3, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    sget-object v0, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    iput-object v0, v3, Landroid/graphics/BitmapFactory$Options;->inPreferredConfig:Landroid/graphics/Bitmap$Config;

    invoke-static {v2, v3}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v6

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v7

    const/4 v5, 0x0

    const/4 v9, 0x1

    const/4 v4, 0x0

    move-object v3, v0

    invoke-static/range {v3 .. v9}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    move-result-object v2

    const-string v3, "createBitmap(\n          \u2026t, matrix, true\n        )"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    new-instance v4, Ljava/io/FileOutputStream;

    invoke-direct {v4, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/16 v5, 0x64

    invoke-virtual {v2, v3, v5, v4}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    new-instance v3, Landroid/util/Size;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    invoke-direct {v3, v4, v5}, Landroid/util/Size;-><init>(II)V

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    invoke-static {p1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->d(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Leo/p;

    move-result-object p1

    if-eqz p1, :cond_8a

    invoke-static {v1}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v0

    const-string v1, "fromFile(file)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1, v0, v3}, Leo/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_8a
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
