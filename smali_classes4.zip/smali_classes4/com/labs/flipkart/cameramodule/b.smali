.class final synthetic Lcom/labs/flipkart/cameramodule/b;
.super Ljava/lang/Object;
.source "FkCameraViewImpl.kt"

# interfaces
.implements Landroidx/lifecycle/J;
.implements Lkotlin/jvm/internal/j;


# instance fields
.field private final synthetic a:Leo/l;


# direct methods
.method constructor <init>(Leo/l;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/b;->a:Leo/l;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Landroidx/lifecycle/J;

    const/4 v1, 0x0

    if-eqz v0, :cond_15

    instance-of v0, p1, Lkotlin/jvm/internal/j;

    if-eqz v0, :cond_15

    check-cast p1, Lkotlin/jvm/internal/j;

    invoke-interface {p1}, Lkotlin/jvm/internal/j;->getFunctionDelegate()LUn/a;

    move-result-object p1

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/b;->a:Leo/l;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    :cond_15
    return v1
.end method

.method public final getFunctionDelegate()LUn/a;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUn/a<",
            "*>;"
        }
    .end annotation

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/b;->a:Leo/l;

    return-object v0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/b;->a:Leo/l;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public final synthetic onChanged(Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/b;->a:Leo/l;

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
