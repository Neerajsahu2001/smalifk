.class public final Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;
.super Lcom/flipkart/android/reactnative/nativeuimodules/camerax/FkCameraView;
.source "FkCameraViewImpl.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0004\u0010\u0005\u00a8\u0006\u0006"
    }
    d2 = {
        "Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;",
        "Lcom/flipkart/android/reactnative/nativeuimodules/camerax/FkCameraView;",
        "Landroid/content/Context;",
        "context",
        "<init>",
        "(Landroid/content/Context;)V",
        "cameramodule_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
.end annotation


# static fields
.field private static final l:[Ljava/lang/String;

.field public static final synthetic m:I


# instance fields
.field private a:Landroidx/lifecycle/A;

.field private b:Landroidx/camera/view/PreviewView;

.field private c:Ljava/util/concurrent/ExecutorService;

.field private d:Landroidx/camera/core/k0;

.field private e:Landroid/util/Size;

.field private f:Leo/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/p<",
            "-",
            "Landroid/net/Uri;",
            "-",
            "Landroid/util/Size;",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private g:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private h:Leo/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/l<",
            "-",
            "Ljava/lang/Boolean;",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private i:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private j:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private final k:Ljava/lang/Runnable;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "android.permission.CAMERA"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->H([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    sput-object v0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->l:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/flipkart/android/reactnative/nativeuimodules/camerax/FkCameraView;-><init>(Landroid/content/Context;)V

    new-instance p1, LVk/a;

    invoke-direct {p1, p0}, LVk/a;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->k:Ljava/lang/Runnable;

    return-void
.end method

.method public static a(Lcom/google/common/util/concurrent/o;Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V
    .registers 5

    const-string v0, "$cameraProviderFuture"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "this$0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/camera/lifecycle/e;

    invoke-virtual {p0}, Landroidx/camera/lifecycle/e;->h()V

    :try_start_13
    iget-object v0, p1, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->a:Landroidx/lifecycle/A;

    if-eqz v0, :cond_2a

    sget-object v1, Landroidx/camera/core/s;->c:Landroidx/camera/core/s;

    const-string v2, "DEFAULT_BACK_CAMERA"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->h()Landroidx/camera/core/k1;

    move-result-object v2

    invoke-virtual {p0, v0, v1, v2}, Landroidx/camera/lifecycle/e;->c(Landroidx/lifecycle/A;Landroidx/camera/core/s;Landroidx/camera/core/k1;)Landroidx/camera/core/l;

    goto :goto_46

    :catch_26
    move-exception p0

    goto :goto_31

    :catch_28
    move-exception p0

    goto :goto_3c

    :cond_2a
    const-string p0, "lifecycleOwner"

    invoke-static {p0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
    :try_end_31
    .catch Ljava/lang/IllegalStateException; {:try_start_13 .. :try_end_31} :catch_28
    .catch Ljava/lang/IllegalArgumentException; {:try_start_13 .. :try_end_31} :catch_26

    :goto_31
    invoke-static {p0}, LO7/c;->logException(Ljava/lang/Throwable;)V

    iget-object p0, p1, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->i:Leo/a;

    if-eqz p0, :cond_46

    invoke-interface {p0}, Leo/a;->invoke()Ljava/lang/Object;

    goto :goto_46

    :goto_3c
    invoke-static {p0}, LO7/c;->logException(Ljava/lang/Throwable;)V

    iget-object p0, p1, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->i:Leo/a;

    if-eqz p0, :cond_46

    invoke-interface {p0}, Leo/a;->invoke()Ljava/lang/Object;

    :cond_46
    :goto_46
    return-void
.end method

.method public static final synthetic b(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Landroidx/camera/core/k0;
    .registers 1

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->d:Landroidx/camera/core/k0;

    return-object p0
.end method

.method public static final synthetic c(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Landroidx/lifecycle/A;
    .registers 1

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->a:Landroidx/lifecycle/A;

    return-object p0
.end method

.method public static final synthetic d(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Leo/p;
    .registers 1

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->f:Leo/p;

    return-object p0
.end method

.method public static final synthetic e(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Leo/a;
    .registers 1

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->g:Leo/a;

    return-object p0
.end method

.method public static final synthetic f(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Leo/l;
    .registers 1

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->h:Leo/l;

    return-object p0
.end method

.method public static final synthetic g(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Landroid/util/Size;
    .registers 1

    iget-object p0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->e:Landroid/util/Size;

    return-object p0
.end method

.method private final h()Landroidx/camera/core/k1;
    .registers 7

    new-instance v0, Landroidx/camera/core/J0$b;

    invoke-direct {v0}, Landroidx/camera/core/J0$b;-><init>()V

    invoke-virtual {v0}, Landroidx/camera/core/J0$b;->e()Landroidx/camera/core/J0;

    move-result-object v0

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->b:Landroidx/camera/view/PreviewView;

    if-eqz v1, :cond_53

    invoke-virtual {v1}, Landroidx/camera/view/PreviewView;->d()Landroidx/camera/core/J0$d;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/camera/core/J0;->M(Landroidx/camera/core/J0$d;)V

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->e:Landroid/util/Size;

    new-instance v2, Landroidx/camera/core/k0$h;

    invoke-direct {v2}, Landroidx/camera/core/k0$h;-><init>()V

    if-eqz v1, :cond_23

    invoke-virtual {v2, v1}, Landroidx/camera/core/k0$h;->l(Landroid/util/Size;)V

    invoke-virtual {v2}, Landroidx/camera/core/k0$h;->h()V

    :cond_23
    invoke-virtual {v2}, Landroidx/camera/core/k0$h;->e()Landroidx/camera/core/k0;

    move-result-object v1

    iput-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->d:Landroidx/camera/core/k0;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    new-instance v4, Landroidx/camera/core/q1$a;

    new-instance v5, Landroid/util/Rational;

    invoke-direct {v5, v2, v3}, Landroid/util/Rational;-><init>(II)V

    const/4 v2, 0x0

    invoke-direct {v4, v2, v5}, Landroidx/camera/core/q1$a;-><init>(ILandroid/util/Rational;)V

    invoke-virtual {v4}, Landroidx/camera/core/q1$a;->a()Landroidx/camera/core/q1;

    move-result-object v2

    new-instance v3, Landroidx/camera/core/k1$a;

    invoke-direct {v3}, Landroidx/camera/core/k1$a;-><init>()V

    invoke-virtual {v3, v0}, Landroidx/camera/core/k1$a;->a(Landroidx/camera/core/j1;)V

    invoke-virtual {v3, v1}, Landroidx/camera/core/k1$a;->a(Landroidx/camera/core/j1;)V

    invoke-virtual {v3, v2}, Landroidx/camera/core/k1$a;->c(Landroidx/camera/core/q1;)V

    invoke-virtual {v3}, Landroidx/camera/core/k1$a;->b()Landroidx/camera/core/k1;

    move-result-object v0

    return-object v0

    :cond_53
    const-string v0, "previewView"

    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method


# virtual methods
.method public final capture()V
    .registers 6

    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, ".jpeg"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->d:Landroidx/camera/core/k0;

    if-eqz v1, :cond_40

    new-instance v2, Landroidx/camera/core/k0$o$a;

    invoke-direct {v2, v0}, Landroidx/camera/core/k0$o$a;-><init>(Ljava/io/File;)V

    invoke-virtual {v2}, Landroidx/camera/core/k0$o$a;->a()Landroidx/camera/core/k0$o;

    move-result-object v2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Landroidx/core/content/c;->i(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object v3

    new-instance v4, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;

    invoke-direct {v4, p0, v0}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;Ljava/io/File;)V

    invoke-virtual {v1, v2, v3, v4}, Landroidx/camera/core/k0;->X(Landroidx/camera/core/k0$o;Ljava/util/concurrent/Executor;Landroidx/camera/core/k0$n;)V

    return-void

    :cond_40
    const-string v0, "imageCapture"

    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method public final requestLayout()V
    .registers 2

    invoke-super {p0}, Landroid/widget/FrameLayout;->requestLayout()V

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->k:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final setLifecycleOwner(Landroidx/lifecycle/A;)V
    .registers 7

    const-string v0, "lifecycleOwner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->a:Landroidx/lifecycle/A;

    sget-object p1, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->l:[Ljava/lang/String;

    array-length v1, p1

    const/4 v2, 0x0

    :goto_b
    if-ge v2, v1, :cond_24

    aget-object v3, p1, v2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, v3}, Landroidx/core/content/c;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    if-nez v3, :cond_1c

    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_1c
    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->j:Leo/a;

    if-eqz p1, :cond_69

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    goto :goto_69

    :cond_24
    new-instance p1, Landroidx/camera/view/PreviewView;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {p1, v1}, Landroidx/camera/view/PreviewView;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->b:Landroidx/camera/view/PreviewView;

    invoke-virtual {p1}, Landroidx/camera/view/PreviewView;->c()Landroidx/lifecycle/I;

    move-result-object p1

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->a:Landroidx/lifecycle/A;

    const/4 v2, 0x0

    if-eqz v1, :cond_70

    new-instance v0, Lcom/labs/flipkart/cameramodule/a;

    invoke-direct {v0, p0}, Lcom/labs/flipkart/cameramodule/a;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V

    new-instance v3, Lcom/labs/flipkart/cameramodule/b;

    invoke-direct {v3, v0}, Lcom/labs/flipkart/cameramodule/b;-><init>(Leo/l;)V

    invoke-virtual {p1, v1, v3}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/A;Landroidx/lifecycle/J;)V

    invoke-virtual {p0}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->b:Landroidx/camera/view/PreviewView;

    if-eqz p1, :cond_6a

    const/4 v0, -0x1

    invoke-virtual {p0, p1, v0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;II)V

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    const-string v0, "newSingleThreadExecutor()"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->c:Ljava/util/concurrent/ExecutorService;

    new-instance p1, LVk/b;

    invoke-direct {p1, p0}, LVk/b;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)V

    const-wide/16 v0, 0x32

    invoke-virtual {p0, p1, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_69
    :goto_69
    return-void

    :cond_6a
    const-string p1, "previewView"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v2

    :cond_70
    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v2
.end method

.method public final setMaxImageSize(I)V
    .registers 2

    return-void
.end method

.method public final setOnCapture(Leo/p;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/p<",
            "-",
            "Landroid/net/Uri;",
            "-",
            "Landroid/util/Size;",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->f:Leo/p;

    return-void
.end method

.method public final setOnCaptureFailed(Leo/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->g:Leo/a;

    return-void
.end method

.method public final setOnInitFailed(Leo/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->i:Leo/a;

    return-void
.end method

.method public final setOnPermissionDenied(Leo/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->j:Leo/a;

    return-void
.end method

.method public final setPreviewStateChange(Leo/l;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/l<",
            "-",
            "Ljava/lang/Boolean;",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->h:Leo/l;

    return-void
.end method

.method public final setResolution(Landroid/util/Size;)V
    .registers 3

    const-string v0, "size"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->e:Landroid/util/Size;

    return-void
.end method
