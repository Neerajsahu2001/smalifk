.class final Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;
.super Lkotlin/jvm/internal/p;
.source "FkCameraWithQrScannerImpl.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->l(LMk/a;ZLandroidx/camera/core/r0;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Ljava/util/List<",
        "LJk/a;",
        ">;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LIk/a;

.field final synthetic b:Landroidx/camera/core/r0;

.field final synthetic c:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

.field final synthetic d:Z


# direct methods
.method constructor <init>(Lcom/google/mlkit/vision/barcode/internal/BarcodeScannerImpl;Landroidx/camera/core/r0;Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Z)V
    .registers 5

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->a:LIk/a;

    iput-object p2, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->b:Landroidx/camera/core/r0;

    iput-object p3, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->c:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    iput-boolean p4, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->d:Z

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    check-cast p1, Ljava/util/List;

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->a:LIk/a;

    iget-object v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->b:Landroidx/camera/core/r0;

    iget-object v2, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->c:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    iget-boolean v3, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$a;->d:Z

    monitor-enter v0

    :try_start_b
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_1a

    if-nez v1, :cond_1a

    invoke-static {v2, v3}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->i(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Z)V
    :try_end_16
    .catchall {:try_start_b .. :try_end_16} :catchall_18

    monitor-exit v0

    goto :goto_51

    :catchall_18
    move-exception p1

    goto :goto_54

    :cond_1a
    :try_start_1a
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v4
    :try_end_1e
    .catchall {:try_start_1a .. :try_end_1e} :catchall_18

    if-eqz v4, :cond_22

    monitor-exit v0

    goto :goto_51

    :cond_22
    if-eqz v1, :cond_40

    :try_start_24
    invoke-virtual {v2}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;->getScanOnce()Z

    move-result v1

    if-eqz v1, :cond_40

    invoke-virtual {v2}, Lcom/flipkart/android/reactnative/nativeuimodules/qrcodescanner/FkCameraWithQrScanner;->getLastDetectedQrDisplayValue()Ljava/lang/String;

    move-result-object v1

    invoke-static {p1}, Lkotlin/collections/q;->r(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LJk/a;

    invoke-virtual {v4}, LJk/a;->a()Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1
    :try_end_3c
    .catchall {:try_start_24 .. :try_end_3c} :catchall_18

    if-eqz v1, :cond_40

    monitor-exit v0

    goto :goto_51

    :cond_40
    :try_start_40
    invoke-static {p1}, Lkotlin/collections/q;->r(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    const-string v1, "barcodes.first()"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, LJk/a;

    invoke-static {v2, p1, v3}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->j(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;LJk/a;Z)V

    sget-object p1, LUn/r;->a:LUn/r;
    :try_end_50
    .catchall {:try_start_40 .. :try_end_50} :catchall_18

    monitor-exit v0

    :goto_51
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1

    :goto_54
    monitor-exit v0

    throw p1
.end method
