.class public final Lcom/labs/flipkart/cameramodule/FkCameraViewProvider;
.super Ljava/lang/Object;
.source "FkCameraViewProvider.kt"

# interfaces
.implements Lcom/flipkart/android/dynamicmodule/p;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003\u00a8\u0006\u0004"
    }
    d2 = {
        "Lcom/labs/flipkart/cameramodule/FkCameraViewProvider;",
        "Lcom/flipkart/android/dynamicmodule/p;",
        "<init>",
        "()V",
        "cameramodule_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final provide(Lcom/facebook/react/bridge/ReactContext;)Landroid/view/View;
    .registers 3

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    invoke-direct {v0, p1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;-><init>(Landroid/content/Context;)V

    return-object v0
.end method
