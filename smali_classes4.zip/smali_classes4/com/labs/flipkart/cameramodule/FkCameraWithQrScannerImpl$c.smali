.class final Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$c;
.super Lkotlin/jvm/internal/p;
.source "FkCameraWithQrScannerImpl.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->toggleCameraState(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Landroidx/camera/lifecycle/e;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

.field final synthetic b:Z


# direct methods
.method constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Z)V
    .registers 3

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$c;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    iput-boolean p2, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$c;->b:Z

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    check-cast p1, Landroidx/camera/lifecycle/e;

    const-string v0, "cameraProvider"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$c;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    invoke-static {v0}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->g(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)Landroidx/camera/core/k1;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/camera/core/k1;->a()Ljava/util/List;

    move-result-object v1

    const-string v2, "getUseCaseGroup().useCases"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    instance-of v2, v1, Ljava/util/Collection;

    const/4 v3, 0x1

    if-eqz v2, :cond_27

    move-object v2, v1

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_27

    goto :goto_3e

    :cond_27
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/j1;

    invoke-virtual {p1, v2}, Landroidx/camera/lifecycle/e;->f(Landroidx/camera/core/j1;)Z

    move-result v2

    if-nez v2, :cond_2b

    const/4 v3, 0x0

    :cond_3e
    :goto_3e
    iget-boolean v1, p0, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl$c;->b:Z

    if-eqz v1, :cond_48

    if-eqz v3, :cond_4d

    invoke-virtual {p1}, Landroidx/camera/lifecycle/e;->h()V

    goto :goto_4d

    :cond_48
    if-nez v3, :cond_4d

    invoke-static {v0, p1}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->h(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Landroidx/camera/lifecycle/e;)V

    :cond_4d
    :goto_4d
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
