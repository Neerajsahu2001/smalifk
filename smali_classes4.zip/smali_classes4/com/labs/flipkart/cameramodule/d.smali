.class final Lcom/labs/flipkart/cameramodule/d;
.super Lkotlin/jvm/internal/p;
.source "FkCameraWithQrScannerImpl.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Landroidx/camera/lifecycle/e;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;


# direct methods
.method constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;)V
    .registers 2

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/d;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Landroidx/camera/lifecycle/e;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/labs/flipkart/cameramodule/d;->a:Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;

    invoke-static {v0, p1}, Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;->h(Lcom/labs/flipkart/cameramodule/FkCameraWithQrScannerImpl;Landroidx/camera/lifecycle/e;)V

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
