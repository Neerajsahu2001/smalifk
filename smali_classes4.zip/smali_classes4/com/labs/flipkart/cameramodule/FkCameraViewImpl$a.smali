.class public final Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;
.super Ljava/lang/Object;
.source "FkCameraViewImpl.kt"

# interfaces
.implements Landroidx/camera/core/k0$n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->capture()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

.field final synthetic b:Ljava/io/File;


# direct methods
.method constructor <init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;Ljava/io/File;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    iput-object p2, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;->b:Ljava/io/File;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/camera/core/n0;)V
    .registers 2

    invoke-static {p1}, LO7/c;->logException(Ljava/lang/Throwable;)V

    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    invoke-static {p1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->e(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Leo/a;

    move-result-object p1

    if-eqz p1, :cond_e

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    :cond_e
    return-void
.end method

.method public final b(Landroidx/camera/core/k0$p;)V
    .registers 8

    iget-object p1, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;->a:Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;

    invoke-static {p1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->b(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Landroidx/camera/core/k0;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_49

    invoke-virtual {v0}, Landroidx/camera/core/k0;->S()Landroidx/camera/core/U0;

    move-result-object v0

    if-eqz v0, :cond_23

    invoke-virtual {v0}, Landroidx/camera/core/U0;->a()Landroid/graphics/Rect;

    move-result-object v0

    if-eqz v0, :cond_23

    new-instance v2, Landroid/util/Size;

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v3

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    invoke-direct {v2, v3, v0}, Landroid/util/Size;-><init>(II)V

    goto :goto_29

    :cond_23
    new-instance v2, Landroid/util/Size;

    const/4 v0, 0x0

    invoke-direct {v2, v0, v0}, Landroid/util/Size;-><init>(II)V

    :goto_29
    invoke-static {p1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;->c(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;)Landroidx/lifecycle/A;

    move-result-object v0

    if-eqz v0, :cond_43

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->c(Landroidx/lifecycle/A;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    move-result-object v0

    invoke-static {}, Lkotlinx/coroutines/S;->a()Lkotlinx/coroutines/scheduling/c;

    move-result-object v3

    new-instance v4, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;

    iget-object v5, p0, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a;->b:Ljava/io/File;

    invoke-direct {v4, p1, v5, v2, v1}, Lcom/labs/flipkart/cameramodule/FkCameraViewImpl$a$a;-><init>(Lcom/labs/flipkart/cameramodule/FkCameraViewImpl;Ljava/io/File;Landroid/util/Size;LXn/d;)V

    const/4 p1, 0x2

    invoke-static {v0, v3, v4, p1}, Lkotlinx/coroutines/h;->b(Lkotlinx/coroutines/G;LXn/f$a;Leo/p;I)Lkotlinx/coroutines/j0;

    return-void

    :cond_43
    const-string p1, "lifecycleOwner"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_49
    const-string p1, "imageCapture"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1
.end method
