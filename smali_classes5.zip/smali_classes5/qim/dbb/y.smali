.class public Lqim/dbb/y;
.super Ljava/lang/Object;
.source "Parcel.java"


# static fields
.field public static a:Ljava/lang/String; = ""

.field public static b:Z = false

.field public static pa:Ljava/lang/String; = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYWNrYWdlTmFtZSI6ImNvbS5mbGlwa2FydC5hbmRyb2lkIiwiYXVkIjoiQkpaWkFGREciLCJleHAiOjY3MDMxMjc5NzgsImlhdCI6MjY1OTQ3MDkyMywiaXNzIjoiIiwianRpIjoiIiwibmJmIjowLCJzdWIiOiI2Njc5OTIyNzU5IiwidHlwZSI6IiJ9.dEVP0yAEx_YTGF-a3M2j7_G1NME00WazxwIddEy7AfpmwzlEN94LxF6rF8FTtW0y5yl6QnNP3NXD\nu7-bvoEmHobZGD1LKAb-QRUmZ5CvFDlWPKStdBI_tI0W5dyEzNdXYR_ar-GL2KAagXKvXZcEt-rB\nQgd10f8Ju5XPbtn9bc2FG75gUBB_lfDl1xzYEDJ0uj0LtwvkDjgLqnTZcAhdj9Yb1Lgs4M9ksIzU\nC-ZP3zDLFsWKGJPaOGeZkoNmSrbucPC-eJC8XGOrYpX8M5B0VlM7kQtR5fcjVysvzK3KdSwN0JGQ\nOhunufMLqHy0_PxRZJ0PPp1fyvVbIjFxzIp20A==\n"


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static enforceInterface(Landroid/os/Parcel;Ljava/lang/String;)V
    .registers 25
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "p",
            "str"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    new-instance v2, Ljava/lang/String;

    const/16 v3, 0x34

    new-array v3, v3, [B

    fill-array-data v3, :array_140

    invoke-direct {v2, v3}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/16 v6, 0x74

    const/16 v7, 0x9

    const/16 v8, 0x8

    const/16 v9, 0x49

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x4

    const/16 v14, 0x6f

    const/4 v15, 0x3

    const/16 v16, 0x2

    const/16 v3, 0x10

    const/16 v17, 0x63

    const/16 v18, 0x72

    const/16 v19, 0x66

    const/16 v20, 0x6e

    const/4 v4, 0x1

    const/16 v21, 0x0

    const/16 v22, 0x65

    if-eqz v2, :cond_8a

    :try_start_36
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    new-instance v5, Ljava/lang/String;

    new-array v3, v3, [B

    aput-byte v22, v3, v21

    aput-byte v20, v3, v4

    aput-byte v19, v3, v16

    aput-byte v14, v3, v15

    aput-byte v18, v3, v13

    aput-byte v17, v3, v12

    aput-byte v22, v3, v11

    aput-byte v9, v3, v10

    aput-byte v20, v3, v8

    aput-byte v6, v3, v7

    const/16 v6, 0xa

    aput-byte v22, v3, v6

    const/16 v6, 0xb

    aput-byte v18, v3, v6

    const/16 v6, 0xc

    aput-byte v19, v3, v6

    const/16 v6, 0xd

    const/16 v7, 0x61

    aput-byte v7, v3, v6

    const/16 v6, 0xe

    aput-byte v17, v3, v6

    const/16 v6, 0xf

    aput-byte v22, v3, v6

    invoke-direct {v5, v3}, Ljava/lang/String;-><init>([B)V

    new-array v3, v4, [Ljava/lang/Class;

    const-class v6, Ljava/lang/String;

    aput-object v6, v3, v21

    invoke-virtual {v2, v5, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    new-array v3, v4, [Ljava/lang/Object;

    aput-object v0, v3, v21

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_80
    .catchall {:try_start_36 .. :try_end_80} :catchall_81

    goto :goto_85

    :catchall_81
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_85
    invoke-static/range {p0 .. p0}, Lqim/dbb/y;->s(Landroid/os/Parcel;)V

    goto/16 :goto_13e

    :cond_8a
    new-instance v2, Ljava/lang/String;

    const/16 v5, 0x36

    new-array v5, v5, [B

    fill-array-data v5, :array_15e

    invoke-direct {v2, v5}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_ef

    :try_start_9c
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    new-instance v5, Ljava/lang/String;

    new-array v3, v3, [B

    aput-byte v22, v3, v21

    aput-byte v20, v3, v4

    aput-byte v19, v3, v16

    aput-byte v14, v3, v15

    aput-byte v18, v3, v13

    aput-byte v17, v3, v12

    aput-byte v22, v3, v11

    aput-byte v9, v3, v10

    aput-byte v20, v3, v8

    aput-byte v6, v3, v7

    const/16 v6, 0xa

    aput-byte v22, v3, v6

    const/16 v6, 0xb

    aput-byte v18, v3, v6

    const/16 v6, 0xc

    aput-byte v19, v3, v6

    const/16 v6, 0xd

    const/16 v7, 0x61

    aput-byte v7, v3, v6

    const/16 v6, 0xe

    aput-byte v17, v3, v6

    const/16 v6, 0xf

    aput-byte v22, v3, v6

    invoke-direct {v5, v3}, Ljava/lang/String;-><init>([B)V

    new-array v3, v4, [Ljava/lang/Class;

    const-class v6, Ljava/lang/String;

    aput-object v6, v3, v21

    invoke-virtual {v2, v5, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    new-array v3, v4, [Ljava/lang/Object;

    aput-object v0, v3, v21

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_e6
    .catchall {:try_start_9c .. :try_end_e6} :catchall_e7

    goto :goto_eb

    :catchall_e7
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_eb
    invoke-static/range {p0 .. p0}, Lqim/dbb/y;->s2(Landroid/os/Parcel;)V

    goto :goto_13e

    :cond_ef
    :try_start_ef
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    new-instance v5, Ljava/lang/String;

    new-array v3, v3, [B

    aput-byte v22, v3, v21

    aput-byte v20, v3, v4

    aput-byte v19, v3, v16

    aput-byte v14, v3, v15

    aput-byte v18, v3, v13

    aput-byte v17, v3, v12

    aput-byte v22, v3, v11

    aput-byte v9, v3, v10

    aput-byte v20, v3, v8

    aput-byte v6, v3, v7

    const/16 v6, 0xa

    aput-byte v22, v3, v6

    const/16 v6, 0xb

    aput-byte v18, v3, v6

    const/16 v6, 0xc

    aput-byte v19, v3, v6

    const/16 v6, 0xd

    const/16 v7, 0x61

    aput-byte v7, v3, v6

    const/16 v6, 0xe

    aput-byte v17, v3, v6

    const/16 v6, 0xf

    aput-byte v22, v3, v6

    invoke-direct {v5, v3}, Ljava/lang/String;-><init>([B)V

    new-array v3, v4, [Ljava/lang/Class;

    const-class v6, Ljava/lang/String;

    aput-object v6, v3, v21

    invoke-virtual {v2, v5, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    new-array v3, v4, [Ljava/lang/Object;

    aput-object v0, v3, v21

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_139
    .catchall {:try_start_ef .. :try_end_139} :catchall_13a

    goto :goto_13e

    :catchall_13a
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_13e
    return-void

    nop

    :array_140
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x61t
        0x6et
        0x64t
        0x72t
        0x6ft
        0x69t
        0x64t
        0x2et
        0x76t
        0x65t
        0x6et
        0x64t
        0x69t
        0x6et
        0x67t
        0x2et
        0x6ct
        0x69t
        0x63t
        0x65t
        0x6et
        0x73t
        0x69t
        0x6et
        0x67t
        0x2et
        0x49t
        0x4ct
        0x69t
        0x63t
        0x65t
        0x6et
        0x73t
        0x65t
        0x52t
        0x65t
        0x73t
        0x75t
        0x6ct
        0x74t
        0x4ct
        0x69t
        0x73t
        0x74t
        0x65t
        0x6et
        0x65t
        0x72t
    .end array-data

    :array_15e
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x61t
        0x6et
        0x64t
        0x72t
        0x6ft
        0x69t
        0x64t
        0x2et
        0x76t
        0x65t
        0x6et
        0x64t
        0x69t
        0x6et
        0x67t
        0x2et
        0x6ct
        0x69t
        0x63t
        0x65t
        0x6et
        0x73t
        0x69t
        0x6et
        0x67t
        0x2et
        0x49t
        0x4ct
        0x69t
        0x63t
        0x65t
        0x6et
        0x73t
        0x65t
        0x56t
        0x32t
        0x52t
        0x65t
        0x73t
        0x75t
        0x6ct
        0x74t
        0x4ct
        0x69t
        0x73t
        0x74t
        0x65t
        0x6et
        0x65t
        0x72t
    .end array-data
.end method

.method public static s(Landroid/os/Parcel;)V
    .registers 14
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "p"
        }
    .end annotation

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    invoke-virtual {p0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v3

    const/4 v4, 0x1

    if-ne v0, v4, :cond_c8

    invoke-virtual {p0, v3}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    if-eqz v1, :cond_bc

    const-wide v5, 0x757b12c00L

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    new-instance v9, Ljava/lang/String;

    const/4 v10, 0x2

    new-array v10, v10, [B

    fill-array-data v10, :array_cc

    invoke-direct {v9, v10}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v1, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    new-instance v9, Ljava/lang/String;

    new-array v10, v4, [B

    const/16 v11, 0x30

    aput-byte v11, v10, v0

    invoke-direct {v9, v10}, Ljava/lang/String;-><init>([B)V

    aput-object v9, v1, v0

    const/4 v9, 0x5

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    add-long/2addr v5, v7

    invoke-virtual {v10, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    new-instance v11, Ljava/lang/String;

    const/16 v12, 0xa

    new-array v12, v12, [B

    fill-array-data v12, :array_d2

    invoke-direct {v11, v12}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-wide/16 v11, 0x1

    add-long/2addr v5, v11

    invoke-virtual {v10, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    new-instance v5, Ljava/lang/String;

    const/4 v6, 0x4

    new-array v6, v6, [B

    fill-array-data v6, :array_dc

    invoke-direct {v5, v6}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-wide v5, 0xeaf625800L

    add-long/2addr v7, v5

    invoke-virtual {v10, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v1, v9

    const-string v5, ""

    const/4 v6, 0x0

    :goto_80
    array-length v7, v1

    if-ge v6, v7, :cond_bb

    array-length v7, v1

    sub-int/2addr v7, v4

    if-ge v6, v7, :cond_a7

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v5, v1, v6

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v5, Ljava/lang/String;

    new-array v8, v4, [B

    const/16 v9, 0x7c

    aput-byte v9, v8, v0

    invoke-direct {v5, v8}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_b8

    :cond_a7
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v5, v1, v6

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :goto_b8
    add-int/lit8 v6, v6, 0x1

    goto :goto_80

    :cond_bb
    move-object v1, v5

    :cond_bc
    sput-object v1, Lqim/dbb/y;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    invoke-virtual {p0, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    invoke-virtual {p0, v3}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_cb

    :cond_c8
    invoke-virtual {p0, v3}, Landroid/os/Parcel;->setDataPosition(I)V

    :goto_cb
    return-void

    :array_cc
    .array-data 1
        0x5ct
        0x7ct
    .end array-data

    nop

    :array_d2
    .array-data 1
        0x3at
        0x47t
        0x52t
        0x3dt
        0x31t
        0x30t
        0x26t
        0x56t
        0x54t
        0x3dt
    .end array-data

    nop

    :array_dc
    .array-data 1
        0x26t
        0x47t
        0x54t
        0x3dt
    .end array-data
.end method

.method public static s2(Landroid/os/Parcel;)V
    .registers 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "p"
        }
    .end annotation

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_13

    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v1, p0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    goto :goto_14

    :cond_13
    const/4 v1, 0x0

    :goto_14
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    sget-object v3, Lqim/dbb/y;->pa:Ljava/lang/String;

    const-string v4, "."

    invoke-virtual {v3, v4}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v3, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lqim/dbb/y;->a:Ljava/lang/String;

    sget-object v3, Lqim/dbb/y;->pa:Ljava/lang/String;

    new-instance v4, Ljava/lang/String;

    const/16 v6, 0xc

    new-array v6, v6, [B

    fill-array-data v6, :array_50

    invoke-direct {v4, v6}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v0, :cond_4b

    invoke-virtual {p0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    invoke-virtual {p0, v5}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {v1, p0, v5}, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel;I)V

    invoke-virtual {p0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_4e

    :cond_4b
    invoke-virtual {p0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    :goto_4e
    return-void

    nop

    :array_50
    .array-data 1
        0x4ct
        0x49t
        0x43t
        0x45t
        0x4et
        0x53t
        0x45t
        0x5ft
        0x44t
        0x41t
        0x54t
        0x41t
    .end array-data
.end method

.method public static update(Ljava/security/Signature;[B)V
    .registers 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "signature",
            "bytes"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    sget-object v0, Lqim/dbb/y;->a:Ljava/lang/String;

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_1c

    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, p1}, Ljava/lang/String;-><init>([B)V

    sget-object v3, Lqim/dbb/y;->a:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1c

    sput-boolean v1, Lqim/dbb/y;->b:Z

    goto :goto_1e

    :cond_1c
    sput-boolean v2, Lqim/dbb/y;->b:Z

    :goto_1e
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    new-instance v3, Ljava/lang/String;

    const/4 v4, 0x6

    new-array v4, v4, [B

    fill-array-data v4, :array_40

    invoke-direct {v3, v4}, Ljava/lang/String;-><init>([B)V

    new-array v4, v1, [Ljava/lang/Class;

    const-class v5, [B

    aput-object v5, v4, v2

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v1, v1, [Ljava/lang/Object;

    aput-object p1, v1, v2

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    nop

    :array_40
    .array-data 1
        0x75t
        0x70t
        0x64t
        0x61t
        0x74t
        0x65t
    .end array-data
.end method

.method public static verify(Ljava/security/Signature;[B)Z
    .registers 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "signature",
            "bytes"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    sget-boolean v0, Lqim/dbb/y;->b:Z

    const/4 v1, 0x1

    if-nez v0, :cond_2e

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    new-instance v2, Ljava/lang/String;

    const/4 v3, 0x6

    new-array v3, v3, [B

    fill-array-data v3, :array_30

    invoke-direct {v2, v3}, Ljava/lang/String;-><init>([B)V

    new-array v3, v1, [Ljava/lang/Class;

    const-class v4, [B

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v0, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v1, v1, [Ljava/lang/Object;

    aput-object p1, v1, v5

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    :cond_2e
    return v1

    nop

    :array_30
    .array-data 1
        0x76t
        0x65t
        0x72t
        0x69t
        0x66t
        0x79t
    .end array-data
.end method
