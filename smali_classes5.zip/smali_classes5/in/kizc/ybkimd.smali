.class public Lin/kizc/ybkimd;
.super Ljava/lang/Object;
.source "SigningInfo.java"


# static fields
.field static sig_data:Ljava/lang/String; = "AQAAA6wwggOoMIICkKADAgECAgRODxspMA0GCSqGSIb3DQEBBQUAMIGVMQswCQYDVQQGEwJJTjESMBAGA1UECBMJS2FybmF0YWthMRIwEAYDVQQHEwlCYW5nYWxvcmUxKTAnBgNVBAoTIEZsaXBrYXJ0IE9ubGluZSBTZXJ2aWNlcyBQdnQgTHRkMRQwEgYDVQQLEwtNb2JpbGUgQXBwczEdMBsGA1UEAxMURmxpcGthcnQgQW5kcm9pZCBBcHAwHhcNMTEwNzAyMTMyMDQxWhcNMzgxMTE3MTMyMDQxWjCBlTELMAkGA1UEBhMCSU4xEjAQBgNVBAgTCUthcm5hdGFrYTESMBAGA1UEBxMJQmFuZ2Fsb3JlMSkwJwYDVQQKEyBGbGlwa2FydCBPbmxpbmUgU2VydmljZXMgUHZ0IEx0ZDEUMBIGA1UECxMLTW9iaWxlIEFwcHMxHTAbBgNVBAMTFEZsaXBrYXJ0IEFuZHJvaWQgQXBwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn0oRuRgoypjkTIpJEKLQYlrkReIbtmz6vOO+sj2iMbhR8jSfPGBE2Wm7ZTnboGOamo5WZFUhn3n17gdhfIN0NdjOZQkTnbZeC3OOIBU7JkEdBj9qQUsiJKKkS9EENbTSWQ7mi752z3+ydsCc4Lst5FNJ/c3NimwxMfyHSzPun7IaWBcPc7S480P/8OW3YXcYLhdV2MwnzrWW/5iyeCUJzSwES+QUTsCFZj9g4+Jl0RyZGpjDFzG91jFWsVdeIUPR/zgh/uVqKg716P8bXC30V13ci0CkG+9UI6gLRktF9bxknS1AFMQREk62lXtumeSc+BgMYDc2dlAvaEjBfnBXpwIDAQABMA0GCSqGSIb3DQEBBQUAA4IBAQAPhtjL9ANBaPG/lDggq+T559AICHvHJdwuLIoLTmd2I+bbMWqriYLmu7FVHR5TeZJMJwkjpFAktZCa8fu7QxYMWgaYEcSdg+uAEKqo8zJ7xj1CP8uRpOzS73Bp4SXFSmp2+HqWoFqerQDvsO+ADo8LWZtoSGP7MdzRrA3Yk/3BsJ/vY6GyWGecPI7F22FxrobH1A4xqOOu1GXfbBs59JLe1qVLP9sVjQiBjD/3yiJwml+bMf5gf5v0UnF8w05TmrKStlwZqfLAPPB9zyMuiaizOlOL3Yh9/5RIdCtDfNBa36V7ir+DO1BsENou7RHiP/Tl2Y1mQGTqyl/PfdheNO+F"

.field public static signatures:[Landroid/content/pm/Signature;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a()V
    .registers 6

    :try_start_0
    new-instance v0, Ljava/io/DataInputStream;

    new-instance v1, Ljava/io/ByteArrayInputStream;

    sget-object v2, Lin/kizc/ybkimd;->sig_data:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {v2, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v0, v1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v0}, Ljava/io/DataInputStream;->read()I

    move-result v1

    and-int/lit16 v1, v1, 0xff

    new-array v2, v1, [[B

    const/4 v4, 0x0

    :goto_1a
    if-ge v4, v1, :cond_2c

    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    move-result v5

    new-array v5, v5, [B

    aput-object v5, v2, v4

    aget-object v5, v2, v4

    invoke-virtual {v0, v5}, Ljava/io/DataInputStream;->readFully([B)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_1a

    :cond_2c
    new-array v0, v1, [Landroid/content/pm/Signature;

    sput-object v0, Lin/kizc/ybkimd;->signatures:[Landroid/content/pm/Signature;

    :goto_30
    sget-object v0, Lin/kizc/ybkimd;->signatures:[Landroid/content/pm/Signature;

    array-length v1, v0

    if-ge v3, v1, :cond_45

    new-instance v1, Landroid/content/pm/Signature;

    aget-object v4, v2, v3

    invoke-direct {v1, v4}, Landroid/content/pm/Signature;-><init>([B)V

    aput-object v1, v0, v3
    :try_end_3e
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_3e} :catch_41

    add-int/lit8 v3, v3, 0x1

    goto :goto_30

    :catch_41
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    :cond_45
    return-void
.end method

.method public static getApkContentsSigners()[Landroid/content/pm/Signature;
    .registers 1

    sget-object v0, Lin/kizc/ybkimd;->signatures:[Landroid/content/pm/Signature;

    if-nez v0, :cond_9

    invoke-static {}, Lin/kizc/ybkimd;->a()V

    sget-object v0, Lin/kizc/ybkimd;->signatures:[Landroid/content/pm/Signature;

    :cond_9
    return-object v0
.end method

.method public static getSigningCertificateHistory(Landroid/content/pm/SigningInfo;)[Landroid/content/pm/Signature;
    .registers 1

    invoke-virtual {p0}, Landroid/content/pm/SigningInfo;->hasMultipleSigners()Z

    move-result p0

    if-eqz p0, :cond_8

    const/4 p0, 0x0

    return-object p0

    :cond_8
    sget-object p0, Lin/kizc/ybkimd;->signatures:[Landroid/content/pm/Signature;

    if-nez p0, :cond_11

    invoke-static {}, Lin/kizc/ybkimd;->a()V

    sget-object p0, Lin/kizc/ybkimd;->signatures:[Landroid/content/pm/Signature;

    :cond_11
    return-object p0
.end method
