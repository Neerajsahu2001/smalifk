.class final Lfn/b;
.super Ljava/lang/Object;
.source "DefaultPlayerUiController.kt"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Lfn/h;


# direct methods
.method constructor <init>(Lfn/h;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lfn/b;->a:Lfn/h;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget-object p1, p0, Lfn/b;->a:Lfn/h;

    invoke-static {p1}, Lfn/h;->h(Lfn/h;)Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;

    move-result-object v0

    invoke-static {p1}, Lfn/h;->d(Lfn/h;)Landroid/widget/ImageView;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;->a(Landroid/widget/ImageView;)V

    return-void
.end method
