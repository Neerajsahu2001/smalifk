.class final Lfn/f;
.super Ljava/lang/Object;
.source "DefaultPlayerUiController.kt"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Lfn/h;


# direct methods
.method constructor <init>(Lfn/h;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lfn/f;->a:Lfn/h;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget-object p1, p0, Lfn/f;->a:Lfn/h;

    invoke-static {p1}, Lfn/h;->e(Lfn/h;)Landroid/view/View$OnClickListener;

    move-result-object v0

    invoke-static {p1}, Lfn/h;->c(Lfn/h;)Landroid/widget/ImageView;

    move-result-object p1

    check-cast v0, Lfn/a;

    invoke-virtual {v0, p1}, Lfn/a;->onClick(Landroid/view/View;)V

    return-void
.end method
