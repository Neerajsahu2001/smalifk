.class public final Lfn/h;
.super Ljava/lang/Object;
.source "DefaultPlayerUiController.kt"

# interfaces
.implements Lbn/d;
.implements Lbn/c;
.implements Ljn/b;


# instance fields
.field private a:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;

.field private final b:Landroid/view/View;

.field private final c:Landroid/view/View;

.field private final d:Landroid/widget/LinearLayout;

.field private final e:Landroid/widget/TextView;

.field private final f:Landroid/widget/TextView;

.field private final g:Landroid/widget/ProgressBar;

.field private final h:Landroid/widget/ImageView;

.field private final i:Landroid/widget/ImageView;

.field private final j:Landroid/widget/ImageView;

.field private final k:Landroid/widget/ImageView;

.field private final l:Landroid/widget/ImageView;

.field private final m:Landroid/widget/ImageView;

.field private final n:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

.field private o:Landroid/view/View$OnClickListener;

.field private p:Landroid/view/View$OnClickListener;

.field private final q:Lin/b;

.field private r:Z

.field private s:Z

.field private final t:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/LegacyYouTubePlayerView;

.field private final u:Lan/e;


# direct methods
.method public constructor <init>(Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/LegacyYouTubePlayerView;Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/WebViewYouTubePlayer;)V
    .registers 10

    const-string v0, "youTubePlayerView"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lfn/h;->t:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/LegacyYouTubePlayerView;

    iput-object p2, p0, Lfn/h;->u:Lan/e;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lfn/h;->s:Z

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, LZm/e;->ayp_default_player_ui:I

    invoke-static {v0, v1, p1}, Landroid/view/View;->inflate(Landroid/content/Context;ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const-string v2, "youTubePlayerView.context"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v1, p1}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lfn/h;->a:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;

    sget p1, LZm/d;->panel:I

    invoke-virtual {v0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const-string v1, "controlsView.findViewById(R.id.panel)"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lfn/h;->b:Landroid/view/View;

    sget v1, LZm/d;->controls_container:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const-string v2, "controlsView.findViewById(R.id.controls_container)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v1, p0, Lfn/h;->c:Landroid/view/View;

    sget v2, LZm/d;->extra_views_container:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "controlsView.findViewByI\u2026id.extra_views_container)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/widget/LinearLayout;

    iput-object v2, p0, Lfn/h;->d:Landroid/widget/LinearLayout;

    sget v2, LZm/d;->video_title:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "controlsView.findViewById(R.id.video_title)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lfn/h;->e:Landroid/widget/TextView;

    sget v2, LZm/d;->live_video_indicator:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "controlsView.findViewByI\u2026.id.live_video_indicator)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lfn/h;->f:Landroid/widget/TextView;

    sget v2, LZm/d;->progress:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "controlsView.findViewById(R.id.progress)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/widget/ProgressBar;

    iput-object v2, p0, Lfn/h;->g:Landroid/widget/ProgressBar;

    sget v2, LZm/d;->menu_button:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "controlsView.findViewById(R.id.menu_button)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/widget/ImageView;

    iput-object v2, p0, Lfn/h;->h:Landroid/widget/ImageView;

    sget v3, LZm/d;->play_pause_button:I

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    const-string v4, "controlsView.findViewById(R.id.play_pause_button)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Landroid/widget/ImageView;

    iput-object v3, p0, Lfn/h;->i:Landroid/widget/ImageView;

    sget v4, LZm/d;->youtube_button:I

    invoke-virtual {v0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const-string v5, "controlsView.findViewById(R.id.youtube_button)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Landroid/widget/ImageView;

    iput-object v4, p0, Lfn/h;->j:Landroid/widget/ImageView;

    sget v4, LZm/d;->fullscreen_button:I

    invoke-virtual {v0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const-string v5, "controlsView.findViewById(R.id.fullscreen_button)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Landroid/widget/ImageView;

    iput-object v4, p0, Lfn/h;->k:Landroid/widget/ImageView;

    sget v5, LZm/d;->custom_action_left_button:I

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    const-string v6, "controlsView.findViewByI\u2026ustom_action_left_button)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Landroid/widget/ImageView;

    iput-object v5, p0, Lfn/h;->l:Landroid/widget/ImageView;

    sget v5, LZm/d;->custom_action_right_button:I

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    const-string v6, "controlsView.findViewByI\u2026stom_action_right_button)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Landroid/widget/ImageView;

    iput-object v5, p0, Lfn/h;->m:Landroid/widget/ImageView;

    sget v5, LZm/d;->youtube_player_seekbar:I

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const-string v5, "controlsView.findViewByI\u2026d.youtube_player_seekbar)"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

    iput-object v0, p0, Lfn/h;->n:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

    new-instance v5, Lin/b;

    invoke-direct {v5, v1}, Lin/b;-><init>(Landroid/view/View;)V

    iput-object v5, p0, Lfn/h;->q:Lin/b;

    new-instance v1, Lfn/a;

    invoke-direct {v1, p0}, Lfn/a;-><init>(Lfn/h;)V

    iput-object v1, p0, Lfn/h;->o:Landroid/view/View$OnClickListener;

    new-instance v1, Lfn/b;

    invoke-direct {v1, p0}, Lfn/b;-><init>(Lfn/h;)V

    iput-object v1, p0, Lfn/h;->p:Landroid/view/View$OnClickListener;

    invoke-virtual {p2, v0}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/WebViewYouTubePlayer;->d(Lbn/d;)Z

    invoke-virtual {p2, v5}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/WebViewYouTubePlayer;->d(Lbn/d;)Z

    invoke-virtual {v0, p0}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;->d(Ljn/b;)V

    new-instance p2, Lfn/d;

    invoke-direct {p2, p0}, Lfn/d;-><init>(Lfn/h;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance p1, Lfn/e;

    invoke-direct {p1, p0}, Lfn/e;-><init>(Lfn/h;)V

    invoke-virtual {v3, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance p1, Lfn/f;

    invoke-direct {p1, p0}, Lfn/f;-><init>(Lfn/h;)V

    invoke-virtual {v4, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance p1, Lfn/g;

    invoke-direct {p1, p0}, Lfn/g;-><init>(Lfn/h;)V

    invoke-virtual {v2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public static final synthetic a(Lfn/h;)Lin/b;
    .registers 1

    iget-object p0, p0, Lfn/h;->q:Lin/b;

    return-object p0
.end method

.method public static final synthetic c(Lfn/h;)Landroid/widget/ImageView;
    .registers 1

    iget-object p0, p0, Lfn/h;->k:Landroid/widget/ImageView;

    return-object p0
.end method

.method public static final synthetic d(Lfn/h;)Landroid/widget/ImageView;
    .registers 1

    iget-object p0, p0, Lfn/h;->h:Landroid/widget/ImageView;

    return-object p0
.end method

.method public static final synthetic e(Lfn/h;)Landroid/view/View$OnClickListener;
    .registers 1

    iget-object p0, p0, Lfn/h;->o:Landroid/view/View$OnClickListener;

    return-object p0
.end method

.method public static final synthetic f(Lfn/h;)Landroid/view/View$OnClickListener;
    .registers 1

    iget-object p0, p0, Lfn/h;->p:Landroid/view/View$OnClickListener;

    return-object p0
.end method

.method public static final synthetic g(Lfn/h;)Landroid/widget/ImageView;
    .registers 1

    iget-object p0, p0, Lfn/h;->j:Landroid/widget/ImageView;

    return-object p0
.end method

.method public static final synthetic h(Lfn/h;)Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;
    .registers 1

    iget-object p0, p0, Lfn/h;->a:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/menu/defaultMenu/DefaultYouTubePlayerMenu;

    return-object p0
.end method

.method public static final synthetic i(Lfn/h;)Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/LegacyYouTubePlayerView;
    .registers 1

    iget-object p0, p0, Lfn/h;->t:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/LegacyYouTubePlayerView;

    return-object p0
.end method

.method public static final synthetic j(Lfn/h;)Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;
    .registers 1

    iget-object p0, p0, Lfn/h;->n:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

    return-object p0
.end method

.method public static final k(Lfn/h;)V
    .registers 2

    iget-boolean v0, p0, Lfn/h;->r:Z

    iget-object p0, p0, Lfn/h;->u:Lan/e;

    if-eqz v0, :cond_a

    invoke-interface {p0}, Lan/e;->pause()V

    goto :goto_d

    :cond_a
    invoke-interface {p0}, Lan/e;->play()V

    :goto_d
    return-void
.end method


# virtual methods
.method public final b(F)V
    .registers 3

    iget-object v0, p0, Lfn/h;->u:Lan/e;

    invoke-interface {v0, p1}, Lan/e;->b(F)V

    return-void
.end method

.method public final l(Landroid/widget/ImageView;)Lfn/h;
    .registers 4

    const-string v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lfn/h;->d:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    return-object p0
.end method

.method public final m(Z)Lfn/h;
    .registers 5

    const/4 v0, 0x0

    if-eqz p1, :cond_5

    const/4 v1, 0x4

    goto :goto_6

    :cond_5
    const/4 v1, 0x0

    :goto_6
    iget-object v2, p0, Lfn/h;->n:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    if-eqz p1, :cond_e

    goto :goto_10

    :cond_e
    const/16 v0, 0x8

    :goto_10
    iget-object p1, p0, Lfn/h;->f:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    return-object p0
.end method

.method public final n(Z)Lfn/h;
    .registers 3

    iget-object v0, p0, Lfn/h;->n:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

    invoke-virtual {v0}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;->b()Landroid/widget/TextView;

    move-result-object v0

    if-eqz p1, :cond_a

    const/4 p1, 0x0

    goto :goto_c

    :cond_a
    const/16 p1, 0x8

    :goto_c
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    return-object p0
.end method

.method public final o(Z)Lfn/h;
    .registers 3

    iget-object v0, p0, Lfn/h;->n:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

    invoke-virtual {v0}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;->c()Landroid/widget/TextView;

    move-result-object v0

    if-eqz p1, :cond_a

    const/4 p1, 0x0

    goto :goto_c

    :cond_a
    const/16 p1, 0x8

    :goto_c
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    return-object p0
.end method

.method public final onApiChange(Lan/e;)V
    .registers 3

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onCurrentSecond(Lan/e;F)V
    .registers 3

    const-string p2, "youTubePlayer"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onError(Lan/e;Lan/c;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "error"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onPlaybackQualityChange(Lan/e;Lan/a;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "playbackQuality"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onPlaybackRateChange(Lan/e;Lan/b;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "playbackRate"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onReady(Lan/e;)V
    .registers 3

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onStateChange(Lan/e;Lan/d;)V
    .registers 10

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "state"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lfn/c;->a:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget p1, p1, v0

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eq p1, v0, :cond_23

    const/4 v2, 0x2

    if-eq p1, v2, :cond_20

    const/4 v2, 0x3

    if-eq p1, v2, :cond_1d

    goto :goto_25

    :cond_1d
    iput-boolean v0, p0, Lfn/h;->r:Z

    goto :goto_25

    :cond_20
    iput-boolean v1, p0, Lfn/h;->r:Z

    goto :goto_25

    :cond_23
    iput-boolean v1, p0, Lfn/h;->r:Z

    :goto_25
    iget-boolean p1, p0, Lfn/h;->r:Z

    xor-int/2addr p1, v0

    if-eqz p1, :cond_2d

    sget p1, LZm/c;->ayp_ic_pause_36dp:I

    goto :goto_2f

    :cond_2d
    sget p1, LZm/c;->ayp_ic_play_36dp:I

    :goto_2f
    iget-object v0, p0, Lfn/h;->i:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object p1, Lan/d;->PLAYING:Lan/d;

    const v2, 0x106000d

    iget-object v3, p0, Lfn/h;->b:Landroid/view/View;

    iget-object v4, p0, Lfn/h;->g:Landroid/widget/ProgressBar;

    const/16 v5, 0x8

    if-eq p2, p1, :cond_82

    sget-object v6, Lan/d;->PAUSED:Lan/d;

    if-eq p2, v6, :cond_82

    sget-object v6, Lan/d;->VIDEO_CUED:Lan/d;

    if-ne p2, v6, :cond_4a

    goto :goto_82

    :cond_4a
    sget p1, LZm/c;->ayp_ic_play_36dp:I

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object p1, Lan/d;->BUFFERING:Lan/d;

    if-ne p2, p1, :cond_73

    invoke-virtual {v4, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1, v2}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v3, p1}, Landroid/view/View;->setBackgroundColor(I)V

    iget-boolean p1, p0, Lfn/h;->s:Z

    if-eqz p1, :cond_69

    const/4 p1, 0x4

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_69
    iget-object p1, p0, Lfn/h;->l:Landroid/widget/ImageView;

    invoke-virtual {p1, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    iget-object p1, p0, Lfn/h;->m:Landroid/widget/ImageView;

    invoke-virtual {p1, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_73
    sget-object p1, Lan/d;->UNSTARTED:Lan/d;

    if-ne p2, p1, :cond_a1

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    iget-boolean p1, p0, Lfn/h;->s:Z

    if-eqz p1, :cond_a1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_a1

    :cond_82
    :goto_82
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6, v2}, Landroidx/core/content/c;->c(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v3, v2}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    iget-boolean v2, p0, Lfn/h;->s:Z

    if-eqz v2, :cond_97

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_97
    if-ne p2, p1, :cond_9c

    sget p1, LZm/c;->ayp_ic_pause_36dp:I

    goto :goto_9e

    :cond_9c
    sget p1, LZm/c;->ayp_ic_play_36dp:I

    :goto_9e
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_a1
    :goto_a1
    return-void
.end method

.method public final onVideoDuration(Lan/e;F)V
    .registers 3

    const-string p2, "youTubePlayer"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onVideoId(Lan/e;Ljava/lang/String;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "videoId"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p1, Lfn/h$a;

    invoke-direct {p1, p0, p2}, Lfn/h$a;-><init>(Lfn/h;Ljava/lang/String;)V

    iget-object p2, p0, Lfn/h;->j:Landroid/widget/ImageView;

    invoke-virtual {p2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public final onVideoLoadedFraction(Lan/e;F)V
    .registers 3

    const-string p2, "youTubePlayer"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onYouTubePlayerEnterFullScreen()V
    .registers 3

    iget-object v0, p0, Lfn/h;->k:Landroid/widget/ImageView;

    sget v1, LZm/c;->ayp_ic_fullscreen_exit_24dp:I

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void
.end method

.method public final onYouTubePlayerExitFullScreen()V
    .registers 3

    iget-object v0, p0, Lfn/h;->k:Landroid/widget/ImageView;

    sget v1, LZm/c;->ayp_ic_fullscreen_24dp:I

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void
.end method

.method public final p(Z)Lfn/h;
    .registers 3

    if-eqz p1, :cond_4

    const/4 p1, 0x0

    goto :goto_6

    :cond_4
    const/16 p1, 0x8

    :goto_6
    iget-object v0, p0, Lfn/h;->k:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    return-object p0
.end method

.method public final q(Z)Lfn/h;
    .registers 4

    if-eqz p1, :cond_4

    const/4 v0, 0x0

    goto :goto_6

    :cond_4
    const/16 v0, 0x8

    :goto_6
    iget-object v1, p0, Lfn/h;->i:Landroid/widget/ImageView;

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    iput-boolean p1, p0, Lfn/h;->s:Z

    return-object p0
.end method

.method public final r(Z)Lfn/h;
    .registers 3

    iget-object v0, p0, Lfn/h;->n:Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;

    invoke-virtual {v0}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/ui/views/YouTubePlayerSeekBar;->a()Landroid/widget/SeekBar;

    move-result-object v0

    if-eqz p1, :cond_a

    const/4 p1, 0x0

    goto :goto_b

    :cond_a
    const/4 p1, 0x4

    :goto_b
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    return-object p0
.end method

.method public final s(Z)Lfn/h;
    .registers 3

    if-eqz p1, :cond_4

    const/4 p1, 0x0

    goto :goto_6

    :cond_4
    const/16 p1, 0x8

    :goto_6
    iget-object v0, p0, Lfn/h;->e:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    return-object p0
.end method

.method public final t(Z)Lfn/h;
    .registers 3

    if-eqz p1, :cond_4

    const/4 p1, 0x0

    goto :goto_6

    :cond_4
    const/16 p1, 0x8

    :goto_6
    iget-object v0, p0, Lfn/h;->j:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    return-object p0
.end method
