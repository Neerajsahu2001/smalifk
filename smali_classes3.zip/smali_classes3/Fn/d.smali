.class final Lfn/d;
.super Ljava/lang/Object;
.source "DefaultPlayerUiController.kt"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Lfn/h;


# direct methods
.method constructor <init>(Lfn/h;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lfn/d;->a:Lfn/h;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 2

    iget-object p1, p0, Lfn/d;->a:Lfn/h;

    invoke-static {p1}, Lfn/h;->a(Lfn/h;)Lin/b;

    move-result-object p1

    invoke-virtual {p1}, Lin/b;->d()V

    return-void
.end method
