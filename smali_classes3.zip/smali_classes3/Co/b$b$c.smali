.class final Lco/b$b$c;
.super Lco/b$a;
.source "FileTreeWalk.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lco/b$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "c"
.end annotation


# instance fields
.field private b:Z

.field private c:[Ljava/io/File;

.field private d:I

.field final synthetic e:Lco/b$b;


# direct methods
.method public constructor <init>(Lco/b$b;Ljava/io/File;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            ")V"
        }
    .end annotation

    const-string v0, "rootDir"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lco/b$b$c;->e:Lco/b$b;

    invoke-direct {p0, p2}, Lco/b$c;-><init>(Ljava/io/File;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/io/File;
    .registers 6

    iget-boolean v0, p0, Lco/b$b$c;->b:Z

    iget-object v1, p0, Lco/b$b$c;->e:Lco/b$b;

    if-nez v0, :cond_13

    iget-object v0, v1, Lco/b$b;->d:Lco/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lco/b$b$c;->b:Z

    invoke-virtual {p0}, Lco/b$c;->a()Ljava/io/File;

    move-result-object v0

    return-object v0

    :cond_13
    iget-object v0, p0, Lco/b$b$c;->c:[Ljava/io/File;

    const/4 v2, 0x0

    if-eqz v0, :cond_24

    iget v3, p0, Lco/b$b$c;->d:I

    array-length v4, v0

    if-ge v3, v4, :cond_1e

    goto :goto_24

    :cond_1e
    iget-object v0, v1, Lco/b$b;->d:Lco/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v2

    :cond_24
    :goto_24
    if-nez v0, :cond_44

    invoke-virtual {p0}, Lco/b$c;->a()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    iput-object v0, p0, Lco/b$b$c;->c:[Ljava/io/File;

    if-nez v0, :cond_37

    iget-object v0, v1, Lco/b$b;->d:Lco/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_37
    iget-object v0, p0, Lco/b$b$c;->c:[Ljava/io/File;

    if-eqz v0, :cond_3e

    array-length v0, v0

    if-nez v0, :cond_44

    :cond_3e
    iget-object v0, v1, Lco/b$b;->d:Lco/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v2

    :cond_44
    iget-object v0, p0, Lco/b$b$c;->c:[Ljava/io/File;

    invoke-static {v0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    iget v1, p0, Lco/b$b$c;->d:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lco/b$b$c;->d:I

    aget-object v0, v0, v1

    return-object v0
.end method
