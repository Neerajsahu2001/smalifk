.class final Lco/b$b$a;
.super Lco/b$a;
.source "FileTreeWalk.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lco/b$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation


# instance fields
.field private b:Z

.field private c:[Ljava/io/File;

.field private d:I

.field private e:Z

.field final synthetic f:Lco/b$b;


# direct methods
.method public constructor <init>(Lco/b$b;Ljava/io/File;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            ")V"
        }
    .end annotation

    const-string v0, "rootDir"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lco/b$b$a;->f:Lco/b$b;

    invoke-direct {p0, p2}, Lco/b$c;-><init>(Ljava/io/File;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/io/File;
    .registers 6

    iget-boolean v0, p0, Lco/b$b$a;->e:Z

    const/4 v1, 0x1

    iget-object v2, p0, Lco/b$b$a;->f:Lco/b$b;

    if-nez v0, :cond_23

    iget-object v0, p0, Lco/b$b$a;->c:[Ljava/io/File;

    if-nez v0, :cond_23

    iget-object v0, v2, Lco/b$b;->d:Lco/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lco/b$c;->a()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    iput-object v0, p0, Lco/b$b$a;->c:[Ljava/io/File;

    if-nez v0, :cond_23

    iget-object v0, v2, Lco/b$b;->d:Lco/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-boolean v1, p0, Lco/b$b$a;->e:Z

    :cond_23
    iget-object v0, p0, Lco/b$b$a;->c:[Ljava/io/File;

    if-eqz v0, :cond_38

    iget v3, p0, Lco/b$b$a;->d:I

    array-length v4, v0

    if-ge v3, v4, :cond_38

    invoke-static {v0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    iget v1, p0, Lco/b$b$a;->d:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lco/b$b$a;->d:I

    aget-object v0, v0, v1

    return-object v0

    :cond_38
    iget-boolean v0, p0, Lco/b$b$a;->b:Z

    if-nez v0, :cond_43

    iput-boolean v1, p0, Lco/b$b$a;->b:Z

    invoke-virtual {p0}, Lco/b$c;->a()Ljava/io/File;

    move-result-object v0

    return-object v0

    :cond_43
    iget-object v0, v2, Lco/b$b;->d:Lco/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    return-object v0
.end method
