.class final Lco/g;
.super Ljava/lang/Object;
.source "ReadWrite.kt"

# interfaces
.implements Lup/h;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lup/h<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Ljava/io/BufferedReader;


# direct methods
.method public constructor <init>(Ljava/io/BufferedReader;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lco/g;->a:Ljava/io/BufferedReader;

    return-void
.end method

.method public static final synthetic b(Lco/g;)Ljava/io/BufferedReader;
    .registers 1

    iget-object p0, p0, Lco/g;->a:Ljava/io/BufferedReader;

    return-object p0
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Lco/g$a;

    invoke-direct {v0, p0}, Lco/g$a;-><init>(Lco/g;)V

    return-object v0
.end method
