.class public final Lco/i;
.super Ljava/lang/Object;
.source "ReadWrite.kt"


# direct methods
.method public static final a(Ljava/io/InputStreamReader;)Ljava/util/ArrayList;
    .registers 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lco/h;

    invoke-direct {v1, v0}, Lco/h;-><init>(Ljava/util/ArrayList;)V

    instance-of v2, p0, Ljava/io/BufferedReader;

    if-eqz v2, :cond_11

    check-cast p0, Ljava/io/BufferedReader;

    goto :goto_19

    :cond_11
    new-instance v2, Ljava/io/BufferedReader;

    const/16 v3, 0x2000

    invoke-direct {v2, p0, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object p0, v2

    :goto_19
    :try_start_19
    new-instance v2, Lco/g;

    invoke-direct {v2, p0}, Lco/g;-><init>(Ljava/io/BufferedReader;)V

    invoke-static {v2}, Lup/k;->a(Lup/h;)Lup/h;

    move-result-object v2

    invoke-interface {v2}, Lup/h;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_26
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_36

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Lco/h;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_26

    :catchall_34
    move-exception v0

    goto :goto_3d

    :cond_36
    sget-object v1, LUn/r;->a:LUn/r;
    :try_end_38
    .catchall {:try_start_19 .. :try_end_38} :catchall_34

    const/4 v1, 0x0

    invoke-static {p0, v1}, Lcom/facebook/imagepipeline/producers/r0;->b(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    :goto_3d
    :try_start_3d
    throw v0
    :try_end_3e
    .catchall {:try_start_3d .. :try_end_3e} :catchall_3e

    :catchall_3e
    move-exception v1

    invoke-static {p0, v0}, Lcom/facebook/imagepipeline/producers/r0;->b(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v1
.end method
