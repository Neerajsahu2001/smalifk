.class final Lco/b$b$b;
.super Lco/b$c;
.source "FileTreeWalk.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lco/b$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "b"
.end annotation


# instance fields
.field private b:Z


# virtual methods
.method public final b()Ljava/io/File;
    .registers 2

    iget-boolean v0, p0, Lco/b$b$b;->b:Z

    if-eqz v0, :cond_6

    const/4 v0, 0x0

    return-object v0

    :cond_6
    const/4 v0, 0x1

    iput-boolean v0, p0, Lco/b$b$b;->b:Z

    invoke-virtual {p0}, Lco/b$c;->a()Ljava/io/File;

    move-result-object v0

    return-object v0
.end method
