.class public final Lco/b;
.super Ljava/lang/Object;
.source "FileTreeWalk.kt"

# interfaces
.implements Lup/h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lco/b$c;,
        Lco/b$a;,
        Lco/b$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lup/h<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Ljava/io/File;

.field private final b:Lco/c;


# direct methods
.method public constructor <init>(Ljava/io/File;Lco/c;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lco/b;->a:Ljava/io/File;

    iput-object p2, p0, Lco/b;->b:Lco/c;

    return-void
.end method

.method public static final synthetic b(Lco/b;)Lco/c;
    .registers 1

    iget-object p0, p0, Lco/b;->b:Lco/c;

    return-object p0
.end method

.method public static final synthetic c(Lco/b;)I
    .registers 1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p0, 0x7fffffff

    return p0
.end method

.method public static final synthetic d(Lco/b;)Ljava/io/File;
    .registers 1

    iget-object p0, p0, Lco/b;->a:Ljava/io/File;

    return-object p0
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation

    new-instance v0, Lco/b$b;

    invoke-direct {v0, p0}, Lco/b$b;-><init>(Lco/b;)V

    return-object v0
.end method
