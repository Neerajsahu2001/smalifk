.class public final Lco/d;
.super Lco/f;


# direct methods
.method public static a(Ljava/io/File;)V
    .registers 5

    sget-object v0, Lco/c;->BOTTOM_UP:Lco/c;

    const-string v1, "direction"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lco/b;

    invoke-direct {v1, p0, v0}, Lco/b;-><init>(Ljava/io/File;Lco/c;)V

    new-instance p0, Lco/b$b;

    invoke-direct {p0, v1}, Lco/b$b;-><init>(Lco/b;)V

    const/4 v0, 0x1

    :goto_12
    const/4 v1, 0x1

    :goto_13
    invoke-virtual {p0}, Lkotlin/collections/b;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_30

    invoke-virtual {p0}, Lkotlin/collections/b;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    move-result v3

    if-nez v3, :cond_2b

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_2e

    :cond_2b
    if-eqz v1, :cond_2e

    goto :goto_12

    :cond_2e
    const/4 v1, 0x0

    goto :goto_13

    :cond_30
    return-void
.end method

.method public static b(Ljava/io/File;)[B
    .registers 10

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    :try_start_a
    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v1
    :try_end_e
    .catchall {:try_start_a .. :try_end_e} :catchall_28

    const-wide/32 v3, 0x7fffffff

    const-string v5, "File "

    cmp-long v6, v1, v3

    if-gtz v6, :cond_84

    long-to-int v2, v1

    :try_start_18
    new-array v1, v2, [B

    const/4 v3, 0x0

    move v4, v2

    const/4 v6, 0x0

    :goto_1d
    if-lez v4, :cond_2b

    invoke-virtual {v0, v1, v6, v4}, Ljava/io/FileInputStream;->read([BII)I

    move-result v7
    :try_end_23
    .catchall {:try_start_18 .. :try_end_23} :catchall_28

    if-ltz v7, :cond_2b

    sub-int/2addr v4, v7

    add-int/2addr v6, v7

    goto :goto_1d

    :catchall_28
    move-exception p0

    goto/16 :goto_a3

    :cond_2b
    const-string v7, "copyOf(this, newSize)"

    if-lez v4, :cond_37

    :try_start_2f
    invoke-static {v1, v6}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v1

    invoke-static {v1, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_65

    :cond_37
    invoke-virtual {v0}, Ljava/io/FileInputStream;->read()I

    move-result v4

    const/4 v6, -0x1

    if-ne v4, v6, :cond_3f

    goto :goto_65

    :cond_3f
    new-instance v6, Lco/a;

    const/16 v8, 0x2001

    invoke-direct {v6, v8}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    invoke-virtual {v6, v4}, Ljava/io/OutputStream;->write(I)V

    invoke-static {v0, v6}, LHj/a;->g(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v4

    add-int/2addr v4, v2

    if-ltz v4, :cond_6a

    invoke-virtual {v6}, Lco/a;->c()[B

    move-result-object p0

    invoke-static {v1, v4}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v1

    invoke-static {v1, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v4

    invoke-static {p0, v2, v1, v3, v4}, Lkotlin/collections/h;->h([BI[BII)V
    :try_end_65
    .catchall {:try_start_2f .. :try_end_65} :catchall_28

    :goto_65
    const/4 p0, 0x0

    invoke-static {v0, p0}, Lcom/facebook/imagepipeline/producers/r0;->b(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v1

    :cond_6a
    :try_start_6a
    new-instance v1, Ljava/lang/OutOfMemoryError;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " is too big to fit in memory."

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/OutOfMemoryError;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_84
    new-instance v3, Ljava/lang/OutOfMemoryError;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " is too big ("

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p0, " bytes) to fit in memory."

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v3, p0}, Ljava/lang/OutOfMemoryError;-><init>(Ljava/lang/String;)V

    throw v3
    :try_end_a3
    .catchall {:try_start_6a .. :try_end_a3} :catchall_28

    :goto_a3
    :try_start_a3
    throw p0
    :try_end_a4
    .catchall {:try_start_a3 .. :try_end_a4} :catchall_a4

    :catchall_a4
    move-exception v1

    invoke-static {v0, p0}, Lcom/facebook/imagepipeline/producers/r0;->b(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v1
.end method
