.class public final enum Lco/c;
.super Ljava/lang/Enum;
.source "FileTreeWalk.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lco/c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lco/c;

.field public static final enum BOTTOM_UP:Lco/c;

.field public static final enum TOP_DOWN:Lco/c;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance v2, Lco/c;

    const-string v3, "TOP_DOWN"

    invoke-direct {v2, v3, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lco/c;->TOP_DOWN:Lco/c;

    new-instance v3, Lco/c;

    const-string v4, "BOTTOM_UP"

    invoke-direct {v3, v4, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lco/c;->BOTTOM_UP:Lco/c;

    const/4 v4, 0x2

    new-array v4, v4, [Lco/c;

    aput-object v2, v4, v1

    aput-object v3, v4, v0

    sput-object v4, Lco/c;->$VALUES:[Lco/c;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lco/c;
    .registers 2

    const-class v0, Lco/c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lco/c;

    return-object p0
.end method

.method public static values()[Lco/c;
    .registers 1

    sget-object v0, Lco/c;->$VALUES:[Lco/c;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lco/c;

    return-object v0
.end method
