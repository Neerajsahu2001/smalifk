.class final Lco/a;
.super Ljava/io/ByteArrayOutputStream;
.source "FileReadWrite.kt"


# virtual methods
.method public final c()[B
    .registers 3

    iget-object v0, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    const-string v1, "buf"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method
