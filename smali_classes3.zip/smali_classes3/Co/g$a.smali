.class public final Lco/g$a;
.super Ljava/lang/Object;
.source "ReadWrite.kt"

# interfaces
.implements Ljava/util/Iterator;
.implements Lfo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lco/g;->iterator()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "Ljava/lang/String;",
        ">;",
        "Lfo/a;"
    }
.end annotation


# instance fields
.field private a:Ljava/lang/String;

.field private b:Z

.field final synthetic c:Lco/g;


# direct methods
.method constructor <init>(Lco/g;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lco/g$a;->c:Lco/g;

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 3

    iget-object v0, p0, Lco/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x1

    if-nez v0, :cond_19

    iget-boolean v0, p0, Lco/g$a;->b:Z

    if-nez v0, :cond_19

    iget-object v0, p0, Lco/g$a;->c:Lco/g;

    invoke-static {v0}, Lco/g;->b(Lco/g;)Ljava/io/BufferedReader;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lco/g$a;->a:Ljava/lang/String;

    if-nez v0, :cond_19

    iput-boolean v1, p0, Lco/g$a;->b:Z

    :cond_19
    iget-object v0, p0, Lco/g$a;->a:Ljava/lang/String;

    if-eqz v0, :cond_1e

    goto :goto_1f

    :cond_1e
    const/4 v1, 0x0

    :goto_1f
    return v1
.end method

.method public final next()Ljava/lang/Object;
    .registers 3

    invoke-virtual {p0}, Lco/g$a;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_f

    iget-object v0, p0, Lco/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object v1, p0, Lco/g$a;->a:Ljava/lang/String;

    invoke-static {v0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    return-object v0

    :cond_f
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final remove()V
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "Operation is not supported for read-only collection"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
