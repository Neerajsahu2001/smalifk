.class final Lco/b$b;
.super Lkotlin/collections/b;
.source "FileTreeWalk.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lco/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lco/b$b$a;,
        Lco/b$b$c;,
        Lco/b$b$b;,
        Lco/b$b$d;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/collections/b<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# instance fields
.field private final c:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Lco/b$c;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic d:Lco/b;


# direct methods
.method public constructor <init>(Lco/b;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lco/b$b;->d:Lco/b;

    invoke-direct {p0}, Lkotlin/collections/b;-><init>()V

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lco/b$b;->c:Ljava/util/ArrayDeque;

    invoke-static {p1}, Lco/b;->d(Lco/b;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-eqz v1, :cond_22

    invoke-static {p1}, Lco/b;->d(Lco/b;)Ljava/io/File;

    move-result-object p1

    invoke-direct {p0, p1}, Lco/b$b;->d(Ljava/io/File;)Lco/b$a;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    goto :goto_41

    :cond_22
    invoke-static {p1}, Lco/b;->d(Lco/b;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->isFile()Z

    move-result v1

    if-eqz v1, :cond_3e

    new-instance v1, Lco/b$b$b;

    invoke-static {p1}, Lco/b;->d(Lco/b;)Ljava/io/File;

    move-result-object p1

    const-string v2, "rootFile"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v1, p1}, Lco/b$c;-><init>(Ljava/io/File;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    goto :goto_41

    :cond_3e
    invoke-virtual {p0}, Lkotlin/collections/b;->b()V

    :goto_41
    return-void
.end method

.method private final d(Ljava/io/File;)Lco/b$a;
    .registers 5

    iget-object v0, p0, Lco/b$b;->d:Lco/b;

    invoke-static {v0}, Lco/b;->b(Lco/b;)Lco/c;

    move-result-object v0

    sget-object v1, Lco/b$b$d;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_20

    const/4 v2, 0x2

    if-ne v0, v2, :cond_1a

    new-instance v0, Lco/b$b$a;

    invoke-direct {v0, p0, p1}, Lco/b$b$a;-><init>(Lco/b$b;Ljava/io/File;)V

    goto :goto_25

    :cond_1a
    new-instance p1, LMj/z;

    invoke-direct {p1, v1}, LMj/z;-><init>(I)V

    throw p1

    :cond_20
    new-instance v0, Lco/b$b$c;

    invoke-direct {v0, p0, p1}, Lco/b$b$c;-><init>(Lco/b$b;Ljava/io/File;)V

    :goto_25
    return-object v0
.end method


# virtual methods
.method protected final a()V
    .registers 5

    :goto_0
    iget-object v0, p0, Lco/b$b;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lco/b$c;

    if-nez v1, :cond_c

    const/4 v0, 0x0

    goto :goto_3c

    :cond_c
    invoke-virtual {v1}, Lco/b$c;->b()Ljava/io/File;

    move-result-object v2

    if-nez v2, :cond_16

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pop()Ljava/lang/Object;

    goto :goto_0

    :cond_16
    invoke-virtual {v1}, Lco/b$c;->a()Ljava/io/File;

    move-result-object v1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3b

    invoke-virtual {v2}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-eqz v1, :cond_3b

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    move-result v1

    iget-object v3, p0, Lco/b$b;->d:Lco/b;

    invoke-static {v3}, Lco/b;->c(Lco/b;)I

    move-result v3

    if-lt v1, v3, :cond_33

    goto :goto_3b

    :cond_33
    invoke-direct {p0, v2}, Lco/b$b;->d(Ljava/io/File;)Lco/b$a;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    goto :goto_0

    :cond_3b
    :goto_3b
    move-object v0, v2

    :goto_3c
    if-eqz v0, :cond_42

    invoke-virtual {p0, v0}, Lkotlin/collections/b;->c(Ljava/lang/Object;)V

    goto :goto_45

    :cond_42
    invoke-virtual {p0}, Lkotlin/collections/b;->b()V

    :goto_45
    return-void
.end method
