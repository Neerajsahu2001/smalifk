.class public final enum LHk/a;
.super Ljava/lang/Enum;
.source "com.google.mlkit:common@@17.5.0"


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LHk/a;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum ENTITY_EXTRACTION:LHk/a;
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static final enum TOXICITY_DETECTION:LHk/a;
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static final enum TRANSLATE:LHk/a;
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static final enum zza:LHk/a;
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation
.end field

.field public static final enum zzb:LHk/a;
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation
.end field

.field private static final synthetic zzc:[LHk/a;


# direct methods
.method static constructor <clinit>()V
    .registers 11

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v5, LHk/a;

    const-string v6, "FACE_DETECTION"

    invoke-direct {v5, v6, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LHk/a;->zza:LHk/a;

    new-instance v6, LHk/a;

    const-string v7, "SMART_REPLY"

    invoke-direct {v6, v7, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, LHk/a;->zzb:LHk/a;

    new-instance v7, LHk/a;

    const-string v8, "TRANSLATE"

    invoke-direct {v7, v8, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, LHk/a;->TRANSLATE:LHk/a;

    new-instance v8, LHk/a;

    const-string v9, "ENTITY_EXTRACTION"

    invoke-direct {v8, v9, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, LHk/a;->ENTITY_EXTRACTION:LHk/a;

    new-instance v9, LHk/a;

    const-string v10, "TOXICITY_DETECTION"

    invoke-direct {v9, v10, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, LHk/a;->TOXICITY_DETECTION:LHk/a;

    const/4 v10, 0x5

    new-array v10, v10, [LHk/a;

    aput-object v5, v10, v4

    aput-object v6, v10, v3

    aput-object v7, v10, v2

    aput-object v8, v10, v1

    aput-object v9, v10, v0

    sput-object v10, LHk/a;->zzc:[LHk/a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static values()[LHk/a;
    .registers 1
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    sget-object v0, LHk/a;->zzc:[LHk/a;

    invoke-virtual {v0}, [LHk/a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LHk/a;

    return-object v0
.end method
