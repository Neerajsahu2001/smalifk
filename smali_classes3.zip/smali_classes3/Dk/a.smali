.class public final synthetic LDk/a;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Lcom/google/firebase/components/ComponentFactory;


# static fields
.field public static final synthetic a:LDk/a;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, LDk/a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LDk/a;->a:LDk/a;

    return-void
.end method


# virtual methods
.method public final create(Lcom/google/firebase/components/ComponentContainer;)Ljava/lang/Object;
    .registers 4

    new-instance v0, LHk/b;

    const-class v1, LGk/i;

    invoke-interface {p1, v1}, Lcom/google/firebase/components/ComponentContainer;->get(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LGk/i;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-object v0
.end method
