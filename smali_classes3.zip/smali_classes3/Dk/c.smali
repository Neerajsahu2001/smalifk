.class public final synthetic LDk/c;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Lcom/google/firebase/components/ComponentFactory;


# static fields
.field public static final synthetic a:LDk/c;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, LDk/c;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LDk/c;->a:LDk/c;

    return-void
.end method


# virtual methods
.method public final create(Lcom/google/firebase/components/ComponentContainer;)Ljava/lang/Object;
    .registers 3

    const-class v0, LFk/c$a;

    invoke-interface {p1, v0}, Lcom/google/firebase/components/ComponentContainer;->setOf(Ljava/lang/Class;)Ljava/util/Set;

    move-result-object p1

    new-instance v0, LFk/c;

    invoke-direct {v0, p1}, LFk/c;-><init>(Ljava/util/Set;)V

    return-object v0
.end method
