.class public final synthetic LDk/b;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Lcom/google/firebase/components/ComponentFactory;


# static fields
.field public static final synthetic a:LDk/b;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, LDk/b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LDk/b;->a:LDk/b;

    return-void
.end method


# virtual methods
.method public final create(Lcom/google/firebase/components/ComponentContainer;)Ljava/lang/Object;
    .registers 2

    new-instance p1, LGk/j;

    invoke-direct {p1}, LGk/j;-><init>()V

    return-object p1
.end method
