.class public final synthetic LDk/d;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Lcom/google/firebase/components/ComponentFactory;


# static fields
.field public static final synthetic a:LDk/d;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, LDk/d;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LDk/d;->a:LDk/d;

    return-void
.end method


# virtual methods
.method public final create(Lcom/google/firebase/components/ComponentContainer;)Ljava/lang/Object;
    .registers 4

    new-instance v0, LGk/d;

    const-class v1, LGk/j;

    invoke-interface {p1, v1}, Lcom/google/firebase/components/ComponentContainer;->getProvider(Ljava/lang/Class;)Lcom/google/firebase/inject/Provider;

    move-result-object p1

    invoke-direct {v0, p1}, LGk/d;-><init>(Lcom/google/firebase/inject/Provider;)V

    return-object v0
.end method
