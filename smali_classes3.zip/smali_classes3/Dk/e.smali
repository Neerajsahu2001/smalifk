.class public final synthetic LDk/e;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Lcom/google/firebase/components/ComponentFactory;


# static fields
.field public static final synthetic a:LDk/e;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, LDk/e;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LDk/e;->a:LDk/e;

    return-void
.end method


# virtual methods
.method public final create(Lcom/google/firebase/components/ComponentContainer;)Ljava/lang/Object;
    .registers 2

    invoke-static {}, LGk/a;->a()LGk/a;

    move-result-object p1

    return-object p1
.end method
