.class public interface abstract Lan/e;
.super Ljava/lang/Object;
.source "YouTubePlayer.kt"


# virtual methods
.method public abstract b(F)V
.end method

.method public abstract d(Lbn/d;)Z
.end method

.method public abstract e(Ljava/lang/String;F)V
.end method

.method public abstract f(Ljava/lang/String;F)V
.end method

.method public abstract g(Lbn/d;)Z
.end method

.method public abstract h(I)V
.end method

.method public abstract mute()V
.end method

.method public abstract pause()V
.end method

.method public abstract play()V
.end method

.method public abstract unMute()V
.end method
