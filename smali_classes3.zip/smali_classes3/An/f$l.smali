.class final Lan/f$l;
.super Ljava/lang/Object;
.source "YouTubePlayerBridge.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lan/f;->sendYouTubeIFrameAPIReady()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field final synthetic a:Lan/f;


# direct methods
.method constructor <init>(Lan/f;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lan/f$l;->a:Lan/f;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lan/f$l;->a:Lan/f;

    invoke-static {v0}, Lan/f;->a(Lan/f;)Lan/f$a;

    move-result-object v0

    invoke-interface {v0}, Lan/f$a;->c()V

    return-void
.end method
