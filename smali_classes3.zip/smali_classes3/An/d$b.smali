.class public final LAn/d$b;
.super Lcom/squareup/sqldelight/f$a;
.source "AndroidSqliteDriver.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAn/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "b"
.end annotation


# instance fields
.field private final h:Lcom/squareup/sqldelight/f$a;

.field final synthetic i:LAn/d;


# direct methods
.method public constructor <init>(LAn/d;Lcom/squareup/sqldelight/f$a;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/squareup/sqldelight/f$a;",
            ")V"
        }
    .end annotation

    const-string v0, "this$0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LAn/d$b;->i:LAn/d;

    invoke-direct {p0}, Lcom/squareup/sqldelight/f$a;-><init>()V

    iput-object p2, p0, LAn/d$b;->h:Lcom/squareup/sqldelight/f$a;

    return-void
.end method


# virtual methods
.method protected final a(Z)V
    .registers 4

    iget-object v0, p0, LAn/d$b;->h:Lcom/squareup/sqldelight/f$a;

    iget-object v1, p0, LAn/d$b;->i:LAn/d;

    if-nez v0, :cond_1e

    if-eqz p1, :cond_17

    invoke-static {v1}, LAn/d;->c(LAn/d;)Lh1/b;

    move-result-object p1

    invoke-interface {p1}, Lh1/b;->V()V

    invoke-static {v1}, LAn/d;->c(LAn/d;)Lh1/b;

    move-result-object p1

    invoke-interface {p1}, Lh1/b;->i0()V

    goto :goto_1e

    :cond_17
    invoke-static {v1}, LAn/d;->c(LAn/d;)Lh1/b;

    move-result-object p1

    invoke-interface {p1}, Lh1/b;->i0()V

    :cond_1e
    :goto_1e
    invoke-static {v1}, LAn/d;->f(LAn/d;)Ljava/lang/ThreadLocal;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    return-void
.end method

.method protected final d()Lcom/squareup/sqldelight/f$a;
    .registers 2

    iget-object v0, p0, LAn/d$b;->h:Lcom/squareup/sqldelight/f$a;

    return-object v0
.end method
