.class final Lan/f$g;
.super Ljava/lang/Object;
.source "YouTubePlayerBridge.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lan/f;->sendStateChange(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field final synthetic a:Lan/f;

.field final synthetic b:Lan/d;


# direct methods
.method constructor <init>(Lan/f;Lan/d;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lan/f$g;->a:Lan/f;

    iput-object p2, p0, Lan/f$g;->b:Lan/d;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget-object v0, p0, Lan/f$g;->a:Lan/f;

    invoke-static {v0}, Lan/f;->a(Lan/f;)Lan/f$a;

    move-result-object v1

    invoke-interface {v1}, Lan/f$a;->i()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_28

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lbn/d;

    invoke-static {v0}, Lan/f;->a(Lan/f;)Lan/f$a;

    move-result-object v3

    invoke-interface {v3}, Lan/f$a;->a()Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/WebViewYouTubePlayer;

    move-result-object v3

    iget-object v4, p0, Lan/f$g;->b:Lan/d;

    invoke-interface {v2, v3, v4}, Lbn/d;->onStateChange(Lan/e;Lan/d;)V

    goto :goto_e

    :cond_28
    return-void
.end method
