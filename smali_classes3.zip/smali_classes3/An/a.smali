.class public final enum Lan/a;
.super Ljava/lang/Enum;
.source "PlayerConstants.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lan/a;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lan/a;

.field public static final enum DEFAULT:Lan/a;

.field public static final enum HD1080:Lan/a;

.field public static final enum HD720:Lan/a;

.field public static final enum HIGH_RES:Lan/a;

.field public static final enum LARGE:Lan/a;

.field public static final enum MEDIUM:Lan/a;

.field public static final enum SMALL:Lan/a;

.field public static final enum UNKNOWN:Lan/a;


# direct methods
.method static constructor <clinit>()V
    .registers 16

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v8, Lan/a;

    const-string v9, "UNKNOWN"

    invoke-direct {v8, v9, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lan/a;->UNKNOWN:Lan/a;

    new-instance v9, Lan/a;

    const-string v10, "SMALL"

    invoke-direct {v9, v10, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lan/a;->SMALL:Lan/a;

    new-instance v10, Lan/a;

    const-string v11, "MEDIUM"

    invoke-direct {v10, v11, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Lan/a;->MEDIUM:Lan/a;

    new-instance v11, Lan/a;

    const-string v12, "LARGE"

    invoke-direct {v11, v12, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Lan/a;->LARGE:Lan/a;

    new-instance v12, Lan/a;

    const-string v13, "HD720"

    invoke-direct {v12, v13, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v12, Lan/a;->HD720:Lan/a;

    new-instance v13, Lan/a;

    const-string v14, "HD1080"

    invoke-direct {v13, v14, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v13, Lan/a;->HD1080:Lan/a;

    new-instance v14, Lan/a;

    const-string v15, "HIGH_RES"

    invoke-direct {v14, v15, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v14, Lan/a;->HIGH_RES:Lan/a;

    new-instance v15, Lan/a;

    const-string v1, "DEFAULT"

    invoke-direct {v15, v1, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v15, Lan/a;->DEFAULT:Lan/a;

    const/16 v1, 0x8

    new-array v1, v1, [Lan/a;

    aput-object v8, v1, v7

    aput-object v9, v1, v6

    aput-object v10, v1, v5

    aput-object v11, v1, v4

    aput-object v12, v1, v3

    aput-object v13, v1, v2

    const/4 v2, 0x6

    aput-object v14, v1, v2

    aput-object v15, v1, v0

    sput-object v1, Lan/a;->$VALUES:[Lan/a;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lan/a;
    .registers 2

    const-class v0, Lan/a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lan/a;

    return-object p0
.end method

.method public static values()[Lan/a;
    .registers 1

    sget-object v0, Lan/a;->$VALUES:[Lan/a;

    invoke-virtual {v0}, [Lan/a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lan/a;

    return-object v0
.end method
