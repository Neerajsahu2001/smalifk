.class final LAn/d$d;
.super Lkotlin/jvm/internal/p;
.source "AndroidSqliteDriver.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAn/d;->e1(Ljava/lang/Integer;Ljava/lang/String;ILeo/l;)LBn/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LAn/g;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:LAn/d;


# direct methods
.method constructor <init>(Ljava/lang/String;LAn/d;I)V
    .registers 4

    iput-object p1, p0, LAn/d$d;->a:Ljava/lang/String;

    iput-object p2, p0, LAn/d$d;->b:LAn/d;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    new-instance v0, LAn/c;

    iget-object v1, p0, LAn/d$d;->b:LAn/d;

    invoke-static {v1}, LAn/d;->c(LAn/d;)Lh1/b;

    move-result-object v1

    iget-object v2, p0, LAn/d$d;->a:Ljava/lang/String;

    invoke-direct {v0, v2, v1}, LAn/c;-><init>(Ljava/lang/String;Lh1/b;)V

    return-object v0
.end method
