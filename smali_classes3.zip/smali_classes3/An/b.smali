.class public final enum Lan/b;
.super Ljava/lang/Enum;
.source "PlayerConstants.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lan/b;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lan/b;

.field public static final enum RATE_0_25:Lan/b;

.field public static final enum RATE_0_5:Lan/b;

.field public static final enum RATE_1:Lan/b;

.field public static final enum RATE_1_5:Lan/b;

.field public static final enum RATE_2:Lan/b;

.field public static final enum UNKNOWN:Lan/b;


# direct methods
.method static constructor <clinit>()V
    .registers 13

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v6, Lan/b;

    const-string v7, "UNKNOWN"

    invoke-direct {v6, v7, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lan/b;->UNKNOWN:Lan/b;

    new-instance v7, Lan/b;

    const-string v8, "RATE_0_25"

    invoke-direct {v7, v8, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lan/b;->RATE_0_25:Lan/b;

    new-instance v8, Lan/b;

    const-string v9, "RATE_0_5"

    invoke-direct {v8, v9, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lan/b;->RATE_0_5:Lan/b;

    new-instance v9, Lan/b;

    const-string v10, "RATE_1"

    invoke-direct {v9, v10, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lan/b;->RATE_1:Lan/b;

    new-instance v10, Lan/b;

    const-string v11, "RATE_1_5"

    invoke-direct {v10, v11, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Lan/b;->RATE_1_5:Lan/b;

    new-instance v11, Lan/b;

    const-string v12, "RATE_2"

    invoke-direct {v11, v12, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Lan/b;->RATE_2:Lan/b;

    const/4 v12, 0x6

    new-array v12, v12, [Lan/b;

    aput-object v6, v12, v5

    aput-object v7, v12, v4

    aput-object v8, v12, v3

    aput-object v9, v12, v2

    aput-object v10, v12, v1

    aput-object v11, v12, v0

    sput-object v12, Lan/b;->$VALUES:[Lan/b;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lan/b;
    .registers 2

    const-class v0, Lan/b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lan/b;

    return-object p0
.end method

.method public static values()[Lan/b;
    .registers 1

    sget-object v0, Lan/b;->$VALUES:[Lan/b;

    invoke-virtual {v0}, [Lan/b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lan/b;

    return-object v0
.end method
