.class public final LAn/d$a;
.super Lh1/c$a;
.source "AndroidSqliteDriver.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAn/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final b:LBn/c$a;

.field private final c:[LBn/a;


# direct methods
.method public constructor <init>(LBn/c$a;)V
    .registers 4

    const-string v0, "schema"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    new-array v1, v0, [LBn/a;

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LBn/a;

    const-string v1, "callbacks"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, LBn/c$a;->getVersion()I

    move-result v1

    invoke-direct {p0, v1}, Lh1/c$a;-><init>(I)V

    iput-object p1, p0, LAn/d$a;->b:LBn/c$a;

    iput-object v0, p0, LAn/d$a;->c:[LBn/a;

    return-void
.end method


# virtual methods
.method public final onCreate(Lh1/b;)V
    .registers 4

    const-string v0, "db"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LAn/d;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, LAn/d;-><init>(Lh1/b;I)V

    iget-object p1, p0, LAn/d$a;->b:LBn/c$a;

    invoke-interface {p1, v0}, LBn/c$a;->create(LBn/c;)V

    return-void
.end method

.method public final onUpgrade(Lh1/b;II)V
    .registers 11

    const-string v0, "db"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LAn/d$a;->c:[LBn/a;

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_e

    const/4 v1, 0x1

    goto :goto_f

    :cond_e
    const/4 v1, 0x0

    :goto_f
    xor-int/2addr v1, v3

    iget-object v4, p0, LAn/d$a;->b:LBn/c$a;

    if-eqz v1, :cond_6a

    new-instance v1, LAn/d;

    invoke-direct {v1, p1, v2}, LAn/d;-><init>(Lh1/b;I)V

    array-length p1, v0

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [LBn/a;

    const-string v0, "<this>"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "callbacks"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    array-length v5, p1

    :goto_30
    if-ge v2, v5, :cond_41

    aget-object v6, p1, v2

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-gtz p2, :cond_3e

    if-lez p3, :cond_3e

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3e
    add-int/lit8 v2, v2, 0x1

    goto :goto_30

    :cond_41
    new-instance p1, LBn/d;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    invoke-static {v0, p1}, Lkotlin/collections/q;->S(Ljava/util/AbstractCollection;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_5c

    if-ge p2, p3, :cond_72

    invoke-interface {v4, v1, p2, p3}, LBn/c$a;->migrate(LBn/c;II)V

    goto :goto_72

    :cond_5c
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LBn/a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v4, v1, p2, v3}, LBn/c$a;->migrate(LBn/c;II)V

    const/4 p1, 0x0

    throw p1

    :cond_6a
    new-instance v0, LAn/d;

    invoke-direct {v0, p1, v2}, LAn/d;-><init>(Lh1/b;I)V

    invoke-interface {v4, v0, p2, p3}, LBn/c$a;->migrate(LBn/c;II)V

    :cond_72
    :goto_72
    return-void
.end method
