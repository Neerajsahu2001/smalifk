.class final LAn/d$c;
.super Lkotlin/jvm/internal/p;
.source "AndroidSqliteDriver.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAn/d;-><init>(Lh1/c;Lh1/b;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Lh1/b;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LAn/d;

.field final synthetic b:Lh1/b;


# direct methods
.method constructor <init>(LAn/d;Lh1/b;)V
    .registers 3

    iput-object p1, p0, LAn/d$c;->a:LAn/d;

    iput-object p2, p0, LAn/d$c;->b:Lh1/b;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LAn/d$c;->a:LAn/d;

    invoke-static {v0}, LAn/d;->e(LAn/d;)Lh1/c;

    move-result-object v0

    if-nez v0, :cond_a

    const/4 v0, 0x0

    goto :goto_e

    :cond_a
    invoke-interface {v0}, Lh1/c;->getWritableDatabase()Lh1/b;

    move-result-object v0

    :goto_e
    if-nez v0, :cond_15

    iget-object v0, p0, LAn/d$c;->b:Lh1/b;

    invoke-static {v0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    :cond_15
    return-object v0
.end method
