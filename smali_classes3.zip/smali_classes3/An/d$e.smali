.class final synthetic LAn/d$e;
.super Lkotlin/jvm/internal/m;
.source "AndroidSqliteDriver.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAn/d;->e1(Ljava/lang/Integer;Ljava/lang/String;ILeo/l;)LBn/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/m;",
        "Leo/l<",
        "LAn/g;",
        "LBn/b;",
        ">;"
    }
.end annotation


# static fields
.field public static final j:LAn/d$e;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LAn/d$e;

    invoke-direct {v0}, LAn/d$e;-><init>()V

    sput-object v0, LAn/d$e;->j:LAn/d$e;

    return-void
.end method

.method constructor <init>()V
    .registers 7

    const-string v4, "executeQuery()Lcom/squareup/sqldelight/db/SqlCursor;"

    const/4 v5, 0x0

    const/4 v1, 0x1

    const-class v2, LAn/g;

    const-string v3, "executeQuery"

    move-object v0, p0

    invoke-direct/range {v0 .. v5}, Lkotlin/jvm/internal/m;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LAn/g;

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, LAn/g;->a()LBn/b;

    move-result-object p1

    return-object p1
.end method
