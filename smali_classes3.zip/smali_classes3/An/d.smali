.class public final enum Lan/d;
.super Ljava/lang/Enum;
.source "PlayerConstants.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lan/d;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lan/d;

.field public static final enum BUFFERING:Lan/d;

.field public static final enum ENDED:Lan/d;

.field public static final enum PAUSED:Lan/d;

.field public static final enum PLAYING:Lan/d;

.field public static final enum UNKNOWN:Lan/d;

.field public static final enum UNSTARTED:Lan/d;

.field public static final enum VIDEO_CUED:Lan/d;


# direct methods
.method static constructor <clinit>()V
    .registers 15

    const/4 v0, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v7, Lan/d;

    const-string v8, "UNKNOWN"

    invoke-direct {v7, v8, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lan/d;->UNKNOWN:Lan/d;

    new-instance v8, Lan/d;

    const-string v9, "UNSTARTED"

    invoke-direct {v8, v9, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lan/d;->UNSTARTED:Lan/d;

    new-instance v9, Lan/d;

    const-string v10, "ENDED"

    invoke-direct {v9, v10, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lan/d;->ENDED:Lan/d;

    new-instance v10, Lan/d;

    const-string v11, "PLAYING"

    invoke-direct {v10, v11, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Lan/d;->PLAYING:Lan/d;

    new-instance v11, Lan/d;

    const-string v12, "PAUSED"

    invoke-direct {v11, v12, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Lan/d;->PAUSED:Lan/d;

    new-instance v12, Lan/d;

    const-string v13, "BUFFERING"

    invoke-direct {v12, v13, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v12, Lan/d;->BUFFERING:Lan/d;

    new-instance v13, Lan/d;

    const-string v14, "VIDEO_CUED"

    invoke-direct {v13, v14, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v13, Lan/d;->VIDEO_CUED:Lan/d;

    const/4 v14, 0x7

    new-array v14, v14, [Lan/d;

    aput-object v7, v14, v6

    aput-object v8, v14, v5

    aput-object v9, v14, v4

    aput-object v10, v14, v3

    aput-object v11, v14, v2

    aput-object v12, v14, v1

    aput-object v13, v14, v0

    sput-object v14, Lan/d;->$VALUES:[Lan/d;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lan/d;
    .registers 2

    const-class v0, Lan/d;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lan/d;

    return-object p0
.end method

.method public static values()[Lan/d;
    .registers 1

    sget-object v0, Lan/d;->$VALUES:[Lan/d;

    invoke-virtual {v0}, [Lan/d;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lan/d;

    return-object v0
.end method
