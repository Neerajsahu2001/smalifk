.class final LAn/c$a;
.super Lkotlin/jvm/internal/p;
.source "AndroidSqliteDriver.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAn/c;->v(ILjava/lang/Long;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Lh1/d;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Long;

.field final synthetic b:I


# direct methods
.method constructor <init>(ILjava/lang/Long;)V
    .registers 3

    iput-object p2, p0, LAn/c$a;->a:Ljava/lang/Long;

    iput p1, p0, LAn/c$a;->b:I

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lh1/d;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget v0, p0, LAn/c$a;->b:I

    iget-object v1, p0, LAn/c$a;->a:Ljava/lang/Long;

    if-nez v1, :cond_11

    invoke-interface {p1, v0}, Lh1/d;->a1(I)V

    goto :goto_18

    :cond_11
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-interface {p1, v0, v1, v2}, Lh1/d;->L0(IJ)V

    :goto_18
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
