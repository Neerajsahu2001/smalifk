.class final LAn/c$b;
.super Lkotlin/jvm/internal/p;
.source "AndroidSqliteDriver.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAn/c;->u(ILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Lh1/d;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:I


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .registers 3

    iput-object p1, p0, LAn/c$b;->a:Ljava/lang/String;

    iput p2, p0, LAn/c$b;->b:I

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lh1/d;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget v0, p0, LAn/c$b;->b:I

    iget-object v1, p0, LAn/c$b;->a:Ljava/lang/String;

    if-nez v1, :cond_11

    invoke-interface {p1, v0}, Lh1/d;->a1(I)V

    goto :goto_14

    :cond_11
    invoke-interface {p1, v0, v1}, Lh1/d;->u(ILjava/lang/String;)V

    :goto_14
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
