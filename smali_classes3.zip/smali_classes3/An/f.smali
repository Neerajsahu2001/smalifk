.class public final Lan/f;
.super Ljava/lang/Object;
.source "YouTubePlayerBridge.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lan/f$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/os/Handler;

.field private final b:Lan/f$a;


# direct methods
.method public constructor <init>(Lan/f$a;)V
    .registers 3

    const-string v0, "youTubePlayerOwner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lan/f;->b:Lan/f$a;

    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lan/f;->a:Landroid/os/Handler;

    return-void
.end method

.method public static final synthetic a(Lan/f;)Lan/f$a;
    .registers 1

    iget-object p0, p0, Lan/f;->b:Lan/f$a;

    return-object p0
.end method


# virtual methods
.method public final sendApiChange()V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$b;

    invoke-direct {v1, p0}, Lan/f$b;-><init>(Lan/f;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final sendError(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "error"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "2"

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_11

    sget-object p1, Lan/c;->INVALID_PARAMETER_IN_REQUEST:Lan/c;

    goto :goto_3f

    :cond_11
    const-string v0, "5"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1c

    sget-object p1, Lan/c;->HTML_5_PLAYER:Lan/c;

    goto :goto_3f

    :cond_1c
    const-string v0, "100"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_27

    sget-object p1, Lan/c;->VIDEO_NOT_FOUND:Lan/c;

    goto :goto_3f

    :cond_27
    const-string v0, "101"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_32

    sget-object p1, Lan/c;->VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER:Lan/c;

    goto :goto_3f

    :cond_32
    const-string v0, "150"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_3d

    sget-object p1, Lan/c;->VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER:Lan/c;

    goto :goto_3f

    :cond_3d
    sget-object p1, Lan/c;->UNKNOWN:Lan/c;

    :goto_3f
    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$c;

    invoke-direct {v1, p0, p1}, Lan/f$c;-><init>(Lan/f;Lan/c;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final sendPlaybackQualityChange(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "quality"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "small"

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_11

    sget-object p1, Lan/a;->SMALL:Lan/a;

    goto :goto_55

    :cond_11
    const-string v0, "medium"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1c

    sget-object p1, Lan/a;->MEDIUM:Lan/a;

    goto :goto_55

    :cond_1c
    const-string v0, "large"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_27

    sget-object p1, Lan/a;->LARGE:Lan/a;

    goto :goto_55

    :cond_27
    const-string v0, "hd720"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_32

    sget-object p1, Lan/a;->HD720:Lan/a;

    goto :goto_55

    :cond_32
    const-string v0, "hd1080"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_3d

    sget-object p1, Lan/a;->HD1080:Lan/a;

    goto :goto_55

    :cond_3d
    const-string v0, "highres"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_48

    sget-object p1, Lan/a;->HIGH_RES:Lan/a;

    goto :goto_55

    :cond_48
    const-string v0, "default"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_53

    sget-object p1, Lan/a;->DEFAULT:Lan/a;

    goto :goto_55

    :cond_53
    sget-object p1, Lan/a;->UNKNOWN:Lan/a;

    :goto_55
    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$d;

    invoke-direct {v1, p0, p1}, Lan/f$d;-><init>(Lan/f;Lan/a;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final sendPlaybackRateChange(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "rate"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "0.25"

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_11

    sget-object p1, Lan/b;->RATE_0_25:Lan/b;

    goto :goto_3f

    :cond_11
    const-string v0, "0.5"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1c

    sget-object p1, Lan/b;->RATE_0_5:Lan/b;

    goto :goto_3f

    :cond_1c
    const-string v0, "1"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_27

    sget-object p1, Lan/b;->RATE_1:Lan/b;

    goto :goto_3f

    :cond_27
    const-string v0, "1.5"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_32

    sget-object p1, Lan/b;->RATE_1_5:Lan/b;

    goto :goto_3f

    :cond_32
    const-string v0, "2"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_3d

    sget-object p1, Lan/b;->RATE_2:Lan/b;

    goto :goto_3f

    :cond_3d
    sget-object p1, Lan/b;->UNKNOWN:Lan/b;

    :goto_3f
    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$e;

    invoke-direct {v1, p0, p1}, Lan/f$e;-><init>(Lan/f;Lan/b;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final sendReady()V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$f;

    invoke-direct {v1, p0}, Lan/f$f;-><init>(Lan/f;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final sendStateChange(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "state"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "UNSTARTED"

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_11

    sget-object p1, Lan/d;->UNSTARTED:Lan/d;

    goto :goto_4a

    :cond_11
    const-string v0, "ENDED"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1c

    sget-object p1, Lan/d;->ENDED:Lan/d;

    goto :goto_4a

    :cond_1c
    const-string v0, "PLAYING"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_27

    sget-object p1, Lan/d;->PLAYING:Lan/d;

    goto :goto_4a

    :cond_27
    const-string v0, "PAUSED"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_32

    sget-object p1, Lan/d;->PAUSED:Lan/d;

    goto :goto_4a

    :cond_32
    const-string v0, "BUFFERING"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_3d

    sget-object p1, Lan/d;->BUFFERING:Lan/d;

    goto :goto_4a

    :cond_3d
    const-string v0, "CUED"

    invoke-static {p1, v0, v1}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_48

    sget-object p1, Lan/d;->VIDEO_CUED:Lan/d;

    goto :goto_4a

    :cond_48
    sget-object p1, Lan/d;->UNKNOWN:Lan/d;

    :goto_4a
    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$g;

    invoke-direct {v1, p0, p1}, Lan/f$g;-><init>(Lan/f;Lan/d;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final sendVideoCurrentTime(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "seconds"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_5
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1
    :try_end_9
    .catch Ljava/lang/NumberFormatException; {:try_start_5 .. :try_end_9} :catch_14

    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$h;

    invoke-direct {v1, p0, p1}, Lan/f$h;-><init>(Lan/f;F)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :catch_14
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final sendVideoDuration(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "seconds"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_5
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_10

    const-string p1, "0"

    goto :goto_10

    :catch_e
    move-exception p1

    goto :goto_1f

    :cond_10
    :goto_10
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1
    :try_end_14
    .catch Ljava/lang/NumberFormatException; {:try_start_5 .. :try_end_14} :catch_e

    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$i;

    invoke-direct {v1, p0, p1}, Lan/f$i;-><init>(Lan/f;F)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :goto_1f
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final sendVideoId(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "videoId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$j;

    invoke-direct {v1, p0, p1}, Lan/f$j;-><init>(Lan/f;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final sendVideoLoadedFraction(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "fraction"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_5
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1
    :try_end_9
    .catch Ljava/lang/NumberFormatException; {:try_start_5 .. :try_end_9} :catch_14

    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$k;

    invoke-direct {v1, p0, p1}, Lan/f$k;-><init>(Lan/f;F)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :catch_14
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final sendYouTubeIFrameAPIReady()Z
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    iget-object v0, p0, Lan/f;->a:Landroid/os/Handler;

    new-instance v1, Lan/f$l;

    invoke-direct {v1, p0}, Lan/f$l;-><init>(Lan/f;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v0

    return v0
.end method
