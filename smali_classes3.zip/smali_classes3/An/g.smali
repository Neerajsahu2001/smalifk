.class public interface abstract LAn/g;
.super Ljava/lang/Object;
.source "AndroidSqliteDriver.kt"

# interfaces
.implements LBn/e;


# virtual methods
.method public abstract a()LBn/b;
.end method

.method public abstract close()V
.end method

.method public abstract execute()V
.end method
