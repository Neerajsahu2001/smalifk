.class public final enum Lan/c;
.super Ljava/lang/Enum;
.source "PlayerConstants.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lan/c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lan/c;

.field public static final enum HTML_5_PLAYER:Lan/c;

.field public static final enum INVALID_PARAMETER_IN_REQUEST:Lan/c;

.field public static final enum UNKNOWN:Lan/c;

.field public static final enum VIDEO_NOT_FOUND:Lan/c;

.field public static final enum VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER:Lan/c;


# direct methods
.method static constructor <clinit>()V
    .registers 11

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v5, Lan/c;

    const-string v6, "UNKNOWN"

    invoke-direct {v5, v6, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lan/c;->UNKNOWN:Lan/c;

    new-instance v6, Lan/c;

    const-string v7, "INVALID_PARAMETER_IN_REQUEST"

    invoke-direct {v6, v7, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lan/c;->INVALID_PARAMETER_IN_REQUEST:Lan/c;

    new-instance v7, Lan/c;

    const-string v8, "HTML_5_PLAYER"

    invoke-direct {v7, v8, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lan/c;->HTML_5_PLAYER:Lan/c;

    new-instance v8, Lan/c;

    const-string v9, "VIDEO_NOT_FOUND"

    invoke-direct {v8, v9, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lan/c;->VIDEO_NOT_FOUND:Lan/c;

    new-instance v9, Lan/c;

    const-string v10, "VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER"

    invoke-direct {v9, v10, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lan/c;->VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER:Lan/c;

    const/4 v10, 0x5

    new-array v10, v10, [Lan/c;

    aput-object v5, v10, v4

    aput-object v6, v10, v3

    aput-object v7, v10, v2

    aput-object v8, v10, v1

    aput-object v9, v10, v0

    sput-object v10, Lan/c;->$VALUES:[Lan/c;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lan/c;
    .registers 2

    const-class v0, Lan/c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lan/c;

    return-object p0
.end method

.method public static values()[Lan/c;
    .registers 1

    sget-object v0, Lan/c;->$VALUES:[Lan/c;

    invoke-virtual {v0}, [Lan/c;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lan/c;

    return-object v0
.end method
