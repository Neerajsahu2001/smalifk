.class public interface abstract Lcp/a;
.super Ljava/lang/Object;
.source "SamConversionResolver.kt"
