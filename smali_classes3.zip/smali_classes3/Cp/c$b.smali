.class public final LCp/c$b;
.super Ljava/lang/Object;

# interfaces
.implements LZp/j$a;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LCp/c;->c(Ljava/lang/String;LZp/p;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Lorg/json/JSONObject;

.field public final synthetic c:LZp/p;

.field public final synthetic d:LCp/c;


# direct methods
.method public constructor <init>(LCp/c;Ljava/lang/String;Lorg/json/JSONObject;LZp/p;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LCp/c$b;->d:LCp/c;

    iput-object p2, p0, LCp/c$b;->a:Ljava/lang/String;

    iput-object p3, p0, LCp/c$b;->b:Lorg/json/JSONObject;

    iput-object p4, p0, LCp/c$b;->c:LZp/p;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/Map;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, LCp/c$b;->d:LCp/c;

    iget-object v0, v0, LCp/c;->c:LZp/l;

    iget-object v1, p0, LCp/c$b;->b:Lorg/json/JSONObject;

    instance-of v2, v1, Lorg/json/JSONObject;

    if-nez v2, :cond_f

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_13

    :cond_f
    invoke-static {v1}, Lcom/newrelic/agent/android/instrumentation/JSONObjectInstrumentation;->toString(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v1

    :goto_13
    iget-object v2, p0, LCp/c$b;->c:LZp/p;

    iget-object v3, p0, LCp/c$b;->a:Ljava/lang/String;

    invoke-interface {v0, v3, p1, v1, v2}, LZp/l;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;LZp/p;)V

    return-void
.end method
