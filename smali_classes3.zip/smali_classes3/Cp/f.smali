.class public final LCp/f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCp/f$a;,
        LCp/f$b;
    }
.end annotation


# static fields
.field public static a:LCp/f$b;


# direct methods
.method public static a(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    sget-object v0, LCp/f;->a:LCp/f$b;

    if-eqz v0, :cond_e

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, LCp/f$a;->e(I)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e
    return-void
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    sget-object v0, LCp/f;->a:LCp/f$b;

    if-eqz v0, :cond_e

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, LCp/f$a;->e(I)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e
    return-void
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    sget-object v0, LCp/f;->a:LCp/f$b;

    if-eqz v0, :cond_e

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, LCp/f$a;->e(I)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e
    return-void
.end method

.method public static d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 5

    sget-object v0, LCp/f;->a:LCp/f$b;

    if-eqz v0, :cond_e

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, LCp/f$a;->e(I)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_e
    return-void
.end method

.method public static e(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    sget-object v0, LCp/f;->a:LCp/f$b;

    if-eqz v0, :cond_e

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, LCp/f$a;->e(I)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e
    return-void
.end method
