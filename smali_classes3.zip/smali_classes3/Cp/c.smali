.class public final LCp/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljmjou/d;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCp/c$a;
    }
.end annotation


# instance fields
.field public a:Ljmjou/jmjou;

.field public b:LZp/j;

.field public c:LZp/l;

.field public d:LCp/c$a;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lrmqfk/qwsnv;)V
    .registers 7

    iget-object v0, p0, LCp/c;->a:Ljmjou/jmjou;

    const-class v1, Lbq/c;

    invoke-virtual {v0, v1}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object v0

    check-cast v0, Lbq/c;

    iget-object v0, v0, Lbq/c;->a:LTn/a;

    invoke-virtual {v0}, Ljmjou/b;->b()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "event_batching_event_ingestion_enabled"

    const/4 v3, 0x1

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_33

    iget-object v0, p0, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {v0, v1}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object v0

    check-cast v0, Lbq/c;

    iget-object v0, v0, Lbq/c;->a:LTn/a;

    invoke-virtual {v0}, Ljmjou/b;->b()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v4, "event_batching_enabled"

    invoke-interface {v0, v4, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_33

    invoke-virtual {p0, p1}, LCp/c;->d(Lrmqfk/qwsnv;)V

    goto :goto_6a

    :cond_33
    iget-object v0, p0, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {v0, v1}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object v0

    check-cast v0, Lbq/c;

    iget-object v0, v0, Lbq/c;->a:LTn/a;

    invoke-virtual {v0}, Ljmjou/b;->b()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_6a

    iget-object v0, p0, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    invoke-virtual {p1}, Lrmqfk/rmqfk;->toJsonObject()Lorg/json/JSONObject;

    move-result-object p1

    invoke-virtual {v0, p1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result p1

    if-eqz p1, :cond_6a

    invoke-static {v0}, Lcom/newrelic/agent/android/instrumentation/JSONArrayInstrumentation;->toString(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object p1

    new-instance v0, LCp/b;

    invoke-direct {v0, p0, p1}, LCp/b;-><init>(LCp/c;Ljava/lang/String;)V

    invoke-virtual {p0, p1, v0}, LCp/c;->c(Ljava/lang/String;LZp/p;)V

    :cond_6a
    :goto_6a
    return-void
.end method

.method public final b(Ljava/lang/String;)Lrmqfk/qwsnv;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "preparing event with name : {"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "AnalyticsManager"

    invoke-static {v1, v0}, LCp/f;->e(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, LCp/c;->a:Ljmjou/jmjou;

    const-class v1, Lrmqfk/qwsnv;

    invoke-virtual {v0, v1}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object v0

    check-cast v0, Lrmqfk/qwsnv;

    const-string v1, "eventName"

    invoke-virtual {v0, v1, p1}, Lbq/b;->put(Ljava/lang/String;Ljava/lang/Object;)V

    return-object v0
.end method

.method public final c(Ljava/lang/String;LZp/p;)V
    .registers 10

    const-string v0, "AnalyticsManager"

    const-string v1, "/apis/v2/sdk/event"

    const-string v2, "transactionId"

    iget-object v3, p0, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    :try_start_10
    iget-object v4, p0, LCp/c;->a:Ljmjou/jmjou;

    const-class v5, Lrmqfk/wlgrx;

    invoke-virtual {v4, v5}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object v4

    check-cast v4, Lrmqfk/wlgrx;

    invoke-virtual {v4}, Lrmqfk/rmqfk;->getObjectFactory()Ljmjou/jmjou;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljmjou/jmjou;->cqqlq(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    const-string v5, "events"

    invoke-virtual {v4, v5, p1}, Lbq/b;->put(Ljava/lang/String;Ljava/lang/Object;)V

    iget-object p1, p0, LCp/c;->a:Ljmjou/jmjou;

    const-class v5, Lrmqfk/lupsq;

    invoke-virtual {p1, v5}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object p1

    check-cast p1, Lrmqfk/lupsq;

    invoke-virtual {p1}, Lrmqfk/rmqfk;->toJsonObject()Lorg/json/JSONObject;

    move-result-object p1

    const-string v5, "sdkContext"

    invoke-virtual {v4, v5, p1}, Lbq/b;->put(Ljava/lang/String;Ljava/lang/Object;)V

    iget-object p1, p0, LCp/c;->a:Ljmjou/jmjou;

    const-string v5, "com.phonepe.android.sdk.MerchantId"

    invoke-virtual {p1, v5}, Ljmjou/jmjou;->irjuc(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const-string v5, "merchantId"

    invoke-virtual {v4, v5, p1}, Lbq/b;->put(Ljava/lang/String;Ljava/lang/Object;)V

    iget-object p1, p0, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {p1, v2}, Ljmjou/jmjou;->irjuc(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {v4, v2, p1}, Lbq/b;->put(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v4}, Lbq/b;->toJsonString()Ljava/lang/String;

    move-result-object p1

    const-string v2, "\n"

    const-string v5, ""

    invoke-virtual {p1, v2, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    const-string v2, "UTF-8"

    invoke-virtual {p1, v2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v2, 0x2

    invoke-static {p1, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    iget-object v2, p0, LCp/c;->a:Ljmjou/jmjou;

    invoke-static {v2, v1, p1}, LCp/e;->e(Ljmjou/jmjou;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    const-string v6, "request"

    invoke-virtual {v5, v6, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v4}, Lbq/b;->toJsonString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, LCp/f;->c(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "X-SDK-CHECKSUM"

    invoke-virtual {v3, p1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, LCp/c;->a:Ljmjou/jmjou;

    const-string v2, "com.phonepe.android.sdk.isUAT"

    invoke-virtual {p1, v2}, Ljmjou/jmjou;->irjuc(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-static {p1}, LCp/e;->h(Ljava/lang/Boolean;)Z

    move-result p1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, LZp/q;->a(Z)LZp/q$a;

    move-result-object p1

    iget-object p1, p1, LZp/q$a;->irjuc:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, LCp/c;->b:LZp/j;

    new-instance v2, LCp/c$b;

    invoke-direct {v2, p0, p1, v5, p2}, LCp/c$b;-><init>(LCp/c;Ljava/lang/String;Lorg/json/JSONObject;LZp/p;)V

    invoke-virtual {v1, v3, v2}, LZp/j;->b(Ljava/util/Map;LZp/j$a;)V
    :try_end_b3
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_b3} :catch_b4

    goto :goto_bc

    :catch_b4
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-static {v0, p2, p1}, LCp/f;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    :goto_bc
    return-void
.end method

.method public final d(Lrmqfk/qwsnv;)V
    .registers 7

    if-eqz p1, :cond_5a

    iget-object v0, p0, LCp/c;->d:LCp/c$a;

    invoke-virtual {p1}, Lbq/b;->toJsonString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0}, Ljmjou/b;->b()Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v2, 0x0

    const-string v3, "1bca992e"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "AnalyticsManager"

    if-eqz v1, :cond_46

    const-string v4, "events for previous sessions are available in db"

    invoke-static {v2, v4}, LCp/f;->a(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "@%#"

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v4, "event json string = {"

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "} ."

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LCp/f;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_46
    const-string v1, "saving events in local db ..."

    invoke-static {v2, v1}, LCp/f;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljmjou/b;->b()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v3, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_5a
    return-void
.end method

.method public final init(Ljmjou/jmjou;Ljmjou/jmjou$a;)V
    .registers 4

    iput-object p1, p0, LCp/c;->a:Ljmjou/jmjou;

    const-class p2, LCp/c$a;

    invoke-virtual {p1, p2}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object p2

    check-cast p2, LCp/c$a;

    iput-object p2, p0, LCp/c;->d:LCp/c$a;

    iget-object p2, p0, LCp/c;->a:Ljmjou/jmjou;

    const-class v0, LZp/j;

    invoke-virtual {p2, v0}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object p2

    check-cast p2, LZp/j;

    iput-object p2, p0, LCp/c;->b:LZp/j;

    invoke-static {p1}, Lj3/o;->s(Ljmjou/jmjou;)LZp/l;

    move-result-object p1

    iput-object p1, p0, LCp/c;->c:LZp/l;

    return-void
.end method

.method public final isCachingAllowed()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method
