.class public final LCp/j$a;
.super Lkotlin/jvm/internal/p;

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LCp/j;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Landroid/content/Context;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:LCp/j;


# direct methods
.method public constructor <init>(LCp/j;)V
    .registers 2

    iput-object p1, p0, LCp/j$a;->a:LCp/j;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LCp/j$a;->a:LCp/j;

    iget-object v0, v0, LCp/j;->a:Ljmjou/jmjou;

    if-nez v0, :cond_8

    const/4 v0, 0x0

    goto :goto_a

    :cond_8
    sget-object v0, Ljmjou/jmjou;->irjuc:Landroid/content/Context;

    :goto_a
    return-object v0
.end method
