.class public final LCp/j;
.super Ljava/lang/Object;

# interfaces
.implements Ljmjou/d;


# instance fields
.field public a:Ljmjou/jmjou;

.field public final b:LUn/e;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LCp/j$a;

    invoke-direct {v0, p0}, LCp/j$a;-><init>(LCp/j;)V

    invoke-static {v0}, LUn/f;->b(Leo/a;)LUn/e;

    move-result-object v0

    iput-object v0, p0, LCp/j;->b:LUn/e;

    return-void
.end method


# virtual methods
.method public final init(Ljmjou/jmjou;Ljmjou/jmjou$a;)V
    .registers 3

    iput-object p1, p0, LCp/j;->a:Ljmjou/jmjou;

    return-void
.end method

.method public final isCachingAllowed()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method
