.class public final enum LCp/a$a;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCp/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LCp/a$a;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic chmha:[LCp/a$a;

.field public static final enum cqqlq:LCp/a$a;

.field public static final enum irjuc:LCp/a$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance v2, LCp/a$a;

    const-string v3, "HIGH"

    invoke-direct {v2, v3, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, LCp/a$a;->irjuc:LCp/a$a;

    new-instance v3, LCp/a$a;

    const-string v4, "LOW"

    invoke-direct {v3, v4, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LCp/a$a;->cqqlq:LCp/a$a;

    const/4 v4, 0x2

    new-array v4, v4, [LCp/a$a;

    aput-object v2, v4, v1

    aput-object v3, v4, v0

    sput-object v4, LCp/a$a;->chmha:[LCp/a$a;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)LCp/a$a;
    .registers 2

    const-class v0, LCp/a$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LCp/a$a;

    return-object p0
.end method

.method public static values()[LCp/a$a;
    .registers 1

    sget-object v0, LCp/a$a;->chmha:[LCp/a$a;

    invoke-virtual {v0}, [LCp/a$a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LCp/a$a;

    return-object v0
.end method
