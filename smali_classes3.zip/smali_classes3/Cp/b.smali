.class public final LCp/b;
.super Ljava/lang/Object;

# interfaces
.implements LZp/p;


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:LCp/c;


# direct methods
.method public constructor <init>(LCp/c;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LCp/b;->b:LCp/c;

    iput-object p2, p0, LCp/b;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/String;)V
    .registers 5

    iget-object p1, p0, LCp/b;->b:LCp/c;

    iget-object p1, p1, LCp/c;->a:Ljmjou/jmjou;

    iget-object v0, p0, LCp/b;->a:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljmjou/jmjou;->cqqlq(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    aput-object p1, v1, v2

    const/4 p1, 0x1

    aput-object v0, v1, p1

    const-string p1, "events!!! ingestion succeeded. count = {%d}, payload = {%s}"

    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "AnalyticsManager"

    invoke-static {v0, p1}, LCp/f;->e(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public final g(ILjava/lang/String;)V
    .registers 7

    iget-object v0, p0, LCp/b;->b:LCp/c;

    iget-object v0, v0, LCp/c;->a:Ljmjou/jmjou;

    iget-object v1, p0, LCp/b;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljmjou/jmjou;->cqqlq(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v0, 0x1

    aput-object p1, v2, v0

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object v1, v2, p1

    const-string p1, "Failed to inject events!!!, count = {%d},responseCode = {%d}, response = {%s} for payload = {%s}"

    invoke-static {p1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "AnalyticsManager"

    invoke-static {p2, p1}, LCp/f;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
