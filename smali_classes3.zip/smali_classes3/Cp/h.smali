.class public final LCp/h;
.super Ljava/lang/Object;

# interfaces
.implements LZp/p;


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:LCp/c;


# direct methods
.method public constructor <init>(LCp/c;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LCp/h;->b:LCp/c;

    iput-object p2, p0, LCp/h;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/String;)V
    .registers 5

    iget-object p1, p0, LCp/h;->b:LCp/c;

    iget-object p1, p1, LCp/c;->a:Ljmjou/jmjou;

    iget-object v0, p0, LCp/h;->a:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljmjou/jmjou;->cqqlq(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    aput-object p1, v1, v2

    const/4 p1, 0x1

    aput-object v0, v1, p1

    const-string p1, "events!!! ingestion succeeded. count = {%d}, payload = {%s}"

    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "AnalyticsManager"

    invoke-static {v0, p1}, LCp/f;->e(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public final g(ILjava/lang/String;)V
    .registers 8

    iget-object v0, p0, LCp/h;->b:LCp/c;

    iget-object v1, v0, LCp/c;->a:Ljmjou/jmjou;

    iget-object v2, p0, LCp/h;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljmjou/jmjou;->cqqlq(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v1, v3, v4

    const/4 v1, 0x1

    aput-object p1, v3, v1

    const/4 p1, 0x2

    aput-object p2, v3, p1

    const/4 p1, 0x3

    aput-object v2, v3, p1

    const-string p1, "Failed to inject events!!!, count = {%d},responseCode = {%d}, response = {%s} for payload = {%s}"

    invoke-static {p1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "AnalyticsManager"

    invoke-static {p2, p1}, LCp/f;->b(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, v0, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {p1, v2}, Ljmjou/jmjou;->cqqlq(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    :goto_36
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result p2

    if-ge v4, p2, :cond_4f

    :try_start_3c
    iget-object p2, v0, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {p1, v4}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {p2, v2}, Lrmqfk/qwsnv;->irjuc(Ljmjou/jmjou;Ljava/lang/String;)Lrmqfk/qwsnv;

    move-result-object p2

    invoke-virtual {v0, p2}, LCp/c;->d(Lrmqfk/qwsnv;)V
    :try_end_4d
    .catch Lorg/json/JSONException; {:try_start_3c .. :try_end_4d} :catch_4d

    :catch_4d
    add-int/2addr v4, v1

    goto :goto_36

    :cond_4f
    return-void
.end method
