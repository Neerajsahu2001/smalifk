.class public final LCp/o;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# instance fields
.field public final synthetic a:J

.field public final synthetic b:Ljava/lang/Long;

.field public final synthetic c:Ljava/lang/Long;

.field public final synthetic d:Landroid/os/Handler;

.field public final synthetic e:Ljava/lang/Long;


# direct methods
.method public constructor <init>(JLjava/lang/Long;Ljava/lang/Long;Landroid/os/Handler;Ljava/lang/Long;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LCp/o;->a:J

    iput-object p3, p0, LCp/o;->b:Ljava/lang/Long;

    iput-object p4, p0, LCp/o;->c:Ljava/lang/Long;

    iput-object p5, p0, LCp/o;->d:Landroid/os/Handler;

    iput-object p6, p0, LCp/o;->e:Ljava/lang/Long;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 16

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object v2, p0, LCp/o;->b:Ljava/lang/Long;

    const-string v3, "timeoutMs"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    iget-object v4, p0, LCp/o;->c:Ljava/lang/Long;

    const-string v5, "batchSize"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v4

    iget-object v6, p0, LCp/o;->e:Ljava/lang/Long;

    const-string v7, "delayMs"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    move-result-wide v6

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    iget-wide v10, p0, LCp/o;->a:J

    sub-long/2addr v8, v10

    const-string v10, "events"

    iget-object v11, p0, LCp/o;->d:Landroid/os/Handler;

    cmp-long v12, v8, v2

    if-gtz v12, :cond_e1

    invoke-static {}, Lcom/phonepe/intent/sdk/api/PhonePe;->getObjectFactory()Ljmjou/jmjou;

    move-result-object v2

    const-class v3, LCp/c;

    invoke-virtual {v2, v3}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object v2

    check-cast v2, LCp/c;

    iget-object v3, v2, LCp/c;->d:LCp/c$a;

    invoke-virtual {v3}, Ljmjou/b;->b()Landroid/content/SharedPreferences;

    move-result-object v3

    const-string v8, "1bca992e"

    const/4 v9, 0x0

    invoke-interface {v3, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_56

    const-string v0, "AnalyticsManager"

    const-string v1, "event database is empty"

    invoke-static {v0, v1}, LCp/f;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_dd

    :cond_56
    iget-object v8, v2, LCp/c;->d:LCp/c$a;

    invoke-virtual {v8}, Ljmjou/b;->b()Landroid/content/SharedPreferences;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const-string v8, "@%#"

    invoke-virtual {v3, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v8, v3

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    new-array v9, v1, [Ljava/lang/Object;

    aput-object v8, v9, v0

    const-string v8, "persisted {%d} events in previous sessions are fetched"

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v10, v8}, LCp/f;->c(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v8, v2, LCp/c;->a:Ljmjou/jmjou;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v8, Lorg/json/JSONArray;

    invoke-direct {v8}, Lorg/json/JSONArray;-><init>()V

    array-length v9, v3

    int-to-long v9, v9

    cmp-long v12, v9, v4

    if-ltz v12, :cond_b2

    array-length v9, v3

    :goto_90
    if-ge v0, v9, :cond_cb

    aget-object v10, v3, v0

    iget-object v12, v2, LCp/c;->a:Ljmjou/jmjou;

    invoke-static {v12, v10}, Lrmqfk/qwsnv;->irjuc(Ljmjou/jmjou;Ljava/lang/String;)Lrmqfk/qwsnv;

    move-result-object v10

    if-eqz v10, :cond_ad

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v12

    int-to-long v12, v12

    cmp-long v14, v12, v4

    if-gez v14, :cond_ad

    invoke-virtual {v10}, Lrmqfk/rmqfk;->toJsonObject()Lorg/json/JSONObject;

    move-result-object v10

    invoke-virtual {v8, v10}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_b0

    :cond_ad
    invoke-virtual {v2, v10}, LCp/c;->d(Lrmqfk/qwsnv;)V

    :goto_b0
    add-int/2addr v0, v1

    goto :goto_90

    :cond_b2
    array-length v4, v3

    if-lez v4, :cond_cb

    array-length v4, v3

    :goto_b6
    if-ge v0, v4, :cond_cb

    aget-object v5, v3, v0

    iget-object v9, v2, LCp/c;->a:Ljmjou/jmjou;

    invoke-static {v9, v5}, Lrmqfk/qwsnv;->irjuc(Ljmjou/jmjou;Ljava/lang/String;)Lrmqfk/qwsnv;

    move-result-object v5

    if-eqz v5, :cond_c9

    invoke-virtual {v5}, Lrmqfk/rmqfk;->toJsonObject()Lorg/json/JSONObject;

    move-result-object v5

    invoke-virtual {v8, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    :cond_c9
    add-int/2addr v0, v1

    goto :goto_b6

    :cond_cb
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-lez v0, :cond_dd

    invoke-static {v8}, Lcom/newrelic/agent/android/instrumentation/JSONArrayInstrumentation;->toString(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, LCp/h;

    invoke-direct {v1, v2, v0}, LCp/h;-><init>(LCp/c;Ljava/lang/String;)V

    invoke-virtual {v2, v0, v1}, LCp/c;->c(Ljava/lang/String;LZp/p;)V

    :cond_dd
    :goto_dd
    invoke-virtual {v11, p0, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_e9

    :cond_e1
    const-string v0, "timedout"

    invoke-static {v10, v0}, LCp/f;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v11, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :goto_e9
    return-void
.end method
