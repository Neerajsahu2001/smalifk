.class public final LCp/c$a;
.super Ljmjou/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCp/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljmjou/b;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    const-string v0, "1bca992e-c98b-4ab7-a789-737ec20fd436"

    return-object v0
.end method
