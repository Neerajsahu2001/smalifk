.class public final LCp/f$b;
.super LCp/f$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCp/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation
