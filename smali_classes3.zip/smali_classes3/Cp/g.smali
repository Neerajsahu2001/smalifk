.class public final LCp/g;
.super LCp/n;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LCp/n;-><init>()V

    return-void
.end method
