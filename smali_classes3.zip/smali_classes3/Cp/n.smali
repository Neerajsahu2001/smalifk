.class public LCp/n;
.super Ljava/lang/Object;

# interfaces
.implements Ljmjou/d;


# instance fields
.field public a:Landroid/content/Context;

.field public b:LCp/l;

.field public c:Ljmjou/jmjou;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Landroid/content/Context;
    .registers 2

    iget-object v0, p0, LCp/n;->a:Landroid/content/Context;

    if-nez v0, :cond_d

    iget-object v0, p0, LCp/n;->c:Ljmjou/jmjou;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljmjou/jmjou;->irjuc:Landroid/content/Context;

    iput-object v0, p0, LCp/n;->a:Landroid/content/Context;

    :cond_d
    iget-object v0, p0, LCp/n;->a:Landroid/content/Context;

    return-object v0
.end method

.method public final b()Ljava/lang/String;
    .registers 4

    :try_start_0
    invoke-virtual {p0}, LCp/n;->a()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, LCp/n;->a()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x80

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    if-eqz v0, :cond_2a

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    if-eqz v0, :cond_2a

    const-string v1, "com.phonepe.android.sdk.AppId"

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_22
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_22} :catch_23

    goto :goto_2c

    :catch_23
    const-string v0, "getAppId"

    const-string v1, "Failed to get appId"

    invoke-static {v0, v1}, LCp/f;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2a
    const-string v0, ""

    :goto_2c
    return-object v0
.end method

.method public final init(Ljmjou/jmjou;Ljmjou/jmjou$a;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Ljmjou/jmjou;->irjuc:Landroid/content/Context;

    iput-object p2, p0, LCp/n;->a:Landroid/content/Context;

    const-class p2, LCp/l;

    invoke-virtual {p1, p2}, Ljmjou/jmjou;->irjuc(Ljava/lang/Class;)Ljmjou/d;

    move-result-object p2

    check-cast p2, LCp/l;

    iput-object p2, p0, LCp/n;->b:LCp/l;

    iput-object p1, p0, LCp/n;->c:Ljmjou/jmjou;

    return-void
.end method

.method public final isCachingAllowed()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method
