.class public final LFk/a;
.super LFk/b;
.source "com.google.mlkit:common@@17.5.0"
