.class public LFo/f;
.super Lxo/L;
.source "JavaPropertyDescriptor.java"

# interfaces
.implements LFo/a;


# instance fields
.field private final C:Z

.field private final D:LUn/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUn/j<",
            "Luo/a$a<",
            "*>;*>;"
        }
    .end annotation
.end field


# direct methods
.method protected constructor <init>(Luo/k;Lvo/h;Luo/A;Luo/r;ZLTo/f;Luo/S;Luo/L;Luo/b$a;ZLUn/j;)V
    .registers 29
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Luo/k;",
            "Lvo/h;",
            "Luo/A;",
            "Luo/r;",
            "Z",
            "LTo/f;",
            "Luo/S;",
            "Luo/L;",
            "Luo/b$a;",
            "Z",
            "LUn/j<",
            "Luo/a$a<",
            "*>;*>;)V"
        }
    .end annotation

    move-object/from16 v15, p0

    const/4 v0, 0x0

    if-eqz p1, :cond_60

    if-eqz p2, :cond_5a

    if-eqz p3, :cond_54

    if-eqz p4, :cond_4e

    if-eqz p6, :cond_48

    if-eqz p7, :cond_42

    if-eqz p9, :cond_3c

    const/4 v14, 0x0

    const/16 v16, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p8

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p9

    move-object/from16 v9, p7

    move/from16 v15, v16

    invoke-direct/range {v0 .. v15}, Lxo/L;-><init>(Luo/k;Luo/L;Lvo/h;Luo/A;Luo/r;ZLTo/f;Luo/b$a;Luo/S;ZZZZZZ)V

    move-object/from16 v1, p0

    move/from16 v0, p10

    iput-boolean v0, v1, LFo/f;->C:Z

    move-object/from16 v0, p11

    iput-object v0, v1, LFo/f;->D:LUn/j;

    return-void

    :cond_3c
    move-object v1, v15

    const/4 v2, 0x6

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v0

    :cond_42
    move-object v1, v15

    const/4 v2, 0x5

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v0

    :cond_48
    move-object v1, v15

    const/4 v2, 0x4

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v0

    :cond_4e
    move-object v1, v15

    const/4 v2, 0x3

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v0

    :cond_54
    move-object v1, v15

    const/4 v2, 0x2

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v0

    :cond_5a
    move-object v1, v15

    const/4 v2, 0x1

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v0

    :cond_60
    move-object v1, v15

    const/4 v2, 0x0

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v0
.end method

.method public static X0(Luo/k;LGo/e;Luo/A;Luo/r;ZLTo/f;LJo/a;Z)LFo/f;
    .registers 21

    const/4 v0, 0x0

    if-eqz p0, :cond_33

    if-eqz p2, :cond_2d

    if-eqz p5, :cond_27

    if-eqz p6, :cond_21

    new-instance v0, LFo/f;

    sget-object v10, Luo/b$a;->DECLARATION:Luo/b$a;

    const/4 v12, 0x0

    const/4 v9, 0x0

    move-object v1, v0

    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    move-object/from16 v5, p3

    move/from16 v6, p4

    move-object/from16 v7, p5

    move-object/from16 v8, p6

    move/from16 v11, p7

    invoke-direct/range {v1 .. v12}, LFo/f;-><init>(Luo/k;Lvo/h;Luo/A;Luo/r;ZLTo/f;Luo/S;Luo/L;Luo/b$a;ZLUn/j;)V

    return-object v0

    :cond_21
    const/16 v1, 0xc

    invoke-static {v1}, LFo/f;->i0(I)V

    throw v0

    :cond_27
    const/16 v1, 0xb

    invoke-static {v1}, LFo/f;->i0(I)V

    throw v0

    :cond_2d
    const/16 v1, 0x9

    invoke-static {v1}, LFo/f;->i0(I)V

    throw v0

    :cond_33
    const/4 v1, 0x7

    invoke-static {v1}, LFo/f;->i0(I)V

    throw v0
.end method

.method private static synthetic i0(I)V
    .registers 8

    const/16 v0, 0x15

    if-eq p0, v0, :cond_7

    const-string v1, "Argument for @NotNull parameter \'%s\' of %s.%s must not be null"

    goto :goto_9

    :cond_7
    const-string v1, "@NotNull method %s.%s must not return null"

    :goto_9
    const/4 v2, 0x2

    if-eq p0, v0, :cond_e

    const/4 v3, 0x3

    goto :goto_f

    :cond_e
    const/4 v3, 0x2

    :goto_f
    new-array v3, v3, [Ljava/lang/Object;

    const-string v4, "kotlin/reflect/jvm/internal/impl/load/java/descriptors/JavaPropertyDescriptor"

    const/4 v5, 0x0

    packed-switch p0, :pswitch_data_94

    :pswitch_17
    const-string v6, "containingDeclaration"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_1c
    const-string v6, "inType"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_21
    aput-object v4, v3, v5

    goto :goto_5f

    :pswitch_24
    const-string v6, "enhancedReturnType"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_29
    const-string v6, "enhancedValueParameterTypes"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_2e
    const-string v6, "newName"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_33
    const-string v6, "newVisibility"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_38
    const-string v6, "newModality"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_3d
    const-string v6, "newOwner"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_42
    const-string v6, "kind"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_47
    const-string v6, "source"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_4c
    const-string v6, "name"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_51
    const-string v6, "visibility"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_56
    const-string v6, "modality"

    aput-object v6, v3, v5

    goto :goto_5f

    :pswitch_5b
    const-string v6, "annotations"

    aput-object v6, v3, v5

    :goto_5f
    const-string v5, "enhance"

    const/4 v6, 0x1

    if-eq p0, v0, :cond_67

    aput-object v4, v3, v6

    goto :goto_69

    :cond_67
    aput-object v5, v3, v6

    :goto_69
    packed-switch p0, :pswitch_data_c4

    const-string v4, "<init>"

    aput-object v4, v3, v2

    goto :goto_82

    :pswitch_71
    const-string v4, "setInType"

    aput-object v4, v3, v2

    goto :goto_82

    :pswitch_76
    aput-object v5, v3, v2

    goto :goto_82

    :pswitch_79
    const-string v4, "createSubstitutedCopy"

    aput-object v4, v3, v2

    goto :goto_82

    :pswitch_7e
    const-string v4, "create"

    aput-object v4, v3, v2

    :goto_82
    :pswitch_82
    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    if-eq p0, v0, :cond_8e

    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    goto :goto_93

    :cond_8e
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    :goto_93
    throw p0

    :pswitch_data_94
    .packed-switch 0x1
        :pswitch_5b
        :pswitch_56
        :pswitch_51
        :pswitch_4c
        :pswitch_47
        :pswitch_42
        :pswitch_17
        :pswitch_5b
        :pswitch_56
        :pswitch_51
        :pswitch_4c
        :pswitch_47
        :pswitch_3d
        :pswitch_38
        :pswitch_33
        :pswitch_42
        :pswitch_2e
        :pswitch_47
        :pswitch_29
        :pswitch_24
        :pswitch_21
        :pswitch_1c
    .end packed-switch

    :pswitch_data_c4
    .packed-switch 0x7
        :pswitch_7e
        :pswitch_7e
        :pswitch_7e
        :pswitch_7e
        :pswitch_7e
        :pswitch_7e
        :pswitch_79
        :pswitch_79
        :pswitch_79
        :pswitch_79
        :pswitch_79
        :pswitch_79
        :pswitch_76
        :pswitch_76
        :pswitch_82
        :pswitch_71
    .end packed-switch
.end method


# virtual methods
.method public final E0(Luo/a$a;)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(",
            "Luo/a$a<",
            "TV;>;)TV;"
        }
    .end annotation

    sget-object p1, LFo/e;->H:Luo/a$a;

    iget-object v0, p0, LFo/f;->D:LUn/j;

    if-eqz v0, :cond_17

    invoke-virtual {v0}, LUn/j;->c()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Luo/a$a;

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_17

    invoke-virtual {v0}, LUn/j;->d()Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_17
    const/4 p1, 0x0

    return-object p1
.end method

.method protected final O0(Luo/k;Luo/A;Luo/r;Luo/L;Luo/b$a;LTo/f;)Lxo/L;
    .registers 21

    move-object v0, p0

    sget-object v8, Luo/S;->a:Luo/S;

    const/4 v1, 0x0

    if-eqz p1, :cond_44

    if-eqz p2, :cond_3e

    if-eqz p3, :cond_38

    if-eqz p5, :cond_32

    if-eqz p6, :cond_2c

    new-instance v13, LFo/f;

    invoke-virtual {p0}, Lvo/b;->getAnnotations()Lvo/h;

    move-result-object v3

    invoke-virtual {p0}, Lxo/Y;->N()Z

    move-result v6

    iget-boolean v11, v0, LFo/f;->C:Z

    iget-object v12, v0, LFo/f;->D:LUn/j;

    move-object v1, v13

    move-object v2, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    move-object/from16 v7, p6

    move-object/from16 v9, p4

    move-object/from16 v10, p5

    invoke-direct/range {v1 .. v12}, LFo/f;-><init>(Luo/k;Lvo/h;Luo/A;Luo/r;ZLTo/f;Luo/S;Luo/L;Luo/b$a;ZLUn/j;)V

    return-object v13

    :cond_2c
    const/16 v2, 0x11

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v1

    :cond_32
    const/16 v2, 0x10

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v1

    :cond_38
    const/16 v2, 0xf

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v1

    :cond_3e
    const/16 v2, 0xe

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v1

    :cond_44
    const/16 v2, 0xd

    invoke-static {v2}, LFo/f;->i0(I)V

    throw v1
.end method

.method public final T0(Lkp/E;)V
    .registers 2

    return-void
.end method

.method public final a0(Lkp/E;Ljava/util/ArrayList;Lkp/E;LUn/j;)LFo/a;
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p0 .. p0}, Lxo/L;->a()Luo/L;

    move-result-object v2

    if-ne v2, v0, :cond_c

    const/4 v2, 0x0

    goto :goto_10

    :cond_c
    invoke-virtual/range {p0 .. p0}, Lxo/L;->a()Luo/L;

    move-result-object v2

    :goto_10
    new-instance v15, LFo/f;

    invoke-virtual/range {p0 .. p0}, Lxo/p;->d()Luo/k;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lvo/b;->getAnnotations()Lvo/h;

    move-result-object v6

    invoke-virtual/range {p0 .. p0}, Lxo/L;->s()Luo/A;

    move-result-object v7

    invoke-virtual/range {p0 .. p0}, Lxo/L;->getVisibility()Luo/r;

    move-result-object v8

    invoke-virtual/range {p0 .. p0}, Lxo/Y;->N()Z

    move-result v9

    invoke-virtual/range {p0 .. p0}, Lxo/o;->getName()LTo/f;

    move-result-object v10

    invoke-virtual/range {p0 .. p0}, Lxo/p;->f()Luo/S;

    move-result-object v11

    invoke-virtual/range {p0 .. p0}, Lxo/L;->h()Luo/b$a;

    move-result-object v13

    iget-boolean v14, v0, LFo/f;->C:Z

    move-object v4, v15

    move-object v12, v2

    move-object/from16 p2, v15

    move-object/from16 v15, p4

    invoke-direct/range {v4 .. v15}, LFo/f;-><init>(Luo/k;Lvo/h;Luo/A;Luo/r;ZLTo/f;Luo/S;Luo/L;Luo/b$a;ZLUn/j;)V

    invoke-virtual/range {p0 .. p0}, Lxo/L;->Q0()Lxo/M;

    move-result-object v15

    if-eqz v15, :cond_84

    new-instance v14, Lxo/M;

    invoke-virtual {v15}, Lvo/b;->getAnnotations()Lvo/h;

    move-result-object v6

    invoke-virtual {v15}, Lxo/K;->s()Luo/A;

    move-result-object v7

    invoke-virtual {v15}, Lxo/K;->getVisibility()Luo/r;

    move-result-object v8

    invoke-virtual {v15}, Lxo/K;->G()Z

    move-result v9

    invoke-virtual {v15}, Lxo/K;->isExternal()Z

    move-result v10

    invoke-virtual {v15}, Lxo/K;->isInline()Z

    move-result v11

    invoke-virtual/range {p0 .. p0}, Lxo/L;->h()Luo/b$a;

    move-result-object v12

    if-nez v2, :cond_65

    const/4 v13, 0x0

    goto :goto_6a

    :cond_65
    invoke-interface {v2}, Luo/L;->l()Lxo/M;

    move-result-object v4

    move-object v13, v4

    :goto_6a
    invoke-virtual {v15}, Lxo/p;->f()Luo/S;

    move-result-object v16

    move-object v4, v14

    move-object/from16 v5, p2

    move-object v3, v14

    move-object/from16 v14, v16

    invoke-direct/range {v4 .. v14}, Lxo/M;-><init>(Luo/L;Lvo/h;Luo/A;Luo/r;ZZZLuo/b$a;Luo/M;Luo/S;)V

    invoke-virtual {v15}, Lxo/K;->t0()Luo/v;

    move-result-object v4

    invoke-virtual {v3, v4}, Lxo/K;->N0(Luo/v;)V

    move-object/from16 v15, p3

    invoke-virtual {v3, v15}, Lxo/M;->Q0(Lkp/E;)V

    goto :goto_87

    :cond_84
    move-object/from16 v15, p3

    const/4 v3, 0x0

    :goto_87
    invoke-virtual/range {p0 .. p0}, Lxo/L;->g()Luo/N;

    move-result-object v16

    if-eqz v16, :cond_da

    new-instance v14, Lxo/N;

    invoke-interface/range {v16 .. v16}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object v6

    invoke-interface/range {v16 .. v16}, Luo/z;->s()Luo/A;

    move-result-object v7

    invoke-interface/range {v16 .. v16}, Luo/z;->getVisibility()Luo/r;

    move-result-object v8

    invoke-interface/range {v16 .. v16}, Luo/K;->G()Z

    move-result v9

    invoke-interface/range {v16 .. v16}, Luo/z;->isExternal()Z

    move-result v10

    invoke-interface/range {v16 .. v16}, Luo/v;->isInline()Z

    move-result v11

    invoke-virtual/range {p0 .. p0}, Lxo/L;->h()Luo/b$a;

    move-result-object v12

    if-nez v2, :cond_af

    const/4 v13, 0x0

    goto :goto_b4

    :cond_af
    invoke-interface {v2}, Luo/L;->g()Luo/N;

    move-result-object v2

    move-object v13, v2

    :goto_b4
    invoke-interface/range {v16 .. v16}, Luo/n;->f()Luo/S;

    move-result-object v2

    move-object v4, v14

    move-object/from16 v5, p2

    move-object/from16 p4, v14

    move-object v14, v2

    invoke-direct/range {v4 .. v14}, Lxo/N;-><init>(Luo/L;Lvo/h;Luo/A;Luo/r;ZZZLuo/b$a;Luo/N;Luo/S;)V

    invoke-virtual/range {p4 .. p4}, Lxo/K;->t0()Luo/v;

    move-result-object v2

    move-object/from16 v4, p4

    invoke-virtual {v4, v2}, Lxo/K;->N0(Luo/v;)V

    invoke-interface/range {v16 .. v16}, Luo/a;->e()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x0

    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Luo/b0;

    invoke-virtual {v4, v2}, Lxo/N;->R0(Luo/b0;)V

    move-object v14, v4

    goto :goto_db

    :cond_da
    const/4 v14, 0x0

    :goto_db
    invoke-virtual/range {p0 .. p0}, Lxo/L;->w0()Luo/t;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Lxo/L;->P()Luo/t;

    move-result-object v4

    move-object/from16 v10, p2

    invoke-virtual {v10, v3, v14, v2, v4}, Lxo/L;->R0(Lxo/M;Lxo/N;Luo/t;Luo/t;)V

    invoke-virtual/range {p0 .. p0}, Lxo/L;->S0()Z

    move-result v2

    invoke-virtual {v10, v2}, Lxo/L;->U0(Z)V

    iget-object v2, v0, Lxo/Y;->h:Leo/a;

    if-eqz v2, :cond_f8

    iget-object v3, v0, Lxo/Y;->g:Ljp/k;

    invoke-virtual {v10, v3, v2}, Lxo/Y;->I0(Ljp/k;Leo/a;)V

    :cond_f8
    invoke-virtual/range {p0 .. p0}, Lxo/L;->o()Ljava/util/Collection;

    move-result-object v2

    invoke-virtual {v10, v2}, Lxo/L;->D0(Ljava/util/Collection;)V

    if-nez v1, :cond_103

    const/4 v8, 0x0

    goto :goto_10c

    :cond_103
    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v2

    invoke-static {v0, v1, v2}, LWo/h;->i(Luo/a;Lkp/E;Lvo/h;)Lxo/O;

    move-result-object v3

    move-object v8, v3

    :goto_10c
    invoke-virtual/range {p0 .. p0}, Lxo/L;->getTypeParameters()Ljava/util/List;

    move-result-object v6

    invoke-virtual/range {p0 .. p0}, Lxo/L;->L()Luo/O;

    move-result-object v7

    sget-object v9, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    move-object v4, v10

    move-object/from16 v5, p3

    invoke-virtual/range {v4 .. v9}, Lxo/L;->V0(Lkp/E;Ljava/util/List;Luo/O;Lxo/O;Ljava/util/List;)V

    return-object v10
.end method

.method public final c0()Z
    .registers 4

    invoke-virtual {p0}, Lxo/X;->getType()Lkp/E;

    move-result-object v0

    iget-boolean v1, p0, LFo/f;->C:Z

    if-eqz v1, :cond_3c

    const-string v1, "type"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lro/j;->i0(Lkp/E;)Z

    move-result v1

    if-nez v1, :cond_19

    invoke-static {v0}, Lro/r;->c(Lkp/E;)Z

    move-result v1

    if-eqz v1, :cond_1f

    :cond_19
    invoke-static {v0}, Lkp/t0;->h(Lkp/E;)Z

    move-result v1

    if-eqz v1, :cond_25

    :cond_1f
    invoke-static {v0}, Lro/j;->k0(Lkp/E;)Z

    move-result v1

    if-eqz v1, :cond_3c

    :cond_25
    sget v1, LLo/x;->c:I

    sget-object v1, LDo/E;->p:LTo/c;

    const-string v2, "ENHANCED_NULLABILITY_ANNOTATION"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0, v1}, Llp/b$a;->C(Lop/h;LTo/c;)Z

    move-result v1

    if-eqz v1, :cond_3a

    invoke-static {v0}, Lro/j;->k0(Lkp/E;)Z

    move-result v0

    if-eqz v0, :cond_3c

    :cond_3a
    const/4 v0, 0x1

    goto :goto_3d

    :cond_3c
    const/4 v0, 0x0

    :goto_3d
    return v0
.end method

.method public final h0()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
