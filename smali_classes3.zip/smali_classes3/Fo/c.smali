.class public interface abstract Lfo/c;
.super Ljava/lang/Object;
.source "KMarkers.kt"

# interfaces
.implements Lfo/a;
