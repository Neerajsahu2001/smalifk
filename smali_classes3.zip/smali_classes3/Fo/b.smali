.class public interface abstract Lfo/b;
.super Ljava/lang/Object;
.source "KMarkers.kt"

# interfaces
.implements Lfo/a;
