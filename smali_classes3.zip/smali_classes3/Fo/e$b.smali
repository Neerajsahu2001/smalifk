.class final LFo/e$b;
.super Ljava/lang/Object;
.source "JavaMethodDescriptor.java"

# interfaces
.implements Luo/a$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFo/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Luo/a$a<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation
