.class public final LFo/e;
.super Lxo/P;
.source "JavaMethodDescriptor.java"

# interfaces
.implements LFo/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LFo/e$c;
    }
.end annotation


# static fields
.field public static final G:Luo/a$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Luo/a$a<",
            "Luo/b0;",
            ">;"
        }
    .end annotation
.end field

.field public static final H:Luo/a$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Luo/a$a<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private E:LFo/e$c;

.field private final F:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LFo/e$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LFo/e;->G:Luo/a$a;

    new-instance v0, LFo/e$b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LFo/e;->H:Luo/a$a;

    return-void
.end method

.method protected constructor <init>(Luo/k;Luo/Q;Lvo/h;LTo/f;Luo/b$a;Luo/S;Z)V
    .registers 9

    const/4 v0, 0x0

    if-eqz p1, :cond_27

    if-eqz p3, :cond_22

    if-eqz p4, :cond_1d

    if-eqz p5, :cond_18

    if-eqz p6, :cond_13

    invoke-direct/range {p0 .. p6}, Lxo/P;-><init>(Luo/k;Luo/Q;Lvo/h;LTo/f;Luo/b$a;Luo/S;)V

    iput-object v0, p0, LFo/e;->E:LFo/e$c;

    iput-boolean p7, p0, LFo/e;->F:Z

    return-void

    :cond_13
    const/4 p1, 0x4

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_18
    const/4 p1, 0x3

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_1d
    const/4 p1, 0x2

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_22
    const/4 p1, 0x1

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_27
    const/4 p1, 0x0

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0
.end method

.method private static synthetic i0(I)V
    .registers 12

    const/16 v0, 0x15

    const/16 v1, 0x12

    const/16 v2, 0xd

    if-eq p0, v2, :cond_f

    if-eq p0, v1, :cond_f

    if-eq p0, v0, :cond_f

    const-string v3, "Argument for @NotNull parameter \'%s\' of %s.%s must not be null"

    goto :goto_11

    :cond_f
    const-string v3, "@NotNull method %s.%s must not return null"

    :goto_11
    const/4 v4, 0x2

    if-eq p0, v2, :cond_1a

    if-eq p0, v1, :cond_1a

    if-eq p0, v0, :cond_1a

    const/4 v5, 0x3

    goto :goto_1b

    :cond_1a
    const/4 v5, 0x2

    :goto_1b
    new-array v5, v5, [Ljava/lang/Object;

    const-string v6, "kotlin/reflect/jvm/internal/impl/load/java/descriptors/JavaMethodDescriptor"

    const/4 v7, 0x0

    packed-switch p0, :pswitch_data_a4

    :pswitch_23
    const-string v8, "containingDeclaration"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_28
    const-string v8, "enhancedReturnType"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_2d
    const-string v8, "enhancedValueParameterTypes"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_32
    const-string v8, "newOwner"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_37
    aput-object v6, v5, v7

    goto :goto_61

    :pswitch_3a
    const-string v8, "visibility"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_3f
    const-string v8, "unsubstitutedValueParameters"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_44
    const-string v8, "typeParameters"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_49
    const-string v8, "contextReceiverParameters"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_4e
    const-string v8, "source"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_53
    const-string v8, "kind"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_58
    const-string v8, "name"

    aput-object v8, v5, v7

    goto :goto_61

    :pswitch_5d
    const-string v8, "annotations"

    aput-object v8, v5, v7

    :goto_61
    const-string v7, "initialize"

    const-string v8, "createSubstitutedCopy"

    const-string v9, "enhance"

    const/4 v10, 0x1

    if-eq p0, v2, :cond_77

    if-eq p0, v1, :cond_74

    if-eq p0, v0, :cond_71

    aput-object v6, v5, v10

    goto :goto_79

    :cond_71
    aput-object v9, v5, v10

    goto :goto_79

    :cond_74
    aput-object v8, v5, v10

    goto :goto_79

    :cond_77
    aput-object v7, v5, v10

    :goto_79
    packed-switch p0, :pswitch_data_d2

    const-string v6, "<init>"

    aput-object v6, v5, v4

    goto :goto_8e

    :pswitch_81
    aput-object v9, v5, v4

    goto :goto_8e

    :pswitch_84
    aput-object v8, v5, v4

    goto :goto_8e

    :pswitch_87
    aput-object v7, v5, v4

    goto :goto_8e

    :pswitch_8a
    const-string v6, "createJavaMethod"

    aput-object v6, v5, v4

    :goto_8e
    :pswitch_8e
    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    if-eq p0, v2, :cond_9e

    if-eq p0, v1, :cond_9e

    if-eq p0, v0, :cond_9e

    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    goto :goto_a3

    :cond_9e
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    :goto_a3
    throw p0

    :pswitch_data_a4
    .packed-switch 0x1
        :pswitch_5d
        :pswitch_58
        :pswitch_53
        :pswitch_4e
        :pswitch_23
        :pswitch_5d
        :pswitch_58
        :pswitch_4e
        :pswitch_49
        :pswitch_44
        :pswitch_3f
        :pswitch_3a
        :pswitch_37
        :pswitch_32
        :pswitch_53
        :pswitch_5d
        :pswitch_4e
        :pswitch_37
        :pswitch_2d
        :pswitch_28
        :pswitch_37
    .end packed-switch

    :pswitch_data_d2
    .packed-switch 0x5
        :pswitch_8a
        :pswitch_8a
        :pswitch_8a
        :pswitch_8a
        :pswitch_87
        :pswitch_87
        :pswitch_87
        :pswitch_87
        :pswitch_8e
        :pswitch_84
        :pswitch_84
        :pswitch_84
        :pswitch_84
        :pswitch_8e
        :pswitch_81
        :pswitch_81
        :pswitch_8e
    .end packed-switch
.end method

.method public static l1(Luo/k;LGo/e;LTo/f;LJo/a;Z)LFo/e;
    .registers 14

    const/4 v0, 0x0

    if-eqz p0, :cond_21

    if-eqz p2, :cond_1c

    if-eqz p3, :cond_16

    new-instance v0, LFo/e;

    const/4 v3, 0x0

    sget-object v6, Luo/b$a;->DECLARATION:Luo/b$a;

    move-object v1, v0

    move-object v2, p0

    move-object v4, p1

    move-object v5, p2

    move-object v7, p3

    move v8, p4

    invoke-direct/range {v1 .. v8}, LFo/e;-><init>(Luo/k;Luo/Q;Lvo/h;LTo/f;Luo/b$a;Luo/S;Z)V

    return-object v0

    :cond_16
    const/16 p0, 0x8

    invoke-static {p0}, LFo/e;->i0(I)V

    throw v0

    :cond_1c
    const/4 p0, 0x7

    invoke-static {p0}, LFo/e;->i0(I)V

    throw v0

    :cond_21
    const/4 p0, 0x5

    invoke-static {p0}, LFo/e;->i0(I)V

    throw v0
.end method


# virtual methods
.method protected final M0(Luo/b$a;Luo/k;Luo/v;Luo/S;Lvo/h;LTo/f;)Lxo/w;
    .registers 16

    const/4 v0, 0x0

    if-eqz p2, :cond_35

    if-eqz p1, :cond_2f

    if-eqz p5, :cond_29

    new-instance v0, LFo/e;

    move-object v3, p3

    check-cast v3, Luo/Q;

    if-eqz p6, :cond_10

    :goto_e
    move-object v5, p6

    goto :goto_15

    :cond_10
    invoke-virtual {p0}, Lxo/o;->getName()LTo/f;

    move-result-object p6

    goto :goto_e

    :goto_15
    iget-boolean v8, p0, LFo/e;->F:Z

    move-object v1, v0

    move-object v2, p2

    move-object v4, p5

    move-object v6, p1

    move-object v7, p4

    invoke-direct/range {v1 .. v8}, LFo/e;-><init>(Luo/k;Luo/Q;Lvo/h;LTo/f;Luo/b$a;Luo/S;Z)V

    iget-object p1, p0, LFo/e;->E:LFo/e$c;

    iget-boolean p2, p1, LFo/e$c;->isStable:Z

    iget-boolean p1, p1, LFo/e$c;->isSynthesized:Z

    invoke-virtual {v0, p2, p1}, LFo/e;->m1(ZZ)V

    return-object v0

    :cond_29
    const/16 p1, 0x10

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_2f
    const/16 p1, 0xf

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_35
    const/16 p1, 0xe

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0
.end method

.method public final Q0()Z
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public final a0(Lkp/E;Ljava/util/ArrayList;Lkp/E;LUn/j;)LFo/a;
    .registers 7

    invoke-virtual {p0}, Lxo/w;->e()Ljava/util/List;

    move-result-object v0

    invoke-static {p2, v0, p0}, Landroidx/lifecycle/LifecycleOwnerKt;->b(Ljava/util/ArrayList;Ljava/util/Collection;Luo/a;)Ljava/util/ArrayList;

    move-result-object p2

    const/4 v0, 0x0

    if-nez p1, :cond_d

    move-object p1, v0

    goto :goto_15

    :cond_d
    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v1

    invoke-static {p0, p1, v1}, LWo/h;->i(Luo/a;Lkp/E;Lvo/h;)Lxo/O;

    move-result-object p1

    :goto_15
    invoke-virtual {p0}, Lxo/P;->H0()Luo/v$a;

    move-result-object v1

    check-cast v1, Lxo/w$a;

    invoke-virtual {v1, p2}, Lxo/w$a;->D(Ljava/util/List;)V

    invoke-virtual {v1, p3}, Lxo/w$a;->m(Lkp/E;)Luo/v$a;

    invoke-virtual {v1, p1}, Lxo/w$a;->A(Luo/O;)Luo/v$a;

    invoke-virtual {v1}, Lxo/w$a;->z()Luo/v$a;

    invoke-virtual {v1}, Lxo/w$a;->l()Luo/v$a;

    invoke-virtual {v1}, Lxo/w$a;->build()Luo/v;

    move-result-object p1

    check-cast p1, LFo/e;

    if-eqz p4, :cond_3f

    invoke-virtual {p4}, LUn/j;->c()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Luo/a$a;

    invoke-virtual {p4}, LUn/j;->d()Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lxo/w;->T0(Luo/a$a;Ljava/lang/Object;)V

    :cond_3f
    if-eqz p1, :cond_42

    return-object p1

    :cond_42
    const/16 p1, 0x15

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0
.end method

.method public final h0()Z
    .registers 2

    iget-object v0, p0, LFo/e;->E:LFo/e$c;

    iget-boolean v0, v0, LFo/e$c;->isSynthesized:Z

    return v0
.end method

.method public final k1(Lxo/O;Luo/O;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkp/E;Luo/A;Luo/r;Ljava/util/Map;)Lxo/P;
    .registers 11

    const/4 v0, 0x0

    if-eqz p3, :cond_4c

    if-eqz p4, :cond_46

    if-eqz p5, :cond_40

    if-eqz p8, :cond_3a

    invoke-super/range {p0 .. p9}, Lxo/P;->k1(Lxo/O;Luo/O;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkp/E;Luo/A;Luo/r;Ljava/util/Map;)Lxo/P;

    sget-object p1, Lrp/s;->a:Lrp/s;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lrp/s;->a()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_19
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_30

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lrp/k;

    invoke-virtual {p2, p0}, Lrp/k;->b(Luo/v;)Z

    move-result p3

    if-eqz p3, :cond_19

    invoke-virtual {p2, p0}, Lrp/k;->a(Luo/v;)Lrp/g;

    move-result-object p1

    goto :goto_32

    :cond_30
    sget-object p1, Lrp/g$a;->b:Lrp/g$a;

    :goto_32
    invoke-virtual {p1}, Lrp/g;->a()Z

    move-result p1

    invoke-virtual {p0, p1}, Lxo/w;->b1(Z)V

    return-object p0

    :cond_3a
    const/16 p1, 0xc

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_40
    const/16 p1, 0xb

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_46
    const/16 p1, 0xa

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0

    :cond_4c
    const/16 p1, 0x9

    invoke-static {p1}, LFo/e;->i0(I)V

    throw v0
.end method

.method public final m1(ZZ)V
    .registers 3

    if-eqz p1, :cond_a

    if-eqz p2, :cond_7

    sget-object p1, LFo/e$c;->STABLE_SYNTHESIZED:LFo/e$c;

    goto :goto_11

    :cond_7
    sget-object p1, LFo/e$c;->STABLE_DECLARED:LFo/e$c;

    goto :goto_11

    :cond_a
    if-eqz p2, :cond_f

    sget-object p1, LFo/e$c;->NON_STABLE_SYNTHESIZED:LFo/e$c;

    goto :goto_11

    :cond_f
    sget-object p1, LFo/e$c;->NON_STABLE_DECLARED:LFo/e$c;

    :goto_11
    if-eqz p1, :cond_16

    iput-object p1, p0, LFo/e;->E:LFo/e$c;

    return-void

    :cond_16
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "@NotNull method kotlin/reflect/jvm/internal/impl/load/java/descriptors/JavaMethodDescriptor$ParameterNamesStatus.get must not return null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
