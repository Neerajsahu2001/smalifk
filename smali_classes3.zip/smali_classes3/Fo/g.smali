.class public interface abstract LFo/g;
.super Ljava/lang/Object;
.source "PossiblyExternalAnnotationDescriptor.kt"

# interfaces
.implements Lvo/c;


# virtual methods
.method public abstract b()Z
.end method
