.class final enum LFo/e$c;
.super Ljava/lang/Enum;
.source "JavaMethodDescriptor.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFo/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LFo/e$c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LFo/e$c;

.field public static final enum NON_STABLE_DECLARED:LFo/e$c;

.field public static final enum NON_STABLE_SYNTHESIZED:LFo/e$c;

.field public static final enum STABLE_DECLARED:LFo/e$c;

.field public static final enum STABLE_SYNTHESIZED:LFo/e$c;


# instance fields
.field public final isStable:Z

.field public final isSynthesized:Z


# direct methods
.method static constructor <clinit>()V
    .registers 9

    new-instance v0, LFo/e$c;

    const-string v1, "NON_STABLE_DECLARED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2, v2}, LFo/e$c;-><init>(Ljava/lang/String;IZZ)V

    sput-object v0, LFo/e$c;->NON_STABLE_DECLARED:LFo/e$c;

    new-instance v1, LFo/e$c;

    const-string v3, "STABLE_DECLARED"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4, v2}, LFo/e$c;-><init>(Ljava/lang/String;IZZ)V

    sput-object v1, LFo/e$c;->STABLE_DECLARED:LFo/e$c;

    new-instance v3, LFo/e$c;

    const-string v5, "NON_STABLE_SYNTHESIZED"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v2, v4}, LFo/e$c;-><init>(Ljava/lang/String;IZZ)V

    sput-object v3, LFo/e$c;->NON_STABLE_SYNTHESIZED:LFo/e$c;

    new-instance v5, LFo/e$c;

    const-string v7, "STABLE_SYNTHESIZED"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v4, v4}, LFo/e$c;-><init>(Ljava/lang/String;IZZ)V

    sput-object v5, LFo/e$c;->STABLE_SYNTHESIZED:LFo/e$c;

    const/4 v7, 0x4

    new-array v7, v7, [LFo/e$c;

    aput-object v0, v7, v2

    aput-object v1, v7, v4

    aput-object v3, v7, v6

    aput-object v5, v7, v8

    sput-object v7, LFo/e$c;->$VALUES:[LFo/e$c;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IZZ)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-boolean p3, p0, LFo/e$c;->isStable:Z

    iput-boolean p4, p0, LFo/e$c;->isSynthesized:Z

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LFo/e$c;
    .registers 2

    const-class v0, LFo/e$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LFo/e$c;

    return-object p0
.end method

.method public static values()[LFo/e$c;
    .registers 1

    sget-object v0, LFo/e$c;->$VALUES:[LFo/e$c;

    invoke-virtual {v0}, [LFo/e$c;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LFo/e$c;

    return-object v0
.end method
