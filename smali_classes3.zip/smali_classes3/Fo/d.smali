.class public final LFo/d;
.super LFo/f;
.source "JavaForKotlinOverridePropertyDescriptor.kt"


# instance fields
.field private final E:Luo/Q;

.field private final F:Luo/Q;

.field private final G:Luo/L;


# direct methods
.method public constructor <init>(Luo/e;Luo/Q;Luo/Q;Luo/L;)V
    .registers 19

    move-object v12, p0

    move-object/from16 v13, p3

    const-string v0, "ownerDescriptor"

    move-object v1, p1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v2

    invoke-interface/range {p2 .. p2}, Luo/z;->s()Luo/A;

    move-result-object v3

    invoke-interface/range {p2 .. p2}, Luo/z;->getVisibility()Luo/r;

    move-result-object v4

    if-eqz v13, :cond_1a

    const/4 v0, 0x1

    const/4 v5, 0x1

    goto :goto_1c

    :cond_1a
    const/4 v0, 0x0

    const/4 v5, 0x0

    :goto_1c
    invoke-interface/range {p4 .. p4}, Luo/k;->getName()LTo/f;

    move-result-object v6

    invoke-interface/range {p2 .. p2}, Luo/n;->f()Luo/S;

    move-result-object v7

    sget-object v9, Luo/b$a;->DECLARATION:Luo/b$a;

    const/4 v11, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x0

    move-object v0, p0

    move-object v1, p1

    invoke-direct/range {v0 .. v11}, LFo/f;-><init>(Luo/k;Lvo/h;Luo/A;Luo/r;ZLTo/f;Luo/S;Luo/L;Luo/b$a;ZLUn/j;)V

    move-object/from16 v0, p2

    iput-object v0, v12, LFo/d;->E:Luo/Q;

    iput-object v13, v12, LFo/d;->F:Luo/Q;

    move-object/from16 v0, p4

    iput-object v0, v12, LFo/d;->G:Luo/L;

    return-void
.end method
