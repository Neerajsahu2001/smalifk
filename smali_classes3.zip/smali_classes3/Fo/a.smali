.class public interface abstract Lfo/a;
.super Ljava/lang/Object;
.source "KMarkers.kt"
