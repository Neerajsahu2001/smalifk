.class final Lgp/s;
.super Lkotlin/jvm/internal/p;
.source "DeserializedPackageFragmentImpl.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/b;",
        "Luo/S;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/t;


# direct methods
.method constructor <init>(Lgp/t;)V
    .registers 2

    iput-object p1, p0, Lgp/s;->a:Lgp/t;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LTo/b;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Lgp/s;->a:Lgp/t;

    invoke-static {p1}, Lgp/t;->L0(Lgp/t;)Lip/h;

    move-result-object p1

    if-eqz p1, :cond_10

    goto :goto_12

    :cond_10
    sget-object p1, Luo/S;->a:Luo/S;

    :goto_12
    return-object p1
.end method
