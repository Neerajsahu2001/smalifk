.class public final Lgp/m$a;
.super Ljava/lang/Object;
.source "DeserializationConfiguration.kt"

# interfaces
.implements Lgp/m;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgp/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:Lgp/m$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lgp/m$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lgp/m$a;->a:Lgp/m$a;

    return-void
.end method
