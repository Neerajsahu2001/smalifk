.class public interface abstract Lgp/v;
.super Ljava/lang/Object;
.source "FlexibleTypeDeserializer.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgp/v$a;
    }
.end annotation


# virtual methods
.method public abstract a(LOo/p;Ljava/lang/String;Lkp/M;Lkp/M;)Lkp/E;
.end method
