.class public final Lgp/z;
.super Ljava/lang/Object;
.source "MemberDeserializer.kt"


# instance fields
.field private final a:Lgp/n;

.field private final b:Lgp/f;


# direct methods
.method public constructor <init>(Lgp/n;)V
    .registers 4

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lgp/z;->a:Lgp/n;

    new-instance v0, Lgp/f;

    invoke-virtual {p1}, Lgp/n;->c()Lgp/l;

    move-result-object v1

    invoke-virtual {v1}, Lgp/l;->p()Luo/B;

    move-result-object v1

    invoke-virtual {p1}, Lgp/n;->c()Lgp/l;

    move-result-object p1

    invoke-virtual {p1}, Lgp/l;->q()Luo/D;

    move-result-object p1

    invoke-direct {v0, v1, p1}, Lgp/f;-><init>(Luo/B;Luo/D;)V

    iput-object v0, p0, Lgp/z;->b:Lgp/f;

    return-void
.end method

.method public static final synthetic a(Lgp/z;Luo/k;)Lgp/G;
    .registers 2

    invoke-direct {p0, p1}, Lgp/z;->c(Luo/k;)Lgp/G;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic b(Lgp/z;)Lgp/n;
    .registers 1

    iget-object p0, p0, Lgp/z;->a:Lgp/n;

    return-object p0
.end method

.method private final c(Luo/k;)Lgp/G;
    .registers 6

    instance-of v0, p1, Luo/E;

    if-eqz v0, :cond_1e

    new-instance v0, Lgp/G$b;

    check-cast p1, Luo/E;

    invoke-interface {p1}, Luo/E;->c()LTo/c;

    move-result-object p1

    iget-object v1, p0, Lgp/z;->a:Lgp/n;

    invoke-virtual {v1}, Lgp/n;->g()LQo/c;

    move-result-object v2

    invoke-virtual {v1}, Lgp/n;->j()LQo/g;

    move-result-object v3

    invoke-virtual {v1}, Lgp/n;->d()Lip/h;

    move-result-object v1

    invoke-direct {v0, p1, v2, v3, v1}, Lgp/G$b;-><init>(LTo/c;LQo/c;LQo/g;Lip/h;)V

    goto :goto_2a

    :cond_1e
    instance-of v0, p1, Lip/d;

    if-eqz v0, :cond_29

    check-cast p1, Lip/d;

    invoke-virtual {p1}, Lip/d;->X0()Lgp/G$a;

    move-result-object v0

    goto :goto_2a

    :cond_29
    const/4 v0, 0x0

    :goto_2a
    return-object v0
.end method

.method private final d(LUo/p;ILgp/c;)Lvo/h;
    .registers 6

    sget-object v0, LQo/b;->c:LQo/b$a;

    invoke-virtual {v0, p2}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-nez p2, :cond_11

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object p1

    return-object p1

    :cond_11
    new-instance p2, Lip/p;

    iget-object v0, p0, Lgp/z;->a:Lgp/n;

    invoke-virtual {v0}, Lgp/n;->h()Ljp/n;

    move-result-object v0

    new-instance v1, Lgp/z$a;

    invoke-direct {v1, p0, p1, p3}, Lgp/z$a;-><init>(Lgp/z;LUo/p;Lgp/c;)V

    invoke-direct {p2, v0, v1}, Lip/p;-><init>(Ljp/n;Leo/a;)V

    return-object p2
.end method

.method private final e(LOo/m;Z)Lvo/h;
    .registers 6

    sget-object v0, LQo/b;->c:LQo/b$a;

    invoke-virtual {p1}, LOo/m;->P()I

    move-result v1

    invoke-virtual {v0, v1}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_15

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object p1

    return-object p1

    :cond_15
    new-instance v0, Lip/p;

    iget-object v1, p0, Lgp/z;->a:Lgp/n;

    invoke-virtual {v1}, Lgp/n;->h()Ljp/n;

    move-result-object v1

    new-instance v2, Lgp/z$b;

    invoke-direct {v2, p0, p2, p1}, Lgp/z$b;-><init>(Lgp/z;ZLOo/m;)V

    invoke-direct {v0, v1, v2}, Lip/p;-><init>(Ljp/n;Leo/a;)V

    return-object v0
.end method

.method private final j(Ljava/util/List;LUo/p;Lgp/c;)Ljava/util/List;
    .registers 30
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LOo/t;",
            ">;",
            "LUo/p;",
            "Lgp/c;",
            ")",
            "Ljava/util/List<",
            "Luo/b0;",
            ">;"
        }
    .end annotation

    move-object/from16 v7, p0

    iget-object v8, v7, Lgp/z;->a:Lgp/n;

    invoke-virtual {v8}, Lgp/n;->e()Luo/k;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.CallableDescriptor"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v21, v0

    check-cast v21, Luo/a;

    invoke-interface/range {v21 .. v21}, Luo/k;->d()Luo/k;

    move-result-object v0

    const-string v1, "callableDescriptor.containingDeclaration"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v7, v0}, Lgp/z;->c(Luo/k;)Lgp/G;

    move-result-object v22

    move-object/from16 v0, p1

    check-cast v0, Ljava/lang/Iterable;

    new-instance v15, Ljava/util/ArrayList;

    invoke-static {v0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v15, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v23

    const/16 v24, 0x0

    const/4 v12, 0x0

    :goto_32
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_105

    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    add-int/lit8 v25, v12, 0x1

    if-ltz v12, :cond_100

    move-object v10, v0

    check-cast v10, LOo/t;

    invoke-virtual {v10}, LOo/t;->H()Z

    move-result v0

    if-eqz v0, :cond_4f

    invoke-virtual {v10}, LOo/t;->B()I

    move-result v0

    move v11, v0

    goto :goto_50

    :cond_4f
    const/4 v11, 0x0

    :goto_50
    if-eqz v22, :cond_79

    sget-object v0, LQo/b;->c:LQo/b$a;

    invoke-virtual {v0, v11}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_79

    new-instance v13, Lip/p;

    invoke-virtual {v8}, Lgp/n;->h()Ljp/n;

    move-result-object v14

    new-instance v6, Lgp/z$c;

    move-object v0, v6

    move-object/from16 v1, p0

    move-object/from16 v2, v22

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move v5, v12

    move-object v9, v6

    move-object v6, v10

    invoke-direct/range {v0 .. v6}, Lgp/z$c;-><init>(Lgp/z;Lgp/G;LUo/p;Lgp/c;ILOo/t;)V

    invoke-direct {v13, v14, v9}, Lip/p;-><init>(Ljp/n;Leo/a;)V

    goto :goto_7e

    :cond_79
    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v0

    move-object v13, v0

    :goto_7e
    invoke-virtual {v8}, Lgp/n;->g()LQo/c;

    move-result-object v0

    invoke-virtual {v10}, LOo/t;->C()I

    move-result v1

    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object v14

    invoke-virtual {v8}, Lgp/n;->i()Lgp/K;

    move-result-object v0

    invoke-virtual {v8}, Lgp/n;->j()LQo/g;

    move-result-object v1

    invoke-static {v10, v1}, LQo/f;->e(LOo/t;LQo/g;)LOo/p;

    move-result-object v1

    invoke-virtual {v0, v1}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v0

    sget-object v1, LQo/b;->G:LQo/b$a;

    invoke-virtual {v1, v11}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v16

    sget-object v1, LQo/b;->H:LQo/b$a;

    invoke-virtual {v1, v11}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v17

    sget-object v1, LQo/b;->I:LQo/b$a;

    invoke-virtual {v1, v11}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v18

    invoke-virtual {v8}, Lgp/n;->j()LQo/g;

    move-result-object v1

    const-string v2, "typeTable"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v10}, LOo/t;->L()Z

    move-result v2

    if-eqz v2, :cond_cc

    invoke-virtual {v10}, LOo/t;->F()LOo/p;

    move-result-object v1

    goto :goto_dc

    :cond_cc
    invoke-virtual {v10}, LOo/t;->M()Z

    move-result v2

    if-eqz v2, :cond_db

    invoke-virtual {v10}, LOo/t;->G()I

    move-result v2

    invoke-virtual {v1, v2}, LQo/g;->a(I)LOo/p;

    move-result-object v1

    goto :goto_dc

    :cond_db
    const/4 v1, 0x0

    :goto_dc
    if-eqz v1, :cond_e9

    invoke-virtual {v8}, Lgp/n;->i()Lgp/K;

    move-result-object v2

    invoke-virtual {v2, v1}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v1

    move-object/from16 v19, v1

    goto :goto_eb

    :cond_e9
    const/16 v19, 0x0

    :goto_eb
    sget-object v20, Luo/S;->a:Luo/S;

    new-instance v1, Lxo/W;

    const/4 v11, 0x0

    move-object v9, v1

    move-object/from16 v10, v21

    move-object v2, v15

    move-object v15, v0

    invoke-direct/range {v9 .. v20}, Lxo/W;-><init>(Luo/a;Luo/b0;ILvo/h;LTo/f;Lkp/E;ZZZLkp/E;Luo/S;)V

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v15, v2

    move/from16 v12, v25

    goto/16 :goto_32

    :cond_100
    invoke-static {}, Lkotlin/collections/q;->V()V

    const/4 v0, 0x0

    throw v0

    :cond_105
    move-object v2, v15

    invoke-static {v2}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final f(LOo/c;Z)Lip/c;
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v13, p1

    iget-object v14, v0, Lgp/z;->a:Lgp/n;

    invoke-virtual {v14}, Lgp/n;->e()Luo/k;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v15, v1

    check-cast v15, Luo/e;

    new-instance v12, Lip/c;

    invoke-virtual/range {p1 .. p1}, LOo/c;->A()I

    move-result v1

    sget-object v11, Lgp/c;->FUNCTION:Lgp/c;

    invoke-direct {v0, v13, v1, v11}, Lgp/z;->d(LUo/p;ILgp/c;)Lvo/h;

    move-result-object v4

    sget-object v6, Luo/b$a;->DECLARATION:Luo/b$a;

    invoke-virtual {v14}, Lgp/n;->g()LQo/c;

    move-result-object v8

    invoke-virtual {v14}, Lgp/n;->j()LQo/g;

    move-result-object v9

    invoke-virtual {v14}, Lgp/n;->k()LQo/h;

    move-result-object v10

    invoke-virtual {v14}, Lgp/n;->d()Lip/h;

    move-result-object v16

    const/4 v3, 0x0

    const/16 v17, 0x0

    move-object v1, v12

    move-object v2, v15

    move/from16 v5, p2

    move-object/from16 v7, p1

    move-object/from16 v18, v11

    move-object/from16 v11, v16

    move-object v0, v12

    move-object/from16 v12, v17

    invoke-direct/range {v1 .. v12}, Lip/c;-><init>(Luo/e;Luo/j;Lvo/h;ZLuo/b$a;LOo/c;LQo/c;LQo/g;LQo/h;Lip/h;Luo/S;)V

    sget-object v1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    invoke-static {v14, v0, v1}, Lgp/n;->b(Lgp/n;Lxo/p;Ljava/util/List;)Lgp/n;

    move-result-object v1

    invoke-virtual {v1}, Lgp/n;->f()Lgp/z;

    move-result-object v1

    invoke-virtual/range {p1 .. p1}, LOo/c;->B()Ljava/util/List;

    move-result-object v2

    const-string v3, "proto.valueParameterList"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v3, v18

    invoke-direct {v1, v2, v13, v3}, Lgp/z;->j(Ljava/util/List;LUo/p;Lgp/c;)Ljava/util/List;

    move-result-object v1

    sget-object v2, LQo/b;->d:LQo/b$c;

    invoke-virtual/range {p1 .. p1}, LOo/c;->A()I

    move-result v3

    invoke-virtual {v2, v3}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LOo/w;

    invoke-static {v2}, Lgp/I;->a(LOo/w;)Luo/p;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lxo/k;->j1(Ljava/util/List;Luo/r;)V

    invoke-interface {v15}, Luo/e;->q()Lkp/M;

    move-result-object v1

    invoke-virtual {v0, v1}, Lxo/w;->c1(Lkp/M;)V

    invoke-interface {v15}, Luo/z;->l0()Z

    move-result v1

    invoke-virtual {v0, v1}, Lxo/w;->V0(Z)V

    sget-object v1, LQo/b;->n:LQo/b$a;

    invoke-virtual/range {p1 .. p1}, LOo/c;->A()I

    move-result v2

    invoke-virtual {v1, v2}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Lxo/w;->X0(Z)V

    return-object v0
.end method

.method public final g(LOo/h;)Lip/m;
    .registers 29

    move-object/from16 v0, p0

    move-object/from16 v13, p1

    const-string v1, "proto"

    invoke-static {v13, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/h;->d0()Z

    move-result v1

    if-eqz v1, :cond_15

    invoke-virtual/range {p1 .. p1}, LOo/h;->R()I

    move-result v1

    :goto_13
    move v14, v1

    goto :goto_21

    :cond_15
    invoke-virtual/range {p1 .. p1}, LOo/h;->T()I

    move-result v1

    and-int/lit8 v2, v1, 0x3f

    shr-int/lit8 v1, v1, 0x8

    shl-int/lit8 v1, v1, 0x6

    add-int/2addr v1, v2

    goto :goto_13

    :goto_21
    sget-object v1, Lgp/c;->FUNCTION:Lgp/c;

    invoke-direct {v0, v13, v14, v1}, Lgp/z;->d(LUo/p;ILgp/c;)Lvo/h;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, LOo/h;->g0()Z

    move-result v2

    iget-object v15, v0, Lgp/z;->a:Lgp/n;

    if-nez v2, :cond_3c

    invoke-virtual/range {p1 .. p1}, LOo/h;->h0()Z

    move-result v2

    if-eqz v2, :cond_36

    goto :goto_3c

    :cond_36
    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v1

    move-object v12, v1

    goto :goto_4b

    :cond_3c
    :goto_3c
    new-instance v2, Lip/a;

    invoke-virtual {v15}, Lgp/n;->h()Ljp/n;

    move-result-object v3

    new-instance v5, Lgp/A;

    invoke-direct {v5, v0, v13, v1}, Lgp/A;-><init>(Lgp/z;LUo/p;Lgp/c;)V

    invoke-direct {v2, v3, v5}, Lip/a;-><init>(Ljp/n;Leo/a;)V

    move-object v12, v2

    :goto_4b
    invoke-virtual {v15}, Lgp/n;->e()Luo/k;

    move-result-object v1

    invoke-static {v1}, Lap/c;->g(Luo/k;)LTo/c;

    move-result-object v1

    invoke-virtual {v15}, Lgp/n;->g()LQo/c;

    move-result-object v2

    invoke-virtual/range {p1 .. p1}, LOo/h;->S()I

    move-result v3

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object v2

    invoke-virtual {v1, v2}, LTo/c;->c(LTo/f;)LTo/c;

    move-result-object v1

    sget-object v2, Lgp/J;->a:LTo/c;

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_71

    invoke-static {}, LQo/h;->a()LQo/h;

    move-result-object v1

    :goto_6f
    move-object v10, v1

    goto :goto_76

    :cond_71
    invoke-virtual {v15}, Lgp/n;->k()LQo/h;

    move-result-object v1

    goto :goto_6f

    :goto_76
    new-instance v11, Lip/m;

    invoke-virtual {v15}, Lgp/n;->e()Luo/k;

    move-result-object v2

    invoke-virtual {v15}, Lgp/n;->g()LQo/c;

    move-result-object v1

    invoke-virtual/range {p1 .. p1}, LOo/h;->S()I

    move-result v3

    invoke-static {v1, v3}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object v5

    sget-object v1, LQo/b;->o:LQo/b$c;

    invoke-virtual {v1, v14}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LOo/i;

    invoke-static {v1}, Lgp/I;->b(LOo/i;)Luo/b$a;

    move-result-object v6

    invoke-virtual {v15}, Lgp/n;->g()LQo/c;

    move-result-object v8

    invoke-virtual {v15}, Lgp/n;->j()LQo/g;

    move-result-object v9

    invoke-virtual {v15}, Lgp/n;->d()Lip/h;

    move-result-object v16

    const/4 v3, 0x0

    const/16 v17, 0x0

    move-object v1, v11

    move-object/from16 v7, p1

    move-object/from16 v26, v11

    move-object/from16 v11, v16

    move-object v0, v12

    move-object/from16 v12, v17

    invoke-direct/range {v1 .. v12}, Lip/m;-><init>(Luo/k;Luo/Q;Lvo/h;LTo/f;Luo/b$a;LOo/h;LQo/c;LQo/g;LQo/h;Lip/h;Luo/S;)V

    invoke-virtual/range {p1 .. p1}, LOo/h;->Z()Ljava/util/List;

    move-result-object v1

    const-string v2, "proto.typeParameterList"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v2, v26

    invoke-static {v15, v2, v1}, Lgp/n;->b(Lgp/n;Lxo/p;Ljava/util/List;)Lgp/n;

    move-result-object v1

    invoke-virtual {v15}, Lgp/n;->j()LQo/g;

    move-result-object v3

    invoke-static {v13, v3}, LQo/f;->b(LOo/h;LQo/g;)LOo/p;

    move-result-object v3

    const/4 v4, 0x0

    if-eqz v3, :cond_db

    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v5

    invoke-virtual {v5, v3}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v3

    if-eqz v3, :cond_db

    invoke-static {v2, v3, v0}, LWo/h;->i(Luo/a;Lkp/E;Lvo/h;)Lxo/O;

    move-result-object v0

    move-object/from16 v17, v0

    goto :goto_dd

    :cond_db
    move-object/from16 v17, v4

    :goto_dd
    invoke-virtual {v15}, Lgp/n;->e()Luo/k;

    move-result-object v0

    instance-of v3, v0, Luo/e;

    if-eqz v3, :cond_e8

    check-cast v0, Luo/e;

    goto :goto_e9

    :cond_e8
    move-object v0, v4

    :goto_e9
    if-eqz v0, :cond_f2

    invoke-interface {v0}, Luo/e;->K0()Luo/O;

    move-result-object v0

    move-object/from16 v18, v0

    goto :goto_f4

    :cond_f2
    move-object/from16 v18, v4

    :goto_f4
    invoke-virtual {v15}, Lgp/n;->j()LQo/g;

    move-result-object v0

    const-string v3, "typeTable"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/h;->O()Ljava/util/List;

    move-result-object v3

    move-object v5, v3

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    xor-int/lit8 v5, v5, 0x1

    if-eqz v5, :cond_10d

    goto :goto_10e

    :cond_10d
    move-object v3, v4

    :goto_10e
    if-nez v3, :cond_146

    invoke-virtual/range {p1 .. p1}, LOo/h;->N()Ljava/util/List;

    move-result-object v3

    const-string v5, "contextReceiverTypeIdList"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ljava/lang/Iterable;

    new-instance v5, Ljava/util/ArrayList;

    invoke-static {v3}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_128
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_145

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    const-string v7, "it"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-virtual {v0, v6}, LQo/g;->a(I)LOo/p;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_128

    :cond_145
    move-object v3, v5

    :cond_146
    check-cast v3, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_151
    :goto_151
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_173

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LOo/p;

    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v6

    invoke-virtual {v6, v5}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v5

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v6

    invoke-static {v2, v5, v4, v6}, LWo/h;->b(Luo/a;Lkp/E;LTo/f;Lvo/h;)Lxo/O;

    move-result-object v5

    if-eqz v5, :cond_151

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_151

    :cond_173
    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v3

    invoke-virtual {v3}, Lgp/K;->e()Ljava/util/List;

    move-result-object v20

    invoke-virtual {v1}, Lgp/n;->f()Lgp/z;

    move-result-object v3

    invoke-virtual/range {p1 .. p1}, LOo/h;->b0()Ljava/util/List;

    move-result-object v4

    const-string v5, "proto.valueParameterList"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v5, Lgp/c;->FUNCTION:Lgp/c;

    invoke-direct {v3, v4, v13, v5}, Lgp/z;->j(Ljava/util/List;LUo/p;Lgp/c;)Ljava/util/List;

    move-result-object v21

    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v3

    invoke-virtual {v15}, Lgp/n;->j()LQo/g;

    move-result-object v4

    invoke-static {v13, v4}, LQo/f;->c(LOo/h;LQo/g;)LOo/p;

    move-result-object v4

    invoke-virtual {v3, v4}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v22

    sget-object v3, LQo/b;->e:LQo/b$c;

    invoke-virtual {v3, v14}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LOo/j;

    invoke-static {v3}, Lgp/H;->a(LOo/j;)Luo/A;

    move-result-object v23

    sget-object v3, LQo/b;->d:LQo/b$c;

    invoke-virtual {v3, v14}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LOo/w;

    invoke-static {v3}, Lgp/I;->a(LOo/w;)Luo/p;

    move-result-object v24

    invoke-static {}, Lkotlin/collections/J;->d()Ljava/util/Map;

    move-result-object v25

    move-object/from16 v16, v2

    move-object/from16 v19, v0

    invoke-virtual/range {v16 .. v25}, Lxo/P;->k1(Lxo/O;Luo/O;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkp/E;Luo/A;Luo/r;Ljava/util/Map;)Lxo/P;

    sget-object v0, LQo/b;->p:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2, v0}, Lxo/w;->b1(Z)V

    sget-object v0, LQo/b;->q:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2, v0}, Lxo/w;->Z0(Z)V

    sget-object v0, LQo/b;->t:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2, v0}, Lxo/w;->W0(Z)V

    sget-object v0, LQo/b;->r:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2, v0}, Lxo/w;->a1(Z)V

    sget-object v0, LQo/b;->s:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2, v0}, Lxo/w;->e1(Z)V

    sget-object v0, LQo/b;->u:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2, v0}, Lxo/w;->d1(Z)V

    sget-object v0, LQo/b;->v:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2, v0}, Lxo/w;->V0(Z)V

    sget-object v0, LQo/b;->w:LQo/b$a;

    invoke-virtual {v0, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {v2, v0}, Lxo/w;->X0(Z)V

    invoke-virtual {v15}, Lgp/n;->c()Lgp/l;

    move-result-object v0

    invoke-virtual {v0}, Lgp/l;->h()Lgp/k;

    move-result-object v0

    invoke-virtual {v15}, Lgp/n;->j()LQo/g;

    move-result-object v3

    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v1

    invoke-interface {v0, v13, v2, v3, v1}, Lgp/k;->a(LOo/h;Lip/m;LQo/g;Lgp/K;)V

    return-object v2
.end method

.method public final h(LOo/m;)Lip/l;
    .registers 27

    move-object/from16 v0, p0

    move-object/from16 v15, p1

    const-string v1, "proto"

    invoke-static {v15, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/m;->b0()Z

    move-result v1

    if-eqz v1, :cond_15

    invoke-virtual/range {p1 .. p1}, LOo/m;->P()I

    move-result v1

    :goto_13
    move v3, v1

    goto :goto_21

    :cond_15
    invoke-virtual/range {p1 .. p1}, LOo/m;->S()I

    move-result v1

    and-int/lit8 v2, v1, 0x3f

    shr-int/lit8 v1, v1, 0x8

    shl-int/lit8 v1, v1, 0x6

    add-int/2addr v1, v2

    goto :goto_13

    :goto_21
    new-instance v14, Lip/l;

    move-object v1, v14

    iget-object v13, v0, Lgp/z;->a:Lgp/n;

    invoke-virtual {v13}, Lgp/n;->e()Luo/k;

    move-result-object v2

    sget-object v4, Lgp/c;->PROPERTY:Lgp/c;

    invoke-direct {v0, v15, v3, v4}, Lgp/z;->d(LUo/p;ILgp/c;)Lvo/h;

    move-result-object v4

    sget-object v5, LQo/b;->e:LQo/b$c;

    invoke-virtual {v5, v3}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LOo/j;

    invoke-static {v5}, Lgp/H;->a(LOo/j;)Luo/A;

    move-result-object v5

    sget-object v6, LQo/b;->d:LQo/b$c;

    invoke-virtual {v6, v3}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LOo/w;

    invoke-static {v6}, Lgp/I;->a(LOo/w;)Luo/p;

    move-result-object v6

    sget-object v7, LQo/b;->x:LQo/b$a;

    invoke-virtual {v7, v3}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    invoke-virtual {v13}, Lgp/n;->g()LQo/c;

    move-result-object v8

    invoke-virtual/range {p1 .. p1}, LOo/m;->R()I

    move-result v9

    invoke-static {v8, v9}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object v8

    sget-object v9, LQo/b;->o:LQo/b$c;

    invoke-virtual {v9, v3}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LOo/i;

    invoke-static {v9}, Lgp/I;->b(LOo/i;)Luo/b$a;

    move-result-object v9

    sget-object v10, LQo/b;->B:LQo/b$a;

    invoke-virtual {v10, v3}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    sget-object v11, LQo/b;->A:LQo/b$a;

    invoke-virtual {v11, v3}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v11

    sget-object v12, LQo/b;->D:LQo/b$a;

    invoke-virtual {v12, v3}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v12

    move-object/from16 v16, v13

    sget-object v13, LQo/b;->E:LQo/b$a;

    invoke-virtual {v13, v3}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v13

    move-object/from16 v20, v16

    move-object/from16 v16, v14

    sget-object v14, LQo/b;->F:LQo/b$a;

    invoke-virtual {v14, v3}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v14

    move-object/from16 v21, v16

    invoke-virtual/range {v20 .. v20}, Lgp/n;->g()LQo/c;

    move-result-object v16

    invoke-virtual/range {v20 .. v20}, Lgp/n;->j()LQo/g;

    move-result-object v17

    invoke-virtual/range {v20 .. v20}, Lgp/n;->k()LQo/h;

    move-result-object v18

    invoke-virtual/range {v20 .. v20}, Lgp/n;->d()Lip/h;

    move-result-object v19

    const/16 v22, 0x0

    move v0, v3

    move-object/from16 v3, v22

    move-object/from16 v15, p1

    invoke-direct/range {v1 .. v19}, Lip/l;-><init>(Luo/k;Luo/L;Lvo/h;Luo/A;Luo/r;ZLTo/f;Luo/b$a;ZZZZZLOo/m;LQo/c;LQo/g;LQo/h;Lip/h;)V

    invoke-virtual/range {p1 .. p1}, LOo/m;->a0()Ljava/util/List;

    move-result-object v1

    const-string v2, "proto.typeParameterList"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v3, v20

    move-object/from16 v2, v21

    invoke-static {v3, v2, v1}, Lgp/n;->b(Lgp/n;Lxo/p;Ljava/util/List;)Lgp/n;

    move-result-object v1

    sget-object v4, LQo/b;->y:LQo/b$a;

    invoke-virtual {v4, v0}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    if-eqz v10, :cond_e8

    invoke-virtual/range {p1 .. p1}, LOo/m;->f0()Z

    move-result v4

    if-nez v4, :cond_ee

    invoke-virtual/range {p1 .. p1}, LOo/m;->g0()Z

    move-result v4

    if-eqz v4, :cond_e8

    goto :goto_ee

    :cond_e8
    move-object/from16 v15, p1

    move v14, v0

    move-object/from16 v0, p0

    goto :goto_104

    :cond_ee
    :goto_ee
    sget-object v4, Lgp/c;->PROPERTY_GETTER:Lgp/c;

    new-instance v5, Lip/a;

    invoke-virtual {v3}, Lgp/n;->h()Ljp/n;

    move-result-object v6

    new-instance v7, Lgp/A;

    move-object/from16 v15, p1

    move v14, v0

    move-object/from16 v0, p0

    invoke-direct {v7, v0, v15, v4}, Lgp/A;-><init>(Lgp/z;LUo/p;Lgp/c;)V

    invoke-direct {v5, v6, v7}, Lip/a;-><init>(Ljp/n;Leo/a;)V

    goto :goto_108

    :goto_104
    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v5

    :goto_108
    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v4

    invoke-virtual {v3}, Lgp/n;->j()LQo/g;

    move-result-object v6

    invoke-static {v15, v6}, LQo/f;->d(LOo/m;LQo/g;)LOo/p;

    move-result-object v6

    invoke-virtual {v4, v6}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v6

    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v4

    invoke-virtual {v4}, Lgp/K;->e()Ljava/util/List;

    move-result-object v7

    invoke-virtual {v3}, Lgp/n;->e()Luo/k;

    move-result-object v4

    instance-of v8, v4, Luo/e;

    if-eqz v8, :cond_12b

    check-cast v4, Luo/e;

    goto :goto_12c

    :cond_12b
    const/4 v4, 0x0

    :goto_12c
    if-eqz v4, :cond_134

    invoke-interface {v4}, Luo/e;->K0()Luo/O;

    move-result-object v4

    move-object v8, v4

    goto :goto_135

    :cond_134
    const/4 v8, 0x0

    :goto_135
    invoke-virtual {v3}, Lgp/n;->j()LQo/g;

    move-result-object v4

    const-string v9, "typeTable"

    invoke-static {v4, v9}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/m;->f0()Z

    move-result v11

    if-eqz v11, :cond_149

    invoke-virtual/range {p1 .. p1}, LOo/m;->T()LOo/p;

    move-result-object v4

    goto :goto_159

    :cond_149
    invoke-virtual/range {p1 .. p1}, LOo/m;->g0()Z

    move-result v11

    if-eqz v11, :cond_158

    invoke-virtual/range {p1 .. p1}, LOo/m;->U()I

    move-result v11

    invoke-virtual {v4, v11}, LQo/g;->a(I)LOo/p;

    move-result-object v4

    goto :goto_159

    :cond_158
    const/4 v4, 0x0

    :goto_159
    if-eqz v4, :cond_16b

    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v11

    invoke-virtual {v11, v4}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v4

    if-eqz v4, :cond_16b

    invoke-static {v2, v4, v5}, LWo/h;->i(Luo/a;Lkp/E;Lvo/h;)Lxo/O;

    move-result-object v4

    move-object v11, v4

    goto :goto_16c

    :cond_16b
    const/4 v11, 0x0

    :goto_16c
    invoke-virtual {v3}, Lgp/n;->j()LQo/g;

    move-result-object v4

    invoke-static {v4, v9}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/m;->N()Ljava/util/List;

    move-result-object v5

    move-object v9, v5

    check-cast v9, Ljava/util/Collection;

    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    const/4 v12, 0x1

    xor-int/2addr v9, v12

    if-eqz v9, :cond_183

    goto :goto_184

    :cond_183
    const/4 v5, 0x0

    :goto_184
    if-nez v5, :cond_1bc

    invoke-virtual/range {p1 .. p1}, LOo/m;->M()Ljava/util/List;

    move-result-object v5

    const-string v9, "contextReceiverTypeIdList"

    invoke-static {v5, v9}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Ljava/lang/Iterable;

    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v5}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v12

    invoke-direct {v9, v12}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_19e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_1bb

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    const-string v13, "it"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    invoke-virtual {v4, v12}, LQo/g;->a(I)LOo/p;

    move-result-object v12

    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_19e

    :cond_1bb
    move-object v5, v9

    :cond_1bc
    check-cast v5, Ljava/lang/Iterable;

    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v5}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v4

    invoke-direct {v9, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1cb
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1ec

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LOo/p;

    invoke-virtual {v1}, Lgp/n;->i()Lgp/K;

    move-result-object v12

    invoke-virtual {v12, v5}, Lgp/K;->j(LOo/p;)Lkp/E;

    move-result-object v5

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v12

    const/4 v13, 0x0

    invoke-static {v2, v5, v13, v12}, LWo/h;->b(Luo/a;Lkp/E;LTo/f;Lvo/h;)Lxo/O;

    move-result-object v5

    invoke-virtual {v9, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1cb

    :cond_1ec
    const/4 v13, 0x0

    move-object v4, v2

    move-object v5, v6

    move-object v6, v7

    move-object v7, v8

    move-object v8, v11

    invoke-virtual/range {v4 .. v9}, Lxo/L;->V0(Lkp/E;Ljava/util/List;Luo/O;Lxo/O;Ljava/util/List;)V

    sget-object v4, LQo/b;->c:LQo/b$a;

    invoke-virtual {v4, v14}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    sget-object v12, LQo/b;->d:LQo/b$c;

    invoke-virtual {v12, v14}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LOo/w;

    sget-object v11, LQo/b;->e:LQo/b$c;

    invoke-virtual {v11, v14}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LOo/j;

    invoke-static {v4, v5, v6}, LQo/b;->b(ZLOo/w;LOo/j;)I

    move-result v17

    sget-object v18, Luo/S;->a:Luo/S;

    if-eqz v10, :cond_299

    invoke-virtual/range {p1 .. p1}, LOo/m;->c0()Z

    move-result v4

    if-eqz v4, :cond_222

    invoke-virtual/range {p1 .. p1}, LOo/m;->Q()I

    move-result v4

    goto :goto_224

    :cond_222
    move/from16 v4, v17

    :goto_224
    sget-object v5, LQo/b;->J:LQo/b$a;

    invoke-virtual {v5, v4}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    sget-object v6, LQo/b;->K:LQo/b$a;

    invoke-virtual {v6, v4}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    sget-object v6, LQo/b;->L:LQo/b$a;

    invoke-virtual {v6, v4}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v19

    sget-object v6, Lgp/c;->PROPERTY_GETTER:Lgp/c;

    invoke-direct {v0, v15, v4, v6}, Lgp/z;->d(LUo/p;ILgp/c;)Lvo/h;

    move-result-object v6

    if-eqz v5, :cond_283

    new-instance v20, Lxo/M;

    invoke-virtual {v11, v4}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LOo/j;

    invoke-static {v7}, Lgp/H;->a(LOo/j;)Luo/A;

    move-result-object v7

    invoke-virtual {v12, v4}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LOo/w;

    invoke-static {v4}, Lgp/I;->a(LOo/w;)Luo/p;

    move-result-object v8

    const/16 v16, 0x1

    xor-int/lit8 v9, v5, 0x1

    invoke-virtual {v2}, Lxo/L;->h()Luo/b$a;

    move-result-object v21

    const/16 v22, 0x0

    move-object/from16 v4, v20

    move-object v5, v2

    move-object/from16 v23, v11

    move/from16 v11, v19

    move-object/from16 v19, v3

    move-object v3, v12

    move-object/from16 v12, v21

    move-object/from16 v13, v22

    move-object/from16 v21, v1

    move v1, v14

    move-object/from16 v14, v18

    invoke-direct/range {v4 .. v14}, Lxo/M;-><init>(Luo/L;Lvo/h;Luo/A;Luo/r;ZZZLuo/b$a;Luo/M;Luo/S;)V

    move-object/from16 v13, v20

    goto :goto_290

    :cond_283
    move-object/from16 v21, v1

    move-object/from16 v19, v3

    move-object/from16 v23, v11

    move-object v3, v12

    move v1, v14

    invoke-static {v2, v6}, LWo/h;->d(Luo/L;Lvo/h;)Lxo/M;

    move-result-object v4

    move-object v13, v4

    :goto_290
    invoke-virtual {v2}, Lxo/L;->getReturnType()Lkp/E;

    move-result-object v4

    invoke-virtual {v13, v4}, Lxo/M;->Q0(Lkp/E;)V

    move-object v14, v13

    goto :goto_2a2

    :cond_299
    move-object/from16 v21, v1

    move-object/from16 v19, v3

    move-object/from16 v23, v11

    move-object v3, v12

    move v1, v14

    const/4 v14, 0x0

    :goto_2a2
    sget-object v4, LQo/b;->z:LQo/b$a;

    invoke-virtual {v4, v1}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_33d

    invoke-virtual/range {p1 .. p1}, LOo/m;->j0()Z

    move-result v4

    if-eqz v4, :cond_2b8

    invoke-virtual/range {p1 .. p1}, LOo/m;->Y()I

    move-result v17

    :cond_2b8
    move/from16 v4, v17

    sget-object v5, LQo/b;->J:LQo/b$a;

    invoke-virtual {v5, v4}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    sget-object v6, LQo/b;->K:LQo/b$a;

    invoke-virtual {v6, v4}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    sget-object v6, LQo/b;->L:LQo/b$a;

    invoke-virtual {v6, v4}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v11

    sget-object v13, Lgp/c;->PROPERTY_SETTER:Lgp/c;

    invoke-direct {v0, v15, v4, v13}, Lgp/z;->d(LUo/p;ILgp/c;)Lvo/h;

    move-result-object v6

    if-eqz v5, :cond_332

    new-instance v12, Lxo/N;

    move-object/from16 v7, v23

    invoke-virtual {v7, v4}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LOo/j;

    invoke-static {v7}, Lgp/H;->a(LOo/j;)Luo/A;

    move-result-object v7

    invoke-virtual {v3, v4}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LOo/w;

    invoke-static {v3}, Lgp/I;->a(LOo/w;)Luo/p;

    move-result-object v8

    const/4 v3, 0x1

    xor-int/lit8 v9, v5, 0x1

    invoke-virtual {v2}, Lxo/L;->h()Luo/b$a;

    move-result-object v3

    const/16 v17, 0x0

    move-object v4, v12

    move-object v5, v2

    move-object v0, v12

    move-object v12, v3

    move-object v3, v13

    move-object/from16 v13, v17

    move-object/from16 v24, v14

    move-object/from16 v14, v18

    invoke-direct/range {v4 .. v14}, Lxo/N;-><init>(Luo/L;Lvo/h;Luo/A;Luo/r;ZZZLuo/b$a;Luo/N;Luo/S;)V

    sget-object v4, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    move-object/from16 v5, v21

    invoke-static {v5, v0, v4}, Lgp/n;->b(Lgp/n;Lxo/p;Ljava/util/List;)Lgp/n;

    move-result-object v4

    invoke-virtual {v4}, Lgp/n;->f()Lgp/z;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, LOo/m;->Z()LOo/t;

    move-result-object v5

    invoke-static {v5}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-direct {v4, v5, v15, v3}, Lgp/z;->j(Ljava/util/List;LUo/p;Lgp/c;)Ljava/util/List;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Luo/b0;

    invoke-virtual {v0, v3}, Lxo/N;->R0(Luo/b0;)V

    move-object v13, v0

    goto :goto_340

    :cond_332
    move-object/from16 v24, v14

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v0

    invoke-static {v2, v6, v0}, LWo/h;->e(Luo/L;Lvo/h;Lvo/h$a$a;)Lxo/N;

    move-result-object v13

    goto :goto_340

    :cond_33d
    move-object/from16 v24, v14

    const/4 v13, 0x0

    :goto_340
    sget-object v0, LQo/b;->C:LQo/b$a;

    invoke-virtual {v0, v1}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_358

    new-instance v0, Lgp/C;

    move-object/from16 v1, p0

    invoke-direct {v0, v1, v15, v2}, Lgp/C;-><init>(Lgp/z;LOo/m;Lip/l;)V

    const/4 v3, 0x0

    invoke-virtual {v2, v3, v0}, Lxo/Y;->I0(Ljp/k;Leo/a;)V

    goto :goto_35b

    :cond_358
    const/4 v3, 0x0

    move-object/from16 v1, p0

    :goto_35b
    invoke-virtual/range {v19 .. v19}, Lgp/n;->e()Luo/k;

    move-result-object v0

    instance-of v4, v0, Luo/e;

    if-eqz v4, :cond_366

    check-cast v0, Luo/e;

    goto :goto_367

    :cond_366
    move-object v0, v3

    :goto_367
    if-eqz v0, :cond_36e

    invoke-interface {v0}, Luo/e;->h()Luo/f;

    move-result-object v0

    goto :goto_36f

    :cond_36e
    move-object v0, v3

    :goto_36f
    sget-object v4, Luo/f;->ANNOTATION_CLASS:Luo/f;

    if-ne v0, v4, :cond_37b

    new-instance v0, Lgp/E;

    invoke-direct {v0, v1, v15, v2}, Lgp/E;-><init>(Lgp/z;LOo/m;Lip/l;)V

    invoke-virtual {v2, v3, v0}, Lxo/Y;->I0(Ljp/k;Leo/a;)V

    :cond_37b
    new-instance v0, Lxo/t;

    const/4 v3, 0x0

    invoke-direct {v1, v15, v3}, Lgp/z;->e(LOo/m;Z)Lvo/h;

    move-result-object v3

    invoke-direct {v0, v2, v3}, Lxo/t;-><init>(Lxo/L;Lvo/h;)V

    new-instance v3, Lxo/t;

    const/4 v4, 0x1

    invoke-direct {v1, v15, v4}, Lgp/z;->e(LOo/m;Z)Lvo/h;

    move-result-object v4

    invoke-direct {v3, v2, v4}, Lxo/t;-><init>(Lxo/L;Lvo/h;)V

    move-object/from16 v4, v24

    invoke-virtual {v2, v4, v13, v0, v3}, Lxo/L;->R0(Lxo/M;Lxo/N;Luo/t;Luo/t;)V

    return-object v2
.end method

.method public final i(LOo/q;)Lip/n;
    .registers 17

    move-object v0, p0

    const-string v1, "proto"

    move-object/from16 v13, p1

    invoke-static {v13, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/q;->G()Ljava/util/List;

    move-result-object v1

    const-string v2, "proto.annotationList"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    new-instance v2, Ljava/util/ArrayList;

    invoke-static {v1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_20
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    iget-object v14, v0, Lgp/z;->a:Lgp/n;

    if-eqz v3, :cond_41

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LOo/a;

    const-string v4, "it"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v14}, Lgp/n;->g()LQo/c;

    move-result-object v4

    iget-object v5, v0, Lgp/z;->b:Lgp/f;

    invoke-virtual {v5, v3, v4}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_20

    :cond_41
    invoke-static {v2}, Lvo/h$a;->a(Ljava/util/List;)Lvo/h;

    move-result-object v5

    sget-object v1, LQo/b;->d:LQo/b$c;

    invoke-virtual/range {p1 .. p1}, LOo/q;->K()I

    move-result v2

    invoke-virtual {v1, v2}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LOo/w;

    invoke-static {v1}, Lgp/I;->a(LOo/w;)Luo/p;

    move-result-object v7

    new-instance v1, Lip/n;

    invoke-virtual {v14}, Lgp/n;->h()Ljp/n;

    move-result-object v3

    invoke-virtual {v14}, Lgp/n;->e()Luo/k;

    move-result-object v4

    invoke-virtual {v14}, Lgp/n;->g()LQo/c;

    move-result-object v2

    invoke-virtual/range {p1 .. p1}, LOo/q;->L()I

    move-result v6

    invoke-static {v2, v6}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object v6

    invoke-virtual {v14}, Lgp/n;->g()LQo/c;

    move-result-object v9

    invoke-virtual {v14}, Lgp/n;->j()LQo/g;

    move-result-object v10

    invoke-virtual {v14}, Lgp/n;->k()LQo/h;

    move-result-object v11

    invoke-virtual {v14}, Lgp/n;->d()Lip/h;

    move-result-object v12

    move-object v2, v1

    move-object/from16 v8, p1

    invoke-direct/range {v2 .. v12}, Lip/n;-><init>(Ljp/n;Luo/k;Lvo/h;LTo/f;Luo/r;LOo/q;LQo/c;LQo/g;LQo/h;Lip/h;)V

    invoke-virtual/range {p1 .. p1}, LOo/q;->M()Ljava/util/List;

    move-result-object v2

    const-string v3, "proto.typeParameterList"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v14, v1, v2}, Lgp/n;->b(Lgp/n;Lxo/p;Ljava/util/List;)Lgp/n;

    move-result-object v2

    invoke-virtual {v2}, Lgp/n;->i()Lgp/K;

    move-result-object v3

    invoke-virtual {v3}, Lgp/K;->e()Ljava/util/List;

    move-result-object v3

    invoke-virtual {v2}, Lgp/n;->i()Lgp/K;

    move-result-object v4

    invoke-virtual {v14}, Lgp/n;->j()LQo/g;

    move-result-object v5

    const-string v6, "typeTable"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/q;->T()Z

    move-result v7

    if-eqz v7, :cond_b3

    invoke-virtual/range {p1 .. p1}, LOo/q;->N()LOo/p;

    move-result-object v5

    const-string v7, "underlyingType"

    invoke-static {v5, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_c1

    :cond_b3
    invoke-virtual/range {p1 .. p1}, LOo/q;->U()Z

    move-result v7

    if-eqz v7, :cond_103

    invoke-virtual/range {p1 .. p1}, LOo/q;->O()I

    move-result v7

    invoke-virtual {v5, v7}, LQo/g;->a(I)LOo/p;

    move-result-object v5

    :goto_c1
    const/4 v7, 0x0

    invoke-virtual {v4, v5, v7}, Lgp/K;->g(LOo/p;Z)Lkp/M;

    move-result-object v4

    invoke-virtual {v2}, Lgp/n;->i()Lgp/K;

    move-result-object v2

    invoke-virtual {v14}, Lgp/n;->j()LQo/g;

    move-result-object v5

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, LOo/q;->P()Z

    move-result v6

    if-eqz v6, :cond_e1

    invoke-virtual/range {p1 .. p1}, LOo/q;->I()LOo/p;

    move-result-object v5

    const-string v6, "expandedType"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_ef

    :cond_e1
    invoke-virtual/range {p1 .. p1}, LOo/q;->Q()Z

    move-result v6

    if-eqz v6, :cond_f7

    invoke-virtual/range {p1 .. p1}, LOo/q;->J()I

    move-result v6

    invoke-virtual {v5, v6}, LQo/g;->a(I)LOo/p;

    move-result-object v5

    :goto_ef
    invoke-virtual {v2, v5, v7}, Lgp/K;->g(LOo/p;Z)Lkp/M;

    move-result-object v2

    invoke-virtual {v1, v3, v4, v2}, Lip/n;->O0(Ljava/util/List;Lkp/M;Lkp/M;)V

    return-object v1

    :cond_f7
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "No expandedType in ProtoBuf.TypeAlias"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_103
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "No underlyingType in ProtoBuf.TypeAlias"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method
