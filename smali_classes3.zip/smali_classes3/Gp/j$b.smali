.class final Lgp/j$b;
.super Lkotlin/jvm/internal/p;
.source "ClassDeserializer.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lgp/j;-><init>(Lgp/l;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Lgp/j$a;",
        "Luo/e;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/j;


# direct methods
.method constructor <init>(Lgp/j;)V
    .registers 2

    iput-object p1, p0, Lgp/j$b;->a:Lgp/j;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lgp/j$a;

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/j$b;->a:Lgp/j;

    invoke-static {v0, p1}, Lgp/j;->a(Lgp/j;Lgp/j$a;)Luo/e;

    move-result-object p1

    return-object p1
.end method
