.class public final LGp/e$b;
.super Ljava/lang/Object;
.source "DiskLruCache.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LGp/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "b"
.end annotation


# instance fields
.field private final a:[J

.field private final b:Ljava/util/ArrayList;

.field private final c:Ljava/util/ArrayList;

.field private d:Z

.field private e:Z

.field private f:LGp/e$a;

.field private g:I

.field private h:J

.field private final i:Ljava/lang/String;

.field final synthetic j:LGp/e;


# direct methods
.method public constructor <init>(LGp/e;Ljava/lang/String;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LGp/e$b;->j:LGp/e;

    iput-object p2, p0, LGp/e$b;->i:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x2

    new-array v1, v0, [J

    iput-object v1, p0, LGp/e$b;->a:[J

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, LGp/e$b;->b:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, LGp/e$b;->c:Ljava/util/ArrayList;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 p2, 0x2e

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result p2

    const/4 v2, 0x0

    :goto_31
    if-ge v2, v0, :cond_65

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object v3, p0, LGp/e$b;->b:Ljava/util/ArrayList;

    new-instance v4, Ljava/io/File;

    invoke-virtual {p1}, LGp/e;->c0()Ljava/io/File;

    move-result-object v5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-interface {v3, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const-string v3, ".tmp"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, LGp/e$b;->c:Ljava/util/ArrayList;

    new-instance v4, Ljava/io/File;

    invoke-virtual {p1}, LGp/e;->c0()Ljava/io/File;

    move-result-object v5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-interface {v3, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->setLength(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_31

    :cond_65
    return-void
.end method


# virtual methods
.method public final a()Ljava/util/ArrayList;
    .registers 2

    iget-object v0, p0, LGp/e$b;->b:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final b()LGp/e$a;
    .registers 2

    iget-object v0, p0, LGp/e$b;->f:LGp/e$a;

    return-object v0
.end method

.method public final c()Ljava/util/ArrayList;
    .registers 2

    iget-object v0, p0, LGp/e$b;->c:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LGp/e$b;->i:Ljava/lang/String;

    return-object v0
.end method

.method public final e()[J
    .registers 2

    iget-object v0, p0, LGp/e$b;->a:[J

    return-object v0
.end method

.method public final f()I
    .registers 2

    iget v0, p0, LGp/e$b;->g:I

    return v0
.end method

.method public final g()Z
    .registers 2

    iget-boolean v0, p0, LGp/e$b;->d:Z

    return v0
.end method

.method public final h()J
    .registers 3

    iget-wide v0, p0, LGp/e$b;->h:J

    return-wide v0
.end method

.method public final i()Z
    .registers 2

    iget-boolean v0, p0, LGp/e$b;->e:Z

    return v0
.end method

.method public final j(LGp/e$a;)V
    .registers 2

    iput-object p1, p0, LGp/e$b;->f:LGp/e$a;

    return-void
.end method

.method public final k(Ljava/util/List;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    iget-object v1, p0, LGp/e$b;->j:LGp/e;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const-string v2, "unexpected journal line: "

    if-ne v0, v1, :cond_3c

    :try_start_e
    move-object v0, p1

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_16
    if-ge v1, v0, :cond_29

    iget-object v3, p0, LGp/e$b;->a:[J

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    aput-wide v4, v3, v1
    :try_end_26
    .catch Ljava/lang/NumberFormatException; {:try_start_e .. :try_end_26} :catch_2a

    add-int/lit8 v1, v1, 0x1

    goto :goto_16

    :cond_29
    return-void

    :catch_2a
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3c
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final l(I)V
    .registers 2

    iput p1, p0, LGp/e$b;->g:I

    return-void
.end method

.method public final m()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, LGp/e$b;->d:Z

    return-void
.end method

.method public final n(J)V
    .registers 3

    iput-wide p1, p0, LGp/e$b;->h:J

    return-void
.end method

.method public final o()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, LGp/e$b;->e:Z

    return-void
.end method

.method public final p()LGp/e$c;
    .registers 12

    sget-object v0, LEp/b;->a:[B

    iget-boolean v0, p0, LGp/e$b;->d:Z

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return-object v1

    :cond_8
    iget-object v0, p0, LGp/e$b;->j:LGp/e;

    invoke-static {v0}, LGp/e;->c(LGp/e;)Z

    move-result v2

    if-nez v2, :cond_19

    iget-object v2, p0, LGp/e$b;->f:LGp/e$a;

    if-nez v2, :cond_18

    iget-boolean v2, p0, LGp/e$b;->e:Z

    if-eqz v2, :cond_19

    :cond_18
    return-object v1

    :cond_19
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iget-object v3, p0, LGp/e$b;->a:[J

    invoke-virtual {v3}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v3

    move-object v9, v3

    check-cast v9, [J

    const/4 v3, 0x0

    :goto_28
    const/4 v4, 0x2

    if-ge v3, v4, :cond_54

    :try_start_2b
    invoke-virtual {v0}, LGp/e;->d0()LMp/b;

    move-result-object v4

    iget-object v5, p0, LGp/e$b;->b:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/io/File;

    invoke-interface {v4, v5}, LMp/b;->e(Ljava/io/File;)Lokio/Source;

    move-result-object v4

    invoke-static {v0}, LGp/e;->c(LGp/e;)Z

    move-result v5

    if-eqz v5, :cond_42

    goto :goto_4e

    :cond_42
    iget v5, p0, LGp/e$b;->g:I

    add-int/lit8 v5, v5, 0x1

    iput v5, p0, LGp/e$b;->g:I

    new-instance v5, LGp/f;

    invoke-direct {v5, p0, v4, v4}, LGp/f;-><init>(LGp/e$b;Lokio/Source;Lokio/Source;)V

    move-object v4, v5

    :goto_4e
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_28

    :cond_54
    new-instance v10, LGp/e$c;

    iget-object v4, p0, LGp/e$b;->j:LGp/e;

    iget-object v5, p0, LGp/e$b;->i:Ljava/lang/String;

    iget-wide v6, p0, LGp/e$b;->h:J

    move-object v3, v10

    move-object v8, v2

    invoke-direct/range {v3 .. v9}, LGp/e$c;-><init>(LGp/e;Ljava/lang/String;JLjava/util/ArrayList;[J)V
    :try_end_61
    .catch Ljava/io/FileNotFoundException; {:try_start_2b .. :try_end_61} :catch_62

    return-object v10

    :catch_62
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_66
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_76

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lokio/Source;

    invoke-static {v3}, LEp/b;->e(Ljava/io/Closeable;)V

    goto :goto_66

    :cond_76
    :try_start_76
    invoke-virtual {v0, p0}, LGp/e;->d1(LGp/e$b;)V
    :try_end_79
    .catch Ljava/io/IOException; {:try_start_76 .. :try_end_79} :catch_79

    :catch_79
    return-object v1
.end method

.method public final q(Lokio/BufferedSink;)V
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, LGp/e$b;->a:[J

    array-length v1, v0

    const/4 v2, 0x0

    :goto_4
    if-ge v2, v1, :cond_14

    aget-wide v3, v0, v2

    const/16 v5, 0x20

    invoke-interface {p1, v5}, Lokio/BufferedSink;->writeByte(I)Lokio/BufferedSink;

    move-result-object v5

    invoke-interface {v5, v3, v4}, Lokio/BufferedSink;->writeDecimalLong(J)Lokio/BufferedSink;

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_14
    return-void
.end method
