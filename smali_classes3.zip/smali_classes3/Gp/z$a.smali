.class final Lgp/z$a;
.super Lkotlin/jvm/internal/p;
.source "MemberDeserializer.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lgp/z;->d(LUo/p;ILgp/c;)Lvo/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "Lvo/c;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/z;

.field final synthetic b:LUo/p;

.field final synthetic c:Lgp/c;


# direct methods
.method constructor <init>(Lgp/z;LUo/p;Lgp/c;)V
    .registers 4

    iput-object p1, p0, Lgp/z$a;->a:Lgp/z;

    iput-object p2, p0, Lgp/z$a;->b:LUo/p;

    iput-object p3, p0, Lgp/z$a;->c:Lgp/c;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, Lgp/z$a;->a:Lgp/z;

    invoke-static {v0}, Lgp/z;->b(Lgp/z;)Lgp/n;

    move-result-object v1

    invoke-virtual {v1}, Lgp/n;->e()Luo/k;

    move-result-object v1

    invoke-static {v0, v1}, Lgp/z;->a(Lgp/z;Luo/k;)Lgp/G;

    move-result-object v1

    if-eqz v1, :cond_2b

    invoke-static {v0}, Lgp/z;->b(Lgp/z;)Lgp/n;

    move-result-object v0

    invoke-virtual {v0}, Lgp/n;->c()Lgp/l;

    move-result-object v0

    invoke-virtual {v0}, Lgp/l;->d()Lgp/d;

    move-result-object v0

    iget-object v2, p0, Lgp/z$a;->b:LUo/p;

    iget-object v3, p0, Lgp/z$a;->c:Lgp/c;

    invoke-interface {v0, v1, v2, v3}, Lgp/g;->b(Lgp/G;LUo/p;Lgp/c;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    goto :goto_2c

    :cond_2b
    const/4 v0, 0x0

    :goto_2c
    if-nez v0, :cond_30

    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_30
    return-object v0
.end method
