.class public interface abstract Lgp/k;
.super Ljava/lang/Object;
.source "ContractDeserializer.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgp/k$a;
    }
.end annotation


# virtual methods
.method public abstract a(LOo/h;Lip/m;LQo/g;Lgp/K;)V
.end method
