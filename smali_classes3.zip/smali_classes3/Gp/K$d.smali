.class final synthetic Lgp/K$d;
.super Lkotlin/jvm/internal/l;
.source "TypeDeserializer.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lgp/K;->k(Lgp/K;LOo/p;I)Luo/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/l;",
        "Leo/l<",
        "LTo/b;",
        "LTo/b;",
        ">;"
    }
.end annotation


# static fields
.field public static final j:Lgp/K$d;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lgp/K$d;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/l;-><init>(I)V

    sput-object v0, Lgp/K$d;->j:Lgp/K$d;

    return-void
.end method


# virtual methods
.method public final getName()Ljava/lang/String;
    .registers 2

    const-string v0, "getOuterClassId"

    return-object v0
.end method

.method public final getOwner()Llo/f;
    .registers 2

    const-class v0, LTo/b;

    invoke-static {v0}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v0

    return-object v0
.end method

.method public final getSignature()Ljava/lang/String;
    .registers 2

    const-string v0, "getOuterClassId()Lorg/jetbrains/kotlin/name/ClassId;"

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LTo/b;

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LTo/b;->g()LTo/b;

    move-result-object p1

    return-object p1
.end method
