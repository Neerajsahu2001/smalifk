.class public final Lgp/f;
.super Ljava/lang/Object;
.source "AnnotationDeserializer.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgp/f$a;
    }
.end annotation


# instance fields
.field private final a:Luo/B;

.field private final b:Luo/D;


# direct methods
.method public constructor <init>(Luo/B;Luo/D;)V
    .registers 4

    const-string v0, "module"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "notFoundClasses"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lgp/f;->a:Luo/B;

    iput-object p2, p0, Lgp/f;->b:Luo/D;

    return-void
.end method

.method private final b(LYo/g;Lkp/E;LOo/a$b$c;)Z
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LYo/g<",
            "*>;",
            "Lkp/E;",
            "LOo/a$b$c;",
            ")Z"
        }
    .end annotation

    invoke-virtual {p3}, LOo/a$b$c;->H()LOo/a$b$c$c;

    move-result-object v0

    if-nez v0, :cond_8

    const/4 v0, -0x1

    goto :goto_10

    :cond_8
    sget-object v1, Lgp/f$a;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    :goto_10
    const/16 v1, 0xa

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_a4

    const/16 v1, 0xd

    iget-object v4, p0, Lgp/f;->a:Luo/B;

    if-eq v0, v1, :cond_26

    invoke-virtual {p1, v4}, LYo/g;->a(Luo/B;)Lkp/E;

    move-result-object p1

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    goto/16 :goto_bd

    :cond_26
    instance-of v0, p1, LYo/b;

    if-eqz v0, :cond_8c

    move-object v0, p1

    check-cast v0, LYo/b;

    invoke-virtual {v0}, LYo/g;->b()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-virtual {p3}, LOo/a$b$c;->y()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ne v1, v5, :cond_8c

    invoke-interface {v4}, Luo/B;->m()Lro/j;

    move-result-object p1

    invoke-virtual {p1, p2}, Lro/j;->j(Lkp/E;)Lkp/E;

    move-result-object p1

    invoke-virtual {v0}, LYo/g;->b()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/Collection;

    invoke-static {p2}, Lkotlin/collections/q;->u(Ljava/util/Collection;)Lko/e;

    move-result-object p2

    instance-of v1, p2, Ljava/util/Collection;

    if-eqz v1, :cond_62

    move-object v1, p2

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_62

    :cond_60
    :goto_60
    const/4 v2, 0x1

    goto :goto_bd

    :cond_62
    invoke-virtual {p2}, Lko/c;->i()Lko/d;

    move-result-object p2

    :cond_66
    invoke-virtual {p2}, Lko/d;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_60

    invoke-virtual {p2}, Lkotlin/collections/G;->a()I

    move-result v1

    invoke-virtual {v0}, LYo/g;->b()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/List;

    invoke-interface {v4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LYo/g;

    invoke-virtual {p3, v1}, LOo/a$b$c;->x(I)LOo/a$b$c;

    move-result-object v1

    const-string v5, "value.getArrayElement(i)"

    invoke-static {v1, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v4, p1, v1}, Lgp/f;->b(LYo/g;Lkp/E;LOo/a$b$c;)Z

    move-result v1

    if-nez v1, :cond_66

    goto :goto_bd

    :cond_8c
    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Deserialized ArrayValue should have the same number of elements as the original array value: "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_a4
    invoke-virtual {p2}, Lkp/E;->N0()Lkp/e0;

    move-result-object p1

    invoke-interface {p1}, Lkp/e0;->n()Luo/h;

    move-result-object p1

    instance-of p2, p1, Luo/e;

    if-eqz p2, :cond_b3

    check-cast p1, Luo/e;

    goto :goto_b4

    :cond_b3
    const/4 p1, 0x0

    :goto_b4
    if-eqz p1, :cond_60

    invoke-static {p1}, Lro/j;->c0(Luo/e;)Z

    move-result p1

    if-eqz p1, :cond_bd

    goto :goto_60

    :cond_bd
    :goto_bd
    return v2
.end method


# virtual methods
.method public final a(LOo/a;LQo/c;)Lvo/d;
    .registers 13

    const-string v0, "proto"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LOo/a;->p()I

    move-result v0

    invoke-static {p2, v0}, Lcom/google/android/gms/internal/ads/zzcgw;->b(LQo/c;I)LTo/b;

    move-result-object v0

    iget-object v1, p0, Lgp/f;->a:Luo/B;

    iget-object v2, p0, Lgp/f;->b:Luo/D;

    invoke-static {v1, v0, v2}, Luo/u;->c(Luo/B;LTo/b;Luo/D;)Luo/e;

    move-result-object v0

    invoke-static {}, Lkotlin/collections/J;->d()Ljava/util/Map;

    move-result-object v1

    invoke-virtual {p1}, LOo/a;->m()I

    move-result v2

    if-eqz v2, :cond_10c

    invoke-static {v0}, Lmp/k;->k(Luo/k;)Z

    move-result v2

    if-nez v2, :cond_10c

    invoke-static {v0}, LWo/i;->q(Luo/k;)Z

    move-result v2

    if-eqz v2, :cond_10c

    invoke-interface {v0}, Luo/e;->k()Ljava/util/Collection;

    move-result-object v2

    const-string v3, "annotationClass.constructors"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/q;->P(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Luo/d;

    if-eqz v2, :cond_10c

    invoke-interface {v2}, Luo/a;->e()Ljava/util/List;

    move-result-object v1

    const-string v2, "constructor.valueParameters"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v2

    invoke-static {v2}, Lkotlin/collections/J;->g(I)I

    move-result v2

    const/16 v3, 0x10

    if-ge v2, v3, :cond_5c

    const/16 v2, 0x10

    :cond_5c
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_65
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_7a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Luo/b0;

    invoke-interface {v4}, Luo/k;->getName()LTo/f;

    move-result-object v4

    invoke-interface {v3, v4, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_65

    :cond_7a
    invoke-virtual {p1}, LOo/a;->n()Ljava/util/List;

    move-result-object p1

    const-string v1, "proto.argumentList"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_8e
    :goto_8e
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_108

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LOo/a$b;

    const-string v4, "it"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, LOo/a$b;->m()I

    move-result v4

    invoke-static {p2, v4}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Luo/b0;

    const/4 v5, 0x0

    if-nez v4, :cond_b1

    goto :goto_102

    :cond_b1
    new-instance v6, LUn/j;

    invoke-virtual {v2}, LOo/a$b;->m()I

    move-result v7

    invoke-static {p2, v7}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object v7

    invoke-interface {v4}, Luo/a0;->getType()Lkp/E;

    move-result-object v4

    const-string v8, "parameter.type"

    invoke-static {v4, v8}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, LOo/a$b;->n()LOo/a$b$c;

    move-result-object v2

    const-string v8, "proto.value"

    invoke-static {v2, v8}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v4, v2, p2}, Lgp/f;->c(Lkp/E;LOo/a$b$c;LQo/c;)LYo/g;

    move-result-object v8

    invoke-direct {p0, v8, v4, v2}, Lgp/f;->b(LYo/g;Lkp/E;LOo/a$b$c;)Z

    move-result v9

    if-eqz v9, :cond_d8

    move-object v5, v8

    :cond_d8
    if-nez v5, :cond_fe

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "Unexpected argument value: actual type "

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, LOo/a$b$c;->H()LOo/a$b$c$c;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " != expected type "

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v4, "message"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v5, LYo/k$a;

    invoke-direct {v5, v2}, LYo/k$a;-><init>(Ljava/lang/String;)V

    :cond_fe
    invoke-direct {v6, v7, v5}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v5, v6

    :goto_102
    if-eqz v5, :cond_8e

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_8e

    :cond_108
    invoke-static {v1}, Lkotlin/collections/J;->k(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v1

    :cond_10c
    new-instance p1, Lvo/d;

    invoke-interface {v0}, Luo/e;->q()Lkp/M;

    move-result-object p2

    sget-object v0, Luo/S;->a:Luo/S;

    invoke-direct {p1, p2, v1, v0}, Lvo/d;-><init>(Lkp/M;Ljava/util/Map;Luo/S;)V

    return-object p1
.end method

.method public final c(Lkp/E;LOo/a$b$c;LQo/c;)LYo/g;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkp/E;",
            "LOo/a$b$c;",
            "LQo/c;",
            ")",
            "LYo/g<",
            "*>;"
        }
    .end annotation

    const-string v0, "nameResolver"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LQo/b;->M:LQo/b$a;

    invoke-virtual {p2}, LOo/a$b$c;->D()I

    move-result v1

    invoke-virtual {v0, v1}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {p2}, LOo/a$b$c;->H()LOo/a$b$c$c;

    move-result-object v1

    if-nez v1, :cond_1b

    const/4 v1, -0x1

    goto :goto_23

    :cond_1b
    sget-object v2, Lgp/f$a;->a:[I

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v1, v2, v1

    :goto_23
    packed-switch v1, :pswitch_data_164

    new-instance p3, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Unsupported annotation argument type: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, LOo/a$b$c;->H()LOo/a$b$c$c;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " (expected "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p3, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p3

    :pswitch_4f
    invoke-virtual {p2}, LOo/a$b$c;->y()Ljava/util/List;

    move-result-object p2

    const-string v0, "value.arrayElementList"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p2}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_67
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8f

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LOo/a$b$c;

    iget-object v2, p0, Lgp/f;->a:Luo/B;

    invoke-interface {v2}, Luo/B;->m()Lro/j;

    move-result-object v2

    invoke-virtual {v2}, Lro/j;->h()Lkp/M;

    move-result-object v2

    const-string v3, "builtIns.anyType"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "it"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v2, v1, p3}, Lgp/f;->c(Lkp/E;LOo/a$b$c;LQo/c;)LYo/g;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_67

    :cond_8f
    new-instance p2, Lgp/p;

    invoke-direct {p2, v0, p1}, Lgp/p;-><init>(Ljava/util/ArrayList;Lkp/E;)V

    goto/16 :goto_163

    :pswitch_96
    new-instance p1, LYo/a;

    invoke-virtual {p2}, LOo/a$b$c;->v()LOo/a;

    move-result-object p2

    const-string v0, "value.annotation"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p2, p3}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object p2

    invoke-direct {p1, p2}, LYo/g;-><init>(Ljava/lang/Object;)V

    :goto_a8
    move-object p2, p1

    goto/16 :goto_163

    :pswitch_ab
    new-instance p1, LYo/j;

    invoke-virtual {p2}, LOo/a$b$c;->z()I

    move-result v0

    invoke-static {p3, v0}, Lcom/google/android/gms/internal/ads/zzcgw;->b(LQo/c;I)LTo/b;

    move-result-object v0

    invoke-virtual {p2}, LOo/a$b$c;->C()I

    move-result p2

    invoke-static {p3, p2}, Lcom/google/android/gms/internal/ads/zzcgw;->c(LQo/c;I)LTo/f;

    move-result-object p2

    invoke-direct {p1, v0, p2}, LYo/j;-><init>(LTo/b;LTo/f;)V

    goto :goto_a8

    :pswitch_c1
    new-instance p1, LYo/r;

    invoke-virtual {p2}, LOo/a$b$c;->z()I

    move-result v0

    invoke-static {p3, v0}, Lcom/google/android/gms/internal/ads/zzcgw;->b(LQo/c;I)LTo/b;

    move-result-object p3

    invoke-virtual {p2}, LOo/a$b$c;->w()I

    move-result p2

    invoke-direct {p1, p3, p2}, LYo/r;-><init>(LTo/b;I)V

    goto :goto_a8

    :pswitch_d3
    new-instance p1, LYo/v;

    invoke-virtual {p2}, LOo/a$b$c;->G()I

    move-result p2

    invoke-interface {p3, p2}, LQo/c;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, LYo/g;-><init>(Ljava/lang/Object;)V

    goto :goto_a8

    :pswitch_e1
    new-instance p1, LYo/c;

    invoke-virtual {p2}, LOo/a$b$c;->F()J

    move-result-wide p2

    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-eqz v2, :cond_ef

    const/4 p2, 0x1

    goto :goto_f0

    :cond_ef
    const/4 p2, 0x0

    :goto_f0
    invoke-direct {p1, p2}, LYo/c;-><init>(Z)V

    goto :goto_a8

    :pswitch_f4
    new-instance p1, LYo/i;

    invoke-virtual {p2}, LOo/a$b$c;->B()D

    move-result-wide p2

    invoke-direct {p1, p2, p3}, LYo/i;-><init>(D)V

    goto :goto_a8

    :pswitch_fe
    new-instance p1, LYo/l;

    invoke-virtual {p2}, LOo/a$b$c;->E()F

    move-result p2

    invoke-direct {p1, p2}, LYo/l;-><init>(F)V

    goto :goto_a8

    :pswitch_108
    invoke-virtual {p2}, LOo/a$b$c;->F()J

    move-result-wide p1

    if-eqz v0, :cond_115

    new-instance p3, LYo/y;

    invoke-direct {p3, p1, p2}, LYo/y;-><init>(J)V

    :goto_113
    move-object p2, p3

    goto :goto_163

    :cond_115
    new-instance p3, LYo/s;

    invoke-direct {p3, p1, p2}, LYo/s;-><init>(J)V

    goto :goto_113

    :pswitch_11b
    invoke-virtual {p2}, LOo/a$b$c;->F()J

    move-result-wide p1

    long-to-int p2, p1

    if-eqz v0, :cond_128

    new-instance p1, LYo/x;

    invoke-direct {p1, p2}, LYo/x;-><init>(I)V

    goto :goto_a8

    :cond_128
    new-instance p1, LYo/m;

    invoke-direct {p1, p2}, LYo/m;-><init>(I)V

    goto/16 :goto_a8

    :pswitch_12f
    invoke-virtual {p2}, LOo/a$b$c;->F()J

    move-result-wide p1

    long-to-int p2, p1

    int-to-short p1, p2

    if-eqz v0, :cond_13d

    new-instance p2, LYo/z;

    invoke-direct {p2, p1}, LYo/z;-><init>(S)V

    goto :goto_163

    :cond_13d
    new-instance p2, LYo/u;

    invoke-direct {p2, p1}, LYo/u;-><init>(S)V

    goto :goto_163

    :pswitch_143
    new-instance p1, LYo/e;

    invoke-virtual {p2}, LOo/a$b$c;->F()J

    move-result-wide p2

    long-to-int p3, p2

    int-to-char p2, p3

    invoke-direct {p1, p2}, LYo/e;-><init>(C)V

    goto/16 :goto_a8

    :pswitch_150
    invoke-virtual {p2}, LOo/a$b$c;->F()J

    move-result-wide p1

    long-to-int p2, p1

    int-to-byte p1, p2

    if-eqz v0, :cond_15e

    new-instance p2, LYo/w;

    invoke-direct {p2, p1}, LYo/w;-><init>(B)V

    goto :goto_163

    :cond_15e
    new-instance p2, LYo/d;

    invoke-direct {p2, p1}, LYo/d;-><init>(B)V

    :goto_163
    return-object p2

    :pswitch_data_164
    .packed-switch 0x1
        :pswitch_150
        :pswitch_143
        :pswitch_12f
        :pswitch_11b
        :pswitch_108
        :pswitch_fe
        :pswitch_f4
        :pswitch_e1
        :pswitch_d3
        :pswitch_c1
        :pswitch_ab
        :pswitch_96
        :pswitch_4f
    .end packed-switch
.end method
