.class public final LGp/d$b;
.super Ljava/lang/Object;
.source "CacheStrategy.kt"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = LGp/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private a:Ljava/util/Date;

.field private b:Ljava/lang/String;

.field private c:Ljava/util/Date;

.field private d:Ljava/lang/String;

.field private e:Ljava/util/Date;

.field private f:J

.field private g:J

.field private h:Ljava/lang/String;

.field private i:I

.field private final j:J

.field private final k:Lokhttp3/Request;

.field private final l:Lokhttp3/Response;


# direct methods
.method public constructor <init>(JLokhttp3/Request;Lokhttp3/Response;)V
    .registers 9

    const-string v0, "request"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LGp/d$b;->j:J

    iput-object p3, p0, LGp/d$b;->k:Lokhttp3/Request;

    iput-object p4, p0, LGp/d$b;->l:Lokhttp3/Response;

    const/4 p1, -0x1

    iput p1, p0, LGp/d$b;->i:I

    if-eqz p4, :cond_80

    invoke-virtual {p4}, Lokhttp3/Response;->sentRequestAtMillis()J

    move-result-wide p2

    iput-wide p2, p0, LGp/d$b;->f:J

    invoke-virtual {p4}, Lokhttp3/Response;->receivedResponseAtMillis()J

    move-result-wide p2

    iput-wide p2, p0, LGp/d$b;->g:J

    invoke-virtual {p4}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object p2

    invoke-virtual {p2}, Lokhttp3/Headers;->size()I

    move-result p3

    const/4 p4, 0x0

    :goto_28
    if-ge p4, p3, :cond_80

    invoke-virtual {p2, p4}, Lokhttp3/Headers;->name(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, p4}, Lokhttp3/Headers;->value(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "Date"

    const/4 v3, 0x1

    invoke-static {v0, v2, v3}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_44

    invoke-static {v1}, LJp/c;->a(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    iput-object v0, p0, LGp/d$b;->a:Ljava/util/Date;

    iput-object v1, p0, LGp/d$b;->b:Ljava/lang/String;

    goto :goto_7d

    :cond_44
    const-string v2, "Expires"

    invoke-static {v0, v2, v3}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_53

    invoke-static {v1}, LJp/c;->a(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    iput-object v0, p0, LGp/d$b;->e:Ljava/util/Date;

    goto :goto_7d

    :cond_53
    const-string v2, "Last-Modified"

    invoke-static {v0, v2, v3}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_64

    invoke-static {v1}, LJp/c;->a(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    iput-object v0, p0, LGp/d$b;->c:Ljava/util/Date;

    iput-object v1, p0, LGp/d$b;->d:Ljava/lang/String;

    goto :goto_7d

    :cond_64
    const-string v2, "ETag"

    invoke-static {v0, v2, v3}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_6f

    iput-object v1, p0, LGp/d$b;->h:Ljava/lang/String;

    goto :goto_7d

    :cond_6f
    const-string v2, "Age"

    invoke-static {v0, v2, v3}, Lvp/k;->x(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_7d

    invoke-static {p1, v1}, LEp/b;->D(ILjava/lang/String;)I

    move-result v0

    iput v0, p0, LGp/d$b;->i:I

    :cond_7d
    :goto_7d
    add-int/lit8 p4, p4, 0x1

    goto :goto_28

    :cond_80
    return-void
.end method


# virtual methods
.method public final a()LGp/d;
    .registers 23

    move-object/from16 v0, p0

    iget-object v1, v0, LGp/d$b;->k:Lokhttp3/Request;

    const/4 v2, 0x0

    iget-object v3, v0, LGp/d$b;->l:Lokhttp3/Response;

    if-nez v3, :cond_10

    new-instance v3, LGp/d;

    invoke-direct {v3, v1, v2}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    goto/16 :goto_1cd

    :cond_10
    invoke-virtual {v1}, Lokhttp3/Request;->isHttps()Z

    move-result v4

    if-eqz v4, :cond_23

    invoke-virtual {v3}, Lokhttp3/Response;->handshake()Lokhttp3/Handshake;

    move-result-object v4

    if-nez v4, :cond_23

    new-instance v3, LGp/d;

    invoke-direct {v3, v1, v2}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    goto/16 :goto_1cd

    :cond_23
    invoke-static {v1, v3}, LGp/d$a;->a(Lokhttp3/Request;Lokhttp3/Response;)Z

    move-result v4

    if-nez v4, :cond_30

    new-instance v3, LGp/d;

    invoke-direct {v3, v1, v2}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    goto/16 :goto_1cd

    :cond_30
    invoke-virtual {v1}, Lokhttp3/Request;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v4

    invoke-virtual {v4}, Lokhttp3/CacheControl;->noCache()Z

    move-result v5

    if-nez v5, :cond_1c8

    const-string v5, "If-Modified-Since"

    invoke-virtual {v1, v5}, Lokhttp3/Request;->header(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_1c8

    const-string v6, "If-None-Match"

    invoke-virtual {v1, v6}, Lokhttp3/Request;->header(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_4c

    goto/16 :goto_1c8

    :cond_4c
    invoke-virtual {v3}, Lokhttp3/Response;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v7

    iget-wide v8, v0, LGp/d$b;->g:J

    iget-object v10, v0, LGp/d$b;->a:Ljava/util/Date;

    const-wide/16 v11, 0x0

    if-eqz v10, :cond_63

    invoke-virtual {v10}, Ljava/util/Date;->getTime()J

    move-result-wide v13

    sub-long v13, v8, v13

    invoke-static {v11, v12, v13, v14}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v13

    goto :goto_64

    :cond_63
    move-wide v13, v11

    :goto_64
    iget v15, v0, LGp/d$b;->i:I

    const/4 v2, -0x1

    if-eq v15, v2, :cond_76

    sget-object v11, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    move-object v12, v3

    int-to-long v2, v15

    invoke-virtual {v11, v2, v3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v2

    invoke-static {v13, v14, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v13

    goto :goto_77

    :cond_76
    move-object v12, v3

    :goto_77
    iget-wide v2, v0, LGp/d$b;->f:J

    sub-long v18, v8, v2

    move-wide/from16 v20, v2

    iget-wide v2, v0, LGp/d$b;->j:J

    sub-long/2addr v2, v8

    add-long v13, v13, v18

    add-long/2addr v13, v2

    invoke-virtual {v12}, Lokhttp3/Response;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/CacheControl;->maxAgeSeconds()I

    move-result v3

    iget-object v11, v0, LGp/d$b;->c:Ljava/util/Date;

    iget-object v15, v0, LGp/d$b;->e:Ljava/util/Date;

    move-object/from16 v18, v5

    const/4 v5, -0x1

    if-eq v3, v5, :cond_a0

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v2}, Lokhttp3/CacheControl;->maxAgeSeconds()I

    move-result v2

    int-to-long v8, v2

    invoke-virtual {v3, v8, v9}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v2

    goto :goto_df

    :cond_a0
    if-eqz v15, :cond_b4

    if-eqz v10, :cond_a8

    invoke-virtual {v10}, Ljava/util/Date;->getTime()J

    move-result-wide v8

    :cond_a8
    invoke-virtual {v15}, Ljava/util/Date;->getTime()J

    move-result-wide v2

    sub-long/2addr v2, v8

    const-wide/16 v8, 0x0

    cmp-long v5, v2, v8

    if-lez v5, :cond_dd

    goto :goto_df

    :cond_b4
    if-eqz v11, :cond_dd

    invoke-virtual {v12}, Lokhttp3/Response;->request()Lokhttp3/Request;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/HttpUrl;->query()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_dd

    if-eqz v10, :cond_cb

    invoke-virtual {v10}, Ljava/util/Date;->getTime()J

    move-result-wide v2

    goto :goto_cd

    :cond_cb
    move-wide/from16 v2, v20

    :goto_cd
    invoke-virtual {v11}, Ljava/util/Date;->getTime()J

    move-result-wide v8

    sub-long/2addr v2, v8

    const-wide/16 v8, 0x0

    cmp-long v5, v2, v8

    if-lez v5, :cond_dd

    const/16 v5, 0xa

    int-to-long v8, v5

    div-long/2addr v2, v8

    goto :goto_df

    :cond_dd
    const-wide/16 v2, 0x0

    :goto_df
    invoke-virtual {v4}, Lokhttp3/CacheControl;->maxAgeSeconds()I

    move-result v5

    const/4 v8, -0x1

    if-eq v5, v8, :cond_f5

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v4}, Lokhttp3/CacheControl;->maxAgeSeconds()I

    move-result v9

    int-to-long v8, v9

    invoke-virtual {v5, v8, v9}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v8

    invoke-static {v2, v3, v8, v9}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    :cond_f5
    invoke-virtual {v4}, Lokhttp3/CacheControl;->minFreshSeconds()I

    move-result v5

    const/4 v8, -0x1

    if-eq v5, v8, :cond_108

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v4}, Lokhttp3/CacheControl;->minFreshSeconds()I

    move-result v9

    int-to-long v8, v9

    invoke-virtual {v5, v8, v9}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v8

    goto :goto_10a

    :cond_108
    const-wide/16 v8, 0x0

    :goto_10a
    invoke-virtual {v7}, Lokhttp3/CacheControl;->mustRevalidate()Z

    move-result v5

    if-nez v5, :cond_12e

    invoke-virtual {v4}, Lokhttp3/CacheControl;->maxStaleSeconds()I

    move-result v5

    move-object/from16 v19, v6

    const/4 v6, -0x1

    if-eq v5, v6, :cond_12a

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v4}, Lokhttp3/CacheControl;->maxStaleSeconds()I

    move-result v4

    move-object v6, v10

    move-object/from16 v20, v11

    int-to-long v10, v4

    invoke-virtual {v5, v10, v11}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v4

    move-wide/from16 v16, v4

    goto :goto_133

    :cond_12a
    :goto_12a
    move-object v6, v10

    move-object/from16 v20, v11

    goto :goto_131

    :cond_12e
    move-object/from16 v19, v6

    goto :goto_12a

    :goto_131
    const-wide/16 v16, 0x0

    :goto_133
    invoke-virtual {v7}, Lokhttp3/CacheControl;->noCache()Z

    move-result v4

    if-nez v4, :cond_180

    add-long/2addr v8, v13

    add-long v16, v2, v16

    cmp-long v4, v8, v16

    if-gez v4, :cond_180

    instance-of v4, v12, Lokhttp3/Response$Builder;

    if-nez v4, :cond_149

    invoke-virtual {v12}, Lokhttp3/Response;->newBuilder()Lokhttp3/Response$Builder;

    move-result-object v4

    goto :goto_150

    :cond_149
    move-object v4, v12

    check-cast v4, Lokhttp3/Response$Builder;

    invoke-static {v4}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->newBuilder(Lokhttp3/Response$Builder;)Lokhttp3/Response$Builder;

    move-result-object v4

    :goto_150
    const-string v5, "Warning"

    cmp-long v6, v8, v2

    if-ltz v6, :cond_15b

    const-string v2, "110 HttpURLConnection \"Response is stale\""

    invoke-virtual {v4, v5, v2}, Lokhttp3/Response$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Response$Builder;

    :cond_15b
    const-wide/32 v2, 0x5265c00

    cmp-long v6, v13, v2

    if-lez v6, :cond_174

    invoke-virtual {v12}, Lokhttp3/Response;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/CacheControl;->maxAgeSeconds()I

    move-result v2

    const/4 v3, -0x1

    if-ne v2, v3, :cond_174

    if-nez v15, :cond_174

    const-string v2, "113 HttpURLConnection \"Heuristic expiration\""

    invoke-virtual {v4, v5, v2}, Lokhttp3/Response$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Response$Builder;

    :cond_174
    new-instance v3, LGp/d;

    invoke-virtual {v4}, Lokhttp3/Response$Builder;->build()Lokhttp3/Response;

    move-result-object v2

    const/4 v4, 0x0

    invoke-direct {v3, v4, v2}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    move-object v2, v4

    goto :goto_1cd

    :cond_180
    iget-object v2, v0, LGp/d$b;->h:Ljava/lang/String;

    if-eqz v2, :cond_187

    move-object/from16 v5, v19

    goto :goto_193

    :cond_187
    if-eqz v20, :cond_18e

    iget-object v2, v0, LGp/d$b;->d:Ljava/lang/String;

    :goto_18b
    move-object/from16 v5, v18

    goto :goto_193

    :cond_18e
    if-eqz v6, :cond_1c1

    iget-object v2, v0, LGp/d$b;->b:Ljava/lang/String;

    goto :goto_18b

    :goto_193
    invoke-virtual {v1}, Lokhttp3/Request;->headers()Lokhttp3/Headers;

    move-result-object v3

    invoke-virtual {v3}, Lokhttp3/Headers;->newBuilder()Lokhttp3/Headers$Builder;

    move-result-object v3

    invoke-static {v2}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v3, v5, v2}, Lokhttp3/Headers$Builder;->addLenient$okhttp(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Headers$Builder;

    invoke-virtual {v1}, Lokhttp3/Request;->newBuilder()Lokhttp3/Request$Builder;

    move-result-object v2

    invoke-virtual {v3}, Lokhttp3/Headers$Builder;->build()Lokhttp3/Headers;

    move-result-object v3

    invoke-virtual {v2, v3}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object v2

    instance-of v3, v2, Lokhttp3/Request$Builder;

    if-nez v3, :cond_1b6

    invoke-virtual {v2}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v2

    goto :goto_1ba

    :cond_1b6
    invoke-static {v2}, Lcom/newrelic/agent/android/instrumentation/okhttp3/OkHttp3Instrumentation;->build(Lokhttp3/Request$Builder;)Lokhttp3/Request;

    move-result-object v2

    :goto_1ba
    new-instance v3, LGp/d;

    invoke-direct {v3, v2, v12}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    const/4 v2, 0x0

    goto :goto_1cd

    :cond_1c1
    new-instance v3, LGp/d;

    const/4 v2, 0x0

    invoke-direct {v3, v1, v2}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    goto :goto_1cd

    :cond_1c8
    :goto_1c8
    new-instance v3, LGp/d;

    invoke-direct {v3, v1, v2}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    :goto_1cd
    invoke-virtual {v3}, LGp/d;->b()Lokhttp3/Request;

    move-result-object v4

    if-eqz v4, :cond_1e3

    invoke-virtual {v1}, Lokhttp3/Request;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/CacheControl;->onlyIfCached()Z

    move-result v1

    if-eqz v1, :cond_1e3

    new-instance v1, LGp/d;

    invoke-direct {v1, v2, v2}, LGp/d;-><init>(Lokhttp3/Request;Lokhttp3/Response;)V

    return-object v1

    :cond_1e3
    return-object v3
.end method
