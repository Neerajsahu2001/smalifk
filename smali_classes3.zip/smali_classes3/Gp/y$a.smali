.class public final Lgp/y$a;
.super Ljava/lang/Object;
.source "LocalClassifierTypeSettings.kt"

# interfaces
.implements Lgp/y;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgp/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:Lgp/y$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lgp/y$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lgp/y$a;->a:Lgp/y$a;

    return-void
.end method
