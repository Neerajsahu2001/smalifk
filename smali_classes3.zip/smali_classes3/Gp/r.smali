.class public abstract Lgp/r;
.super Lxo/I;
.source "DeserializedPackageFragment.kt"


# direct methods
.method public constructor <init>(LTo/c;Ljp/n;Luo/B;)V
    .registers 5

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "storageManager"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "module"

    invoke-static {p3, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p3, p1}, Lxo/I;-><init>(Luo/B;LTo/c;)V

    return-void
.end method


# virtual methods
.method public abstract I0()Lgp/F;
.end method
