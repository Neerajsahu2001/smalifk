.class final LGp/e$a$a;
.super Lkotlin/jvm/internal/p;
.source "DiskLruCache.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LGp/e$a;->f(I)Lokio/Sink;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Ljava/io/IOException;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LGp/e$a;


# direct methods
.method constructor <init>(LGp/e$a;)V
    .registers 2

    iput-object p1, p0, LGp/e$a$a;->a:LGp/e$a;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/io/IOException;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LGp/e$a$a;->a:LGp/e$a;

    iget-object p1, p1, LGp/e$a;->d:LGp/e;

    monitor-enter p1

    :try_start_c
    iget-object v0, p0, LGp/e$a$a;->a:LGp/e$a;

    invoke-virtual {v0}, LGp/e$a;->c()V
    :try_end_11
    .catchall {:try_start_c .. :try_end_11} :catchall_15

    monitor-exit p1

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1

    :catchall_15
    move-exception v0

    monitor-exit p1

    throw v0
.end method
