.class final Lgp/K$c;
.super Lkotlin/jvm/internal/p;
.source "TypeDeserializer.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lgp/K;-><init>(Lgp/n;Lgp/K;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Ljava/lang/Integer;",
        "Luo/h;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/K;


# direct methods
.method constructor <init>(Lgp/K;)V
    .registers 2

    iput-object p1, p0, Lgp/K$c;->a:Lgp/K;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    iget-object v0, p0, Lgp/K$c;->a:Lgp/K;

    invoke-static {v0, p1}, Lgp/K;->b(Lgp/K;I)Luo/W;

    move-result-object p1

    return-object p1
.end method
