.class public interface abstract Lgp/y;
.super Ljava/lang/Object;
.source "LocalClassifierTypeSettings.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgp/y$a;
    }
.end annotation
