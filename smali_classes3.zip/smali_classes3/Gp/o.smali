.class final Lgp/o;
.super Lkotlin/jvm/internal/p;
.source "DeserializedArrayValue.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Luo/B;",
        "Lkp/E;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkp/E;


# direct methods
.method constructor <init>(Lkp/E;)V
    .registers 2

    iput-object p1, p0, Lgp/o;->a:Lkp/E;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Luo/B;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Lgp/o;->a:Lkp/E;

    return-object p1
.end method
