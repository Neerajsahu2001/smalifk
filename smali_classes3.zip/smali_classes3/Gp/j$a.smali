.class final Lgp/j$a;
.super Ljava/lang/Object;
.source "ClassDeserializer.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgp/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:LTo/b;

.field private final b:Lgp/h;


# direct methods
.method public constructor <init>(LTo/b;Lgp/h;)V
    .registers 4

    const-string v0, "classId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lgp/j$a;->a:LTo/b;

    iput-object p2, p0, Lgp/j$a;->b:Lgp/h;

    return-void
.end method


# virtual methods
.method public final a()Lgp/h;
    .registers 2

    iget-object v0, p0, Lgp/j$a;->b:Lgp/h;

    return-object v0
.end method

.method public final b()LTo/b;
    .registers 2

    iget-object v0, p0, Lgp/j$a;->a:LTo/b;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, Lgp/j$a;

    if-eqz v0, :cond_12

    check-cast p1, Lgp/j$a;

    iget-object p1, p1, Lgp/j$a;->a:LTo/b;

    iget-object v0, p0, Lgp/j$a;->a:LTo/b;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_12

    const/4 p1, 0x1

    goto :goto_13

    :cond_12
    const/4 p1, 0x0

    :goto_13
    return p1
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lgp/j$a;->a:LTo/b;

    invoke-virtual {v0}, LTo/b;->hashCode()I

    move-result v0

    return v0
.end method
