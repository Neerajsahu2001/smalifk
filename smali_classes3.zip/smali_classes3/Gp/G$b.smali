.class public final Lgp/G$b;
.super Lgp/G;
.source "ProtoContainer.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgp/G;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private final d:LTo/c;


# direct methods
.method public constructor <init>(LTo/c;LQo/c;LQo/g;Lip/h;)V
    .registers 6

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "typeTable"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2, p3, p4}, Lgp/G;-><init>(LQo/c;LQo/g;Luo/S;)V

    iput-object p1, p0, Lgp/G$b;->d:LTo/c;

    return-void
.end method


# virtual methods
.method public final a()LTo/c;
    .registers 2

    iget-object v0, p0, Lgp/G$b;->d:LTo/c;

    return-object v0
.end method
