.class public final Lgp/p;
.super LYo/b;
.source "DeserializedArrayValue.kt"


# instance fields
.field private final c:Lkp/E;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Lkp/E;)V
    .registers 4

    new-instance v0, Lgp/o;

    invoke-direct {v0, p2}, Lgp/o;-><init>(Lkp/E;)V

    invoke-direct {p0, p1, v0}, LYo/b;-><init>(Ljava/util/List;Leo/l;)V

    iput-object p2, p0, Lgp/p;->c:Lkp/E;

    return-void
.end method


# virtual methods
.method public final c()Lkp/E;
    .registers 2

    iget-object v0, p0, Lgp/p;->c:Lkp/E;

    return-object v0
.end method
