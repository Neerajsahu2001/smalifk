.class public final LGp/e$c;
.super Ljava/lang/Object;
.source "DiskLruCache.kt"

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LGp/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "c"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:J

.field private final c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lokio/Source;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic d:LGp/e;


# direct methods
.method public constructor <init>(LGp/e;Ljava/lang/String;JLjava/util/ArrayList;[J)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "lengths"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LGp/e$c;->d:LGp/e;

    iput-object p2, p0, LGp/e$c;->a:Ljava/lang/String;

    iput-wide p3, p0, LGp/e$c;->b:J

    iput-object p5, p0, LGp/e$c;->c:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final c()LGp/e$a;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, LGp/e$c;->a:Ljava/lang/String;

    iget-wide v1, p0, LGp/e$c;->b:J

    iget-object v3, p0, LGp/e$c;->d:LGp/e;

    invoke-virtual {v3, v1, v2, v0}, LGp/e;->T(JLjava/lang/String;)LGp/e$a;

    move-result-object v0

    return-object v0
.end method

.method public final close()V
    .registers 3

    iget-object v0, p0, LGp/e$c;->c:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lokio/Source;

    invoke-static {v1}, LEp/b;->e(Ljava/io/Closeable;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method public final e(I)Lokio/Source;
    .registers 3

    iget-object v0, p0, LGp/e$c;->c:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lokio/Source;

    return-object p1
.end method

.method public final g()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LGp/e$c;->a:Ljava/lang/String;

    return-object v0
.end method
