.class public interface abstract Lgp/x;
.super Ljava/lang/Object;
.source "KotlinMetadataFinder.kt"


# virtual methods
.method public abstract b(LTo/c;)Ljava/io/InputStream;
.end method
