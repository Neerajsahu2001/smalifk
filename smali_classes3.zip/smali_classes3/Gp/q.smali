.class public final Lgp/q;
.super Ljava/lang/Object;
.source "DeserializedClassDataFinder.kt"

# interfaces
.implements Lgp/i;


# instance fields
.field private final a:Luo/F;


# direct methods
.method public constructor <init>(Luo/F;)V
    .registers 3

    const-string v0, "packageFragmentProvider"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lgp/q;->a:Luo/F;

    return-void
.end method


# virtual methods
.method public final a(LTo/b;)Lgp/h;
    .registers 5

    const-string v0, "classId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LTo/b;->h()LTo/c;

    move-result-object v0

    const-string v1, "classId.packageFqName"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, Lgp/q;->a:Luo/F;

    invoke-static {v1, v0}, Lcom/facebook/soloader/m;->j(Luo/F;LTo/c;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_18
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_35

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Luo/E;

    instance-of v2, v1, Lgp/r;

    if-eqz v2, :cond_18

    check-cast v1, Lgp/r;

    invoke-virtual {v1}, Lgp/r;->I0()Lgp/F;

    move-result-object v1

    invoke-virtual {v1, p1}, Lgp/F;->a(LTo/b;)Lgp/h;

    move-result-object v1

    if-eqz v1, :cond_18

    return-object v1

    :cond_35
    const/4 p1, 0x0

    return-object p1
.end method
