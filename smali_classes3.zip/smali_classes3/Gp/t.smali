.class public abstract Lgp/t;
.super Lgp/r;
.source "DeserializedPackageFragmentImpl.kt"


# instance fields
.field private final g:LQo/a;

.field private final h:Lip/h;

.field private final i:LQo/d;

.field private final j:Lgp/F;

.field private k:LOo/l;

.field private l:Lip/k;


# direct methods
.method public constructor <init>(LTo/c;Ljp/n;Luo/B;LOo/l;LPo/a;)V
    .registers 7

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "storageManager"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "module"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "metadataVersion"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1, p2, p3}, Lgp/r;-><init>(LTo/c;Ljp/n;Luo/B;)V

    iput-object p5, p0, Lgp/t;->g:LQo/a;

    const/4 p1, 0x0

    iput-object p1, p0, Lgp/t;->h:Lip/h;

    new-instance p1, LQo/d;

    invoke-virtual {p4}, LOo/l;->D()LOo/o;

    move-result-object p2

    const-string p3, "proto.strings"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p4}, LOo/l;->C()LOo/n;

    move-result-object p3

    const-string v0, "proto.qualifiedNames"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p1, p2, p3}, LQo/d;-><init>(LOo/o;LOo/n;)V

    iput-object p1, p0, Lgp/t;->i:LQo/d;

    new-instance p2, Lgp/F;

    new-instance p3, Lgp/s;

    invoke-direct {p3, p0}, Lgp/s;-><init>(Lgp/t;)V

    invoke-direct {p2, p4, p1, p5, p3}, Lgp/F;-><init>(LOo/l;LQo/d;LPo/a;Leo/l;)V

    iput-object p2, p0, Lgp/t;->j:Lgp/F;

    iput-object p4, p0, Lgp/t;->k:LOo/l;

    return-void
.end method

.method public static final synthetic L0(Lgp/t;)Lip/h;
    .registers 1

    iget-object p0, p0, Lgp/t;->h:Lip/h;

    return-object p0
.end method


# virtual methods
.method public final I0()Lgp/F;
    .registers 2

    iget-object v0, p0, Lgp/t;->j:Lgp/F;

    return-object v0
.end method

.method public final M0()Lgp/F;
    .registers 2

    iget-object v0, p0, Lgp/t;->j:Lgp/F;

    return-object v0
.end method

.method public final N0(Lgp/l;)V
    .registers 13

    iget-object v0, p0, Lgp/t;->k:LOo/l;

    if-eqz v0, :cond_34

    const/4 v1, 0x0

    iput-object v1, p0, Lgp/t;->k:LOo/l;

    new-instance v1, Lip/k;

    invoke-virtual {v0}, LOo/l;->B()LOo/k;

    move-result-object v4

    const-string v0, "proto.`package`"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "scope of "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    new-instance v10, Lgp/t$a;

    invoke-direct {v10, p0}, Lgp/t$a;-><init>(Lgp/t;)V

    iget-object v6, p0, Lgp/t;->g:LQo/a;

    iget-object v7, p0, Lgp/t;->h:Lip/h;

    iget-object v5, p0, Lgp/t;->i:LQo/d;

    move-object v2, v1

    move-object v3, p0

    move-object v8, p1

    invoke-direct/range {v2 .. v10}, Lip/k;-><init>(Luo/E;LOo/k;LQo/c;LQo/a;Lip/h;Lgp/l;Ljava/lang/String;Leo/a;)V

    iput-object v1, p0, Lgp/t;->l:Lip/k;

    return-void

    :cond_34
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Repeated call to DeserializedPackageFragmentImpl::initialize"

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final p()Ldp/i;
    .registers 2

    iget-object v0, p0, Lgp/t;->l:Lip/k;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    const-string v0, "_memberScope"

    invoke-static {v0}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method
