.class public final Lgp/j;
.super Ljava/lang/Object;
.source "ClassDeserializer.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgp/j$a;
    }
.end annotation


# static fields
.field private static final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LTo/b;",
            ">;"
        }
    .end annotation
.end field

.field public static final synthetic d:I


# instance fields
.field private final a:Lgp/l;

.field private final b:Ljp/i;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Lro/n$a;->c:LTo/d;

    invoke-virtual {v0}, LTo/d;->l()LTo/c;

    move-result-object v0

    invoke-static {v0}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/O;->e(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lgp/j;->c:Ljava/util/Set;

    return-void
.end method

.method public constructor <init>(Lgp/l;)V
    .registers 3

    const-string v0, "components"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lgp/j;->a:Lgp/l;

    invoke-virtual {p1}, Lgp/l;->u()Ljp/n;

    move-result-object p1

    new-instance v0, Lgp/j$b;

    invoke-direct {v0, p0}, Lgp/j$b;-><init>(Lgp/j;)V

    invoke-interface {p1, v0}, Ljp/n;->i(Leo/l;)Ljp/i;

    move-result-object p1

    iput-object p1, p0, Lgp/j;->b:Ljp/i;

    return-void
.end method

.method public static final a(Lgp/j;Lgp/j$a;)Luo/e;
    .registers 15

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lgp/j$a;->b()LTo/b;

    move-result-object v0

    iget-object v1, p0, Lgp/j;->a:Lgp/l;

    invoke-virtual {v1}, Lgp/l;->k()Ljava/lang/Iterable;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_11
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_25

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lwo/b;

    invoke-interface {v3, v0}, Lwo/b;->c(LTo/b;)Luo/e;

    move-result-object v3

    if-eqz v3, :cond_11

    goto/16 :goto_fd

    :cond_25
    sget-object v2, Lgp/j;->c:Ljava/util/Set;

    invoke-interface {v2, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_30

    goto/16 :goto_fd

    :cond_30
    invoke-virtual {p1}, Lgp/j$a;->a()Lgp/h;

    move-result-object p1

    if-nez p1, :cond_42

    invoke-virtual {v1}, Lgp/l;->e()Lgp/i;

    move-result-object p1

    invoke-interface {p1, v0}, Lgp/i;->a(LTo/b;)Lgp/h;

    move-result-object p1

    if-nez p1, :cond_42

    goto/16 :goto_fd

    :cond_42
    invoke-virtual {p1}, Lgp/h;->a()LQo/c;

    move-result-object v2

    invoke-virtual {p1}, Lgp/h;->b()LOo/b;

    move-result-object v11

    invoke-virtual {p1}, Lgp/h;->c()LQo/a;

    move-result-object v12

    invoke-virtual {p1}, Lgp/h;->d()Luo/S;

    move-result-object p1

    invoke-virtual {v0}, LTo/b;->g()LTo/b;

    move-result-object v4

    const-string v5, "classId.shortClassName"

    if-eqz v4, :cond_80

    invoke-virtual {p0, v4, v3}, Lgp/j;->c(LTo/b;Lgp/h;)Luo/e;

    move-result-object p0

    instance-of v1, p0, Lip/d;

    if-eqz v1, :cond_65

    check-cast p0, Lip/d;

    goto :goto_66

    :cond_65
    move-object p0, v3

    :goto_66
    if-nez p0, :cond_6a

    goto/16 :goto_fd

    :cond_6a
    invoke-virtual {v0}, LTo/b;->j()LTo/f;

    move-result-object v0

    invoke-static {v0, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lip/d;->Y0(LTo/f;)Z

    move-result v0

    if-nez v0, :cond_79

    goto/16 :goto_fd

    :cond_79
    invoke-virtual {p0}, Lip/d;->T0()Lgp/n;

    move-result-object p0

    :goto_7d
    move-object v5, p0

    goto/16 :goto_f3

    :cond_80
    invoke-virtual {v1}, Lgp/l;->r()Luo/F;

    move-result-object v1

    invoke-virtual {v0}, LTo/b;->h()LTo/c;

    move-result-object v4

    const-string v6, "classId.packageFqName"

    invoke-static {v4, v6}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, v4}, Lcom/facebook/soloader/m;->j(Luo/F;LTo/c;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_95
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v6, v4

    check-cast v6, Luo/E;

    instance-of v7, v6, Lgp/r;

    if-eqz v7, :cond_c6

    check-cast v6, Lgp/r;

    invoke-virtual {v0}, LTo/b;->j()LTo/f;

    move-result-object v7

    invoke-static {v7, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v6, Lgp/t;

    invoke-virtual {v6}, Lgp/t;->p()Ldp/i;

    move-result-object v6

    check-cast v6, Lip/j;

    invoke-virtual {v6}, Lip/j;->o()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_95

    goto :goto_c6

    :cond_c5
    move-object v4, v3

    :cond_c6
    :goto_c6
    move-object v5, v4

    check-cast v5, Luo/E;

    if-nez v5, :cond_cc

    goto :goto_fd

    :cond_cc
    new-instance v7, LQo/g;

    invoke-virtual {v11}, LOo/b;->I0()LOo/s;

    move-result-object v0

    const-string v1, "classProto.typeTable"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v7, v0}, LQo/g;-><init>(LOo/s;)V

    sget v0, LQo/h;->c:I

    invoke-virtual {v11}, LOo/b;->J0()LOo/v;

    move-result-object v0

    const-string v1, "classProto.versionRequirementTable"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LQo/h$a;->a(LOo/v;)LQo/h;

    move-result-object v8

    const/4 v10, 0x0

    iget-object v4, p0, Lgp/j;->a:Lgp/l;

    move-object v6, v2

    move-object v9, v12

    invoke-virtual/range {v4 .. v10}, Lgp/l;->a(Luo/E;LQo/c;LQo/g;LQo/h;LQo/a;Lip/h;)Lgp/n;

    move-result-object p0

    goto :goto_7d

    :goto_f3
    new-instance v3, Lip/d;

    move-object v4, v3

    move-object v6, v11

    move-object v7, v2

    move-object v8, v12

    move-object v9, p1

    invoke-direct/range {v4 .. v9}, Lip/d;-><init>(Lgp/n;LOo/b;LQo/c;LQo/a;Luo/S;)V

    :goto_fd
    return-object v3
.end method

.method public static final synthetic b()Ljava/util/Set;
    .registers 1

    sget-object v0, Lgp/j;->c:Ljava/util/Set;

    return-object v0
.end method


# virtual methods
.method public final c(LTo/b;Lgp/h;)Luo/e;
    .registers 4

    const-string v0, "classId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lgp/j$a;

    invoke-direct {v0, p1, p2}, Lgp/j$a;-><init>(LTo/b;Lgp/h;)V

    iget-object p1, p0, Lgp/j;->b:Ljp/i;

    invoke-interface {p1, v0}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Luo/e;

    return-object p1
.end method
