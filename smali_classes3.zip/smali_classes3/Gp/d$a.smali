.class public final LGp/d$a;
.super Ljava/lang/Object;
.source "CacheStrategy.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LGp/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Lokhttp3/Request;Lokhttp3/Response;)Z
    .registers 6

    const-string v0, "response"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "request"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lokhttp3/Response;->code()I

    move-result v0

    const/16 v1, 0xc8

    const/4 v2, 0x0

    if-eq v0, v1, :cond_65

    const/16 v1, 0x19a

    if-eq v0, v1, :cond_65

    const/16 v1, 0x19e

    if-eq v0, v1, :cond_65

    const/16 v1, 0x1f5

    if-eq v0, v1, :cond_65

    const/16 v1, 0xcb

    if-eq v0, v1, :cond_65

    const/16 v1, 0xcc

    if-eq v0, v1, :cond_65

    const/16 v1, 0x133

    if-eq v0, v1, :cond_3b

    const/16 v1, 0x134

    if-eq v0, v1, :cond_65

    const/16 v1, 0x194

    if-eq v0, v1, :cond_65

    const/16 v1, 0x195

    if-eq v0, v1, :cond_65

    packed-switch v0, :pswitch_data_7c

    return v2

    :cond_3b
    :pswitch_3b
    const/4 v0, 0x2

    const/4 v1, 0x0

    const-string v3, "Expires"

    invoke-static {p1, v3, v1, v0, v1}, Lokhttp3/Response;->header$default(Lokhttp3/Response;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_65

    invoke-virtual {p1}, Lokhttp3/Response;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/CacheControl;->maxAgeSeconds()I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_65

    invoke-virtual {p1}, Lokhttp3/Response;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/CacheControl;->isPublic()Z

    move-result v0

    if-nez v0, :cond_65

    invoke-virtual {p1}, Lokhttp3/Response;->cacheControl()Lokhttp3/CacheControl;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/CacheControl;->isPrivate()Z

    move-result v0

    if-nez v0, :cond_65

    return v2

    :cond_65
    :pswitch_65
    invoke-virtual {p1}, Lokhttp3/Response;->cacheControl()Lokhttp3/CacheControl;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/CacheControl;->noStore()Z

    move-result p1

    if-nez p1, :cond_7a

    invoke-virtual {p0}, Lokhttp3/Request;->cacheControl()Lokhttp3/CacheControl;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/CacheControl;->noStore()Z

    move-result p0

    if-nez p0, :cond_7a

    const/4 v2, 0x1

    :cond_7a
    return v2

    nop

    :pswitch_data_7c
    .packed-switch 0x12c
        :pswitch_65
        :pswitch_65
        :pswitch_3b
    .end packed-switch
.end method
