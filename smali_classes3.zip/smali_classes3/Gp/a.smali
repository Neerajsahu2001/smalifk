.class final Lgp/a;
.super Lkotlin/jvm/internal/p;
.source "AbstractDeserializedPackageFragmentProvider.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/c;",
        "Luo/E;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/b;


# direct methods
.method constructor <init>(Lgp/b;)V
    .registers 2

    iput-object p1, p0, Lgp/a;->a:Lgp/b;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, LTo/c;

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/a;->a:Lgp/b;

    invoke-virtual {v0, p1}, Lgp/b;->d(LTo/c;)Lhp/c;

    move-result-object p1

    const/4 v1, 0x0

    if-eqz p1, :cond_1e

    iget-object v0, v0, Lgp/b;->d:Lgp/l;

    if-eqz v0, :cond_18

    invoke-virtual {p1, v0}, Lgp/t;->N0(Lgp/l;)V

    goto :goto_1f

    :cond_18
    const-string p1, "components"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    throw v1

    :cond_1e
    move-object p1, v1

    :goto_1f
    return-object p1
.end method
