.class final Lgp/K$e;
.super Lkotlin/jvm/internal/p;
.source "TypeDeserializer.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lgp/K;->k(Lgp/K;LOo/p;I)Luo/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LOo/p;",
        "LOo/p;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/K;


# direct methods
.method constructor <init>(Lgp/K;)V
    .registers 2

    iput-object p1, p0, Lgp/K$e;->a:Lgp/K;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LOo/p;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/K$e;->a:Lgp/K;

    invoke-static {v0}, Lgp/K;->c(Lgp/K;)Lgp/n;

    move-result-object v0

    invoke-virtual {v0}, Lgp/n;->j()LQo/g;

    move-result-object v0

    invoke-static {p1, v0}, LQo/f;->a(LOo/p;LQo/g;)LOo/p;

    move-result-object p1

    return-object p1
.end method
