.class public interface abstract Lgp/g;
.super Ljava/lang/Object;
.source "AnnotationLoader.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract b(Lgp/G;LUo/p;Lgp/c;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LUo/p;",
            "Lgp/c;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation
.end method

.method public abstract c(LOo/r;LQo/c;)Ljava/util/ArrayList;
.end method

.method public abstract d(Lgp/G;LOo/m;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LOo/m;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation
.end method

.method public abstract e(LOo/p;LQo/c;)Ljava/util/ArrayList;
.end method

.method public abstract f(Lgp/G;LUo/p;Lgp/c;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LUo/p;",
            "Lgp/c;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation
.end method

.method public abstract g(Lgp/G$a;)Ljava/util/ArrayList;
.end method

.method public abstract h(Lgp/G;LOo/m;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LOo/m;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation
.end method

.method public abstract i(Lgp/G;LUo/p;Lgp/c;ILOo/t;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LUo/p;",
            "Lgp/c;",
            "I",
            "LOo/t;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation
.end method

.method public abstract k(Lgp/G$a;LOo/f;)Ljava/util/List;
.end method
