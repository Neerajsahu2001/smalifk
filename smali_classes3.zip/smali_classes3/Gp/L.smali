.class public final Lgp/l;
.super Ljava/lang/Object;
.source "context.kt"


# instance fields
.field private final a:Ljp/n;

.field private final b:Luo/B;

.field private final c:Lgp/m;

.field private final d:Lgp/i;

.field private final e:Lgp/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lgp/d<",
            "Lvo/c;",
            "LYo/g<",
            "*>;>;"
        }
    .end annotation
.end field

.field private final f:Luo/F;

.field private final g:Lgp/y;

.field private final h:Lgp/u;

.field private final i:LCo/b;

.field private final j:Lgp/v;

.field private final k:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "Lwo/b;",
            ">;"
        }
    .end annotation
.end field

.field private final l:Luo/D;

.field private final m:Lgp/k;

.field private final n:Lwo/a;

.field private final o:Lwo/c;

.field private final p:LUo/f;

.field private final q:Llp/l;

.field private final r:Lwo/e;

.field private final s:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lkp/b0;",
            ">;"
        }
    .end annotation
.end field

.field private final t:Lgp/j;


# direct methods
.method public constructor <init>(Ljp/n;Luo/B;Lgp/i;Lgp/d;Luo/F;Lgp/u;Lgp/v;Ljava/lang/Iterable;Luo/D;Lgp/k$a$a;Lwo/a;Lwo/c;LUo/f;Llp/m;LD2/o;Ljava/util/List;I)V
    .registers 33

    move-object v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p5

    move-object/from16 v4, p8

    move-object/from16 v5, p11

    move-object/from16 v6, p12

    move-object/from16 v7, p13

    sget-object v8, Lgp/m$a;->a:Lgp/m$a;

    sget-object v9, Lgp/y$a;->a:Lgp/y$a;

    sget-object v10, LCo/b$a;->a:LCo/b$a;

    const/high16 v11, 0x10000

    and-int v11, p17, v11

    if-eqz v11, :cond_25

    sget-object v11, Llp/l;->b:Llp/l$a;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Llp/l$a;->a()Llp/m;

    move-result-object v11

    goto :goto_27

    :cond_25
    move-object/from16 v11, p14

    :goto_27
    sget-object v12, Lwo/e$a;->a:Lwo/e$a;

    const/high16 v13, 0x80000

    and-int v13, p17, v13

    if-eqz v13, :cond_36

    sget-object v13, Lkp/p;->a:Lkp/p;

    invoke-static {v13}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v13

    goto :goto_38

    :cond_36
    move-object/from16 v13, p16

    :goto_38
    const-string v14, "storageManager"

    invoke-static {v1, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "moduleDescriptor"

    invoke-static {v2, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "packageFragmentProvider"

    invoke-static {v3, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "fictitiousClassDescriptorFactories"

    invoke-static {v4, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "additionalClassPartsProvider"

    invoke-static {v5, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "platformDependentDeclarationFilter"

    invoke-static {v6, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "extensionRegistryLite"

    invoke-static {v7, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "kotlinTypeChecker"

    invoke-static {v11, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "typeAttributeTranslators"

    invoke-static {v13, v14}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Lgp/l;->a:Ljp/n;

    iput-object v2, v0, Lgp/l;->b:Luo/B;

    iput-object v8, v0, Lgp/l;->c:Lgp/m;

    move-object/from16 v1, p3

    iput-object v1, v0, Lgp/l;->d:Lgp/i;

    move-object/from16 v1, p4

    iput-object v1, v0, Lgp/l;->e:Lgp/d;

    iput-object v3, v0, Lgp/l;->f:Luo/F;

    iput-object v9, v0, Lgp/l;->g:Lgp/y;

    move-object/from16 v1, p6

    iput-object v1, v0, Lgp/l;->h:Lgp/u;

    iput-object v10, v0, Lgp/l;->i:LCo/b;

    move-object/from16 v1, p7

    iput-object v1, v0, Lgp/l;->j:Lgp/v;

    iput-object v4, v0, Lgp/l;->k:Ljava/lang/Iterable;

    move-object/from16 v1, p9

    iput-object v1, v0, Lgp/l;->l:Luo/D;

    move-object/from16 v1, p10

    iput-object v1, v0, Lgp/l;->m:Lgp/k;

    iput-object v5, v0, Lgp/l;->n:Lwo/a;

    iput-object v6, v0, Lgp/l;->o:Lwo/c;

    iput-object v7, v0, Lgp/l;->p:LUo/f;

    iput-object v11, v0, Lgp/l;->q:Llp/l;

    iput-object v12, v0, Lgp/l;->r:Lwo/e;

    iput-object v13, v0, Lgp/l;->s:Ljava/util/List;

    new-instance v1, Lgp/j;

    invoke-direct {v1, p0}, Lgp/j;-><init>(Lgp/l;)V

    iput-object v1, v0, Lgp/l;->t:Lgp/j;

    return-void
.end method


# virtual methods
.method public final a(Luo/E;LQo/c;LQo/g;LQo/h;LQo/a;Lip/h;)Lgp/n;
    .registers 18

    const-string v0, "descriptor"

    move-object v4, p1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    move-object v3, p2

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "metadataVersion"

    move-object/from16 v7, p5

    invoke-static {v7, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lgp/n;

    sget-object v10, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    const/4 v9, 0x0

    move-object v1, v0

    move-object v2, p0

    move-object v5, p3

    move-object v6, p4

    move-object/from16 v8, p6

    invoke-direct/range {v1 .. v10}, Lgp/n;-><init>(Lgp/l;LQo/c;Luo/k;LQo/g;LQo/h;LQo/a;Lip/h;Lgp/K;Ljava/util/List;)V

    return-object v0
.end method

.method public final b(LTo/b;)Luo/e;
    .registers 4

    const-string v0, "classId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget v0, Lgp/j;->d:I

    const/4 v0, 0x0

    iget-object v1, p0, Lgp/l;->t:Lgp/j;

    invoke-virtual {v1, p1, v0}, Lgp/j;->c(LTo/b;Lgp/h;)Luo/e;

    move-result-object p1

    return-object p1
.end method

.method public final c()Lwo/a;
    .registers 2

    iget-object v0, p0, Lgp/l;->n:Lwo/a;

    return-object v0
.end method

.method public final d()Lgp/d;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lgp/d<",
            "Lvo/c;",
            "LYo/g<",
            "*>;>;"
        }
    .end annotation

    iget-object v0, p0, Lgp/l;->e:Lgp/d;

    return-object v0
.end method

.method public final e()Lgp/i;
    .registers 2

    iget-object v0, p0, Lgp/l;->d:Lgp/i;

    return-object v0
.end method

.method public final f()Lgp/j;
    .registers 2

    iget-object v0, p0, Lgp/l;->t:Lgp/j;

    return-object v0
.end method

.method public final g()Lgp/m;
    .registers 2

    iget-object v0, p0, Lgp/l;->c:Lgp/m;

    return-object v0
.end method

.method public final h()Lgp/k;
    .registers 2

    iget-object v0, p0, Lgp/l;->m:Lgp/k;

    return-object v0
.end method

.method public final i()Lgp/u;
    .registers 2

    iget-object v0, p0, Lgp/l;->h:Lgp/u;

    return-object v0
.end method

.method public final j()LUo/f;
    .registers 2

    iget-object v0, p0, Lgp/l;->p:LUo/f;

    return-object v0
.end method

.method public final k()Ljava/lang/Iterable;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Iterable<",
            "Lwo/b;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lgp/l;->k:Ljava/lang/Iterable;

    return-object v0
.end method

.method public final l()Lgp/v;
    .registers 2

    iget-object v0, p0, Lgp/l;->j:Lgp/v;

    return-object v0
.end method

.method public final m()Llp/l;
    .registers 2

    iget-object v0, p0, Lgp/l;->q:Llp/l;

    return-object v0
.end method

.method public final n()Lgp/y;
    .registers 2

    iget-object v0, p0, Lgp/l;->g:Lgp/y;

    return-object v0
.end method

.method public final o()LCo/b;
    .registers 2

    iget-object v0, p0, Lgp/l;->i:LCo/b;

    return-object v0
.end method

.method public final p()Luo/B;
    .registers 2

    iget-object v0, p0, Lgp/l;->b:Luo/B;

    return-object v0
.end method

.method public final q()Luo/D;
    .registers 2

    iget-object v0, p0, Lgp/l;->l:Luo/D;

    return-object v0
.end method

.method public final r()Luo/F;
    .registers 2

    iget-object v0, p0, Lgp/l;->f:Luo/F;

    return-object v0
.end method

.method public final s()Lwo/c;
    .registers 2

    iget-object v0, p0, Lgp/l;->o:Lwo/c;

    return-object v0
.end method

.method public final t()Lwo/e;
    .registers 2

    iget-object v0, p0, Lgp/l;->r:Lwo/e;

    return-object v0
.end method

.method public final u()Ljp/n;
    .registers 2

    iget-object v0, p0, Lgp/l;->a:Ljp/n;

    return-object v0
.end method

.method public final v()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lkp/b0;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lgp/l;->s:Ljava/util/List;

    return-object v0
.end method
