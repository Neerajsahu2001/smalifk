.class public interface abstract Lgp/d;
.super Ljava/lang/Object;
.source "AnnotationAndConstantLoader.kt"

# interfaces
.implements Lgp/g;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        "C:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lgp/g<",
        "TA;>;"
    }
.end annotation


# virtual methods
.method public abstract a(Lgp/G;LOo/m;Lkp/E;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LOo/m;",
            "Lkp/E;",
            ")TC;"
        }
    .end annotation
.end method

.method public abstract j(Lgp/G;LOo/m;Lkp/E;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LOo/m;",
            "Lkp/E;",
            ")TC;"
        }
    .end annotation
.end method
