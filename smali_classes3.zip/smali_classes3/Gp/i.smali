.class public interface abstract Lgp/i;
.super Ljava/lang/Object;
.source "ClassDataFinder.java"


# virtual methods
.method public abstract a(LTo/b;)Lgp/h;
.end method
