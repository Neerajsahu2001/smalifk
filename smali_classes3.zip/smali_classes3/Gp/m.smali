.class public interface abstract Lgp/m;
.super Ljava/lang/Object;
.source "DeserializationConfiguration.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgp/m$a;
    }
.end annotation
