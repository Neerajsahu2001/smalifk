.class final Lgp/K$b;
.super Lkotlin/jvm/internal/p;
.source "TypeDeserializer.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lgp/K;->g(LOo/p;Z)Lkp/M;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "Lvo/c;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/K;

.field final synthetic b:LOo/p;


# direct methods
.method constructor <init>(LOo/p;Lgp/K;)V
    .registers 3

    iput-object p2, p0, Lgp/K$b;->a:Lgp/K;

    iput-object p1, p0, Lgp/K$b;->b:LOo/p;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Lgp/K$b;->a:Lgp/K;

    invoke-static {v0}, Lgp/K;->c(Lgp/K;)Lgp/n;

    move-result-object v1

    invoke-virtual {v1}, Lgp/n;->c()Lgp/l;

    move-result-object v1

    invoke-virtual {v1}, Lgp/l;->d()Lgp/d;

    move-result-object v1

    invoke-static {v0}, Lgp/K;->c(Lgp/K;)Lgp/n;

    move-result-object v0

    invoke-virtual {v0}, Lgp/n;->g()LQo/c;

    move-result-object v0

    iget-object v2, p0, Lgp/K$b;->b:LOo/p;

    invoke-interface {v1, v2, v0}, Lgp/g;->e(LOo/p;LQo/c;)Ljava/util/ArrayList;

    move-result-object v0

    return-object v0
.end method
