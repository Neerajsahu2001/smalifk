.class public final Lgp/k$a;
.super Ljava/lang/Object;
.source "ContractDeserializer.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgp/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field private static final a:Lgp/k$a$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lgp/k$a$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lgp/k$a;->a:Lgp/k$a$a;

    return-void
.end method

.method public static a()Lgp/k$a$a;
    .registers 1

    sget-object v0, Lgp/k$a;->a:Lgp/k$a$a;

    return-object v0
.end method
