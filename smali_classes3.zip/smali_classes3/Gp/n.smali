.class public final Lgp/n;
.super Ljava/lang/Object;
.source "context.kt"


# instance fields
.field private final a:Lgp/l;

.field private final b:LQo/c;

.field private final c:Luo/k;

.field private final d:LQo/g;

.field private final e:LQo/h;

.field private final f:LQo/a;

.field private final g:Lip/h;

.field private final h:Lgp/K;

.field private final i:Lgp/z;


# direct methods
.method public constructor <init>(Lgp/l;LQo/c;Luo/k;LQo/g;LQo/h;LQo/a;Lip/h;Lgp/K;Ljava/util/List;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/l;",
            "LQo/c;",
            "Luo/k;",
            "LQo/g;",
            "LQo/h;",
            "LQo/a;",
            "Lip/h;",
            "Lgp/K;",
            "Ljava/util/List<",
            "LOo/r;",
            ">;)V"
        }
    .end annotation

    const-string v0, "components"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "containingDeclaration"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "typeTable"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "versionRequirementTable"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "metadataVersion"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lgp/n;->a:Lgp/l;

    iput-object p2, p0, Lgp/n;->b:LQo/c;

    iput-object p3, p0, Lgp/n;->c:Luo/k;

    iput-object p4, p0, Lgp/n;->d:LQo/g;

    iput-object p5, p0, Lgp/n;->e:LQo/h;

    iput-object p6, p0, Lgp/n;->f:LQo/a;

    iput-object p7, p0, Lgp/n;->g:Lip/h;

    new-instance v0, Lgp/K;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Deserializer for \""

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {p3}, Luo/k;->getName()LTo/f;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p2, 0x22

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p5

    if-eqz p7, :cond_53

    invoke-interface {p7}, Lip/h;->a()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_51

    goto :goto_53

    :cond_51
    :goto_51
    move-object p6, p1

    goto :goto_56

    :cond_53
    :goto_53
    const-string p1, "[container not found]"

    goto :goto_51

    :goto_56
    move-object p1, v0

    move-object p2, p0

    move-object p3, p8

    move-object p4, p9

    invoke-direct/range {p1 .. p6}, Lgp/K;-><init>(Lgp/n;Lgp/K;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V

    iput-object v0, p0, Lgp/n;->h:Lgp/K;

    new-instance p1, Lgp/z;

    invoke-direct {p1, p0}, Lgp/z;-><init>(Lgp/n;)V

    iput-object p1, p0, Lgp/n;->i:Lgp/z;

    return-void
.end method

.method public static synthetic b(Lgp/n;Lxo/p;Ljava/util/List;)Lgp/n;
    .registers 10

    iget-object v3, p0, Lgp/n;->b:LQo/c;

    iget-object v4, p0, Lgp/n;->d:LQo/g;

    iget-object v5, p0, Lgp/n;->e:LQo/h;

    iget-object v6, p0, Lgp/n;->f:LQo/a;

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    invoke-virtual/range {v0 .. v6}, Lgp/n;->a(Luo/k;Ljava/util/List;LQo/c;LQo/g;LQo/h;LQo/a;)Lgp/n;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final a(Luo/k;Ljava/util/List;LQo/c;LQo/g;LQo/h;LQo/a;)Lgp/n;
    .registers 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Luo/k;",
            "Ljava/util/List<",
            "LOo/r;",
            ">;",
            "LQo/c;",
            "LQo/g;",
            "LQo/h;",
            "LQo/a;",
            ")",
            "Lgp/n;"
        }
    .end annotation

    move-object v0, p0

    const-string v1, "descriptor"

    move-object v5, p1

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "nameResolver"

    move-object v4, p3

    invoke-static {p3, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "typeTable"

    move-object/from16 v6, p4

    invoke-static {v6, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "versionRequirementTable"

    move-object/from16 v2, p5

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "metadataVersion"

    move-object/from16 v8, p6

    invoke-static {v8, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lgp/n;

    invoke-virtual/range {p6 .. p6}, LQo/a;->a()I

    move-result v3

    const/4 v7, 0x1

    if-ne v3, v7, :cond_34

    invoke-virtual/range {p6 .. p6}, LQo/a;->b()I

    move-result v3

    const/4 v7, 0x4

    if-lt v3, v7, :cond_34

    :goto_32
    move-object v7, v2

    goto :goto_37

    :cond_34
    iget-object v2, v0, Lgp/n;->e:LQo/h;

    goto :goto_32

    :goto_37
    iget-object v10, v0, Lgp/n;->h:Lgp/K;

    iget-object v3, v0, Lgp/n;->a:Lgp/l;

    iget-object v9, v0, Lgp/n;->g:Lip/h;

    move-object v2, v1

    move-object v4, p3

    move-object v5, p1

    move-object/from16 v6, p4

    move-object/from16 v8, p6

    move-object v11, p2

    invoke-direct/range {v2 .. v11}, Lgp/n;-><init>(Lgp/l;LQo/c;Luo/k;LQo/g;LQo/h;LQo/a;Lip/h;Lgp/K;Ljava/util/List;)V

    return-object v1
.end method

.method public final c()Lgp/l;
    .registers 2

    iget-object v0, p0, Lgp/n;->a:Lgp/l;

    return-object v0
.end method

.method public final d()Lip/h;
    .registers 2

    iget-object v0, p0, Lgp/n;->g:Lip/h;

    return-object v0
.end method

.method public final e()Luo/k;
    .registers 2

    iget-object v0, p0, Lgp/n;->c:Luo/k;

    return-object v0
.end method

.method public final f()Lgp/z;
    .registers 2

    iget-object v0, p0, Lgp/n;->i:Lgp/z;

    return-object v0
.end method

.method public final g()LQo/c;
    .registers 2

    iget-object v0, p0, Lgp/n;->b:LQo/c;

    return-object v0
.end method

.method public final h()Ljp/n;
    .registers 2

    iget-object v0, p0, Lgp/n;->a:Lgp/l;

    invoke-virtual {v0}, Lgp/l;->u()Ljp/n;

    move-result-object v0

    return-object v0
.end method

.method public final i()Lgp/K;
    .registers 2

    iget-object v0, p0, Lgp/n;->h:Lgp/K;

    return-object v0
.end method

.method public final j()LQo/g;
    .registers 2

    iget-object v0, p0, Lgp/n;->d:LQo/g;

    return-object v0
.end method

.method public final k()LQo/h;
    .registers 2

    iget-object v0, p0, Lgp/n;->e:LQo/h;

    return-object v0
.end method
