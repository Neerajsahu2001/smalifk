.class public final Lgp/G$a;
.super Lgp/G;
.source "ProtoContainer.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgp/G;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final d:LOo/b;

.field private final e:Lgp/G$a;

.field private final f:LTo/b;

.field private final g:LOo/b$c;

.field private final h:Z


# direct methods
.method public constructor <init>(LOo/b;LQo/c;LQo/g;Luo/S;Lgp/G$a;)V
    .registers 7

    const-string v0, "classProto"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "typeTable"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2, p3, p4}, Lgp/G;-><init>(LQo/c;LQo/g;Luo/S;)V

    iput-object p1, p0, Lgp/G$a;->d:LOo/b;

    iput-object p5, p0, Lgp/G$a;->e:Lgp/G$a;

    invoke-virtual {p1}, LOo/b;->q0()I

    move-result p3

    invoke-static {p2, p3}, Lcom/google/android/gms/internal/ads/zzcgw;->b(LQo/c;I)LTo/b;

    move-result-object p2

    iput-object p2, p0, Lgp/G$a;->f:LTo/b;

    sget-object p2, LQo/b;->f:LQo/b$c;

    invoke-virtual {p1}, LOo/b;->p0()I

    move-result p3

    invoke-virtual {p2, p3}, LQo/b$c;->c(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, LOo/b$c;

    if-nez p2, :cond_30

    sget-object p2, LOo/b$c;->CLASS:LOo/b$c;

    :cond_30
    iput-object p2, p0, Lgp/G$a;->g:LOo/b$c;

    sget-object p2, LQo/b;->g:LQo/b$a;

    invoke-virtual {p1}, LOo/b;->p0()I

    move-result p1

    invoke-virtual {p2, p1}, LQo/b$a;->d(I)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iput-boolean p1, p0, Lgp/G$a;->h:Z

    return-void
.end method


# virtual methods
.method public final a()LTo/c;
    .registers 3

    iget-object v0, p0, Lgp/G$a;->f:LTo/b;

    invoke-virtual {v0}, LTo/b;->b()LTo/c;

    move-result-object v0

    const-string v1, "classId.asSingleFqName()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public final e()LTo/b;
    .registers 2

    iget-object v0, p0, Lgp/G$a;->f:LTo/b;

    return-object v0
.end method

.method public final f()LOo/b;
    .registers 2

    iget-object v0, p0, Lgp/G$a;->d:LOo/b;

    return-object v0
.end method

.method public final g()LOo/b$c;
    .registers 2

    iget-object v0, p0, Lgp/G$a;->g:LOo/b$c;

    return-object v0
.end method

.method public final h()Lgp/G$a;
    .registers 2

    iget-object v0, p0, Lgp/G$a;->e:Lgp/G$a;

    return-object v0
.end method

.method public final i()Z
    .registers 2

    iget-boolean v0, p0, Lgp/G$a;->h:Z

    return v0
.end method
