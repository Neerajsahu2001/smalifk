.class final Lgp/z$c;
.super Lkotlin/jvm/internal/p;
.source "MemberDeserializer.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lgp/z;->j(Ljava/util/List;LUo/p;Lgp/c;)Ljava/util/List;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "Lvo/c;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lgp/z;

.field final synthetic b:Lgp/G;

.field final synthetic c:LUo/p;

.field final synthetic d:Lgp/c;

.field final synthetic e:I

.field final synthetic f:LOo/t;


# direct methods
.method constructor <init>(Lgp/z;Lgp/G;LUo/p;Lgp/c;ILOo/t;)V
    .registers 7

    iput-object p1, p0, Lgp/z$c;->a:Lgp/z;

    iput-object p2, p0, Lgp/z$c;->b:Lgp/G;

    iput-object p3, p0, Lgp/z$c;->c:LUo/p;

    iput-object p4, p0, Lgp/z$c;->d:Lgp/c;

    iput p5, p0, Lgp/z$c;->e:I

    iput-object p6, p0, Lgp/z$c;->f:LOo/t;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 8

    iget-object v0, p0, Lgp/z$c;->a:Lgp/z;

    invoke-static {v0}, Lgp/z;->b(Lgp/z;)Lgp/n;

    move-result-object v0

    invoke-virtual {v0}, Lgp/n;->c()Lgp/l;

    move-result-object v0

    invoke-virtual {v0}, Lgp/l;->d()Lgp/d;

    move-result-object v1

    iget v5, p0, Lgp/z$c;->e:I

    iget-object v6, p0, Lgp/z$c;->f:LOo/t;

    iget-object v2, p0, Lgp/z$c;->b:Lgp/G;

    iget-object v3, p0, Lgp/z$c;->c:LUo/p;

    iget-object v4, p0, Lgp/z$c;->d:Lgp/c;

    invoke-interface/range {v1 .. v6}, Lgp/g;->i(Lgp/G;LUo/p;Lgp/c;ILOo/t;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
