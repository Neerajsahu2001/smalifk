.class public final enum Lgp/c;
.super Ljava/lang/Enum;
.source "AnnotatedCallableKind.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lgp/c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lgp/c;

.field public static final enum FUNCTION:Lgp/c;

.field public static final enum PROPERTY:Lgp/c;

.field public static final enum PROPERTY_GETTER:Lgp/c;

.field public static final enum PROPERTY_SETTER:Lgp/c;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v4, Lgp/c;

    const-string v5, "FUNCTION"

    invoke-direct {v4, v5, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Lgp/c;->FUNCTION:Lgp/c;

    new-instance v5, Lgp/c;

    const-string v6, "PROPERTY"

    invoke-direct {v5, v6, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lgp/c;->PROPERTY:Lgp/c;

    new-instance v6, Lgp/c;

    const-string v7, "PROPERTY_GETTER"

    invoke-direct {v6, v7, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lgp/c;->PROPERTY_GETTER:Lgp/c;

    new-instance v7, Lgp/c;

    const-string v8, "PROPERTY_SETTER"

    invoke-direct {v7, v8, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lgp/c;->PROPERTY_SETTER:Lgp/c;

    const/4 v8, 0x4

    new-array v8, v8, [Lgp/c;

    aput-object v4, v8, v3

    aput-object v5, v8, v2

    aput-object v6, v8, v1

    aput-object v7, v8, v0

    sput-object v8, Lgp/c;->$VALUES:[Lgp/c;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lgp/c;
    .registers 2

    const-class v0, Lgp/c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lgp/c;

    return-object p0
.end method

.method public static values()[Lgp/c;
    .registers 1

    sget-object v0, Lgp/c;->$VALUES:[Lgp/c;

    invoke-virtual {v0}, [Lgp/c;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lgp/c;

    return-object v0
.end method
