.class public abstract Lgp/b;
.super Ljava/lang/Object;
.source "AbstractDeserializedPackageFragmentProvider.kt"

# interfaces
.implements Luo/H;


# instance fields
.field private final a:Ljp/n;

.field private final b:Lgp/x;

.field private final c:Luo/B;

.field protected d:Lgp/l;

.field private final e:Ljp/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/i<",
            "LTo/c;",
            "Luo/E;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljp/e;Lzo/f;Lxo/G;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lgp/b;->a:Ljp/n;

    iput-object p2, p0, Lgp/b;->b:Lgp/x;

    iput-object p3, p0, Lgp/b;->c:Luo/B;

    new-instance p2, Lgp/a;

    invoke-direct {p2, p0}, Lgp/a;-><init>(Lgp/b;)V

    invoke-virtual {p1, p2}, Ljp/e;->i(Leo/l;)Ljp/i;

    move-result-object p1

    iput-object p1, p0, Lgp/b;->e:Ljp/i;

    return-void
.end method


# virtual methods
.method public final a(LTo/c;)Z
    .registers 4

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/b;->e:Ljp/i;

    invoke-interface {v0, p1}, Ljp/i;->m(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Luo/E;

    goto :goto_18

    :cond_14
    invoke-virtual {p0, p1}, Lgp/b;->d(LTo/c;)Lhp/c;

    move-result-object p1

    :goto_18
    if-nez p1, :cond_1c

    const/4 p1, 0x1

    goto :goto_1d

    :cond_1c
    const/4 p1, 0x0

    :goto_1d
    return p1
.end method

.method public final b(LTo/c;)Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTo/c;",
            ")",
            "Ljava/util/List<",
            "Luo/E;",
            ">;"
        }
    .end annotation

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/b;->e:Ljp/i;

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/q;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public final c(LTo/c;Ljava/util/ArrayList;)V
    .registers 4

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/b;->e:Ljp/i;

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1, p2}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    return-void
.end method

.method protected abstract d(LTo/c;)Lhp/c;
.end method

.method protected final e()Lgp/x;
    .registers 2

    iget-object v0, p0, Lgp/b;->b:Lgp/x;

    return-object v0
.end method

.method protected final f()Luo/B;
    .registers 2

    iget-object v0, p0, Lgp/b;->c:Luo/B;

    return-object v0
.end method

.method protected final g()Ljp/n;
    .registers 2

    iget-object v0, p0, Lgp/b;->a:Ljp/n;

    return-object v0
.end method

.method protected final h(Lgp/l;)V
    .registers 2

    iput-object p1, p0, Lgp/b;->d:Lgp/l;

    return-void
.end method

.method public final n(LTo/c;Leo/l;)Ljava/util/Collection;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTo/c;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "LTo/c;",
            ">;"
        }
    .end annotation

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "nameFilter"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object p1
.end method
