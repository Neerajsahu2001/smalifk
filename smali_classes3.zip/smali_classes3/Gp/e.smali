.class public final Lgp/e;
.super Ljava/lang/Object;
.source "AnnotationAndConstantLoaderImpl.kt"

# interfaces
.implements Lgp/d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgp/e$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lgp/d<",
        "Lvo/c;",
        "LYo/g<",
        "*>;>;"
    }
.end annotation


# instance fields
.field private final a:Lfp/a;

.field private final b:Lgp/f;


# direct methods
.method public constructor <init>(Luo/B;Luo/D;Lhp/a;)V
    .registers 5

    const-string v0, "module"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "protocol"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lgp/e;->a:Lfp/a;

    new-instance p3, Lgp/f;

    invoke-direct {p3, p1, p2}, Lgp/f;-><init>(Luo/B;Luo/D;)V

    iput-object p3, p0, Lgp/e;->b:Lgp/f;

    return-void
.end method


# virtual methods
.method public final a(Lgp/G;LOo/m;Lkp/E;)Ljava/lang/Object;
    .registers 5

    const-string v0, "proto"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/e;->a:Lfp/a;

    invoke-virtual {v0}, Lfp/a;->b()LUo/h$f;

    move-result-object v0

    invoke-static {p2, v0}, LQo/e;->a(LUo/h$d;LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, LOo/a$b$c;

    if-nez p2, :cond_15

    const/4 p1, 0x0

    goto :goto_1f

    :cond_15
    iget-object v0, p0, Lgp/e;->b:Lgp/f;

    invoke-virtual {p1}, Lgp/G;->b()LQo/c;

    move-result-object p1

    invoke-virtual {v0, p3, p2, p1}, Lgp/f;->c(Lkp/E;LOo/a$b$c;LQo/c;)LYo/g;

    move-result-object p1

    :goto_1f
    return-object p1
.end method

.method public final b(Lgp/G;LUo/p;Lgp/c;)Ljava/util/List;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LUo/p;",
            "Lgp/c;",
            ")",
            "Ljava/util/List<",
            "Lvo/c;",
            ">;"
        }
    .end annotation

    const-string v0, "proto"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "kind"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p2, LOo/c;

    iget-object v1, p0, Lgp/e;->a:Lfp/a;

    if-eqz v0, :cond_1d

    check-cast p2, LOo/c;

    invoke-virtual {v1}, Lfp/a;->c()LUo/h$f;

    move-result-object p3

    invoke-virtual {p2, p3}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    goto :goto_75

    :cond_1d
    instance-of v0, p2, LOo/h;

    if-eqz v0, :cond_2e

    check-cast p2, LOo/h;

    invoke-virtual {v1}, Lfp/a;->f()LUo/h$f;

    move-result-object p3

    invoke-virtual {p2, p3}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    goto :goto_75

    :cond_2e
    instance-of v0, p2, LOo/m;

    if-eqz v0, :cond_a3

    sget-object v0, Lgp/e$a;->a:[I

    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    move-result p3

    aget p3, v0, p3

    const/4 v0, 0x1

    if-eq p3, v0, :cond_69

    const/4 v0, 0x2

    if-eq p3, v0, :cond_5c

    const/4 v0, 0x3

    if-ne p3, v0, :cond_50

    check-cast p2, LOo/m;

    invoke-virtual {v1}, Lfp/a;->j()LUo/h$f;

    move-result-object p3

    invoke-virtual {p2, p3}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    goto :goto_75

    :cond_50
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Unsupported callable kind with property proto"

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5c
    check-cast p2, LOo/m;

    invoke-virtual {v1}, Lfp/a;->i()LUo/h$f;

    move-result-object p3

    invoke-virtual {p2, p3}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    goto :goto_75

    :cond_69
    check-cast p2, LOo/m;

    invoke-virtual {v1}, Lfp/a;->h()LUo/h$f;

    move-result-object p3

    invoke-virtual {p2, p3}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    :goto_75
    if-nez p2, :cond_79

    sget-object p2, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_79
    check-cast p2, Ljava/lang/Iterable;

    new-instance p3, Ljava/util/ArrayList;

    invoke-static {p2}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v0

    invoke-direct {p3, v0}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_88
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a2

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LOo/a;

    iget-object v1, p0, Lgp/e;->b:Lgp/f;

    invoke-virtual {p1}, Lgp/G;->b()LQo/c;

    move-result-object v2

    invoke-virtual {v1, v0, v2}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_88

    :cond_a2
    return-object p3

    :cond_a3
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "Unknown message: "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c(LOo/r;LQo/c;)Ljava/util/ArrayList;
    .registers 6

    const-string v0, "proto"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/e;->a:Lfp/a;

    invoke-virtual {v0}, Lfp/a;->l()LUo/h$f;

    move-result-object v0

    invoke-virtual {p1, v0}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    if-nez p1, :cond_1a

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_1a
    check-cast p1, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_29
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3f

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LOo/a;

    iget-object v2, p0, Lgp/e;->b:Lgp/f;

    invoke-virtual {v2, v1, p2}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_29

    :cond_3f
    return-object v0
.end method

.method public final d(Lgp/G;LOo/m;)Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LOo/m;",
            ")",
            "Ljava/util/List<",
            "Lvo/c;",
            ">;"
        }
    .end annotation

    const-string p1, "proto"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p1
.end method

.method public final e(LOo/p;LQo/c;)Ljava/util/ArrayList;
    .registers 6

    const-string v0, "proto"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/e;->a:Lfp/a;

    invoke-virtual {v0}, Lfp/a;->k()LUo/h$f;

    move-result-object v0

    invoke-virtual {p1, v0}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    if-nez p1, :cond_1a

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_1a
    check-cast p1, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_29
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3f

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LOo/a;

    iget-object v2, p0, Lgp/e;->b:Lgp/f;

    invoke-virtual {v2, v1, p2}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_29

    :cond_3f
    return-object v0
.end method

.method public final f(Lgp/G;LUo/p;Lgp/c;)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LUo/p;",
            "Lgp/c;",
            ")",
            "Ljava/util/List<",
            "Lvo/c;",
            ">;"
        }
    .end annotation

    const-string p1, "proto"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "kind"

    invoke-static {p3, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p1
.end method

.method public final g(Lgp/G$a;)Ljava/util/ArrayList;
    .registers 7

    const-string v0, "container"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lgp/G$a;->f()LOo/b;

    move-result-object v0

    iget-object v1, p0, Lgp/e;->a:Lfp/a;

    invoke-virtual {v1}, Lfp/a;->a()LUo/h$f;

    move-result-object v1

    invoke-virtual {v0, v1}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    if-nez v0, :cond_19

    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_19
    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-static {v0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_28
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_42

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LOo/a;

    iget-object v3, p0, Lgp/e;->b:Lgp/f;

    invoke-virtual {p1}, Lgp/G;->b()LQo/c;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_28

    :cond_42
    return-object v1
.end method

.method public final h(Lgp/G;LOo/m;)Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LOo/m;",
            ")",
            "Ljava/util/List<",
            "Lvo/c;",
            ">;"
        }
    .end annotation

    const-string p1, "proto"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p1
.end method

.method public final i(Lgp/G;LUo/p;Lgp/c;ILOo/t;)Ljava/util/List;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgp/G;",
            "LUo/p;",
            "Lgp/c;",
            "I",
            "LOo/t;",
            ")",
            "Ljava/util/List<",
            "Lvo/c;",
            ">;"
        }
    .end annotation

    const-string p4, "container"

    invoke-static {p1, p4}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p4, "callableProto"

    invoke-static {p2, p4}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "kind"

    invoke-static {p3, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "proto"

    invoke-static {p5, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p2, p0, Lgp/e;->a:Lfp/a;

    invoke-virtual {p2}, Lfp/a;->g()LUo/h$f;

    move-result-object p2

    invoke-virtual {p5, p2}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    if-nez p2, :cond_24

    sget-object p2, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_24
    check-cast p2, Ljava/lang/Iterable;

    new-instance p3, Ljava/util/ArrayList;

    invoke-static {p2}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result p4

    invoke-direct {p3, p4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_33
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_4d

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, LOo/a;

    iget-object p5, p0, Lgp/e;->b:Lgp/f;

    invoke-virtual {p1}, Lgp/G;->b()LQo/c;

    move-result-object v0

    invoke-virtual {p5, p4, v0}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object p4

    invoke-virtual {p3, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_33

    :cond_4d
    return-object p3
.end method

.method public final j(Lgp/G;LOo/m;Lkp/E;)Ljava/lang/Object;
    .registers 4

    const-string p1, "proto"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public final k(Lgp/G$a;LOo/f;)Ljava/util/List;
    .registers 7

    const-string v0, "container"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "proto"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lgp/e;->a:Lfp/a;

    invoke-virtual {v0}, Lfp/a;->d()LUo/h$f;

    move-result-object v0

    invoke-virtual {p2, v0}, LUo/h$d;->k(LUo/h$f;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    if-nez p2, :cond_1a

    sget-object p2, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_1a
    check-cast p2, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p2}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_29
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_43

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LOo/a;

    iget-object v2, p0, Lgp/e;->b:Lgp/f;

    invoke-virtual {p1}, Lgp/G;->b()LQo/c;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Lgp/f;->a(LOo/a;LQo/c;)Lvo/d;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_29

    :cond_43
    return-object v0
.end method
