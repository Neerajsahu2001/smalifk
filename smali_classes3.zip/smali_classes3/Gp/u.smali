.class public interface abstract Lgp/u;
.super Ljava/lang/Object;
.source "ErrorReporter.java"


# static fields
.field public static final a:Lgp/u;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lgp/u$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lgp/u;->a:Lgp/u;

    return-void
.end method


# virtual methods
.method public abstract a(Lxo/b;Ljava/util/ArrayList;)V
.end method

.method public abstract b(Luo/b;)V
.end method
