.class public final Lhp/c$a;
.super Ljava/lang/Object;
.source "BuiltInsPackageFragmentImpl.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lhp/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(LTo/c;Ljp/n;Luo/B;Ljava/io/InputStream;)Lhp/c;
    .registers 14

    const-string v0, "fqName"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "storageManager"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "module"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_f
    sget-object v0, LPo/a;->f:LPo/a;

    invoke-static {p3}, LPo/a$a;->a(Ljava/io/InputStream;)LPo/a;

    move-result-object v0

    invoke-virtual {v0}, LPo/a;->g()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_30

    invoke-static {}, LUo/f;->c()LUo/f;

    move-result-object v1

    invoke-static {v1}, LPo/b;->a(LUo/f;)V

    sget-object v3, LOo/l;->k:LUo/r;

    check-cast v3, LUo/b;

    invoke-virtual {v3, p3, v1}, LUo/b;->d(Ljava/io/InputStream;LUo/f;)LUo/p;

    move-result-object v1

    check-cast v1, LOo/l;

    goto :goto_31

    :catchall_2e
    move-exception p0

    goto :goto_76

    :cond_30
    move-object v1, v2

    :goto_31
    new-instance v3, LUn/j;

    invoke-direct {v3, v1, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_36
    .catchall {:try_start_f .. :try_end_36} :catchall_2e

    invoke-static {p3, v2}, Lcom/facebook/imagepipeline/producers/r0;->b(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    invoke-virtual {v3}, LUn/j;->a()Ljava/lang/Object;

    move-result-object p3

    move-object v8, p3

    check-cast v8, LOo/l;

    invoke-virtual {v3}, LUn/j;->b()Ljava/lang/Object;

    move-result-object p3

    move-object v9, p3

    check-cast v9, LPo/a;

    if-eqz v8, :cond_53

    new-instance p3, Lhp/c;

    move-object v4, p3

    move-object v5, p0

    move-object v6, p1

    move-object v7, p2

    invoke-direct/range {v4 .. v9}, Lgp/t;-><init>(LTo/c;Ljp/n;Luo/B;LOo/l;LPo/a;)V

    return-object p3

    :cond_53
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Kotlin built-in definition format version is not supported: expected "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object p2, LPo/a;->f:LPo/a;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, ", actual "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, ". Please update Kotlin"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0

    :goto_76
    :try_start_76
    throw p0
    :try_end_77
    .catchall {:try_start_76 .. :try_end_77} :catchall_77

    :catchall_77
    move-exception p1

    invoke-static {p3, p0}, Lcom/facebook/imagepipeline/producers/r0;->b(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1
.end method
