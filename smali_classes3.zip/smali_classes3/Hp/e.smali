.class public final LHp/e;
.super Ljava/lang/Object;
.source "TaskRunner.kt"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:LHp/d;


# direct methods
.method constructor <init>(LHp/d;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LHp/e;->a:LHp/d;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    :cond_0
    :goto_0
    iget-object v0, p0, LHp/e;->a:LHp/d;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LHp/e;->a:LHp/d;

    invoke-virtual {v1}, LHp/d;->d()LHp/a;

    move-result-object v1
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_82

    monitor-exit v0

    if-eqz v1, :cond_81

    invoke-virtual {v1}, LHp/a;->d()LHp/c;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-static {}, LHp/d;->a()Ljava/util/logging/Logger;

    move-result-object v2

    sget-object v3, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    invoke-virtual {v2, v3}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    move-result v2

    if-eqz v2, :cond_31

    invoke-virtual {v0}, LHp/c;->h()LHp/d;

    move-result-object v3

    invoke-virtual {v3}, LHp/d;->f()LHp/d$a;

    move-result-object v3

    invoke-interface {v3}, LHp/d$a;->nanoTime()J

    move-result-wide v3

    const-string v5, "starting"

    invoke-static {v1, v0, v5}, Lcom/google/android/gms/internal/ads/I0;->a(LHp/a;LHp/c;Ljava/lang/String;)V

    goto :goto_33

    :cond_31
    const-wide/16 v3, -0x1

    :goto_33
    :try_start_33
    iget-object v5, p0, LHp/e;->a:LHp/d;

    invoke-static {v5, v1}, LHp/d;->b(LHp/d;LHp/a;)V
    :try_end_38
    .catchall {:try_start_33 .. :try_end_38} :catchall_59

    :try_start_38
    sget-object v5, LUn/r;->a:LUn/r;
    :try_end_3a
    .catchall {:try_start_38 .. :try_end_3a} :catchall_57

    if-eqz v2, :cond_0

    invoke-virtual {v0}, LHp/c;->h()LHp/d;

    move-result-object v2

    invoke-virtual {v2}, LHp/d;->f()LHp/d$a;

    move-result-object v2

    invoke-interface {v2}, LHp/d$a;->nanoTime()J

    move-result-wide v5

    sub-long/2addr v5, v3

    invoke-static {v5, v6}, Lcom/google/android/gms/internal/ads/I0;->b(J)Ljava/lang/String;

    move-result-object v2

    const-string v3, "finished run in "

    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v0, v2}, Lcom/google/android/gms/internal/ads/I0;->a(LHp/a;LHp/c;Ljava/lang/String;)V

    goto :goto_0

    :catchall_57
    move-exception v5

    goto :goto_64

    :catchall_59
    move-exception v5

    :try_start_5a
    iget-object v6, p0, LHp/e;->a:LHp/d;

    invoke-virtual {v6}, LHp/d;->f()LHp/d$a;

    move-result-object v6

    invoke-interface {v6, p0}, LHp/d$a;->execute(Ljava/lang/Runnable;)V

    throw v5
    :try_end_64
    .catchall {:try_start_5a .. :try_end_64} :catchall_57

    :goto_64
    if-eqz v2, :cond_80

    invoke-virtual {v0}, LHp/c;->h()LHp/d;

    move-result-object v2

    invoke-virtual {v2}, LHp/d;->f()LHp/d$a;

    move-result-object v2

    invoke-interface {v2}, LHp/d$a;->nanoTime()J

    move-result-wide v6

    sub-long/2addr v6, v3

    invoke-static {v6, v7}, Lcom/google/android/gms/internal/ads/I0;->b(J)Ljava/lang/String;

    move-result-object v2

    const-string v3, "failed a run in "

    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v0, v2}, Lcom/google/android/gms/internal/ads/I0;->a(LHp/a;LHp/c;Ljava/lang/String;)V

    :cond_80
    throw v5

    :cond_81
    return-void

    :catchall_82
    move-exception v1

    monitor-exit v0

    throw v1
.end method
