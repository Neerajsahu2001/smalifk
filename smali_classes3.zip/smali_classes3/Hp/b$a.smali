.class final synthetic Lhp/b$a;
.super Lkotlin/jvm/internal/l;
.source "BuiltInsLoaderImpl.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lhp/b;->a(Ljp/n;Luo/B;Ljava/lang/Iterable;Lwo/c;Lwo/a;Z)Luo/F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/l;",
        "Leo/l<",
        "Ljava/lang/String;",
        "Ljava/io/InputStream;",
        ">;"
    }
.end annotation


# virtual methods
.method public final getName()Ljava/lang/String;
    .registers 2

    const-string v0, "loadResource"

    return-object v0
.end method

.method public final getOwner()Llo/f;
    .registers 2

    const-class v0, Lhp/d;

    invoke-static {v0}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v0

    return-object v0
.end method

.method public final getSignature()Ljava/lang/String;
    .registers 2

    const-string v0, "loadResource(Ljava/lang/String;)Ljava/io/InputStream;"

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/lang/String;

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lkotlin/jvm/internal/e;->b:Ljava/lang/Object;

    check-cast v0, Lhp/d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Lhp/d;->a(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p1

    return-object p1
.end method
