.class public final Lhp/b;
.super Ljava/lang/Object;
.source "BuiltInsLoaderImpl.kt"

# interfaces
.implements Lro/a;


# instance fields
.field private final b:Lhp/d;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lhp/d;

    invoke-direct {v0}, Lhp/d;-><init>()V

    iput-object v0, p0, Lhp/b;->b:Lhp/d;

    return-void
.end method


# virtual methods
.method public a(Ljp/n;Luo/B;Ljava/lang/Iterable;Lwo/c;Lwo/a;Z)Luo/F;
    .registers 28
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljp/n;",
            "Luo/B;",
            "Ljava/lang/Iterable<",
            "+",
            "Lwo/b;",
            ">;",
            "Lwo/c;",
            "Lwo/a;",
            "Z)",
            "Luo/F;"
        }
    .end annotation

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v0, "storageManager"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "builtInsModule"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "classDescriptorFactories"

    move-object/from16 v8, p3

    invoke-static {v8, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "platformDependentDeclarationFilter"

    move-object/from16 v12, p4

    invoke-static {v12, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "additionalClassPartsProvider"

    move-object/from16 v11, p5

    invoke-static {v11, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lro/n;->o:Ljava/util/Set;

    new-instance v3, Lhp/b$a;

    const/4 v4, 0x1

    move-object/from16 v14, p0

    iget-object v5, v14, Lhp/b;->b:Lhp/d;

    invoke-direct {v3, v4, v5}, Lkotlin/jvm/internal/l;-><init>(ILjava/lang/Object;)V

    const-string v4, "packageFqNames"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    new-instance v15, Ljava/util/ArrayList;

    invoke-static {v0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v4

    invoke-direct {v15, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_43
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_74

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LTo/c;

    sget-object v5, Lhp/a;->m:Lhp/a;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v4}, Lhp/a;->m(LTo/c;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lhp/b$a;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/InputStream;

    if-eqz v6, :cond_68

    invoke-static {v4, v1, v2, v6}, Lhp/c$a;->a(LTo/c;Ljp/n;Luo/B;Ljava/io/InputStream;)Lhp/c;

    move-result-object v4

    invoke-virtual {v15, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_43

    :cond_68
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Resource not found in classpath: "

    invoke-static {v1, v5}, Landroidx/coordinatorlayout/widget/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_74
    new-instance v13, Luo/G;

    move-object v5, v13

    invoke-direct {v13, v15}, Luo/G;-><init>(Ljava/util/ArrayList;)V

    new-instance v6, Luo/D;

    move-object v9, v6

    invoke-direct {v6, v1, v2}, Luo/D;-><init>(Ljp/n;Luo/B;)V

    new-instance v10, Lgp/l;

    move-object v0, v10

    new-instance v4, Lgp/q;

    move-object v3, v4

    invoke-direct {v4, v13}, Lgp/q;-><init>(Luo/F;)V

    new-instance v7, Lgp/e;

    move-object v4, v7

    sget-object v8, Lhp/a;->m:Lhp/a;

    invoke-direct {v7, v2, v6, v8}, Lgp/e;-><init>(Luo/B;Luo/D;Lhp/a;)V

    sget-object v6, Lgp/u;->a:Lgp/u;

    sget-object v7, Lgp/v$a;->a:Lgp/v$a;

    invoke-static {}, Lgp/k$a;->a()Lgp/k$a$a;

    move-result-object v16

    move-object/from16 v18, v10

    move-object/from16 v10, v16

    invoke-virtual {v8}, Lfp/a;->e()LUo/f;

    move-result-object v8

    move-object/from16 v19, v13

    move-object v13, v8

    new-instance v8, LD2/o;

    move-object/from16 v20, v15

    move-object v15, v8

    invoke-direct {v8, v1}, LD2/o;-><init>(Ljp/n;)V

    const/4 v8, 0x0

    move-object v14, v8

    const/high16 v17, 0xd0000

    const/16 v16, 0x0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v8, p3

    move-object/from16 v11, p5

    move-object/from16 v12, p4

    invoke-direct/range {v0 .. v17}, Lgp/l;-><init>(Ljp/n;Luo/B;Lgp/i;Lgp/d;Luo/F;Lgp/u;Lgp/v;Ljava/lang/Iterable;Luo/D;Lgp/k$a$a;Lwo/a;Lwo/c;LUo/f;Llp/m;LD2/o;Ljava/util/List;I)V

    invoke-virtual/range {v20 .. v20}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_c3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_d5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lhp/c;

    move-object/from16 v2, v18

    invoke-virtual {v1, v2}, Lgp/t;->N0(Lgp/l;)V

    goto :goto_c3

    :cond_d5
    return-object v19
.end method
