.class public final LAo/e;
.super LAo/v;
.source "ReflectJavaAnnotation.kt"

# interfaces
.implements LKo/a;


# instance fields
.field private final a:Ljava/lang/annotation/Annotation;


# direct methods
.method public constructor <init>(Ljava/lang/annotation/Annotation;)V
    .registers 3

    const-string v0, "annotation"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LAo/v;-><init>()V

    iput-object p1, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    return-void
.end method


# virtual methods
.method public final G()Ljava/lang/annotation/Annotation;
    .registers 2

    iget-object v0, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    return-object v0
.end method

.method public final d()LTo/b;
    .registers 2

    iget-object v0, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    invoke-static {v0}, Lq3/m;->c(Ljava/lang/annotation/Annotation;)Llo/d;

    move-result-object v0

    invoke-static {v0}, Lq3/m;->d(Llo/d;)Ljava/lang/Class;

    move-result-object v0

    invoke-static {v0}, LAo/d;->a(Ljava/lang/Class;)LTo/b;

    move-result-object v0

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, LAo/e;

    if-eqz v0, :cond_e

    check-cast p1, LAo/e;

    iget-object p1, p1, LAo/e;->a:Ljava/lang/annotation/Annotation;

    iget-object v0, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    if-ne v0, p1, :cond_e

    const/4 p1, 0x1

    goto :goto_f

    :cond_e
    const/4 p1, 0x0

    :goto_f
    return p1
.end method

.method public final getArguments()Ljava/util/ArrayList;
    .registers 11

    iget-object v0, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    invoke-static {v0}, Lq3/m;->c(Ljava/lang/annotation/Annotation;)Llo/d;

    move-result-object v1

    invoke-static {v1}, Lq3/m;->d(Llo/d;)Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v1

    const-string v2, "annotation.annotationClass.java.declaredMethods"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Ljava/util/ArrayList;

    array-length v3, v1

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    array-length v3, v1

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_1c
    if-ge v5, v3, :cond_78

    aget-object v6, v1, v5

    new-array v7, v4, [Ljava/lang/Object;

    invoke-virtual {v6, v0, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const-string v8, "method.invoke(annotation)"

    invoke-static {v7, v8}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    sget v9, LAo/d;->e:I

    const-class v9, Ljava/lang/Enum;

    invoke-virtual {v9, v8}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v8

    if-eqz v8, :cond_49

    new-instance v8, LAo/w;

    check-cast v7, Ljava/lang/Enum;

    invoke-direct {v8, v6, v7}, LAo/w;-><init>(LTo/f;Ljava/lang/Enum;)V

    goto :goto_72

    :cond_49
    instance-of v8, v7, Ljava/lang/annotation/Annotation;

    if-eqz v8, :cond_55

    new-instance v8, LAo/g;

    check-cast v7, Ljava/lang/annotation/Annotation;

    invoke-direct {v8, v6, v7}, LAo/g;-><init>(LTo/f;Ljava/lang/annotation/Annotation;)V

    goto :goto_72

    :cond_55
    instance-of v8, v7, [Ljava/lang/Object;

    if-eqz v8, :cond_61

    new-instance v8, LAo/h;

    check-cast v7, [Ljava/lang/Object;

    invoke-direct {v8, v6, v7}, LAo/h;-><init>(LTo/f;[Ljava/lang/Object;)V

    goto :goto_72

    :cond_61
    instance-of v8, v7, Ljava/lang/Class;

    if-eqz v8, :cond_6d

    new-instance v8, LAo/s;

    check-cast v7, Ljava/lang/Class;

    invoke-direct {v8, v6, v7}, LAo/s;-><init>(LTo/f;Ljava/lang/Class;)V

    goto :goto_72

    :cond_6d
    new-instance v8, LAo/y;

    invoke-direct {v8, v7, v6}, LAo/y;-><init>(Ljava/lang/Object;LTo/f;)V

    :goto_72
    invoke-virtual {v2, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_1c

    :cond_78
    return-object v2
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method public final j()LAo/r;
    .registers 3

    new-instance v0, LAo/r;

    iget-object v1, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    invoke-static {v1}, Lq3/m;->c(Ljava/lang/annotation/Annotation;)Llo/d;

    move-result-object v1

    invoke-static {v1}, Lq3/m;->d(Llo/d;)Ljava/lang/Class;

    move-result-object v1

    invoke-direct {v0, v1}, LAo/r;-><init>(Ljava/lang/Class;)V

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-class v1, LAo/e;

    const-string v2, ": "

    invoke-static {v1, v0, v2}, LO0/d;->d(Ljava/lang/Class;Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, p0, LAo/e;->a:Ljava/lang/annotation/Annotation;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
