.class public final LAo/h;
.super LAo/f;
.source "ReflectJavaAnnotationArguments.kt"

# interfaces
.implements LKo/e;


# instance fields
.field private final b:[Ljava/lang/Object;


# direct methods
.method public constructor <init>(LTo/f;[Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0, p1}, LAo/f;-><init>(LTo/f;)V

    iput-object p2, p0, LAo/h;->b:[Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final c()Ljava/util/ArrayList;
    .registers 8

    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, LAo/h;->b:[Ljava/lang/Object;

    array-length v2, v1

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    array-length v2, v1

    const/4 v3, 0x0

    :goto_a
    if-ge v3, v2, :cond_57

    aget-object v4, v1, v3

    invoke-static {v4}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    sget v6, LAo/d;->e:I

    const-class v6, Ljava/lang/Enum;

    invoke-virtual {v6, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_28

    new-instance v5, LAo/w;

    check-cast v4, Ljava/lang/Enum;

    invoke-direct {v5, v6, v4}, LAo/w;-><init>(LTo/f;Ljava/lang/Enum;)V

    goto :goto_51

    :cond_28
    instance-of v5, v4, Ljava/lang/annotation/Annotation;

    if-eqz v5, :cond_34

    new-instance v5, LAo/g;

    check-cast v4, Ljava/lang/annotation/Annotation;

    invoke-direct {v5, v6, v4}, LAo/g;-><init>(LTo/f;Ljava/lang/annotation/Annotation;)V

    goto :goto_51

    :cond_34
    instance-of v5, v4, [Ljava/lang/Object;

    if-eqz v5, :cond_40

    new-instance v5, LAo/h;

    check-cast v4, [Ljava/lang/Object;

    invoke-direct {v5, v6, v4}, LAo/h;-><init>(LTo/f;[Ljava/lang/Object;)V

    goto :goto_51

    :cond_40
    instance-of v5, v4, Ljava/lang/Class;

    if-eqz v5, :cond_4c

    new-instance v5, LAo/s;

    check-cast v4, Ljava/lang/Class;

    invoke-direct {v5, v6, v4}, LAo/s;-><init>(LTo/f;Ljava/lang/Class;)V

    goto :goto_51

    :cond_4c
    new-instance v5, LAo/y;

    invoke-direct {v5, v4, v6}, LAo/y;-><init>(Ljava/lang/Object;LTo/f;)V

    :goto_51
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_a

    :cond_57
    return-object v0
.end method
