.class public final LAo/G;
.super LAo/v;
.source "ReflectJavaValueParameter.kt"

# interfaces
.implements LKo/z;


# instance fields
.field private final a:LAo/E;

.field private final b:[Ljava/lang/annotation/Annotation;

.field private final c:Ljava/lang/String;

.field private final d:Z


# direct methods
.method public constructor <init>(LAo/E;[Ljava/lang/annotation/Annotation;Ljava/lang/String;Z)V
    .registers 6

    const-string v0, "reflectAnnotations"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LAo/v;-><init>()V

    iput-object p1, p0, LAo/G;->a:LAo/E;

    iput-object p2, p0, LAo/G;->b:[Ljava/lang/annotation/Annotation;

    iput-object p3, p0, LAo/G;->c:Ljava/lang/String;

    iput-boolean p4, p0, LAo/G;->d:Z

    return-void
.end method


# virtual methods
.method public final b()Z
    .registers 2

    iget-boolean v0, p0, LAo/G;->d:Z

    return v0
.end method

.method public final f(LTo/c;)LKo/a;
    .registers 3

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LAo/G;->b:[Ljava/lang/annotation/Annotation;

    invoke-static {v0, p1}, LMo/l;->d([Ljava/lang/annotation/Annotation;LTo/c;)LAo/e;

    move-result-object p1

    return-object p1
.end method

.method public final getAnnotations()Ljava/util/Collection;
    .registers 2

    iget-object v0, p0, LAo/G;->b:[Ljava/lang/annotation/Annotation;

    invoke-static {v0}, LMo/l;->e([Ljava/lang/annotation/Annotation;)Ljava/util/ArrayList;

    move-result-object v0

    return-object v0
.end method

.method public final getName()LTo/f;
    .registers 2

    iget-object v0, p0, LAo/G;->c:Ljava/lang/String;

    if-eqz v0, :cond_9

    invoke-static {v0}, LTo/f;->f(Ljava/lang/String;)LTo/f;

    move-result-object v0

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    return-object v0
.end method

.method public final getType()LKo/w;
    .registers 2

    iget-object v0, p0, LAo/G;->a:LAo/E;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-class v1, LAo/G;

    const-string v2, ": "

    invoke-static {v1, v0, v2}, LO0/d;->d(Ljava/lang/Class;Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-boolean v1, p0, LAo/G;->d:Z

    if-eqz v1, :cond_13

    const-string v1, "vararg "

    goto :goto_15

    :cond_13
    const-string v1, ""

    :goto_15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LAo/G;->getName()LTo/f;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LAo/G;->a:LAo/E;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
