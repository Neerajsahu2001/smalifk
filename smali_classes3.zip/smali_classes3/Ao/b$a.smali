.class public final LAo/b$a;
.super Ljava/lang/Object;
.source "ReflectJavaClass.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAo/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/lang/reflect/Method;

.field private final b:Ljava/lang/reflect/Method;

.field private final c:Ljava/lang/reflect/Method;

.field private final d:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAo/b$a;->a:Ljava/lang/reflect/Method;

    iput-object p2, p0, LAo/b$a;->b:Ljava/lang/reflect/Method;

    iput-object p3, p0, LAo/b$a;->c:Ljava/lang/reflect/Method;

    iput-object p4, p0, LAo/b$a;->d:Ljava/lang/reflect/Method;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/reflect/Method;
    .registers 2

    iget-object v0, p0, LAo/b$a;->b:Ljava/lang/reflect/Method;

    return-object v0
.end method

.method public final b()Ljava/lang/reflect/Method;
    .registers 2

    iget-object v0, p0, LAo/b$a;->d:Ljava/lang/reflect/Method;

    return-object v0
.end method

.method public final c()Ljava/lang/reflect/Method;
    .registers 2

    iget-object v0, p0, LAo/b$a;->c:Ljava/lang/reflect/Method;

    return-object v0
.end method

.method public final d()Ljava/lang/reflect/Method;
    .registers 2

    iget-object v0, p0, LAo/b$a;->a:Ljava/lang/reflect/Method;

    return-object v0
.end method
