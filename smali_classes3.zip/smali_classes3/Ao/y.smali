.class public final LAo/y;
.super LAo/f;
.source "ReflectJavaAnnotationArguments.kt"

# interfaces
.implements LKo/o;


# instance fields
.field private final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;LTo/f;)V
    .registers 3

    invoke-direct {p0, p2}, LAo/f;-><init>(LTo/f;)V

    iput-object p1, p0, LAo/y;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final getValue()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LAo/y;->b:Ljava/lang/Object;

    return-object v0
.end method
