.class public abstract LAo/z;
.super LAo/v;
.source "ReflectJavaMember.kt"

# interfaces
.implements LKo/d;
.implements LKo/r;
.implements LKo/p;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, LAo/v;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract G()Ljava/lang/reflect/Member;
.end method

.method protected final H([Ljava/lang/reflect/Type;[[Ljava/lang/annotation/Annotation;Z)Ljava/util/ArrayList;
    .registers 15

    new-instance v0, Ljava/util/ArrayList;

    array-length v1, p1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    sget-object v1, LAo/c;->a:LAo/c;

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v2

    invoke-virtual {v1, v2}, LAo/c;->b(Ljava/lang/reflect/Member;)Ljava/util/ArrayList;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1a

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    array-length v4, p1

    sub-int/2addr v3, v4

    goto :goto_1b

    :cond_1a
    const/4 v3, 0x0

    :goto_1b
    array-length v4, p1

    const/4 v5, 0x0

    :goto_1d
    if-ge v5, v4, :cond_c3

    aget-object v6, p1, v5

    const-string v7, "type"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v7, v6, Ljava/lang/Class;

    if-eqz v7, :cond_39

    move-object v8, v6

    check-cast v8, Ljava/lang/Class;

    invoke-virtual {v8}, Ljava/lang/Class;->isPrimitive()Z

    move-result v9

    if-eqz v9, :cond_39

    new-instance v6, LAo/C;

    invoke-direct {v6, v8}, LAo/C;-><init>(Ljava/lang/Class;)V

    goto :goto_62

    :cond_39
    instance-of v8, v6, Ljava/lang/reflect/GenericArrayType;

    if-nez v8, :cond_5c

    if-eqz v7, :cond_49

    move-object v7, v6

    check-cast v7, Ljava/lang/Class;

    invoke-virtual {v7}, Ljava/lang/Class;->isArray()Z

    move-result v7

    if-eqz v7, :cond_49

    goto :goto_5c

    :cond_49
    instance-of v7, v6, Ljava/lang/reflect/WildcardType;

    if-eqz v7, :cond_56

    new-instance v7, LAo/H;

    check-cast v6, Ljava/lang/reflect/WildcardType;

    invoke-direct {v7, v6}, LAo/H;-><init>(Ljava/lang/reflect/WildcardType;)V

    :goto_54
    move-object v6, v7

    goto :goto_62

    :cond_56
    new-instance v7, LAo/t;

    invoke-direct {v7, v6}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_54

    :cond_5c
    :goto_5c
    new-instance v7, LAo/i;

    invoke-direct {v7, v6}, LAo/i;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_54

    :goto_62
    if-eqz v1, :cond_ab

    add-int v7, v5, v3

    invoke-static {v7, v1}, Lkotlin/collections/q;->w(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    if-eqz v7, :cond_6f

    goto :goto_ac

    :cond_6f
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "No parameter with index "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p3, 0x2b

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, " (name="

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LAo/z;->getName()LTo/f;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p3, " type="

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p3, ") in "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_ab
    const/4 v7, 0x0

    :goto_ac
    if-eqz p3, :cond_b4

    array-length v8, p1

    const/4 v9, 0x1

    sub-int/2addr v8, v9

    if-ne v5, v8, :cond_b4

    goto :goto_b5

    :cond_b4
    const/4 v9, 0x0

    :goto_b5
    new-instance v8, LAo/G;

    aget-object v10, p2, v5

    invoke-direct {v8, v6, v10, v7, v9}, LAo/G;-><init>(LAo/E;[Ljava/lang/annotation/Annotation;Ljava/lang/String;Z)V

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_1d

    :cond_c3
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, LAo/z;

    if-eqz v0, :cond_16

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    check-cast p1, LAo/z;

    invoke-virtual {p1}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object p1

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_16

    const/4 p1, 0x1

    goto :goto_17

    :cond_16
    const/4 p1, 0x0

    :goto_17
    return p1
.end method

.method public final f(LTo/c;)LKo/a;
    .registers 4

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type java.lang.reflect.AnnotatedElement"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/reflect/AnnotatedElement;

    invoke-interface {v0}, Ljava/lang/reflect/AnnotatedElement;->getDeclaredAnnotations()[Ljava/lang/annotation/Annotation;

    move-result-object v0

    if-eqz v0, :cond_1b

    invoke-static {v0, p1}, LMo/l;->d([Ljava/lang/annotation/Annotation;LTo/c;)LAo/e;

    move-result-object p1

    goto :goto_1c

    :cond_1b
    const/4 p1, 0x0

    :goto_1c
    return-object p1
.end method

.method public final g()LAo/r;
    .registers 4

    new-instance v0, LAo/r;

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/reflect/Member;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v1

    const-string v2, "member.declaringClass"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1}, LAo/r;-><init>(Ljava/lang/Class;)V

    return-object v0
.end method

.method public final getAnnotations()Ljava/util/Collection;
    .registers 3

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type java.lang.reflect.AnnotatedElement"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/reflect/AnnotatedElement;

    invoke-interface {v0}, Ljava/lang/reflect/AnnotatedElement;->getDeclaredAnnotations()[Ljava/lang/annotation/Annotation;

    move-result-object v0

    if-eqz v0, :cond_16

    invoke-static {v0}, LMo/l;->e([Ljava/lang/annotation/Annotation;)Ljava/util/ArrayList;

    move-result-object v0

    goto :goto_18

    :cond_16
    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :goto_18
    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method

.method public final getName()LTo/f;
    .registers 2

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/reflect/Member;->getName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_f

    invoke-static {v0}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v0

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    if-nez v0, :cond_14

    sget-object v0, LTo/h;->a:LTo/f;

    :cond_14
    return-object v0
.end method

.method public final getVisibility()Luo/f0;
    .registers 3

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/reflect/Member;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isPublic(I)Z

    move-result v1

    if-eqz v1, :cond_11

    sget-object v0, Luo/e0$h;->c:Luo/e0$h;

    goto :goto_2e

    :cond_11
    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isPrivate(I)Z

    move-result v1

    if-eqz v1, :cond_1a

    sget-object v0, Luo/e0$e;->c:Luo/e0$e;

    goto :goto_2e

    :cond_1a
    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isProtected(I)Z

    move-result v1

    if-eqz v1, :cond_2c

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v0

    if-eqz v0, :cond_29

    sget-object v0, Lyo/c;->c:Lyo/c;

    goto :goto_2e

    :cond_29
    sget-object v0, Lyo/b;->c:Lyo/b;

    goto :goto_2e

    :cond_2c
    sget-object v0, Lyo/a;->c:Lyo/a;

    :goto_2e
    return-object v0
.end method

.method public final hashCode()I
    .registers 2

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public final isAbstract()Z
    .registers 2

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/reflect/Member;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    move-result v0

    return v0
.end method

.method public final isFinal()Z
    .registers 2

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/reflect/Member;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isFinal(I)Z

    move-result v0

    return v0
.end method

.method public final isStatic()Z
    .registers 2

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/reflect/Member;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LAo/z;->G()Ljava/lang/reflect/Member;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
