.class public final LAo/x;
.super LAo/z;
.source "ReflectJavaField.kt"

# interfaces
.implements LKo/n;


# instance fields
.field private final a:Ljava/lang/reflect/Field;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Field;)V
    .registers 3

    const-string v0, "member"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LAo/z;-><init>()V

    iput-object p1, p0, LAo/x;->a:Ljava/lang/reflect/Field;

    return-void
.end method


# virtual methods
.method public final C()Z
    .registers 2

    iget-object v0, p0, LAo/x;->a:Ljava/lang/reflect/Field;

    invoke-virtual {v0}, Ljava/lang/reflect/Field;->isEnumConstant()Z

    move-result v0

    return v0
.end method

.method public final G()Ljava/lang/reflect/Member;
    .registers 2

    iget-object v0, p0, LAo/x;->a:Ljava/lang/reflect/Field;

    return-object v0
.end method

.method public final I()Ljava/lang/reflect/Field;
    .registers 2

    iget-object v0, p0, LAo/x;->a:Ljava/lang/reflect/Field;

    return-object v0
.end method

.method public final getType()LKo/w;
    .registers 5

    iget-object v0, p0, LAo/x;->a:Ljava/lang/reflect/Field;

    invoke-virtual {v0}, Ljava/lang/reflect/Field;->getGenericType()Ljava/lang/reflect/Type;

    move-result-object v0

    const-string v1, "member.genericType"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v1, v0, Ljava/lang/Class;

    if-eqz v1, :cond_1e

    move-object v2, v0

    check-cast v2, Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Class;->isPrimitive()Z

    move-result v3

    if-eqz v3, :cond_1e

    new-instance v0, LAo/C;

    invoke-direct {v0, v2}, LAo/C;-><init>(Ljava/lang/Class;)V

    goto :goto_47

    :cond_1e
    instance-of v2, v0, Ljava/lang/reflect/GenericArrayType;

    if-nez v2, :cond_41

    if-eqz v1, :cond_2e

    move-object v1, v0

    check-cast v1, Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Class;->isArray()Z

    move-result v1

    if-eqz v1, :cond_2e

    goto :goto_41

    :cond_2e
    instance-of v1, v0, Ljava/lang/reflect/WildcardType;

    if-eqz v1, :cond_3b

    new-instance v1, LAo/H;

    check-cast v0, Ljava/lang/reflect/WildcardType;

    invoke-direct {v1, v0}, LAo/H;-><init>(Ljava/lang/reflect/WildcardType;)V

    :goto_39
    move-object v0, v1

    goto :goto_47

    :cond_3b
    new-instance v1, LAo/t;

    invoke-direct {v1, v0}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_39

    :cond_41
    :goto_41
    new-instance v1, LAo/i;

    invoke-direct {v1, v0}, LAo/i;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_39

    :goto_47
    return-object v0
.end method
