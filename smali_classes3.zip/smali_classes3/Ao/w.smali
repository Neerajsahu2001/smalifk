.class public final LAo/w;
.super LAo/f;
.source "ReflectJavaAnnotationArguments.kt"

# interfaces
.implements LKo/m;


# instance fields
.field private final b:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Enum<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LTo/f;Ljava/lang/Enum;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTo/f;",
            "Ljava/lang/Enum<",
            "*>;)V"
        }
    .end annotation

    invoke-direct {p0, p1}, LAo/f;-><init>(LTo/f;)V

    iput-object p2, p0, LAo/w;->b:Ljava/lang/Enum;

    return-void
.end method


# virtual methods
.method public final d()LTo/b;
    .registers 3

    iget-object v0, p0, LAo/w;->b:Ljava/lang/Enum;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->isEnum()Z

    move-result v1

    if-eqz v1, :cond_d

    goto :goto_11

    :cond_d
    invoke-virtual {v0}, Ljava/lang/Class;->getEnclosingClass()Ljava/lang/Class;

    move-result-object v0

    :goto_11
    const-string v1, "enumClass"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LAo/d;->a(Ljava/lang/Class;)LTo/b;

    move-result-object v0

    return-object v0
.end method

.method public final e()LTo/f;
    .registers 2

    iget-object v0, p0, LAo/w;->b:Ljava/lang/Enum;

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v0

    return-object v0
.end method
