.class public abstract LAo/v;
.super Ljava/lang/Object;
.source "ReflectJavaElement.kt"

# interfaces
.implements LKo/l;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
