.class public final LAo/r;
.super LAo/v;
.source "ReflectJavaClass.kt"

# interfaces
.implements LKo/d;
.implements LKo/r;
.implements LKo/g;


# instance fields
.field private final a:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Class;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    const-string v0, "klass"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LAo/v;-><init>()V

    iput-object p1, p0, LAo/r;->a:Ljava/lang/Class;

    return-void
.end method


# virtual methods
.method public final D()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->isInterface()Z

    move-result v0

    return v0
.end method

.method public final G()Ljava/lang/Class;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    return-object v0
.end method

.method public final c()LTo/c;
    .registers 3

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-static {v0}, LAo/d;->a(Ljava/lang/Class;)LTo/b;

    move-result-object v0

    invoke-virtual {v0}, LTo/b;->b()LTo/c;

    move-result-object v0

    const-string v1, "klass.classId.asSingleFqName()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, LAo/r;

    if-eqz v0, :cond_12

    check-cast p1, LAo/r;

    iget-object p1, p1, LAo/r;->a:Ljava/lang/Class;

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_12

    const/4 p1, 0x1

    goto :goto_13

    :cond_12
    const/4 p1, 0x0

    :goto_13
    return p1
.end method

.method public final f(LTo/c;)LKo/a;
    .registers 3

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredAnnotations()[Ljava/lang/annotation/Annotation;

    move-result-object v0

    if-eqz v0, :cond_14

    invoke-static {v0, p1}, LMo/l;->d([Ljava/lang/annotation/Annotation;LTo/c;)LAo/e;

    move-result-object p1

    goto :goto_15

    :cond_14
    const/4 p1, 0x0

    :goto_15
    return-object p1
.end method

.method public final getAnnotations()Ljava/util/Collection;
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredAnnotations()[Ljava/lang/annotation/Annotation;

    move-result-object v0

    if-eqz v0, :cond_f

    invoke-static {v0}, LMo/l;->e([Ljava/lang/annotation/Annotation;)Ljava/util/ArrayList;

    move-result-object v0

    goto :goto_11

    :cond_f
    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :goto_11
    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method

.method public final getName()LTo/f;
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v0

    return-object v0
.end method

.method public final getTypeParameters()Ljava/util/ArrayList;
    .registers 7

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getTypeParameters()[Ljava/lang/reflect/TypeVariable;

    move-result-object v0

    const-string v1, "klass.typeParameters"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/util/ArrayList;

    array-length v2, v0

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    array-length v2, v0

    const/4 v3, 0x0

    :goto_13
    if-ge v3, v2, :cond_22

    aget-object v4, v0, v3

    new-instance v5, LAo/F;

    invoke-direct {v5, v4}, LAo/F;-><init>(Ljava/lang/reflect/TypeVariable;)V

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    :cond_22
    return-object v1
.end method

.method public final getVisibility()Luo/f0;
    .registers 3

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isPublic(I)Z

    move-result v1

    if-eqz v1, :cond_f

    sget-object v0, Luo/e0$h;->c:Luo/e0$h;

    goto :goto_2c

    :cond_f
    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isPrivate(I)Z

    move-result v1

    if-eqz v1, :cond_18

    sget-object v0, Luo/e0$e;->c:Luo/e0$e;

    goto :goto_2c

    :cond_18
    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isProtected(I)Z

    move-result v1

    if-eqz v1, :cond_2a

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v0

    if-eqz v0, :cond_27

    sget-object v0, Lyo/c;->c:Lyo/c;

    goto :goto_2c

    :cond_27
    sget-object v0, Lyo/b;->c:Lyo/b;

    goto :goto_2c

    :cond_2a
    sget-object v0, Lyo/a;->c:Lyo/a;

    :goto_2c
    return-object v0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public final isAbstract()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    move-result v0

    return v0
.end method

.method public final isFinal()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isFinal(I)Z

    move-result v0

    return v0
.end method

.method public final isStatic()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v0

    return v0
.end method

.method public final k()Ljava/util/Collection;
    .registers 3

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredConstructors()[Ljava/lang/reflect/Constructor;

    move-result-object v0

    const-string v1, "klass.declaredConstructors"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/h;->e([Ljava/lang/Object;)Lup/h;

    move-result-object v0

    sget-object v1, LAo/j;->j:LAo/j;

    invoke-static {v0, v1}, Lup/k;->f(Lup/h;Leo/l;)Lup/e;

    move-result-object v0

    sget-object v1, LAo/k;->j:LAo/k;

    invoke-static {v0, v1}, Lup/k;->m(Lup/h;Leo/l;)Lup/z;

    move-result-object v0

    invoke-static {v0}, Lup/k;->q(Lup/h;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method

.method public final l()Ljava/util/Collection;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "LKo/j;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    const-class v1, Ljava/lang/Object;

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d

    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object v0

    :cond_d
    new-instance v2, Lkotlin/jvm/internal/SpreadBuilder;

    const/4 v3, 0x2

    invoke-direct {v2, v3}, Lkotlin/jvm/internal/SpreadBuilder;-><init>(I)V

    invoke-virtual {v0}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    move-result-object v3

    if-nez v3, :cond_1a

    goto :goto_1b

    :cond_1a
    move-object v1, v3

    :goto_1b
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/SpreadBuilder;->a(Ljava/lang/Object;)V

    invoke-virtual {v0}, Ljava/lang/Class;->getGenericInterfaces()[Ljava/lang/reflect/Type;

    move-result-object v0

    const-string v1, "klass.genericInterfaces"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Lkotlin/jvm/internal/SpreadBuilder;->b(Ljava/lang/Object;)V

    invoke-virtual {v2}, Lkotlin/jvm/internal/SpreadBuilder;->c()I

    move-result v0

    new-array v0, v0, [Ljava/lang/reflect/Type;

    invoke-virtual {v2, v0}, Lkotlin/jvm/internal/SpreadBuilder;->d([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-static {v0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_47
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/reflect/Type;

    new-instance v3, LAo/t;

    invoke-direct {v3, v2}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_47

    :cond_5c
    return-object v1
.end method

.method public final m()Ljava/util/ArrayList;
    .registers 7

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-static {v0}, LAo/b;->c(Ljava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_b

    new-array v0, v1, [Ljava/lang/Object;

    :cond_b
    new-instance v2, Ljava/util/ArrayList;

    array-length v3, v0

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    array-length v3, v0

    :goto_12
    if-ge v1, v3, :cond_21

    aget-object v4, v0, v1

    new-instance v5, LAo/D;

    invoke-direct {v5, v4}, LAo/D;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_12

    :cond_21
    return-object v2
.end method

.method public final n()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->isAnnotation()Z

    move-result v0

    return v0
.end method

.method public final o()LAo/r;
    .registers 3

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v0

    if-eqz v0, :cond_e

    new-instance v1, LAo/r;

    invoke-direct {v1, v0}, LAo/r;-><init>(Ljava/lang/Class;)V

    goto :goto_f

    :cond_e
    const/4 v1, 0x0

    :goto_f
    return-object v1
.end method

.method public final p()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-static {v0}, LAo/b;->d(Ljava/lang/Class;)Ljava/lang/Boolean;

    move-result-object v0

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    goto :goto_e

    :cond_d
    const/4 v0, 0x0

    :goto_e
    return v0
.end method

.method public final q()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->isEnum()Z

    move-result v0

    return v0
.end method

.method public final r()Ljava/util/Collection;
    .registers 3

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v0

    const-string v1, "klass.declaredFields"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/h;->e([Ljava/lang/Object;)Lup/h;

    move-result-object v0

    sget-object v1, LAo/l;->j:LAo/l;

    invoke-static {v0, v1}, Lup/k;->f(Lup/h;Leo/l;)Lup/e;

    move-result-object v0

    sget-object v1, LAo/m;->j:LAo/m;

    invoke-static {v0, v1}, Lup/k;->m(Lup/h;Leo/l;)Lup/z;

    move-result-object v0

    invoke-static {v0}, Lup/k;->q(Lup/h;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method

.method public final s()Z
    .registers 2

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-static {v0}, LAo/b;->e(Ljava/lang/Class;)Ljava/lang/Boolean;

    move-result-object v0

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    goto :goto_e

    :cond_d
    const/4 v0, 0x0

    :goto_e
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-class v1, LAo/r;

    const-string v2, ": "

    invoke-static {v1, v0, v2}, LO0/d;->d(Ljava/lang/Class;Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final u()Ljava/util/Collection;
    .registers 3

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredClasses()[Ljava/lang/Class;

    move-result-object v0

    const-string v1, "klass.declaredClasses"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/h;->e([Ljava/lang/Object;)Lup/h;

    move-result-object v0

    sget-object v1, LAo/n;->a:LAo/n;

    invoke-static {v0, v1}, Lup/k;->f(Lup/h;Leo/l;)Lup/e;

    move-result-object v0

    sget-object v1, LAo/o;->a:LAo/o;

    invoke-static {v0, v1}, Lup/k;->n(Lup/h;Leo/l;)Lup/e;

    move-result-object v0

    invoke-static {v0}, Lup/k;->q(Lup/h;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method

.method public final w()Ljava/util/Collection;
    .registers 3

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v0

    const-string v1, "klass.declaredMethods"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/h;->e([Ljava/lang/Object;)Lup/h;

    move-result-object v0

    new-instance v1, LAo/p;

    invoke-direct {v1, p0}, LAo/p;-><init>(LAo/r;)V

    invoke-static {v0, v1}, Lup/k;->e(Lup/h;Leo/l;)Lup/e;

    move-result-object v0

    sget-object v1, LAo/q;->j:LAo/q;

    invoke-static {v0, v1}, Lup/k;->m(Lup/h;Leo/l;)Lup/z;

    move-result-object v0

    invoke-static {v0}, Lup/k;->q(Lup/h;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method

.method public final x()Ljava/util/Collection;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "LKo/j;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LAo/r;->a:Ljava/lang/Class;

    invoke-static {v0}, LAo/b;->b(Ljava/lang/Class;)[Ljava/lang/Class;

    move-result-object v0

    if-eqz v0, :cond_1f

    new-instance v1, Ljava/util/ArrayList;

    array-length v2, v0

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    array-length v2, v0

    const/4 v3, 0x0

    :goto_10
    if-ge v3, v2, :cond_21

    aget-object v4, v0, v3

    new-instance v5, LAo/t;

    invoke-direct {v5, v4}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_10

    :cond_1f
    sget-object v1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_21
    return-object v1
.end method
