.class final synthetic LAo/k;
.super Lkotlin/jvm/internal/l;
.source "ReflectJavaClass.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/l;",
        "Leo/l<",
        "Ljava/lang/reflect/Constructor<",
        "*>;",
        "LAo/u;",
        ">;"
    }
.end annotation


# static fields
.field public static final j:LAo/k;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LAo/k;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/l;-><init>(I)V

    sput-object v0, LAo/k;->j:LAo/k;

    return-void
.end method


# virtual methods
.method public final getName()Ljava/lang/String;
    .registers 2

    const-string v0, "<init>"

    return-object v0
.end method

.method public final getOwner()Llo/f;
    .registers 2

    const-class v0, LAo/u;

    invoke-static {v0}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v0

    return-object v0
.end method

.method public final getSignature()Ljava/lang/String;
    .registers 2

    const-string v0, "<init>(Ljava/lang/reflect/Constructor;)V"

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/lang/reflect/Constructor;

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LAo/u;

    invoke-direct {v0, p1}, LAo/u;-><init>(Ljava/lang/reflect/Constructor;)V

    return-object v0
.end method
