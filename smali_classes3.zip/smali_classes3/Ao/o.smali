.class final LAo/o;
.super Lkotlin/jvm/internal/p;
.source "ReflectJavaClass.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Ljava/lang/Class<",
        "*>;",
        "LTo/f;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LAo/o;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LAo/o;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LAo/o;->a:LAo/o;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, LTo/f;->j(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_e

    goto :goto_f

    :cond_e
    move-object p1, v1

    :goto_f
    if-eqz p1, :cond_15

    invoke-static {p1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    :cond_15
    return-object v1
.end method
