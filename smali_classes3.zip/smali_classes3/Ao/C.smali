.class final LAo/c;
.super Ljava/lang/Object;
.source "ReflectJavaMember.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAo/c$a;
    }
.end annotation


# static fields
.field public static final a:LAo/c;

.field private static b:LAo/c$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LAo/c;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LAo/c;->a:LAo/c;

    return-void
.end method

.method public static a(Ljava/lang/reflect/Member;)LAo/c$a;
    .registers 5

    const-string v0, "member"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    :try_start_9
    const-string v0, "getParameters"

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/Class;

    invoke-virtual {p0, v0, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_12
    .catch Ljava/lang/NoSuchMethodException; {:try_start_9 .. :try_end_12} :catch_2a

    invoke-static {p0}, LAo/d;->e(Ljava/lang/Class;)Ljava/lang/ClassLoader;

    move-result-object p0

    const-string v2, "java.lang.reflect.Parameter"

    invoke-virtual {p0, v2}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    new-instance v2, LAo/c$a;

    const-string v3, "getName"

    new-array v1, v1, [Ljava/lang/Class;

    invoke-virtual {p0, v3, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    invoke-direct {v2, v0, p0}, LAo/c$a;-><init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V

    return-object v2

    :catch_2a
    new-instance p0, LAo/c$a;

    const/4 v0, 0x0

    invoke-direct {p0, v0, v0}, LAo/c$a;-><init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V

    return-object p0
.end method


# virtual methods
.method public final b(Ljava/lang/reflect/Member;)Ljava/util/ArrayList;
    .registers 9

    const-string v0, "member"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LAo/c;->b:LAo/c$a;

    if-nez v0, :cond_1b

    monitor-enter p0

    :try_start_a
    sget-object v0, LAo/c;->b:LAo/c$a;

    if-nez v0, :cond_17

    invoke-static {p1}, LAo/c;->a(Ljava/lang/reflect/Member;)LAo/c$a;

    move-result-object v0

    sput-object v0, LAo/c;->b:LAo/c$a;
    :try_end_14
    .catchall {:try_start_a .. :try_end_14} :catchall_15

    goto :goto_17

    :catchall_15
    move-exception p1

    goto :goto_19

    :cond_17
    :goto_17
    monitor-exit p0

    goto :goto_1b

    :goto_19
    monitor-exit p0

    throw p1

    :cond_1b
    :goto_1b
    invoke-virtual {v0}, LAo/c$a;->b()Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_23

    return-object v2

    :cond_23
    invoke-virtual {v0}, LAo/c$a;->a()Ljava/lang/reflect/Method;

    move-result-object v0

    if-nez v0, :cond_2a

    return-object v2

    :cond_2a
    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Object;

    invoke-virtual {v1, p1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const-string v1, "null cannot be cast to non-null type kotlin.Array<*>"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, [Ljava/lang/Object;

    new-instance v1, Ljava/util/ArrayList;

    array-length v3, p1

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V

    array-length v3, p1

    const/4 v4, 0x0

    :goto_40
    if-ge v4, v3, :cond_57

    aget-object v5, p1, v4

    new-array v6, v2, [Ljava/lang/Object;

    invoke-virtual {v0, v5, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const-string v6, "null cannot be cast to non-null type kotlin.String"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_40

    :cond_57
    return-object v1
.end method
