.class public final LAo/s;
.super LAo/f;
.source "ReflectJavaAnnotationArguments.kt"

# interfaces
.implements LKo/h;


# instance fields
.field private final b:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LTo/f;Ljava/lang/Class;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTo/f;",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    invoke-direct {p0, p1}, LAo/f;-><init>(LTo/f;)V

    iput-object p2, p0, LAo/s;->b:Ljava/lang/Class;

    return-void
.end method


# virtual methods
.method public final b()LAo/E;
    .registers 3

    iget-object v0, p0, LAo/s;->b:Ljava/lang/Class;

    const-string v1, "type"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v1

    if-eqz v1, :cond_13

    new-instance v1, LAo/C;

    invoke-direct {v1, v0}, LAo/C;-><init>(Ljava/lang/Class;)V

    goto :goto_35

    :cond_13
    instance-of v1, v0, Ljava/lang/reflect/GenericArrayType;

    if-nez v1, :cond_30

    invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z

    move-result v1

    if-eqz v1, :cond_1e

    goto :goto_30

    :cond_1e
    instance-of v1, v0, Ljava/lang/reflect/WildcardType;

    if-eqz v1, :cond_2a

    new-instance v1, LAo/H;

    check-cast v0, Ljava/lang/reflect/WildcardType;

    invoke-direct {v1, v0}, LAo/H;-><init>(Ljava/lang/reflect/WildcardType;)V

    goto :goto_35

    :cond_2a
    new-instance v1, LAo/t;

    invoke-direct {v1, v0}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_35

    :cond_30
    :goto_30
    new-instance v1, LAo/i;

    invoke-direct {v1, v0}, LAo/i;-><init>(Ljava/lang/reflect/Type;)V

    :goto_35
    return-object v1
.end method
