.class public final LAo/d;
.super Ljava/lang/Object;
.source "reflectClassUtil.kt"


# static fields
.field private static final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Llo/d<",
            "+",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+",
            "LUn/a<",
            "*>;>;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final synthetic e:I


# direct methods
.method static constructor <clinit>()V
    .registers 14

    sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v0}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v0

    sget-object v1, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v1

    sget-object v2, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    invoke-static {v2}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v2

    sget-object v3, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    invoke-static {v3}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v3

    sget-object v4, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    invoke-static {v4}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v4

    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v5}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v5

    sget-object v6, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    invoke-static {v6}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v6

    sget-object v7, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    invoke-static {v7}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v7

    const/16 v8, 0x8

    new-array v9, v8, [Llo/d;

    const/4 v10, 0x0

    aput-object v0, v9, v10

    const/4 v0, 0x1

    aput-object v1, v9, v0

    const/4 v1, 0x2

    aput-object v2, v9, v1

    const/4 v2, 0x3

    aput-object v3, v9, v2

    const/4 v3, 0x4

    aput-object v4, v9, v3

    const/4 v4, 0x5

    aput-object v5, v9, v4

    const/4 v5, 0x6

    aput-object v6, v9, v5

    const/4 v6, 0x7

    aput-object v7, v9, v6

    invoke-static {v9}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    sput-object v7, LAo/d;->a:Ljava/util/List;

    check-cast v7, Ljava/lang/Iterable;

    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v7}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_61
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_7e

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Llo/d;

    invoke-static {v11}, Lq3/m;->e(Llo/d;)Ljava/lang/Class;

    move-result-object v12

    invoke-static {v11}, Lq3/m;->f(Llo/d;)Ljava/lang/Class;

    move-result-object v11

    new-instance v13, LUn/j;

    invoke-direct {v13, v12, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_61

    :cond_7e
    invoke-static {v9}, Lkotlin/collections/J;->k(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v7

    sput-object v7, LAo/d;->b:Ljava/util/Map;

    sget-object v7, LAo/d;->a:Ljava/util/List;

    check-cast v7, Ljava/lang/Iterable;

    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v7}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_95
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_b2

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Llo/d;

    invoke-static {v11}, Lq3/m;->f(Llo/d;)Ljava/lang/Class;

    move-result-object v12

    invoke-static {v11}, Lq3/m;->e(Llo/d;)Ljava/lang/Class;

    move-result-object v11

    new-instance v13, LUn/j;

    invoke-direct {v13, v12, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_95

    :cond_b2
    invoke-static {v9}, Lkotlin/collections/J;->k(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v7

    sput-object v7, LAo/d;->c:Ljava/util/Map;

    const/16 v7, 0x17

    new-array v7, v7, [Ljava/lang/Class;

    const-class v9, Leo/a;

    aput-object v9, v7, v10

    const-class v9, Leo/l;

    aput-object v9, v7, v0

    const-class v9, Leo/p;

    aput-object v9, v7, v1

    const-class v1, Leo/q;

    aput-object v1, v7, v2

    const-class v1, Leo/r;

    aput-object v1, v7, v3

    const-class v1, Leo/s;

    aput-object v1, v7, v4

    const-class v1, Leo/t;

    aput-object v1, v7, v5

    const-class v1, Leo/u;

    aput-object v1, v7, v6

    const-class v1, Leo/v;

    aput-object v1, v7, v8

    const-class v1, Leo/w;

    const/16 v2, 0x9

    aput-object v1, v7, v2

    const-class v1, Leo/b;

    const/16 v2, 0xa

    aput-object v1, v7, v2

    const-class v1, Leo/c;

    const/16 v2, 0xb

    aput-object v1, v7, v2

    const-class v1, Leo/d;

    const/16 v2, 0xc

    aput-object v1, v7, v2

    const-class v1, Leo/e;

    const/16 v2, 0xd

    aput-object v1, v7, v2

    const-class v1, Leo/f;

    const/16 v2, 0xe

    aput-object v1, v7, v2

    const-class v1, Leo/g;

    const/16 v2, 0xf

    aput-object v1, v7, v2

    const-class v1, Leo/h;

    const/16 v2, 0x10

    aput-object v1, v7, v2

    const-class v1, Leo/i;

    const/16 v2, 0x11

    aput-object v1, v7, v2

    const-class v1, Leo/j;

    const/16 v2, 0x12

    aput-object v1, v7, v2

    const-class v1, Leo/k;

    const/16 v2, 0x13

    aput-object v1, v7, v2

    const-class v1, Leo/m;

    const/16 v2, 0x14

    aput-object v1, v7, v2

    const-class v1, Leo/n;

    const/16 v2, 0x15

    aput-object v1, v7, v2

    const-class v1, Leo/o;

    const/16 v2, 0x16

    aput-object v1, v7, v2

    invoke-static {v7}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    new-instance v2, Ljava/util/ArrayList;

    invoke-static {v1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_147
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_16a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v4, v10, 0x1

    if-ltz v10, :cond_165

    check-cast v3, Ljava/lang/Class;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    new-instance v6, LUn/j;

    invoke-direct {v6, v3, v5}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v10, v4

    goto :goto_147

    :cond_165
    invoke-static {}, Lkotlin/collections/q;->V()V

    const/4 v0, 0x0

    throw v0

    :cond_16a
    invoke-static {v2}, Lkotlin/collections/J;->k(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LAo/d;->d:Ljava/util/Map;

    return-void
.end method

.method public static final a(Ljava/lang/Class;)LTo/b;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "LTo/b;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    if-nez v0, :cond_77

    invoke-virtual {p0}, Ljava/lang/Class;->isArray()Z

    move-result v0

    if-nez v0, :cond_6b

    invoke-virtual {p0}, Ljava/lang/Class;->getEnclosingMethod()Ljava/lang/reflect/Method;

    move-result-object v0

    if-nez v0, :cond_4f

    invoke-virtual {p0}, Ljava/lang/Class;->getEnclosingConstructor()Ljava/lang/reflect/Constructor;

    move-result-object v0

    if-nez v0, :cond_4f

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_28

    goto :goto_4f

    :cond_28
    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v0

    if-eqz v0, :cond_41

    invoke-static {v0}, LAo/d;->a(Ljava/lang/Class;)LTo/b;

    move-result-object v0

    if-eqz v0, :cond_41

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object p0

    invoke-virtual {v0, p0}, LTo/b;->d(LTo/f;)LTo/b;

    move-result-object p0

    goto :goto_6a

    :cond_41
    new-instance v0, LTo/c;

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object p0

    goto :goto_6a

    :cond_4f
    :goto_4f
    new-instance v0, LTo/c;

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, LTo/c;-><init>(Ljava/lang/String;)V

    new-instance p0, LTo/b;

    invoke-virtual {v0}, LTo/c;->e()LTo/c;

    move-result-object v1

    invoke-virtual {v0}, LTo/c;->g()LTo/f;

    move-result-object v0

    invoke-static {v0}, LTo/c;->k(LTo/f;)LTo/c;

    move-result-object v0

    const/4 v2, 0x1

    invoke-direct {p0, v1, v0, v2}, LTo/b;-><init>(LTo/c;LTo/c;Z)V

    :goto_6a
    return-object p0

    :cond_6b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t compute ClassId for array type: "

    invoke-static {v1, p0}, Landroidx/lifecycle/Z;->c(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_77
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t compute ClassId for primitive type: "

    invoke-static {v1, p0}, Landroidx/lifecycle/Z;->c(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final b(Ljava/lang/Class;)Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    if-eqz v0, :cond_8b

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_ba

    goto/16 :goto_7f

    :sswitch_18
    const-string v1, "short"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "S"

    goto/16 :goto_b9

    :sswitch_24
    const-string v1, "float"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "F"

    goto/16 :goto_b9

    :sswitch_30
    const-string v1, "boolean"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "Z"

    goto/16 :goto_b9

    :sswitch_3c
    const-string v1, "void"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "V"

    goto/16 :goto_b9

    :sswitch_48
    const-string v1, "long"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "J"

    goto :goto_b9

    :sswitch_53
    const-string v1, "char"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "C"

    goto :goto_b9

    :sswitch_5e
    const-string v1, "byte"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "B"

    goto :goto_b9

    :sswitch_69
    const-string v1, "int"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "I"

    goto :goto_b9

    :sswitch_74
    const-string v1, "double"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7f

    const-string p0, "D"

    goto :goto_b9

    :cond_7f
    :goto_7f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Unsupported primitive type: "

    invoke-static {v1, p0}, Landroidx/lifecycle/Z;->c(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8b
    invoke-virtual {p0}, Ljava/lang/Class;->isArray()Z

    move-result v0

    const/16 v1, 0x2f

    const/16 v2, 0x2e

    if-eqz v0, :cond_9e

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v2, v1}, Lvp/k;->L(Ljava/lang/String;CC)Ljava/lang/String;

    move-result-object p0

    goto :goto_b9

    :cond_9e
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "L"

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v2, v1}, Lvp/k;->L(Ljava/lang/String;CC)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x3b

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_b9
    return-object p0

    :sswitch_data_ba
    .sparse-switch
        -0x4f08842f -> :sswitch_74
        0x197ef -> :sswitch_69
        0x2e6108 -> :sswitch_5e
        0x2e9356 -> :sswitch_53
        0x32c67c -> :sswitch_48
        0x375194 -> :sswitch_3c
        0x3db6c28 -> :sswitch_30
        0x5d0225c -> :sswitch_24
        0x685847c -> :sswitch_18
    .end sparse-switch
.end method

.method public static final c(Ljava/lang/reflect/Type;)Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/reflect/Type;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/reflect/Type;",
            ">;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p0, Ljava/lang/reflect/ParameterizedType;

    if-nez v0, :cond_c

    sget-object p0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p0

    :cond_c
    move-object v0, p0

    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getOwnerType()Ljava/lang/reflect/Type;

    move-result-object v1

    if-nez v1, :cond_23

    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p0

    const-string v0, "actualTypeArguments"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lkotlin/collections/h;->A([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_23
    sget-object v0, LAo/d$a;->a:LAo/d$a;

    invoke-static {p0, v0}, Lup/k;->k(Ljava/lang/Object;Leo/l;)Lup/h;

    move-result-object p0

    sget-object v0, LAo/d$b;->a:LAo/d$b;

    invoke-static {p0, v0}, Lup/k;->i(Lup/h;Leo/l;)Lup/f;

    move-result-object p0

    invoke-static {p0}, Lup/k;->q(Lup/h;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static final d(Ljava/lang/Class;)Ljava/lang/Class;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    sget-object v0, LAo/d;->b:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Class;

    return-object p0
.end method

.method public static final e(Ljava/lang/Class;)Ljava/lang/ClassLoader;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/ClassLoader;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    if-nez p0, :cond_14

    invoke-static {}, Ljava/lang/ClassLoader;->getSystemClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    const-string v0, "getSystemClassLoader()"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_14
    return-object p0
.end method

.method public static final f(Ljava/lang/Class;)Ljava/lang/Class;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LAo/d;->c:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Class;

    return-object p0
.end method

.method public static final g(Ljava/lang/Class;)Z
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const-class v0, Ljava/lang/Enum;

    invoke-virtual {v0, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p0

    return p0
.end method
