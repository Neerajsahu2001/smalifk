.class public final LAo/t;
.super LAo/E;
.source "ReflectJavaClassifierType.kt"

# interfaces
.implements LKo/j;


# instance fields
.field private final a:Ljava/lang/reflect/Type;

.field private final b:LAo/v;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Type;)V
    .registers 5

    const-string v0, "reflectType"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LAo/E;-><init>()V

    iput-object p1, p0, LAo/t;->a:Ljava/lang/reflect/Type;

    instance-of v0, p1, Ljava/lang/Class;

    if-eqz v0, :cond_16

    new-instance v0, LAo/r;

    check-cast p1, Ljava/lang/Class;

    invoke-direct {v0, p1}, LAo/r;-><init>(Ljava/lang/Class;)V

    goto :goto_38

    :cond_16
    instance-of v0, p1, Ljava/lang/reflect/TypeVariable;

    if-eqz v0, :cond_22

    new-instance v0, LAo/F;

    check-cast p1, Ljava/lang/reflect/TypeVariable;

    invoke-direct {v0, p1}, LAo/F;-><init>(Ljava/lang/reflect/TypeVariable;)V

    goto :goto_38

    :cond_22
    instance-of v0, p1, Ljava/lang/reflect/ParameterizedType;

    if-eqz v0, :cond_3b

    new-instance v0, LAo/r;

    check-cast p1, Ljava/lang/reflect/ParameterizedType;

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object p1

    const-string v1, "null cannot be cast to non-null type java.lang.Class<*>"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Ljava/lang/Class;

    invoke-direct {v0, p1}, LAo/r;-><init>(Ljava/lang/Class;)V

    :goto_38
    iput-object v0, p0, LAo/t;->b:LAo/v;

    return-void

    :cond_3b
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Not a classifier type ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, "): "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public final A()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Type not found: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, LAo/t;->a:Ljava/lang/reflect/Type;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final G()Ljava/lang/reflect/Type;
    .registers 2

    iget-object v0, p0, LAo/t;->a:Ljava/lang/reflect/Type;

    return-object v0
.end method

.method public final a()LKo/i;
    .registers 2

    iget-object v0, p0, LAo/t;->b:LAo/v;

    return-object v0
.end method

.method public final f(LTo/c;)LKo/a;
    .registers 3

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public final getAnnotations()Ljava/util/Collection;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "LKo/a;",
            ">;"
        }
    .end annotation

    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object v0
.end method

.method public final i()Z
    .registers 4

    iget-object v0, p0, LAo/t;->a:Ljava/lang/reflect/Type;

    instance-of v1, v0, Ljava/lang/Class;

    const/4 v2, 0x0

    if-eqz v1, :cond_1d

    check-cast v0, Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->getTypeParameters()[Ljava/lang/reflect/TypeVariable;

    move-result-object v0

    const-string v1, "getTypeParameters()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v0, v0

    const/4 v1, 0x1

    if-nez v0, :cond_18

    const/4 v0, 0x1

    goto :goto_19

    :cond_18
    const/4 v0, 0x0

    :goto_19
    xor-int/2addr v0, v1

    if-eqz v0, :cond_1d

    const/4 v2, 0x1

    :cond_1d
    return v2
.end method

.method public final t()Ljava/util/ArrayList;
    .registers 7

    iget-object v0, p0, LAo/t;->a:Ljava/lang/reflect/Type;

    invoke-static {v0}, LAo/d;->c(Ljava/lang/reflect/Type;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-static {v0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_15
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_66

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/reflect/Type;

    const-string v3, "type"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v3, v2, Ljava/lang/Class;

    if-eqz v3, :cond_39

    move-object v4, v2

    check-cast v4, Ljava/lang/Class;

    invoke-virtual {v4}, Ljava/lang/Class;->isPrimitive()Z

    move-result v5

    if-eqz v5, :cond_39

    new-instance v2, LAo/C;

    invoke-direct {v2, v4}, LAo/C;-><init>(Ljava/lang/Class;)V

    goto :goto_62

    :cond_39
    instance-of v4, v2, Ljava/lang/reflect/GenericArrayType;

    if-nez v4, :cond_5c

    if-eqz v3, :cond_49

    move-object v3, v2

    check-cast v3, Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Class;->isArray()Z

    move-result v3

    if-eqz v3, :cond_49

    goto :goto_5c

    :cond_49
    instance-of v3, v2, Ljava/lang/reflect/WildcardType;

    if-eqz v3, :cond_56

    new-instance v3, LAo/H;

    check-cast v2, Ljava/lang/reflect/WildcardType;

    invoke-direct {v3, v2}, LAo/H;-><init>(Ljava/lang/reflect/WildcardType;)V

    :goto_54
    move-object v2, v3

    goto :goto_62

    :cond_56
    new-instance v3, LAo/t;

    invoke-direct {v3, v2}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_54

    :cond_5c
    :goto_5c
    new-instance v3, LAo/i;

    invoke-direct {v3, v2}, LAo/i;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_54

    :goto_62
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_15

    :cond_66
    return-object v1
.end method

.method public final z()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LAo/t;->a:Ljava/lang/reflect/Type;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
