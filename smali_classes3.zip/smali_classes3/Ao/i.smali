.class public final LAo/i;
.super LAo/E;
.source "ReflectJavaArrayType.kt"

# interfaces
.implements LKo/f;


# instance fields
.field private final a:Ljava/lang/reflect/Type;

.field private final b:LAo/E;

.field private final c:Lkotlin/collections/A;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Type;)V
    .registers 5

    invoke-direct {p0}, LAo/E;-><init>()V

    iput-object p1, p0, LAo/i;->a:Ljava/lang/reflect/Type;

    instance-of v0, p1, Ljava/lang/reflect/GenericArrayType;

    if-eqz v0, :cond_51

    check-cast p1, Ljava/lang/reflect/GenericArrayType;

    invoke-interface {p1}, Ljava/lang/reflect/GenericArrayType;->getGenericComponentType()Ljava/lang/reflect/Type;

    move-result-object p1

    const-string v0, "genericComponentType"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p1, Ljava/lang/Class;

    if-eqz v0, :cond_28

    move-object v1, p1

    check-cast v1, Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Class;->isPrimitive()Z

    move-result v2

    if-eqz v2, :cond_28

    new-instance p1, LAo/C;

    invoke-direct {p1, v1}, LAo/C;-><init>(Ljava/lang/Class;)V

    goto/16 :goto_96

    :cond_28
    instance-of v1, p1, Ljava/lang/reflect/GenericArrayType;

    if-nez v1, :cond_4b

    if-eqz v0, :cond_38

    move-object v0, p1

    check-cast v0, Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z

    move-result v0

    if-eqz v0, :cond_38

    goto :goto_4b

    :cond_38
    instance-of v0, p1, Ljava/lang/reflect/WildcardType;

    if-eqz v0, :cond_45

    new-instance v0, LAo/H;

    check-cast p1, Ljava/lang/reflect/WildcardType;

    invoke-direct {v0, p1}, LAo/H;-><init>(Ljava/lang/reflect/WildcardType;)V

    :goto_43
    move-object p1, v0

    goto :goto_96

    :cond_45
    new-instance v0, LAo/t;

    invoke-direct {v0, p1}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_43

    :cond_4b
    :goto_4b
    new-instance v0, LAo/i;

    invoke-direct {v0, p1}, LAo/i;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_43

    :cond_51
    instance-of v0, p1, Ljava/lang/Class;

    if-eqz v0, :cond_9d

    move-object v0, p1

    check-cast v0, Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z

    move-result v1

    if-eqz v1, :cond_9d

    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object p1

    const-string v0, "getComponentType()"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    if-eqz v0, :cond_73

    new-instance v0, LAo/C;

    invoke-direct {v0, p1}, LAo/C;-><init>(Ljava/lang/Class;)V

    goto :goto_43

    :cond_73
    instance-of v0, p1, Ljava/lang/reflect/GenericArrayType;

    if-nez v0, :cond_90

    invoke-virtual {p1}, Ljava/lang/Class;->isArray()Z

    move-result v0

    if-eqz v0, :cond_7e

    goto :goto_90

    :cond_7e
    instance-of v0, p1, Ljava/lang/reflect/WildcardType;

    if-eqz v0, :cond_8a

    new-instance v0, LAo/H;

    check-cast p1, Ljava/lang/reflect/WildcardType;

    invoke-direct {v0, p1}, LAo/H;-><init>(Ljava/lang/reflect/WildcardType;)V

    goto :goto_43

    :cond_8a
    new-instance v0, LAo/t;

    invoke-direct {v0, p1}, LAo/t;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_43

    :cond_90
    :goto_90
    new-instance v0, LAo/i;

    invoke-direct {v0, p1}, LAo/i;-><init>(Ljava/lang/reflect/Type;)V

    goto :goto_43

    :goto_96
    iput-object p1, p0, LAo/i;->b:LAo/E;

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    iput-object p1, p0, LAo/i;->c:Lkotlin/collections/A;

    return-void

    :cond_9d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Not an array type ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, "): "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method protected final G()Ljava/lang/reflect/Type;
    .registers 2

    iget-object v0, p0, LAo/i;->a:Ljava/lang/reflect/Type;

    return-object v0
.end method

.method public final getAnnotations()Ljava/util/Collection;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "LKo/a;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LAo/i;->c:Lkotlin/collections/A;

    return-object v0
.end method

.method public final v()LAo/E;
    .registers 2

    iget-object v0, p0, LAo/i;->b:LAo/E;

    return-object v0
.end method
