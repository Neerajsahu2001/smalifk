.class public interface abstract LBn/c$a;
.super Ljava/lang/Object;
.source "SqlDriver.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LBn/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract create(LBn/c;)V
.end method

.method public abstract getVersion()I
.end method

.method public abstract migrate(LBn/c;II)V
.end method
