.class public interface abstract Lbn/d;
.super Ljava/lang/Object;
.source "YouTubePlayerListener.kt"


# virtual methods
.method public abstract onApiChange(Lan/e;)V
.end method

.method public abstract onCurrentSecond(Lan/e;F)V
.end method

.method public abstract onError(Lan/e;Lan/c;)V
.end method

.method public abstract onPlaybackQualityChange(Lan/e;Lan/a;)V
.end method

.method public abstract onPlaybackRateChange(Lan/e;Lan/b;)V
.end method

.method public abstract onReady(Lan/e;)V
.end method

.method public abstract onStateChange(Lan/e;Lan/d;)V
.end method

.method public abstract onVideoDuration(Lan/e;F)V
.end method

.method public abstract onVideoId(Lan/e;Ljava/lang/String;)V
.end method

.method public abstract onVideoLoadedFraction(Lan/e;F)V
.end method
