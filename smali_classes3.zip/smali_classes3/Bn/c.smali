.class public interface abstract Lbn/c;
.super Ljava/lang/Object;
.source "YouTubePlayerFullScreenListener.kt"


# virtual methods
.method public abstract onYouTubePlayerEnterFullScreen()V
.end method

.method public abstract onYouTubePlayerExitFullScreen()V
.end method
