.class public interface abstract LBn/e;
.super Ljava/lang/Object;
.source "SqlPreparedStatement.kt"


# virtual methods
.method public abstract u(ILjava/lang/String;)V
.end method

.method public abstract v(ILjava/lang/Long;)V
.end method
