.class public interface abstract Lbn/b;
.super Ljava/lang/Object;
.source "YouTubePlayerCallback.kt"


# virtual methods
.method public abstract a()V
.end method
