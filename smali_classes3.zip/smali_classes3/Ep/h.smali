.class public interface abstract Lep/h;
.super Ljava/lang/Object;
.source "SuperCallReceiverValue.kt"

# interfaces
.implements Lep/g;


# virtual methods
.method public abstract b()Lkp/E;
.end method
