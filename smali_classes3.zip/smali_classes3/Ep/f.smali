.class public interface abstract Lep/f;
.super Ljava/lang/Object;
.source "ImplicitReceiver.kt"

# interfaces
.implements Lep/g;


# virtual methods
.method public abstract a()LTo/f;
.end method
