.class public final Lep/c;
.super Lep/a;
.source "ContextReceiver.kt"

# interfaces
.implements Lep/f;


# instance fields
.field private final c:Luo/a;

.field private final d:LTo/f;


# direct methods
.method public constructor <init>(Luo/a;Lkp/E;LTo/f;Lep/g;)V
    .registers 6

    const-string v0, "declarationDescriptor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "receiverType"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2, p4}, Lep/a;-><init>(Lkp/E;Lep/g;)V

    iput-object p1, p0, Lep/c;->c:Luo/a;

    iput-object p3, p0, Lep/c;->d:LTo/f;

    return-void
.end method


# virtual methods
.method public final a()LTo/f;
    .registers 2

    iget-object v0, p0, Lep/c;->d:LTo/f;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Cxt { "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lep/c;->c:Luo/a;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " }"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
