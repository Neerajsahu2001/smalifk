.class public interface abstract Lep/g;
.super Ljava/lang/Object;
.source "ReceiverValue.java"


# virtual methods
.method public abstract getType()Lkp/E;
.end method
