.class public interface abstract Lep/i;
.super Ljava/lang/Object;
.source "ImplicitClassReceiver.kt"

# interfaces
.implements Lep/g;


# virtual methods
.method public abstract t()Luo/e;
.end method
