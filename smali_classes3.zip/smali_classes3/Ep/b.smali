.class public final Lep/b;
.super Lep/a;
.source "ContextClassReceiver.kt"

# interfaces
.implements Lep/f;


# instance fields
.field private final c:Luo/e;

.field private final d:LTo/f;


# direct methods
.method public constructor <init>(Luo/e;Lkp/E;LTo/f;)V
    .registers 5

    const-string v0, "classDescriptor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "receiverType"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, p2, v0}, Lep/a;-><init>(Lkp/E;Lep/g;)V

    iput-object p1, p0, Lep/b;->c:Luo/e;

    iput-object p3, p0, Lep/b;->d:LTo/f;

    return-void
.end method


# virtual methods
.method public final a()LTo/f;
    .registers 2

    iget-object v0, p0, Lep/b;->d:LTo/f;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lep/a;->getType()Lkp/E;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ": Ctx { "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lep/b;->c:Luo/e;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " }"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
