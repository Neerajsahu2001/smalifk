.class public final LDo/q;
.super Ljava/lang/Object;
.source "FieldOverridabilityCondition.kt"

# interfaces
.implements LWo/j;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Luo/a;Luo/a;Luo/e;)LWo/j$b;
    .registers 5

    const-string p3, "superDescriptor"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p3, "subDescriptor"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of p3, p2, Luo/L;

    if-eqz p3, :cond_4a

    instance-of p3, p1, Luo/L;

    if-nez p3, :cond_13

    goto :goto_4a

    :cond_13
    check-cast p2, Luo/L;

    invoke-interface {p2}, Luo/k;->getName()LTo/f;

    move-result-object p3

    check-cast p1, Luo/L;

    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v0

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_28

    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1

    :cond_28
    invoke-static {p2}, Landroidx/core/util/g;->k(Luo/L;)Z

    move-result p3

    if-eqz p3, :cond_37

    invoke-static {p1}, Landroidx/core/util/g;->k(Luo/L;)Z

    move-result p3

    if-eqz p3, :cond_37

    sget-object p1, LWo/j$b;->OVERRIDABLE:LWo/j$b;

    return-object p1

    :cond_37
    invoke-static {p2}, Landroidx/core/util/g;->k(Luo/L;)Z

    move-result p2

    if-nez p2, :cond_47

    invoke-static {p1}, Landroidx/core/util/g;->k(Luo/L;)Z

    move-result p1

    if-eqz p1, :cond_44

    goto :goto_47

    :cond_44
    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1

    :cond_47
    :goto_47
    sget-object p1, LWo/j$b;->INCOMPATIBLE:LWo/j$b;

    return-object p1

    :cond_4a
    :goto_4a
    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1
.end method

.method public b()LWo/j$a;
    .registers 2

    sget-object v0, LWo/j$a;->BOTH:LWo/j$a;

    return-object v0
.end method
