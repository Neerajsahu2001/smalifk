.class public final LDo/e;
.super LDo/b;
.source "AnnotationTypeQualifierResolver.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LDo/b<",
        "Lvo/c;",
        ">;"
    }
.end annotation


# direct methods
.method private static n(LYo/g;)Ljava/util/List;
    .registers 3

    instance-of v0, p0, LYo/b;

    if-eqz v0, :cond_2b

    check-cast p0, LYo/b;

    invoke-virtual {p0}, LYo/g;->b()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_15
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_40

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LYo/g;

    invoke-static {v1}, LDo/e;->n(LYo/g;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1, v0}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_15

    :cond_2b
    instance-of v0, p0, LYo/j;

    if-eqz v0, :cond_3e

    check-cast p0, LYo/j;

    invoke-virtual {p0}, LYo/j;->c()LTo/f;

    move-result-object p0

    invoke-virtual {p0}, LTo/f;->d()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    goto :goto_40

    :cond_3e
    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_40
    :goto_40
    return-object v0
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Z)Ljava/util/ArrayList;
    .registers 7

    check-cast p1, Lvo/c;

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, Lvo/c;->a()Ljava/util/Map;

    move-result-object p1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_18
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_48

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LTo/f;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LYo/g;

    if-eqz p2, :cond_3e

    sget-object v3, LDo/E;->b:LTo/f;

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3b

    goto :goto_3e

    :cond_3b
    sget-object v1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    goto :goto_42

    :cond_3e
    :goto_3e
    invoke-static {v1}, LDo/e;->n(LYo/g;)Ljava/util/List;

    move-result-object v1

    :goto_42
    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1, v0}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_18

    :cond_48
    return-object v0
.end method

.method public final g(Ljava/lang/Object;)LTo/c;
    .registers 3

    check-cast p1, Lvo/c;

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, Lvo/c;->c()LTo/c;

    move-result-object p1

    return-object p1
.end method

.method public final h(Ljava/lang/Object;)Luo/e;
    .registers 3

    check-cast p1, Lvo/c;

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lap/c;->d(Lvo/c;)Luo/e;

    move-result-object p1

    invoke-static {p1}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    return-object p1
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Iterable;
    .registers 3

    check-cast p1, Lvo/c;

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lap/c;->d(Lvo/c;)Luo/e;

    move-result-object p1

    if-eqz p1, :cond_14

    invoke-interface {p1}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object p1

    if-eqz p1, :cond_14

    goto :goto_16

    :cond_14
    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :goto_16
    return-object p1
.end method
