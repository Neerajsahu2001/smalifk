.class public final LDo/o;
.super Ljava/lang/Object;
.source "ErasedOverridabilityCondition.kt"

# interfaces
.implements LWo/j;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LDo/o$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Luo/a;Luo/a;Luo/e;)LWo/j$b;
    .registers 8

    const-string p3, "superDescriptor"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p3, "subDescriptor"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of p3, p2, LFo/e;

    if-eqz p3, :cond_ee

    move-object p3, p2

    check-cast p3, LFo/e;

    invoke-virtual {p3}, Lxo/w;->getTypeParameters()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    if-eqz v0, :cond_21

    goto/16 :goto_ee

    :cond_21
    invoke-static {p1, p2}, LWo/o;->k(Luo/a;Luo/a;)LWo/o$c;

    move-result-object v0

    const/4 v2, 0x0

    if-eqz v0, :cond_2d

    invoke-virtual {v0}, LWo/o$c;->c()LWo/o$c$a;

    move-result-object v0

    goto :goto_2e

    :cond_2d
    move-object v0, v2

    :goto_2e
    if-eqz v0, :cond_33

    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1

    :cond_33
    invoke-virtual {p3}, Lxo/w;->e()Ljava/util/List;

    move-result-object v0

    const-string v3, "subDescriptor.valueParameters"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/q;->j(Ljava/lang/Iterable;)Lkotlin/collections/w;

    move-result-object v0

    sget-object v3, LDo/o$b;->a:LDo/o$b;

    invoke-static {v0, v3}, Lup/k;->m(Lup/h;Leo/l;)Lup/z;

    move-result-object v0

    invoke-virtual {p3}, Lxo/w;->getReturnType()Lkp/E;

    move-result-object v3

    invoke-static {v3}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-static {v0, v3}, Lup/k;->p(Lup/z;Ljava/lang/Object;)Lup/f;

    move-result-object v0

    invoke-virtual {p3}, Lxo/w;->O()Luo/O;

    move-result-object p3

    if-eqz p3, :cond_5d

    invoke-interface {p3}, Luo/a0;->getType()Lkp/E;

    move-result-object v2

    :cond_5d
    invoke-static {v2}, Lkotlin/collections/q;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p3

    check-cast p3, Ljava/lang/Iterable;

    invoke-static {v0, p3}, Lup/k;->o(Lup/f;Ljava/lang/Iterable;)Lup/f;

    move-result-object p3

    invoke-virtual {p3}, Lup/f;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :cond_6b
    move-object v0, p3

    check-cast v0, Lup/f$a;

    invoke-virtual {v0}, Lup/f$a;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_92

    invoke-virtual {v0}, Lup/f$a;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkp/E;

    invoke-virtual {v0}, Lkp/E;->L0()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    xor-int/2addr v2, v1

    if-eqz v2, :cond_6b

    invoke-virtual {v0}, Lkp/E;->Q0()Lkp/v0;

    move-result-object v0

    instance-of v0, v0, LIo/h;

    if-nez v0, :cond_6b

    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1

    :cond_92
    new-instance p3, LIo/g;

    invoke-direct {p3}, LIo/g;-><init>()V

    invoke-static {p3}, Lkp/r0;->f(Lkp/n0;)Lkp/r0;

    move-result-object p3

    invoke-interface {p1, p3}, Luo/U;->b(Lkp/r0;)Luo/l;

    move-result-object p1

    check-cast p1, Luo/a;

    if-nez p1, :cond_a6

    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1

    :cond_a6
    instance-of p3, p1, Luo/Q;

    if-eqz p3, :cond_ce

    move-object p3, p1

    check-cast p3, Luo/Q;

    invoke-interface {p3}, Luo/a;->getTypeParameters()Ljava/util/List;

    move-result-object v0

    const-string v2, "erasedSuper.typeParameters"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    xor-int/2addr v0, v1

    if-eqz v0, :cond_ce

    invoke-interface {p3}, Luo/v;->H0()Luo/v$a;

    move-result-object p1

    invoke-interface {p1}, Luo/v$a;->i()Luo/v$a;

    move-result-object p1

    invoke-interface {p1}, Luo/v$a;->build()Luo/v;

    move-result-object p1

    invoke-static {p1}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    :cond_ce
    sget-object p3, LWo/o;->f:LWo/o;

    const/4 v0, 0x0

    invoke-virtual {p3, p1, p2, v0}, LWo/o;->p(Luo/a;Luo/a;Z)LWo/o$c;

    move-result-object p1

    invoke-virtual {p1}, LWo/o$c;->c()LWo/o$c$a;

    move-result-object p1

    const-string p2, "DEFAULT.isOverridableByW\u2026Descriptor, false).result"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p2, LDo/o$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, p2, p1

    if-ne p1, v1, :cond_eb

    sget-object p1, LWo/j$b;->OVERRIDABLE:LWo/j$b;

    goto :goto_ed

    :cond_eb
    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    :goto_ed
    return-object p1

    :cond_ee
    :goto_ee
    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1
.end method

.method public b()LWo/j$a;
    .registers 2

    sget-object v0, LWo/j$a;->SUCCESS_ONLY:LWo/j$a;

    return-object v0
.end method
