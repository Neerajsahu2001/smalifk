.class public final LDo/z;
.super Ljava/lang/Object;
.source "JavaTypeEnhancementState.kt"


# static fields
.field private static final d:LDo/z;


# instance fields
.field private final a:LDo/C;

.field private final b:Leo/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/l<",
            "LTo/c;",
            "LDo/J;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, LDo/z;

    invoke-static {}, LDo/x;->a()LDo/C;

    move-result-object v1

    sget-object v2, LDo/z$a;->j:LDo/z$a;

    invoke-direct {v0, v1, v2}, LDo/z;-><init>(LDo/C;Leo/l;)V

    sput-object v0, LDo/z;->d:LDo/z;

    return-void
.end method

.method public constructor <init>(LDo/C;Leo/l;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LDo/C;",
            "Leo/l<",
            "-",
            "LTo/c;",
            "+",
            "LDo/J;",
            ">;)V"
        }
    .end annotation

    const-string v0, "getReportLevelForAnnotation"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LDo/z;->a:LDo/C;

    iput-object p2, p0, LDo/z;->b:Leo/l;

    invoke-virtual {p1}, LDo/C;->d()Z

    move-result p1

    if-nez p1, :cond_23

    invoke-static {}, LDo/x;->c()LTo/c;

    move-result-object p1

    check-cast p2, LDo/z$a;

    invoke-virtual {p2, p1}, LDo/z$a;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LDo/J;->IGNORE:LDo/J;

    if-ne p1, p2, :cond_21

    goto :goto_23

    :cond_21
    const/4 p1, 0x0

    goto :goto_24

    :cond_23
    :goto_23
    const/4 p1, 0x1

    :goto_24
    iput-boolean p1, p0, LDo/z;->c:Z

    return-void
.end method

.method public static final synthetic a()LDo/z;
    .registers 1

    sget-object v0, LDo/z;->d:LDo/z;

    return-object v0
.end method


# virtual methods
.method public final b()Z
    .registers 2

    iget-boolean v0, p0, LDo/z;->c:Z

    return v0
.end method

.method public final c()Leo/l;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Leo/l<",
            "LTo/c;",
            "LDo/J;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LDo/z;->b:Leo/l;

    return-object v0
.end method

.method public final d()LDo/C;
    .registers 2

    iget-object v0, p0, LDo/z;->a:LDo/C;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "JavaTypeEnhancementState(jsr305="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LDo/z;->a:LDo/C;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", getReportLevelForAnnotation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LDo/z;->b:Leo/l;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
