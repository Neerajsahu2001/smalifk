.class final synthetic LDo/z$a;
.super Lkotlin/jvm/internal/l;
.source "JavaTypeEnhancementState.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LDo/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/l;",
        "Leo/l<",
        "LTo/c;",
        "LDo/J;",
        ">;"
    }
.end annotation


# static fields
.field public static final j:LDo/z$a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LDo/z$a;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/l;-><init>(I)V

    sput-object v0, LDo/z$a;->j:LDo/z$a;

    return-void
.end method


# virtual methods
.method public final getName()Ljava/lang/String;
    .registers 2

    const-string v0, "getDefaultReportLevelForAnnotation"

    return-object v0
.end method

.method public final getOwner()Llo/f;
    .registers 3

    const-class v0, LDo/x;

    const-string v1, "compiler.common.jvm"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/E;->d(Ljava/lang/Class;Ljava/lang/String;)Llo/f;

    move-result-object v0

    return-object v0
.end method

.method public final getSignature()Ljava/lang/String;
    .registers 2

    const-string v0, "getDefaultReportLevelForAnnotation(Lorg/jetbrains/kotlin/name/FqName;)Lorg/jetbrains/kotlin/load/java/ReportLevel;"

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LTo/c;

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, LDo/x;->b(LTo/c;)LDo/J;

    move-result-object p1

    return-object p1
.end method
