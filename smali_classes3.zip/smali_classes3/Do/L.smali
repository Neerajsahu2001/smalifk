.class public final LDo/l;
.super Ljava/lang/Object;
.source "ClassicBuiltinSpecialProperties.kt"


# direct methods
.method public static a(Luo/M;)Ljava/lang/String;
    .registers 3

    invoke-static {p0}, Lro/j;->X(Luo/k;)Z

    invoke-static {p0}, Lap/c;->l(Luo/b;)Luo/b;

    move-result-object p0

    sget-object v0, LDo/k;->a:LDo/k;

    invoke-static {p0, v0}, Lap/c;->b(Luo/b;Leo/l;)Luo/b;

    move-result-object p0

    const/4 v0, 0x0

    if-nez p0, :cond_11

    return-object v0

    :cond_11
    invoke-static {}, LDo/j;->a()Ljava/util/Map;

    move-result-object v1

    invoke-static {p0}, Lap/c;->g(Luo/k;)LTo/c;

    move-result-object p0

    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LTo/f;

    if-eqz p0, :cond_25

    invoke-virtual {p0}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    :cond_25
    return-object v0
.end method

.method public static b(Luo/b;)Z
    .registers 5

    const-string v0, "callableMemberDescriptor"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, LDo/j;->d()Ljava/util/Set;

    move-result-object v0

    invoke-interface {p0}, Luo/k;->getName()LTo/f;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_15

    return v1

    :cond_15
    invoke-static {}, LDo/j;->c()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {p0}, Lap/c;->c(Luo/k;)LTo/c;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/collections/q;->m(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_32

    invoke-interface {p0}, Luo/a;->e()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_32

    :goto_30
    const/4 v1, 0x1

    goto :goto_6a

    :cond_32
    invoke-static {p0}, Lro/j;->X(Luo/k;)Z

    move-result v0

    if-nez v0, :cond_39

    goto :goto_6a

    :cond_39
    invoke-interface {p0}, Luo/b;->o()Ljava/util/Collection;

    move-result-object p0

    const-string v0, "overriddenDescriptors"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Iterable;

    move-object v0, p0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_4e

    goto :goto_6a

    :cond_4e
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_52
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6a

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/b;

    const-string v3, "it"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LDo/l;->b(Luo/b;)Z

    move-result v0

    if-eqz v0, :cond_52

    goto :goto_30

    :cond_6a
    :goto_6a
    return v1
.end method
