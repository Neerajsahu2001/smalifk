.class final LDo/f;
.super Lkotlin/jvm/internal/p;
.source "specialBuiltinMembers.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Luo/b;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Luo/Q;


# direct methods
.method constructor <init>(Luo/Q;)V
    .registers 2

    iput-object p1, p0, LDo/f;->a:Luo/Q;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Luo/b;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, LDo/L;->h()Ljava/util/LinkedHashMap;

    move-result-object p1

    iget-object v0, p0, LDo/f;->a:Luo/Q;

    invoke-static {v0}, LMo/A;->b(Luo/a;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
