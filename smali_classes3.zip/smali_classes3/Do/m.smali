.class public final LDo/m;
.super LZo/a;
.source "utils.kt"


# instance fields
.field private final a:Luo/k;


# direct methods
.method public constructor <init>(Luo/b;)V
    .registers 2

    invoke-direct {p0}, LZo/a;-><init>()V

    iput-object p1, p0, LDo/m;->a:Luo/k;

    return-void
.end method


# virtual methods
.method public final a()LZo/b;
    .registers 2

    sget-object v0, LZo/b;->ERROR:LZo/b;

    return-object v0
.end method
