.class public final enum LDo/c;
.super Ljava/lang/Enum;
.source "AnnotationQualifierApplicabilityType.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LDo/c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LDo/c;

.field public static final enum FIELD:LDo/c;

.field public static final enum METHOD_RETURN_TYPE:LDo/c;

.field public static final enum TYPE_PARAMETER:LDo/c;

.field public static final enum TYPE_PARAMETER_BOUNDS:LDo/c;

.field public static final enum TYPE_USE:LDo/c;

.field public static final enum VALUE_PARAMETER:LDo/c;


# instance fields
.field private final javaTarget:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 13

    new-instance v0, LDo/c;

    const/4 v1, 0x0

    const-string v2, "METHOD"

    const-string v3, "METHOD_RETURN_TYPE"

    invoke-direct {v0, v3, v1, v2}, LDo/c;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, LDo/c;->METHOD_RETURN_TYPE:LDo/c;

    new-instance v2, LDo/c;

    const/4 v3, 0x1

    const-string v4, "PARAMETER"

    const-string v5, "VALUE_PARAMETER"

    invoke-direct {v2, v5, v3, v4}, LDo/c;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v2, LDo/c;->VALUE_PARAMETER:LDo/c;

    new-instance v4, LDo/c;

    const-string v5, "FIELD"

    const/4 v6, 0x2

    invoke-direct {v4, v5, v6, v5}, LDo/c;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v4, LDo/c;->FIELD:LDo/c;

    new-instance v5, LDo/c;

    const/4 v7, 0x3

    const-string v8, "TYPE_USE"

    invoke-direct {v5, v8, v7, v8}, LDo/c;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v5, LDo/c;->TYPE_USE:LDo/c;

    new-instance v9, LDo/c;

    const-string v10, "TYPE_PARAMETER_BOUNDS"

    const/4 v11, 0x4

    invoke-direct {v9, v10, v11, v8}, LDo/c;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v9, LDo/c;->TYPE_PARAMETER_BOUNDS:LDo/c;

    new-instance v8, LDo/c;

    const-string v10, "TYPE_PARAMETER"

    const/4 v12, 0x5

    invoke-direct {v8, v10, v12, v10}, LDo/c;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v8, LDo/c;->TYPE_PARAMETER:LDo/c;

    const/4 v10, 0x6

    new-array v10, v10, [LDo/c;

    aput-object v0, v10, v1

    aput-object v2, v10, v3

    aput-object v4, v10, v6

    aput-object v5, v10, v7

    aput-object v9, v10, v11

    aput-object v8, v10, v12

    sput-object v10, LDo/c;->$VALUES:[LDo/c;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, LDo/c;->javaTarget:Ljava/lang/String;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LDo/c;
    .registers 2

    const-class v0, LDo/c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LDo/c;

    return-object p0
.end method

.method public static values()[LDo/c;
    .registers 1

    sget-object v0, LDo/c;->$VALUES:[LDo/c;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LDo/c;

    return-object v0
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, LDo/c;->javaTarget:Ljava/lang/String;

    return-object v0
.end method
