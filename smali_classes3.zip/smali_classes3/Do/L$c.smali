.class public enum LDo/L$c;
.super Ljava/lang/Enum;
.source "SpecialGenericSignatures.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LDo/L;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LDo/L$c$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LDo/L$c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LDo/L$c;

.field public static final enum FALSE:LDo/L$c;

.field public static final enum INDEX:LDo/L$c;

.field public static final enum MAP_GET_OR_DEFAULT:LDo/L$c;

.field public static final enum NULL:LDo/L$c;


# instance fields
.field private final defaultValue:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    new-instance v0, LDo/L$c;

    const/4 v1, 0x0

    const-string v2, "NULL"

    const/4 v3, 0x0

    invoke-direct {v0, v3, v1, v2}, LDo/L$c;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    sput-object v0, LDo/L$c;->NULL:LDo/L$c;

    new-instance v1, LDo/L$c;

    const/4 v2, -0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x1

    const-string v5, "INDEX"

    invoke-direct {v1, v4, v2, v5}, LDo/L$c;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    sput-object v1, LDo/L$c;->INDEX:LDo/L$c;

    new-instance v2, LDo/L$c;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const-string v7, "FALSE"

    invoke-direct {v2, v6, v5, v7}, LDo/L$c;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    sput-object v2, LDo/L$c;->FALSE:LDo/L$c;

    new-instance v5, LDo/L$c$a;

    invoke-direct {v5}, LDo/L$c;-><init>()V

    sput-object v5, LDo/L$c;->MAP_GET_OR_DEFAULT:LDo/L$c;

    const/4 v7, 0x4

    new-array v7, v7, [LDo/L$c;

    aput-object v0, v7, v3

    aput-object v1, v7, v4

    aput-object v2, v7, v6

    const/4 v0, 0x3

    aput-object v5, v7, v0

    sput-object v7, LDo/L$c;->$VALUES:[LDo/L$c;

    return-void
.end method

.method public synthetic constructor <init>()V
    .registers 4

    const/4 v0, 0x3

    const/4 v1, 0x0

    const-string v2, "MAP_GET_OR_DEFAULT"

    invoke-direct {p0, v0, v1, v2}, LDo/L$c;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method private constructor <init>(ILjava/lang/Object;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p3, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p2, p0, LDo/L$c;->defaultValue:Ljava/lang/Object;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LDo/L$c;
    .registers 2

    const-class v0, LDo/L$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LDo/L$c;

    return-object p0
.end method

.method public static values()[LDo/L$c;
    .registers 1

    sget-object v0, LDo/L$c;->$VALUES:[LDo/L$c;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LDo/L$c;

    return-object v0
.end method
