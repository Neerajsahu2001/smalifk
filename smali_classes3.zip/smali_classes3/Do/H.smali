.class public final LDo/h;
.super LDo/L;
.source "specialBuiltinMembers.kt"


# static fields
.field public static final synthetic m:I


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public static final i(Luo/v;)Luo/v;
    .registers 3

    const-string v0, "functionDescriptor"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Luo/k;->getName()LTo/f;

    move-result-object v0

    const-string v1, "functionDescriptor.name"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LDo/h;->j(LTo/f;)Z

    move-result v0

    if-nez v0, :cond_16

    const/4 p0, 0x0

    return-object p0

    :cond_16
    sget-object v0, LDo/h$a;->a:LDo/h$a;

    invoke-static {p0, v0}, Lap/c;->b(Luo/b;Leo/l;)Luo/b;

    move-result-object p0

    check-cast p0, Luo/v;

    return-object p0
.end method

.method public static j(LTo/f;)Z
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, LDo/L;->b()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method
