.class public final LDo/v;
.super Ljava/lang/Object;
.source "JavaIncompatibilityRulesOverridabilityCondition.kt"

# interfaces
.implements LWo/j;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LDo/v$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Luo/a;Luo/a;Luo/e;)LWo/j$b;
    .registers 11

    const-string v0, "superDescriptor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "subDescriptor"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p1, Luo/b;

    if-eqz v0, :cond_b0

    instance-of v0, p2, Luo/v;

    if-eqz v0, :cond_b0

    invoke-static {p2}, Lro/j;->X(Luo/k;)Z

    move-result v0

    if-eqz v0, :cond_1a

    goto/16 :goto_b0

    :cond_1a
    sget v0, LDo/h;->m:I

    move-object v0, p2

    check-cast v0, Luo/v;

    invoke-interface {v0}, Luo/k;->getName()LTo/f;

    move-result-object v1

    const-string v2, "subDescriptor.name"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, LDo/h;->j(LTo/f;)Z

    move-result v1

    if-nez v1, :cond_43

    sget-object v1, LDo/L;->a:LDo/L$a;

    invoke-interface {v0}, Luo/k;->getName()LTo/f;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, LDo/L;->e()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_43

    goto/16 :goto_b0

    :cond_43
    move-object v1, p1

    check-cast v1, Luo/b;

    invoke-static {v1}, LDo/K;->c(Luo/b;)Luo/b;

    move-result-object v1

    instance-of v2, p1, Luo/v;

    if-eqz v2, :cond_52

    move-object v3, p1

    check-cast v3, Luo/v;

    goto :goto_53

    :cond_52
    const/4 v3, 0x0

    :goto_53
    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_62

    invoke-interface {v0}, Luo/v;->C0()Z

    move-result v6

    invoke-interface {v3}, Luo/v;->C0()Z

    move-result v3

    if-ne v6, v3, :cond_62

    const/4 v4, 0x1

    :cond_62
    xor-int/lit8 v3, v4, 0x1

    if-eqz v3, :cond_6f

    if-eqz v1, :cond_ad

    invoke-interface {v0}, Luo/v;->C0()Z

    move-result v3

    if-nez v3, :cond_6f

    goto :goto_ad

    :cond_6f
    instance-of v3, p3, LFo/c;

    if-eqz v3, :cond_b0

    invoke-interface {v0}, Luo/v;->t0()Luo/v;

    move-result-object v3

    if-eqz v3, :cond_7a

    goto :goto_b0

    :cond_7a
    if-eqz v1, :cond_b0

    invoke-static {p3, v1}, LDo/K;->d(Luo/e;Luo/b;)Z

    move-result p3

    if-eqz p3, :cond_83

    goto :goto_b0

    :cond_83
    instance-of p3, v1, Luo/v;

    if-eqz p3, :cond_ad

    if-eqz v2, :cond_ad

    check-cast v1, Luo/v;

    invoke-static {v1}, LDo/h;->i(Luo/v;)Luo/v;

    move-result-object p3

    if-eqz p3, :cond_ad

    const/4 p3, 0x2

    invoke-static {v0, p3}, LMo/A;->a(Luo/v;I)Ljava/lang/String;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Luo/v;

    invoke-interface {v1}, Luo/v;->a()Luo/v;

    move-result-object v1

    const-string v2, "superDescriptor.original"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, p3}, LMo/A;->a(Luo/v;I)Ljava/lang/String;

    move-result-object p3

    invoke-static {v0, p3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_ad

    goto :goto_b0

    :cond_ad
    :goto_ad
    sget-object p1, LWo/j$b;->INCOMPATIBLE:LWo/j$b;

    return-object p1

    :cond_b0
    :goto_b0
    invoke-static {p1, p2}, LDo/v$a;->a(Luo/a;Luo/a;)Z

    move-result p1

    if-eqz p1, :cond_b9

    sget-object p1, LWo/j$b;->INCOMPATIBLE:LWo/j$b;

    return-object p1

    :cond_b9
    sget-object p1, LWo/j$b;->UNKNOWN:LWo/j$b;

    return-object p1
.end method

.method public b()LWo/j$a;
    .registers 2

    sget-object v0, LWo/j$a;->CONFLICTS_ONLY:LWo/j$a;

    return-object v0
.end method
