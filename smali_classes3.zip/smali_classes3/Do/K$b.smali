.class final LDo/K$b;
.super Lkotlin/jvm/internal/p;
.source "specialBuiltinMembers.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LDo/K;->b(Luo/b;)Luo/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Luo/b;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LDo/K$b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LDo/K$b;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LDo/K$b;->a:LDo/K$b;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Luo/b;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget v0, LDo/g;->m:I

    check-cast p1, Luo/Q;

    invoke-static {p1}, Lro/j;->X(Luo/k;)Z

    move-result v0

    if-eqz v0, :cond_1e

    new-instance v0, LDo/f;

    invoke-direct {v0, p1}, LDo/f;-><init>(Luo/Q;)V

    invoke-static {p1, v0}, Lap/c;->b(Luo/b;Leo/l;)Luo/b;

    move-result-object p1

    if-eqz p1, :cond_1e

    const/4 p1, 0x1

    goto :goto_1f

    :cond_1e
    const/4 p1, 0x0

    :goto_1f
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
