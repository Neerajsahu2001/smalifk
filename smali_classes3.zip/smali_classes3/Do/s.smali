.class public interface abstract LDo/s;
.super Ljava/lang/Object;
.source "JavaClassesTracker.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LDo/s$a;
    }
.end annotation


# virtual methods
.method public abstract a(LHo/e;)V
.end method
