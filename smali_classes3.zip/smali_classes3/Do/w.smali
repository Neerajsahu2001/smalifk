.class public interface abstract LDo/w;
.super Ljava/lang/Object;
.source "JavaModuleAnnotationsProvider.kt"


# virtual methods
.method public abstract a(LTo/b;)V
.end method
