.class public final LDo/G$a;
.super Ljava/lang/Object;
.source "JavaNullabilityAnnotationSettings.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LDo/G;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field static final synthetic a:LDo/G$a;

.field private static final b:LDo/H;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LDo/G$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LDo/G$a;->a:LDo/G$a;

    new-instance v0, LDo/H;

    invoke-static {}, Lkotlin/collections/J;->d()Ljava/util/Map;

    move-result-object v1

    invoke-direct {v0, v1}, LDo/H;-><init>(Ljava/util/Map;)V

    sput-object v0, LDo/G$a;->b:LDo/H;

    return-void
.end method

.method public static a()LDo/H;
    .registers 1

    sget-object v0, LDo/G$a;->b:LDo/H;

    return-object v0
.end method
