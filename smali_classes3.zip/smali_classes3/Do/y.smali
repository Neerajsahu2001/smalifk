.class public final LDo/y;
.super Ljava/lang/Object;
.source "JavaNullabilityAnnotationsStatus.kt"


# static fields
.field private static final d:LDo/y;


# instance fields
.field private final a:LDo/J;

.field private final b:LUn/d;

.field private final c:LDo/J;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, LDo/y;

    sget-object v1, LDo/J;->STRICT:LDo/J;

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2}, LDo/y;-><init>(LDo/J;I)V

    sput-object v0, LDo/y;->d:LDo/y;

    return-void
.end method

.method public constructor <init>(LDo/J;I)V
    .registers 4

    and-int/lit8 p2, p2, 0x2

    if-eqz p2, :cond_b

    new-instance p2, LUn/d;

    const/4 v0, 0x0

    invoke-direct {p2, v0, v0}, LUn/d;-><init>(II)V

    goto :goto_c

    :cond_b
    const/4 p2, 0x0

    :goto_c
    invoke-direct {p0, p1, p2, p1}, LDo/y;-><init>(LDo/J;LUn/d;LDo/J;)V

    return-void
.end method

.method public constructor <init>(LDo/J;LUn/d;LDo/J;)V
    .registers 5

    const-string v0, "reportLevelBefore"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "reportLevelAfter"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LDo/y;->a:LDo/J;

    iput-object p2, p0, LDo/y;->b:LUn/d;

    iput-object p3, p0, LDo/y;->c:LDo/J;

    return-void
.end method

.method public static final synthetic a()LDo/y;
    .registers 1

    sget-object v0, LDo/y;->d:LDo/y;

    return-object v0
.end method


# virtual methods
.method public final b()LDo/J;
    .registers 2

    iget-object v0, p0, LDo/y;->c:LDo/J;

    return-object v0
.end method

.method public final c()LDo/J;
    .registers 2

    iget-object v0, p0, LDo/y;->a:LDo/J;

    return-object v0
.end method

.method public final d()LUn/d;
    .registers 2

    iget-object v0, p0, LDo/y;->b:LUn/d;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LDo/y;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, LDo/y;

    iget-object v1, p1, LDo/y;->a:LDo/J;

    iget-object v3, p0, LDo/y;->a:LDo/J;

    if-eq v3, v1, :cond_13

    return v2

    :cond_13
    iget-object v1, p0, LDo/y;->b:LUn/d;

    iget-object v3, p1, LDo/y;->b:LUn/d;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    return v2

    :cond_1e
    iget-object v1, p0, LDo/y;->c:LDo/J;

    iget-object p1, p1, LDo/y;->c:LDo/J;

    if-eq v1, p1, :cond_25

    return v2

    :cond_25
    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, LDo/y;->a:LDo/J;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, LDo/y;->b:LUn/d;

    if-nez v1, :cond_e

    const/4 v1, 0x0

    goto :goto_12

    :cond_e
    invoke-virtual {v1}, LUn/d;->hashCode()I

    move-result v1

    :goto_12
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, LDo/y;->c:LDo/J;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "JavaNullabilityAnnotationsStatus(reportLevelBefore="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LDo/y;->a:LDo/J;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", sinceVersion="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LDo/y;->b:LUn/d;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", reportLevelAfter="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LDo/y;->c:LDo/J;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
