.class public final LDo/v$a;
.super Ljava/lang/Object;
.source "JavaIncompatibilityRulesOverridabilityCondition.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LDo/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Luo/a;Luo/a;)Z
    .registers 8

    const-string v0, "superDescriptor"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "subDescriptor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p1, LFo/e;

    const/4 v1, 0x0

    if-eqz v0, :cond_82

    instance-of v0, p0, Luo/v;

    if-nez v0, :cond_14

    goto :goto_82

    :cond_14
    move-object v0, p1

    check-cast v0, LFo/e;

    invoke-virtual {v0}, Lxo/w;->e()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    check-cast p0, Luo/v;

    invoke-interface {p0}, Luo/a;->e()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    invoke-virtual {v0}, Lxo/P;->i1()Luo/Q;

    move-result-object v0

    invoke-interface {v0}, Luo/a;->e()Ljava/util/List;

    move-result-object v0

    const-string v2, "subDescriptor.original.valueParameters"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {p0}, Luo/v;->a()Luo/v;

    move-result-object v2

    invoke-interface {v2}, Luo/a;->e()Ljava/util/List;

    move-result-object v2

    const-string v3, "superDescriptor.original.valueParameters"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v0, v2}, Lkotlin/collections/q;->e0(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_4d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_82

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LUn/j;

    invoke-virtual {v2}, LUn/j;->a()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Luo/b0;

    invoke-virtual {v2}, LUn/j;->b()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Luo/b0;

    move-object v4, p1

    check-cast v4, Luo/v;

    const-string v5, "subParameter"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4, v3}, LDo/v$a;->b(Luo/v;Luo/b0;)LMo/r;

    move-result-object v3

    instance-of v3, v3, LMo/r$c;

    const-string v4, "superParameter"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, v2}, LDo/v$a;->b(Luo/v;Luo/b0;)LMo/r;

    move-result-object v2

    instance-of v2, v2, LMo/r$c;

    if-eq v3, v2, :cond_4d

    const/4 p0, 0x1

    return p0

    :cond_82
    :goto_82
    return v1
.end method

.method private static b(Luo/v;Luo/b0;)LMo/r;
    .registers 8

    const-string v0, "f"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Luo/k;->getName()LTo/f;

    move-result-object v0

    invoke-virtual {v0}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    const-string v1, "remove"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "valueParameterDescriptor.type"

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_bf

    invoke-interface {p0}, Luo/a;->e()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ne v0, v3, :cond_bf

    invoke-static {p0}, Lap/c;->l(Luo/b;)Luo/b;

    move-result-object v0

    invoke-interface {v0}, Luo/k;->d()Luo/k;

    move-result-object v0

    instance-of v0, v0, LFo/c;

    if-nez v0, :cond_bf

    invoke-static {p0}, Lro/j;->X(Luo/k;)Z

    move-result v0

    if-eqz v0, :cond_37

    goto/16 :goto_bf

    :cond_37
    invoke-interface {p0}, Luo/v;->a()Luo/v;

    move-result-object v0

    invoke-interface {v0}, Luo/a;->e()Ljava/util/List;

    move-result-object v0

    const-string v4, "f.original.valueParameters"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/b0;

    invoke-interface {v0}, Luo/a0;->getType()Lkp/E;

    move-result-object v0

    const-string v4, "f.original.valueParameters.single().type"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LMo/A;->c(Lkp/E;)LMo/r;

    move-result-object v0

    instance-of v4, v0, LMo/r$c;

    if-eqz v4, :cond_5e

    check-cast v0, LMo/r$c;

    goto :goto_5f

    :cond_5e
    move-object v0, v2

    :goto_5f
    if-eqz v0, :cond_66

    invoke-virtual {v0}, LMo/r$c;->i()Lbp/c;

    move-result-object v0

    goto :goto_67

    :cond_66
    move-object v0, v2

    :goto_67
    sget-object v4, Lbp/c;->INT:Lbp/c;

    if-eq v0, v4, :cond_6c

    goto :goto_bf

    :cond_6c
    invoke-static {p0}, LDo/h;->i(Luo/v;)Luo/v;

    move-result-object v0

    if-nez v0, :cond_73

    goto :goto_bf

    :cond_73
    invoke-interface {v0}, Luo/v;->a()Luo/v;

    move-result-object v4

    invoke-interface {v4}, Luo/a;->e()Ljava/util/List;

    move-result-object v4

    const-string v5, "overridden.original.valueParameters"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Luo/b0;

    invoke-interface {v4}, Luo/a0;->getType()Lkp/E;

    move-result-object v4

    const-string v5, "overridden.original.valueParameters.single().type"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, LMo/A;->c(Lkp/E;)LMo/r;

    move-result-object v4

    invoke-interface {v0}, Luo/k;->d()Luo/k;

    move-result-object v0

    const-string v5, "overridden.containingDeclaration"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lap/c;->h(Luo/k;)LTo/d;

    move-result-object v0

    sget-object v5, Lro/n$a;->J:LTo/c;

    invoke-virtual {v5}, LTo/c;->j()LTo/d;

    move-result-object v5

    invoke-static {v0, v5}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bf

    instance-of v0, v4, LMo/r$b;

    if-eqz v0, :cond_bf

    check-cast v4, LMo/r$b;

    invoke-virtual {v4}, LMo/r$b;->i()Ljava/lang/String;

    move-result-object v0

    const-string v4, "java/lang/Object"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bf

    goto :goto_112

    :cond_bf
    :goto_bf
    invoke-interface {p0}, Luo/a;->e()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-eq v0, v3, :cond_ca

    goto :goto_122

    :cond_ca
    invoke-interface {p0}, Luo/k;->d()Luo/k;

    move-result-object v0

    instance-of v3, v0, Luo/e;

    if-eqz v3, :cond_d5

    check-cast v0, Luo/e;

    goto :goto_d6

    :cond_d5
    move-object v0, v2

    :goto_d6
    if-nez v0, :cond_d9

    goto :goto_122

    :cond_d9
    invoke-interface {p0}, Luo/a;->e()Ljava/util/List;

    move-result-object p0

    const-string v3, "f.valueParameters"

    invoke-static {p0, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Luo/b0;

    invoke-interface {p0}, Luo/a0;->getType()Lkp/E;

    move-result-object p0

    invoke-virtual {p0}, Lkp/E;->N0()Lkp/e0;

    move-result-object p0

    invoke-interface {p0}, Lkp/e0;->n()Luo/h;

    move-result-object p0

    instance-of v3, p0, Luo/e;

    if-eqz v3, :cond_fb

    move-object v2, p0

    check-cast v2, Luo/e;

    :cond_fb
    if-nez v2, :cond_fe

    goto :goto_122

    :cond_fe
    invoke-static {v0}, Lro/j;->h0(Luo/e;)Z

    move-result p0

    if-eqz p0, :cond_122

    invoke-static {v0}, Lap/c;->g(Luo/k;)LTo/c;

    move-result-object p0

    invoke-static {v2}, Lap/c;->g(Luo/k;)LTo/c;

    move-result-object v0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_122

    :goto_112
    invoke-interface {p1}, Luo/a0;->getType()Lkp/E;

    move-result-object p0

    invoke-static {p0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lkp/t0;->k(Lkp/E;)Lkp/v0;

    move-result-object p0

    invoke-static {p0}, LMo/A;->c(Lkp/E;)LMo/r;

    move-result-object p0

    goto :goto_12d

    :cond_122
    :goto_122
    invoke-interface {p1}, Luo/a0;->getType()Lkp/E;

    move-result-object p0

    invoke-static {p0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, LMo/A;->c(Lkp/E;)LMo/r;

    move-result-object p0

    :goto_12d
    return-object p0
.end method
