.class public final LDo/p;
.super Ljava/lang/Object;
.source "FakePureImplementationsProvider.kt"


# static fields
.field private static final a:Ljava/util/LinkedHashMap;

.field private static final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "LTo/c;",
            "LTo/c;",
            ">;"
        }
    .end annotation
.end field

.field public static final synthetic c:I


# direct methods
.method static constructor <clinit>()V
    .registers 7

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    sput-object v0, LDo/p;->a:Ljava/util/LinkedHashMap;

    invoke-static {}, LTo/i;->i()LTo/b;

    move-result-object v1

    const-string v2, "java.util.ArrayList"

    const-string v3, "java.util.LinkedList"

    filled-new-array {v2, v3}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, LDo/p;->a([Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-static {v1, v2}, LDo/p;->c(LTo/b;Ljava/util/ArrayList;)V

    invoke-static {}, LTo/i;->k()LTo/b;

    move-result-object v1

    const-string v2, "java.util.LinkedHashSet"

    const-string v3, "java.util.HashSet"

    const-string v4, "java.util.TreeSet"

    filled-new-array {v3, v4, v2}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, LDo/p;->a([Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-static {v1, v2}, LDo/p;->c(LTo/b;Ljava/util/ArrayList;)V

    invoke-static {}, LTo/i;->j()LTo/b;

    move-result-object v1

    const-string v2, "java.util.TreeMap"

    const-string v3, "java.util.LinkedHashMap"

    const-string v4, "java.util.HashMap"

    const-string v5, "java.util.concurrent.ConcurrentHashMap"

    const-string v6, "java.util.concurrent.ConcurrentSkipListMap"

    filled-new-array {v4, v2, v3, v5, v6}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, LDo/p;->a([Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-static {v1, v2}, LDo/p;->c(LTo/b;Ljava/util/ArrayList;)V

    new-instance v1, LTo/c;

    const-string v2, "java.util.function.Function"

    invoke-direct {v1, v2}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object v1

    const-string v2, "java.util.function.UnaryOperator"

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, LDo/p;->a([Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-static {v1, v2}, LDo/p;->c(LTo/b;Ljava/util/ArrayList;)V

    new-instance v1, LTo/c;

    const-string v2, "java.util.function.BiFunction"

    invoke-direct {v1, v2}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object v1

    const-string v2, "java.util.function.BinaryOperator"

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, LDo/p;->a([Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-static {v1, v2}, LDo/p;->c(LTo/b;Ljava/util/ArrayList;)V

    new-instance v1, Ljava/util/ArrayList;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_89
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_b2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LTo/b;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LTo/b;

    invoke-virtual {v3}, LTo/b;->b()LTo/c;

    move-result-object v3

    invoke-virtual {v2}, LTo/b;->b()LTo/c;

    move-result-object v2

    new-instance v4, LUn/j;

    invoke-direct {v4, v3, v2}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_89

    :cond_b2
    invoke-static {v1}, Lkotlin/collections/J;->k(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LDo/p;->b:Ljava/util/Map;

    return-void
.end method

.method private static varargs a([Ljava/lang/String;)Ljava/util/ArrayList;
    .registers 6

    new-instance v0, Ljava/util/ArrayList;

    array-length v1, p0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    array-length v1, p0

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_1b

    aget-object v3, p0, v2

    new-instance v4, LTo/c;

    invoke-direct {v4, v3}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {v4}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    :cond_1b
    return-object v0
.end method

.method public static b(LTo/c;)LTo/c;
    .registers 2

    sget-object v0, LDo/p;->b:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LTo/c;

    return-object p0
.end method

.method private static c(LTo/b;Ljava/util/ArrayList;)V
    .registers 4

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, LTo/b;

    sget-object v1, LDo/p;->a:Ljava/util/LinkedHashMap;

    invoke-interface {v1, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_17
    return-void
.end method
