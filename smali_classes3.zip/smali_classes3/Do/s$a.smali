.class public final LDo/s$a;
.super Ljava/lang/Object;
.source "JavaClassesTracker.kt"

# interfaces
.implements LDo/s;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LDo/s;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:LDo/s$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LDo/s$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LDo/s$a;->a:LDo/s$a;

    return-void
.end method


# virtual methods
.method public final a(LHo/e;)V
    .registers 2

    return-void
.end method
