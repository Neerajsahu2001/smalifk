.class public abstract LDo/b;
.super Ljava/lang/Object;
.source "AbstractAnnotationTypeQualifierResolver.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<TAnnotation:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static final c:Ljava/util/LinkedHashMap;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field private final a:LDo/z;

.field private final b:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/Object;",
            "TTAnnotation;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 7

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-static {}, LDo/c;->values()[LDo/c;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v2, :cond_1f

    aget-object v4, v1, v3

    invoke-virtual {v4}, LDo/c;->a()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_1c

    invoke-interface {v0, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1c
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_1f
    sput-object v0, LDo/b;->c:Ljava/util/LinkedHashMap;

    return-void
.end method

.method public constructor <init>(LDo/z;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LDo/b;->a:LDo/z;

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p1, p0, LDo/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method

.method private final e(Ljava/lang/Object;Leo/l;)LLo/k;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;",
            "Leo/l<",
            "-TTAnnotation;",
            "Ljava/lang/Boolean;",
            ">;)",
            "LLo/k;"
        }
    .end annotation

    invoke-interface {p2, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-direct {p0, p1, v0}, LDo/b;->k(Ljava/lang/Object;Z)LLo/k;

    move-result-object v0

    if-eqz v0, :cond_11

    return-object v0

    :cond_11
    invoke-virtual {p0, p1}, LDo/b;->m(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_19

    return-object v1

    :cond_19
    invoke-direct {p0, p1}, LDo/b;->l(Ljava/lang/Object;)LDo/J;

    move-result-object p1

    if-eqz p1, :cond_20

    goto :goto_2a

    :cond_20
    iget-object p1, p0, LDo/b;->a:LDo/z;

    invoke-virtual {p1}, LDo/z;->d()LDo/C;

    move-result-object p1

    invoke-virtual {p1}, LDo/C;->a()LDo/J;

    move-result-object p1

    :goto_2a
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, LDo/J;->IGNORE:LDo/J;

    if-ne p1, v2, :cond_32

    return-object v1

    :cond_32
    invoke-interface {p2, v0}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    invoke-direct {p0, v0, p2}, LDo/b;->k(Ljava/lang/Object;Z)LLo/k;

    move-result-object p2

    if-eqz p2, :cond_4e

    sget-object v0, LDo/J;->WARN:LDo/J;

    const/4 v2, 0x1

    if-ne p1, v0, :cond_49

    const/4 p1, 0x1

    goto :goto_4a

    :cond_49
    const/4 p1, 0x0

    :goto_4a
    invoke-static {p2, v1, p1, v2}, LLo/k;->a(LLo/k;LLo/j;ZI)LLo/k;

    move-result-object v1

    :cond_4e
    return-object v1
.end method

.method private final f(Ljava/lang/Object;LTo/c;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;",
            "LTo/c;",
            ")TTAnnotation;"
        }
    .end annotation

    invoke-virtual {p0, p1}, LDo/b;->i(Ljava/lang/Object;)Ljava/lang/Iterable;

    move-result-object p1

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_8
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v0}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v1

    invoke-static {v1, p2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8

    goto :goto_1e

    :cond_1d
    const/4 v0, 0x0

    :goto_1e
    return-object v0
.end method

.method private final j(Ljava/lang/Object;LTo/c;)Z
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;",
            "LTo/c;",
            ")Z"
        }
    .end annotation

    invoke-virtual {p0, p1}, LDo/b;->i(Ljava/lang/Object;)Ljava/lang/Iterable;

    move-result-object p1

    instance-of v0, p1, Ljava/util/Collection;

    const/4 v1, 0x0

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_13

    goto :goto_2c

    :cond_13
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_17
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v0}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v0

    invoke-static {v0, p2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_17

    const/4 v1, 0x1

    :cond_2c
    :goto_2c
    return v1
.end method

.method private final k(Ljava/lang/Object;Z)LLo/k;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;Z)",
            "LLo/k;"
        }
    .end annotation

    invoke-virtual {p0, p1}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return-object v1

    :cond_8
    iget-object v2, p0, LDo/b;->a:LDo/z;

    invoke-virtual {v2}, LDo/z;->c()Leo/l;

    move-result-object v2

    invoke-interface {v2, v0}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LDo/J;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, LDo/J;->IGNORE:LDo/J;

    if-ne v2, v3, :cond_1c

    return-object v1

    :cond_1c
    invoke-static {}, LDo/F;->l()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_2b

    sget-object p1, LLo/j;->NULLABLE:LLo/j;

    goto/16 :goto_d3

    :cond_2b
    invoke-static {}, LDo/F;->k()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_39

    sget-object p1, LLo/j;->NOT_NULL:LLo/j;

    goto/16 :goto_d3

    :cond_39
    invoke-static {}, LDo/F;->g()LTo/c;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_47

    sget-object p1, LLo/j;->NULLABLE:LLo/j;

    goto/16 :goto_d3

    :cond_47
    invoke-static {}, LDo/F;->h()LTo/c;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_55

    sget-object p1, LLo/j;->FORCE_FLEXIBILITY:LLo/j;

    goto/16 :goto_d3

    :cond_55
    invoke-static {}, LDo/F;->f()LTo/c;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a0

    invoke-virtual {p0, p1, v4}, LDo/b;->a(Ljava/lang/Object;Z)Ljava/util/ArrayList;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/q;->s(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-eqz p1, :cond_9d

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_e2

    goto :goto_99

    :sswitch_73
    const-string v0, "ALWAYS"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_99

    goto :goto_9d

    :sswitch_7c
    const-string v0, "UNKNOWN"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_85

    goto :goto_99

    :cond_85
    sget-object p1, LLo/j;->FORCE_FLEXIBILITY:LLo/j;

    goto :goto_d3

    :sswitch_88
    const-string v0, "NEVER"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_9a

    goto :goto_99

    :sswitch_91
    const-string v0, "MAYBE"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_9a

    :cond_99
    :goto_99
    return-object v1

    :cond_9a
    sget-object p1, LLo/j;->NULLABLE:LLo/j;

    goto :goto_d3

    :cond_9d
    :goto_9d
    sget-object p1, LLo/j;->NOT_NULL:LLo/j;

    goto :goto_d3

    :cond_a0
    invoke-static {}, LDo/F;->d()LTo/c;

    move-result-object p1

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_ad

    sget-object p1, LLo/j;->NULLABLE:LLo/j;

    goto :goto_d3

    :cond_ad
    invoke-static {}, LDo/F;->c()LTo/c;

    move-result-object p1

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_ba

    sget-object p1, LLo/j;->NOT_NULL:LLo/j;

    goto :goto_d3

    :cond_ba
    invoke-static {}, LDo/F;->a()LTo/c;

    move-result-object p1

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_c7

    sget-object p1, LLo/j;->NOT_NULL:LLo/j;

    goto :goto_d3

    :cond_c7
    invoke-static {}, LDo/F;->b()LTo/c;

    move-result-object p1

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_e1

    sget-object p1, LLo/j;->NULLABLE:LLo/j;

    :goto_d3
    new-instance v0, LLo/k;

    sget-object v1, LDo/J;->WARN:LDo/J;

    if-ne v2, v1, :cond_da

    goto :goto_dc

    :cond_da
    if-eqz p2, :cond_dd

    :goto_dc
    const/4 v4, 0x1

    :cond_dd
    invoke-direct {v0, p1, v4}, LLo/k;-><init>(LLo/j;Z)V

    return-object v0

    :cond_e1
    return-object v1

    :sswitch_data_e2
    .sparse-switch
        0x45bf448 -> :sswitch_91
        0x46bd26c -> :sswitch_88
        0x19d1382a -> :sswitch_7c
        0x7342860f -> :sswitch_73
    .end sparse-switch
.end method

.method private final l(Ljava/lang/Object;)LDo/J;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;)",
            "LDo/J;"
        }
    .end annotation

    iget-object v0, p0, LDo/b;->a:LDo/z;

    invoke-virtual {v0}, LDo/z;->d()LDo/C;

    move-result-object v1

    invoke-virtual {v1}, LDo/C;->c()Ljava/util/Map;

    move-result-object v1

    invoke-virtual {p0, p1}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LDo/J;

    if-eqz v1, :cond_17

    return-object v1

    :cond_17
    invoke-static {}, LDo/d;->d()LTo/c;

    move-result-object v1

    invoke-direct {p0, p1, v1}, LDo/b;->f(Ljava/lang/Object;LTo/c;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    if-eqz p1, :cond_73

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v2}, LDo/b;->a(Ljava/lang/Object;Z)Ljava/util/ArrayList;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/q;->s(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_30

    goto :goto_73

    :cond_30
    invoke-virtual {v0}, LDo/z;->d()LDo/C;

    move-result-object v0

    invoke-virtual {v0}, LDo/C;->b()LDo/J;

    move-result-object v0

    if-nez v0, :cond_72

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v2, -0x7f610e2e

    if-eq v0, v2, :cond_66

    const v2, -0x6d97ad37

    if-eq v0, v2, :cond_5a

    const v2, 0x288a86

    if-eq v0, v2, :cond_4e

    goto :goto_73

    :cond_4e
    const-string v0, "WARN"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_57

    goto :goto_73

    :cond_57
    sget-object v1, LDo/J;->WARN:LDo/J;

    goto :goto_73

    :cond_5a
    const-string v0, "STRICT"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_63

    goto :goto_73

    :cond_63
    sget-object v1, LDo/J;->STRICT:LDo/J;

    goto :goto_73

    :cond_66
    const-string v0, "IGNORE"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6f

    goto :goto_73

    :cond_6f
    sget-object v1, LDo/J;->IGNORE:LDo/J;

    goto :goto_73

    :cond_72
    move-object v1, v0

    :cond_73
    :goto_73
    return-object v1
.end method


# virtual methods
.method protected abstract a(Ljava/lang/Object;Z)Ljava/util/ArrayList;
.end method

.method public final b(LDo/A;Ljava/lang/Iterable;)LDo/A;
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LDo/A;",
            "Ljava/lang/Iterable<",
            "+TTAnnotation;>;)",
            "LDo/A;"
        }
    .end annotation

    move-object/from16 v0, p0

    const-string v1, "annotations"

    move-object/from16 v2, p2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v0, LDo/b;->a:LDo/z;

    invoke-virtual {v1}, LDo/z;->b()Z

    move-result v3

    if-eqz v3, :cond_12

    return-object p1

    :cond_12
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {p2 .. p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1b
    :goto_1b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_17f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1}, LDo/z;->b()Z

    move-result v7

    const/4 v8, 0x0

    if-eqz v7, :cond_30

    :cond_2e
    :goto_2e
    move-object v7, v8

    goto :goto_86

    :cond_30
    invoke-static {}, LDo/d;->a()Ljava/util/LinkedHashMap;

    move-result-object v7

    invoke-virtual {v0, v4}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LDo/t;

    if-eqz v7, :cond_2e

    invoke-virtual {v0, v4}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v9

    if-eqz v9, :cond_5b

    invoke-static {}, LDo/d;->c()Ljava/util/Map;

    move-result-object v10

    invoke-interface {v10, v9}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_5b

    invoke-virtual {v1}, LDo/z;->c()Leo/l;

    move-result-object v10

    invoke-interface {v10, v9}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LDo/J;

    goto :goto_6a

    :cond_5b
    invoke-direct {v0, v4}, LDo/b;->l(Ljava/lang/Object;)LDo/J;

    move-result-object v9

    if-eqz v9, :cond_62

    goto :goto_6a

    :cond_62
    invoke-virtual {v1}, LDo/z;->d()LDo/C;

    move-result-object v9

    invoke-virtual {v9}, LDo/C;->a()LDo/J;

    move-result-object v9

    :goto_6a
    sget-object v10, LDo/J;->IGNORE:LDo/J;

    if-eq v9, v10, :cond_6f

    goto :goto_70

    :cond_6f
    move-object v9, v8

    :goto_70
    if-nez v9, :cond_73

    goto :goto_2e

    :cond_73
    invoke-virtual {v7}, LDo/t;->c()LLo/k;

    move-result-object v10

    sget-object v11, LDo/J;->WARN:LDo/J;

    if-ne v9, v11, :cond_7d

    const/4 v9, 0x1

    goto :goto_7e

    :cond_7d
    const/4 v9, 0x0

    :goto_7e
    invoke-static {v10, v8, v9, v5}, LLo/k;->a(LLo/k;LLo/j;ZI)LLo/k;

    move-result-object v9

    invoke-static {v7, v9}, LDo/t;->a(LDo/t;LLo/k;)LDo/t;

    move-result-object v7

    :goto_86
    if-eqz v7, :cond_8b

    move-object v8, v7

    goto/16 :goto_178

    :cond_8b
    invoke-virtual {v1}, LDo/z;->d()LDo/C;

    move-result-object v7

    invoke-virtual {v7}, LDo/C;->d()Z

    move-result v7

    if-eqz v7, :cond_98

    :goto_95
    move-object v7, v8

    goto/16 :goto_134

    :cond_98
    invoke-static {}, LDo/d;->e()LTo/c;

    move-result-object v7

    invoke-direct {v0, v4, v7}, LDo/b;->f(Ljava/lang/Object;LTo/c;)Ljava/lang/Object;

    move-result-object v7

    if-nez v7, :cond_a3

    goto :goto_95

    :cond_a3
    invoke-virtual {v0, v4}, LDo/b;->i(Ljava/lang/Object;)Ljava/lang/Iterable;

    move-result-object v9

    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_ab
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_bc

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v0, v10}, LDo/b;->m(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    if-eqz v11, :cond_ab

    goto :goto_bd

    :cond_bc
    move-object v10, v8

    :goto_bd
    if-nez v10, :cond_c0

    goto :goto_95

    :cond_c0
    invoke-virtual {v0, v7, v5}, LDo/b;->a(Ljava/lang/Object;Z)Ljava/util/ArrayList;

    move-result-object v7

    new-instance v9, Ljava/util/LinkedHashSet;

    invoke-direct {v9}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_cd
    :goto_cd
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_e7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    sget-object v12, LDo/b;->c:Ljava/util/LinkedHashMap;

    invoke-virtual {v12, v11}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, LDo/c;

    if-eqz v11, :cond_cd

    invoke-interface {v9, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_cd

    :cond_e7
    new-instance v7, LUn/j;

    sget-object v11, LDo/c;->TYPE_USE:LDo/c;

    invoke-interface {v9, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_131

    invoke-static {}, LDo/c;->values()[LDo/c;

    move-result-object v11

    invoke-static {v11}, Lkotlin/collections/h;->D([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v11

    sget-object v12, LDo/c;->TYPE_PARAMETER_BOUNDS:LDo/c;

    new-instance v13, Ljava/util/LinkedHashSet;

    invoke-interface {v11}, Ljava/util/Set;->size()I

    move-result v14

    invoke-static {v14}, Lkotlin/collections/J;->g(I)I

    move-result v14

    invoke-direct {v13, v14}, Ljava/util/LinkedHashSet;-><init>(I)V

    check-cast v11, Ljava/lang/Iterable;

    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    const/4 v14, 0x0

    :cond_10f
    :goto_10f
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_12d

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    if-nez v14, :cond_125

    invoke-static {v15, v12}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_125

    const/4 v14, 0x1

    const/16 v16, 0x0

    goto :goto_127

    :cond_125
    const/16 v16, 0x1

    :goto_127
    if-eqz v16, :cond_10f

    invoke-interface {v13, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_10f

    :cond_12d
    invoke-static {v13, v9}, Lkotlin/collections/O;->c(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    move-result-object v9

    :cond_131
    invoke-direct {v7, v10, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_134
    if-nez v7, :cond_137

    goto :goto_178

    :cond_137
    invoke-virtual {v7}, LUn/j;->a()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v7}, LUn/j;->b()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Set;

    invoke-direct {v0, v4}, LDo/b;->l(Ljava/lang/Object;)LDo/J;

    move-result-object v4

    if-nez v4, :cond_156

    invoke-direct {v0, v9}, LDo/b;->l(Ljava/lang/Object;)LDo/J;

    move-result-object v4

    if-eqz v4, :cond_14e

    goto :goto_156

    :cond_14e
    invoke-virtual {v1}, LDo/z;->d()LDo/C;

    move-result-object v4

    invoke-virtual {v4}, LDo/C;->a()LDo/J;

    move-result-object v4

    :cond_156
    :goto_156
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v10, LDo/J;->IGNORE:LDo/J;

    if-ne v4, v10, :cond_15e

    goto :goto_178

    :cond_15e
    sget-object v10, LDo/a;->a:LDo/a;

    invoke-direct {v0, v9, v10}, LDo/b;->e(Ljava/lang/Object;Leo/l;)LLo/k;

    move-result-object v9

    if-nez v9, :cond_167

    goto :goto_178

    :cond_167
    new-instance v10, LDo/t;

    sget-object v11, LDo/J;->WARN:LDo/J;

    if-ne v4, v11, :cond_16e

    const/4 v6, 0x1

    :cond_16e
    invoke-static {v9, v8, v6, v5}, LLo/k;->a(LLo/k;LLo/j;ZI)LLo/k;

    move-result-object v4

    check-cast v7, Ljava/util/Collection;

    invoke-direct {v10, v4, v7}, LDo/t;-><init>(LLo/k;Ljava/util/Collection;)V

    move-object v8, v10

    :goto_178
    if-eqz v8, :cond_1b

    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1b

    :cond_17f
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_186

    return-object p1

    :cond_186
    if-eqz p1, :cond_194

    invoke-virtual/range {p1 .. p1}, LDo/A;->b()Ljava/util/EnumMap;

    move-result-object v1

    if-eqz v1, :cond_194

    new-instance v2, Ljava/util/EnumMap;

    invoke-direct {v2, v1}, Ljava/util/EnumMap;-><init>(Ljava/util/EnumMap;)V

    goto :goto_19b

    :cond_194
    new-instance v2, Ljava/util/EnumMap;

    const-class v1, LDo/c;

    invoke-direct {v2, v1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    :goto_19b
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_19f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1c4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LDo/t;

    invoke-virtual {v3}, LDo/t;->d()Ljava/util/Collection;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1b3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_19f

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LDo/c;

    invoke-interface {v2, v6, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    goto :goto_1b3

    :cond_1c4
    if-nez v6, :cond_1c9

    move-object/from16 v1, p1

    goto :goto_1ce

    :cond_1c9
    new-instance v1, LDo/A;

    invoke-direct {v1, v2}, LDo/A;-><init>(Ljava/util/EnumMap;)V

    :goto_1ce
    return-object v1
.end method

.method public final c(Ljava/lang/Iterable;)LLo/h;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+TTAnnotation;>;)",
            "LLo/h;"
        }
    .end annotation

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v0, 0x0

    move-object v1, v0

    :cond_6
    :goto_6
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_34

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v2}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v2

    invoke-static {}, LDo/F;->m()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_21

    sget-object v2, LLo/h;->READ_ONLY:LLo/h;

    goto :goto_2d

    :cond_21
    invoke-static {}, LDo/F;->j()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    sget-object v2, LLo/h;->MUTABLE:LLo/h;

    :goto_2d
    if-eqz v1, :cond_32

    if-eq v1, v2, :cond_32

    return-object v0

    :cond_32
    move-object v1, v2

    goto :goto_6

    :cond_34
    return-object v1
.end method

.method public final d(Ljava/lang/Iterable;Leo/l;)LLo/k;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+TTAnnotation;>;",
            "Leo/l<",
            "-TTAnnotation;",
            "Ljava/lang/Boolean;",
            ">;)",
            "LLo/k;"
        }
    .end annotation

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v0, 0x0

    move-object v1, v0

    :cond_6
    :goto_6
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    invoke-direct {p0, v2, p2}, LDo/b;->e(Ljava/lang/Object;Leo/l;)LLo/k;

    move-result-object v2

    if-nez v1, :cond_17

    goto :goto_39

    :cond_17
    if-eqz v2, :cond_6

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_20

    goto :goto_6

    :cond_20
    invoke-virtual {v2}, LLo/k;->c()Z

    move-result v3

    if-eqz v3, :cond_2d

    invoke-virtual {v1}, LLo/k;->c()Z

    move-result v3

    if-nez v3, :cond_2d

    goto :goto_6

    :cond_2d
    invoke-virtual {v2}, LLo/k;->c()Z

    move-result v3

    if-nez v3, :cond_3b

    invoke-virtual {v1}, LLo/k;->c()Z

    move-result v1

    if-eqz v1, :cond_3b

    :goto_39
    move-object v1, v2

    goto :goto_6

    :cond_3b
    return-object v0

    :cond_3c
    return-object v1
.end method

.method protected abstract g(Ljava/lang/Object;)LTo/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;)",
            "LTo/c;"
        }
    .end annotation
.end method

.method protected abstract h(Ljava/lang/Object;)Luo/e;
.end method

.method protected abstract i(Ljava/lang/Object;)Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;)",
            "Ljava/lang/Iterable<",
            "TTAnnotation;>;"
        }
    .end annotation
.end method

.method public final m(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TTAnnotation;)TTAnnotation;"
        }
    .end annotation

    const-string v0, "annotation"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LDo/b;->a:LDo/z;

    invoke-virtual {v0}, LDo/z;->d()LDo/C;

    move-result-object v0

    invoke-virtual {v0}, LDo/C;->d()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_13

    return-object v1

    :cond_13
    invoke-static {}, LDo/d;->b()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-virtual {p0, p1}, LDo/b;->g(Ljava/lang/Object;)LTo/c;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/collections/q;->m(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6b

    invoke-static {}, LDo/d;->f()LTo/c;

    move-result-object v0

    invoke-direct {p0, p1, v0}, LDo/b;->j(Ljava/lang/Object;LTo/c;)Z

    move-result v0

    if-eqz v0, :cond_2e

    goto :goto_6b

    :cond_2e
    invoke-static {}, LDo/d;->g()LTo/c;

    move-result-object v0

    invoke-direct {p0, p1, v0}, LDo/b;->j(Ljava/lang/Object;LTo/c;)Z

    move-result v0

    if-nez v0, :cond_39

    return-object v1

    :cond_39
    iget-object v0, p0, LDo/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p0, p1}, LDo/b;->h(Ljava/lang/Object;)Luo/e;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_6a

    invoke-virtual {p0, p1}, LDo/b;->i(Ljava/lang/Object;)Ljava/lang/Iterable;

    move-result-object p1

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_4d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5e

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p0, v3}, LDo/b;->m(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_4d

    goto :goto_5f

    :cond_5e
    move-object v3, v1

    :goto_5f
    if-nez v3, :cond_62

    return-object v1

    :cond_62
    invoke-virtual {v0, v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-nez p1, :cond_69

    goto :goto_6a

    :cond_69
    move-object v3, p1

    :cond_6a
    :goto_6a
    return-object v3

    :cond_6b
    :goto_6b
    return-object p1
.end method
