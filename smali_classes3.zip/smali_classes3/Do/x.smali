.class public final LDo/x;
.super Ljava/lang/Object;
.source "JavaNullabilityAnnotationSettings.kt"


# static fields
.field private static final a:LTo/c;

.field private static final b:[LTo/c;

.field private static final c:LDo/H;

.field private static final d:LDo/y;


# direct methods
.method static constructor <clinit>()V
    .registers 23

    new-instance v3, LTo/c;

    const-string v4, "org.jspecify.nullness"

    invoke-direct {v3, v4}, LTo/c;-><init>(Ljava/lang/String;)V

    sput-object v3, LDo/x;->a:LTo/c;

    new-instance v4, LTo/c;

    const-string v5, "io.reactivex.rxjava3.annotations"

    invoke-direct {v4, v5}, LTo/c;-><init>(Ljava/lang/String;)V

    new-instance v5, LTo/c;

    const-string v6, "org.checkerframework.checker.nullness.compatqual"

    invoke-direct {v5, v6}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, LTo/c;->b()Ljava/lang/String;

    move-result-object v6

    const-string v7, "RXJAVA3_ANNOTATIONS_PACKAGE.asString()"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v7, LTo/c;

    const-string v8, ".Nullable"

    invoke-virtual {v6, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, LTo/c;-><init>(Ljava/lang/String;)V

    new-instance v8, LTo/c;

    const-string v9, ".NonNull"

    invoke-virtual {v6, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v8, v6}, LTo/c;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    new-array v9, v6, [LTo/c;

    const/4 v10, 0x0

    aput-object v7, v9, v10

    const/4 v7, 0x1

    aput-object v8, v9, v7

    sput-object v9, LDo/x;->b:[LTo/c;

    new-instance v8, LDo/H;

    new-instance v9, LTo/c;

    const-string v11, "org.jetbrains.annotations"

    invoke-direct {v9, v11}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v11

    new-instance v12, LUn/j;

    invoke-direct {v12, v9, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, LTo/c;

    const-string v11, "androidx.annotation"

    invoke-direct {v9, v11}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v11

    new-instance v13, LUn/j;

    invoke-direct {v13, v9, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, LTo/c;

    const-string v11, "android.support.annotation"

    invoke-direct {v9, v11}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v11

    new-instance v14, LUn/j;

    invoke-direct {v14, v9, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, LTo/c;

    const-string v11, "android.annotation"

    invoke-direct {v9, v11}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v11

    new-instance v15, LUn/j;

    invoke-direct {v15, v9, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, LTo/c;

    const-string v11, "com.android.annotations"

    invoke-direct {v9, v11}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v11

    new-instance v6, LUn/j;

    invoke-direct {v6, v9, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, LTo/c;

    const-string v11, "org.eclipse.jdt.annotation"

    invoke-direct {v9, v11}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v11

    new-instance v7, LUn/j;

    invoke-direct {v7, v9, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, LTo/c;

    const-string v11, "org.checkerframework.checker.nullness.qual"

    invoke-direct {v9, v11}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v11

    new-instance v0, LUn/j;

    invoke-direct {v0, v9, v11}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v9

    new-instance v11, LUn/j;

    invoke-direct {v11, v5, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LTo/c;

    const-string v9, "javax.annotation"

    invoke-direct {v5, v9}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v9

    new-instance v1, LUn/j;

    invoke-direct {v1, v5, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LTo/c;

    const-string v9, "edu.umd.cs.findbugs.annotations"

    invoke-direct {v5, v9}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v9

    new-instance v10, LUn/j;

    invoke-direct {v10, v5, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LTo/c;

    const-string v9, "io.reactivex.annotations"

    invoke-direct {v5, v9}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v9

    new-instance v2, LUn/j;

    invoke-direct {v2, v5, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LTo/c;

    const-string v9, "androidx.annotation.RecentlyNullable"

    invoke-direct {v5, v9}, LTo/c;-><init>(Ljava/lang/String;)V

    new-instance v9, LDo/y;

    move-object/from16 v17, v8

    sget-object v8, LDo/J;->WARN:LDo/J;

    move-object/from16 v18, v2

    const/4 v2, 0x4

    invoke-direct {v9, v8, v2}, LDo/y;-><init>(LDo/J;I)V

    new-instance v2, LUn/j;

    invoke-direct {v2, v5, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LTo/c;

    const-string v9, "androidx.annotation.RecentlyNonNull"

    invoke-direct {v5, v9}, LTo/c;-><init>(Ljava/lang/String;)V

    new-instance v9, LDo/y;

    move-object/from16 v19, v2

    const/4 v2, 0x4

    invoke-direct {v9, v8, v2}, LDo/y;-><init>(LDo/J;I)V

    new-instance v2, LUn/j;

    invoke-direct {v2, v5, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LTo/c;

    const-string v9, "lombok"

    invoke-direct {v5, v9}, LTo/c;-><init>(Ljava/lang/String;)V

    invoke-static {}, LDo/y;->a()LDo/y;

    move-result-object v9

    move-object/from16 v20, v2

    new-instance v2, LUn/j;

    invoke-direct {v2, v5, v9}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LDo/y;

    new-instance v9, LUn/d;

    move-object/from16 v21, v2

    move-object/from16 v16, v10

    const/4 v2, 0x0

    const/16 v10, 0x9

    invoke-direct {v9, v10, v2}, LUn/d;-><init>(II)V

    sget-object v10, LDo/J;->STRICT:LDo/J;

    invoke-direct {v5, v8, v9, v10}, LDo/y;-><init>(LDo/J;LUn/d;LDo/J;)V

    new-instance v9, LUn/j;

    invoke-direct {v9, v3, v5}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v3, LDo/y;

    new-instance v5, LUn/d;

    move-object/from16 v22, v9

    const/16 v9, 0x8

    invoke-direct {v5, v9, v2}, LUn/d;-><init>(II)V

    invoke-direct {v3, v8, v5, v10}, LDo/y;-><init>(LDo/J;LUn/d;LDo/J;)V

    new-instance v5, LUn/j;

    invoke-direct {v5, v4, v3}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v3, 0x10

    new-array v3, v3, [LUn/j;

    aput-object v12, v3, v2

    const/4 v2, 0x1

    aput-object v13, v3, v2

    const/4 v2, 0x2

    aput-object v14, v3, v2

    const/4 v2, 0x3

    aput-object v15, v3, v2

    const/4 v2, 0x4

    aput-object v6, v3, v2

    const/4 v2, 0x5

    aput-object v7, v3, v2

    const/4 v2, 0x6

    aput-object v0, v3, v2

    const/4 v0, 0x7

    aput-object v11, v3, v0

    const/16 v0, 0x8

    aput-object v1, v3, v0

    const/16 v0, 0x9

    aput-object v16, v3, v0

    const/16 v0, 0xa

    aput-object v18, v3, v0

    const/16 v0, 0xb

    aput-object v19, v3, v0

    const/16 v0, 0xc

    aput-object v20, v3, v0

    const/16 v0, 0xd

    aput-object v21, v3, v0

    const/16 v0, 0xe

    aput-object v22, v3, v0

    const/16 v0, 0xf

    aput-object v5, v3, v0

    invoke-static {v3}, Lkotlin/collections/J;->i([LUn/j;)Ljava/util/Map;

    move-result-object v0

    move-object/from16 v1, v17

    invoke-direct {v1, v0}, LDo/H;-><init>(Ljava/util/Map;)V

    sput-object v1, LDo/x;->c:LDo/H;

    new-instance v0, LDo/y;

    const/4 v1, 0x4

    invoke-direct {v0, v8, v1}, LDo/y;-><init>(LDo/J;I)V

    sput-object v0, LDo/x;->d:LDo/y;

    return-void
.end method

.method public static a()LDo/C;
    .registers 3

    sget-object v0, LUn/d;->e:LUn/d;

    const-string v1, "configuredKotlinVersion"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, LDo/x;->d:LDo/y;

    invoke-virtual {v1}, LDo/y;->d()LUn/d;

    move-result-object v2

    if-eqz v2, :cond_1e

    invoke-virtual {v1}, LDo/y;->d()LUn/d;

    move-result-object v2

    invoke-virtual {v2, v0}, LUn/d;->a(LUn/d;)I

    move-result v0

    if-gtz v0, :cond_1e

    invoke-virtual {v1}, LDo/y;->b()LDo/J;

    move-result-object v0

    goto :goto_22

    :cond_1e
    invoke-virtual {v1}, LDo/y;->c()LDo/J;

    move-result-object v0

    :goto_22
    const-string v1, "globalReportLevel"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, LDo/J;->WARN:LDo/J;

    if-ne v0, v1, :cond_2d

    const/4 v1, 0x0

    goto :goto_2e

    :cond_2d
    move-object v1, v0

    :goto_2e
    new-instance v2, LDo/C;

    invoke-direct {v2, v0, v1}, LDo/C;-><init>(LDo/J;LDo/J;)V

    return-object v2
.end method

.method public static final b(LTo/c;)LDo/J;
    .registers 5

    const-string v0, "annotationFqName"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LDo/G;->a:LDo/G$a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, LDo/G$a;->a()LDo/H;

    move-result-object v0

    new-instance v1, LUn/d;

    const/16 v2, 0x14

    const/4 v3, 0x7

    invoke-direct {v1, v3, v2}, LUn/d;-><init>(II)V

    const-string v2, "configuredReportLevels"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, p0}, LDo/H;->a(LTo/c;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LDo/J;

    if-eqz v0, :cond_24

    goto :goto_4c

    :cond_24
    sget-object v0, LDo/x;->c:LDo/H;

    invoke-virtual {v0, p0}, LDo/H;->a(LTo/c;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LDo/y;

    if-nez p0, :cond_31

    sget-object v0, LDo/J;->IGNORE:LDo/J;

    goto :goto_4c

    :cond_31
    invoke-virtual {p0}, LDo/y;->d()LUn/d;

    move-result-object v0

    if-eqz v0, :cond_47

    invoke-virtual {p0}, LDo/y;->d()LUn/d;

    move-result-object v0

    invoke-virtual {v0, v1}, LUn/d;->a(LUn/d;)I

    move-result v0

    if-gtz v0, :cond_47

    invoke-virtual {p0}, LDo/y;->b()LDo/J;

    move-result-object p0

    :goto_45
    move-object v0, p0

    goto :goto_4c

    :cond_47
    invoke-virtual {p0}, LDo/y;->c()LDo/J;

    move-result-object p0

    goto :goto_45

    :goto_4c
    return-object v0
.end method

.method public static final c()LTo/c;
    .registers 1

    sget-object v0, LDo/x;->a:LTo/c;

    return-object v0
.end method

.method public static final d()[LTo/c;
    .registers 1

    sget-object v0, LDo/x;->b:[LTo/c;

    return-object v0
.end method
