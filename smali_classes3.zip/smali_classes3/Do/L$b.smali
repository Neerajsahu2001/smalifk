.class public final enum LDo/L$b;
.super Ljava/lang/Enum;
.source "SpecialGenericSignatures.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LDo/L;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LDo/L$b;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LDo/L$b;

.field public static final enum OBJECT_PARAMETER_GENERIC:LDo/L$b;

.field public static final enum OBJECT_PARAMETER_NON_GENERIC:LDo/L$b;

.field public static final enum ONE_COLLECTION_PARAMETER:LDo/L$b;


# instance fields
.field private final isObjectReplacedWithTypeParameter:Z

.field private final valueParametersSignature:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    new-instance v0, LDo/L$b;

    const/4 v1, 0x0

    const-string v2, "Ljava/util/Collection<+Ljava/lang/Object;>;"

    const-string v3, "ONE_COLLECTION_PARAMETER"

    invoke-direct {v0, v1, v3, v2, v1}, LDo/L$b;-><init>(ILjava/lang/String;Ljava/lang/String;Z)V

    sput-object v0, LDo/L$b;->ONE_COLLECTION_PARAMETER:LDo/L$b;

    new-instance v2, LDo/L$b;

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v5, "OBJECT_PARAMETER_NON_GENERIC"

    invoke-direct {v2, v4, v5, v3, v4}, LDo/L$b;-><init>(ILjava/lang/String;Ljava/lang/String;Z)V

    sput-object v2, LDo/L$b;->OBJECT_PARAMETER_NON_GENERIC:LDo/L$b;

    new-instance v3, LDo/L$b;

    const/4 v5, 0x2

    const-string v6, "Ljava/lang/Object;"

    const-string v7, "OBJECT_PARAMETER_GENERIC"

    invoke-direct {v3, v5, v7, v6, v4}, LDo/L$b;-><init>(ILjava/lang/String;Ljava/lang/String;Z)V

    sput-object v3, LDo/L$b;->OBJECT_PARAMETER_GENERIC:LDo/L$b;

    const/4 v6, 0x3

    new-array v6, v6, [LDo/L$b;

    aput-object v0, v6, v1

    aput-object v2, v6, v4

    aput-object v3, v6, v5

    sput-object v6, LDo/L$b;->$VALUES:[LDo/L$b;

    return-void
.end method

.method private constructor <init>(ILjava/lang/String;Ljava/lang/String;Z)V
    .registers 5

    invoke-direct {p0, p2, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, LDo/L$b;->valueParametersSignature:Ljava/lang/String;

    iput-boolean p4, p0, LDo/L$b;->isObjectReplacedWithTypeParameter:Z

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LDo/L$b;
    .registers 2

    const-class v0, LDo/L$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LDo/L$b;

    return-object p0
.end method

.method public static values()[LDo/L$b;
    .registers 1

    sget-object v0, LDo/L$b;->$VALUES:[LDo/L$b;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LDo/L$b;

    return-object v0
.end method
