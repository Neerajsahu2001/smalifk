.class public final LDo/d;
.super Ljava/lang/Object;
.source "AnnotationQualifiersFqNames.kt"


# static fields
.field private static final a:LTo/c;

.field private static final b:LTo/c;

.field private static final c:LTo/c;

.field private static final d:LTo/c;

.field private static final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LDo/c;",
            ">;"
        }
    .end annotation
.end field

.field private static final f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "LTo/c;",
            "LDo/t;",
            ">;"
        }
    .end annotation
.end field

.field private static final g:Ljava/util/LinkedHashMap;

.field private static final h:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LTo/c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 10

    new-instance v0, LTo/c;

    const-string v1, "javax.annotation.meta.TypeQualifierNickname"

    invoke-direct {v0, v1}, LTo/c;-><init>(Ljava/lang/String;)V

    sput-object v0, LDo/d;->a:LTo/c;

    new-instance v0, LTo/c;

    const-string v1, "javax.annotation.meta.TypeQualifier"

    invoke-direct {v0, v1}, LTo/c;-><init>(Ljava/lang/String;)V

    sput-object v0, LDo/d;->b:LTo/c;

    new-instance v0, LTo/c;

    const-string v1, "javax.annotation.meta.TypeQualifierDefault"

    invoke-direct {v0, v1}, LTo/c;-><init>(Ljava/lang/String;)V

    sput-object v0, LDo/d;->c:LTo/c;

    new-instance v0, LTo/c;

    const-string v1, "kotlin.annotations.jvm.UnderMigration"

    invoke-direct {v0, v1}, LTo/c;-><init>(Ljava/lang/String;)V

    sput-object v0, LDo/d;->d:LTo/c;

    sget-object v0, LDo/c;->VALUE_PARAMETER:LDo/c;

    const/4 v1, 0x5

    new-array v1, v1, [LDo/c;

    sget-object v2, LDo/c;->FIELD:LDo/c;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    sget-object v2, LDo/c;->METHOD_RETURN_TYPE:LDo/c;

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const/4 v2, 0x2

    aput-object v0, v1, v2

    sget-object v5, LDo/c;->TYPE_PARAMETER_BOUNDS:LDo/c;

    const/4 v6, 0x3

    aput-object v5, v1, v6

    sget-object v5, LDo/c;->TYPE_USE:LDo/c;

    const/4 v6, 0x4

    aput-object v5, v1, v6

    invoke-static {v1}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sput-object v1, LDo/d;->e:Ljava/util/List;

    invoke-static {}, LDo/F;->i()LTo/c;

    move-result-object v5

    new-instance v6, LDo/t;

    new-instance v7, LLo/k;

    sget-object v8, LLo/j;->NOT_NULL:LLo/j;

    invoke-direct {v7, v8, v3}, LLo/k;-><init>(LLo/j;Z)V

    check-cast v1, Ljava/util/Collection;

    invoke-direct {v6, v7, v1, v3}, LDo/t;-><init>(LLo/k;Ljava/util/Collection;Z)V

    new-instance v1, LUn/j;

    invoke-direct {v1, v5, v6}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v1}, Lkotlin/collections/J;->h(LUn/j;)Ljava/util/Map;

    move-result-object v1

    sput-object v1, LDo/d;->f:Ljava/util/Map;

    new-instance v5, LTo/c;

    const-string v6, "javax.annotation.ParametersAreNullableByDefault"

    invoke-direct {v5, v6}, LTo/c;-><init>(Ljava/lang/String;)V

    new-instance v6, LDo/t;

    new-instance v7, LLo/k;

    sget-object v9, LLo/j;->NULLABLE:LLo/j;

    invoke-direct {v7, v9, v3}, LLo/k;-><init>(LLo/j;Z)V

    invoke-static {v0}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    check-cast v9, Ljava/util/Collection;

    invoke-direct {v6, v7, v9}, LDo/t;-><init>(LLo/k;Ljava/util/Collection;)V

    new-instance v7, LUn/j;

    invoke-direct {v7, v5, v6}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, LTo/c;

    const-string v6, "javax.annotation.ParametersAreNonnullByDefault"

    invoke-direct {v5, v6}, LTo/c;-><init>(Ljava/lang/String;)V

    new-instance v6, LDo/t;

    new-instance v9, LLo/k;

    invoke-direct {v9, v8, v3}, LLo/k;-><init>(LLo/j;Z)V

    invoke-static {v0}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-direct {v6, v9, v0}, LDo/t;-><init>(LLo/k;Ljava/util/Collection;)V

    new-instance v0, LUn/j;

    invoke-direct {v0, v5, v6}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-array v5, v2, [LUn/j;

    aput-object v7, v5, v3

    aput-object v0, v5, v4

    invoke-static {v5}, Lkotlin/collections/J;->i([LUn/j;)Ljava/util/Map;

    move-result-object v0

    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5, v0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    invoke-virtual {v5, v1}, Ljava/util/AbstractMap;->putAll(Ljava/util/Map;)V

    sput-object v5, LDo/d;->g:Ljava/util/LinkedHashMap;

    invoke-static {}, LDo/F;->f()LTo/c;

    move-result-object v0

    invoke-static {}, LDo/F;->e()LTo/c;

    move-result-object v1

    new-array v2, v2, [LTo/c;

    aput-object v0, v2, v3

    aput-object v1, v2, v4

    invoke-static {v2}, Lkotlin/collections/O;->f([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LDo/d;->h:Ljava/util/Set;

    return-void
.end method

.method public static final a()Ljava/util/LinkedHashMap;
    .registers 1

    sget-object v0, LDo/d;->g:Ljava/util/LinkedHashMap;

    return-object v0
.end method

.method public static final b()Ljava/util/Set;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/c;",
            ">;"
        }
    .end annotation

    sget-object v0, LDo/d;->h:Ljava/util/Set;

    return-object v0
.end method

.method public static final c()Ljava/util/Map;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "LTo/c;",
            "LDo/t;",
            ">;"
        }
    .end annotation

    sget-object v0, LDo/d;->f:Ljava/util/Map;

    return-object v0
.end method

.method public static final d()LTo/c;
    .registers 1

    sget-object v0, LDo/d;->d:LTo/c;

    return-object v0
.end method

.method public static final e()LTo/c;
    .registers 1

    sget-object v0, LDo/d;->c:LTo/c;

    return-object v0
.end method

.method public static final f()LTo/c;
    .registers 1

    sget-object v0, LDo/d;->b:LTo/c;

    return-object v0
.end method

.method public static final g()LTo/c;
    .registers 1

    sget-object v0, LDo/d;->a:LTo/c;

    return-object v0
.end method
