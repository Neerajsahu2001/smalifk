.class public final LDo/g;
.super LDo/L;
.source "specialBuiltinMembers.kt"


# static fields
.field public static final synthetic m:I
