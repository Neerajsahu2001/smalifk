.class public final LDo/u;
.super Ljava/lang/Object;
.source "JavaDescriptorVisibilities.java"


# static fields
.field public static final a:Luo/r;

.field public static final b:Luo/r;

.field public static final c:Luo/r;

.field private static final d:Ljava/util/HashMap;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    new-instance v0, LDo/u$a;

    sget-object v1, Lyo/a;->c:Lyo/a;

    invoke-direct {v0, v1}, Luo/p;-><init>(Luo/f0;)V

    sput-object v0, LDo/u;->a:Luo/r;

    new-instance v1, LDo/u$b;

    sget-object v2, Lyo/c;->c:Lyo/c;

    invoke-direct {v1, v2}, Luo/p;-><init>(Luo/f0;)V

    sput-object v1, LDo/u;->b:Luo/r;

    new-instance v2, LDo/u$c;

    sget-object v3, Lyo/b;->c:Lyo/b;

    invoke-direct {v2, v3}, Luo/p;-><init>(Luo/f0;)V

    sput-object v2, LDo/u;->c:Luo/r;

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    sput-object v3, LDo/u;->d:Ljava/util/HashMap;

    invoke-virtual {v0}, Luo/p;->a()Luo/f0;

    move-result-object v4

    invoke-virtual {v3, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v1}, Luo/p;->a()Luo/f0;

    move-result-object v0

    invoke-virtual {v3, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2}, Luo/p;->a()Luo/f0;

    move-result-object v0

    invoke-virtual {v3, v0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private static synthetic a(I)V
    .registers 10

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-eq p0, v1, :cond_9

    if-eq p0, v0, :cond_9

    const-string v2, "Argument for @NotNull parameter \'%s\' of %s.%s must not be null"

    goto :goto_b

    :cond_9
    const-string v2, "@NotNull method %s.%s must not return null"

    :goto_b
    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eq p0, v1, :cond_13

    if-eq p0, v0, :cond_13

    const/4 v5, 0x3

    goto :goto_14

    :cond_13
    const/4 v5, 0x2

    :goto_14
    new-array v5, v5, [Ljava/lang/Object;

    const-string v6, "kotlin/reflect/jvm/internal/impl/load/java/JavaDescriptorVisibilities"

    const/4 v7, 0x0

    packed-switch p0, :pswitch_data_6e

    const-string v8, "what"

    aput-object v8, v5, v7

    goto :goto_37

    :pswitch_21
    aput-object v6, v5, v7

    goto :goto_37

    :pswitch_24
    const-string v8, "visibility"

    aput-object v8, v5, v7

    goto :goto_37

    :pswitch_29
    const-string v8, "second"

    aput-object v8, v5, v7

    goto :goto_37

    :pswitch_2e
    const-string v8, "first"

    aput-object v8, v5, v7

    goto :goto_37

    :pswitch_33
    const-string v8, "from"

    aput-object v8, v5, v7

    :goto_37
    const-string v7, "toDescriptorVisibility"

    const/4 v8, 0x1

    if-eq p0, v1, :cond_41

    if-eq p0, v0, :cond_41

    aput-object v6, v5, v8

    goto :goto_43

    :cond_41
    aput-object v7, v5, v8

    :goto_43
    if-eq p0, v4, :cond_56

    if-eq p0, v3, :cond_56

    const/4 v3, 0x4

    if-eq p0, v3, :cond_53

    if-eq p0, v1, :cond_5a

    if-eq p0, v0, :cond_5a

    const-string v3, "isVisibleForProtectedAndPackage"

    aput-object v3, v5, v4

    goto :goto_5a

    :cond_53
    aput-object v7, v5, v4

    goto :goto_5a

    :cond_56
    const-string v3, "areInSamePackage"

    aput-object v3, v5, v4

    :cond_5a
    :goto_5a
    invoke-static {v2, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    if-eq p0, v1, :cond_68

    if-eq p0, v0, :cond_68

    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    goto :goto_6d

    :cond_68
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    :goto_6d
    throw p0

    :pswitch_data_6e
    .packed-switch 0x1
        :pswitch_33
        :pswitch_2e
        :pswitch_29
        :pswitch_24
        :pswitch_21
        :pswitch_21
    .end packed-switch
.end method

.method static synthetic b(Luo/k;Luo/k;)Z
    .registers 2

    invoke-static {p0, p1}, LDo/u;->d(Luo/k;Luo/k;)Z

    move-result p0

    return p0
.end method

.method static c(Lep/g;Luo/o;Luo/k;)Z
    .registers 5

    const/4 v0, 0x1

    if-eqz p2, :cond_15

    invoke-static {p1}, LWo/i;->H(Luo/o;)Luo/o;

    move-result-object v1

    invoke-static {v1, p2}, LDo/u;->d(Luo/k;Luo/k;)Z

    move-result v1

    if-eqz v1, :cond_e

    goto :goto_14

    :cond_e
    sget-object v0, Luo/q;->c:Luo/r;

    invoke-virtual {v0, p0, p1, p2}, Luo/r;->c(Lep/g;Luo/o;Luo/k;)Z

    move-result v0

    :goto_14
    return v0

    :cond_15
    invoke-static {v0}, LDo/u;->a(I)V

    const/4 p0, 0x0

    throw p0
.end method

.method private static d(Luo/k;Luo/k;)Z
    .registers 4

    const/4 v0, 0x0

    if-eqz p0, :cond_2d

    if-eqz p1, :cond_28

    const-class v0, Luo/E;

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, LWo/i;->o(Luo/k;Ljava/lang/Class;Z)Luo/k;

    move-result-object p0

    check-cast p0, Luo/E;

    invoke-static {p1, v0, v1}, LWo/i;->o(Luo/k;Ljava/lang/Class;Z)Luo/k;

    move-result-object p1

    check-cast p1, Luo/E;

    if-eqz p1, :cond_27

    if-eqz p0, :cond_27

    invoke-interface {p0}, Luo/E;->c()LTo/c;

    move-result-object p0

    invoke-interface {p1}, Luo/E;->c()LTo/c;

    move-result-object p1

    invoke-virtual {p0, p1}, LTo/c;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_27

    const/4 v1, 0x1

    :cond_27
    return v1

    :cond_28
    const/4 p0, 0x3

    invoke-static {p0}, LDo/u;->a(I)V

    throw v0

    :cond_2d
    const/4 p0, 0x2

    invoke-static {p0}, LDo/u;->a(I)V

    throw v0
.end method

.method public static e(Luo/f0;)Luo/r;
    .registers 2

    if-eqz p0, :cond_12

    sget-object v0, LDo/u;->d:Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/r;

    if-nez v0, :cond_11

    invoke-static {p0}, Luo/q;->j(Luo/f0;)Luo/r;

    move-result-object p0

    return-object p0

    :cond_11
    return-object v0

    :cond_12
    const/4 p0, 0x4

    invoke-static {p0}, LDo/u;->a(I)V

    const/4 p0, 0x0

    throw p0
.end method
