.class final LDo/o$b;
.super Lkotlin/jvm/internal/p;
.source "ErasedOverridabilityCondition.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LDo/o;->a(Luo/a;Luo/a;Luo/e;)LWo/j$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Luo/b0;",
        "Lkp/E;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LDo/o$b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LDo/o$b;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LDo/o$b;->a:LDo/o$b;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Luo/b0;

    invoke-interface {p1}, Luo/a0;->getType()Lkp/E;

    move-result-object p1

    return-object p1
.end method
