.class public final LDo/n;
.super Ljava/lang/Object;
.source "DescriptorsJvmAbiUtil.java"


# direct methods
.method private static synthetic a(I)V
    .registers 7

    const/4 v0, 0x3

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eq p0, v3, :cond_16

    if-eq p0, v4, :cond_16

    if-eq p0, v0, :cond_11

    const-string v5, "propertyDescriptor"

    aput-object v5, v1, v2

    goto :goto_1a

    :cond_11
    const-string v5, "memberDescriptor"

    aput-object v5, v1, v2

    goto :goto_1a

    :cond_16
    const-string v5, "companionObject"

    aput-object v5, v1, v2

    :goto_1a
    const-string v2, "kotlin/reflect/jvm/internal/impl/load/java/DescriptorsJvmAbiUtil"

    aput-object v2, v1, v3

    if-eq p0, v3, :cond_33

    if-eq p0, v4, :cond_2e

    if-eq p0, v0, :cond_29

    const-string p0, "isPropertyWithBackingFieldInOuterClass"

    aput-object p0, v1, v4

    goto :goto_37

    :cond_29
    const-string p0, "hasJvmFieldAnnotation"

    aput-object p0, v1, v4

    goto :goto_37

    :cond_2e
    const-string p0, "isMappedIntrinsicCompanionObject"

    aput-object p0, v1, v4

    goto :goto_37

    :cond_33
    const-string p0, "isClassCompanionObjectWithBackingFieldsInOuter"

    aput-object p0, v1, v4

    :goto_37
    const-string p0, "Argument for @NotNull parameter \'%s\' of %s.%s must not be null"

    invoke-static {p0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static b(Luo/L;)Z
    .registers 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p0, :cond_5e

    invoke-interface {p0}, Luo/b;->h()Luo/b$a;

    move-result-object v2

    sget-object v3, Luo/b$a;->FAKE_OVERRIDE:Luo/b$a;

    if-ne v2, v3, :cond_d

    return v1

    :cond_d
    invoke-interface {p0}, Luo/k;->d()Luo/k;

    move-result-object v2

    const/4 v3, 0x1

    if-eqz v2, :cond_5a

    invoke-static {v2}, LWo/i;->t(Luo/k;)Z

    move-result v0

    if-eqz v0, :cond_2f

    invoke-interface {v2}, Luo/k;->d()Luo/k;

    move-result-object v0

    invoke-static {v0}, LWo/i;->s(Luo/k;)Z

    move-result v0

    if-eqz v0, :cond_2f

    check-cast v2, Luo/e;

    sget v0, Lro/c;->b:I

    invoke-static {v2}, LC2/a;->d(Luo/e;)Z

    move-result v0

    if-nez v0, :cond_2f

    return v3

    :cond_2f
    invoke-interface {p0}, Luo/k;->d()Luo/k;

    move-result-object v0

    invoke-static {v0}, LWo/i;->t(Luo/k;)Z

    move-result v0

    if-eqz v0, :cond_59

    invoke-interface {p0}, Luo/L;->w0()Luo/t;

    move-result-object v0

    if-eqz v0, :cond_4c

    invoke-interface {v0}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object v0

    sget-object v2, LDo/D;->a:LTo/c;

    invoke-interface {v0, v2}, Lvo/h;->r0(LTo/c;)Z

    move-result v0

    if-eqz v0, :cond_4c

    goto :goto_58

    :cond_4c
    invoke-interface {p0}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object p0

    sget-object v0, LDo/D;->a:LTo/c;

    invoke-interface {p0, v0}, Lvo/h;->r0(LTo/c;)Z

    move-result p0

    if-eqz p0, :cond_59

    :goto_58
    const/4 v1, 0x1

    :cond_59
    return v1

    :cond_5a
    invoke-static {v3}, LDo/n;->a(I)V

    throw v0

    :cond_5e
    invoke-static {v1}, LDo/n;->a(I)V

    throw v0
.end method
