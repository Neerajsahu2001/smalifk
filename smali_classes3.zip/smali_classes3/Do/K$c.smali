.class final LDo/K$c;
.super Lkotlin/jvm/internal/p;
.source "specialBuiltinMembers.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LDo/K;->c(Luo/b;)Luo/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Luo/b;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LDo/K$c;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LDo/K$c;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LDo/K$c;->a:LDo/K$c;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Luo/b;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lro/j;->X(Luo/k;)Z

    move-result v0

    if-eqz v0, :cond_54

    sget v0, LDo/h;->m:I

    invoke-static {}, LDo/L;->b()Ljava/util/Set;

    move-result-object v0

    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_1f

    goto :goto_50

    :cond_1f
    sget-object v0, LDo/i;->a:LDo/i;

    invoke-static {p1, v0}, Lap/c;->b(Luo/b;Leo/l;)Luo/b;

    move-result-object p1

    if-eqz p1, :cond_50

    invoke-static {p1}, LMo/A;->b(Luo/a;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_2e

    goto :goto_50

    :cond_2e
    invoke-static {}, LDo/L;->a()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c

    sget-object p1, LDo/L$b;->ONE_COLLECTION_PARAMETER:LDo/L$b;

    :goto_3a
    move-object v1, p1

    goto :goto_50

    :cond_3c
    invoke-static {}, LDo/L;->g()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0, p1}, Lkotlin/collections/J;->e(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LDo/L$c;

    sget-object v0, LDo/L$c;->NULL:LDo/L$c;

    if-ne p1, v0, :cond_4d

    sget-object p1, LDo/L$b;->OBJECT_PARAMETER_GENERIC:LDo/L$b;

    goto :goto_3a

    :cond_4d
    sget-object p1, LDo/L$b;->OBJECT_PARAMETER_NON_GENERIC:LDo/L$b;

    goto :goto_3a

    :cond_50
    :goto_50
    if-eqz v1, :cond_54

    const/4 p1, 0x1

    goto :goto_55

    :cond_54
    const/4 p1, 0x0

    :goto_55
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
