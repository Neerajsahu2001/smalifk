.class public final LDo/t;
.super Ljava/lang/Object;
.source "AnnotationQualifiersFqNames.kt"


# instance fields
.field private final a:LLo/k;

.field private final b:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Collection<",
            "LDo/c;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Z


# direct methods
.method public synthetic constructor <init>(LLo/k;Ljava/util/Collection;)V
    .registers 5

    invoke-virtual {p1}, LLo/k;->b()LLo/j;

    move-result-object v0

    sget-object v1, LLo/j;->NOT_NULL:LLo/j;

    if-ne v0, v1, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    invoke-direct {p0, p1, p2, v0}, LDo/t;-><init>(LLo/k;Ljava/util/Collection;Z)V

    return-void
.end method

.method public constructor <init>(LLo/k;Ljava/util/Collection;Z)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LLo/k;",
            "Ljava/util/Collection<",
            "+",
            "LDo/c;",
            ">;Z)V"
        }
    .end annotation

    const-string v0, "qualifierApplicabilityTypes"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LDo/t;->a:LLo/k;

    iput-object p2, p0, LDo/t;->b:Ljava/util/Collection;

    iput-boolean p3, p0, LDo/t;->c:Z

    return-void
.end method

.method public static a(LDo/t;LLo/k;)LDo/t;
    .registers 4

    const-string v0, "qualifierApplicabilityTypes"

    iget-object v1, p0, LDo/t;->b:Ljava/util/Collection;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LDo/t;

    iget-boolean p0, p0, LDo/t;->c:Z

    invoke-direct {v0, p1, v1, p0}, LDo/t;-><init>(LLo/k;Ljava/util/Collection;Z)V

    return-object v0
.end method


# virtual methods
.method public final b()Z
    .registers 2

    iget-boolean v0, p0, LDo/t;->c:Z

    return v0
.end method

.method public final c()LLo/k;
    .registers 2

    iget-object v0, p0, LDo/t;->a:LLo/k;

    return-object v0
.end method

.method public final d()Ljava/util/Collection;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "LDo/c;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LDo/t;->b:Ljava/util/Collection;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LDo/t;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, LDo/t;

    iget-object v1, p1, LDo/t;->a:LLo/k;

    iget-object v3, p0, LDo/t;->a:LLo/k;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, LDo/t;->b:Ljava/util/Collection;

    iget-object v3, p1, LDo/t;->b:Ljava/util/Collection;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-boolean v1, p0, LDo/t;->c:Z

    iget-boolean p1, p1, LDo/t;->c:Z

    if-eq v1, p1, :cond_29

    return v2

    :cond_29
    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, LDo/t;->a:LLo/k;

    invoke-virtual {v0}, LLo/k;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, LDo/t;->b:Ljava/util/Collection;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-boolean v0, p0, LDo/t;->c:Z

    if-eqz v0, :cond_16

    const/4 v0, 0x1

    :cond_16
    add-int/2addr v1, v0

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "JavaDefaultQualifiers(nullabilityQualifier="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LDo/t;->a:LLo/k;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", qualifierApplicabilityTypes="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LDo/t;->b:Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", definitelyNotNull="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, LDo/t;->c:Z

    const/16 v2, 0x29

    invoke-static {v0, v1, v2}, Landroidx/coordinatorlayout/widget/a;->b(Ljava/lang/StringBuilder;ZC)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
