.class public final LDo/j;
.super Ljava/lang/Object;
.source "BuiltinSpecialProperties.kt"


# static fields
.field private static final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "LTo/c;",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end field

.field private static final b:Ljava/util/LinkedHashMap;

.field private static final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LTo/c;",
            ">;"
        }
    .end annotation
.end field

.field private static final d:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 10

    sget-object v0, Lro/n$a;->j:LTo/d;

    const-string v1, "name"

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v2

    invoke-virtual {v0, v2}, LTo/d;->c(LTo/f;)LTo/d;

    move-result-object v2

    invoke-virtual {v2}, LTo/d;->l()LTo/c;

    move-result-object v2

    const-string v3, "child(Name.identifier(name)).toSafe()"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    new-instance v4, LUn/j;

    invoke-direct {v4, v2, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v1, "ordinal"

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v2

    invoke-virtual {v0, v2}, LTo/d;->c(LTo/f;)LTo/d;

    move-result-object v0

    invoke-virtual {v0}, LTo/d;->l()LTo/c;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    new-instance v2, LUn/j;

    invoke-direct {v2, v0, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v0, Lro/n$a;->B:LTo/c;

    const-string v1, "size"

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v5

    invoke-virtual {v0, v5}, LTo/c;->c(LTo/f;)LTo/c;

    move-result-object v0

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v5

    new-instance v6, LUn/j;

    invoke-direct {v6, v0, v5}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v0, Lro/n$a;->F:LTo/c;

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v5

    invoke-virtual {v0, v5}, LTo/c;->c(LTo/f;)LTo/c;

    move-result-object v5

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    new-instance v7, LUn/j;

    invoke-direct {v7, v5, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lro/n$a;->e:LTo/d;

    const-string v5, "length"

    invoke-static {v5}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v8

    invoke-virtual {v1, v8}, LTo/d;->c(LTo/f;)LTo/d;

    move-result-object v1

    invoke-virtual {v1}, LTo/d;->l()LTo/c;

    move-result-object v1

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v3

    new-instance v5, LUn/j;

    invoke-direct {v5, v1, v3}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v1, "keys"

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    invoke-virtual {v0, v1}, LTo/c;->c(LTo/f;)LTo/c;

    move-result-object v1

    const-string v3, "keySet"

    invoke-static {v3}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v3

    new-instance v8, LUn/j;

    invoke-direct {v8, v1, v3}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v1, "values"

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v3

    invoke-virtual {v0, v3}, LTo/c;->c(LTo/f;)LTo/c;

    move-result-object v3

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    new-instance v9, LUn/j;

    invoke-direct {v9, v3, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v1, "entries"

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    invoke-virtual {v0, v1}, LTo/c;->c(LTo/f;)LTo/c;

    move-result-object v0

    const-string v1, "entrySet"

    invoke-static {v1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v1

    new-instance v3, LUn/j;

    invoke-direct {v3, v0, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0x8

    new-array v0, v0, [LUn/j;

    const/4 v1, 0x0

    aput-object v4, v0, v1

    const/4 v1, 0x1

    aput-object v2, v0, v1

    const/4 v1, 0x2

    aput-object v6, v0, v1

    const/4 v1, 0x3

    aput-object v7, v0, v1

    const/4 v1, 0x4

    aput-object v5, v0, v1

    const/4 v1, 0x5

    aput-object v8, v0, v1

    const/4 v1, 0x6

    aput-object v9, v0, v1

    const/4 v1, 0x7

    aput-object v3, v0, v1

    invoke-static {v0}, Lkotlin/collections/J;->i([LUn/j;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LDo/j;->a:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-static {v0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_ee
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_111

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    new-instance v3, LUn/j;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LTo/c;

    invoke-virtual {v4}, LTo/c;->g()LTo/f;

    move-result-object v4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-direct {v3, v4, v2}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_ee

    :cond_111
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_11a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_146

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LUn/j;

    invoke-virtual {v2}, LUn/j;->d()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LTo/f;

    invoke-virtual {v0, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-nez v4, :cond_13a

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_13a
    check-cast v4, Ljava/util/List;

    invoke-virtual {v2}, LUn/j;->c()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LTo/f;

    invoke-interface {v4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_11a

    :cond_146
    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v2

    invoke-static {v2}, Lkotlin/collections/J;->g(I)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_15d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_17b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/q;->n(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_15d

    :cond_17b
    sput-object v1, LDo/j;->b:Ljava/util/LinkedHashMap;

    sget-object v0, LDo/j;->a:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    sput-object v0, LDo/j;->c:Ljava/util/Set;

    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-static {v0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_194
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1a8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LTo/c;

    invoke-virtual {v2}, LTo/c;->g()LTo/f;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_194

    :cond_1a8
    invoke-static {v1}, Lkotlin/collections/q;->c0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LDo/j;->d:Ljava/util/Set;

    return-void
.end method

.method public static a()Ljava/util/Map;
    .registers 1

    sget-object v0, LDo/j;->a:Ljava/util/Map;

    return-object v0
.end method

.method public static b(LTo/f;)Ljava/util/List;
    .registers 2

    sget-object v0, LDo/j;->b:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    if-nez p0, :cond_c

    sget-object p0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_c
    return-object p0
.end method

.method public static c()Ljava/util/Set;
    .registers 1

    sget-object v0, LDo/j;->c:Ljava/util/Set;

    return-object v0
.end method

.method public static d()Ljava/util/Set;
    .registers 1

    sget-object v0, LDo/j;->d:Ljava/util/Set;

    return-object v0
.end method
