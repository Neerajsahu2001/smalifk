.class public final LHo/n$b$b;
.super LHo/n$b;
.source "LazyJavaPackageScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHo/n$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final a:LHo/n$b$b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LHo/n$b$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LHo/n$b;-><init>(I)V

    sput-object v0, LHo/n$b$b;->a:LHo/n$b$b;

    return-void
.end method
