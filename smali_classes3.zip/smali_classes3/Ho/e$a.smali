.class final LHo/e$a;
.super Lkp/b;
.source "LazyJavaClassDescriptor.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHo/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation


# instance fields
.field private final c:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/List<",
            "Luo/X;",
            ">;>;"
        }
    .end annotation
.end field

.field final synthetic d:LHo/e;


# direct methods
.method public constructor <init>(LHo/e;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, LHo/e$a;->d:LHo/e;

    invoke-static {p1}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->e()Ljp/n;

    move-result-object v0

    invoke-direct {p0, v0}, Lkp/b;-><init>(Ljp/n;)V

    invoke-static {p1}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->e()Ljp/n;

    move-result-object v0

    new-instance v1, LHo/e$a$a;

    invoke-direct {v1, p1}, LHo/e$a$a;-><init>(LHo/e;)V

    invoke-interface {v0, v1}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p1

    iput-object p1, p0, LHo/e$a;->c:Ljp/j;

    return-void
.end method


# virtual methods
.method protected final e()Ljava/util/Collection;
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "Lkp/E;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/e$a;->d:LHo/e;

    invoke-virtual {v0}, LHo/e;->Q0()LKo/g;

    move-result-object v1

    invoke-interface {v1}, LKo/g;->l()Ljava/util/Collection;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-interface {v1}, Ljava/util/Collection;->size()I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v3, Ljava/util/ArrayList;

    const/4 v4, 0x0

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0}, LHo/e;->getAnnotations()Lvo/h;

    move-result-object v5

    sget-object v6, LDo/E;->n:LTo/c;

    const-string v7, "PURELY_IMPLEMENTS_ANNOTATION"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, LGo/e;

    invoke-virtual {v5, v6}, LGo/e;->f(LTo/c;)Lvo/c;

    move-result-object v5

    const/4 v6, 0x0

    if-nez v5, :cond_2f

    :cond_2d
    :goto_2d
    move-object v7, v6

    goto :goto_5c

    :cond_2f
    invoke-interface {v5}, Lvo/c;->a()Ljava/util/Map;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    invoke-static {v5}, Lkotlin/collections/q;->P(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v5

    instance-of v7, v5, LYo/v;

    if-eqz v7, :cond_44

    check-cast v5, LYo/v;

    goto :goto_45

    :cond_44
    move-object v5, v6

    :goto_45
    if-eqz v5, :cond_2d

    invoke-virtual {v5}, LYo/g;->b()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    if-nez v5, :cond_50

    goto :goto_2d

    :cond_50
    invoke-static {v5}, LTo/e;->a(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_57

    goto :goto_2d

    :cond_57
    new-instance v7, LTo/c;

    invoke-direct {v7, v5}, LTo/c;-><init>(Ljava/lang/String;)V

    :goto_5c
    if-eqz v7, :cond_6d

    invoke-virtual {v7}, LTo/c;->d()Z

    move-result v5

    if-nez v5, :cond_6d

    sget-object v5, Lro/n;->j:LTo/f;

    invoke-virtual {v7, v5}, LTo/c;->i(LTo/f;)Z

    move-result v5

    if-eqz v5, :cond_6d

    goto :goto_6e

    :cond_6d
    move-object v7, v6

    :goto_6e
    const/4 v5, 0x1

    if-nez v7, :cond_80

    sget v8, LDo/p;->c:I

    invoke-static {v0}, Lap/c;->g(Luo/k;)LTo/c;

    move-result-object v8

    invoke-static {v8}, LDo/p;->b(LTo/c;)LTo/c;

    move-result-object v8

    if-nez v8, :cond_81

    :cond_7d
    :goto_7d
    move-object v7, v6

    goto/16 :goto_154

    :cond_80
    move-object v8, v7

    :cond_81
    invoke-static {v0}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v9

    invoke-virtual {v9}, LGo/g;->d()Luo/B;

    move-result-object v9

    sget-object v10, LCo/c;->FROM_JAVA_LOADER:LCo/c;

    sget v11, Lap/c;->a:I

    const-string v11, "<this>"

    invoke-static {v9, v11}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v11, "location"

    invoke-static {v10, v11}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v8}, LTo/c;->d()Z

    invoke-virtual {v8}, LTo/c;->e()LTo/c;

    move-result-object v11

    const-string v12, "topLevelClassFqName.parent()"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v9, v11}, Luo/B;->y(LTo/c;)Luo/I;

    move-result-object v9

    invoke-interface {v9}, Luo/I;->p()Ldp/i;

    move-result-object v9

    invoke-virtual {v8}, LTo/c;->g()LTo/f;

    move-result-object v8

    const-string v11, "topLevelClassFqName.shortName()"

    invoke-static {v8, v11}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v9, Ldp/a;

    invoke-virtual {v9, v8, v10}, Ldp/a;->g(LTo/f;LCo/c;)Luo/h;

    move-result-object v8

    instance-of v9, v8, Luo/e;

    if-eqz v9, :cond_c1

    check-cast v8, Luo/e;

    goto :goto_c2

    :cond_c1
    move-object v8, v6

    :goto_c2
    if-nez v8, :cond_c5

    goto :goto_7d

    :cond_c5
    invoke-interface {v8}, Luo/h;->j()Lkp/e0;

    move-result-object v9

    invoke-interface {v9}, Lkp/e0;->getParameters()Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    invoke-virtual {v0}, LHo/e;->j()Lkp/e0;

    move-result-object v10

    check-cast v10, LHo/e$a;

    invoke-virtual {v10}, LHo/e$a;->getParameters()Ljava/util/List;

    move-result-object v10

    const-string v11, "getTypeConstructor().parameters"

    invoke-static {v10, v11}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v11

    if-ne v11, v9, :cond_110

    check-cast v10, Ljava/lang/Iterable;

    new-instance v7, Ljava/util/ArrayList;

    invoke-static {v10}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v9

    invoke-direct {v7, v9}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_f5
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_147

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Luo/X;

    new-instance v11, Lkp/m0;

    sget-object v12, Lkp/w0;->INVARIANT:Lkp/w0;

    invoke-interface {v10}, Luo/h;->q()Lkp/M;

    move-result-object v10

    invoke-direct {v11, v10, v12}, Lkp/m0;-><init>(Lkp/E;Lkp/w0;)V

    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_f5

    :cond_110
    if-ne v11, v5, :cond_7d

    if-le v9, v5, :cond_7d

    if-nez v7, :cond_7d

    new-instance v7, Lkp/m0;

    sget-object v11, Lkp/w0;->INVARIANT:Lkp/w0;

    invoke-static {v10}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Luo/X;

    invoke-interface {v10}, Luo/h;->q()Lkp/M;

    move-result-object v10

    invoke-direct {v7, v10, v11}, Lkp/m0;-><init>(Lkp/E;Lkp/w0;)V

    new-instance v10, Lko/e;

    invoke-direct {v10, v5, v9, v5}, Lko/c;-><init>(III)V

    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v10}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v10}, Lko/c;->i()Lko/d;

    move-result-object v10

    :goto_139
    invoke-virtual {v10}, Lko/d;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_146

    invoke-virtual {v10}, Lkotlin/collections/G;->a()I

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_139

    :cond_146
    move-object v7, v9

    :cond_147
    sget-object v9, Lkp/c0;->b:Lkp/c0$a;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lkp/c0;->h()Lkp/c0;

    move-result-object v9

    invoke-static {v9, v8, v7}, Lkp/F;->d(Lkp/c0;Luo/e;Ljava/util/List;)Lkp/M;

    move-result-object v7

    :goto_154
    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_158
    :goto_158
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_1b7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LKo/j;

    invoke-static {v0}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v9

    invoke-virtual {v9}, LGo/g;->g()LIo/d;

    move-result-object v9

    sget-object v10, Lkp/s0;->SUPERTYPE:Lkp/s0;

    const/4 v11, 0x7

    invoke-static {v10, v4, v4, v6, v11}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v10

    invoke-virtual {v9, v8, v10}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v9

    invoke-static {v0}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v10

    invoke-virtual {v10}, LGo/g;->a()LGo/c;

    move-result-object v10

    invoke-virtual {v10}, LGo/c;->r()LLo/s;

    move-result-object v10

    invoke-static {v0}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v11

    invoke-virtual {v10, v9, v11}, LLo/s;->c(Lkp/E;LGo/g;)Lkp/E;

    move-result-object v9

    invoke-virtual {v9}, Lkp/E;->N0()Lkp/e0;

    move-result-object v10

    invoke-interface {v10}, Lkp/e0;->n()Luo/h;

    move-result-object v10

    instance-of v10, v10, Luo/D$b;

    if-eqz v10, :cond_19a

    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_19a
    invoke-virtual {v9}, Lkp/E;->N0()Lkp/e0;

    move-result-object v8

    if-eqz v7, :cond_1a5

    invoke-virtual {v7}, Lkp/E;->N0()Lkp/e0;

    move-result-object v10

    goto :goto_1a6

    :cond_1a5
    move-object v10, v6

    :goto_1a6
    invoke-static {v8, v10}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1ad

    goto :goto_158

    :cond_1ad
    invoke-static {v9}, Lro/j;->U(Lkp/E;)Z

    move-result v8

    if-nez v8, :cond_158

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_158

    :cond_1b7
    invoke-static {v0}, LHo/e;->L0(LHo/e;)Luo/e;

    move-result-object v1

    if-eqz v1, :cond_1cf

    invoke-static {v1, v0}, Lto/y;->a(Luo/e;Lxo/b;)Lkp/f0;

    move-result-object v4

    invoke-static {v4}, Lkp/r0;->f(Lkp/n0;)Lkp/r0;

    move-result-object v4

    invoke-interface {v1}, Luo/e;->q()Lkp/M;

    move-result-object v1

    sget-object v6, Lkp/w0;->INVARIANT:Lkp/w0;

    invoke-virtual {v4, v1, v6}, Lkp/r0;->l(Lkp/E;Lkp/w0;)Lkp/E;

    move-result-object v6

    :cond_1cf
    invoke-static {v6, v2}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    invoke-static {v7, v2}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    xor-int/2addr v1, v5

    if-eqz v1, :cond_213

    invoke-static {v0}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->c()Lgp/u;

    move-result-object v1

    new-instance v4, Ljava/util/ArrayList;

    invoke-static {v3}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v6

    invoke-direct {v4, v6}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1f5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_210

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LKo/w;

    const-string v7, "null cannot be cast to non-null type org.jetbrains.kotlin.load.java.structure.JavaClassifierType"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, LKo/j;

    invoke-interface {v6}, LKo/j;->z()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1f5

    :cond_210
    invoke-interface {v1, v0, v4}, Lgp/u;->a(Lxo/b;Ljava/util/ArrayList;)V

    :cond_213
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    xor-int/2addr v1, v5

    if-eqz v1, :cond_221

    invoke-static {v2}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    :goto_21e
    check-cast v0, Ljava/util/Collection;

    goto :goto_236

    :cond_221
    invoke-static {v0}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->d()Luo/B;

    move-result-object v0

    invoke-interface {v0}, Luo/B;->m()Lro/j;

    move-result-object v0

    invoke-virtual {v0}, Lro/j;->h()Lkp/M;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    goto :goto_21e

    :goto_236
    return-object v0
.end method

.method public final getParameters()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Luo/X;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/e$a;->c:Ljp/j;

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0
.end method

.method protected final h()Luo/V;
    .registers 2

    iget-object v0, p0, LHo/e$a;->d:LHo/e;

    invoke-static {v0}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->v()Luo/V;

    move-result-object v0

    return-object v0
.end method

.method public final n()Luo/h;
    .registers 2

    iget-object v0, p0, LHo/e$a;->d:LHo/e;

    return-object v0
.end method

.method public final o()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public final q()Luo/e;
    .registers 2

    iget-object v0, p0, LHo/e$a;->d:LHo/e;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, LHo/e$a;->d:LHo/e;

    invoke-virtual {v0}, Lxo/b;->getName()LTo/f;

    move-result-object v0

    invoke-virtual {v0}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    const-string v1, "name.asString()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method
