.class final LHo/a$a;
.super Lkotlin/jvm/internal/p;
.source "DeclaredMemberIndex.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/a;-><init>(LKo/g;Leo/l;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LKo/q;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/a;


# direct methods
.method constructor <init>(LHo/a;)V
    .registers 2

    iput-object p1, p0, LHo/a$a;->a:LHo/a;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, LKo/q;

    const-string v0, "m"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/a$a;->a:LHo/a;

    invoke-static {v0}, LHo/a;->g(LHo/a;)Leo/l;

    move-result-object v0

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_a0

    invoke-interface {p1}, LKo/p;->g()LAo/r;

    move-result-object v0

    invoke-virtual {v0}, LAo/r;->D()Z

    move-result v0

    if-eqz v0, :cond_9e

    invoke-interface {p1}, LKo/s;->getName()LTo/f;

    move-result-object v0

    invoke-virtual {v0}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const v2, -0x69e9ad94

    if-eq v1, v2, :cond_89

    const v2, -0x4d378041

    if-eq v1, v2, :cond_48

    const v2, 0x8cdac1b

    if-eq v1, v2, :cond_3f

    goto :goto_9e

    :cond_3f
    const-string v1, "hashCode"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_91

    goto :goto_9e

    :cond_48
    const-string v1, "equals"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_51

    goto :goto_9e

    :cond_51
    invoke-interface {p1}, LKo/q;->e()Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/q;->Q(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LKo/z;

    const/4 v0, 0x0

    if-eqz p1, :cond_63

    invoke-interface {p1}, LKo/z;->getType()LKo/w;

    move-result-object p1

    goto :goto_64

    :cond_63
    move-object p1, v0

    :goto_64
    instance-of v1, p1, LKo/j;

    if-eqz v1, :cond_6b

    move-object v0, p1

    check-cast v0, LKo/j;

    :cond_6b
    if-nez v0, :cond_6e

    goto :goto_9e

    :cond_6e
    invoke-interface {v0}, LKo/j;->a()LKo/i;

    move-result-object p1

    instance-of v0, p1, LKo/g;

    if-eqz v0, :cond_9e

    check-cast p1, LKo/g;

    invoke-interface {p1}, LKo/g;->c()LTo/c;

    move-result-object p1

    invoke-virtual {p1}, LTo/c;->b()Ljava/lang/String;

    move-result-object p1

    const-string v0, "java.lang.Object"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_9e

    goto :goto_a0

    :cond_89
    const-string v1, "toString"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9e

    :cond_91
    invoke-interface {p1}, LKo/q;->e()Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_9e

    goto :goto_a0

    :cond_9e
    :goto_9e
    const/4 p1, 0x1

    goto :goto_a1

    :cond_a0
    :goto_a0
    const/4 p1, 0x0

    :goto_a1
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
