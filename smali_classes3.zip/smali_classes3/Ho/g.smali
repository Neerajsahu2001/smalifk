.class final synthetic LHo/g;
.super Lkotlin/jvm/internal/l;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/l;",
        "Leo/l<",
        "LTo/f;",
        "Ljava/util/Collection<",
        "+",
        "Luo/Q;",
        ">;>;"
    }
.end annotation


# virtual methods
.method public final getName()Ljava/lang/String;
    .registers 2

    const-string v0, "searchMethodsByNameWithoutBuiltinMagic"

    return-object v0
.end method

.method public final getOwner()Llo/f;
    .registers 2

    const-class v0, LHo/k;

    invoke-static {v0}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v0

    return-object v0
.end method

.method public final getSignature()Ljava/lang/String;
    .registers 2

    const-string v0, "searchMethodsByNameWithoutBuiltinMagic(Lorg/jetbrains/kotlin/name/Name;)Ljava/util/Collection;"

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LTo/f;

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lkotlin/jvm/internal/e;->b:Ljava/lang/Object;

    check-cast v0, LHo/k;

    invoke-static {v0, p1}, LHo/k;->J(LHo/k;LTo/f;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1
.end method
