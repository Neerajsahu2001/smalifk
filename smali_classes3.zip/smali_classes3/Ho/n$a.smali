.class final LHo/n$a;
.super Ljava/lang/Object;
.source "LazyJavaPackageScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHo/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:LTo/f;

.field private final b:LKo/g;


# direct methods
.method public constructor <init>(LTo/f;LKo/g;)V
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LHo/n$a;->a:LTo/f;

    iput-object p2, p0, LHo/n$a;->b:LKo/g;

    return-void
.end method


# virtual methods
.method public final a()LKo/g;
    .registers 2

    iget-object v0, p0, LHo/n$a;->b:LKo/g;

    return-object v0
.end method

.method public final b()LTo/f;
    .registers 2

    iget-object v0, p0, LHo/n$a;->a:LTo/f;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, LHo/n$a;

    if-eqz v0, :cond_12

    check-cast p1, LHo/n$a;

    iget-object p1, p1, LHo/n$a;->a:LTo/f;

    iget-object v0, p0, LHo/n$a;->a:LTo/f;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_12

    const/4 p1, 0x1

    goto :goto_13

    :cond_12
    const/4 p1, 0x0

    :goto_13
    return p1
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, LHo/n$a;->a:LTo/f;

    invoke-virtual {v0}, LTo/f;->hashCode()I

    move-result v0

    return v0
.end method
