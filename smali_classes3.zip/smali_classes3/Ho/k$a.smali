.class final LHo/k$a;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/k;-><init>(LGo/g;Luo/e;LKo/g;ZLHo/k;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "Luo/d;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/k;

.field final synthetic b:LGo/g;


# direct methods
.method constructor <init>(LGo/g;LHo/k;)V
    .registers 3

    iput-object p2, p0, LHo/k$a;->a:LHo/k;

    iput-object p1, p0, LHo/k$a;->b:LGo/g;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 9

    iget-object v0, p0, LHo/k$a;->a:LHo/k;

    invoke-static {v0}, LHo/k;->G(LHo/k;)LKo/g;

    move-result-object v1

    invoke-interface {v1}, LKo/g;->k()Ljava/util/Collection;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-interface {v1}, Ljava/util/Collection;->size()I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_17
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LKo/k;

    invoke-static {v0, v3}, LHo/k;->I(LHo/k;LKo/k;)LFo/b;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_17

    :cond_2b
    invoke-static {v0}, LHo/k;->G(LHo/k;)LKo/g;

    move-result-object v1

    invoke-interface {v1}, LKo/g;->p()Z

    move-result v1

    iget-object v3, p0, LHo/k$a;->b:LGo/g;

    if-eqz v1, :cond_74

    invoke-static {v0}, LHo/k;->D(LHo/k;)LFo/b;

    move-result-object v1

    const/4 v4, 0x2

    invoke-static {v1, v4}, LMo/A;->a(Luo/v;I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_47

    goto :goto_62

    :cond_47
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_4b
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_62

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Luo/d;

    invoke-static {v7, v4}, LMo/A;->a(Luo/v;I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v5}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4b

    goto :goto_74

    :cond_62
    :goto_62
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v4

    invoke-virtual {v4}, LGo/c;->h()LEo/i;

    move-result-object v4

    invoke-static {v0}, LHo/k;->G(LHo/k;)LKo/g;

    move-result-object v5

    invoke-interface {v4, v5, v1}, LEo/i;->b(LKo/l;LFo/b;)V

    :cond_74
    :goto_74
    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->w()Lbp/d;

    move-result-object v1

    invoke-virtual {v0}, LHo/k;->a0()Luo/e;

    move-result-object v4

    invoke-interface {v1, v3, v4, v2}, Lbp/d;->c(LGo/g;Luo/e;Ljava/util/ArrayList;)V

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->r()LLo/s;

    move-result-object v1

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_9c

    invoke-static {v0}, LHo/k;->C(LHo/k;)LFo/b;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    :cond_9c
    invoke-virtual {v1, v3, v2}, LLo/s;->b(LGo/g;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
