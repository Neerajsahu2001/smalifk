.class public abstract LHo/o;
.super Ldp/j;
.source "LazyJavaScope.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LHo/o$a;,
        LHo/o$b;
    }
.end annotation


# static fields
.field static final synthetic m:[Llo/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Llo/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final b:LGo/g;

.field private final c:LHo/o;

.field private final d:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;>;"
        }
    .end annotation
.end field

.field private final e:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "LHo/b;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Ljp/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/h<",
            "LTo/f;",
            "Ljava/util/Collection<",
            "Luo/Q;",
            ">;>;"
        }
    .end annotation
.end field

.field private final g:Ljp/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/i<",
            "LTo/f;",
            "Luo/L;",
            ">;"
        }
    .end annotation
.end field

.field private final h:Ljp/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/h<",
            "LTo/f;",
            "Ljava/util/Collection<",
            "Luo/Q;",
            ">;>;"
        }
    .end annotation
.end field

.field private final i:Ljp/j;

.field private final j:Ljp/j;

.field private final k:Ljp/j;

.field private final l:Ljp/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/h<",
            "LTo/f;",
            "Ljava/util/List<",
            "Luo/L;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, Lkotlin/jvm/internal/x;

    const-class v1, LHo/o;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v2

    const-string v3, "functionNamesLazy"

    const-string v4, "getFunctionNamesLazy()Ljava/util/Set;"

    invoke-direct {v0, v2, v3, v4}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v0

    new-instance v2, Lkotlin/jvm/internal/x;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v3

    const-string v4, "propertyNamesLazy"

    const-string v5, "getPropertyNamesLazy()Ljava/util/Set;"

    invoke-direct {v2, v3, v4, v5}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v2

    new-instance v3, Lkotlin/jvm/internal/x;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v1

    const-string v4, "classNamesLazy"

    const-string v5, "getClassNamesLazy()Ljava/util/Set;"

    invoke-direct {v3, v1, v4, v5}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v1

    const/4 v3, 0x3

    new-array v3, v3, [Llo/m;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    const/4 v0, 0x1

    aput-object v2, v3, v0

    const/4 v0, 0x2

    aput-object v1, v3, v0

    sput-object v3, LHo/o;->m:[Llo/m;

    return-void
.end method

.method public constructor <init>(LGo/g;LHo/o;)V
    .registers 4

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ldp/j;-><init>()V

    iput-object p1, p0, LHo/o;->b:LGo/g;

    iput-object p2, p0, LHo/o;->c:LHo/o;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$c;

    invoke-direct {v0, p0}, LHo/o$c;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->g(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/o;->d:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$g;

    invoke-direct {v0, p0}, LHo/o$g;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/o;->e:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$f;

    invoke-direct {v0, p0}, LHo/o$f;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->b(Leo/l;)Ljp/h;

    move-result-object p2

    iput-object p2, p0, LHo/o;->f:Ljp/h;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$e;

    invoke-direct {v0, p0}, LHo/o$e;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->i(Leo/l;)Ljp/i;

    move-result-object p2

    iput-object p2, p0, LHo/o;->g:Ljp/i;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$i;

    invoke-direct {v0, p0}, LHo/o$i;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->b(Leo/l;)Ljp/h;

    move-result-object p2

    iput-object p2, p0, LHo/o;->h:Ljp/h;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$h;

    invoke-direct {v0, p0}, LHo/o$h;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/o;->i:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$k;

    invoke-direct {v0, p0}, LHo/o$k;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/o;->j:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance v0, LHo/o$d;

    invoke-direct {v0, p0}, LHo/o$d;-><init>(LHo/o;)V

    invoke-interface {p2, v0}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/o;->k:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p1

    new-instance p2, LHo/o$j;

    invoke-direct {p2, p0}, LHo/o$j;-><init>(LHo/o;)V

    invoke-interface {p1, p2}, Ljp/n;->b(Leo/l;)Ljp/h;

    move-result-object p1

    iput-object p1, p0, LHo/o;->l:Ljp/h;

    return-void
.end method

.method protected static B(LGo/g;Lxo/w;Ljava/util/List;)LHo/o$b;
    .registers 22

    move-object/from16 v0, p2

    const-string v1, "jValueParameters"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v1, v0

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/q;->d0(Ljava/lang/Iterable;)Lkotlin/collections/E;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-static {v1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Lkotlin/collections/E;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_1d
    move-object v5, v1

    check-cast v5, Lkotlin/collections/F;

    invoke-virtual {v5}, Lkotlin/collections/F;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_116

    invoke-virtual {v5}, Lkotlin/collections/F;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lkotlin/collections/D;

    invoke-virtual {v5}, Lkotlin/collections/D;->a()I

    move-result v9

    invoke-virtual {v5}, Lkotlin/collections/D;->b()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LKo/z;

    move-object/from16 v15, p0

    invoke-static {v15, v5}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object v10

    sget-object v6, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v6, v3, v3, v8, v7}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v6

    invoke-interface {v5}, LKo/z;->b()Z

    move-result v7

    const/4 v11, 0x1

    if-eqz v7, :cond_86

    invoke-interface {v5}, LKo/z;->getType()LKo/w;

    move-result-object v7

    instance-of v12, v7, LKo/f;

    if-eqz v12, :cond_56

    move-object v8, v7

    check-cast v8, LKo/f;

    :cond_56
    if-eqz v8, :cond_72

    invoke-virtual/range {p0 .. p0}, LGo/g;->g()LIo/d;

    move-result-object v7

    invoke-virtual {v7, v8, v6, v11}, LIo/d;->d(LKo/f;LIo/a;Z)Lkp/v0;

    move-result-object v6

    invoke-virtual/range {p0 .. p0}, LGo/g;->d()Luo/B;

    move-result-object v7

    invoke-interface {v7}, Luo/B;->m()Lro/j;

    move-result-object v7

    invoke-virtual {v7, v6}, Lro/j;->j(Lkp/E;)Lkp/E;

    move-result-object v7

    new-instance v8, LUn/j;

    invoke-direct {v8, v6, v7}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_98

    :cond_72
    new-instance v0, Ljava/lang/AssertionError;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Vararg parameter should be an array: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    :cond_86
    invoke-virtual/range {p0 .. p0}, LGo/g;->g()LIo/d;

    move-result-object v7

    invoke-interface {v5}, LKo/z;->getType()LKo/w;

    move-result-object v12

    invoke-virtual {v7, v12, v6}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v6

    new-instance v7, LUn/j;

    invoke-direct {v7, v6, v8}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v8, v7

    :goto_98
    invoke-virtual {v8}, LUn/j;->a()Ljava/lang/Object;

    move-result-object v6

    move-object v12, v6

    check-cast v12, Lkp/E;

    invoke-virtual {v8}, LUn/j;->b()Ljava/lang/Object;

    move-result-object v6

    move-object/from16 v16, v6

    check-cast v16, Lkp/E;

    invoke-virtual/range {p1 .. p1}, Lxo/o;->getName()LTo/f;

    move-result-object v6

    invoke-virtual {v6}, LTo/f;->b()Ljava/lang/String;

    move-result-object v6

    const-string v7, "equals"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_d7

    invoke-interface/range {p2 .. p2}, Ljava/util/List;->size()I

    move-result v6

    if-ne v6, v11, :cond_d7

    invoke-virtual/range {p0 .. p0}, LGo/g;->d()Luo/B;

    move-result-object v6

    invoke-interface {v6}, Luo/B;->m()Lro/j;

    move-result-object v6

    invoke-virtual {v6}, Lro/j;->E()Lkp/M;

    move-result-object v6

    invoke-static {v6, v12}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_d7

    const-string v6, "other"

    invoke-static {v6}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v6

    :cond_d5
    :goto_d5
    move-object v11, v6

    goto :goto_f3

    :cond_d7
    invoke-interface {v5}, LKo/z;->getName()LTo/f;

    move-result-object v6

    if-nez v6, :cond_de

    const/4 v4, 0x1

    :cond_de
    if-nez v6, :cond_d5

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "p"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v6

    goto :goto_d5

    :goto_f3
    new-instance v14, Lxo/W;

    invoke-virtual/range {p0 .. p0}, LGo/g;->a()LGo/c;

    move-result-object v6

    invoke-virtual {v6}, LGo/c;->t()LJo/b;

    move-result-object v6

    invoke-interface {v6, v5}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v17

    const/4 v5, 0x0

    const/16 v18, 0x0

    const/4 v8, 0x0

    const/4 v13, 0x0

    move-object v6, v14

    move-object/from16 v7, p1

    move-object v3, v14

    move v14, v5

    move/from16 v15, v18

    invoke-direct/range {v6 .. v17}, Lxo/W;-><init>(Luo/a;Luo/b0;ILvo/h;LTo/f;Lkp/E;ZZZLkp/E;Luo/S;)V

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    goto/16 :goto_1d

    :cond_116
    invoke-static {v2}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    new-instance v1, LHo/o$b;

    invoke-direct {v1, v0, v4}, LHo/o$b;-><init>(Ljava/util/List;Z)V

    return-object v1
.end method

.method public static final synthetic h(LHo/o;)Ljp/i;
    .registers 1

    iget-object p0, p0, LHo/o;->g:Ljp/i;

    return-object p0
.end method

.method public static final synthetic i(LHo/o;)Ljp/h;
    .registers 1

    iget-object p0, p0, LHo/o;->f:Ljp/h;

    return-object p0
.end method

.method public static final j(LHo/o;LKo/n;)LFo/f;
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface/range {p1 .. p1}, LKo/r;->isFinal()Z

    move-result v2

    const/4 v3, 0x1

    xor-int/lit8 v8, v2, 0x1

    iget-object v2, v0, LHo/o;->b:LGo/g;

    invoke-static {v2, v1}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, LHo/o;->x()Luo/k;

    move-result-object v4

    sget-object v6, Luo/A;->FINAL:Luo/A;

    invoke-interface/range {p1 .. p1}, LKo/r;->getVisibility()Luo/f0;

    move-result-object v7

    const-string v9, "<this>"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v7}, LDo/u;->e(Luo/f0;)Luo/r;

    move-result-object v7

    invoke-interface/range {p1 .. p1}, LKo/s;->getName()LTo/f;

    move-result-object v9

    invoke-virtual {v2}, LGo/g;->a()LGo/c;

    move-result-object v10

    invoke-virtual {v10}, LGo/c;->t()LJo/b;

    move-result-object v10

    invoke-interface {v10, v1}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v10

    invoke-interface/range {p1 .. p1}, LKo/r;->isFinal()Z

    move-result v11

    const/4 v12, 0x0

    if-eqz v11, :cond_46

    invoke-interface/range {p1 .. p1}, LKo/r;->isStatic()Z

    move-result v11

    if-eqz v11, :cond_46

    const/4 v11, 0x1

    goto :goto_47

    :cond_46
    const/4 v11, 0x0

    :goto_47
    invoke-static/range {v4 .. v11}, LFo/f;->X0(Luo/k;LGo/e;Luo/A;Luo/r;ZLTo/f;LJo/a;Z)LFo/f;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v3, v4, v4, v4, v4}, Lxo/L;->R0(Lxo/M;Lxo/N;Luo/t;Luo/t;)V

    invoke-virtual {v2}, LGo/g;->g()LIo/d;

    move-result-object v5

    invoke-interface/range {p1 .. p1}, LKo/n;->getType()LKo/w;

    move-result-object v6

    sget-object v7, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v8, 0x7

    invoke-static {v7, v12, v12, v4, v8}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v14

    invoke-static {v14}, Lro/j;->i0(Lkp/E;)Z

    move-result v5

    if-nez v5, :cond_6e

    invoke-static {v14}, Lro/j;->k0(Lkp/E;)Z

    move-result v5

    if-eqz v5, :cond_77

    :cond_6e
    invoke-interface/range {p1 .. p1}, LKo/r;->isFinal()Z

    move-result v5

    if-eqz v5, :cond_77

    invoke-interface/range {p1 .. p1}, LKo/r;->isStatic()Z

    :cond_77
    sget-object v18, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    invoke-virtual/range {p0 .. p0}, LHo/o;->v()Luo/O;

    move-result-object v16

    const/16 v17, 0x0

    move-object v13, v3

    move-object/from16 v15, v18

    invoke-virtual/range {v13 .. v18}, Lxo/L;->V0(Lkp/E;Ljava/util/List;Luo/O;Lxo/O;Ljava/util/List;)V

    invoke-virtual {v3}, Lxo/X;->getType()Lkp/E;

    move-result-object v5

    invoke-static {v3, v5}, LWo/i;->F(LFo/f;Lkp/E;)Z

    move-result v5

    if-eqz v5, :cond_97

    new-instance v5, LHo/q;

    invoke-direct {v5, v0, v1, v3}, LHo/q;-><init>(LHo/o;LKo/n;LFo/f;)V

    invoke-virtual {v3, v4, v5}, Lxo/Y;->I0(Ljp/k;Leo/a;)V

    :cond_97
    invoke-virtual {v2}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->h()LEo/i;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v3
.end method

.method protected static o(LKo/q;LGo/g;)Lkp/E;
    .registers 7

    const-string v0, "method"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, LKo/p;->g()LAo/r;

    move-result-object v0

    invoke-virtual {v0}, LAo/r;->n()Z

    move-result v0

    sget-object v1, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1, v0, v2, v3, v4}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v0

    invoke-virtual {p1}, LGo/g;->g()LIo/d;

    move-result-object p1

    invoke-interface {p0}, LKo/q;->y()LAo/E;

    move-result-object p0

    invoke-virtual {p1, p0, v0}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method protected final A(LKo/q;)LFo/e;
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "method"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v0, LHo/o;->b:LGo/g;

    invoke-static {v2, v1}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, LHo/o;->x()Luo/k;

    move-result-object v4

    invoke-interface/range {p1 .. p1}, LKo/s;->getName()LTo/f;

    move-result-object v5

    invoke-virtual {v2}, LGo/g;->a()LGo/c;

    move-result-object v6

    invoke-virtual {v6}, LGo/c;->t()LJo/b;

    move-result-object v6

    invoke-interface {v6, v1}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v6

    iget-object v7, v0, LHo/o;->e:Ljp/j;

    invoke-interface {v7}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LHo/b;

    invoke-interface/range {p1 .. p1}, LKo/s;->getName()LTo/f;

    move-result-object v8

    invoke-interface {v7, v8}, LHo/b;->b(LTo/f;)LKo/v;

    move-result-object v7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v7, :cond_45

    invoke-interface/range {p1 .. p1}, LKo/q;->e()Ljava/util/List;

    move-result-object v7

    check-cast v7, Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_45

    const/4 v7, 0x1

    goto :goto_46

    :cond_45
    const/4 v7, 0x0

    :goto_46
    invoke-static {v4, v3, v5, v6, v7}, LFo/e;->l1(Luo/k;LGo/e;LTo/f;LJo/a;Z)LFo/e;

    move-result-object v3

    invoke-static {v2, v3, v1, v8}, LGo/b;->b(LGo/g;Lxo/p;LKo/y;I)LGo/g;

    move-result-object v2

    invoke-interface/range {p1 .. p1}, LKo/y;->getTypeParameters()Ljava/util/ArrayList;

    move-result-object v4

    new-instance v5, Ljava/util/ArrayList;

    invoke-static {v4}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_5f
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_7a

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LKo/x;

    invoke-virtual {v2}, LGo/g;->f()LGo/k;

    move-result-object v7

    invoke-interface {v7, v6}, LGo/k;->a(LKo/x;)Luo/X;

    move-result-object v6

    invoke-static {v6}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5f

    :cond_7a
    invoke-interface/range {p1 .. p1}, LKo/q;->e()Ljava/util/List;

    move-result-object v4

    invoke-static {v2, v3, v4}, LHo/o;->B(LGo/g;Lxo/w;Ljava/util/List;)LHo/o$b;

    move-result-object v4

    invoke-static {v1, v2}, LHo/o;->o(LKo/q;LGo/g;)Lkp/E;

    move-result-object v6

    invoke-virtual {v4}, LHo/o$b;->a()Ljava/util/List;

    move-result-object v7

    invoke-virtual {v0, v1, v5, v6, v7}, LHo/o;->z(LKo/q;Ljava/util/ArrayList;Lkp/E;Ljava/util/List;)LHo/o$a;

    move-result-object v5

    invoke-virtual {v5}, LHo/o$a;->c()Lkp/E;

    move-result-object v6

    if-eqz v6, :cond_9e

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v10

    invoke-static {v3, v6, v10}, LWo/h;->i(Luo/a;Lkp/E;Lvo/h;)Lxo/O;

    move-result-object v6

    move-object v11, v6

    goto :goto_9f

    :cond_9e
    const/4 v11, 0x0

    :goto_9f
    invoke-virtual/range {p0 .. p0}, LHo/o;->v()Luo/O;

    move-result-object v12

    sget-object v13, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    invoke-virtual {v5}, LHo/o$a;->e()Ljava/util/List;

    move-result-object v14

    invoke-virtual {v5}, LHo/o$a;->f()Ljava/util/List;

    move-result-object v15

    invoke-virtual {v5}, LHo/o$a;->d()Lkp/E;

    move-result-object v16

    sget-object v6, Luo/A;->Companion:Luo/A$a;

    invoke-interface/range {p1 .. p1}, LKo/r;->isAbstract()Z

    move-result v10

    invoke-interface/range {p1 .. p1}, LKo/r;->isFinal()Z

    move-result v17

    xor-int/lit8 v7, v17, 0x1

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v8, v10, v7}, Luo/A$a;->a(ZZZ)Luo/A;

    move-result-object v17

    invoke-interface/range {p1 .. p1}, LKo/r;->getVisibility()Luo/f0;

    move-result-object v1

    const-string v6, "<this>"

    invoke-static {v1, v6}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, LDo/u;->e(Luo/f0;)Luo/r;

    move-result-object v18

    invoke-virtual {v5}, LHo/o$a;->c()Lkp/E;

    move-result-object v1

    if-eqz v1, :cond_ed

    sget-object v1, LFo/e;->G:Luo/a$a;

    invoke-virtual {v4}, LHo/o$b;->a()Ljava/util/List;

    move-result-object v6

    invoke-static {v6}, Lkotlin/collections/q;->r(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v6

    new-instance v7, LUn/j;

    invoke-direct {v7, v1, v6}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v7}, Lkotlin/collections/J;->h(LUn/j;)Ljava/util/Map;

    move-result-object v1

    :goto_ea
    move-object/from16 v19, v1

    goto :goto_f2

    :cond_ed
    invoke-static {}, Lkotlin/collections/J;->d()Ljava/util/Map;

    move-result-object v1

    goto :goto_ea

    :goto_f2
    move-object v10, v3

    invoke-virtual/range {v10 .. v19}, LFo/e;->k1(Lxo/O;Luo/O;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkp/E;Luo/A;Luo/r;Ljava/util/Map;)Lxo/P;

    invoke-virtual {v5}, LHo/o$a;->b()Z

    move-result v1

    invoke-virtual {v4}, LHo/o$b;->b()Z

    move-result v4

    invoke-virtual {v3, v1, v4}, LFo/e;->m1(ZZ)V

    invoke-virtual {v5}, LHo/o$a;->a()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    xor-int/2addr v1, v9

    if-nez v1, :cond_10f

    return-object v3

    :cond_10f
    invoke-virtual {v2}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->s()LEo/l;

    move-result-object v1

    invoke-virtual {v5}, LHo/o$a;->a()Ljava/util/List;

    move-result-object v2

    invoke-interface {v1, v3, v2}, LEo/l;->a(LFo/e;Ljava/util/List;)V

    const/4 v1, 0x0

    throw v1
.end method

.method public final a()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, LHo/o;->m:[Llo/m;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v1, p0, LHo/o;->i:Ljp/j;

    invoke-static {v1, v0}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    return-object v0
.end method

.method public b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->a()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_17

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p1

    :cond_17
    iget-object p2, p0, LHo/o;->h:Ljp/h;

    invoke-interface {p2, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    return-object p1
.end method

.method public c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->d()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_17

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p1

    :cond_17
    iget-object p2, p0, LHo/o;->l:Ljp/h;

    invoke-interface {p2, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    return-object p1
.end method

.method public final d()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, LHo/o;->m:[Llo/m;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    iget-object v1, p0, LHo/o;->j:Ljp/j;

    invoke-static {v1, v0}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    return-object v0
.end method

.method public e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "nameFilter"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LHo/o;->d:Ljp/j;

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    return-object p1
.end method

.method public final f()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, LHo/o;->m:[Llo/m;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    iget-object v1, p0, LHo/o;->k:Ljp/j;

    invoke-static {v1, v0}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    return-object v0
.end method

.method protected abstract k(Ldp/d;Leo/l;)Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method

.method protected abstract l(Ldp/d;Leo/l;)Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method

.method protected m(Ljava/util/ArrayList;LTo/f;)V
    .registers 3

    const-string p1, "name"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method protected abstract n()LHo/b;
.end method

.method protected abstract p(Ljava/util/LinkedHashSet;LTo/f;)V
.end method

.method protected abstract q(Ljava/util/ArrayList;LTo/f;)V
.end method

.method protected abstract r(Ldp/d;)Ljava/util/Set;
.end method

.method protected final s()Ljp/j;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljp/j<",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, LHo/o;->d:Ljp/j;

    return-object v0
.end method

.method protected final t()LGo/g;
    .registers 2

    iget-object v0, p0, LHo/o;->b:LGo/g;

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Lazy scope for "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->x()Luo/k;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method protected final u()Ljp/j;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljp/j<",
            "LHo/b;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/o;->e:Ljp/j;

    return-object v0
.end method

.method protected abstract v()Luo/O;
.end method

.method protected final w()LHo/o;
    .registers 2

    iget-object v0, p0, LHo/o;->c:LHo/o;

    return-object v0
.end method

.method protected abstract x()Luo/k;
.end method

.method protected y(LFo/e;)Z
    .registers 2

    const/4 p1, 0x1

    return p1
.end method

.method protected abstract z(LKo/q;Ljava/util/ArrayList;Lkp/E;Ljava/util/List;)LHo/o$a;
.end method
