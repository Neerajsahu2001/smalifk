.class final LHo/q;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljp/k<",
        "+",
        "LYo/g<",
        "*>;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/o;

.field final synthetic b:LKo/n;

.field final synthetic c:Lxo/L;


# direct methods
.method constructor <init>(LHo/o;LKo/n;LFo/f;)V
    .registers 4

    iput-object p1, p0, LHo/q;->a:LHo/o;

    iput-object p2, p0, LHo/q;->b:LKo/n;

    iput-object p3, p0, LHo/q;->c:Lxo/L;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 6

    iget-object v0, p0, LHo/q;->a:LHo/o;

    invoke-virtual {v0}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->e()Ljp/n;

    move-result-object v1

    new-instance v2, LHo/p;

    iget-object v3, p0, LHo/q;->b:LKo/n;

    iget-object v4, p0, LHo/q;->c:Lxo/L;

    invoke-direct {v2, v0, v3, v4}, LHo/p;-><init>(LHo/o;LKo/n;Lxo/L;)V

    invoke-interface {v1, v2}, Ljp/n;->h(Leo/a;)Ljp/k;

    move-result-object v0

    return-object v0
.end method
