.class public final LHo/k;
.super LHo/o;
.source "LazyJavaClassMemberScope.kt"


# instance fields
.field private final n:Luo/e;

.field private final o:LKo/g;

.field private final p:Z

.field private final q:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/List<",
            "Luo/d;",
            ">;>;"
        }
    .end annotation
.end field

.field private final r:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;>;"
        }
    .end annotation
.end field

.field private final s:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;>;"
        }
    .end annotation
.end field

.field private final t:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/Map<",
            "LTo/f;",
            "LKo/n;",
            ">;>;"
        }
    .end annotation
.end field

.field private final u:Ljp/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/i<",
            "LTo/f;",
            "Luo/e;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LGo/g;Luo/e;LKo/g;ZLHo/k;)V
    .registers 7

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ownerDescriptor"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "jClass"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1, p5}, LHo/o;-><init>(LGo/g;LHo/o;)V

    iput-object p2, p0, LHo/k;->n:Luo/e;

    iput-object p3, p0, LHo/k;->o:LKo/g;

    iput-boolean p4, p0, LHo/k;->p:Z

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance p3, LHo/k$a;

    invoke-direct {p3, p1, p0}, LHo/k$a;-><init>(LGo/g;LHo/k;)V

    invoke-interface {p2, p3}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/k;->q:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance p3, LHo/k$e;

    invoke-direct {p3, p0}, LHo/k$e;-><init>(LHo/k;)V

    invoke-interface {p2, p3}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/k;->r:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance p3, LHo/k$c;

    invoke-direct {p3, p1, p0}, LHo/k$c;-><init>(LGo/g;LHo/k;)V

    invoke-interface {p2, p3}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/k;->s:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance p3, LHo/k$b;

    invoke-direct {p3, p0}, LHo/k$b;-><init>(LHo/k;)V

    invoke-interface {p2, p3}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, LHo/k;->t:Ljp/j;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance p3, LHo/k$f;

    invoke-direct {p3, p1, p0}, LHo/k$f;-><init>(LGo/g;LHo/k;)V

    invoke-interface {p2, p3}, Ljp/n;->i(Leo/l;)Ljp/i;

    move-result-object p1

    iput-object p1, p0, LHo/k;->u:Ljp/i;

    return-void
.end method

.method public static final C(LHo/k;)LFo/b;
    .registers 18

    move-object/from16 v7, p0

    iget-object v0, v7, LHo/k;->o:LKo/g;

    invoke-interface {v0}, LKo/g;->n()Z

    move-result v1

    invoke-interface {v0}, LKo/g;->D()Z

    const/4 v2, 0x0

    if-nez v1, :cond_10

    goto/16 :goto_157

    :cond_10
    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v4

    invoke-virtual {v4}, LGo/g;->a()LGo/c;

    move-result-object v4

    invoke-virtual {v4}, LGo/c;->t()LJo/b;

    move-result-object v4

    invoke-interface {v4, v0}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v4

    iget-object v8, v7, LHo/k;->n:Luo/e;

    const/4 v9, 0x1

    invoke-static {v8, v3, v9, v4}, LFo/b;->l1(Luo/e;Lvo/h;ZLJo/a;)LFo/b;

    move-result-object v10

    const/4 v11, 0x0

    if-eqz v1, :cond_11b

    invoke-interface {v0}, LKo/g;->w()Ljava/util/Collection;

    move-result-object v0

    new-instance v12, Ljava/util/ArrayList;

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v1

    invoke-direct {v12, v1}, Ljava/util/ArrayList;-><init>(I)V

    sget-object v1, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v3, 0x6

    invoke-static {v1, v9, v11, v2, v3}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v13

    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_52
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_73

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, LKo/q;

    invoke-interface {v5}, LKo/s;->getName()LTo/f;

    move-result-object v5

    sget-object v6, LDo/E;->b:LTo/f;

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6f

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_52

    :cond_6f
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_52

    :cond_73
    new-instance v0, LUn/j;

    invoke-direct {v0, v1, v3}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0}, LUn/j;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-virtual {v0}, LUn/j;->b()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    invoke-static {v1}, Lkotlin/collections/q;->t(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, LKo/q;

    if-eqz v15, :cond_e5

    invoke-interface {v15}, LKo/q;->y()LAo/E;

    move-result-object v0

    instance-of v1, v0, LKo/f;

    if-eqz v1, :cond_bd

    new-instance v1, LUn/j;

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v2

    invoke-virtual {v2}, LGo/g;->g()LIo/d;

    move-result-object v2

    check-cast v0, LKo/f;

    invoke-virtual {v2, v0, v13, v9}, LIo/d;->d(LKo/f;LIo/a;Z)Lkp/v0;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v3

    invoke-virtual {v3}, LGo/g;->g()LIo/d;

    move-result-object v3

    invoke-interface {v0}, LKo/f;->v()LAo/E;

    move-result-object v0

    invoke-virtual {v3, v0, v13}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v0

    invoke-direct {v1, v2, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_ce

    :cond_bd
    new-instance v1, LUn/j;

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v3

    invoke-virtual {v3}, LGo/g;->g()LIo/d;

    move-result-object v3

    invoke-virtual {v3, v0, v13}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v0

    invoke-direct {v1, v0, v2}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_ce
    invoke-virtual {v1}, LUn/j;->a()Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Lkp/E;

    invoke-virtual {v1}, LUn/j;->b()Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Lkp/E;

    const/4 v3, 0x0

    move-object/from16 v0, p0

    move-object v1, v12

    move-object v2, v10

    move-object v4, v15

    invoke-direct/range {v0 .. v6}, LHo/k;->L(Ljava/util/ArrayList;LFo/b;ILKo/q;Lkp/E;Lkp/E;)V

    :cond_e5
    if-eqz v15, :cond_e9

    const/4 v15, 0x1

    goto :goto_ea

    :cond_e9
    const/4 v15, 0x0

    :goto_ea
    invoke-interface {v14}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v14

    const/4 v0, 0x0

    :goto_ef
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_11f

    add-int/lit8 v16, v0, 0x1

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, LKo/q;

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->g()LIo/d;

    move-result-object v1

    invoke-interface {v4}, LKo/q;->y()LAo/E;

    move-result-object v2

    invoke-virtual {v1, v2, v13}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v5

    add-int v3, v0, v15

    const/4 v6, 0x0

    move-object/from16 v0, p0

    move-object v1, v12

    move-object v2, v10

    invoke-direct/range {v0 .. v6}, LHo/k;->L(Ljava/util/ArrayList;LFo/b;ILKo/q;Lkp/E;Lkp/E;)V

    move/from16 v0, v16

    goto :goto_ef

    :cond_11b
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v12

    :cond_11f
    invoke-virtual {v10, v11}, LFo/b;->Y0(Z)V

    invoke-interface {v8}, Luo/e;->getVisibility()Luo/r;

    move-result-object v0

    const-string v1, "classDescriptor.visibility"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, LDo/u;->b:Luo/r;

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_13a

    sget-object v0, LDo/u;->c:Luo/r;

    const-string v1, "PROTECTED_AND_PACKAGE"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_13a
    invoke-virtual {v10, v12, v0}, Lxo/k;->j1(Ljava/util/List;Luo/r;)V

    invoke-virtual {v10, v9}, LFo/b;->X0(Z)V

    invoke-interface {v8}, Luo/e;->q()Lkp/M;

    move-result-object v0

    invoke-virtual {v10, v0}, Lxo/w;->c1(Lkp/M;)V

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->h()LEo/i;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v2, v10

    :goto_157
    return-object v2
.end method

.method public static final D(LHo/k;)LFo/b;
    .registers 23

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v2

    invoke-virtual {v2}, LGo/g;->a()LGo/c;

    move-result-object v2

    invoke-virtual {v2}, LGo/c;->t()LJo/b;

    move-result-object v2

    iget-object v3, v0, LHo/k;->o:LKo/g;

    invoke-interface {v2, v3}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v2

    iget-object v4, v0, LHo/k;->n:Luo/e;

    const/4 v5, 0x1

    invoke-static {v4, v1, v5, v2}, LFo/b;->l1(Luo/e;Lvo/h;ZLJo/a;)LFo/b;

    move-result-object v1

    invoke-interface {v3}, LKo/g;->m()Ljava/util/ArrayList;

    move-result-object v2

    new-instance v3, Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    sget-object v5, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v15, 0x0

    invoke-static {v5, v15, v15, v7, v6}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v5

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v9, 0x0

    :goto_3d
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_93

    add-int/lit8 v18, v9, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LKo/v;

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v7

    invoke-virtual {v7}, LGo/g;->g()LIo/d;

    move-result-object v7

    invoke-interface {v6}, LKo/v;->getType()LKo/w;

    move-result-object v8

    invoke-virtual {v7, v8, v5}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v12

    new-instance v14, Lxo/W;

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v10

    invoke-interface {v6}, LKo/s;->getName()LTo/f;

    move-result-object v11

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v7

    invoke-virtual {v7}, LGo/g;->a()LGo/c;

    move-result-object v7

    invoke-virtual {v7}, LGo/c;->t()LJo/b;

    move-result-object v7

    invoke-interface {v7, v6}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v17

    const/16 v16, 0x0

    const/16 v19, 0x0

    const/4 v8, 0x0

    const/4 v13, 0x0

    const/16 v20, 0x0

    move-object v6, v14

    move-object v7, v1

    move-object/from16 v21, v14

    move/from16 v14, v16

    move/from16 v15, v19

    move-object/from16 v16, v20

    invoke-direct/range {v6 .. v17}, Lxo/W;-><init>(Luo/a;Luo/b0;ILvo/h;LTo/f;Lkp/E;ZZZLkp/E;Luo/S;)V

    move-object/from16 v6, v21

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v9, v18

    const/4 v15, 0x0

    goto :goto_3d

    :cond_93
    const/4 v6, 0x0

    invoke-virtual {v1, v6}, LFo/b;->Y0(Z)V

    invoke-interface {v4}, Luo/e;->getVisibility()Luo/r;

    move-result-object v0

    const-string v2, "classDescriptor.visibility"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, LDo/u;->b:Luo/r;

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_af

    sget-object v0, LDo/u;->c:Luo/r;

    const-string v2, "PROTECTED_AND_PACKAGE"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_af
    invoke-virtual {v1, v3, v0}, Lxo/k;->j1(Ljava/util/List;Luo/r;)V

    invoke-virtual {v1, v6}, LFo/b;->X0(Z)V

    invoke-interface {v4}, Luo/e;->q()Lkp/M;

    move-result-object v0

    invoke-virtual {v1, v0}, Lxo/w;->c1(Lkp/M;)V

    return-object v1
.end method

.method public static final synthetic E(LHo/k;)Ljp/j;
    .registers 1

    iget-object p0, p0, LHo/k;->t:Ljp/j;

    return-object p0
.end method

.method public static final synthetic F(LHo/k;)Ljp/j;
    .registers 1

    iget-object p0, p0, LHo/k;->s:Ljp/j;

    return-object p0
.end method

.method public static final synthetic G(LHo/k;)LKo/g;
    .registers 1

    iget-object p0, p0, LHo/k;->o:LKo/g;

    return-object p0
.end method

.method public static final synthetic H(LHo/k;)Ljp/j;
    .registers 1

    iget-object p0, p0, LHo/k;->r:Ljp/j;

    return-object p0
.end method

.method public static final I(LHo/k;LKo/k;)LFo/b;
    .registers 11

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object v0

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->t()LJo/b;

    move-result-object v1

    invoke-interface {v1, p1}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v1

    iget-object v2, p0, LHo/k;->n:Luo/e;

    const/4 v3, 0x0

    invoke-static {v2, v0, v3, v1}, LFo/b;->l1(Luo/e;Lvo/h;ZLJo/a;)LFo/b;

    move-result-object v0

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object p0

    invoke-interface {v2}, Luo/e;->r()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {p0, v0, p1, v1}, LGo/b;->b(LGo/g;Lxo/p;LKo/y;I)LGo/g;

    move-result-object p0

    invoke-interface {p1}, LKo/k;->e()Ljava/util/List;

    move-result-object v1

    invoke-static {p0, v0, v1}, LHo/o;->B(LGo/g;Lxo/w;Ljava/util/List;)LHo/o$b;

    move-result-object v1

    invoke-interface {v2}, Luo/e;->r()Ljava/util/List;

    move-result-object v4

    const-string v5, "classDescriptor.declaredTypeParameters"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/util/Collection;

    invoke-interface {p1}, LKo/y;->getTypeParameters()Ljava/util/ArrayList;

    move-result-object v5

    new-instance v6, Ljava/util/ArrayList;

    invoke-static {v5}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_53
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_6e

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LKo/x;

    invoke-virtual {p0}, LGo/g;->f()LGo/k;

    move-result-object v8

    invoke-interface {v8, v7}, LGo/k;->a(LKo/x;)Luo/X;

    move-result-object v7

    invoke-static {v7}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_53

    :cond_6e
    invoke-static {v6, v4}, Lkotlin/collections/q;->L(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v1}, LHo/o$b;->a()Ljava/util/List;

    move-result-object v5

    invoke-interface {p1}, LKo/r;->getVisibility()Luo/f0;

    move-result-object p1

    const-string v6, "<this>"

    invoke-static {p1, v6}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, LDo/u;->e(Luo/f0;)Luo/r;

    move-result-object p1

    invoke-virtual {v0, v5, p1, v4}, Lxo/k;->k1(Ljava/util/List;Luo/r;Ljava/util/List;)V

    invoke-virtual {v0, v3}, LFo/b;->X0(Z)V

    invoke-virtual {v1}, LHo/o$b;->b()Z

    move-result p1

    invoke-virtual {v0, p1}, LFo/b;->Y0(Z)V

    invoke-interface {v2}, Luo/e;->q()Lkp/M;

    move-result-object p1

    invoke-virtual {v0, p1}, Lxo/w;->c1(Lkp/M;)V

    invoke-virtual {p0}, LGo/g;->a()LGo/c;

    move-result-object p0

    invoke-virtual {p0}, LGo/c;->h()LEo/i;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0
.end method

.method public static final J(LHo/k;LTo/f;)Ljava/util/ArrayList;
    .registers 4

    invoke-virtual {p0}, LHo/o;->u()Ljp/j;

    move-result-object v0

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LHo/b;

    invoke-interface {v0, p1}, LHo/b;->c(LTo/f;)Ljava/util/Collection;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_31

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LKo/q;

    invoke-virtual {p0, v1}, LHo/o;->A(LKo/q;)LFo/e;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1d

    :cond_31
    return-object v0
.end method

.method public static final K(LHo/k;LTo/f;)Ljava/util/ArrayList;
    .registers 5

    invoke-direct {p0, p1}, LHo/k;->Z(LTo/f;)Ljava/util/LinkedHashSet;

    move-result-object p0

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_d
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_31

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Luo/Q;

    const-string v2, "<this>"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, LDo/K;->b(Luo/b;)Luo/b;

    move-result-object v2

    if-eqz v2, :cond_26

    goto :goto_d

    :cond_26
    invoke-static {v1}, LDo/h;->i(Luo/v;)Luo/v;

    move-result-object v1

    if-eqz v1, :cond_2d

    goto :goto_d

    :cond_2d
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_d

    :cond_31
    return-object p1
.end method

.method private final L(Ljava/util/ArrayList;LFo/b;ILKo/q;Lkp/E;Lkp/E;)V
    .registers 20

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v4

    invoke-interface/range {p4 .. p4}, LKo/s;->getName()LTo/f;

    move-result-object v5

    invoke-static/range {p5 .. p5}, Lkp/t0;->j(Lkp/E;)Lkp/v0;

    move-result-object v6

    invoke-interface/range {p4 .. p4}, LKo/q;->F()Z

    move-result v7

    if-eqz p6, :cond_18

    invoke-static/range {p6 .. p6}, Lkp/t0;->j(Lkp/E;)Lkp/v0;

    move-result-object v0

    :goto_16
    move-object v10, v0

    goto :goto_1a

    :cond_18
    const/4 v0, 0x0

    goto :goto_16

    :goto_1a
    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->t()LJo/b;

    move-result-object v0

    move-object/from16 v1, p4

    invoke-interface {v0, v1}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v11

    new-instance v12, Lxo/W;

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v2, 0x0

    move-object v0, v12

    move-object v1, p2

    move/from16 v3, p3

    invoke-direct/range {v0 .. v11}, Lxo/W;-><init>(Luo/a;Luo/b0;ILvo/h;LTo/f;Lkp/E;ZZZLkp/E;Luo/S;)V

    move-object v0, p1

    invoke-virtual {p1, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private final M(Ljava/util/LinkedHashSet;LTo/f;Ljava/util/ArrayList;Z)V
    .registers 12

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->c()Lgp/u;

    move-result-object v5

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->k()Llp/l;

    move-result-object v0

    invoke-interface {v0}, Llp/l;->a()LWo/o;

    move-result-object v6

    iget-object v4, p0, LHo/k;->n:Luo/e;

    move-object v1, p2

    move-object v2, p3

    move-object v3, p1

    invoke-static/range {v1 .. v6}, LEo/b;->d(LTo/f;Ljava/util/AbstractCollection;Ljava/util/Collection;Luo/e;Lgp/u;LWo/o;)Ljava/util/LinkedHashSet;

    move-result-object p2

    if-nez p4, :cond_2b

    invoke-interface {p1, p2}, Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z

    goto :goto_5c

    :cond_2b
    invoke-static {p2, p1}, Lkotlin/collections/q;->L(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p3

    new-instance p4, Ljava/util/ArrayList;

    invoke-static {p2}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v0

    invoke-direct {p4, v0}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_3c
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_59

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/Q;

    invoke-static {v0}, LDo/K;->c(Luo/b;)Luo/b;

    move-result-object v1

    check-cast v1, Luo/Q;

    if-nez v1, :cond_51

    goto :goto_55

    :cond_51
    invoke-static {v0, v1, p3}, LHo/k;->Q(Luo/Q;Luo/v;Ljava/util/AbstractCollection;)Luo/Q;

    move-result-object v0

    :goto_55
    invoke-virtual {p4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3c

    :cond_59
    invoke-interface {p1, p4}, Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z

    :goto_5c
    return-void
.end method

.method private final N(LTo/f;Ljava/util/LinkedHashSet;Ljava/util/LinkedHashSet;Ljava/util/AbstractSet;Leo/l;)V
    .registers 14

    invoke-interface {p3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_4
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_136

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/Q;

    invoke-static {v0}, LDo/K;->b(Luo/b;)Luo/b;

    move-result-object v1

    check-cast v1, Luo/Q;

    const/4 v2, 0x0

    if-nez v1, :cond_1b

    :cond_19
    move-object v1, v2

    goto :goto_5c

    :cond_1b
    invoke-static {v1}, LDo/K;->a(Luo/b;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-static {v3}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v3

    invoke-interface {p5, v3}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_30
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_19

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Luo/Q;

    invoke-interface {v4}, Luo/v;->H0()Luo/v$a;

    move-result-object v4

    invoke-interface {v4, p1}, Luo/v$a;->e(LTo/f;)Luo/v$a;

    invoke-interface {v4}, Luo/v$a;->r()Luo/v$a;

    invoke-interface {v4}, Luo/v$a;->l()Luo/v$a;

    invoke-interface {v4}, Luo/v$a;->build()Luo/v;

    move-result-object v4

    invoke-static {v4}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    check-cast v4, Luo/Q;

    invoke-static {v1, v4}, LHo/k;->U(Luo/Q;Luo/Q;)Z

    move-result v5

    if-eqz v5, :cond_30

    invoke-static {v4, v1, p2}, LHo/k;->Q(Luo/Q;Luo/v;Ljava/util/AbstractCollection;)Luo/Q;

    move-result-object v1

    :goto_5c
    invoke-static {v1, p4}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    invoke-static {v0}, LDo/h;->i(Luo/v;)Luo/v;

    move-result-object v1

    if-nez v1, :cond_68

    :cond_65
    move-object v1, v2

    goto/16 :goto_f7

    :cond_68
    invoke-interface {v1}, Luo/k;->getName()LTo/f;

    move-result-object v3

    const-string v4, "overridden.name"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p5, v3}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_7b
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_8f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Luo/Q;

    invoke-static {v5, v1}, LHo/k;->c0(Luo/Q;Luo/v;)Z

    move-result v5

    if-eqz v5, :cond_7b

    goto :goto_90

    :cond_8f
    move-object v4, v2

    :goto_90
    check-cast v4, Luo/Q;

    if-eqz v4, :cond_e6

    invoke-interface {v4}, Luo/v;->H0()Luo/v$a;

    move-result-object v3

    invoke-interface {v1}, Luo/a;->e()Ljava/util/List;

    move-result-object v5

    const-string v6, "overridden.valueParameters"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Ljava/lang/Iterable;

    new-instance v6, Ljava/util/ArrayList;

    invoke-static {v5}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_b0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_c4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Luo/b0;

    invoke-interface {v7}, Luo/a0;->getType()Lkp/E;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_b0

    :cond_c4
    invoke-interface {v4}, Luo/a;->e()Ljava/util/List;

    move-result-object v4

    const-string v5, "override.valueParameters"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/util/Collection;

    invoke-static {v6, v4, v1}, Landroidx/lifecycle/LifecycleOwnerKt;->b(Ljava/util/ArrayList;Ljava/util/Collection;Luo/a;)Ljava/util/ArrayList;

    move-result-object v4

    invoke-interface {v3, v4}, Luo/v$a;->c(Ljava/util/List;)Luo/v$a;

    invoke-interface {v3}, Luo/v$a;->r()Luo/v$a;

    invoke-interface {v3}, Luo/v$a;->l()Luo/v$a;

    invoke-interface {v3}, Luo/v$a;->o()Luo/v$a;

    invoke-interface {v3}, Luo/v$a;->build()Luo/v;

    move-result-object v3

    check-cast v3, Luo/Q;

    goto :goto_e7

    :cond_e6
    move-object v3, v2

    :goto_e7
    if-eqz v3, :cond_65

    invoke-direct {p0, v3}, LHo/k;->d0(Luo/Q;)Z

    move-result v4

    if-eqz v4, :cond_f0

    goto :goto_f1

    :cond_f0
    move-object v3, v2

    :goto_f1
    if-eqz v3, :cond_65

    invoke-static {v3, v1, p2}, LHo/k;->Q(Luo/Q;Luo/v;Ljava/util/AbstractCollection;)Luo/Q;

    move-result-object v1

    :goto_f7
    invoke-static {v1, p4}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    invoke-interface {v0}, Luo/v;->isSuspend()Z

    move-result v1

    if-nez v1, :cond_101

    goto :goto_131

    :cond_101
    invoke-interface {v0}, Luo/k;->getName()LTo/f;

    move-result-object v1

    const-string v3, "descriptor.name"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p5, v1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_114
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_131

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Luo/Q;

    invoke-static {v3}, LHo/k;->R(Luo/Q;)Luo/Q;

    move-result-object v3

    if-eqz v3, :cond_12d

    invoke-static {v3, v0}, LHo/k;->T(Luo/a;Luo/a;)Z

    move-result v4

    if-eqz v4, :cond_12d

    goto :goto_12e

    :cond_12d
    move-object v3, v2

    :goto_12e
    if-eqz v3, :cond_114

    move-object v2, v3

    :cond_131
    :goto_131
    invoke-static {v2, p4}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    goto/16 :goto_4

    :cond_136
    return-void
.end method

.method private final O(Ljava/util/Set;Ljava/util/AbstractCollection;Ltp/d;Leo/l;)V
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    invoke-interface/range {p1 .. p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_a
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Luo/L;

    invoke-direct {v0, v4, v2}, LHo/k;->S(Luo/L;Leo/l;)Z

    move-result v5

    const/4 v6, 0x0

    if-nez v5, :cond_1f

    goto/16 :goto_b4

    :cond_1f
    invoke-direct {v0, v4, v2}, LHo/k;->W(Luo/L;Leo/l;)Luo/Q;

    move-result-object v5

    invoke-static {v5}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-interface {v4}, Luo/c0;->N()Z

    move-result v7

    if-eqz v7, :cond_34

    invoke-static {v4, v2}, LHo/k;->X(Luo/L;Leo/l;)Luo/Q;

    move-result-object v7

    invoke-static {v7}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    goto :goto_35

    :cond_34
    move-object v7, v6

    :goto_35
    if-eqz v7, :cond_3d

    invoke-interface {v7}, Luo/z;->s()Luo/A;

    invoke-interface {v5}, Luo/z;->s()Luo/A;

    :cond_3d
    new-instance v14, LFo/d;

    iget-object v8, v0, LHo/k;->n:Luo/e;

    invoke-direct {v14, v8, v5, v7, v4}, LFo/d;-><init>(Luo/e;Luo/Q;Luo/Q;Luo/L;)V

    invoke-interface {v5}, Luo/a;->getReturnType()Lkp/E;

    move-result-object v9

    invoke-static {v9}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    sget-object v13, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    invoke-static {v8}, LWo/i;->k(Luo/e;)Luo/O;

    move-result-object v11

    const/4 v12, 0x0

    move-object v8, v14

    move-object v10, v13

    invoke-virtual/range {v8 .. v13}, Lxo/L;->V0(Lkp/E;Ljava/util/List;Luo/O;Lxo/O;Ljava/util/List;)V

    invoke-interface {v5}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object v8

    invoke-interface {v5}, Luo/n;->f()Luo/S;

    move-result-object v9

    const/4 v10, 0x0

    invoke-static {v14, v8, v10, v9}, LWo/h;->j(Luo/L;Lvo/h;ZLuo/S;)Lxo/M;

    move-result-object v15

    invoke-virtual {v15, v5}, Lxo/K;->N0(Luo/v;)V

    invoke-virtual {v14}, Lxo/X;->getType()Lkp/E;

    move-result-object v5

    invoke-virtual {v15, v5}, Lxo/M;->Q0(Lkp/E;)V

    if-eqz v7, :cond_af

    invoke-interface {v7}, Luo/a;->e()Ljava/util/List;

    move-result-object v5

    const-string v8, "setterMethod.valueParameters"

    invoke-static {v5, v8}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5}, Lkotlin/collections/q;->t(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Luo/b0;

    if-eqz v5, :cond_9b

    invoke-interface {v7}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object v9

    invoke-interface {v5}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object v10

    invoke-interface {v7}, Luo/z;->getVisibility()Luo/r;

    move-result-object v12

    invoke-interface {v7}, Luo/n;->f()Luo/S;

    move-result-object v13

    const/4 v11, 0x0

    move-object v8, v14

    invoke-static/range {v8 .. v13}, LWo/h;->l(Luo/L;Lvo/h;Lvo/h;ZLuo/r;Luo/S;)Lxo/N;

    move-result-object v5

    invoke-virtual {v5, v7}, Lxo/K;->N0(Luo/v;)V

    goto :goto_b0

    :cond_9b
    new-instance v1, Ljava/lang/AssertionError;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "No parameter found for "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v1

    :cond_af
    move-object v5, v6

    :goto_b0
    invoke-virtual {v14, v15, v5, v6, v6}, Lxo/L;->R0(Lxo/M;Lxo/N;Luo/t;Luo/t;)V

    move-object v6, v14

    :goto_b4
    move-object/from16 v5, p2

    if-eqz v6, :cond_a

    invoke-interface {v5, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    if-eqz v1, :cond_c0

    invoke-virtual {v1, v4}, Ltp/d;->add(Ljava/lang/Object;)Z

    :cond_c0
    return-void
.end method

.method private final P()Ljava/util/Collection;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "Lkp/E;",
            ">;"
        }
    .end annotation

    iget-boolean v0, p0, LHo/k;->p:Z

    iget-object v1, p0, LHo/k;->n:Luo/e;

    if-eqz v0, :cond_14

    invoke-interface {v1}, Luo/h;->j()Lkp/e0;

    move-result-object v0

    invoke-interface {v0}, Lkp/e0;->l()Ljava/util/Collection;

    move-result-object v0

    const-string v1, "ownerDescriptor.typeConstructor.supertypes"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :cond_14
    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->k()Llp/l;

    move-result-object v0

    invoke-interface {v0}, Llp/l;->c()Llp/f;

    move-result-object v0

    invoke-virtual {v0, v1}, Llp/f;->i(Luo/e;)Ljava/util/Collection;

    move-result-object v0

    return-object v0
.end method

.method private static Q(Luo/Q;Luo/v;Ljava/util/AbstractCollection;)Luo/Q;
    .registers 5

    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_7

    goto :goto_3a

    :cond_7
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_b
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3a

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/Q;

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    invoke-interface {v0}, Luo/v;->t0()Luo/v;

    move-result-object v1

    if-nez v1, :cond_b

    invoke-static {v0, p1}, LHo/k;->T(Luo/a;Luo/a;)Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-interface {p0}, Luo/v;->H0()Luo/v$a;

    move-result-object p0

    invoke-interface {p0}, Luo/v$a;->j()Luo/v$a;

    move-result-object p0

    invoke-interface {p0}, Luo/v$a;->build()Luo/v;

    move-result-object p0

    invoke-static {p0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    check-cast p0, Luo/Q;

    :cond_3a
    :goto_3a
    return-object p0
.end method

.method private static R(Luo/Q;)Luo/Q;
    .registers 6

    invoke-interface {p0}, Luo/a;->e()Ljava/util/List;

    move-result-object v0

    const-string v1, "valueParameters"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/q;->C(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/b0;

    const/4 v2, 0x0

    if-eqz v0, :cond_7c

    invoke-interface {v0}, Luo/a0;->getType()Lkp/E;

    move-result-object v3

    invoke-virtual {v3}, Lkp/E;->N0()Lkp/e0;

    move-result-object v3

    invoke-interface {v3}, Lkp/e0;->n()Luo/h;

    move-result-object v3

    if-eqz v3, :cond_33

    invoke-static {v3}, Lap/c;->h(Luo/k;)LTo/d;

    move-result-object v3

    invoke-virtual {v3}, LTo/d;->f()Z

    move-result v4

    if-eqz v4, :cond_2b

    goto :goto_2c

    :cond_2b
    move-object v3, v2

    :goto_2c
    if-eqz v3, :cond_33

    invoke-virtual {v3}, LTo/d;->l()LTo/c;

    move-result-object v3

    goto :goto_34

    :cond_33
    move-object v3, v2

    :goto_34
    sget-object v4, Lro/n;->f:LTo/c;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3d

    goto :goto_3e

    :cond_3d
    move-object v0, v2

    :goto_3e
    if-nez v0, :cond_41

    goto :goto_7c

    :cond_41
    invoke-interface {p0}, Luo/v;->H0()Luo/v$a;

    move-result-object v2

    invoke-interface {p0}, Luo/a;->e()Ljava/util/List;

    move-result-object p0

    invoke-static {p0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lkotlin/collections/q;->p(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    invoke-interface {v2, p0}, Luo/v$a;->c(Ljava/util/List;)Luo/v$a;

    move-result-object p0

    invoke-interface {v0}, Luo/a0;->getType()Lkp/E;

    move-result-object v0

    invoke-virtual {v0}, Lkp/E;->L0()Ljava/util/List;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkp/k0;

    invoke-interface {v0}, Lkp/k0;->getType()Lkp/E;

    move-result-object v0

    invoke-interface {p0, v0}, Luo/v$a;->m(Lkp/E;)Luo/v$a;

    move-result-object p0

    invoke-interface {p0}, Luo/v$a;->build()Luo/v;

    move-result-object p0

    check-cast p0, Luo/Q;

    move-object v0, p0

    check-cast v0, Lxo/P;

    if-nez v0, :cond_77

    goto :goto_7b

    :cond_77
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lxo/w;->d1(Z)V

    :goto_7b
    return-object p0

    :cond_7c
    :goto_7c
    return-object v2
.end method

.method private final S(Luo/L;Leo/l;)Z
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Luo/L;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "+",
            "Ljava/util/Collection<",
            "+",
            "Luo/Q;",
            ">;>;)Z"
        }
    .end annotation

    invoke-static {p1}, Landroidx/core/util/g;->k(Luo/L;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    return v1

    :cond_8
    invoke-direct {p0, p1, p2}, LHo/k;->W(Luo/L;Leo/l;)Luo/Q;

    move-result-object v0

    invoke-static {p1, p2}, LHo/k;->X(Luo/L;Leo/l;)Luo/Q;

    move-result-object p2

    if-nez v0, :cond_13

    return v1

    :cond_13
    invoke-interface {p1}, Luo/c0;->N()Z

    move-result p1

    const/4 v2, 0x1

    if-nez p1, :cond_1b

    return v2

    :cond_1b
    if-eqz p2, :cond_28

    invoke-interface {p2}, Luo/z;->s()Luo/A;

    move-result-object p1

    invoke-interface {v0}, Luo/z;->s()Luo/A;

    move-result-object p2

    if-ne p1, p2, :cond_28

    const/4 v1, 0x1

    :cond_28
    return v1
.end method

.method private static T(Luo/a;Luo/a;)Z
    .registers 5

    sget-object v0, LWo/o;->f:LWo/o;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p0, v1}, LWo/o;->p(Luo/a;Luo/a;Z)LWo/o$c;

    move-result-object v0

    invoke-virtual {v0}, LWo/o$c;->c()LWo/o$c$a;

    move-result-object v0

    const-string v2, "DEFAULT.isOverridableByW\u2026iptor, this, true).result"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, LWo/o$c$a;->OVERRIDABLE:LWo/o$c$a;

    if-ne v0, v2, :cond_1b

    invoke-static {p1, p0}, LDo/v$a;->a(Luo/a;Luo/a;)Z

    move-result p0

    if-nez p0, :cond_1b

    goto :goto_1c

    :cond_1b
    const/4 v1, 0x0

    :goto_1c
    return v1
.end method

.method private static U(Luo/Q;Luo/Q;)Z
    .registers 4

    sget v0, LDo/g;->m:I

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Luo/k;->getName()LTo/f;

    move-result-object v0

    invoke-virtual {v0}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    const-string v1, "removeAt"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2d

    invoke-static {p0}, LMo/A;->b(Luo/a;)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, LDo/L;->f()LDo/L$a$a;

    move-result-object v1

    invoke-virtual {v1}, LDo/L$a$a;->b()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2d

    invoke-interface {p1}, Luo/v;->a()Luo/v;

    move-result-object p1

    :cond_2d
    const-string v0, "if (superDescriptor.isRe\u2026iginal else subDescriptor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1, p0}, LHo/k;->T(Luo/a;Luo/a;)Z

    move-result p0

    return p0
.end method

.method private static V(Luo/L;Ljava/lang/String;Leo/l;)Luo/Q;
    .registers 7

    invoke-static {p1}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object p1

    invoke-interface {p2, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_e
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v0, 0x0

    if-eqz p2, :cond_3c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Luo/Q;

    invoke-interface {p2}, Luo/a;->e()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-eqz v1, :cond_26

    goto :goto_3a

    :cond_26
    sget-object v1, Llp/d;->a:Llp/m;

    invoke-interface {p2}, Luo/a;->getReturnType()Lkp/E;

    move-result-object v2

    if-nez v2, :cond_2f

    goto :goto_3a

    :cond_2f
    invoke-interface {p0}, Luo/a0;->getType()Lkp/E;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Llp/m;->d(Lkp/E;Lkp/E;)Z

    move-result v1

    if-eqz v1, :cond_3a

    move-object v0, p2

    :cond_3a
    :goto_3a
    if-eqz v0, :cond_e

    :cond_3c
    return-object v0
.end method

.method private final W(Luo/L;Leo/l;)Luo/Q;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Luo/L;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "+",
            "Ljava/util/Collection<",
            "+",
            "Luo/Q;",
            ">;>;)",
            "Luo/Q;"
        }
    .end annotation

    invoke-interface {p1}, Luo/L;->l()Lxo/M;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_e

    invoke-static {v0}, LDo/K;->b(Luo/b;)Luo/b;

    move-result-object v0

    check-cast v0, Luo/M;

    goto :goto_f

    :cond_e
    move-object v0, v1

    :goto_f
    if-eqz v0, :cond_15

    invoke-static {v0}, LDo/l;->a(Luo/M;)Ljava/lang/String;

    move-result-object v1

    :cond_15
    if-eqz v1, :cond_24

    iget-object v2, p0, LHo/k;->n:Luo/e;

    invoke-static {v2, v0}, LDo/K;->d(Luo/e;Luo/b;)Z

    move-result v0

    if-nez v0, :cond_24

    invoke-static {p1, v1, p2}, LHo/k;->V(Luo/L;Ljava/lang/String;Leo/l;)Luo/Q;

    move-result-object p1

    return-object p1

    :cond_24
    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v0

    invoke-virtual {v0}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    const-string v1, "name.asString()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LDo/D;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0, p2}, LHo/k;->V(Luo/L;Ljava/lang/String;Leo/l;)Luo/Q;

    move-result-object p1

    return-object p1
.end method

.method private static X(Luo/L;Leo/l;)Luo/Q;
    .registers 7

    invoke-interface {p0}, Luo/k;->getName()LTo/f;

    move-result-object v0

    invoke-virtual {v0}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    const-string v1, "name.asString()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LDo/D;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v0

    invoke-interface {p1, v0}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_68

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Luo/Q;

    invoke-interface {v0}, Luo/a;->e()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x1

    if-eq v2, v3, :cond_38

    goto :goto_66

    :cond_38
    invoke-interface {v0}, Luo/a;->getReturnType()Lkp/E;

    move-result-object v2

    if-nez v2, :cond_3f

    goto :goto_66

    :cond_3f
    invoke-static {v2}, Lro/j;->n0(Lkp/E;)Z

    move-result v2

    if-nez v2, :cond_46

    goto :goto_66

    :cond_46
    sget-object v2, Llp/d;->a:Llp/m;

    invoke-interface {v0}, Luo/a;->e()Ljava/util/List;

    move-result-object v3

    const-string v4, "descriptor.valueParameters"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Luo/b0;

    invoke-interface {v3}, Luo/a0;->getType()Lkp/E;

    move-result-object v3

    invoke-interface {p0}, Luo/a0;->getType()Lkp/E;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Llp/m;->b(Lkp/E;Lkp/E;)Z

    move-result v2

    if-eqz v2, :cond_66

    move-object v1, v0

    :cond_66
    :goto_66
    if-eqz v1, :cond_1f

    :cond_68
    return-object v1
.end method

.method private final Z(LTo/f;)Ljava/util/LinkedHashSet;
    .registers 6

    invoke-direct {p0}, LHo/k;->P()Ljava/util/Collection;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkp/E;

    invoke-virtual {v2}, Lkp/E;->p()Ldp/i;

    move-result-object v2

    sget-object v3, LCo/c;->WHEN_GET_SUPER_MEMBERS:LCo/c;

    invoke-interface {v2, p1, v3}, Ldp/i;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2, v1}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_f

    :cond_2b
    return-object v1
.end method

.method private final b0(LTo/f;)Ljava/util/Set;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTo/f;",
            ")",
            "Ljava/util/Set<",
            "Luo/L;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, LHo/k;->P()Ljava/util/Collection;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_48

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkp/E;

    invoke-virtual {v2}, Lkp/E;->p()Ldp/i;

    move-result-object v2

    sget-object v3, LCo/c;->WHEN_GET_SUPER_MEMBERS:LCo/c;

    invoke-interface {v2, p1, v3}, Ldp/i;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    new-instance v3, Ljava/util/ArrayList;

    invoke-static {v2}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_34
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_44

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Luo/L;

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_34

    :cond_44
    invoke-static {v3, v1}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_f

    :cond_48
    invoke-static {v1}, Lkotlin/collections/q;->c0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    return-object p1
.end method

.method private static c0(Luo/Q;Luo/v;)Z
    .registers 6

    const/4 v0, 0x2

    invoke-static {p0, v0}, LMo/A;->a(Luo/v;I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1}, Luo/v;->a()Luo/v;

    move-result-object v2

    const-string v3, "builtinWithErasedParameters.original"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2, v0}, LMo/A;->a(Luo/v;I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-static {p0, p1}, LHo/k;->T(Luo/a;Luo/a;)Z

    move-result p0

    if-nez p0, :cond_20

    const/4 p0, 0x1

    goto :goto_21

    :cond_20
    const/4 p0, 0x0

    :goto_21
    return p0
.end method

.method private final d0(Luo/Q;)Z
    .registers 10

    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v0

    const-string v1, "function.name"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LDo/I;->a(LTo/f;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    instance-of v1, v0, Ljava/util/Collection;

    const/4 v2, 0x0

    if-eqz v1, :cond_1e

    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1e

    goto :goto_7b

    :cond_1e
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_22
    :goto_22
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LTo/f;

    invoke-direct {p0, v1}, LHo/k;->b0(LTo/f;)Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    instance-of v3, v1, Ljava/util/Collection;

    if-eqz v3, :cond_42

    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_42

    goto :goto_22

    :cond_42
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_46
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_22

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Luo/L;

    new-instance v4, LHo/k$d;

    invoke-direct {v4, p1, p0}, LHo/k$d;-><init>(Luo/Q;LHo/k;)V

    invoke-direct {p0, v3, v4}, LHo/k;->S(Luo/L;Leo/l;)Z

    move-result v4

    if-eqz v4, :cond_46

    invoke-interface {v3}, Luo/c0;->N()Z

    move-result v3

    if-nez v3, :cond_7a

    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v3

    invoke-virtual {v3}, LTo/f;->b()Ljava/lang/String;

    move-result-object v3

    const-string v4, "function.name.asString()"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v4, LDo/D;->a:LTo/c;

    const-string v4, "set"

    invoke-static {v3, v4, v2}, Lvp/k;->N(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_46

    :cond_7a
    return v2

    :cond_7b
    :goto_7b
    sget-object v0, LDo/L;->a:LDo/L$a;

    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v0

    const-string v1, "name"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, LDo/L;->d()Ljava/util/LinkedHashMap;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LTo/f;

    if-nez v0, :cond_93

    goto :goto_f8

    :cond_93
    invoke-direct {p0, v0}, LHo/k;->Z(LTo/f;)Ljava/util/LinkedHashSet;

    move-result-object v3

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_a0
    :goto_a0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_bc

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    move-object v6, v5

    check-cast v6, Luo/Q;

    const-string v7, "<this>"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6}, LDo/K;->b(Luo/b;)Luo/b;

    move-result-object v6

    if-eqz v6, :cond_a0

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_a0

    :cond_bc
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_c3

    goto :goto_f8

    :cond_c3
    invoke-interface {p1}, Luo/v;->H0()Luo/v$a;

    move-result-object v3

    invoke-interface {v3, v0}, Luo/v$a;->e(LTo/f;)Luo/v$a;

    invoke-interface {v3}, Luo/v$a;->r()Luo/v$a;

    invoke-interface {v3}, Luo/v$a;->l()Luo/v$a;

    invoke-interface {v3}, Luo/v$a;->build()Luo/v;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    check-cast v0, Luo/Q;

    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_e0

    goto :goto_f8

    :cond_e0
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_e4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_f8

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Luo/Q;

    invoke-static {v4, v0}, LHo/k;->U(Luo/Q;Luo/Q;)Z

    move-result v4

    if-eqz v4, :cond_e4

    goto/16 :goto_187

    :cond_f8
    :goto_f8
    sget v0, LDo/h;->m:I

    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, LDo/h;->j(LTo/f;)Z

    move-result v0

    if-nez v0, :cond_108

    goto :goto_150

    :cond_108
    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0}, LHo/k;->Z(LTo/f;)Ljava/util/LinkedHashSet;

    move-result-object v0

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_11c
    :goto_11c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_132

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Luo/Q;

    invoke-static {v4}, LDo/h;->i(Luo/v;)Luo/v;

    move-result-object v4

    if-eqz v4, :cond_11c

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_11c

    :cond_132
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_139

    goto :goto_150

    :cond_139
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_13d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_150

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Luo/v;

    invoke-static {p1, v3}, LHo/k;->c0(Luo/Q;Luo/v;)Z

    move-result v3

    if-eqz v3, :cond_13d

    goto :goto_187

    :cond_150
    :goto_150
    invoke-static {p1}, LHo/k;->R(Luo/Q;)Luo/Q;

    move-result-object v0

    if-nez v0, :cond_157

    goto :goto_186

    :cond_157
    invoke-interface {p1}, Luo/k;->getName()LTo/f;

    move-result-object p1

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, LHo/k;->Z(LTo/f;)Ljava/util/LinkedHashSet;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_169

    goto :goto_186

    :cond_169
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_16d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_186

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Luo/Q;

    invoke-interface {v1}, Luo/v;->isSuspend()Z

    move-result v3

    if-eqz v3, :cond_16d

    invoke-static {v0, v1}, LHo/k;->T(Luo/a;Luo/a;)Z

    move-result v1

    if-eqz v1, :cond_16d

    goto :goto_187

    :cond_186
    :goto_186
    const/4 v2, 0x1

    :goto_187
    return v2
.end method


# virtual methods
.method public final Y()Ljp/j;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljp/j<",
            "Ljava/util/List<",
            "Luo/d;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, LHo/k;->q:Ljp/j;

    return-object v0
.end method

.method protected final a0()Luo/e;
    .registers 2

    iget-object v0, p0, LHo/k;->n:Luo/e;

    return-object v0
.end method

.method public final b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2}, LHo/k;->e0(LTo/f;LCo/a;)V

    invoke-super {p0, p1, p2}, LHo/o;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2}, LHo/k;->e0(LTo/f;LCo/a;)V

    invoke-super {p0, p1, p2}, LHo/o;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final e0(LTo/f;LCo/a;)V
    .registers 5

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->l()LCo/b;

    move-result-object v0

    iget-object v1, p0, LHo/k;->n:Luo/e;

    check-cast p2, LCo/c;

    invoke-static {v0, p2, v1, p1}, LBo/a;->a(LCo/b;LCo/c;Luo/e;LTo/f;)V

    return-void
.end method

.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2}, LHo/k;->e0(LTo/f;LCo/a;)V

    invoke-virtual {p0}, LHo/o;->w()LHo/o;

    move-result-object p2

    check-cast p2, LHo/k;

    if-eqz p2, :cond_22

    iget-object p2, p2, LHo/k;->u:Ljp/i;

    if-eqz p2, :cond_22

    invoke-interface {p2, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Luo/e;

    if-eqz p2, :cond_22

    goto :goto_2b

    :cond_22
    iget-object p2, p0, LHo/k;->u:Ljp/i;

    invoke-interface {p2, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    move-object p2, p1

    check-cast p2, Luo/h;

    :goto_2b
    return-object p2
.end method

.method protected final k(Ldp/d;Leo/l;)Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    const-string p2, "kindFilter"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LHo/k;->r:Ljp/j;

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Set;

    iget-object p2, p0, LHo/k;->t:Ljp/j;

    invoke-interface {p2}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/Map;

    invoke-interface {p2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    invoke-static {p1, p2}, Lkotlin/collections/O;->c(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    move-result-object p1

    return-object p1
.end method

.method public final l(Ldp/d;Leo/l;)Ljava/util/Set;
    .registers 7

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/k;->n:Luo/e;

    invoke-interface {v0}, Luo/h;->j()Lkp/e0;

    move-result-object v1

    invoke-interface {v1}, Lkp/e0;->l()Ljava/util/Collection;

    move-result-object v1

    const-string v2, "ownerDescriptor.typeConstructor.supertypes"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    new-instance v2, Ljava/util/LinkedHashSet;

    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_39

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lkp/E;

    invoke-virtual {v3}, Lkp/E;->p()Ldp/i;

    move-result-object v3

    invoke-interface {v3}, Ldp/i;->a()Ljava/util/Set;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v3, v2}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_1f

    :cond_39
    invoke-virtual {p0}, LHo/o;->u()Ljp/j;

    move-result-object v1

    invoke-interface {v1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LHo/b;

    invoke-interface {v1}, LHo/b;->a()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v2, v1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p0}, LHo/o;->u()Ljp/j;

    move-result-object v1

    invoke-interface {v1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LHo/b;

    invoke-interface {v1}, LHo/b;->d()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v2, v1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p0, p1, p2}, LHo/k;->k(Ldp/d;Leo/l;)Ljava/util/Set;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object p1

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object p2

    invoke-virtual {p2}, LGo/g;->a()LGo/c;

    move-result-object p2

    invoke-virtual {p2}, LGo/c;->w()Lbp/d;

    move-result-object p2

    invoke-interface {p2, p1, v0}, Lbp/d;->d(LGo/g;Luo/e;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    return-object v2
.end method

.method protected final m(Ljava/util/ArrayList;LTo/f;)V
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v3, "name"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, v0, LHo/k;->o:LKo/g;

    invoke-interface {v3}, LKo/g;->p()Z

    move-result v3

    iget-object v4, v0, LHo/k;->n:Luo/e;

    if-eqz v3, :cond_c4

    invoke-virtual/range {p0 .. p0}, LHo/o;->u()Ljp/j;

    move-result-object v3

    invoke-interface {v3}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LHo/b;

    invoke-interface {v3, v2}, LHo/b;->b(LTo/f;)LKo/v;

    move-result-object v3

    if-eqz v3, :cond_c4

    invoke-interface/range {p1 .. p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2c

    goto :goto_48

    :cond_2c
    invoke-interface/range {p1 .. p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_30
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Luo/Q;

    invoke-interface {v5}, Luo/a;->e()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_30

    goto/16 :goto_c4

    :cond_48
    :goto_48
    invoke-virtual/range {p0 .. p0}, LHo/o;->u()Ljp/j;

    move-result-object v3

    invoke-interface {v3}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LHo/b;

    invoke-interface {v3, v2}, LHo/b;->b(LTo/f;)LKo/v;

    move-result-object v3

    invoke-static {v3}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v5

    invoke-static {v5, v3}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object v5

    invoke-interface {v3}, LKo/s;->getName()LTo/f;

    move-result-object v6

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v7

    invoke-virtual {v7}, LGo/g;->a()LGo/c;

    move-result-object v7

    invoke-virtual {v7}, LGo/c;->t()LJo/b;

    move-result-object v7

    invoke-interface {v7, v3}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v7

    const/4 v8, 0x1

    invoke-static {v4, v5, v6, v7, v8}, LFo/e;->l1(Luo/k;LGo/e;LTo/f;LJo/a;Z)LFo/e;

    move-result-object v5

    sget-object v6, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v7, 0x0

    const/4 v9, 0x6

    const/4 v15, 0x0

    invoke-static {v6, v15, v15, v7, v9}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v6

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v7

    invoke-virtual {v7}, LGo/g;->g()LIo/d;

    move-result-object v7

    invoke-interface {v3}, LKo/v;->getType()LKo/w;

    move-result-object v3

    invoke-virtual {v7, v3, v6}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v3

    invoke-static {v4}, LWo/i;->k(Luo/e;)Luo/O;

    move-result-object v11

    sget-object v14, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    sget-object v6, Luo/A;->Companion:Luo/A$a;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v15, v15, v8}, Luo/A$a;->a(ZZZ)Luo/A;

    move-result-object v16

    sget-object v17, Luo/q;->e:Luo/r;

    const/16 v18, 0x0

    const/4 v10, 0x0

    move-object v9, v5

    move-object v12, v14

    move-object v13, v14

    const/4 v6, 0x0

    move-object v15, v3

    invoke-virtual/range {v9 .. v18}, LFo/e;->k1(Lxo/O;Luo/O;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkp/E;Luo/A;Luo/r;Ljava/util/Map;)Lxo/P;

    invoke-virtual {v5, v6, v6}, LFo/e;->m1(ZZ)V

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v3

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v3

    invoke-virtual {v3}, LGo/c;->h()LEo/i;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_c4
    :goto_c4
    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v5

    invoke-virtual {v5}, LGo/g;->a()LGo/c;

    move-result-object v5

    invoke-virtual {v5}, LGo/c;->w()Lbp/d;

    move-result-object v5

    invoke-interface {v5, v3, v4, v2, v1}, Lbp/d;->b(LGo/g;Luo/e;LTo/f;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final n()LHo/b;
    .registers 4

    new-instance v0, LHo/a;

    iget-object v1, p0, LHo/k;->o:LKo/g;

    sget-object v2, LHo/f;->a:LHo/f;

    invoke-direct {v0, v1, v2}, LHo/a;-><init>(LKo/g;Leo/l;)V

    return-object v0
.end method

.method protected final p(Ljava/util/LinkedHashSet;LTo/f;)V
    .registers 13

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2}, LHo/k;->Z(LTo/f;)Ljava/util/LinkedHashSet;

    move-result-object v6

    sget-object v0, LDo/L;->a:LDo/L$a;

    invoke-static {}, LDo/L;->e()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_60

    sget v0, LDo/h;->m:I

    invoke-static {p2}, LDo/h;->j(LTo/f;)Z

    move-result v0

    if-nez v0, :cond_60

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_24

    goto :goto_3b

    :cond_24
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_28
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Luo/v;

    invoke-interface {v1}, Luo/v;->isSuspend()Z

    move-result v1

    if-eqz v1, :cond_28

    goto :goto_60

    :cond_3b
    :goto_3b
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_44
    :goto_44
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Luo/Q;

    invoke-direct {p0, v3}, LHo/k;->d0(Luo/Q;)Z

    move-result v3

    if-eqz v3, :cond_44

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_44

    :cond_5b
    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, v0, v1}, LHo/k;->M(Ljava/util/LinkedHashSet;LTo/f;Ljava/util/ArrayList;Z)V

    return-void

    :cond_60
    :goto_60
    new-instance v7, Ltp/d;

    invoke-direct {v7}, Ltp/d;-><init>()V

    sget-object v2, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    sget-object v4, Lgp/u;->a:Lgp/u;

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->k()Llp/l;

    move-result-object v0

    invoke-interface {v0}, Llp/l;->a()LWo/o;

    move-result-object v5

    iget-object v3, p0, LHo/k;->n:Luo/e;

    move-object v0, p2

    move-object v1, v6

    invoke-static/range {v0 .. v5}, LEo/b;->d(LTo/f;Ljava/util/AbstractCollection;Ljava/util/Collection;Luo/e;Lgp/u;LWo/o;)Ljava/util/LinkedHashSet;

    move-result-object v8

    new-instance v5, LHo/g;

    const/4 v9, 0x1

    invoke-direct {v5, v9, p0}, Lkotlin/jvm/internal/l;-><init>(ILjava/lang/Object;)V

    move-object v0, p0

    move-object v1, p2

    move-object v2, p1

    move-object v3, v8

    move-object v4, p1

    invoke-direct/range {v0 .. v5}, LHo/k;->N(LTo/f;Ljava/util/LinkedHashSet;Ljava/util/LinkedHashSet;Ljava/util/AbstractSet;Leo/l;)V

    new-instance v5, LHo/h;

    invoke-direct {v5, v9, p0}, Lkotlin/jvm/internal/l;-><init>(ILjava/lang/Object;)V

    move-object v0, p0

    move-object v1, p2

    move-object v2, p1

    move-object v3, v8

    move-object v4, v7

    invoke-direct/range {v0 .. v5}, LHo/k;->N(LTo/f;Ljava/util/LinkedHashSet;Ljava/util/LinkedHashSet;Ljava/util/AbstractSet;Leo/l;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_a5
    :goto_a5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_bc

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Luo/Q;

    invoke-direct {p0, v3}, LHo/k;->d0(Luo/Q;)Z

    move-result v3

    if-eqz v3, :cond_a5

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_a5

    :cond_bc
    invoke-static {v7, v0}, Lkotlin/collections/q;->L(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-direct {p0, p1, p2, v0, v9}, LHo/k;->M(Ljava/util/LinkedHashSet;LTo/f;Ljava/util/ArrayList;Z)V

    return-void
.end method

.method protected final q(Ljava/util/ArrayList;LTo/f;)V
    .registers 25

    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move-object/from16 v1, p2

    const-string v2, "name"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v0, LHo/k;->o:LKo/g;

    invoke-interface {v2}, LKo/g;->n()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_91

    invoke-virtual/range {p0 .. p0}, LHo/o;->u()Ljp/j;

    move-result-object v2

    invoke-interface {v2}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LHo/b;

    invoke-interface {v2, v1}, LHo/b;->c(LTo/f;)Ljava/util/Collection;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/q;->P(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LKo/q;

    if-nez v2, :cond_2d

    goto :goto_91

    :cond_2d
    sget-object v10, Luo/A;->FINAL:Luo/A;

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v4

    invoke-static {v4, v2}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object v9

    invoke-interface {v2}, LKo/r;->getVisibility()Luo/f0;

    move-result-object v4

    const-string v5, "<this>"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, LDo/u;->e(Luo/f0;)Luo/r;

    move-result-object v11

    invoke-interface {v2}, LKo/s;->getName()LTo/f;

    move-result-object v13

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v4

    invoke-virtual {v4}, LGo/g;->a()LGo/c;

    move-result-object v4

    invoke-virtual {v4}, LGo/c;->t()LJo/b;

    move-result-object v4

    invoke-interface {v4, v2}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v14

    iget-object v8, v0, LHo/k;->n:Luo/e;

    const/4 v12, 0x0

    const/4 v15, 0x0

    invoke-static/range {v8 .. v15}, LFo/f;->X0(Luo/k;LGo/e;Luo/A;Luo/r;ZLTo/f;LJo/a;Z)LFo/f;

    move-result-object v4

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object v5

    invoke-static {v4, v5}, LWo/h;->d(Luo/L;Lvo/h;)Lxo/M;

    move-result-object v5

    invoke-virtual {v4, v5, v3, v3, v3}, Lxo/L;->R0(Lxo/M;Lxo/N;Luo/t;Luo/t;)V

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v6

    const/4 v8, 0x0

    invoke-static {v6, v4, v2, v8}, LGo/b;->b(LGo/g;Lxo/p;LKo/y;I)LGo/g;

    move-result-object v6

    invoke-static {v2, v6}, LHo/o;->o(LKo/q;LGo/g;)Lkp/E;

    move-result-object v2

    sget-object v21, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    iget-object v6, v0, LHo/k;->n:Luo/e;

    invoke-static {v6}, LWo/i;->k(Luo/e;)Luo/O;

    move-result-object v19

    const/16 v20, 0x0

    move-object/from16 v16, v4

    move-object/from16 v17, v2

    move-object/from16 v18, v21

    invoke-virtual/range {v16 .. v21}, Lxo/L;->V0(Lkp/E;Ljava/util/List;Luo/O;Lxo/O;Ljava/util/List;)V

    invoke-virtual {v5, v2}, Lxo/M;->Q0(Lkp/E;)V

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_91
    :goto_91
    invoke-direct {v0, v1}, LHo/k;->b0(LTo/f;)Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_9c

    return-void

    :cond_9c
    new-instance v4, Ltp/d;

    invoke-direct {v4}, Ltp/d;-><init>()V

    new-instance v5, Ltp/d;

    invoke-direct {v5}, Ltp/d;-><init>()V

    new-instance v6, LHo/i;

    invoke-direct {v6, v0}, LHo/i;-><init>(LHo/k;)V

    invoke-direct {v0, v2, v7, v4, v6}, LHo/k;->O(Ljava/util/Set;Ljava/util/AbstractCollection;Ltp/d;Leo/l;)V

    invoke-static {v2, v4}, Lkotlin/collections/O;->b(Ljava/util/Set;Ltp/d;)Ljava/util/Set;

    move-result-object v4

    new-instance v6, LHo/j;

    invoke-direct {v6, v0}, LHo/j;-><init>(LHo/k;)V

    invoke-direct {v0, v4, v5, v3, v6}, LHo/k;->O(Ljava/util/Set;Ljava/util/AbstractCollection;Ltp/d;Leo/l;)V

    invoke-static {v2, v5}, Lkotlin/collections/O;->c(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v3

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v3

    invoke-virtual {v3}, LGo/c;->c()Lgp/u;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, LHo/o;->t()LGo/g;

    move-result-object v3

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v3

    invoke-virtual {v3}, LGo/c;->k()Llp/l;

    move-result-object v3

    invoke-interface {v3}, Llp/l;->a()LWo/o;

    move-result-object v6

    iget-object v4, v0, LHo/k;->n:Luo/e;

    move-object/from16 v1, p2

    move-object/from16 v3, p1

    invoke-static/range {v1 .. v6}, LEo/b;->d(LTo/f;Ljava/util/AbstractCollection;Ljava/util/Collection;Luo/e;Lgp/u;LWo/o;)Ljava/util/LinkedHashSet;

    move-result-object v1

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    return-void
.end method

.method protected final r(Ldp/d;)Ljava/util/Set;
    .registers 4

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LHo/k;->o:LKo/g;

    invoke-interface {p1}, LKo/g;->n()Z

    move-result p1

    if-eqz p1, :cond_12

    invoke-virtual {p0}, LHo/o;->a()Ljava/util/Set;

    move-result-object p1

    return-object p1

    :cond_12
    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-virtual {p0}, LHo/o;->u()Ljp/j;

    move-result-object v0

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LHo/b;

    invoke-interface {v0}, LHo/b;->e()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-direct {p1, v0}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    iget-object v0, p0, LHo/k;->n:Luo/e;

    invoke-interface {v0}, Luo/h;->j()Lkp/e0;

    move-result-object v0

    invoke-interface {v0}, Lkp/e0;->l()Ljava/util/Collection;

    move-result-object v0

    const-string v1, "ownerDescriptor.typeConstructor.supertypes"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_56

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkp/E;

    invoke-virtual {v1}, Lkp/E;->p()Ldp/i;

    move-result-object v1

    invoke-interface {v1}, Ldp/i;->d()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1, p1}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_3c

    :cond_56
    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Lazy Java member scope for "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LHo/k;->o:LKo/g;

    invoke-interface {v1}, LKo/g;->c()LTo/c;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method protected final v()Luo/O;
    .registers 2

    iget-object v0, p0, LHo/k;->n:Luo/e;

    invoke-static {v0}, LWo/i;->k(Luo/e;)Luo/O;

    move-result-object v0

    return-object v0
.end method

.method public final x()Luo/k;
    .registers 2

    iget-object v0, p0, LHo/k;->n:Luo/e;

    return-object v0
.end method

.method protected final y(LFo/e;)Z
    .registers 3

    iget-object v0, p0, LHo/k;->o:LKo/g;

    invoke-interface {v0}, LKo/g;->n()Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 p1, 0x0

    return p1

    :cond_a
    invoke-direct {p0, p1}, LHo/k;->d0(Luo/Q;)Z

    move-result p1

    return p1
.end method

.method protected final z(LKo/q;Ljava/util/ArrayList;Lkp/E;Ljava/util/List;)LHo/o$a;
    .registers 12

    const-string v0, "method"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "valueParameters"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->s()LEo/l;

    move-result-object v1

    iget-object v3, p0, LHo/k;->n:Luo/e;

    move-object v2, p1

    move-object v4, p3

    move-object v5, p4

    move-object v6, p2

    invoke-interface/range {v1 .. v6}, LEo/l;->b(LKo/q;Luo/e;Lkp/E;Ljava/util/List;Ljava/util/ArrayList;)LEo/l$b;

    move-result-object p1

    new-instance p2, LHo/o$a;

    invoke-virtual {p1}, LEo/l$b;->d()Lkp/E;

    move-result-object v4

    const-string p3, "propagated.returnType"

    invoke-static {v4, p3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LEo/l$b;->c()Lkp/E;

    move-result-object v5

    invoke-virtual {p1}, LEo/l$b;->f()Ljava/util/List;

    move-result-object v1

    const-string p3, "propagated.valueParameters"

    invoke-static {v1, p3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LEo/l$b;->e()Ljava/util/List;

    move-result-object v2

    const-string p3, "propagated.typeParameters"

    invoke-static {v2, p3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LEo/l$b;->b()Ljava/util/List;

    move-result-object v3

    const-string p1, "propagated.errors"

    invoke-static {v3, p1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x0

    move-object v0, p2

    invoke-direct/range {v0 .. v6}, LHo/o$a;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkp/E;Lkp/E;Z)V

    return-object p2
.end method
