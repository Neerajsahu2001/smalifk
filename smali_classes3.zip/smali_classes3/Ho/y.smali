.class public final LHo/y;
.super LHo/z;
.source "LazyJavaStaticClassScope.kt"


# static fields
.field public static final synthetic p:I


# instance fields
.field private final n:LKo/g;

.field private final o:LFo/c;


# direct methods
.method public constructor <init>(LGo/g;LKo/g;LFo/c;)V
    .registers 5

    const-string v0, "jClass"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ownerDescriptor"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, LHo/o;-><init>(LGo/g;LHo/o;)V

    iput-object p2, p0, LHo/y;->n:LKo/g;

    iput-object p3, p0, LHo/y;->o:LFo/c;

    return-void
.end method

.method private static C(Luo/L;)Luo/L;
    .registers 4

    invoke-interface {p0}, Luo/b;->h()Luo/b$a;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Luo/b$a;->FAKE_OVERRIDE:Luo/b$a;

    if-eq v0, v1, :cond_c

    return-object p0

    :cond_c
    invoke-interface {p0}, Luo/b;->o()Ljava/util/Collection;

    move-result-object p0

    const-string v0, "this.overriddenDescriptors"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p0}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_24
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3d

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Luo/L;

    const-string v2, "it"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, LHo/y;->C(Luo/L;)Luo/L;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_24

    :cond_3d
    invoke-static {v0}, Lkotlin/collections/q;->n(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Luo/L;

    return-object p0
.end method


# virtual methods
.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "location"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method protected final k(Ldp/d;Leo/l;)Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    const-string p2, "kindFilter"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object p1
.end method

.method protected final l(Ldp/d;Leo/l;)Ljava/util/Set;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    const-string p2, "kindFilter"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->u()Ljp/j;

    move-result-object p1

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LHo/b;

    invoke-interface {p1}, LHo/b;->a()Ljava/util/Set;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    invoke-static {p1}, Lkotlin/collections/q;->b0(Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    move-result-object p1

    iget-object p2, p0, LHo/y;->o:LFo/c;

    invoke-static {p2}, Landroidx/lifecycle/LifecycleOwnerKt;->d(Luo/e;)LHo/y;

    move-result-object v0

    if-eqz v0, :cond_26

    invoke-virtual {v0}, LHo/o;->a()Ljava/util/Set;

    move-result-object v0

    goto :goto_27

    :cond_26
    const/4 v0, 0x0

    :goto_27
    if-nez v0, :cond_2b

    sget-object v0, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    :cond_2b
    check-cast v0, Ljava/util/Collection;

    invoke-interface {p1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, LHo/y;->n:LKo/g;

    invoke-interface {v0}, LKo/g;->q()Z

    move-result v0

    if-eqz v0, :cond_4e

    const/4 v0, 0x2

    new-array v0, v0, [LTo/f;

    sget-object v1, Lro/n;->c:LTo/f;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lro/n;->a:LTo/f;

    const/4 v2, 0x1

    aput-object v1, v0, v2

    invoke-static {v0}, Lkotlin/collections/q;->E([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {p1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    :cond_4e
    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->w()Lbp/d;

    move-result-object v1

    invoke-interface {v1, v0, p2}, Lbp/d;->f(LGo/g;LFo/c;)Ljava/util/ArrayList;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    return-object p1
.end method

.method protected final m(Ljava/util/ArrayList;LTo/f;)V
    .registers 6

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->w()Lbp/d;

    move-result-object v1

    iget-object v2, p0, LHo/y;->o:LFo/c;

    invoke-interface {v1, v0, v2, p2, p1}, Lbp/d;->a(LGo/g;LFo/c;LTo/f;Ljava/util/ArrayList;)V

    return-void
.end method

.method public final n()LHo/b;
    .registers 4

    new-instance v0, LHo/a;

    iget-object v1, p0, LHo/y;->n:LKo/g;

    sget-object v2, LHo/t;->a:LHo/t;

    invoke-direct {v0, v1, v2}, LHo/a;-><init>(LKo/g;Leo/l;)V

    return-object v0
.end method

.method protected final p(Ljava/util/LinkedHashSet;LTo/f;)V
    .registers 11

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/y;->o:LFo/c;

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->d(Luo/e;)LHo/y;

    move-result-object v1

    if-nez v1, :cond_10

    sget-object v1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    goto :goto_1c

    :cond_10
    sget-object v2, LCo/c;->WHEN_GET_SUPER_MEMBERS:LCo/c;

    invoke-virtual {v1, p2, v2}, LHo/o;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/q;->c0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v1

    :goto_1c
    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->c()Lgp/u;

    move-result-object v6

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->k()Llp/l;

    move-result-object v1

    invoke-interface {v1}, Llp/l;->a()LWo/o;

    move-result-object v7

    iget-object v5, p0, LHo/y;->o:LFo/c;

    move-object v2, p2

    move-object v4, p1

    invoke-static/range {v2 .. v7}, LEo/b;->e(LTo/f;Ljava/util/Collection;Ljava/util/AbstractCollection;LFo/c;Lgp/u;LWo/o;)Ljava/util/LinkedHashSet;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, LHo/y;->n:LKo/g;

    invoke-interface {v1}, LKo/g;->q()Z

    move-result v1

    if-eqz v1, :cond_6d

    sget-object v1, Lro/n;->c:LTo/f;

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5e

    invoke-static {v0}, LWo/h;->g(Luo/e;)Lxo/P;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_6d

    :cond_5e
    sget-object v1, Lro/n;->a:LTo/f;

    invoke-static {p2, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_6d

    invoke-static {v0}, LWo/h;->h(Luo/e;)Lxo/P;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_6d
    :goto_6d
    return-void
.end method

.method protected final q(Ljava/util/ArrayList;LTo/f;)V
    .registers 12

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    new-instance v0, LHo/u;

    invoke-direct {v0, p2}, LHo/u;-><init>(LTo/f;)V

    iget-object v6, p0, LHo/y;->o:LFo/c;

    invoke-static {v6}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    sget-object v3, LHo/s;->a:LHo/s;

    new-instance v4, LHo/x;

    invoke-direct {v4, v6, v1, v0}, LHo/x;-><init>(LFo/c;Ljava/util/LinkedHashSet;Leo/l;)V

    invoke-static {v2, v3, v4}, Ltp/a;->b(Ljava/util/Collection;Ltp/a$c;Ltp/a$b;)Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    if-eqz v0, :cond_52

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->c()Lgp/u;

    move-result-object v4

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->k()Llp/l;

    move-result-object v0

    invoke-interface {v0}, Llp/l;->a()LWo/o;

    move-result-object v5

    iget-object v3, p0, LHo/y;->o:LFo/c;

    move-object v0, p2

    move-object v2, p1

    invoke-static/range {v0 .. v5}, LEo/b;->e(LTo/f;Ljava/util/Collection;Ljava/util/AbstractCollection;LFo/c;Lgp/u;LWo/o;)Ljava/util/LinkedHashSet;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto/16 :goto_cb

    :cond_52
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_5b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_80

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Luo/L;

    invoke-static {v3}, LHo/y;->C(Luo/L;)Luo/L;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-nez v4, :cond_7a

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7a
    check-cast v4, Ljava/util/List;

    invoke-interface {v4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_5b

    :cond_80
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_8d
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_c8

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->c()Lgp/u;

    move-result-object v4

    invoke-virtual {p0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->k()Llp/l;

    move-result-object v0

    invoke-interface {v0}, Llp/l;->a()LWo/o;

    move-result-object v5

    iget-object v3, p0, LHo/y;->o:LFo/c;

    move-object v0, p2

    move-object v2, p1

    invoke-static/range {v0 .. v5}, LEo/b;->e(LTo/f;Ljava/util/Collection;Ljava/util/AbstractCollection;LFo/c;Lgp/u;LWo/o;)Ljava/util/LinkedHashSet;

    move-result-object v0

    invoke-static {v0, v7}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_8d

    :cond_c8
    invoke-virtual {p1, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :goto_cb
    iget-object v0, p0, LHo/y;->n:LKo/g;

    invoke-interface {v0}, LKo/g;->q()Z

    move-result v0

    if-eqz v0, :cond_e2

    sget-object v0, Lro/n;->b:LTo/f;

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e2

    invoke-static {v6}, LWo/h;->f(Luo/e;)Lxo/L;

    move-result-object v0

    invoke-static {v0, p1}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    :cond_e2
    return-void
.end method

.method protected final r(Ldp/d;)Ljava/util/Set;
    .registers 7

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LHo/o;->u()Ljp/j;

    move-result-object p1

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LHo/b;

    invoke-interface {p1}, LHo/b;->e()Ljava/util/Set;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    invoke-static {p1}, Lkotlin/collections/q;->b0(Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    move-result-object p1

    sget-object v0, LHo/v;->a:LHo/v;

    iget-object v1, p0, LHo/y;->o:LFo/c;

    invoke-static {v1}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    sget-object v3, LHo/s;->a:LHo/s;

    new-instance v4, LHo/x;

    invoke-direct {v4, v1, p1, v0}, LHo/x;-><init>(LFo/c;Ljava/util/LinkedHashSet;Leo/l;)V

    invoke-static {v2, v3, v4}, Ltp/a;->b(Ljava/util/Collection;Ltp/a$c;Ltp/a$b;)Ljava/lang/Object;

    iget-object v0, p0, LHo/y;->n:LKo/g;

    invoke-interface {v0}, LKo/g;->q()Z

    move-result v0

    if-eqz v0, :cond_3a

    sget-object v0, Lro/n;->b:LTo/f;

    invoke-interface {p1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_3a
    return-object p1
.end method

.method public final x()Luo/k;
    .registers 2

    iget-object v0, p0, LHo/y;->o:LFo/c;

    return-object v0
.end method
