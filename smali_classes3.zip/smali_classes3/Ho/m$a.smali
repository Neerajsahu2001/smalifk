.class final LHo/m$a;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaPackageFragment.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/m;-><init>(LGo/g;LKo/t;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "+",
        "LMo/w;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/m;


# direct methods
.method constructor <init>(LHo/m;)V
    .registers 2

    iput-object p1, p0, LHo/m$a;->a:LHo/m;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 7

    iget-object v0, p0, LHo/m$a;->a:LHo/m;

    invoke-static {v0}, LHo/m;->I0(LHo/m;)LGo/g;

    move-result-object v1

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->o()LMo/B;

    move-result-object v1

    invoke-virtual {v0}, Lxo/I;->c()LTo/c;

    move-result-object v2

    invoke-virtual {v2}, LTo/c;->b()Ljava/lang/String;

    move-result-object v2

    const-string v3, "fqName.asString()"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1, v2}, LMo/B;->a(Ljava/lang/String;)V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    sget-object v2, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    :cond_25
    :goto_25
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Lbp/b;->d(Ljava/lang/String;)Lbp/b;

    move-result-object v4

    invoke-virtual {v4}, Lbp/b;->e()LTo/c;

    move-result-object v4

    invoke-static {v4}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object v4

    invoke-static {v0}, LHo/m;->I0(LHo/m;)LGo/g;

    move-result-object v5

    invoke-virtual {v5}, LGo/g;->a()LGo/c;

    move-result-object v5

    invoke-virtual {v5}, LGo/c;->j()LMo/u;

    move-result-object v5

    invoke-static {v5, v4}, LMo/v;->a(LMo/u;LTo/b;)LMo/w;

    move-result-object v4

    if-eqz v4, :cond_55

    new-instance v5, LUn/j;

    invoke-direct {v5, v3, v4}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_56

    :cond_55
    const/4 v5, 0x0

    :goto_56
    if-eqz v5, :cond_25

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_25

    :cond_5c
    invoke-static {v1}, Lkotlin/collections/J;->k(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method
