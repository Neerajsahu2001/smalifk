.class final LHo/w;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaStaticClassScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Lkp/E;",
        "Luo/e;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LHo/w;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LHo/w;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LHo/w;->a:LHo/w;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkp/E;

    invoke-virtual {p1}, Lkp/E;->N0()Lkp/e0;

    move-result-object p1

    invoke-interface {p1}, Lkp/e0;->n()Luo/h;

    move-result-object p1

    instance-of v0, p1, Luo/e;

    if-eqz v0, :cond_11

    check-cast p1, Luo/e;

    goto :goto_12

    :cond_11
    const/4 p1, 0x0

    :goto_12
    return-object p1
.end method
