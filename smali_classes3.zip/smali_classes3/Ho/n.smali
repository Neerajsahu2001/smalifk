.class public final LHo/n;
.super LHo/z;
.source "LazyJavaPackageScope.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LHo/n$b;,
        LHo/n$a;
    }
.end annotation


# instance fields
.field private final n:LKo/t;

.field private final o:LHo/m;

.field private final p:Ljp/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/k<",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final q:Ljp/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/i<",
            "LHo/n$a;",
            "Luo/e;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LGo/g;LKo/t;LHo/m;)V
    .registers 5

    const-string v0, "jPackage"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ownerDescriptor"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, LHo/o;-><init>(LGo/g;LHo/o;)V

    iput-object p2, p0, LHo/n;->n:LKo/t;

    iput-object p3, p0, LHo/n;->o:LHo/m;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance p3, LHo/n$d;

    invoke-direct {p3, p1, p0}, LHo/n$d;-><init>(LGo/g;LHo/n;)V

    invoke-interface {p2, p3}, Ljp/n;->h(Leo/a;)Ljp/k;

    move-result-object p2

    iput-object p2, p0, LHo/n;->p:Ljp/k;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p2

    new-instance p3, LHo/n$c;

    invoke-direct {p3, p1, p0}, LHo/n$c;-><init>(LGo/g;LHo/n;)V

    invoke-interface {p2, p3}, Ljp/n;->i(Leo/l;)Ljp/i;

    move-result-object p1

    iput-object p1, p0, LHo/n;->q:Ljp/i;

    return-void
.end method

.method private final C(LTo/f;LKo/g;)Luo/e;
    .registers 6

    sget-object v0, LTo/h;->a:LTo/f;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LTo/f;->b()Ljava/lang/String;

    move-result-object v0

    const-string v1, "name.asString()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_42

    invoke-virtual {p1}, LTo/f;->i()Z

    move-result v0

    if-nez v0, :cond_42

    iget-object v0, p0, LHo/n;->p:Ljp/k;

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    if-nez p2, :cond_34

    if-eqz v0, :cond_34

    invoke-virtual {p1}, LTo/f;->b()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_34

    return-object v1

    :cond_34
    new-instance v0, LHo/n$a;

    invoke-direct {v0, p1, p2}, LHo/n$a;-><init>(LTo/f;LKo/g;)V

    iget-object p1, p0, LHo/n;->q:Ljp/i;

    invoke-interface {p1, v0}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Luo/e;

    return-object p1

    :cond_42
    return-object v1
.end method


# virtual methods
.method public final D(LKo/g;)Luo/e;
    .registers 3

    invoke-interface {p1}, LKo/s;->getName()LTo/f;

    move-result-object v0

    invoke-direct {p0, v0, p1}, LHo/n;->C(LTo/f;LKo/g;)Luo/e;

    move-result-object p1

    return-object p1
.end method

.method public final E(LTo/f;LCo/c;)Luo/e;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, LHo/n;->C(LTo/f;LKo/g;)Luo/e;

    move-result-object p1

    return-object p1
.end method

.method protected final F()LHo/m;
    .registers 2

    iget-object v0, p0, LHo/n;->o:LHo/m;

    return-object v0
.end method

.method public final c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "location"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p1
.end method

.method public final e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameFilter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Ldp/d;->c:Ldp/d$a;

    invoke-static {}, Ldp/d;->c()I

    move-result v0

    invoke-static {}, Ldp/d;->e()I

    move-result v1

    or-int/2addr v0, v1

    invoke-virtual {p1, v0}, Ldp/d;->a(I)Z

    move-result p1

    if-nez p1, :cond_1e

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    goto :goto_5e

    :cond_1e
    invoke-virtual {p0}, LHo/o;->s()Ljp/j;

    move-result-object p1

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_31
    :goto_31
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Luo/k;

    instance-of v3, v2, Luo/e;

    if-eqz v3, :cond_31

    check-cast v2, Luo/e;

    invoke-interface {v2}, Luo/k;->getName()LTo/f;

    move-result-object v2

    const-string v3, "it.name"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p2, v2}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_31

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_31

    :cond_5d
    move-object p1, v0

    :goto_5e
    return-object p1
.end method

.method public final bridge synthetic g(LTo/f;LCo/c;)Luo/h;
    .registers 3

    invoke-virtual {p0, p1, p2}, LHo/n;->E(LTo/f;LCo/c;)Luo/e;

    move-result-object p1

    return-object p1
.end method

.method protected final k(Ldp/d;Leo/l;)Ljava/util/Set;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Ldp/d;->e()I

    move-result v0

    invoke-virtual {p1, v0}, Ldp/d;->a(I)Z

    move-result p1

    if-nez p1, :cond_12

    sget-object p1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object p1

    :cond_12
    iget-object p1, p0, LHo/n;->p:Ljp/k;

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Set;

    if-eqz p1, :cond_3c

    check-cast p1, Ljava/lang/Iterable;

    new-instance p2, Ljava/util/HashSet;

    invoke-direct {p2}, Ljava/util/HashSet;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_27
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_27

    :cond_3b
    return-object p2

    :cond_3c
    if-nez p2, :cond_42

    invoke-static {}, Ltp/b;->a()Leo/l;

    move-result-object p2

    :cond_42
    iget-object p1, p0, LHo/n;->n:LKo/t;

    invoke-interface {p1, p2}, LKo/t;->B(Leo/l;)V

    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    sget-object p2, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    :cond_4e
    :goto_4e
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6d

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LKo/g;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, LKo/B;->SOURCE:LKo/B;

    if-nez v1, :cond_63

    const/4 v0, 0x0

    goto :goto_67

    :cond_63
    invoke-interface {v0}, LKo/s;->getName()LTo/f;

    move-result-object v0

    :goto_67
    if-eqz v0, :cond_4e

    invoke-interface {p1, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_4e

    :cond_6d
    return-object p1
.end method

.method protected final l(Ldp/d;Leo/l;)Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    const-string p2, "kindFilter"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object p1
.end method

.method protected final n()LHo/b;
    .registers 2

    sget-object v0, LHo/b$a;->a:LHo/b$a;

    return-object v0
.end method

.method protected final p(Ljava/util/LinkedHashSet;LTo/f;)V
    .registers 3

    const-string p1, "name"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method protected final r(Ldp/d;)Ljava/util/Set;
    .registers 3

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object p1
.end method

.method public final x()Luo/k;
    .registers 2

    iget-object v0, p0, LHo/n;->o:LHo/m;

    return-object v0
.end method
