.class public final LHo/n$b$a;
.super LHo/n$b;
.source "LazyJavaPackageScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHo/n$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Luo/e;


# direct methods
.method public constructor <init>(Luo/e;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, v0}, LHo/n$b;-><init>(I)V

    iput-object p1, p0, LHo/n$b$a;->a:Luo/e;

    return-void
.end method


# virtual methods
.method public final a()Luo/e;
    .registers 2

    iget-object v0, p0, LHo/n$b$a;->a:Luo/e;

    return-object v0
.end method
