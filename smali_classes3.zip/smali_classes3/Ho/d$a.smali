.class final LHo/d$a;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaAnnotationDescriptor.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/d;-><init>(LGo/g;LKo/a;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Map<",
        "LTo/f;",
        "+",
        "LYo/g<",
        "*>;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/d;


# direct methods
.method constructor <init>(LHo/d;)V
    .registers 2

    iput-object p1, p0, LHo/d$a;->a:LHo/d;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 7

    iget-object v0, p0, LHo/d$a;->a:LHo/d;

    invoke-static {v0}, LHo/d;->g(LHo/d;)LKo/a;

    move-result-object v1

    invoke-interface {v1}, LKo/a;->getArguments()Ljava/util/ArrayList;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_13
    :goto_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LKo/b;

    invoke-interface {v3}, LKo/b;->getName()LTo/f;

    move-result-object v4

    if-nez v4, :cond_27

    sget-object v4, LDo/E;->b:LTo/f;

    :cond_27
    invoke-static {v0, v3}, LHo/d;->h(LHo/d;LKo/b;)LYo/g;

    move-result-object v3

    if-eqz v3, :cond_33

    new-instance v5, LUn/j;

    invoke-direct {v5, v4, v3}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_34

    :cond_33
    const/4 v5, 0x0

    :goto_34
    if-eqz v5, :cond_13

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_13

    :cond_3a
    invoke-static {v2}, Lkotlin/collections/J;->k(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method
