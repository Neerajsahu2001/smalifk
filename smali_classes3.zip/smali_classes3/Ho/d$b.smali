.class final LHo/d$b;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaAnnotationDescriptor.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/d;-><init>(LGo/g;LKo/a;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LTo/c;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/d;


# direct methods
.method constructor <init>(LHo/d;)V
    .registers 2

    iput-object p1, p0, LHo/d$b;->a:LHo/d;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LHo/d$b;->a:LHo/d;

    invoke-static {v0}, LHo/d;->g(LHo/d;)LKo/a;

    move-result-object v0

    invoke-interface {v0}, LKo/a;->d()LTo/b;

    move-result-object v0

    invoke-virtual {v0}, LTo/b;->b()LTo/c;

    move-result-object v0

    return-object v0
.end method
