.class final LHo/k$d;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/k;->d0(Luo/Q;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/f;",
        "Ljava/util/Collection<",
        "+",
        "Luo/Q;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Luo/Q;

.field final synthetic b:LHo/k;


# direct methods
.method constructor <init>(Luo/Q;LHo/k;)V
    .registers 3

    iput-object p1, p0, LHo/k$d;->a:Luo/Q;

    iput-object p2, p0, LHo/k$d;->b:LHo/k;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, LTo/f;

    const-string v0, "accessorName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/k$d;->a:Luo/Q;

    invoke-interface {v0}, Luo/k;->getName()LTo/f;

    move-result-object v1

    invoke-static {v1, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1a

    invoke-static {v0}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    goto :goto_28

    :cond_1a
    iget-object v0, p0, LHo/k$d;->b:LHo/k;

    invoke-static {v0, p1}, LHo/k;->J(LHo/k;LTo/f;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {v0, p1}, LHo/k;->K(LHo/k;LTo/f;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-static {p1, v1}, Lkotlin/collections/q;->L(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p1

    :goto_28
    return-object p1
.end method
