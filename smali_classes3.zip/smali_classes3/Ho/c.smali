.class public final LHo/c;
.super Ljava/lang/Object;
.source "JvmPackageScope.kt"

# interfaces
.implements Ldp/i;


# static fields
.field static final synthetic f:[Llo/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Llo/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final b:LGo/g;

.field private final c:LHo/m;

.field private final d:LHo/n;

.field private final e:Ljp/j;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lkotlin/jvm/internal/x;

    const-class v1, LHo/c;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v1

    const-string v2, "kotlinScopes"

    const-string v3, "getKotlinScopes()[Lorg/jetbrains/kotlin/resolve/scopes/MemberScope;"

    invoke-direct {v0, v1, v2, v3}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Llo/m;

    const/4 v2, 0x0

    aput-object v0, v1, v2

    sput-object v1, LHo/c;->f:[Llo/m;

    return-void
.end method

.method public constructor <init>(LGo/g;LKo/t;LHo/m;)V
    .registers 5

    const-string v0, "jPackage"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "packageFragment"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LHo/c;->b:LGo/g;

    iput-object p3, p0, LHo/c;->c:LHo/m;

    new-instance v0, LHo/n;

    invoke-direct {v0, p1, p2, p3}, LHo/n;-><init>(LGo/g;LKo/t;LHo/m;)V

    iput-object v0, p0, LHo/c;->d:LHo/n;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p1

    new-instance p2, LHo/c$a;

    invoke-direct {p2, p0}, LHo/c$a;-><init>(LHo/c;)V

    invoke-interface {p1, p2}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p1

    iput-object p1, p0, LHo/c;->e:Ljp/j;

    return-void
.end method

.method public static final synthetic h(LHo/c;)LGo/g;
    .registers 1

    iget-object p0, p0, LHo/c;->b:LGo/g;

    return-object p0
.end method

.method public static final synthetic i(LHo/c;)LHo/m;
    .registers 1

    iget-object p0, p0, LHo/c;->c:LHo/m;

    return-object p0
.end method

.method private final k()[Ldp/i;
    .registers 3

    sget-object v0, LHo/c;->f:[Llo/m;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v1, p0, LHo/c;->e:Ljp/j;

    invoke-static {v1, v0}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ldp/i;

    return-object v0
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, LHo/c;->k()[Ldp/i;

    move-result-object v0

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    array-length v2, v0

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v2, :cond_1b

    aget-object v4, v0, v3

    invoke-interface {v4}, Ldp/i;->a()Ljava/util/Set;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4, v1}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_1b
    iget-object v0, p0, LHo/c;->d:LHo/n;

    invoke-virtual {v0}, LHo/o;->a()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    return-object v1
.end method

.method public final b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 8

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2}, LHo/c;->l(LTo/f;LCo/a;)V

    invoke-direct {p0}, LHo/c;->k()[Ldp/i;

    move-result-object v0

    iget-object v1, p0, LHo/c;->d:LHo/n;

    invoke-virtual {v1, p1, p2}, LHo/o;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v1

    array-length v2, v0

    const/4 v3, 0x0

    :goto_19
    if-ge v3, v2, :cond_28

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/i;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v4

    invoke-static {v1, v4}, Lsp/a;->a(Ljava/util/Collection;Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_19

    :cond_28
    if-nez v1, :cond_2c

    sget-object v1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    :cond_2c
    return-object v1
.end method

.method public final c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 8

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2}, LHo/c;->l(LTo/f;LCo/a;)V

    invoke-direct {p0}, LHo/c;->k()[Ldp/i;

    move-result-object v0

    iget-object v1, p0, LHo/c;->d:LHo/n;

    invoke-virtual {v1, p1, p2}, LHo/n;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    sget-object v1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    array-length v2, v0

    const/4 v3, 0x0

    :goto_1a
    if-ge v3, v2, :cond_29

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/i;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v4

    invoke-static {v1, v4}, Lsp/a;->a(Ljava/util/Collection;Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_1a

    :cond_29
    if-nez v1, :cond_2d

    sget-object v1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    :cond_2d
    return-object v1
.end method

.method public final d()Ljava/util/Set;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, LHo/c;->k()[Ldp/i;

    move-result-object v0

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    array-length v2, v0

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v2, :cond_1b

    aget-object v4, v0, v3

    invoke-interface {v4}, Ldp/i;->d()Ljava/util/Set;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4, v1}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_1b
    iget-object v0, p0, LHo/c;->d:LHo/n;

    invoke-virtual {v0}, LHo/o;->d()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    return-object v1
.end method

.method public final e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameFilter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LHo/c;->k()[Ldp/i;

    move-result-object v0

    iget-object v1, p0, LHo/c;->d:LHo/n;

    invoke-virtual {v1, p1, p2}, LHo/n;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object v1

    array-length v2, v0

    const/4 v3, 0x0

    :goto_16
    if-ge v3, v2, :cond_25

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/l;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object v4

    invoke-static {v1, v4}, Lsp/a;->a(Ljava/util/Collection;Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    goto :goto_16

    :cond_25
    if-nez v1, :cond_29

    sget-object v1, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    :cond_29
    return-object v1
.end method

.method public final f()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, LHo/c;->k()[Ldp/i;

    move-result-object v0

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v1, v0

    if-nez v1, :cond_f

    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    goto :goto_15

    :cond_f
    new-instance v1, Lkotlin/collections/m;

    invoke-direct {v1, v0}, Lkotlin/collections/m;-><init>([Ljava/lang/Object;)V

    move-object v0, v1

    :goto_15
    invoke-static {v0}, Ldp/k;->a(Ljava/lang/Iterable;)Ljava/util/HashSet;

    move-result-object v0

    if-eqz v0, :cond_27

    iget-object v1, p0, LHo/c;->d:LHo/n;

    invoke-virtual {v1}, LHo/o;->f()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v0, v1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    goto :goto_28

    :cond_27
    const/4 v0, 0x0

    :goto_28
    return-object v0
.end method

.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 9

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, p2}, LHo/c;->l(LTo/f;LCo/a;)V

    iget-object v0, p0, LHo/c;->d:LHo/n;

    invoke-virtual {v0, p1, p2}, LHo/n;->E(LTo/f;LCo/c;)Luo/e;

    move-result-object v0

    if-eqz v0, :cond_16

    return-object v0

    :cond_16
    invoke-direct {p0}, LHo/c;->k()[Ldp/i;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_1d
    if-ge v3, v1, :cond_3d

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/l;->g(LTo/f;LCo/c;)Luo/h;

    move-result-object v4

    if-eqz v4, :cond_3a

    instance-of v5, v4, Luo/i;

    if-eqz v5, :cond_38

    move-object v5, v4

    check-cast v5, Luo/i;

    invoke-interface {v5}, Luo/z;->l0()Z

    move-result v5

    if-eqz v5, :cond_38

    if-nez v2, :cond_3a

    move-object v2, v4

    goto :goto_3a

    :cond_38
    move-object v2, v4

    goto :goto_3d

    :cond_3a
    :goto_3a
    add-int/lit8 v3, v3, 0x1

    goto :goto_1d

    :cond_3d
    :goto_3d
    return-object v2
.end method

.method public final j()LHo/n;
    .registers 2

    iget-object v0, p0, LHo/c;->d:LHo/n;

    return-object v0
.end method

.method public final l(LTo/f;LCo/a;)V
    .registers 5

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/c;->b:LGo/g;

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->l()LCo/b;

    move-result-object v0

    iget-object v1, p0, LHo/c;->c:LHo/m;

    check-cast p2, LCo/c;

    invoke-static {v0, p2, v1, p1}, LBo/a;->b(LCo/b;LCo/c;Luo/E;LTo/f;)V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "scope for "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LHo/c;->c:LHo/m;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
