.class final LHo/l;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Set<",
        "+",
        "LTo/f;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/k;


# direct methods
.method constructor <init>(LHo/k;)V
    .registers 2

    iput-object p1, p0, LHo/l;->a:LHo/k;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, LHo/l;->a:LHo/k;

    invoke-virtual {v0}, LHo/o;->a()Ljava/util/Set;

    move-result-object v1

    invoke-virtual {v0}, LHo/o;->d()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v1, v0}, Lkotlin/collections/O;->c(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    move-result-object v0

    return-object v0
.end method
