.class public abstract LHo/z;
.super LHo/o;
.source "LazyJavaStaticScope.kt"


# virtual methods
.method protected q(Ljava/util/ArrayList;LTo/f;)V
    .registers 3

    const-string p1, "name"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method protected final v()Luo/O;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method protected final z(LKo/q;Ljava/util/ArrayList;Lkp/E;Ljava/util/List;)LHo/o$a;
    .registers 12

    const-string v0, "method"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "valueParameters"

    invoke-static {p4, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p1, LHo/o$a;

    sget-object v3, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p1

    move-object v1, p4

    move-object v2, p2

    move-object v4, p3

    invoke-direct/range {v0 .. v6}, LHo/o$a;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkp/E;Lkp/E;Z)V

    return-object p1
.end method
