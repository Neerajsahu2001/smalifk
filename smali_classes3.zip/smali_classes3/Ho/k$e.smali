.class final LHo/k$e;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/k;-><init>(LGo/g;Luo/e;LKo/g;ZLHo/k;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Set<",
        "+",
        "LTo/f;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/k;


# direct methods
.method constructor <init>(LHo/k;)V
    .registers 2

    iput-object p1, p0, LHo/k$e;->a:LHo/k;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LHo/k$e;->a:LHo/k;

    invoke-static {v0}, LHo/k;->G(LHo/k;)LKo/g;

    move-result-object v0

    invoke-interface {v0}, LKo/g;->u()Ljava/util/Collection;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/q;->c0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method
