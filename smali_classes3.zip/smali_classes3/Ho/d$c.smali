.class final LHo/d$c;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaAnnotationDescriptor.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/d;-><init>(LGo/g;LKo/a;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Lkp/M;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/d;


# direct methods
.method constructor <init>(LHo/d;)V
    .registers 2

    iput-object p1, p0, LHo/d$c;->a:LHo/d;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, LHo/d$c;->a:LHo/d;

    invoke-virtual {v0}, LHo/d;->c()LTo/c;

    move-result-object v1

    if-nez v1, :cond_1b

    sget-object v1, Lmp/j;->NOT_FOUND_FQNAME_FOR_JAVA_ANNOTATION:Lmp/j;

    invoke-static {v0}, LHo/d;->g(LHo/d;)LKo/a;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lmp/k;->c(Lmp/j;[Ljava/lang/String;)Lmp/h;

    move-result-object v0

    goto :goto_4f

    :cond_1b
    invoke-static {v0}, LHo/d;->e(LHo/d;)LGo/g;

    move-result-object v2

    invoke-virtual {v2}, LGo/g;->d()Luo/B;

    move-result-object v2

    invoke-interface {v2}, Luo/B;->m()Lro/j;

    move-result-object v2

    invoke-static {v1, v2}, Lto/d;->b(LTo/c;Lro/j;)Luo/e;

    move-result-object v2

    if-nez v2, :cond_4b

    invoke-static {v0}, LHo/d;->g(LHo/d;)LKo/a;

    move-result-object v2

    invoke-interface {v2}, LKo/a;->j()LAo/r;

    move-result-object v2

    invoke-static {v0}, LHo/d;->e(LHo/d;)LGo/g;

    move-result-object v3

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v3

    invoke-virtual {v3}, LGo/c;->n()LGo/i;

    move-result-object v3

    invoke-interface {v3, v2}, LGo/i;->a(LKo/g;)Luo/e;

    move-result-object v2

    if-nez v2, :cond_4b

    invoke-static {v0, v1}, LHo/d;->d(LHo/d;LTo/c;)Luo/e;

    move-result-object v2

    :cond_4b
    invoke-interface {v2}, Luo/e;->q()Lkp/M;

    move-result-object v0

    :goto_4f
    return-object v0
.end method
