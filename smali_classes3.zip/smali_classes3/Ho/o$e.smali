.class final LHo/o$e;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/o;-><init>(LGo/g;LHo/o;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/f;",
        "Luo/L;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/o;


# direct methods
.method constructor <init>(LHo/o;)V
    .registers 2

    iput-object p1, p0, LHo/o$e;->a:LHo/o;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, LTo/f;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/o$e;->a:LHo/o;

    invoke-virtual {v0}, LHo/o;->w()LHo/o;

    move-result-object v1

    if-eqz v1, :cond_1e

    invoke-virtual {v0}, LHo/o;->w()LHo/o;

    move-result-object v0

    invoke-static {v0}, LHo/o;->h(LHo/o;)Ljp/i;

    move-result-object v0

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Luo/L;

    goto :goto_3a

    :cond_1e
    invoke-virtual {v0}, LHo/o;->u()Ljp/j;

    move-result-object v1

    invoke-interface {v1}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LHo/b;

    invoke-interface {v1, p1}, LHo/b;->f(LTo/f;)LKo/n;

    move-result-object p1

    if-eqz p1, :cond_39

    invoke-interface {p1}, LKo/n;->C()Z

    move-result v1

    if-nez v1, :cond_39

    invoke-static {v0, p1}, LHo/o;->j(LHo/o;LKo/n;)LFo/f;

    move-result-object p1

    goto :goto_3a

    :cond_39
    const/4 p1, 0x0

    :goto_3a
    return-object p1
.end method
