.class public final LHo/x;
.super Ltp/a$b;
.source "LazyJavaStaticClassScope.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltp/a$b<",
        "Luo/e;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Luo/e;

.field final synthetic b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic c:Leo/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/l<",
            "Ldp/i;",
            "Ljava/util/Collection<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(LFo/c;Ljava/util/LinkedHashSet;Leo/l;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LHo/x;->a:Luo/e;

    iput-object p2, p0, LHo/x;->b:Ljava/util/Set;

    iput-object p3, p0, LHo/x;->c:Leo/l;

    return-void
.end method


# virtual methods
.method public final bridge synthetic a()Ljava/lang/Object;
    .registers 2

    sget-object v0, LUn/r;->a:LUn/r;

    return-object v0
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 4

    check-cast p1, Luo/e;

    const-string v0, "current"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/x;->a:Luo/e;

    const/4 v1, 0x1

    if-ne p1, v0, :cond_d

    goto :goto_28

    :cond_d
    invoke-interface {p1}, Luo/e;->n0()Ldp/i;

    move-result-object p1

    const-string v0, "current.staticScope"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p1, LHo/z;

    if-eqz v0, :cond_28

    iget-object v0, p0, LHo/x;->c:Leo/l;

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    iget-object v0, p0, LHo/x;->b:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v1, 0x0

    :cond_28
    :goto_28
    return v1
.end method
