.class final LHo/e$a$a;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassDescriptor.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/e$a;-><init>(LHo/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "Luo/X;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/e;


# direct methods
.method constructor <init>(LHo/e;)V
    .registers 2

    iput-object p1, p0, LHo/e$a$a;->a:LHo/e;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, LHo/e$a$a;->a:LHo/e;

    invoke-static {v0}, Luo/Y;->c(Luo/i;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
