.class public interface abstract LHo/b;
.super Ljava/lang/Object;
.source "DeclaredMemberIndex.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LHo/b$a;
    }
.end annotation


# virtual methods
.method public abstract a()Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method

.method public abstract b(LTo/f;)LKo/v;
.end method

.method public abstract c(LTo/f;)Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTo/f;",
            ")",
            "Ljava/util/Collection<",
            "LKo/q;",
            ">;"
        }
    .end annotation
.end method

.method public abstract d()Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method

.method public abstract e()Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method

.method public abstract f(LTo/f;)LKo/n;
.end method
