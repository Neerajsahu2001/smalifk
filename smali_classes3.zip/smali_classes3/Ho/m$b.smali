.class final LHo/m$b;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaPackageFragment.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/m;-><init>(LGo/g;LKo/t;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LHo/m$b$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/HashMap<",
        "Lbp/b;",
        "Lbp/b;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/m;


# direct methods
.method constructor <init>(LHo/m;)V
    .registers 2

    iput-object p1, p0, LHo/m$b;->a:LHo/m;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 7

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, LHo/m$b;->a:LHo/m;

    invoke-virtual {v1}, LHo/m;->N0()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_59

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LMo/w;

    invoke-static {v3}, Lbp/b;->d(Ljava/lang/String;)Lbp/b;

    move-result-object v3

    invoke-interface {v2}, LMo/w;->a()LNo/a;

    move-result-object v2

    invoke-virtual {v2}, LNo/a;->c()LNo/a$a;

    move-result-object v4

    sget-object v5, LHo/m$b$a;->a:[I

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aget v4, v5, v4

    const/4 v5, 0x1

    if-eq v4, v5, :cond_4a

    const/4 v2, 0x2

    if-eq v4, v2, :cond_46

    goto :goto_13

    :cond_46
    invoke-virtual {v0, v3, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_13

    :cond_4a
    invoke-virtual {v2}, LNo/a;->e()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_51

    goto :goto_13

    :cond_51
    invoke-static {v2}, Lbp/b;->d(Ljava/lang/String;)Lbp/b;

    move-result-object v2

    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_13

    :cond_59
    return-object v0
.end method
