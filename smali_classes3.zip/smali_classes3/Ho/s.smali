.class final LHo/s;
.super Ljava/lang/Object;

# interfaces
.implements Ltp/a$c;


# static fields
.field public static final a:LHo/s;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LHo/s;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LHo/s;->a:LHo/s;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Iterable;
    .registers 3

    check-cast p1, Luo/e;

    sget v0, LHo/y;->p:I

    invoke-interface {p1}, Luo/h;->j()Lkp/e0;

    move-result-object p1

    invoke-interface {p1}, Lkp/e0;->l()Ljava/util/Collection;

    move-result-object p1

    const-string v0, "it.typeConstructor.supertypes"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Ljava/lang/Iterable;

    invoke-static {p1}, Lkotlin/collections/q;->j(Ljava/lang/Iterable;)Lkotlin/collections/w;

    move-result-object p1

    sget-object v0, LHo/w;->a:LHo/w;

    invoke-static {p1, v0}, Lup/k;->n(Lup/h;Leo/l;)Lup/e;

    move-result-object p1

    new-instance v0, Lup/u;

    invoke-direct {v0, p1}, Lup/u;-><init>(Lup/h;)V

    return-object v0
.end method
