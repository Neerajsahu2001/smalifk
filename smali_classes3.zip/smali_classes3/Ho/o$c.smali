.class final LHo/o$c;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/o;-><init>(LGo/g;LHo/o;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Collection<",
        "+",
        "Luo/k;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/o;


# direct methods
.method constructor <init>(LHo/o;)V
    .registers 2

    iput-object p1, p0, LHo/o$c;->a:LHo/o;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 8

    sget-object v0, Ldp/d;->m:Ldp/d;

    sget-object v1, Ldp/i;->a:Ldp/i$a;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ldp/i$a;->a()Leo/l;

    move-result-object v1

    iget-object v2, p0, LHo/o$c;->a:LHo/o;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v3, "kindFilter"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "nameFilter"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v3, LCo/c;->WHEN_GET_ALL_DESCRIPTORS:LCo/c;

    new-instance v4, Ljava/util/LinkedHashSet;

    invoke-direct {v4}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-static {}, Ldp/d;->c()I

    move-result v5

    invoke-virtual {v0, v5}, Ldp/d;->a(I)Z

    move-result v5

    if-eqz v5, :cond_4a

    invoke-virtual {v2, v0, v1}, LHo/o;->k(Ldp/d;Leo/l;)Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_33
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_4a

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LTo/f;

    invoke-interface {v1, v6}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2, v6, v3}, Ldp/j;->g(LTo/f;LCo/c;)Luo/h;

    move-result-object v6

    invoke-static {v6, v4}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    goto :goto_33

    :cond_4a
    invoke-static {}, Ldp/d;->d()I

    move-result v5

    invoke-virtual {v0, v5}, Ldp/d;->a(I)Z

    move-result v5

    if-eqz v5, :cond_7f

    invoke-virtual {v0}, Ldp/d;->l()Ljava/util/List;

    move-result-object v5

    sget-object v6, Ldp/c$a;->a:Ldp/c$a;

    invoke-interface {v5, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_7f

    invoke-virtual {v2, v0, v1}, LHo/o;->l(Ldp/d;Leo/l;)Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_68
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_7f

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LTo/f;

    invoke-interface {v1, v6}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2, v6, v3}, LHo/o;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    goto :goto_68

    :cond_7f
    invoke-static {}, Ldp/d;->j()I

    move-result v5

    invoke-virtual {v0, v5}, Ldp/d;->a(I)Z

    move-result v5

    if-eqz v5, :cond_b4

    invoke-virtual {v0}, Ldp/d;->l()Ljava/util/List;

    move-result-object v5

    sget-object v6, Ldp/c$a;->a:Ldp/c$a;

    invoke-interface {v5, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_b4

    invoke-virtual {v2, v0}, LHo/o;->r(Ldp/d;)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_9d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_b4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LTo/f;

    invoke-interface {v1, v5}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2, v5, v3}, LHo/o;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    goto :goto_9d

    :cond_b4
    invoke-static {v4}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method
