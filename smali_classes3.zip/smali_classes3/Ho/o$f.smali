.class final LHo/o$f;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/o;-><init>(LGo/g;LHo/o;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/f;",
        "Ljava/util/Collection<",
        "+",
        "Luo/Q;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/o;


# direct methods
.method constructor <init>(LHo/o;)V
    .registers 2

    iput-object p1, p0, LHo/o$f;->a:LHo/o;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    check-cast p1, LTo/f;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/o$f;->a:LHo/o;

    invoke-virtual {v0}, LHo/o;->w()LHo/o;

    move-result-object v1

    if-eqz v1, :cond_1e

    invoke-virtual {v0}, LHo/o;->w()LHo/o;

    move-result-object v0

    invoke-static {v0}, LHo/o;->i(LHo/o;)Ljp/h;

    move-result-object v0

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    goto :goto_62

    :cond_1e
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, LHo/o;->u()Ljp/j;

    move-result-object v2

    invoke-interface {v2}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LHo/b;

    invoke-interface {v2, p1}, LHo/b;->c(LTo/f;)Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_35
    :goto_35
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LKo/q;

    invoke-virtual {v0, v3}, LHo/o;->A(LKo/q;)LFo/e;

    move-result-object v3

    invoke-virtual {v0, v3}, LHo/o;->y(LFo/e;)Z

    move-result v4

    if-eqz v4, :cond_35

    invoke-virtual {v0}, LHo/o;->t()LGo/g;

    move-result-object v4

    invoke-virtual {v4}, LGo/g;->a()LGo/c;

    move-result-object v4

    invoke-virtual {v4}, LGo/c;->h()LEo/i;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_35

    :cond_5e
    invoke-virtual {v0, v1, p1}, LHo/o;->m(Ljava/util/ArrayList;LTo/f;)V

    move-object p1, v1

    :goto_62
    return-object p1
.end method
