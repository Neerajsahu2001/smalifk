.class final LHo/k$c;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/k;-><init>(LGo/g;Luo/e;LKo/g;ZLHo/k;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Set<",
        "+",
        "LTo/f;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LGo/g;

.field final synthetic b:LHo/k;


# direct methods
.method constructor <init>(LGo/g;LHo/k;)V
    .registers 3

    iput-object p1, p0, LHo/k$c;->a:LGo/g;

    iput-object p2, p0, LHo/k$c;->b:LHo/k;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, LHo/k$c;->a:LGo/g;

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->w()Lbp/d;

    move-result-object v1

    iget-object v2, p0, LHo/k$c;->b:LHo/k;

    invoke-virtual {v2}, LHo/k;->a0()Luo/e;

    move-result-object v2

    invoke-interface {v1, v0, v2}, Lbp/d;->g(LGo/g;Luo/e;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->c0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method
