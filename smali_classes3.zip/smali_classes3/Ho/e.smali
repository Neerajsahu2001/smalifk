.class public final LHo/e;
.super Lxo/l;
.source "LazyJavaClassDescriptor.kt"

# interfaces
.implements LFo/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LHo/e$a;
    }
.end annotation


# instance fields
.field private final h:LGo/g;

.field private final i:LKo/g;

.field private final j:Luo/e;

.field private final k:LGo/g;

.field private final l:LUn/e;

.field private final m:Luo/f;

.field private final n:Luo/A;

.field private final o:Luo/f0;

.field private final p:Z

.field private final q:LHo/e$a;

.field private final r:LHo/k;

.field private final s:Luo/P;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Luo/P<",
            "LHo/k;",
            ">;"
        }
    .end annotation
.end field

.field private final t:Ldp/g;

.field private final u:LHo/y;

.field private final v:LGo/e;

.field private final w:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/List<",
            "Luo/X;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 7

    const-string v5, "notifyAll"

    const-string v6, "toString"

    const-string v0, "equals"

    const-string v1, "hashCode"

    const-string v2, "getClass"

    const-string v3, "wait"

    const-string v4, "notify"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/O;->f([Ljava/lang/Object;)Ljava/util/Set;

    return-void
.end method

.method public constructor <init>(LGo/g;Luo/k;LKo/g;Luo/e;)V
    .registers 11

    const-string v0, "outerContext"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "containingDeclaration"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "jClass"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object v0

    invoke-interface {p3}, LKo/s;->getName()LTo/f;

    move-result-object v1

    invoke-virtual {p1}, LGo/g;->a()LGo/c;

    move-result-object v2

    invoke-virtual {v2}, LGo/c;->t()LJo/b;

    move-result-object v2

    invoke-interface {v2, p3}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v2

    invoke-direct {p0, v0, p2, v1, v2}, Lxo/l;-><init>(Ljp/n;Luo/k;LTo/f;Luo/S;)V

    iput-object p1, p0, LHo/e;->h:LGo/g;

    iput-object p3, p0, LHo/e;->i:LKo/g;

    iput-object p4, p0, LHo/e;->j:Luo/e;

    const/4 p2, 0x4

    invoke-static {p1, p0, p3, p2}, LGo/b;->a(LGo/g;Luo/g;LKo/y;I)LGo/g;

    move-result-object p1

    iput-object p1, p0, LHo/e;->k:LGo/g;

    invoke-virtual {p1}, LGo/g;->a()LGo/c;

    move-result-object p2

    invoke-virtual {p2}, LGo/c;->h()LEo/i;

    move-result-object p2

    invoke-interface {p2, p3, p0}, LEo/i;->a(LKo/g;Luo/e;)V

    new-instance p2, LHo/e$d;

    invoke-direct {p2, p0}, LHo/e$d;-><init>(LHo/e;)V

    invoke-static {p2}, LUn/f;->b(Leo/a;)LUn/e;

    move-result-object p2

    iput-object p2, p0, LHo/e;->l:LUn/e;

    invoke-interface {p3}, LKo/g;->n()Z

    move-result p2

    if-eqz p2, :cond_52

    sget-object p2, Luo/f;->ANNOTATION_CLASS:Luo/f;

    goto :goto_66

    :cond_52
    invoke-interface {p3}, LKo/g;->D()Z

    move-result p2

    if-eqz p2, :cond_5b

    sget-object p2, Luo/f;->INTERFACE:Luo/f;

    goto :goto_66

    :cond_5b
    invoke-interface {p3}, LKo/g;->q()Z

    move-result p2

    if-eqz p2, :cond_64

    sget-object p2, Luo/f;->ENUM_CLASS:Luo/f;

    goto :goto_66

    :cond_64
    sget-object p2, Luo/f;->CLASS:Luo/f;

    :goto_66
    iput-object p2, p0, LHo/e;->m:Luo/f;

    invoke-interface {p3}, LKo/g;->n()Z

    move-result p2

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p2, :cond_a0

    invoke-interface {p3}, LKo/g;->q()Z

    move-result p2

    if-eqz p2, :cond_77

    goto :goto_a0

    :cond_77
    sget-object p2, Luo/A;->Companion:Luo/A$a;

    invoke-interface {p3}, LKo/g;->s()Z

    move-result v2

    invoke-interface {p3}, LKo/g;->s()Z

    move-result v3

    if-nez v3, :cond_92

    invoke-interface {p3}, LKo/r;->isAbstract()Z

    move-result v3

    if-nez v3, :cond_92

    invoke-interface {p3}, LKo/g;->D()Z

    move-result v3

    if-eqz v3, :cond_90

    goto :goto_92

    :cond_90
    const/4 v3, 0x0

    goto :goto_93

    :cond_92
    :goto_92
    const/4 v3, 0x1

    :goto_93
    invoke-interface {p3}, LKo/r;->isFinal()Z

    move-result v4

    xor-int/2addr v4, v1

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v3, v4}, Luo/A$a;->a(ZZZ)Luo/A;

    move-result-object p2

    goto :goto_a2

    :cond_a0
    :goto_a0
    sget-object p2, Luo/A;->FINAL:Luo/A;

    :goto_a2
    iput-object p2, p0, LHo/e;->n:Luo/A;

    invoke-interface {p3}, LKo/r;->getVisibility()Luo/f0;

    move-result-object p2

    iput-object p2, p0, LHo/e;->o:Luo/f0;

    invoke-interface {p3}, LKo/g;->o()LAo/r;

    move-result-object p2

    if-eqz p2, :cond_b8

    invoke-interface {p3}, LKo/r;->isStatic()Z

    move-result p2

    if-nez p2, :cond_b8

    const/4 p2, 0x1

    goto :goto_b9

    :cond_b8
    const/4 p2, 0x0

    :goto_b9
    iput-boolean p2, p0, LHo/e;->p:Z

    new-instance p2, LHo/e$a;

    invoke-direct {p2, p0}, LHo/e$a;-><init>(LHo/e;)V

    iput-object p2, p0, LHo/e;->q:LHo/e$a;

    new-instance p2, LHo/k;

    if-eqz p4, :cond_c8

    const/4 v4, 0x1

    goto :goto_c9

    :cond_c8
    const/4 v4, 0x0

    :goto_c9
    const/4 v5, 0x0

    move-object v0, p2

    move-object v1, p1

    move-object v2, p0

    move-object v3, p3

    invoke-direct/range {v0 .. v5}, LHo/k;-><init>(LGo/g;Luo/e;LKo/g;ZLHo/k;)V

    iput-object p2, p0, LHo/e;->r:LHo/k;

    sget-object p4, Luo/P;->e:Luo/P$a;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object v0

    invoke-virtual {p1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->k()Llp/l;

    move-result-object v1

    invoke-interface {v1}, Llp/l;->c()Llp/f;

    move-result-object v1

    new-instance v2, LHo/e$e;

    invoke-direct {v2, p0}, LHo/e$e;-><init>(LHo/e;)V

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p4, "storageManager"

    invoke-static {v0, p4}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p4, "kotlinTypeRefinerForOwnerModule"

    invoke-static {v1, p4}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p4, Luo/P;

    invoke-direct {p4, p0, v0, v2, v1}, Luo/P;-><init>(Luo/e;Ljp/n;Leo/l;Llp/f;)V

    iput-object p4, p0, LHo/e;->s:Luo/P;

    new-instance p4, Ldp/g;

    invoke-direct {p4, p2}, Ldp/g;-><init>(Ldp/i;)V

    iput-object p4, p0, LHo/e;->t:Ldp/g;

    new-instance p2, LHo/y;

    invoke-direct {p2, p1, p3, p0}, LHo/y;-><init>(LGo/g;LKo/g;LFo/c;)V

    iput-object p2, p0, LHo/e;->u:LHo/y;

    invoke-static {p1, p3}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object p2

    iput-object p2, p0, LHo/e;->v:LGo/e;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p1

    new-instance p2, LHo/e$b;

    invoke-direct {p2, p0}, LHo/e$b;-><init>(LHo/e;)V

    invoke-interface {p1, p2}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p1

    iput-object p1, p0, LHo/e;->w:Ljp/j;

    return-void
.end method

.method public static final synthetic L0(LHo/e;)Luo/e;
    .registers 1

    iget-object p0, p0, LHo/e;->j:Luo/e;

    return-object p0
.end method

.method public static final synthetic M0(LHo/e;)LGo/g;
    .registers 1

    iget-object p0, p0, LHo/e;->k:LGo/g;

    return-object p0
.end method

.method public static final synthetic N0(LHo/e;)LHo/k;
    .registers 1

    iget-object p0, p0, LHo/e;->r:LHo/k;

    return-object p0
.end method


# virtual methods
.method public final E()Luo/d;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public final J0()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final O0(Luo/e;)LHo/e;
    .registers 7

    new-instance v0, LHo/e;

    iget-object v1, p0, LHo/e;->k:LGo/g;

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v2

    invoke-virtual {v2}, LGo/c;->x()LGo/c;

    move-result-object v2

    new-instance v3, LGo/g;

    invoke-virtual {v1}, LGo/g;->f()LGo/k;

    move-result-object v4

    invoke-virtual {v1}, LGo/g;->c()LUn/e;

    move-result-object v1

    invoke-direct {v3, v2, v4, v1}, LGo/g;-><init>(LGo/c;LGo/k;LUn/e;)V

    invoke-virtual {p0}, Lxo/l;->d()Luo/k;

    move-result-object v1

    const-string v2, "containingDeclaration"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, LHo/e;->i:LKo/g;

    invoke-direct {v0, v3, v1, v2, p1}, LHo/e;-><init>(LGo/g;Luo/k;LKo/g;Luo/e;)V

    return-object v0
.end method

.method public final P0()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Luo/d;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/e;->r:LHo/k;

    invoke-virtual {v0}, LHo/k;->Y()Ljp/j;

    move-result-object v0

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0
.end method

.method public final Q0()LKo/g;
    .registers 2

    iget-object v0, p0, LHo/e;->i:LKo/g;

    return-object v0
.end method

.method public final R0()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "LKo/a;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/e;->l:LUn/e;

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0
.end method

.method public final S0()LGo/g;
    .registers 2

    iget-object v0, p0, LHo/e;->h:LGo/g;

    return-object v0
.end method

.method public final T()Ldp/i;
    .registers 2

    iget-object v0, p0, LHo/e;->t:Ldp/g;

    return-object v0
.end method

.method public final T0()LHo/k;
    .registers 3

    invoke-super {p0}, Lxo/b;->W()Ldp/i;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type org.jetbrains.kotlin.load.java.lazy.descriptors.LazyJavaClassMemberScope"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LHo/k;

    return-object v0
.end method

.method public final U()Luo/Z;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Luo/Z<",
            "Lkp/M;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    return-object v0
.end method

.method public final bridge synthetic W()Ldp/i;
    .registers 2

    invoke-virtual {p0}, LHo/e;->T0()LHo/k;

    move-result-object v0

    return-object v0
.end method

.method public final Y()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final b0()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final f0()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final getAnnotations()Lvo/h;
    .registers 2

    iget-object v0, p0, LHo/e;->v:LGo/e;

    return-object v0
.end method

.method public final getVisibility()Luo/r;
    .registers 3

    sget-object v0, Luo/q;->a:Luo/r;

    iget-object v1, p0, LHo/e;->o:Luo/f0;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1a

    iget-object v0, p0, LHo/e;->i:LKo/g;

    invoke-interface {v0}, LKo/g;->o()LAo/r;

    move-result-object v0

    if-nez v0, :cond_1a

    sget-object v0, LDo/u;->a:Luo/r;

    const-string v1, "{\n            JavaDescri\u2026KAGE_VISIBILITY\n        }"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_23

    :cond_1a
    const-string v0, "<this>"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, LDo/u;->e(Luo/f0;)Luo/r;

    move-result-object v0

    :goto_23
    return-object v0
.end method

.method public final h()Luo/f;
    .registers 2

    iget-object v0, p0, LHo/e;->m:Luo/f;

    return-object v0
.end method

.method public final isInline()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final j()Lkp/e0;
    .registers 2

    iget-object v0, p0, LHo/e;->q:LHo/e$a;

    return-object v0
.end method

.method public final bridge synthetic k()Ljava/util/Collection;
    .registers 2

    invoke-virtual {p0}, LHo/e;->P0()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    return-object v0
.end method

.method public final k0()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final l0()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final m0(Llp/f;)Ldp/i;
    .registers 3

    const-string v0, "kotlinTypeRefiner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/e;->s:Luo/P;

    invoke-virtual {v0, p1}, Luo/P;->c(Llp/f;)Ldp/i;

    move-result-object p1

    check-cast p1, LHo/k;

    return-object p1
.end method

.method public final n0()Ldp/i;
    .registers 2

    iget-object v0, p0, LHo/e;->u:LHo/y;

    return-object v0
.end method

.method public final o0()Luo/e;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public final r()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Luo/X;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/e;->w:Ljp/j;

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0
.end method

.method public final s()Luo/A;
    .registers 2

    iget-object v0, p0, LHo/e;->n:Luo/A;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Lazy Java class "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Lap/c;->h(Luo/k;)LTo/d;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final w()Ljava/util/Collection;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "Luo/e;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/e;->n:Luo/A;

    sget-object v1, Luo/A;->SEALED:Luo/A;

    if-ne v0, v1, :cond_58

    sget-object v0, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v2, v2, v3, v1}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v0

    iget-object v1, p0, LHo/e;->i:LKo/g;

    invoke-interface {v1}, LKo/g;->x()Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_20
    :goto_20
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4c

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LKo/j;

    iget-object v5, p0, LHo/e;->k:LGo/g;

    invoke-virtual {v5}, LGo/g;->g()LIo/d;

    move-result-object v5

    invoke-virtual {v5, v4, v0}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object v4

    invoke-virtual {v4}, Lkp/E;->N0()Lkp/e0;

    move-result-object v4

    invoke-interface {v4}, Lkp/e0;->n()Luo/h;

    move-result-object v4

    instance-of v5, v4, Luo/e;

    if-eqz v5, :cond_45

    check-cast v4, Luo/e;

    goto :goto_46

    :cond_45
    move-object v4, v3

    :goto_46
    if-eqz v4, :cond_20

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_20

    :cond_4c
    new-instance v0, LHo/e$c;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {v2, v0}, Lkotlin/collections/q;->S(Ljava/util/AbstractCollection;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    goto :goto_5a

    :cond_58
    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :goto_5a
    return-object v0
.end method

.method public final z()Z
    .registers 2

    iget-boolean v0, p0, LHo/e;->p:Z

    return v0
.end method
