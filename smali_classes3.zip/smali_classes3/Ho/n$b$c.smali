.class public final LHo/n$b$c;
.super LHo/n$b;
.source "LazyJavaPackageScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHo/n$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field public static final a:LHo/n$b$c;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LHo/n$b$c;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LHo/n$b;-><init>(I)V

    sput-object v0, LHo/n$b$c;->a:LHo/n$b$c;

    return-void
.end method
