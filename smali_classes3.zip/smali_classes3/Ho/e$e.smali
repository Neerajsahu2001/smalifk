.class final LHo/e$e;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassDescriptor.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/e;-><init>(LGo/g;Luo/k;LKo/g;Luo/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Llp/f;",
        "LHo/k;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/e;


# direct methods
.method constructor <init>(LHo/e;)V
    .registers 2

    iput-object p1, p0, LHo/e$e;->a:LHo/e;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    check-cast p1, Llp/f;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p1, LHo/k;

    iget-object v3, p0, LHo/e$e;->a:LHo/e;

    invoke-static {v3}, LHo/e;->M0(LHo/e;)LGo/g;

    move-result-object v2

    invoke-virtual {v3}, LHo/e;->Q0()LKo/g;

    move-result-object v4

    invoke-static {v3}, LHo/e;->L0(LHo/e;)Luo/e;

    move-result-object v0

    if-eqz v0, :cond_1c

    const/4 v0, 0x1

    const/4 v5, 0x1

    goto :goto_1e

    :cond_1c
    const/4 v0, 0x0

    const/4 v5, 0x0

    :goto_1e
    invoke-static {v3}, LHo/e;->N0(LHo/e;)LHo/k;

    move-result-object v6

    move-object v1, p1

    invoke-direct/range {v1 .. v6}, LHo/k;-><init>(LGo/g;Luo/e;LKo/g;ZLHo/k;)V

    return-object p1
.end method
