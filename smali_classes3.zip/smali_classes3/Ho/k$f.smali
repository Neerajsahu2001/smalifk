.class final LHo/k$f;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/k;-><init>(LGo/g;Luo/e;LKo/g;ZLHo/k;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/f;",
        "Luo/e;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/k;

.field final synthetic b:LGo/g;


# direct methods
.method constructor <init>(LGo/g;LHo/k;)V
    .registers 3

    iput-object p2, p0, LHo/k$f;->a:LHo/k;

    iput-object p1, p0, LHo/k$f;->b:LGo/g;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    move-object v2, p1

    check-cast v2, LTo/f;

    const-string p1, "name"

    invoke-static {v2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, LHo/k$f;->a:LHo/k;

    invoke-static {p1}, LHo/k;->H(LHo/k;)Ljp/j;

    move-result-object v0

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    iget-object v1, p0, LHo/k$f;->b:LGo/g;

    const/4 v3, 0x0

    if-eqz v0, :cond_5b

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->d()LDo/r;

    move-result-object v0

    new-instance v4, LDo/r$a;

    invoke-virtual {p1}, LHo/k;->a0()Luo/e;

    move-result-object v5

    invoke-static {v5}, Lap/c;->f(Luo/h;)LTo/b;

    move-result-object v5

    invoke-static {v5}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v5, v2}, LTo/b;->d(LTo/f;)LTo/b;

    move-result-object v2

    invoke-static {p1}, LHo/k;->G(LHo/k;)LKo/g;

    move-result-object v5

    const/4 v6, 0x2

    invoke-direct {v4, v2, v5, v6}, LDo/r$a;-><init>(LTo/b;LKo/g;I)V

    invoke-interface {v0, v4}, LDo/r;->b(LDo/r$a;)LAo/r;

    move-result-object v0

    if-eqz v0, :cond_ea

    new-instance v2, LHo/e;

    invoke-virtual {p1}, LHo/k;->a0()Luo/e;

    move-result-object p1

    invoke-direct {v2, v1, p1, v0, v3}, LHo/e;-><init>(LGo/g;Luo/k;LKo/g;Luo/e;)V

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object p1

    invoke-virtual {p1}, LGo/c;->e()LDo/s;

    move-result-object p1

    invoke-interface {p1, v2}, LDo/s;->a(LHo/e;)V

    move-object v3, v2

    goto/16 :goto_ea

    :cond_5b
    invoke-static {p1}, LHo/k;->F(LHo/k;)Ljp/j;

    move-result-object v0

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ab

    new-instance v0, LVn/a;

    invoke-direct {v0}, LVn/a;-><init>()V

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v4

    invoke-virtual {v4}, LGo/c;->w()Lbp/d;

    move-result-object v4

    invoke-virtual {p1}, LHo/k;->a0()Luo/e;

    move-result-object p1

    invoke-interface {v4, v1, p1, v2, v0}, Lbp/d;->e(LGo/g;Luo/e;LTo/f;LVn/a;)V

    invoke-virtual {v0}, LVn/a;->q()V

    invoke-virtual {v0}, LVn/a;->b()I

    move-result p1

    if-eqz p1, :cond_ea

    const/4 v1, 0x1

    if-ne p1, v1, :cond_93

    invoke-static {v0}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    move-object v3, p1

    check-cast v3, Luo/e;

    goto :goto_ea

    :cond_93
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Multiple classes with same name are generated: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_ab
    invoke-static {p1}, LHo/k;->E(LHo/k;)Ljp/j;

    move-result-object v0

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LKo/n;

    if-eqz v0, :cond_ea

    invoke-virtual {v1}, LGo/g;->e()Ljp/n;

    move-result-object v3

    new-instance v4, LHo/l;

    invoke-direct {v4, p1}, LHo/l;-><init>(LHo/k;)V

    invoke-interface {v3, v4}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object v3

    invoke-virtual {v1}, LGo/g;->e()Ljp/n;

    move-result-object v4

    invoke-virtual {p1}, LHo/k;->a0()Luo/e;

    move-result-object p1

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object v5

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->t()LJo/b;

    move-result-object v1

    invoke-interface {v1, v0}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object v6

    move-object v0, v4

    move-object v1, p1

    move-object v4, v5

    move-object v5, v6

    invoke-static/range {v0 .. v5}, Lxo/r;->M0(Ljp/n;Luo/e;LTo/f;Ljp/j;Lvo/h;Luo/S;)Lxo/r;

    move-result-object v3

    :cond_ea
    :goto_ea
    return-object v3
.end method
