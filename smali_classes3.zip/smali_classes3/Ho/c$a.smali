.class final LHo/c$a;
.super Lkotlin/jvm/internal/p;
.source "JvmPackageScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/c;-><init>(LGo/g;LKo/t;LHo/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "[",
        "Ldp/i;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/c;


# direct methods
.method constructor <init>(LHo/c;)V
    .registers 2

    iput-object p1, p0, LHo/c$a;->a:LHo/c;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 7

    iget-object v0, p0, LHo/c$a;->a:LHo/c;

    invoke-static {v0}, LHo/c;->i(LHo/c;)LHo/m;

    move-result-object v1

    invoke-virtual {v1}, LHo/m;->N0()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_19
    :goto_19
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LMo/w;

    invoke-static {v0}, LHo/c;->h(LHo/c;)LGo/g;

    move-result-object v4

    invoke-virtual {v4}, LGo/g;->a()LGo/c;

    move-result-object v4

    invoke-virtual {v4}, LGo/c;->b()LMo/n;

    move-result-object v4

    invoke-static {v0}, LHo/c;->i(LHo/c;)LHo/m;

    move-result-object v5

    invoke-virtual {v4, v5, v3}, LMo/n;->b(Lxo/I;LMo/w;)Lip/k;

    move-result-object v3

    if-eqz v3, :cond_19

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_19

    :cond_3f
    invoke-static {v2}, Lsp/a;->b(Ljava/util/ArrayList;)Ltp/c;

    move-result-object v0

    const/4 v1, 0x0

    new-array v1, v1, [Ldp/i;

    invoke-virtual {v0, v1}, Ltp/c;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ldp/i;

    return-object v0
.end method
