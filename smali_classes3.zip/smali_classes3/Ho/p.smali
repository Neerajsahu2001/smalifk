.class final LHo/p;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LYo/g<",
        "*>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/o;

.field final synthetic b:LKo/n;

.field final synthetic c:Lxo/L;


# direct methods
.method constructor <init>(LHo/o;LKo/n;Lxo/L;)V
    .registers 4

    iput-object p1, p0, LHo/p;->a:LHo/o;

    iput-object p2, p0, LHo/p;->b:LKo/n;

    iput-object p3, p0, LHo/p;->c:Lxo/L;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, LHo/p;->a:LHo/o;

    invoke-virtual {v0}, LHo/o;->t()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->g()LEo/h;

    move-result-object v0

    iget-object v1, p0, LHo/p;->b:LKo/n;

    iget-object v2, p0, LHo/p;->c:Lxo/L;

    invoke-interface {v0, v1, v2}, LEo/h;->a(LKo/n;Lxo/L;)V

    const/4 v0, 0x0

    return-object v0
.end method
