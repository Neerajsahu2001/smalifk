.class final LHo/n$d;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaPackageScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/n;-><init>(LGo/g;LKo/t;LHo/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Set<",
        "+",
        "Ljava/lang/String;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LGo/g;

.field final synthetic b:LHo/n;


# direct methods
.method constructor <init>(LGo/g;LHo/n;)V
    .registers 3

    iput-object p1, p0, LHo/n$d;->a:LGo/g;

    iput-object p2, p0, LHo/n$d;->b:LHo/n;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, LHo/n$d;->a:LGo/g;

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->d()LDo/r;

    move-result-object v0

    iget-object v1, p0, LHo/n$d;->b:LHo/n;

    invoke-virtual {v1}, LHo/n;->F()LHo/m;

    move-result-object v1

    invoke-virtual {v1}, Lxo/I;->c()LTo/c;

    move-result-object v1

    invoke-interface {v0, v1}, LDo/r;->a(LTo/c;)V

    const/4 v0, 0x0

    return-object v0
.end method
