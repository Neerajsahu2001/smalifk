.class public final LHo/d;
.super Ljava/lang/Object;
.source "LazyJavaAnnotationDescriptor.kt"

# interfaces
.implements Lvo/c;
.implements LFo/g;


# static fields
.field static final synthetic i:[Llo/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Llo/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:LGo/g;

.field private final b:LKo/a;

.field private final c:Ljp/k;

.field private final d:Ljp/j;

.field private final e:LJo/a;

.field private final f:Ljp/j;

.field private final g:Z

.field private final h:Z


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, Lkotlin/jvm/internal/x;

    const-class v1, LHo/d;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v2

    const-string v3, "fqName"

    const-string v4, "getFqName()Lorg/jetbrains/kotlin/name/FqName;"

    invoke-direct {v0, v2, v3, v4}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v0

    new-instance v2, Lkotlin/jvm/internal/x;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v3

    const-string v4, "type"

    const-string v5, "getType()Lorg/jetbrains/kotlin/types/SimpleType;"

    invoke-direct {v2, v3, v4, v5}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v2

    new-instance v3, Lkotlin/jvm/internal/x;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v1

    const-string v4, "allValueArguments"

    const-string v5, "getAllValueArguments()Ljava/util/Map;"

    invoke-direct {v3, v1, v4, v5}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v1

    const/4 v3, 0x3

    new-array v3, v3, [Llo/m;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    const/4 v0, 0x1

    aput-object v2, v3, v0

    const/4 v0, 0x2

    aput-object v1, v3, v0

    sput-object v3, LHo/d;->i:[Llo/m;

    return-void
.end method

.method public constructor <init>(LGo/g;LKo/a;Z)V
    .registers 6

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "javaAnnotation"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LHo/d;->a:LGo/g;

    iput-object p2, p0, LHo/d;->b:LKo/a;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object v0

    new-instance v1, LHo/d$b;

    invoke-direct {v1, p0}, LHo/d$b;-><init>(LHo/d;)V

    invoke-interface {v0, v1}, Ljp/n;->h(Leo/a;)Ljp/k;

    move-result-object v0

    iput-object v0, p0, LHo/d;->c:Ljp/k;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object v0

    new-instance v1, LHo/d$c;

    invoke-direct {v1, p0}, LHo/d$c;-><init>(LHo/d;)V

    invoke-interface {v0, v1}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object v0

    iput-object v0, p0, LHo/d;->d:Ljp/j;

    invoke-virtual {p1}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->t()LJo/b;

    move-result-object v0

    invoke-interface {v0, p2}, LJo/b;->a(LKo/l;)Lzo/j$a;

    move-result-object p2

    iput-object p2, p0, LHo/d;->e:LJo/a;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p1

    new-instance p2, LHo/d$a;

    invoke-direct {p2, p0}, LHo/d$a;-><init>(LHo/d;)V

    invoke-interface {p1, p2}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p1

    iput-object p1, p0, LHo/d;->f:Ljp/j;

    const/4 p1, 0x0

    iput-boolean p1, p0, LHo/d;->g:Z

    iput-boolean p3, p0, LHo/d;->h:Z

    return-void
.end method

.method public static final d(LHo/d;LTo/c;)Luo/e;
    .registers 3

    iget-object p0, p0, LHo/d;->a:LGo/g;

    invoke-virtual {p0}, LGo/g;->d()Luo/B;

    move-result-object v0

    invoke-static {p1}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object p1

    invoke-virtual {p0}, LGo/g;->a()LGo/c;

    move-result-object p0

    invoke-virtual {p0}, LGo/c;->b()LMo/n;

    move-result-object p0

    invoke-virtual {p0}, LMo/n;->d()Lgp/l;

    move-result-object p0

    invoke-virtual {p0}, Lgp/l;->q()Luo/D;

    move-result-object p0

    invoke-static {v0, p1, p0}, Luo/u;->c(Luo/B;LTo/b;Luo/D;)Luo/e;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic e(LHo/d;)LGo/g;
    .registers 1

    iget-object p0, p0, LHo/d;->a:LGo/g;

    return-object p0
.end method

.method public static final synthetic g(LHo/d;)LKo/a;
    .registers 1

    iget-object p0, p0, LHo/d;->b:LKo/a;

    return-object p0
.end method

.method public static final synthetic h(LHo/d;LKo/b;)LYo/g;
    .registers 2

    invoke-direct {p0, p1}, LHo/d;->j(LKo/b;)LYo/g;

    move-result-object p0

    return-object p0
.end method

.method private final j(LKo/b;)LYo/g;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LKo/b;",
            ")",
            "LYo/g<",
            "*>;"
        }
    .end annotation

    instance-of v0, p1, LKo/o;

    if-eqz v0, :cond_10

    check-cast p1, LKo/o;

    invoke-interface {p1}, LKo/o;->getValue()Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, LYo/h;->c(Ljava/lang/Object;)LYo/g;

    move-result-object p1

    goto/16 :goto_144

    :cond_10
    instance-of v0, p1, LKo/m;

    if-eqz v0, :cond_26

    check-cast p1, LKo/m;

    invoke-interface {p1}, LKo/m;->d()LTo/b;

    move-result-object v0

    invoke-interface {p1}, LKo/m;->e()LTo/f;

    move-result-object p1

    new-instance v1, LYo/j;

    invoke-direct {v1, v0, p1}, LYo/j;-><init>(LTo/b;LTo/f;)V

    :cond_23
    :goto_23
    move-object p1, v1

    goto/16 :goto_144

    :cond_26
    instance-of v0, p1, LKo/e;

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v3, p0, LHo/d;->a:LGo/g;

    if-eqz v0, :cond_b5

    check-cast p1, LKo/e;

    invoke-interface {p1}, LKo/b;->getName()LTo/f;

    move-result-object v0

    if-nez v0, :cond_38

    sget-object v0, LDo/E;->b:LTo/f;

    :cond_38
    const-string v4, "argument.name ?: DEFAULT_ANNOTATION_MEMBER_NAME"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, LKo/e;->c()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v4, LHo/d;->i:[Llo/m;

    const/4 v5, 0x1

    aget-object v4, v4, v5

    iget-object v5, p0, LHo/d;->d:Ljp/j;

    invoke-static {v5, v4}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lkp/M;

    const-string v5, "type"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, LHj/a;->l(Lkp/E;)Z

    move-result v4

    if-eqz v4, :cond_5a

    goto :goto_23

    :cond_5a
    invoke-static {p0}, Lap/c;->d(Lvo/c;)Luo/e;

    move-result-object v4

    invoke-static {v4}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-static {v0, v4}, LEo/b;->b(LTo/f;Luo/e;)Luo/b0;

    move-result-object v0

    if-eqz v0, :cond_6d

    invoke-interface {v0}, Luo/a0;->getType()Lkp/E;

    move-result-object v0

    if-nez v0, :cond_87

    :cond_6d
    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->m()Luo/B;

    move-result-object v0

    invoke-interface {v0}, Luo/B;->m()Lro/j;

    move-result-object v0

    sget-object v3, Lkp/w0;->INVARIANT:Lkp/w0;

    sget-object v4, Lmp/j;->UNKNOWN_ARRAY_ELEMENT_TYPE_OF_ANNOTATION_ARGUMENT:Lmp/j;

    new-array v2, v2, [Ljava/lang/String;

    invoke-static {v4, v2}, Lmp/k;->c(Lmp/j;[Ljava/lang/String;)Lmp/h;

    move-result-object v2

    invoke-virtual {v0, v2, v3}, Lro/j;->k(Lkp/v0;Lkp/w0;)Lkp/M;

    move-result-object v0

    :cond_87
    new-instance v2, Ljava/util/ArrayList;

    invoke-static {p1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_94
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_af

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LKo/b;

    invoke-direct {p0, v3}, LHo/d;->j(LKo/b;)LYo/g;

    move-result-object v3

    if-nez v3, :cond_ab

    new-instance v3, LYo/t;

    invoke-direct {v3, v1}, LYo/g;-><init>(Ljava/lang/Object;)V

    :cond_ab
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_94

    :cond_af
    invoke-static {v2, v0}, LYo/h;->a(Ljava/util/List;Lkp/E;)LYo/b;

    move-result-object p1

    goto/16 :goto_144

    :cond_b5
    instance-of v0, p1, LKo/c;

    if-eqz v0, :cond_cc

    check-cast p1, LKo/c;

    invoke-interface {p1}, LKo/c;->a()LAo/e;

    move-result-object p1

    new-instance v0, LYo/a;

    new-instance v1, LHo/d;

    invoke-direct {v1, v3, p1, v2}, LHo/d;-><init>(LGo/g;LKo/a;Z)V

    invoke-direct {v0, v1}, LYo/g;-><init>(Ljava/lang/Object;)V

    :goto_c9
    move-object p1, v0

    goto/16 :goto_144

    :cond_cc
    instance-of v0, p1, LKo/h;

    if-eqz v0, :cond_23

    check-cast p1, LKo/h;

    invoke-interface {p1}, LKo/h;->b()LAo/E;

    move-result-object p1

    invoke-virtual {v3}, LGo/g;->g()LIo/d;

    move-result-object v0

    sget-object v3, Lkp/s0;->COMMON:Lkp/s0;

    const/4 v4, 0x7

    invoke-static {v3, v2, v2, v1, v4}, Lj3/o;->w(Lkp/s0;ZZLxo/j;I)LIo/a;

    move-result-object v3

    invoke-virtual {v0, p1, v3}, LIo/d;->e(LKo/w;LIo/a;)Lkp/E;

    move-result-object p1

    invoke-static {p1}, LHj/a;->l(Lkp/E;)Z

    move-result v0

    if-eqz v0, :cond_ed

    goto/16 :goto_23

    :cond_ed
    move-object v0, p1

    const/4 v3, 0x0

    :goto_ef
    invoke-static {v0}, Lro/j;->V(Lkp/E;)Z

    move-result v4

    if-eqz v4, :cond_10b

    invoke-virtual {v0}, Lkp/E;->L0()Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->O(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkp/k0;

    invoke-interface {v0}, Lkp/k0;->getType()Lkp/E;

    move-result-object v0

    const-string v4, "type.arguments.single().type"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_ef

    :cond_10b
    invoke-virtual {v0}, Lkp/E;->N0()Lkp/e0;

    move-result-object v0

    invoke-interface {v0}, Lkp/e0;->n()Luo/h;

    move-result-object v0

    instance-of v4, v0, Luo/e;

    if-eqz v4, :cond_12f

    invoke-static {v0}, Lap/c;->f(Luo/h;)LTo/b;

    move-result-object v0

    if-nez v0, :cond_128

    new-instance v0, LYo/r;

    new-instance v1, LYo/r$a$a;

    invoke-direct {v1, p1}, LYo/r$a$a;-><init>(Lkp/E;)V

    invoke-direct {v0, v1}, LYo/g;-><init>(Ljava/lang/Object;)V

    goto :goto_c9

    :cond_128
    new-instance v1, LYo/r;

    invoke-direct {v1, v0, v3}, LYo/r;-><init>(LTo/b;I)V

    goto/16 :goto_23

    :cond_12f
    instance-of p1, v0, Luo/X;

    if-eqz p1, :cond_23

    new-instance v1, LYo/r;

    sget-object p1, Lro/n$a;->a:LTo/d;

    invoke-virtual {p1}, LTo/d;->l()LTo/c;

    move-result-object p1

    invoke-static {p1}, LTo/b;->m(LTo/c;)LTo/b;

    move-result-object p1

    invoke-direct {v1, p1, v2}, LYo/r;-><init>(LTo/b;I)V

    goto/16 :goto_23

    :goto_144
    return-object p1
.end method


# virtual methods
.method public final a()Ljava/util/Map;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "LTo/f;",
            "LYo/g<",
            "*>;>;"
        }
    .end annotation

    sget-object v0, LHo/d;->i:[Llo/m;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    iget-object v1, p0, LHo/d;->f:Ljp/j;

    invoke-static {v1, v0}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    return-object v0
.end method

.method public final b()Z
    .registers 2

    iget-boolean v0, p0, LHo/d;->g:Z

    return v0
.end method

.method public final c()LTo/c;
    .registers 4

    sget-object v0, LHo/d;->i:[Llo/m;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const-string v1, "<this>"

    iget-object v2, p0, LHo/d;->c:Ljp/k;

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "p"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v2}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LTo/c;

    return-object v0
.end method

.method public final f()Luo/S;
    .registers 2

    iget-object v0, p0, LHo/d;->e:LJo/a;

    return-object v0
.end method

.method public final getType()Lkp/E;
    .registers 3

    sget-object v0, LHo/d;->i:[Llo/m;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    iget-object v1, p0, LHo/d;->d:Ljp/j;

    invoke-static {v1, v0}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkp/M;

    return-object v0
.end method

.method public final i()Z
    .registers 2

    iget-boolean v0, p0, LHo/d;->h:Z

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    sget-object v0, LVo/c;->a:LVo/d;

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1}, LVo/d;->p(Lvo/c;Lvo/e;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
