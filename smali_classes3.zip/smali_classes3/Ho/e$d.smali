.class final LHo/e$d;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassDescriptor.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/e;-><init>(LGo/g;Luo/k;LKo/g;Luo/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "LKo/a;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/e;


# direct methods
.method constructor <init>(LHo/e;)V
    .registers 2

    iput-object p1, p0, LHo/e$d;->a:LHo/e;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, LHo/e$d;->a:LHo/e;

    invoke-static {v0}, Lap/c;->f(Luo/h;)LTo/b;

    move-result-object v1

    if-eqz v1, :cond_17

    invoke-virtual {v0}, LHo/e;->S0()LGo/g;

    move-result-object v0

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->f()LDo/w;

    move-result-object v0

    invoke-interface {v0, v1}, LDo/w;->a(LTo/b;)V

    :cond_17
    const/4 v0, 0x0

    return-object v0
.end method
