.class final LHo/i;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaClassMemberScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/f;",
        "Ljava/util/Collection<",
        "+",
        "Luo/Q;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/k;


# direct methods
.method constructor <init>(LHo/k;)V
    .registers 2

    iput-object p1, p0, LHo/i;->a:LHo/k;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, LTo/f;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/i;->a:LHo/k;

    invoke-static {v0, p1}, LHo/k;->J(LHo/k;LTo/f;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1
.end method
