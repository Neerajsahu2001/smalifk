.class final LHo/o$j;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/o;-><init>(LGo/g;LHo/o;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LTo/f;",
        "Ljava/util/List<",
        "+",
        "Luo/L;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/o;


# direct methods
.method constructor <init>(LHo/o;)V
    .registers 2

    iput-object p1, p0, LHo/o$j;->a:LHo/o;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, LTo/f;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, LHo/o$j;->a:LHo/o;

    invoke-static {v1}, LHo/o;->h(LHo/o;)Ljp/i;

    move-result-object v2

    invoke-interface {v2, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2, v0}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    invoke-virtual {v1, v0, p1}, LHo/o;->q(Ljava/util/ArrayList;LTo/f;)V

    invoke-virtual {v1}, LHo/o;->x()Luo/k;

    move-result-object p1

    invoke-static {p1}, LWo/i;->q(Luo/k;)Z

    move-result p1

    if-eqz p1, :cond_2b

    invoke-static {v0}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    goto :goto_43

    :cond_2b
    invoke-virtual {v1}, LHo/o;->t()LGo/g;

    move-result-object p1

    invoke-virtual {p1}, LGo/g;->a()LGo/c;

    move-result-object p1

    invoke-virtual {p1}, LGo/c;->r()LLo/s;

    move-result-object p1

    invoke-virtual {v1}, LHo/o;->t()LGo/g;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, LLo/s;->b(LGo/g;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/q;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    :goto_43
    return-object p1
.end method
