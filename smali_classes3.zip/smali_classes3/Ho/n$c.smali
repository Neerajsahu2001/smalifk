.class final LHo/n$c;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaPackageScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/n;-><init>(LGo/g;LKo/t;LHo/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LHo/n$a;",
        "Luo/e;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/n;

.field final synthetic b:LGo/g;


# direct methods
.method constructor <init>(LGo/g;LHo/n;)V
    .registers 3

    iput-object p2, p0, LHo/n$c;->a:LHo/n;

    iput-object p1, p0, LHo/n$c;->b:LGo/g;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    check-cast p1, LHo/n$a;

    const-string v0, "request"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, LTo/b;

    iget-object v1, p0, LHo/n$c;->a:LHo/n;

    invoke-virtual {v1}, LHo/n;->F()LHo/m;

    move-result-object v2

    invoke-virtual {v2}, Lxo/I;->c()LTo/c;

    move-result-object v2

    invoke-virtual {p1}, LHo/n$a;->b()LTo/f;

    move-result-object v3

    invoke-direct {v0, v2, v3}, LTo/b;-><init>(LTo/c;LTo/f;)V

    invoke-virtual {p1}, LHo/n$a;->a()LKo/g;

    move-result-object v2

    iget-object v3, p0, LHo/n$c;->b:LGo/g;

    if-eqz v2, :cond_33

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v2

    invoke-virtual {v2}, LGo/c;->j()LMo/u;

    move-result-object v2

    invoke-virtual {p1}, LHo/n$a;->a()LKo/g;

    move-result-object v4

    invoke-interface {v2, v4}, LMo/u;->a(LKo/g;)LMo/u$a$b;

    move-result-object v2

    goto :goto_3f

    :cond_33
    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v2

    invoke-virtual {v2}, LGo/c;->j()LMo/u;

    move-result-object v2

    invoke-interface {v2, v0}, LMo/u;->c(LTo/b;)LMo/u$a$b;

    move-result-object v2

    :goto_3f
    const/4 v4, 0x0

    if-eqz v2, :cond_47

    invoke-virtual {v2}, LMo/u$a$b;->a()LMo/w;

    move-result-object v5

    goto :goto_48

    :cond_47
    move-object v5, v4

    :goto_48
    if-eqz v5, :cond_4f

    invoke-interface {v5}, LMo/w;->d()LTo/b;

    move-result-object v6

    goto :goto_50

    :cond_4f
    move-object v6, v4

    :goto_50
    if-eqz v6, :cond_60

    invoke-virtual {v6}, LTo/b;->l()Z

    move-result v7

    if-nez v7, :cond_172

    invoke-virtual {v6}, LTo/b;->k()Z

    move-result v6

    if-eqz v6, :cond_60

    goto/16 :goto_172

    :cond_60
    if-nez v5, :cond_65

    sget-object v5, LHo/n$b$b;->a:LHo/n$b$b;

    goto :goto_a6

    :cond_65
    invoke-interface {v5}, LMo/w;->a()LNo/a;

    move-result-object v6

    invoke-virtual {v6}, LNo/a;->c()LNo/a$a;

    move-result-object v6

    sget-object v7, LNo/a$a;->CLASS:LNo/a$a;

    if-ne v6, v7, :cond_a4

    invoke-virtual {v1}, LHo/o;->t()LGo/g;

    move-result-object v6

    invoke-virtual {v6}, LGo/g;->a()LGo/c;

    move-result-object v6

    invoke-virtual {v6}, LGo/c;->b()LMo/n;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6, v5}, LMo/n;->g(LMo/w;)Lgp/h;

    move-result-object v7

    if-nez v7, :cond_88

    move-object v5, v4

    goto :goto_98

    :cond_88
    invoke-virtual {v6}, LMo/n;->d()Lgp/l;

    move-result-object v6

    invoke-virtual {v6}, Lgp/l;->f()Lgp/j;

    move-result-object v6

    invoke-interface {v5}, LMo/w;->d()LTo/b;

    move-result-object v5

    invoke-virtual {v6, v5, v7}, Lgp/j;->c(LTo/b;Lgp/h;)Luo/e;

    move-result-object v5

    :goto_98
    if-eqz v5, :cond_a1

    new-instance v6, LHo/n$b$a;

    invoke-direct {v6, v5}, LHo/n$b$a;-><init>(Luo/e;)V

    move-object v5, v6

    goto :goto_a6

    :cond_a1
    sget-object v5, LHo/n$b$b;->a:LHo/n$b$b;

    goto :goto_a6

    :cond_a4
    sget-object v5, LHo/n$b$c;->a:LHo/n$b$c;

    :goto_a6
    instance-of v6, v5, LHo/n$b$a;

    if-eqz v6, :cond_b2

    check-cast v5, LHo/n$b$a;

    invoke-virtual {v5}, LHo/n$b$a;->a()Luo/e;

    move-result-object v4

    goto/16 :goto_172

    :cond_b2
    instance-of v6, v5, LHo/n$b$c;

    if-eqz v6, :cond_b8

    goto/16 :goto_172

    :cond_b8
    instance-of v5, v5, LHo/n$b$b;

    if-eqz v5, :cond_173

    invoke-virtual {p1}, LHo/n$a;->a()LKo/g;

    move-result-object p1

    if-nez p1, :cond_dd

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object p1

    invoke-virtual {p1}, LGo/c;->d()LDo/r;

    move-result-object p1

    new-instance v5, LDo/r$a;

    if-eqz v2, :cond_d5

    instance-of v6, v2, LMo/u$a$a;

    if-nez v6, :cond_d3

    move-object v2, v4

    :cond_d3
    check-cast v2, LMo/u$a$a;

    :cond_d5
    const/4 v2, 0x4

    invoke-direct {v5, v0, v4, v2}, LDo/r$a;-><init>(LTo/b;LKo/g;I)V

    invoke-interface {p1, v5}, LDo/r;->b(LDo/r$a;)LAo/r;

    move-result-object p1

    :cond_dd
    sget-object v2, LKo/B;->BINARY:LKo/B;

    if-nez v2, :cond_13a

    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v5, "Couldn\'t find kotlin binary class for light class created by kotlin binary file\nJavaClass: "

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v5, "\nClassId: "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v5, "\nfindKotlinClass(JavaClass) = "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v5

    invoke-virtual {v5}, LGo/c;->j()LMo/u;

    move-result-object v5

    const-string v6, "<this>"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "javaClass"

    invoke-static {p1, v6}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v5, p1}, LMo/u;->a(LKo/g;)LMo/u$a$b;

    move-result-object p1

    if-eqz p1, :cond_116

    invoke-virtual {p1}, LMo/u$a$b;->a()LMo/w;

    move-result-object v4

    :cond_116
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, "\nfindKotlinClass(ClassId) = "

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object p1

    invoke-virtual {p1}, LGo/c;->j()LMo/u;

    move-result-object p1

    invoke-static {p1, v0}, LMo/v;->a(LMo/u;LTo/b;)LMo/w;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p1, 0xa

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_13a
    if-eqz p1, :cond_141

    invoke-interface {p1}, LKo/g;->c()LTo/c;

    move-result-object v0

    goto :goto_142

    :cond_141
    move-object v0, v4

    :goto_142
    if-eqz v0, :cond_172

    invoke-virtual {v0}, LTo/c;->d()Z

    move-result v2

    if-nez v2, :cond_172

    invoke-virtual {v0}, LTo/c;->e()LTo/c;

    move-result-object v0

    invoke-virtual {v1}, LHo/n;->F()LHo/m;

    move-result-object v2

    invoke-virtual {v2}, Lxo/I;->c()LTo/c;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15d

    goto :goto_172

    :cond_15d
    new-instance v0, LHo/e;

    invoke-virtual {v1}, LHo/n;->F()LHo/m;

    move-result-object v1

    invoke-direct {v0, v3, v1, p1, v4}, LHo/e;-><init>(LGo/g;Luo/k;LKo/g;Luo/e;)V

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object p1

    invoke-virtual {p1}, LGo/c;->e()LDo/s;

    move-result-object p1

    invoke-interface {p1, v0}, LDo/s;->a(LHo/e;)V

    move-object v4, v0

    :cond_172
    :goto_172
    return-object v4

    :cond_173
    new-instance p1, LMj/z;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, LMj/z;-><init>(I)V

    throw p1
.end method
