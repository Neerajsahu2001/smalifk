.class final LHo/u;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaStaticClassScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Ldp/i;",
        "Ljava/util/Collection<",
        "+",
        "Luo/L;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LTo/f;


# direct methods
.method constructor <init>(LTo/f;)V
    .registers 2

    iput-object p1, p0, LHo/u;->a:LTo/f;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Ldp/i;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LHo/u;->a:LTo/f;

    sget-object v1, LCo/c;->WHEN_GET_SUPER_MEMBERS:LCo/c;

    invoke-interface {p1, v0, v1}, Ldp/i;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method
