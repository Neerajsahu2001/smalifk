.class public final LHo/m;
.super Lxo/I;
.source "LazyJavaPackageFragment.kt"


# static fields
.field static final synthetic m:[Llo/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Llo/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final g:LKo/t;

.field private final h:LGo/g;

.field private final i:Ljp/j;

.field private final j:LHo/c;

.field private final k:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ljava/util/List<",
            "LTo/c;",
            ">;>;"
        }
    .end annotation
.end field

.field private final l:Lvo/h;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    new-instance v0, Lkotlin/jvm/internal/x;

    const-class v1, LHo/m;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v2

    const-string v3, "binaryClasses"

    const-string v4, "getBinaryClasses$descriptors_jvm()Ljava/util/Map;"

    invoke-direct {v0, v2, v3, v4}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v0

    new-instance v2, Lkotlin/jvm/internal/x;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v1

    const-string v3, "partToFacade"

    const-string v4, "getPartToFacade()Ljava/util/HashMap;"

    invoke-direct {v2, v1, v3, v4}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v1

    const/4 v2, 0x2

    new-array v2, v2, [Llo/m;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v0, 0x1

    aput-object v1, v2, v0

    sput-object v2, LHo/m;->m:[Llo/m;

    return-void
.end method

.method public constructor <init>(LGo/g;LKo/t;)V
    .registers 5

    const-string v0, "outerContext"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "jPackage"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LGo/g;->d()Luo/B;

    move-result-object v0

    invoke-interface {p2}, LKo/t;->c()LTo/c;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lxo/I;-><init>(Luo/B;LTo/c;)V

    iput-object p2, p0, LHo/m;->g:LKo/t;

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1, p0, v1, v0}, LGo/b;->a(LGo/g;Luo/g;LKo/y;I)LGo/g;

    move-result-object p1

    iput-object p1, p0, LHo/m;->h:LGo/g;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object v0

    new-instance v1, LHo/m$a;

    invoke-direct {v1, p0}, LHo/m$a;-><init>(LHo/m;)V

    invoke-interface {v0, v1}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object v0

    iput-object v0, p0, LHo/m;->i:Ljp/j;

    new-instance v0, LHo/c;

    invoke-direct {v0, p1, p2, p0}, LHo/c;-><init>(LGo/g;LKo/t;LHo/m;)V

    iput-object v0, p0, LHo/m;->j:LHo/c;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object v0

    new-instance v1, LHo/m$c;

    invoke-direct {v1, p0}, LHo/m$c;-><init>(LHo/m;)V

    invoke-interface {v0, v1}, Ljp/n;->g(Leo/a;)Ljp/j;

    move-result-object v0

    iput-object v0, p0, LHo/m;->k:Ljp/j;

    invoke-virtual {p1}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->i()LDo/z;

    move-result-object v0

    invoke-virtual {v0}, LDo/z;->b()Z

    move-result v0

    if-eqz v0, :cond_57

    invoke-static {}, Lvo/h$a;->b()Lvo/h$a$a;

    move-result-object p2

    goto :goto_5b

    :cond_57
    invoke-static {p1, p2}, Lcom/google/android/gms/internal/ads/c2;->e(LGo/g;LKo/d;)LGo/e;

    move-result-object p2

    :goto_5b
    iput-object p2, p0, LHo/m;->l:Lvo/h;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p1

    new-instance p2, LHo/m$b;

    invoke-direct {p2, p0}, LHo/m$b;-><init>(LHo/m;)V

    invoke-interface {p1, p2}, Ljp/n;->e(Leo/a;)Ljp/j;

    return-void
.end method

.method public static final synthetic I0(LHo/m;)LGo/g;
    .registers 1

    iget-object p0, p0, LHo/m;->h:LGo/g;

    return-object p0
.end method

.method public static final synthetic L0(LHo/m;)LKo/t;
    .registers 1

    iget-object p0, p0, LHo/m;->g:LKo/t;

    return-object p0
.end method


# virtual methods
.method public final M0(LKo/g;)Luo/e;
    .registers 3

    iget-object v0, p0, LHo/m;->j:LHo/c;

    invoke-virtual {v0}, LHo/c;->j()LHo/n;

    move-result-object v0

    invoke-virtual {v0, p1}, LHo/n;->D(LKo/g;)Luo/e;

    move-result-object p1

    return-object p1
.end method

.method public final N0()Ljava/util/Map;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LMo/w;",
            ">;"
        }
    .end annotation

    sget-object v0, LHo/m;->m:[Llo/m;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v1, p0, LHo/m;->i:Ljp/j;

    invoke-static {v1, v0}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    return-object v0
.end method

.method public final O0()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "LTo/c;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LHo/m;->k:Ljp/j;

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0
.end method

.method public final f()Luo/S;
    .registers 2

    new-instance v0, LMo/x;

    invoke-direct {v0, p0}, LMo/x;-><init>(LHo/m;)V

    return-object v0
.end method

.method public final getAnnotations()Lvo/h;
    .registers 2

    iget-object v0, p0, LHo/m;->l:Lvo/h;

    return-object v0
.end method

.method public final p()Ldp/i;
    .registers 2

    iget-object v0, p0, LHo/m;->j:LHo/c;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Lazy Java package fragment: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lxo/I;->c()LTo/c;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " of module "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LHo/m;->h:LGo/g;

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->m()Luo/B;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
