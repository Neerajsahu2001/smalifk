.class final LHo/o$h;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/o;-><init>(LGo/g;LHo/o;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Set<",
        "+",
        "LTo/f;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LHo/o;


# direct methods
.method constructor <init>(LHo/o;)V
    .registers 2

    iput-object p1, p0, LHo/o$h;->a:LHo/o;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    sget-object v0, Ldp/d;->p:Ldp/d;

    const/4 v1, 0x0

    iget-object v2, p0, LHo/o$h;->a:LHo/o;

    invoke-virtual {v2, v0, v1}, LHo/o;->l(Ldp/d;Leo/l;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method
