.class final LHo/v;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaStaticClassScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Ldp/i;",
        "Ljava/util/Collection<",
        "+",
        "LTo/f;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final a:LHo/v;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LHo/v;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LHo/v;->a:LHo/v;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ldp/i;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, Ldp/i;->d()Ljava/util/Set;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    return-object p1
.end method
