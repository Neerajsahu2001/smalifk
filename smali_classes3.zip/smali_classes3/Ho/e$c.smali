.class public final LHo/e$c;
.super Ljava/lang/Object;
.source "Comparisons.kt"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHo/e;->w()Ljava/util/Collection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    check-cast p1, Luo/e;

    invoke-static {p1}, Lap/c;->g(Luo/k;)LTo/c;

    move-result-object p1

    invoke-virtual {p1}, LTo/c;->b()Ljava/lang/String;

    move-result-object p1

    check-cast p2, Luo/e;

    invoke-static {p2}, Lap/c;->g(Luo/k;)LTo/c;

    move-result-object p2

    invoke-virtual {p2}, LTo/c;->b()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, LWn/a;->a(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result p1

    return p1
.end method
