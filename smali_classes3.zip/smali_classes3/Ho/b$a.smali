.class public final LHo/b$a;
.super Ljava/lang/Object;
.source "DeclaredMemberIndex.kt"

# interfaces
.implements LHo/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHo/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:LHo/b$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LHo/b$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LHo/b$a;->a:LHo/b$a;

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object v0
.end method

.method public final b(LTo/f;)LKo/v;
    .registers 3

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public final c(LTo/f;)Ljava/util/Collection;
    .registers 3

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    return-object p1
.end method

.method public final d()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object v0
.end method

.method public final e()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object v0
.end method

.method public final f(LTo/f;)LKo/n;
    .registers 3

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method
