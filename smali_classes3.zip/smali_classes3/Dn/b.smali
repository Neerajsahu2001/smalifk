.class public final Ldn/b;
.super Landroid/content/BroadcastReceiver;
.source "NetworkListener.kt"


# instance fields
.field private a:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field

.field private b:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    sget-object v0, Ldn/b$b;->a:Ldn/b$b;

    iput-object v0, p0, Ldn/b;->a:Leo/a;

    sget-object v0, Ldn/b$a;->a:Ldn/b$a;

    iput-object v0, p0, Ldn/b;->b:Leo/a;

    return-void
.end method


# virtual methods
.method public final a(Leo/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/a<",
            "LUn/r;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldn/b;->b:Leo/a;

    return-void
.end method

.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 4

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "intent"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "connectivity"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_30

    check-cast p1, Landroid/net/ConnectivityManager;

    invoke-virtual {p1}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p1

    if-eqz p1, :cond_26

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result p1

    if-eqz p1, :cond_26

    iget-object p1, p0, Ldn/b;->b:Leo/a;

    invoke-interface {p1}, Leo/a;->invoke()Ljava/lang/Object;

    goto :goto_2f

    :cond_26
    iget-object p1, p0, Ldn/b;->a:Leo/a;

    check-cast p1, Ldn/b$b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, LUn/r;->a:LUn/r;

    :goto_2f
    return-void

    :cond_30
    new-instance p1, LUn/o;

    const-string p2, "null cannot be cast to non-null type android.net.ConnectivityManager"

    invoke-direct {p1, p2}, Ljava/lang/ClassCastException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
