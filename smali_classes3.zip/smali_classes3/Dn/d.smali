.class public final Ldn/d;
.super Lbn/a;
.source "PlaybackResumer.kt"


# instance fields
.field private a:Z

.field private b:Z

.field private c:Lan/c;

.field private d:Ljava/lang/String;

.field private e:F


# virtual methods
.method public final a()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Ldn/d;->a:Z

    return-void
.end method

.method public final b()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldn/d;->a:Z

    return-void
.end method

.method public final c(Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/WebViewYouTubePlayer;)V
    .registers 6

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldn/d;->d:Ljava/lang/String;

    if-eqz v0, :cond_28

    iget-boolean v1, p0, Ldn/d;->b:Z

    if-eqz v1, :cond_1b

    iget-object v2, p0, Ldn/d;->c:Lan/c;

    sget-object v3, Lan/c;->HTML_5_PLAYER:Lan/c;

    if-ne v2, v3, :cond_1b

    iget-boolean v1, p0, Ldn/d;->a:Z

    iget v2, p0, Ldn/d;->e:F

    invoke-static {p1, v1, v0, v2}, Lkotlinx/coroutines/I;->g(Lan/e;ZLjava/lang/String;F)V

    goto :goto_28

    :cond_1b
    if-nez v1, :cond_28

    iget-object v1, p0, Ldn/d;->c:Lan/c;

    sget-object v2, Lan/c;->HTML_5_PLAYER:Lan/c;

    if-ne v1, v2, :cond_28

    iget v1, p0, Ldn/d;->e:F

    invoke-virtual {p1, v0, v1}, Lcom/pierfrancescosoffritti/androidyoutubeplayer/core/player/views/WebViewYouTubePlayer;->e(Ljava/lang/String;F)V

    :cond_28
    :goto_28
    const/4 p1, 0x0

    iput-object p1, p0, Ldn/d;->c:Lan/c;

    return-void
.end method

.method public final onCurrentSecond(Lan/e;F)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iput p2, p0, Ldn/d;->e:F

    return-void
.end method

.method public final onError(Lan/e;Lan/c;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "error"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lan/c;->HTML_5_PLAYER:Lan/c;

    if-ne p2, p1, :cond_10

    iput-object p2, p0, Ldn/d;->c:Lan/c;

    :cond_10
    return-void
.end method

.method public final onStateChange(Lan/e;Lan/d;)V
    .registers 5

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "state"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Ldn/c;->a:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    aget p1, p1, p2

    const/4 p2, 0x0

    const/4 v0, 0x1

    if-eq p1, v0, :cond_23

    const/4 v1, 0x2

    if-eq p1, v1, :cond_20

    const/4 p2, 0x3

    if-eq p1, p2, :cond_1d

    return-void

    :cond_1d
    iput-boolean v0, p0, Ldn/d;->b:Z

    return-void

    :cond_20
    iput-boolean p2, p0, Ldn/d;->b:Z

    return-void

    :cond_23
    iput-boolean p2, p0, Ldn/d;->b:Z

    return-void
.end method

.method public final onVideoId(Lan/e;Ljava/lang/String;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "videoId"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p2, p0, Ldn/d;->d:Ljava/lang/String;

    return-void
.end method
