.class final Ldn/b$b;
.super Lkotlin/jvm/internal/p;
.source "NetworkListener.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldn/b;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LUn/r;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Ldn/b$b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ldn/b$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, Ldn/b$b;->a:Ldn/b$b;

    return-void
.end method


# virtual methods
.method public final bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    sget-object v0, LUn/r;->a:LUn/r;

    return-object v0
.end method
