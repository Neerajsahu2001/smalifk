.class final Lap/a;
.super Ljava/lang/Object;

# interfaces
.implements Ltp/a$c;


# static fields
.field public static final a:Lap/a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lap/a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lap/a;->a:Lap/a;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Iterable;
    .registers 4

    check-cast p1, Luo/b0;

    sget v0, Lap/c;->a:I

    invoke-interface {p1}, Luo/a;->o()Ljava/util/Collection;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_17
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Luo/b0;

    invoke-interface {v1}, Luo/b0;->a()Luo/b0;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_17

    :cond_2b
    return-object v0
.end method
