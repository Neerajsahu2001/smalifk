.class public final LAp/r;
.super Ljava/lang/Object;
.source "SendingCollector.kt"

# interfaces
.implements Lzp/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lzp/c<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private final a:Lyp/w;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lyp/w<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lyp/w;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lyp/w<",
            "-TT;>;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAp/r;->a:Lyp/w;

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    iget-object v0, p0, LAp/r;->a:Lyp/w;

    invoke-interface {v0, p1, p2}, Lyp/w;->k(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_b

    return-object p1

    :cond_b
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
