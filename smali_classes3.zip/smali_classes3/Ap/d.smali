.class public final Lap/d;
.super Ltp/a$b;
.source "DescriptorUtils.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltp/a$b<",
        "Luo/b;",
        "Luo/b;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlin/jvm/internal/D;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/D<",
            "Luo/b;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:Leo/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/l<",
            "Luo/b;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/D;Leo/l;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/D<",
            "Luo/b;",
            ">;",
            "Leo/l<",
            "-",
            "Luo/b;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lap/d;->a:Lkotlin/jvm/internal/D;

    iput-object p2, p0, Lap/d;->b:Leo/l;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lap/d;->a:Lkotlin/jvm/internal/D;

    iget-object v0, v0, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    check-cast v0, Luo/b;

    return-object v0
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Luo/b;

    const-string v0, "current"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lap/d;->a:Lkotlin/jvm/internal/D;

    iget-object v1, v0, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    if-nez v1, :cond_1d

    iget-object v1, p0, Lap/d;->b:Leo/l;

    invoke-interface {v1, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1d

    iput-object p1, v0, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    :cond_1d
    return-void
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 3

    check-cast p1, Luo/b;

    const-string v0, "current"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Lap/d;->a:Lkotlin/jvm/internal/D;

    iget-object p1, p1, Lkotlin/jvm/internal/D;->a:Ljava/lang/Object;

    if-nez p1, :cond_f

    const/4 p1, 0x1

    goto :goto_10

    :cond_f
    const/4 p1, 0x0

    :goto_10
    return p1
.end method
