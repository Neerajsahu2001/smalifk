.class public final LAp/k;
.super Ljava/lang/Object;
.source "SafeCollector.kt"

# interfaces
.implements LXn/f;


# instance fields
.field public final a:Ljava/lang/Throwable;

.field private final synthetic b:LXn/f;


# direct methods
.method public constructor <init>(LXn/f;Ljava/lang/Throwable;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LAp/k;->a:Ljava/lang/Throwable;

    iput-object p1, p0, LAp/k;->b:LXn/f;

    return-void
.end method


# virtual methods
.method public final fold(Ljava/lang/Object;Leo/p;)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(TR;",
            "Leo/p<",
            "-TR;-",
            "LXn/f$a;",
            "+TR;>;)TR;"
        }
    .end annotation

    iget-object v0, p0, LAp/k;->b:LXn/f;

    invoke-interface {v0, p1, p2}, LXn/f;->fold(Ljava/lang/Object;Leo/p;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final get(LXn/f$b;)LXn/f$a;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E::",
            "LXn/f$a;",
            ">(",
            "LXn/f$b<",
            "TE;>;)TE;"
        }
    .end annotation

    iget-object v0, p0, LAp/k;->b:LXn/f;

    invoke-interface {v0, p1}, LXn/f;->get(LXn/f$b;)LXn/f$a;

    move-result-object p1

    return-object p1
.end method

.method public final minusKey(LXn/f$b;)LXn/f;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LXn/f$b<",
            "*>;)",
            "LXn/f;"
        }
    .end annotation

    iget-object v0, p0, LAp/k;->b:LXn/f;

    invoke-interface {v0, p1}, LXn/f;->minusKey(LXn/f$b;)LXn/f;

    move-result-object p1

    return-object p1
.end method

.method public final plus(LXn/f;)LXn/f;
    .registers 3

    iget-object v0, p0, LAp/k;->b:LXn/f;

    invoke-interface {v0, p1}, LXn/f;->plus(LXn/f;)LXn/f;

    move-result-object p1

    return-object p1
.end method
