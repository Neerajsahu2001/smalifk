.class public final LAp/n;
.super Ljava/lang/Object;
.source "NopCollector.kt"

# interfaces
.implements Lzp/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lzp/c<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LAp/n;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LAp/n;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LAp/n;->a:LAp/n;

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
