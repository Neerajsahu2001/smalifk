.class public final LAp/g;
.super Ljava/lang/Object;
.source "ChannelFlow.kt"


# direct methods
.method public static final a(LXn/f;Ljava/lang/Object;Ljava/lang/Object;Leo/p;LXn/d;)Ljava/lang/Object;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "LXn/f;",
            "TV;",
            "Ljava/lang/Object;",
            "Leo/p<",
            "-TV;-",
            "LXn/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LXn/d<",
            "-TT;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-static {p0, p2}, Lkotlinx/coroutines/internal/x;->c(LXn/f;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    :try_start_4
    new-instance v0, LAp/s;

    invoke-direct {v0, p4, p0}, LAp/s;-><init>(LXn/d;LXn/f;)V

    const/4 v1, 0x2

    invoke-static {v1, p3}, Lkotlin/jvm/internal/H;->c(ILjava/lang/Object;)V

    invoke-interface {p3, p1, v0}, Leo/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_11
    .catchall {:try_start_4 .. :try_end_11} :catchall_1e

    invoke-static {p0, p2}, Lkotlinx/coroutines/internal/x;->a(LXn/f;Ljava/lang/Object;)V

    sget-object p0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p0, :cond_1d

    const-string p0, "frame"

    invoke-static {p4, p0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1d
    return-object p1

    :catchall_1e
    move-exception p1

    invoke-static {p0, p2}, Lkotlinx/coroutines/internal/x;->a(LXn/f;Ljava/lang/Object;)V

    throw p1
.end method
