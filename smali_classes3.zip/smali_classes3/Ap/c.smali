.class public final Lap/c;
.super Ljava/lang/Object;
.source "DescriptorUtils.kt"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "value"

    invoke-static {v0}, LTo/f;->h(Ljava/lang/String;)LTo/f;

    return-void
.end method

.method public static final a(Luo/b0;)Z
    .registers 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    check-cast p0, Ljava/util/Collection;

    sget-object v0, Lap/a;->a:Lap/a;

    sget-object v1, Lap/c$a;->j:Lap/c$a;

    invoke-static {p0, v0, v1}, Ltp/a;->d(Ljava/util/Collection;Ltp/a$c;Leo/l;)Ljava/lang/Boolean;

    move-result-object p0

    const-string v0, "ifAny(\n        listOf(th\u2026eclaresDefaultValue\n    )"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public static b(Luo/b;Leo/l;)Luo/b;
    .registers 5

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "predicate"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lkotlin/jvm/internal/D;

    invoke-direct {v0}, Lkotlin/jvm/internal/D;-><init>()V

    invoke-static {p0}, Lkotlin/collections/q;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    check-cast p0, Ljava/util/Collection;

    new-instance v1, Lap/b;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Lap/b;-><init>(Z)V

    new-instance v2, Lap/d;

    invoke-direct {v2, v0, p1}, Lap/d;-><init>(Lkotlin/jvm/internal/D;Leo/l;)V

    invoke-static {p0, v1, v2}, Ltp/a;->b(Ljava/util/Collection;Ltp/a$c;Ltp/a$b;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Luo/b;

    return-object p0
.end method

.method public static final c(Luo/k;)LTo/c;
    .registers 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lap/c;->h(Luo/k;)LTo/d;

    move-result-object p0

    invoke-virtual {p0}, LTo/d;->f()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    goto :goto_12

    :cond_11
    move-object p0, v1

    :goto_12
    if-eqz p0, :cond_18

    invoke-virtual {p0}, LTo/d;->l()LTo/c;

    move-result-object v1

    :cond_18
    return-object v1
.end method

.method public static final d(Lvo/c;)Luo/e;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Lvo/c;->getType()Lkp/E;

    move-result-object p0

    invoke-virtual {p0}, Lkp/E;->N0()Lkp/e0;

    move-result-object p0

    invoke-interface {p0}, Lkp/e0;->n()Luo/h;

    move-result-object p0

    instance-of v0, p0, Luo/e;

    if-eqz v0, :cond_18

    check-cast p0, Luo/e;

    goto :goto_19

    :cond_18
    const/4 p0, 0x0

    :goto_19
    return-object p0
.end method

.method public static final e(Luo/k;)Lro/j;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lap/c;->j(Luo/k;)Luo/B;

    move-result-object p0

    invoke-interface {p0}, Luo/B;->m()Lro/j;

    move-result-object p0

    return-object p0
.end method

.method public static final f(Luo/h;)LTo/b;
    .registers 4

    const/4 v0, 0x0

    if-eqz p0, :cond_31

    invoke-interface {p0}, Luo/k;->d()Luo/k;

    move-result-object v1

    if-eqz v1, :cond_31

    instance-of v2, v1, Luo/E;

    if-eqz v2, :cond_1d

    new-instance v0, LTo/b;

    check-cast v1, Luo/E;

    invoke-interface {v1}, Luo/E;->c()LTo/c;

    move-result-object v1

    invoke-interface {p0}, Luo/k;->getName()LTo/f;

    move-result-object p0

    invoke-direct {v0, v1, p0}, LTo/b;-><init>(LTo/c;LTo/f;)V

    goto :goto_31

    :cond_1d
    instance-of v2, v1, Luo/i;

    if-eqz v2, :cond_31

    check-cast v1, Luo/h;

    invoke-static {v1}, Lap/c;->f(Luo/h;)LTo/b;

    move-result-object v1

    if-eqz v1, :cond_31

    invoke-interface {p0}, Luo/k;->getName()LTo/f;

    move-result-object p0

    invoke-virtual {v1, p0}, LTo/b;->d(LTo/f;)LTo/b;

    move-result-object v0

    :cond_31
    :goto_31
    return-object v0
.end method

.method public static final g(Luo/k;)LTo/c;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, LWo/i;->m(Luo/k;)LTo/c;

    move-result-object p0

    const-string v0, "getFqNameSafe(this)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static final h(Luo/k;)LTo/d;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, LWo/i;->l(Luo/k;)LTo/d;

    move-result-object p0

    const-string v0, "getFqName(this)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static final i(Luo/B;)Llp/f$a;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Llp/g;->a()Landroidx/media3/exoplayer/hls/v;

    move-result-object v0

    invoke-interface {p0, v0}, Luo/B;->S(Landroidx/media3/exoplayer/hls/v;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Llp/o;

    sget-object p0, Llp/f$a;->a:Llp/f$a;

    return-object p0
.end method

.method public static final j(Luo/k;)Luo/B;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, LWo/i;->f(Luo/k;)Luo/B;

    move-result-object p0

    const-string v0, "getContainingModule(this)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static final k(Luo/k;)Lup/h;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Luo/k;",
            ")",
            "Lup/h<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lap/e;->a:Lap/e;

    invoke-static {p0, v0}, Lup/k;->k(Ljava/lang/Object;Leo/l;)Lup/h;

    move-result-object p0

    const/4 v0, 0x1

    invoke-static {p0, v0}, Lup/k;->c(Lup/h;I)Lup/h;

    move-result-object p0

    return-object p0
.end method

.method public static final l(Luo/b;)Luo/b;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p0, Luo/K;

    if-eqz v0, :cond_14

    check-cast p0, Luo/K;

    invoke-interface {p0}, Luo/K;->V()Luo/L;

    move-result-object p0

    const-string v0, "correspondingProperty"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_14
    return-object p0
.end method
