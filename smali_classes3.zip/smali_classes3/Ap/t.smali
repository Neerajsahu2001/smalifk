.class final LAp/t;
.super Ljava/lang/Object;
.source "ChannelFlow.kt"

# interfaces
.implements Lzp/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lzp/c<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private final a:LXn/f;

.field private final b:Ljava/lang/Object;

.field private final c:Leo/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/p<",
            "TT;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lzp/c;LXn/f;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/c<",
            "-TT;>;",
            "LXn/f;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LAp/t;->a:LXn/f;

    invoke-static {p2}, Lkotlinx/coroutines/internal/x;->b(LXn/f;)Ljava/lang/Object;

    move-result-object p2

    iput-object p2, p0, LAp/t;->b:Ljava/lang/Object;

    new-instance p2, LAp/t$a;

    const/4 v0, 0x0

    invoke-direct {p2, p1, v0}, LAp/t$a;-><init>(Lzp/c;LXn/d;)V

    iput-object p2, p0, LAp/t;->c:Leo/p;

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    iget-object v0, p0, LAp/t;->c:Leo/p;

    iget-object v1, p0, LAp/t;->a:LXn/f;

    iget-object v2, p0, LAp/t;->b:Ljava/lang/Object;

    invoke-static {v1, p1, v2, v0, p2}, LAp/g;->a(LXn/f;Ljava/lang/Object;Ljava/lang/Object;Leo/p;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_f

    return-object p1

    :cond_f
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
