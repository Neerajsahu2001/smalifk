.class public final LAp/j;
.super LAp/i;
.source "ChannelFlow.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "LAp/i<",
        "TT;TT;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(Lzp/b;Lkotlinx/coroutines/scheduling/b;ILyp/f;I)V
    .registers 7

    and-int/lit8 v0, p5, 0x2

    if-eqz v0, :cond_6

    sget-object p2, LXn/h;->a:LXn/h;

    :cond_6
    and-int/lit8 v0, p5, 0x4

    if-eqz v0, :cond_b

    const/4 p3, -0x3

    :cond_b
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_11

    sget-object p4, Lyp/f;->SUSPEND:Lyp/f;

    :cond_11
    invoke-direct {p0, p1, p2, p3, p4}, LAp/i;-><init>(Lzp/b;LXn/f;ILyp/f;)V

    return-void
.end method


# virtual methods
.method protected final e(LXn/f;ILyp/f;)LAp/j;
    .registers 6

    new-instance v0, LAp/j;

    iget-object v1, p0, LAp/i;->d:Lzp/b;

    invoke-direct {v0, v1, p1, p2, p3}, LAp/i;-><init>(Lzp/b;LXn/f;ILyp/f;)V

    return-object v0
.end method
