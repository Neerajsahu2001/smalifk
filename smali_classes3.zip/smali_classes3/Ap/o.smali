.class public final LAp/o;
.super Lkotlin/coroutines/jvm/internal/c;
.source "SafeCollector.kt"

# interfaces
.implements Lzp/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlin/coroutines/jvm/internal/c;",
        "Lzp/c<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:Lzp/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lzp/c<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final b:LXn/f;

.field public final c:I

.field private d:LXn/f;

.field private e:LXn/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lzp/c;LXn/f;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/c<",
            "-TT;>;",
            "LXn/f;",
            ")V"
        }
    .end annotation

    sget-object v0, LAp/m;->a:LAp/m;

    sget-object v1, LXn/h;->a:LXn/h;

    invoke-direct {p0, v0, v1}, Lkotlin/coroutines/jvm/internal/c;-><init>(LXn/d;LXn/f;)V

    iput-object p1, p0, LAp/o;->a:Lzp/c;

    iput-object p2, p0, LAp/o;->b:LXn/f;

    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    sget-object v0, LAp/o$a;->a:LAp/o$a;

    invoke-interface {p2, p1, v0}, LXn/f;->fold(Ljava/lang/Object;Leo/p;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    iput p1, p0, LAp/o;->c:I

    return-void
.end method

.method private final a(LXn/d;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;TT;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-interface {p1}, LXn/d;->getContext()LXn/f;

    move-result-object v0

    invoke-static {v0}, Lkotlinx/coroutines/n0;->c(LXn/f;)V

    iget-object v1, p0, LAp/o;->d:LXn/f;

    if-eq v1, v0, :cond_7e

    instance-of v2, v1, LAp/k;

    if-nez v2, :cond_51

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    new-instance v2, LAp/q;

    invoke-direct {v2, p0}, LAp/q;-><init>(LAp/o;)V

    invoke-interface {v0, v1, v2}, LXn/f;->fold(Ljava/lang/Object;Leo/p;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    iget v2, p0, LAp/o;->c:I

    if-ne v1, v2, :cond_2a

    iput-object v0, p0, LAp/o;->d:LXn/f;

    goto :goto_7e

    :cond_2a
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v1, "Flow invariant is violated:\n\t\tFlow was collected in "

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LAp/o;->b:LXn/f;

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ",\n\t\tbut emission happened in "

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ".\n\t\tPlease refer to \'flow\' documentation or use \'flowOn\' instead"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_51
    check-cast v1, LAp/k;

    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "\n            Flow exception transparency is violated:\n                Previous \'emit\' call has thrown exception "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v1, LAp/k;->a:Ljava/lang/Throwable;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", but then emission attempt of value \'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, "\' has been detected.\n                Emissions from \'catch\' blocks are prohibited in order to avoid unspecified behaviour, \'Flow.catch\' operator can be used instead.\n                For a more detailed explanation, please refer to Flow documentation.\n            "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lvp/k;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7e
    :goto_7e
    iput-object p1, p0, LAp/o;->e:LXn/d;

    invoke-static {}, LAp/p;->a()Leo/q;

    move-result-object p1

    iget-object v0, p0, LAp/o;->a:Lzp/c;

    invoke-interface {p1, v0, p2, p0}, Leo/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_95

    const/4 p2, 0x0

    iput-object p2, p0, LAp/o;->e:LXn/d;

    :cond_95
    return-object p1
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    :try_start_0
    invoke-direct {p0, p2, p1}, LAp/o;->a(LXn/d;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_4
    .catchall {:try_start_0 .. :try_end_4} :catchall_c

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_9

    return-object p1

    :cond_9
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1

    :catchall_c
    move-exception p1

    new-instance v0, LAp/k;

    invoke-interface {p2}, LXn/d;->getContext()LXn/f;

    move-result-object p2

    invoke-direct {v0, p2, p1}, LAp/k;-><init>(LXn/f;Ljava/lang/Throwable;)V

    iput-object v0, p0, LAp/o;->d:LXn/f;

    throw p1
.end method

.method public final getCallerFrame()Lkotlin/coroutines/jvm/internal/d;
    .registers 3

    iget-object v0, p0, LAp/o;->e:LXn/d;

    instance-of v1, v0, Lkotlin/coroutines/jvm/internal/d;

    if-eqz v1, :cond_9

    check-cast v0, Lkotlin/coroutines/jvm/internal/d;

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    return-object v0
.end method

.method public final getContext()LXn/f;
    .registers 2

    iget-object v0, p0, LAp/o;->d:LXn/f;

    if-nez v0, :cond_6

    sget-object v0, LXn/h;->a:LXn/h;

    :cond_6
    return-object v0
.end method

.method public final getStackTraceElement()Ljava/lang/StackTraceElement;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    invoke-static {p1}, LUn/k;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_11

    new-instance v1, LAp/k;

    invoke-virtual {p0}, LAp/o;->getContext()LXn/f;

    move-result-object v2

    invoke-direct {v1, v2, v0}, LAp/k;-><init>(LXn/f;Ljava/lang/Throwable;)V

    iput-object v1, p0, LAp/o;->d:LXn/f;

    :cond_11
    iget-object v0, p0, LAp/o;->e:LXn/d;

    if-eqz v0, :cond_18

    invoke-interface {v0, p1}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    :cond_18
    sget-object p1, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    return-object p1
.end method

.method public final releaseIntercepted()V
    .registers 1

    invoke-super {p0}, Lkotlin/coroutines/jvm/internal/c;->releaseIntercepted()V

    return-void
.end method
