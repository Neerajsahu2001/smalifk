.class public final LAp/l$a;
.super Ljava/lang/Object;
.source "ChannelFlow.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAp/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(LAp/l;Lkotlinx/coroutines/scheduling/b;ILyp/f;I)Lzp/b;
    .registers 6

    and-int/lit8 v0, p4, 0x1

    if-eqz v0, :cond_6

    sget-object p1, LXn/h;->a:LXn/h;

    :cond_6
    and-int/lit8 v0, p4, 0x2

    if-eqz v0, :cond_b

    const/4 p2, -0x3

    :cond_b
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_11

    sget-object p3, Lyp/f;->SUSPEND:Lyp/f;

    :cond_11
    invoke-interface {p0, p1, p2, p3}, LAp/l;->a(LXn/f;ILyp/f;)Lzp/b;

    move-result-object p0

    return-object p0
.end method
