.class final LAp/s;
.super Ljava/lang/Object;
.source "ChannelFlow.kt"

# interfaces
.implements LXn/d;
.implements Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LXn/d<",
        "TT;>;",
        "Lkotlin/coroutines/jvm/internal/d;"
    }
.end annotation


# instance fields
.field private final a:LXn/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LXn/d<",
            "TT;>;"
        }
    .end annotation
.end field

.field private final b:LXn/f;


# direct methods
.method public constructor <init>(LXn/d;LXn/f;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LXn/d<",
            "-TT;>;",
            "LXn/f;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAp/s;->a:LXn/d;

    iput-object p2, p0, LAp/s;->b:LXn/f;

    return-void
.end method


# virtual methods
.method public final getCallerFrame()Lkotlin/coroutines/jvm/internal/d;
    .registers 3

    iget-object v0, p0, LAp/s;->a:LXn/d;

    instance-of v1, v0, Lkotlin/coroutines/jvm/internal/d;

    if-eqz v1, :cond_9

    check-cast v0, Lkotlin/coroutines/jvm/internal/d;

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    return-object v0
.end method

.method public final getContext()LXn/f;
    .registers 2

    iget-object v0, p0, LAp/s;->b:LXn/f;

    return-object v0
.end method

.method public final resumeWith(Ljava/lang/Object;)V
    .registers 3

    iget-object v0, p0, LAp/s;->a:LXn/d;

    invoke-interface {v0, p1}, LXn/d;->resumeWith(Ljava/lang/Object;)V

    return-void
.end method
