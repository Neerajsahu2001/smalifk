.class public interface abstract LAp/l;
.super Ljava/lang/Object;
.source "ChannelFlow.kt"

# interfaces
.implements Lzp/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAp/l$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lzp/b<",
        "TT;>;"
    }
.end annotation


# virtual methods
.method public abstract a(LXn/f;ILyp/f;)Lzp/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LXn/f;",
            "I",
            "Lyp/f;",
            ")",
            "Lzp/b<",
            "TT;>;"
        }
    .end annotation
.end method
