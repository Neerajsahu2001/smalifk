.class public final LAp/p;
.super Ljava/lang/Object;
.source "SafeCollector.kt"


# static fields
.field private static final a:Leo/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/q<",
            "Lzp/c<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Object;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget-object v0, LAp/p$a;->j:LAp/p$a;

    const/4 v1, 0x3

    invoke-static {v1, v0}, Lkotlin/jvm/internal/H;->c(ILjava/lang/Object;)V

    sput-object v0, LAp/p;->a:Leo/q;

    return-void
.end method

.method public static final synthetic a()Leo/q;
    .registers 1

    sget-object v0, LAp/p;->a:Leo/q;

    return-object v0
.end method
