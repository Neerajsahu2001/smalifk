.class final LAp/q;
.super Lkotlin/jvm/internal/p;
.source "SafeCollector.common.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/p<",
        "Ljava/lang/Integer;",
        "LXn/f$a;",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LAp/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LAp/o<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(LAp/o;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAp/o<",
            "*>;)V"
        }
    .end annotation

    iput-object p1, p0, LAp/q;->a:LAp/o;

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    check-cast p2, LXn/f$a;

    invoke-interface {p2}, LXn/f$a;->getKey()LXn/f$b;

    move-result-object v0

    iget-object v1, p0, LAp/q;->a:LAp/o;

    iget-object v1, v1, LAp/o;->b:LXn/f;

    invoke-interface {v1, v0}, LXn/f;->get(LXn/f$b;)LXn/f$a;

    move-result-object v1

    sget-object v2, Lkotlinx/coroutines/j0;->w0:Lkotlinx/coroutines/j0$b;

    if-eq v0, v2, :cond_24

    if-eq p2, v1, :cond_1d

    const/high16 p1, -0x80000000

    goto :goto_1f

    :cond_1d
    add-int/lit8 p1, p1, 0x1

    :goto_1f
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    goto :goto_3f

    :cond_24
    check-cast v1, Lkotlinx/coroutines/j0;

    check-cast p2, Lkotlinx/coroutines/j0;

    :goto_28
    const/4 v0, 0x0

    if-nez p2, :cond_2d

    move-object p2, v0

    goto :goto_34

    :cond_2d
    if-ne p2, v1, :cond_30

    goto :goto_34

    :cond_30
    instance-of v2, p2, Lkotlinx/coroutines/internal/t;

    if-nez v2, :cond_65

    :goto_34
    if-ne p2, v1, :cond_40

    if-nez v1, :cond_39

    goto :goto_3b

    :cond_39
    add-int/lit8 p1, p1, 0x1

    :goto_3b
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    :goto_3f
    return-object p1

    :cond_40
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, ", expected child of "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use \'channelFlow\' builder instead of \'flow\'"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_65
    check-cast p2, Lkotlinx/coroutines/internal/t;

    invoke-virtual {p2}, Lkotlinx/coroutines/p0;->I()Lkotlinx/coroutines/q;

    move-result-object p2

    if-eqz p2, :cond_72

    invoke-interface {p2}, Lkotlinx/coroutines/q;->getParent()Lkotlinx/coroutines/j0;

    move-result-object p2

    goto :goto_28

    :cond_72
    move-object p2, v0

    goto :goto_28
.end method
