.class final LAp/o$a;
.super Lkotlin/jvm/internal/p;
.source "SafeCollector.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAp/o;-><init>(Lzp/c;LXn/f;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/p<",
        "Ljava/lang/Integer;",
        "LXn/f$a;",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LAp/o$a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LAp/o$a;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LAp/o$a;->a:LAp/o$a;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    check-cast p2, LXn/f$a;

    add-int/lit8 p1, p1, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1
.end method
