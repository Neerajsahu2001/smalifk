.class public abstract LAp/i;
.super LAp/f;
.source "ChannelFlow.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        "T:",
        "Ljava/lang/Object;",
        ">",
        "LAp/f<",
        "TT;>;"
    }
.end annotation


# instance fields
.field protected final d:Lzp/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lzp/b<",
            "TS;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lzp/b;LXn/f;ILyp/f;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/b<",
            "+TS;>;",
            "LXn/f;",
            "I",
            "Lyp/f;",
            ")V"
        }
    .end annotation

    invoke-direct {p0, p2, p3, p4}, LAp/f;-><init>(LXn/f;ILyp/f;)V

    iput-object p1, p0, LAp/i;->d:Lzp/b;

    return-void
.end method


# virtual methods
.method public final b(Lzp/c;LXn/d;)Ljava/lang/Object;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/c<",
            "-TT;>;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    iget v0, p0, LAp/f;->b:I

    const/4 v1, -0x3

    if-ne v0, v1, :cond_6a

    invoke-interface {p2}, LXn/d;->getContext()LXn/f;

    move-result-object v0

    iget-object v1, p0, LAp/f;->a:LXn/f;

    invoke-interface {v0, v1}, LXn/f;->plus(LXn/f;)LXn/f;

    move-result-object v1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2b

    move-object v0, p0

    check-cast v0, LAp/j;

    iget-object v0, v0, LAp/i;->d:Lzp/b;

    invoke-interface {v0, p1, p2}, Lzp/b;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_23

    goto :goto_25

    :cond_23
    sget-object p1, LUn/r;->a:LUn/r;

    :goto_25
    if-ne p1, p2, :cond_28

    goto :goto_75

    :cond_28
    sget-object p1, LUn/r;->a:LUn/r;

    goto :goto_75

    :cond_2b
    sget-object v2, LXn/e;->b0:LXn/e$b;

    invoke-interface {v1, v2}, LXn/f;->get(LXn/f$b;)LXn/f$a;

    move-result-object v3

    invoke-interface {v0, v2}, LXn/f;->get(LXn/f$b;)LXn/f$a;

    move-result-object v0

    invoke-static {v3, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6a

    invoke-interface {p2}, LXn/d;->getContext()LXn/f;

    move-result-object v0

    instance-of v2, p1, LAp/r;

    if-eqz v2, :cond_44

    goto :goto_4f

    :cond_44
    instance-of v2, p1, LAp/n;

    if-eqz v2, :cond_49

    goto :goto_4f

    :cond_49
    new-instance v2, LAp/t;

    invoke-direct {v2, p1, v0}, LAp/t;-><init>(Lzp/c;LXn/f;)V

    move-object p1, v2

    :goto_4f
    new-instance v0, LAp/h;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, LAp/h;-><init>(LAp/i;LXn/d;)V

    invoke-static {v1}, Lkotlinx/coroutines/internal/x;->b(LXn/f;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, p1, v2, v0, p2}, LAp/g;->a(LXn/f;Ljava/lang/Object;Ljava/lang/Object;Leo/p;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_62

    goto :goto_64

    :cond_62
    sget-object p1, LUn/r;->a:LUn/r;

    :goto_64
    if-ne p1, p2, :cond_67

    goto :goto_75

    :cond_67
    sget-object p1, LUn/r;->a:LUn/r;

    goto :goto_75

    :cond_6a
    invoke-super {p0, p1, p2}, LAp/f;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_73

    goto :goto_75

    :cond_73
    sget-object p1, LUn/r;->a:LUn/r;

    :goto_75
    return-object p1
.end method

.method protected final d(Lyp/q;LXn/d;)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lyp/q<",
            "-TT;>;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    new-instance v0, LAp/r;

    invoke-direct {v0, p1}, LAp/r;-><init>(Lyp/w;)V

    move-object p1, p0

    check-cast p1, LAp/j;

    iget-object p1, p1, LAp/i;->d:Lzp/b;

    invoke-interface {p1, v0, p2}, Lzp/b;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_13

    goto :goto_15

    :cond_13
    sget-object p1, LUn/r;->a:LUn/r;

    :goto_15
    if-ne p1, p2, :cond_18

    goto :goto_1a

    :cond_18
    sget-object p1, LUn/r;->a:LUn/r;

    :goto_1a
    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, LAp/i;->d:Lzp/b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " -> "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-super {p0}, LAp/f;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
