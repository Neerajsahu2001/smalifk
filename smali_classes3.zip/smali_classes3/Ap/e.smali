.class final Lap/e;
.super Lkotlin/jvm/internal/p;
.source "DescriptorUtils.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Luo/k;",
        "Luo/k;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lap/e;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lap/e;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, Lap/e;->a:Lap/e;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Luo/k;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, Luo/k;->d()Luo/k;

    move-result-object p1

    return-object p1
.end method
