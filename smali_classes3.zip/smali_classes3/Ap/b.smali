.class final Lap/b;
.super Ljava/lang/Object;

# interfaces
.implements Ltp/a$c;


# instance fields
.field private final a:Z


# direct methods
.method public constructor <init>(Z)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lap/b;->a:Z

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Iterable;
    .registers 4

    check-cast p1, Luo/b;

    iget-boolean v0, p0, Lap/b;->a:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_f

    if-eqz p1, :cond_e

    invoke-interface {p1}, Luo/b;->a()Luo/b;

    move-result-object p1

    goto :goto_f

    :cond_e
    move-object p1, v1

    :cond_f
    :goto_f
    if-eqz p1, :cond_15

    invoke-interface {p1}, Luo/b;->o()Ljava/util/Collection;

    move-result-object v1

    :cond_15
    if-nez v1, :cond_1a

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    goto :goto_1d

    :cond_1a
    move-object p1, v1

    check-cast p1, Ljava/lang/Iterable;

    :goto_1d
    return-object p1
.end method
