.class final synthetic LAp/p$a;
.super Lkotlin/jvm/internal/m;
.source "SafeCollector.kt"

# interfaces
.implements Leo/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAp/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/m;",
        "Leo/q<",
        "Lzp/c<",
        "-",
        "Ljava/lang/Object;",
        ">;",
        "Ljava/lang/Object;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final j:LAp/p$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LAp/p$a;

    invoke-direct {v0}, LAp/p$a;-><init>()V

    sput-object v0, LAp/p$a;->j:LAp/p$a;

    return-void
.end method

.method constructor <init>()V
    .registers 7

    const-string v4, "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"

    const/4 v5, 0x0

    const/4 v1, 0x3

    const-class v2, Lzp/c;

    const-string v3, "emit"

    move-object v0, p0

    invoke-direct/range {v0 .. v5}, Lkotlin/jvm/internal/m;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lzp/c;

    check-cast p3, LXn/d;

    invoke-interface {p1, p2, p3}, Lzp/c;->emit(Ljava/lang/Object;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
