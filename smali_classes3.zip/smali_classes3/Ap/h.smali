.class final LAp/h;
.super Lkotlin/coroutines/jvm/internal/i;
.source "ChannelFlow.kt"

# interfaces
.implements Leo/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/i;",
        "Leo/p<",
        "Lzp/c<",
        "Ljava/lang/Object;",
        ">;",
        "LXn/d<",
        "-",
        "LUn/r;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/e;
    c = "kotlinx.coroutines.flow.internal.ChannelFlowOperator$collectWithContextUndispatched$2"
    f = "ChannelFlow.kt"
    l = {
        0x98
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field a:I

.field synthetic b:Ljava/lang/Object;

.field final synthetic c:LAp/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LAp/i<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(LAp/i;LXn/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAp/i<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;",
            "LXn/d<",
            "-",
            "LAp/h;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, LAp/h;->c:LAp/i;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/i;-><init>(ILXn/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LXn/d;)LXn/d;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LXn/d<",
            "*>;)",
            "LXn/d<",
            "LUn/r;",
            ">;"
        }
    .end annotation

    new-instance v0, LAp/h;

    iget-object v1, p0, LAp/h;->c:LAp/i;

    invoke-direct {v0, v1, p2}, LAp/h;-><init>(LAp/i;LXn/d;)V

    iput-object p1, v0, LAp/h;->b:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lzp/c;

    check-cast p2, LXn/d;

    invoke-virtual {p0, p1, p2}, LAp/h;->create(Ljava/lang/Object;LXn/d;)LXn/d;

    move-result-object p1

    check-cast p1, LAp/h;

    sget-object p2, LUn/r;->a:LUn/r;

    invoke-virtual {p1, p2}, LAp/h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    sget-object v0, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    iget v1, p0, LAp/h;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    goto :goto_30

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Landroidx/core/util/g;->o(Ljava/lang/Object;)V

    iget-object p1, p0, LAp/h;->b:Ljava/lang/Object;

    check-cast p1, Lzp/c;

    iput v2, p0, LAp/h;->a:I

    iget-object v1, p0, LAp/h;->c:LAp/i;

    check-cast v1, LAp/j;

    iget-object v1, v1, LAp/i;->d:Lzp/b;

    invoke-interface {v1, p1, p0}, Lzp/b;->b(Lzp/c;LXn/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_2b

    goto :goto_2d

    :cond_2b
    sget-object p1, LUn/r;->a:LUn/r;

    :goto_2d
    if-ne p1, v0, :cond_30

    return-object v0

    :cond_30
    :goto_30
    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1
.end method
