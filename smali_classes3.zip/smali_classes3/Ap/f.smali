.class public abstract LAp/f;
.super Ljava/lang/Object;
.source "ChannelFlow.kt"

# interfaces
.implements LAp/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LAp/l<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:LXn/f;

.field public final b:I

.field public final c:Lyp/f;


# direct methods
.method public constructor <init>(LXn/f;ILyp/f;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAp/f;->a:LXn/f;

    iput p2, p0, LAp/f;->b:I

    iput-object p3, p0, LAp/f;->c:Lyp/f;

    return-void
.end method


# virtual methods
.method public final a(LXn/f;ILyp/f;)Lzp/b;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LXn/f;",
            "I",
            "Lyp/f;",
            ")",
            "Lzp/b<",
            "TT;>;"
        }
    .end annotation

    iget-object v0, p0, LAp/f;->a:LXn/f;

    invoke-interface {p1, v0}, LXn/f;->plus(LXn/f;)LXn/f;

    move-result-object p1

    sget-object v1, Lyp/f;->SUSPEND:Lyp/f;

    iget-object v2, p0, LAp/f;->c:Lyp/f;

    iget v3, p0, LAp/f;->b:I

    if-eq p3, v1, :cond_f

    goto :goto_26

    :cond_f
    const/4 p3, -0x3

    if-ne v3, p3, :cond_13

    goto :goto_25

    :cond_13
    if-ne p2, p3, :cond_17

    :goto_15
    move p2, v3

    goto :goto_25

    :cond_17
    const/4 p3, -0x2

    if-ne v3, p3, :cond_1b

    goto :goto_25

    :cond_1b
    if-ne p2, p3, :cond_1e

    goto :goto_15

    :cond_1e
    add-int/2addr p2, v3

    if-ltz p2, :cond_22

    goto :goto_25

    :cond_22
    const p2, 0x7fffffff

    :goto_25
    move-object p3, v2

    :goto_26
    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_31

    if-ne p2, v3, :cond_31

    if-ne p3, v2, :cond_31

    return-object p0

    :cond_31
    invoke-virtual {p0, p1, p2, p3}, LAp/f;->e(LXn/f;ILyp/f;)LAp/j;

    move-result-object p1

    return-object p1
.end method

.method public b(Lzp/c;LXn/d;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lzp/c<",
            "-TT;>;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    new-instance v0, LAp/d;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p1, p0}, LAp/d;-><init>(LXn/d;Lzp/c;LAp/f;)V

    new-instance p1, Lkotlinx/coroutines/internal/t;

    invoke-interface {p2}, LXn/d;->getContext()LXn/f;

    move-result-object v1

    invoke-direct {p1, p2, v1}, Lkotlinx/coroutines/internal/t;-><init>(LXn/d;LXn/f;)V

    invoke-static {p1, p1, v0}, Lj3/o;->v(Lkotlinx/coroutines/internal/t;Lkotlinx/coroutines/internal/t;Leo/p;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, LYn/a;->COROUTINE_SUSPENDED:LYn/a;

    if-ne p1, p2, :cond_18

    goto :goto_1a

    :cond_18
    sget-object p1, LUn/r;->a:LUn/r;

    :goto_1a
    return-object p1
.end method

.method protected abstract d(Lyp/q;LXn/d;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lyp/q<",
            "-TT;>;",
            "LXn/d<",
            "-",
            "LUn/r;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method

.method protected abstract e(LXn/f;ILyp/f;)LAp/j;
.end method

.method public toString()Ljava/lang/String;
    .registers 8

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    sget-object v1, LXn/h;->a:LXn/h;

    iget-object v2, p0, LAp/f;->a:LXn/f;

    if-eq v2, v1, :cond_1d

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "context="

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1d
    const/4 v1, -0x3

    iget v2, p0, LAp/f;->b:I

    if-eq v2, v1, :cond_33

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "capacity="

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_33
    sget-object v1, Lyp/f;->SUSPEND:Lyp/f;

    iget-object v2, p0, LAp/f;->c:Lyp/f;

    if-eq v2, v1, :cond_4a

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "onBufferOverflow="

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4a
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x5b

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, ", "

    const/4 v2, 0x0

    const/16 v5, 0x3e

    invoke-static/range {v0 .. v5}, Lkotlin/collections/q;->z(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Leo/l;I)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x5d

    invoke-static {v6, v0, v1}, Landroidx/lifecycle/Z;->d(Ljava/lang/StringBuilder;Ljava/lang/String;C)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
