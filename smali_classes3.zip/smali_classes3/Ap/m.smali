.class final LAp/m;
.super Ljava/lang/Object;
.source "SafeCollector.kt"

# interfaces
.implements LXn/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LXn/d<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LAp/m;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LAp/m;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LAp/m;->a:LAp/m;

    return-void
.end method


# virtual methods
.method public final getContext()LXn/f;
    .registers 2

    sget-object v0, LXn/h;->a:LXn/h;

    return-object v0
.end method

.method public final resumeWith(Ljava/lang/Object;)V
    .registers 2

    return-void
.end method
