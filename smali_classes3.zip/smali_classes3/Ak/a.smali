.class final LAk/a;
.super LAk/b;
.source "PreJava9ReflectionAccessor.java"


# virtual methods
.method public final b(Ljava/lang/reflect/AccessibleObject;)V
    .registers 3

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    return-void
.end method
