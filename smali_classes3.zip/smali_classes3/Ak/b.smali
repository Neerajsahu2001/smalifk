.class public abstract LAk/b;
.super Ljava/lang/Object;
.source "ReflectionAccessor.java"


# static fields
.field private static final a:LAk/b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    invoke-static {}, Lcom/google/gson/internal/o;->a()I

    move-result v0

    const/16 v1, 0x9

    if-ge v0, v1, :cond_e

    new-instance v0, LAk/a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    goto :goto_13

    :cond_e
    new-instance v0, LAk/c;

    invoke-direct {v0}, LAk/c;-><init>()V

    :goto_13
    sput-object v0, LAk/b;->a:LAk/b;

    return-void
.end method

.method public static a()LAk/b;
    .registers 1

    sget-object v0, LAk/b;->a:LAk/b;

    return-object v0
.end method


# virtual methods
.method public abstract b(Ljava/lang/reflect/AccessibleObject;)V
.end method
