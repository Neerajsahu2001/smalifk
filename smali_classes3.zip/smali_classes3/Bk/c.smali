.class public LBk/c;
.super Ljava/lang/Object;
.source "JsonWriter.java"

# interfaces
.implements Ljava/io/Closeable;
.implements Ljava/io/Flushable;


# static fields
.field private static final j:[Ljava/lang/String;

.field private static final k:[Ljava/lang/String;


# instance fields
.field private final a:Ljava/io/Writer;

.field private b:[I

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Z

.field private g:Z

.field private h:Ljava/lang/String;

.field private i:Z


# direct methods
.method static constructor <clinit>()V
    .registers 6

    const/4 v0, 0x1

    const/16 v1, 0x80

    new-array v1, v1, [Ljava/lang/String;

    sput-object v1, LBk/c;->j:[Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_9
    const/16 v3, 0x1f

    if-gt v2, v3, :cond_21

    sget-object v3, LBk/c;->j:[Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-array v5, v0, [Ljava/lang/Object;

    aput-object v4, v5, v1

    const-string v4, "\\u%04x"

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v2

    add-int/2addr v2, v0

    goto :goto_9

    :cond_21
    sget-object v0, LBk/c;->j:[Ljava/lang/String;

    const/16 v1, 0x22

    const-string v2, "\\\""

    aput-object v2, v0, v1

    const/16 v1, 0x5c

    const-string v2, "\\\\"

    aput-object v2, v0, v1

    const/16 v1, 0x9

    const-string v2, "\\t"

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const-string v2, "\\b"

    aput-object v2, v0, v1

    const/16 v1, 0xa

    const-string v2, "\\n"

    aput-object v2, v0, v1

    const/16 v1, 0xd

    const-string v2, "\\r"

    aput-object v2, v0, v1

    const/16 v1, 0xc

    const-string v2, "\\f"

    aput-object v2, v0, v1

    invoke-virtual {v0}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    sput-object v0, LBk/c;->k:[Ljava/lang/String;

    const/16 v1, 0x3c

    const-string v2, "\\u003c"

    aput-object v2, v0, v1

    const/16 v1, 0x3e

    const-string v2, "\\u003e"

    aput-object v2, v0, v1

    const/16 v1, 0x26

    const-string v2, "\\u0026"

    aput-object v2, v0, v1

    const/16 v1, 0x3d

    const-string v2, "\\u003d"

    aput-object v2, v0, v1

    const/16 v1, 0x27

    const-string v2, "\\u0027"

    aput-object v2, v0, v1

    return-void
.end method

.method public constructor <init>(Ljava/io/Writer;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x20

    new-array v0, v0, [I

    iput-object v0, p0, LBk/c;->b:[I

    const/4 v0, 0x0

    iput v0, p0, LBk/c;->c:I

    const/4 v0, 0x6

    invoke-direct {p0, v0}, LBk/c;->o(I)V

    const-string v0, ":"

    iput-object v0, p0, LBk/c;->e:Ljava/lang/String;

    const/4 v0, 0x1

    iput-boolean v0, p0, LBk/c;->i:Z

    if-eqz p1, :cond_1c

    iput-object p1, p0, LBk/c;->a:Ljava/io/Writer;

    return-void

    :cond_1c
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "out == null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private A()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, LBk/c;->h:Ljava/lang/String;

    if-eqz v0, :cond_33

    invoke-direct {p0}, LBk/c;->n()I

    move-result v0

    const/4 v1, 0x5

    if-ne v0, v1, :cond_13

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    const/16 v1, 0x2c

    invoke-virtual {v0, v1}, Ljava/io/Writer;->write(I)V

    goto :goto_16

    :cond_13
    const/4 v1, 0x3

    if-ne v0, v1, :cond_2b

    :goto_16
    invoke-direct {p0}, LBk/c;->g()V

    iget-object v0, p0, LBk/c;->b:[I

    iget v1, p0, LBk/c;->c:I

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x4

    aput v2, v0, v1

    iget-object v0, p0, LBk/c;->h:Ljava/lang/String;

    invoke-direct {p0, v0}, LBk/c;->w(Ljava/lang/String;)V

    const/4 v0, 0x0

    iput-object v0, p0, LBk/c;->h:Ljava/lang/String;

    goto :goto_33

    :cond_2b
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Nesting problem."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_33
    :goto_33
    return-void
.end method

.method private c()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0}, LBk/c;->n()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eq v0, v1, :cond_49

    iget-object v3, p0, LBk/c;->a:Ljava/io/Writer;

    if-eq v0, v2, :cond_40

    const/4 v2, 0x4

    if-eq v0, v2, :cond_32

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eq v0, v2, :cond_2a

    if-ne v0, v3, :cond_22

    iget-boolean v0, p0, LBk/c;->f:Z

    if-eqz v0, :cond_1a

    goto :goto_2a

    :cond_1a
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "JSON must have only one top-level value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_22
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Nesting problem."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2a
    :goto_2a
    iget-object v0, p0, LBk/c;->b:[I

    iget v2, p0, LBk/c;->c:I

    sub-int/2addr v2, v1

    aput v3, v0, v2

    goto :goto_53

    :cond_32
    iget-object v0, p0, LBk/c;->e:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/io/Writer;->append(Ljava/lang/CharSequence;)Ljava/io/Writer;

    iget-object v0, p0, LBk/c;->b:[I

    iget v2, p0, LBk/c;->c:I

    sub-int/2addr v2, v1

    const/4 v1, 0x5

    aput v1, v0, v2

    goto :goto_53

    :cond_40
    const/16 v0, 0x2c

    invoke-virtual {v3, v0}, Ljava/io/Writer;->append(C)Ljava/io/Writer;

    invoke-direct {p0}, LBk/c;->g()V

    goto :goto_53

    :cond_49
    iget-object v0, p0, LBk/c;->b:[I

    iget v3, p0, LBk/c;->c:I

    sub-int/2addr v3, v1

    aput v2, v0, v3

    invoke-direct {p0}, LBk/c;->g()V

    :goto_53
    return-void
.end method

.method private e(IILjava/lang/String;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0}, LBk/c;->n()I

    move-result v0

    if-eq v0, p2, :cond_11

    if-ne v0, p1, :cond_9

    goto :goto_11

    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Nesting problem."

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_11
    :goto_11
    iget-object p1, p0, LBk/c;->h:Ljava/lang/String;

    if-nez p1, :cond_26

    iget p1, p0, LBk/c;->c:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, LBk/c;->c:I

    if-ne v0, p2, :cond_20

    invoke-direct {p0}, LBk/c;->g()V

    :cond_20
    iget-object p1, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {p1, p3}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-void

    :cond_26
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Dangling name: "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p3, p0, LBk/c;->h:Ljava/lang/String;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private g()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, LBk/c;->d:Ljava/lang/String;

    if-nez v0, :cond_5

    return-void

    :cond_5
    const-string v0, "\n"

    iget-object v1, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    iget v0, p0, LBk/c;->c:I

    const/4 v2, 0x1

    :goto_f
    if-ge v2, v0, :cond_19

    iget-object v3, p0, LBk/c;->d:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_f

    :cond_19
    return-void
.end method

.method private n()I
    .registers 3

    iget v0, p0, LBk/c;->c:I

    if-eqz v0, :cond_b

    iget-object v1, p0, LBk/c;->b:[I

    add-int/lit8 v0, v0, -0x1

    aget v0, v1, v0

    return v0

    :cond_b
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "JsonWriter is closed."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private o(I)V
    .registers 6

    iget v0, p0, LBk/c;->c:I

    iget-object v1, p0, LBk/c;->b:[I

    array-length v2, v1

    if-ne v0, v2, :cond_11

    mul-int/lit8 v2, v0, 0x2

    new-array v2, v2, [I

    const/4 v3, 0x0

    invoke-static {v1, v3, v2, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v2, p0, LBk/c;->b:[I

    :cond_11
    iget-object v0, p0, LBk/c;->b:[I

    iget v1, p0, LBk/c;->c:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, LBk/c;->c:I

    aput p1, v0, v1

    return-void
.end method

.method private w(Ljava/lang/String;)V
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-boolean v0, p0, LBk/c;->g:Z

    if-eqz v0, :cond_7

    sget-object v0, LBk/c;->k:[Ljava/lang/String;

    goto :goto_9

    :cond_7
    sget-object v0, LBk/c;->j:[Ljava/lang/String;

    :goto_9
    iget-object v1, p0, LBk/c;->a:Ljava/io/Writer;

    const-string v2, "\""

    invoke-virtual {v1, v2}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_16
    if-ge v4, v3, :cond_41

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/16 v7, 0x80

    if-ge v6, v7, :cond_25

    aget-object v6, v0, v6

    if-nez v6, :cond_32

    goto :goto_3e

    :cond_25
    const/16 v7, 0x2028

    if-ne v6, v7, :cond_2c

    const-string v6, "\\u2028"

    goto :goto_32

    :cond_2c
    const/16 v7, 0x2029

    if-ne v6, v7, :cond_3e

    const-string v6, "\\u2029"

    :cond_32
    :goto_32
    if-ge v5, v4, :cond_39

    sub-int v7, v4, v5

    invoke-virtual {v1, p1, v5, v7}, Ljava/io/Writer;->write(Ljava/lang/String;II)V

    :cond_39
    invoke-virtual {v1, v6}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    add-int/lit8 v5, v4, 0x1

    :cond_3e
    :goto_3e
    add-int/lit8 v4, v4, 0x1

    goto :goto_16

    :cond_41
    if-ge v5, v3, :cond_47

    sub-int/2addr v3, v5

    invoke-virtual {v1, p1, v5, v3}, Ljava/io/Writer;->write(Ljava/lang/String;II)V

    :cond_47
    invoke-virtual {v1, v2}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public beginArray()LBk/c;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0}, LBk/c;->A()V

    invoke-direct {p0}, LBk/c;->c()V

    const/4 v0, 0x1

    invoke-direct {p0, v0}, LBk/c;->o(I)V

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    const-string v1, "["

    invoke-virtual {v0, v1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-object p0
.end method

.method public beginObject()LBk/c;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0}, LBk/c;->A()V

    invoke-direct {p0}, LBk/c;->c()V

    const/4 v0, 0x3

    invoke-direct {p0, v0}, LBk/c;->o(I)V

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    const-string v1, "{"

    invoke-virtual {v0, v1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-object p0
.end method

.method public close()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->close()V

    iget v0, p0, LBk/c;->c:I

    const/4 v1, 0x1

    if-gt v0, v1, :cond_18

    if-ne v0, v1, :cond_14

    iget-object v2, p0, LBk/c;->b:[I

    sub-int/2addr v0, v1

    aget v0, v2, v0

    const/4 v1, 0x7

    if-ne v0, v1, :cond_18

    :cond_14
    const/4 v0, 0x0

    iput v0, p0, LBk/c;->c:I

    return-void

    :cond_18
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Incomplete document"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public endArray()LBk/c;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v0, "]"

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, v1, v2, v0}, LBk/c;->e(IILjava/lang/String;)V

    return-object p0
.end method

.method public endObject()LBk/c;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v0, "}"

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, v1, v2, v0}, LBk/c;->e(IILjava/lang/String;)V

    return-object p0
.end method

.method public flush()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/c;->c:I

    if-eqz v0, :cond_a

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->flush()V

    return-void

    :cond_a
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "JsonWriter is closed."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final getSerializeNulls()Z
    .registers 2

    iget-boolean v0, p0, LBk/c;->i:Z

    return v0
.end method

.method public final isHtmlSafe()Z
    .registers 2

    iget-boolean v0, p0, LBk/c;->g:Z

    return v0
.end method

.method public isLenient()Z
    .registers 2

    iget-boolean v0, p0, LBk/c;->f:Z

    return v0
.end method

.method public jsonValue(Ljava/lang/String;)LBk/c;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p1, :cond_7

    invoke-virtual {p0}, LBk/c;->nullValue()LBk/c;

    move-result-object p1

    return-object p1

    :cond_7
    invoke-direct {p0}, LBk/c;->A()V

    invoke-direct {p0}, LBk/c;->c()V

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {v0, p1}, Ljava/io/Writer;->append(Ljava/lang/CharSequence;)Ljava/io/Writer;

    return-object p0
.end method

.method public name(Ljava/lang/String;)LBk/c;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-eqz p1, :cond_1b

    iget-object v0, p0, LBk/c;->h:Ljava/lang/String;

    if-nez v0, :cond_15

    iget v0, p0, LBk/c;->c:I

    if-eqz v0, :cond_d

    iput-object p1, p0, LBk/c;->h:Ljava/lang/String;

    return-object p0

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "JsonWriter is closed."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    throw p1

    :cond_1b
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "name == null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public nullValue()LBk/c;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, LBk/c;->h:Ljava/lang/String;

    if-eqz v0, :cond_10

    iget-boolean v0, p0, LBk/c;->i:Z

    if-eqz v0, :cond_c

    invoke-direct {p0}, LBk/c;->A()V

    goto :goto_10

    :cond_c
    const/4 v0, 0x0

    iput-object v0, p0, LBk/c;->h:Ljava/lang/String;

    return-object p0

    :cond_10
    :goto_10
    invoke-direct {p0}, LBk/c;->c()V

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    const-string v1, "null"

    invoke-virtual {v0, v1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-object p0
.end method

.method public final setHtmlSafe(Z)V
    .registers 2

    iput-boolean p1, p0, LBk/c;->g:Z

    return-void
.end method

.method public final setIndent(Ljava/lang/String;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_e

    const/4 p1, 0x0

    iput-object p1, p0, LBk/c;->d:Ljava/lang/String;

    const-string p1, ":"

    iput-object p1, p0, LBk/c;->e:Ljava/lang/String;

    goto :goto_14

    :cond_e
    iput-object p1, p0, LBk/c;->d:Ljava/lang/String;

    const-string p1, ": "

    iput-object p1, p0, LBk/c;->e:Ljava/lang/String;

    :goto_14
    return-void
.end method

.method public final setLenient(Z)V
    .registers 2

    iput-boolean p1, p0, LBk/c;->f:Z

    return-void
.end method

.method public final setSerializeNulls(Z)V
    .registers 2

    iput-boolean p1, p0, LBk/c;->i:Z

    return-void
.end method

.method public value(D)LBk/c;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0}, LBk/c;->A()V

    iget-boolean v0, p0, LBk/c;->f:Z

    if-nez v0, :cond_28

    invoke-static {p1, p2}, Ljava/lang/Double;->isNaN(D)Z

    move-result v0

    if-nez v0, :cond_14

    invoke-static {p1, p2}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v0

    if-nez v0, :cond_14

    goto :goto_28

    :cond_14
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Numeric values must be finite, but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_28
    :goto_28
    invoke-direct {p0}, LBk/c;->c()V

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-static {p1, p2}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/io/Writer;->append(Ljava/lang/CharSequence;)Ljava/io/Writer;

    return-object p0
.end method

.method public value(J)LBk/c;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0}, LBk/c;->A()V

    invoke-direct {p0}, LBk/c;->c()V

    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-static {p1, p2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-object p0
.end method

.method public value(Ljava/lang/Boolean;)LBk/c;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p1, :cond_7

    invoke-virtual {p0}, LBk/c;->nullValue()LBk/c;

    move-result-object p1

    return-object p1

    :cond_7
    invoke-direct {p0}, LBk/c;->A()V

    invoke-direct {p0}, LBk/c;->c()V

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_16

    const-string p1, "true"

    goto :goto_18

    :cond_16
    const-string p1, "false"

    :goto_18
    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {v0, p1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-object p0
.end method

.method public value(Ljava/lang/Number;)LBk/c;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p1, :cond_7

    invoke-virtual {p0}, LBk/c;->nullValue()LBk/c;

    move-result-object p1

    return-object p1

    :cond_7
    invoke-direct {p0}, LBk/c;->A()V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    iget-boolean v1, p0, LBk/c;->f:Z

    if-nez v1, :cond_3f

    const-string v1, "-Infinity"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b

    const-string v1, "Infinity"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b

    const-string v1, "NaN"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b

    goto :goto_3f

    :cond_2b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Numeric values must be finite, but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3f
    :goto_3f
    invoke-direct {p0}, LBk/c;->c()V

    iget-object p1, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {p1, v0}, Ljava/io/Writer;->append(Ljava/lang/CharSequence;)Ljava/io/Writer;

    return-object p0
.end method

.method public value(Ljava/lang/String;)LBk/c;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p1, :cond_7

    invoke-virtual {p0}, LBk/c;->nullValue()LBk/c;

    move-result-object p1

    return-object p1

    :cond_7
    invoke-direct {p0}, LBk/c;->A()V

    invoke-direct {p0}, LBk/c;->c()V

    invoke-direct {p0, p1}, LBk/c;->w(Ljava/lang/String;)V

    return-object p0
.end method

.method public value(Z)LBk/c;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-direct {p0}, LBk/c;->A()V

    invoke-direct {p0}, LBk/c;->c()V

    if-eqz p1, :cond_b

    const-string p1, "true"

    goto :goto_d

    :cond_b
    const-string p1, "false"

    :goto_d
    iget-object v0, p0, LBk/c;->a:Ljava/io/Writer;

    invoke-virtual {v0, p1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-object p0
.end method
