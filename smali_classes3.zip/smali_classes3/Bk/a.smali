.class public LBk/a;
.super Ljava/lang/Object;
.source "JsonReader.java"

# interfaces
.implements Ljava/io/Closeable;


# static fields
.field private static final p:[C


# instance fields
.field private final a:Ljava/io/Reader;

.field private b:Z

.field private final c:[C

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field h:I

.field private i:J

.field private j:I

.field private k:Ljava/lang/String;

.field private l:[I

.field private m:I

.field private n:[Ljava/lang/String;

.field private o:[I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, ")]}\'\n"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    sput-object v0, LBk/a;->p:[C

    new-instance v0, LBk/a$a;

    invoke-direct {v0}, Lcom/google/gson/internal/p;-><init>()V

    sput-object v0, Lcom/google/gson/internal/p;->a:Lcom/google/gson/internal/p;

    return-void
.end method

.method public constructor <init>(Ljava/io/Reader;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, LBk/a;->b:Z

    const/16 v1, 0x400

    new-array v1, v1, [C

    iput-object v1, p0, LBk/a;->c:[C

    iput v0, p0, LBk/a;->d:I

    iput v0, p0, LBk/a;->e:I

    iput v0, p0, LBk/a;->f:I

    iput v0, p0, LBk/a;->g:I

    iput v0, p0, LBk/a;->h:I

    const/16 v1, 0x20

    new-array v2, v1, [I

    iput-object v2, p0, LBk/a;->l:[I

    const/4 v3, 0x1

    iput v3, p0, LBk/a;->m:I

    const/4 v3, 0x6

    aput v3, v2, v0

    new-array v0, v1, [Ljava/lang/String;

    iput-object v0, p0, LBk/a;->n:[Ljava/lang/String;

    new-array v0, v1, [I

    iput-object v0, p0, LBk/a;->o:[I

    if-eqz p1, :cond_2f

    iput-object p1, p0, LBk/a;->a:Ljava/io/Reader;

    return-void

    :cond_2f
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "in == null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private A(C)Ljava/lang/String;
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x0

    move-object v1, v0

    :goto_2
    iget v2, p0, LBk/a;->d:I

    iget v3, p0, LBk/a;->e:I

    :goto_6
    move v4, v3

    move v3, v2

    :goto_8
    const/4 v5, 0x1

    const/16 v6, 0x10

    iget-object v7, p0, LBk/a;->c:[C

    if-ge v2, v4, :cond_5b

    add-int/lit8 v8, v2, 0x1

    aget-char v2, v7, v2

    if-ne v2, p1, :cond_29

    iput v8, p0, LBk/a;->d:I

    sub-int/2addr v8, v3

    sub-int/2addr v8, v5

    if-nez v1, :cond_21

    new-instance p1, Ljava/lang/String;

    invoke-direct {p1, v7, v3, v8}, Ljava/lang/String;-><init>([CII)V

    return-object p1

    :cond_21
    invoke-virtual {v1, v7, v3, v8}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_29
    const/16 v9, 0x5c

    if-ne v2, v9, :cond_4e

    iput v8, p0, LBk/a;->d:I

    sub-int/2addr v8, v3

    add-int/lit8 v2, v8, -0x1

    if-nez v1, :cond_3f

    mul-int/lit8 v8, v8, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-static {v8, v6}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    :cond_3f
    invoke-virtual {v1, v7, v3, v2}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    invoke-direct {p0}, LBk/a;->T()C

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget v2, p0, LBk/a;->d:I

    iget v3, p0, LBk/a;->e:I

    goto :goto_6

    :cond_4e
    const/16 v6, 0xa

    if-ne v2, v6, :cond_59

    iget v2, p0, LBk/a;->f:I

    add-int/2addr v2, v5

    iput v2, p0, LBk/a;->f:I

    iput v8, p0, LBk/a;->g:I

    :cond_59
    move v2, v8

    goto :goto_8

    :cond_5b
    if-nez v1, :cond_6b

    sub-int v1, v2, v3

    mul-int/lit8 v1, v1, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    move-object v1, v4

    :cond_6b
    sub-int v4, v2, v3

    invoke-virtual {v1, v7, v3, v4}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    iput v2, p0, LBk/a;->d:I

    invoke-direct {p0, v5}, LBk/a;->m(I)Z

    move-result v2

    if-eqz v2, :cond_79

    goto :goto_2

    :cond_79
    const-string p1, "Unterminated string"

    invoke-direct {p0, p1}, LBk/a;->a0(Ljava/lang/String;)V

    throw v0
.end method

.method private N()Ljava/lang/String;
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    :cond_2
    const/4 v2, 0x0

    :goto_3
    iget v3, p0, LBk/a;->d:I

    add-int v4, v3, v2

    iget v5, p0, LBk/a;->e:I

    iget-object v6, p0, LBk/a;->c:[C

    if-ge v4, v5, :cond_4e

    add-int/2addr v3, v2

    aget-char v3, v6, v3

    const/16 v4, 0x9

    if-eq v3, v4, :cond_5a

    const/16 v4, 0xa

    if-eq v3, v4, :cond_5a

    const/16 v4, 0xc

    if-eq v3, v4, :cond_5a

    const/16 v4, 0xd

    if-eq v3, v4, :cond_5a

    const/16 v4, 0x20

    if-eq v3, v4, :cond_5a

    const/16 v4, 0x23

    if-eq v3, v4, :cond_4a

    const/16 v4, 0x2c

    if-eq v3, v4, :cond_5a

    const/16 v4, 0x2f

    if-eq v3, v4, :cond_4a

    const/16 v4, 0x3d

    if-eq v3, v4, :cond_4a

    const/16 v4, 0x7b

    if-eq v3, v4, :cond_5a

    const/16 v4, 0x7d

    if-eq v3, v4, :cond_5a

    const/16 v4, 0x3a

    if-eq v3, v4, :cond_5a

    const/16 v4, 0x3b

    if-eq v3, v4, :cond_4a

    packed-switch v3, :pswitch_data_94

    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_4a
    :pswitch_4a
    invoke-direct {p0}, LBk/a;->c()V

    goto :goto_5a

    :cond_4e
    array-length v3, v6

    if-ge v2, v3, :cond_5c

    add-int/lit8 v3, v2, 0x1

    invoke-direct {p0, v3}, LBk/a;->m(I)Z

    move-result v3

    if-eqz v3, :cond_5a

    goto :goto_3

    :cond_5a
    :goto_5a
    :pswitch_5a
    move v1, v2

    goto :goto_7a

    :cond_5c
    if-nez v0, :cond_69

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v3, 0x10

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    :cond_69
    iget v3, p0, LBk/a;->d:I

    invoke-virtual {v0, v6, v3, v2}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    iget v3, p0, LBk/a;->d:I

    add-int/2addr v3, v2

    iput v3, p0, LBk/a;->d:I

    const/4 v2, 0x1

    invoke-direct {p0, v2}, LBk/a;->m(I)Z

    move-result v2

    if-nez v2, :cond_2

    :goto_7a
    if-nez v0, :cond_84

    new-instance v0, Ljava/lang/String;

    iget v2, p0, LBk/a;->d:I

    invoke-direct {v0, v6, v2, v1}, Ljava/lang/String;-><init>([CII)V

    goto :goto_8d

    :cond_84
    iget v2, p0, LBk/a;->d:I

    invoke-virtual {v0, v6, v2, v1}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_8d
    iget v2, p0, LBk/a;->d:I

    add-int/2addr v2, v1

    iput v2, p0, LBk/a;->d:I

    return-object v0

    nop

    :pswitch_data_94
    .packed-switch 0x5b
        :pswitch_5a
        :pswitch_4a
        :pswitch_5a
    .end packed-switch
.end method

.method private Q(I)V
    .registers 8

    iget v0, p0, LBk/a;->m:I

    iget-object v1, p0, LBk/a;->l:[I

    array-length v2, v1

    if-ne v0, v2, :cond_27

    mul-int/lit8 v2, v0, 0x2

    new-array v3, v2, [I

    new-array v4, v2, [I

    new-array v2, v2, [Ljava/lang/String;

    const/4 v5, 0x0

    invoke-static {v1, v5, v3, v5, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    invoke-static {v0, v5, v4, v5, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, LBk/a;->n:[Ljava/lang/String;

    iget v1, p0, LBk/a;->m:I

    invoke-static {v0, v5, v2, v5, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v3, p0, LBk/a;->l:[I

    iput-object v4, p0, LBk/a;->o:[I

    iput-object v2, p0, LBk/a;->n:[Ljava/lang/String;

    :cond_27
    iget-object v0, p0, LBk/a;->l:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, LBk/a;->m:I

    aput p1, v0, v1

    return-void
.end method

.method private T()C
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    const/4 v2, 0x0

    const-string v3, "Unterminated escape sequence"

    const/4 v4, 0x1

    if-ne v0, v1, :cond_15

    invoke-direct {p0, v4}, LBk/a;->m(I)Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_15

    :cond_11
    invoke-direct {p0, v3}, LBk/a;->a0(Ljava/lang/String;)V

    throw v2

    :cond_15
    :goto_15
    iget v0, p0, LBk/a;->d:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, LBk/a;->d:I

    iget-object v5, p0, LBk/a;->c:[C

    aget-char v6, v5, v0

    const/16 v7, 0xa

    if-eq v6, v7, :cond_b9

    const/16 v1, 0x22

    if-eq v6, v1, :cond_c0

    const/16 v1, 0x27

    if-eq v6, v1, :cond_c0

    const/16 v1, 0x2f

    if-eq v6, v1, :cond_c0

    const/16 v1, 0x5c

    if-eq v6, v1, :cond_c0

    const/16 v1, 0x62

    if-eq v6, v1, :cond_b6

    const/16 v1, 0x66

    if-eq v6, v1, :cond_b3

    const/16 v4, 0x6e

    if-eq v6, v4, :cond_b2

    const/16 v4, 0x72

    if-eq v6, v4, :cond_af

    const/16 v4, 0x74

    if-eq v6, v4, :cond_ac

    const/16 v4, 0x75

    if-ne v6, v4, :cond_a6

    add-int/lit8 v0, v0, 0x5

    iget v4, p0, LBk/a;->e:I

    const/4 v6, 0x4

    if-le v0, v4, :cond_5d

    invoke-direct {p0, v6}, LBk/a;->m(I)Z

    move-result v0

    if-eqz v0, :cond_59

    goto :goto_5d

    :cond_59
    invoke-direct {p0, v3}, LBk/a;->a0(Ljava/lang/String;)V

    throw v2

    :cond_5d
    :goto_5d
    iget v0, p0, LBk/a;->d:I

    add-int/lit8 v2, v0, 0x4

    const/4 v3, 0x0

    :goto_62
    if-ge v0, v2, :cond_a0

    aget-char v4, v5, v0

    shl-int/lit8 v3, v3, 0x4

    int-to-char v3, v3

    const/16 v7, 0x30

    if-lt v4, v7, :cond_76

    const/16 v7, 0x39

    if-gt v4, v7, :cond_76

    add-int/lit8 v4, v4, -0x30

    :goto_73
    add-int/2addr v4, v3

    int-to-char v3, v4

    goto :goto_8a

    :cond_76
    const/16 v7, 0x61

    if-lt v4, v7, :cond_7f

    if-gt v4, v1, :cond_7f

    add-int/lit8 v4, v4, -0x57

    goto :goto_73

    :cond_7f
    const/16 v7, 0x41

    if-lt v4, v7, :cond_8d

    const/16 v7, 0x46

    if-gt v4, v7, :cond_8d

    add-int/lit8 v4, v4, -0x37

    goto :goto_73

    :goto_8a
    add-int/lit8 v0, v0, 0x1

    goto :goto_62

    :cond_8d
    new-instance v0, Ljava/lang/NumberFormatException;

    new-instance v1, Ljava/lang/String;

    iget v2, p0, LBk/a;->d:I

    invoke-direct {v1, v5, v2, v6}, Ljava/lang/String;-><init>([CII)V

    const-string v2, "\\u"

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a0
    iget v0, p0, LBk/a;->d:I

    add-int/2addr v0, v6

    iput v0, p0, LBk/a;->d:I

    return v3

    :cond_a6
    const-string v0, "Invalid escape sequence"

    invoke-direct {p0, v0}, LBk/a;->a0(Ljava/lang/String;)V

    throw v2

    :cond_ac
    const/16 v0, 0x9

    return v0

    :cond_af
    const/16 v0, 0xd

    return v0

    :cond_b2
    return v7

    :cond_b3
    const/16 v0, 0xc

    return v0

    :cond_b6
    const/16 v0, 0x8

    return v0

    :cond_b9
    iget v0, p0, LBk/a;->f:I

    add-int/2addr v0, v4

    iput v0, p0, LBk/a;->f:I

    iput v1, p0, LBk/a;->g:I

    :cond_c0
    return v6
.end method

.method private U(C)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :goto_0
    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    :goto_4
    const/4 v2, 0x1

    if-ge v0, v1, :cond_2d

    add-int/lit8 v3, v0, 0x1

    iget-object v4, p0, LBk/a;->c:[C

    aget-char v0, v4, v0

    if-ne v0, p1, :cond_12

    iput v3, p0, LBk/a;->d:I

    return-void

    :cond_12
    const/16 v4, 0x5c

    if-ne v0, v4, :cond_20

    iput v3, p0, LBk/a;->d:I

    invoke-direct {p0}, LBk/a;->T()C

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    goto :goto_4

    :cond_20
    const/16 v4, 0xa

    if-ne v0, v4, :cond_2b

    iget v0, p0, LBk/a;->f:I

    add-int/2addr v0, v2

    iput v0, p0, LBk/a;->f:I

    iput v3, p0, LBk/a;->g:I

    :cond_2b
    move v0, v3

    goto :goto_4

    :cond_2d
    iput v0, p0, LBk/a;->d:I

    invoke-direct {p0, v2}, LBk/a;->m(I)Z

    move-result v0

    if-eqz v0, :cond_36

    goto :goto_0

    :cond_36
    const-string p1, "Unterminated string"

    invoke-direct {p0, p1}, LBk/a;->a0(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1
.end method

.method private X()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    const/4 v2, 0x1

    if-lt v0, v1, :cond_d

    invoke-direct {p0, v2}, LBk/a;->m(I)Z

    move-result v0

    if-eqz v0, :cond_27

    :cond_d
    iget v0, p0, LBk/a;->d:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, LBk/a;->d:I

    iget-object v3, p0, LBk/a;->c:[C

    aget-char v0, v3, v0

    const/16 v3, 0xa

    if-ne v0, v3, :cond_23

    iget v0, p0, LBk/a;->f:I

    add-int/2addr v0, v2

    iput v0, p0, LBk/a;->f:I

    iput v1, p0, LBk/a;->g:I

    goto :goto_27

    :cond_23
    const/16 v1, 0xd

    if-ne v0, v1, :cond_0

    :cond_27
    :goto_27
    return-void
.end method

.method private a0(Ljava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, LBk/d;

    invoke-static {p1}, LD/a;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private c()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-boolean v0, p0, LBk/a;->b:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const-string v0, "Use JsonReader.setLenient(true) to accept malformed JSON"

    invoke-direct {p0, v0}, LBk/a;->a0(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method private m(I)Z
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->g:I

    iget v1, p0, LBk/a;->d:I

    sub-int/2addr v0, v1

    iput v0, p0, LBk/a;->g:I

    iget v0, p0, LBk/a;->e:I

    const/4 v2, 0x0

    iget-object v3, p0, LBk/a;->c:[C

    if-eq v0, v1, :cond_15

    sub-int/2addr v0, v1

    iput v0, p0, LBk/a;->e:I

    invoke-static {v3, v1, v3, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_17

    :cond_15
    iput v2, p0, LBk/a;->e:I

    :goto_17
    iput v2, p0, LBk/a;->d:I

    :cond_19
    iget v0, p0, LBk/a;->e:I

    array-length v1, v3

    sub-int/2addr v1, v0

    iget-object v4, p0, LBk/a;->a:Ljava/io/Reader;

    invoke-virtual {v4, v3, v0, v1}, Ljava/io/Reader;->read([CII)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_4b

    iget v1, p0, LBk/a;->e:I

    add-int/2addr v1, v0

    iput v1, p0, LBk/a;->e:I

    iget v0, p0, LBk/a;->f:I

    const/4 v4, 0x1

    if-nez v0, :cond_48

    iget v0, p0, LBk/a;->g:I

    if-nez v0, :cond_48

    if-lez v1, :cond_48

    aget-char v5, v3, v2

    const v6, 0xfeff

    if-ne v5, v6, :cond_48

    iget v5, p0, LBk/a;->d:I

    add-int/2addr v5, v4

    iput v5, p0, LBk/a;->d:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, LBk/a;->g:I

    add-int/lit8 p1, p1, 0x1

    :cond_48
    if-lt v1, p1, :cond_19

    return v4

    :cond_4b
    return v2
.end method

.method private n(C)Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/16 v0, 0x9

    if-eq p1, v0, :cond_3c

    const/16 v0, 0xa

    if-eq p1, v0, :cond_3c

    const/16 v0, 0xc

    if-eq p1, v0, :cond_3c

    const/16 v0, 0xd

    if-eq p1, v0, :cond_3c

    const/16 v0, 0x20

    if-eq p1, v0, :cond_3c

    const/16 v0, 0x23

    if-eq p1, v0, :cond_39

    const/16 v0, 0x2c

    if-eq p1, v0, :cond_3c

    const/16 v0, 0x2f

    if-eq p1, v0, :cond_39

    const/16 v0, 0x3d

    if-eq p1, v0, :cond_39

    const/16 v0, 0x7b

    if-eq p1, v0, :cond_3c

    const/16 v0, 0x7d

    if-eq p1, v0, :cond_3c

    const/16 v0, 0x3a

    if-eq p1, v0, :cond_3c

    const/16 v0, 0x3b

    if-eq p1, v0, :cond_39

    packed-switch p1, :pswitch_data_3e

    const/4 p1, 0x1

    return p1

    :cond_39
    :pswitch_39
    invoke-direct {p0}, LBk/a;->c()V

    :cond_3c
    :pswitch_3c
    const/4 p1, 0x0

    return p1

    :pswitch_data_3e
    .packed-switch 0x5b
        :pswitch_3c
        :pswitch_39
        :pswitch_3c
    .end packed-switch
.end method

.method private w(Z)I
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    :goto_4
    const/4 v2, 0x1

    if-ne v0, v1, :cond_2f

    iput v0, p0, LBk/a;->d:I

    invoke-direct {p0, v2}, LBk/a;->m(I)Z

    move-result v0

    if-nez v0, :cond_2b

    if-nez p1, :cond_13

    const/4 p1, -0x1

    return p1

    :cond_13
    new-instance p1, Ljava/io/EOFException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "End of input"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2b
    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    :cond_2f
    add-int/lit8 v3, v0, 0x1

    iget-object v4, p0, LBk/a;->c:[C

    aget-char v5, v4, v0

    const/16 v6, 0xa

    if-ne v5, v6, :cond_42

    iget v0, p0, LBk/a;->f:I

    add-int/2addr v0, v2

    iput v0, p0, LBk/a;->f:I

    iput v3, p0, LBk/a;->g:I

    goto/16 :goto_df

    :cond_42
    const/16 v7, 0x20

    if-eq v5, v7, :cond_df

    const/16 v7, 0xd

    if-eq v5, v7, :cond_df

    const/16 v7, 0x9

    if-ne v5, v7, :cond_50

    goto/16 :goto_df

    :cond_50
    const/16 v7, 0x2f

    if-ne v5, v7, :cond_ca

    iput v3, p0, LBk/a;->d:I

    const/4 v8, 0x2

    if-ne v3, v1, :cond_67

    iput v0, p0, LBk/a;->d:I

    invoke-direct {p0, v8}, LBk/a;->m(I)Z

    move-result v0

    iget v1, p0, LBk/a;->d:I

    add-int/2addr v1, v2

    iput v1, p0, LBk/a;->d:I

    if-nez v0, :cond_67

    return v5

    :cond_67
    invoke-direct {p0}, LBk/a;->c()V

    iget v0, p0, LBk/a;->d:I

    aget-char v1, v4, v0

    const/16 v3, 0x2a

    if-eq v1, v3, :cond_81

    if-eq v1, v7, :cond_75

    return v5

    :cond_75
    add-int/lit8 v0, v0, 0x1

    iput v0, p0, LBk/a;->d:I

    invoke-direct {p0}, LBk/a;->X()V

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    goto :goto_4

    :cond_81
    add-int/lit8 v0, v0, 0x1

    iput v0, p0, LBk/a;->d:I

    :goto_85
    iget v0, p0, LBk/a;->d:I

    add-int/2addr v0, v8

    iget v1, p0, LBk/a;->e:I

    if-le v0, v1, :cond_9a

    invoke-direct {p0, v8}, LBk/a;->m(I)Z

    move-result v0

    if-eqz v0, :cond_93

    goto :goto_9a

    :cond_93
    const-string p1, "Unterminated comment"

    invoke-direct {p0, p1}, LBk/a;->a0(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    :cond_9a
    :goto_9a
    iget v0, p0, LBk/a;->d:I

    aget-char v1, v4, v0

    if-ne v1, v6, :cond_aa

    iget v1, p0, LBk/a;->f:I

    add-int/2addr v1, v2

    iput v1, p0, LBk/a;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, LBk/a;->g:I

    goto :goto_ba

    :cond_aa
    const/4 v0, 0x0

    :goto_ab
    if-ge v0, v8, :cond_c3

    iget v1, p0, LBk/a;->d:I

    add-int/2addr v1, v0

    aget-char v1, v4, v1

    const-string v3, "*/"

    invoke-virtual {v3, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    if-eq v1, v3, :cond_c0

    :goto_ba
    iget v0, p0, LBk/a;->d:I

    add-int/2addr v0, v2

    iput v0, p0, LBk/a;->d:I

    goto :goto_85

    :cond_c0
    add-int/lit8 v0, v0, 0x1

    goto :goto_ab

    :cond_c3
    iget v0, p0, LBk/a;->d:I

    add-int/2addr v0, v8

    iget v1, p0, LBk/a;->e:I

    goto/16 :goto_4

    :cond_ca
    const/16 v0, 0x23

    if-ne v5, v0, :cond_dc

    iput v3, p0, LBk/a;->d:I

    invoke-direct {p0}, LBk/a;->c()V

    invoke-direct {p0}, LBk/a;->X()V

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->e:I

    goto/16 :goto_4

    :cond_dc
    iput v3, p0, LBk/a;->d:I

    return v5

    :cond_df
    :goto_df
    move v0, v3

    goto/16 :goto_4
.end method


# virtual methods
.method public beginArray()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/4 v1, 0x3

    if-ne v0, v1, :cond_1a

    const/4 v0, 0x1

    invoke-direct {p0, v0}, LBk/a;->Q(I)V

    iget-object v1, p0, LBk/a;->o:[I

    iget v2, p0, LBk/a;->m:I

    sub-int/2addr v2, v0

    const/4 v0, 0x0

    aput v0, v1, v2

    iput v0, p0, LBk/a;->h:I

    return-void

    :cond_1a
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected BEGIN_ARRAY but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public beginObject()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/4 v1, 0x1

    if-ne v0, v1, :cond_13

    const/4 v0, 0x3

    invoke-direct {p0, v0}, LBk/a;->Q(I)V

    const/4 v0, 0x0

    iput v0, p0, LBk/a;->h:I

    return-void

    :cond_13
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected BEGIN_OBJECT but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public close()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x0

    iput v0, p0, LBk/a;->h:I

    iget-object v1, p0, LBk/a;->l:[I

    const/16 v2, 0x8

    aput v2, v1, v0

    const/4 v0, 0x1

    iput v0, p0, LBk/a;->m:I

    iget-object v0, p0, LBk/a;->a:Ljava/io/Reader;

    invoke-virtual {v0}, Ljava/io/Reader;->close()V

    return-void
.end method

.method public endArray()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/4 v1, 0x4

    if-ne v0, v1, :cond_1f

    iget v0, p0, LBk/a;->m:I

    add-int/lit8 v1, v0, -0x1

    iput v1, p0, LBk/a;->m:I

    iget-object v1, p0, LBk/a;->o:[I

    add-int/lit8 v0, v0, -0x2

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    const/4 v0, 0x0

    iput v0, p0, LBk/a;->h:I

    return-void

    :cond_1f
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected END_ARRAY but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public endObject()V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/4 v1, 0x2

    if-ne v0, v1, :cond_23

    iget v0, p0, LBk/a;->m:I

    add-int/lit8 v2, v0, -0x1

    iput v2, p0, LBk/a;->m:I

    iget-object v3, p0, LBk/a;->n:[Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v4, v3, v2

    iget-object v2, p0, LBk/a;->o:[I

    sub-int/2addr v0, v1

    aget v1, v2, v0

    add-int/lit8 v1, v1, 0x1

    aput v1, v2, v0

    const/4 v0, 0x0

    iput v0, p0, LBk/a;->h:I

    return-void

    :cond_23
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected END_OBJECT but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method final g()I
    .registers 21
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v0, p0

    iget-object v1, v0, LBk/a;->l:[I

    iget v2, v0, LBk/a;->m:I

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    aget v4, v1, v2

    const/4 v5, 0x0

    const/16 v9, 0x5d

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/16 v12, 0x3b

    const/16 v13, 0x2c

    const/4 v15, 0x7

    iget-object v6, v0, LBk/a;->c:[C

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v14, 0x2

    if-ne v4, v3, :cond_20

    aput v14, v1, v2

    :cond_1d
    :goto_1d
    const/4 v1, 0x0

    goto/16 :goto_cd

    :cond_20
    if-ne v4, v14, :cond_39

    invoke-direct {v0, v3}, LBk/a;->w(Z)I

    move-result v1

    if-eq v1, v13, :cond_1d

    if-eq v1, v12, :cond_35

    if-ne v1, v9, :cond_2f

    iput v7, v0, LBk/a;->h:I

    return v7

    :cond_2f
    const-string v1, "Unterminated array"

    invoke-direct {v0, v1}, LBk/a;->a0(Ljava/lang/String;)V

    throw v5

    :cond_35
    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    goto :goto_1d

    :cond_39
    if-eq v4, v11, :cond_3d

    if-ne v4, v8, :cond_40

    :cond_3d
    const/4 v3, 0x4

    goto/16 :goto_2bb

    :cond_40
    if-ne v4, v7, :cond_71

    aput v8, v1, v2

    invoke-direct {v0, v3}, LBk/a;->w(Z)I

    move-result v1

    const/16 v2, 0x3a

    if-eq v1, v2, :cond_1d

    const/16 v2, 0x3d

    if-ne v1, v2, :cond_6b

    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    iget v1, v0, LBk/a;->d:I

    iget v2, v0, LBk/a;->e:I

    if-lt v1, v2, :cond_5f

    invoke-direct {v0, v3}, LBk/a;->m(I)Z

    move-result v1

    if-eqz v1, :cond_1d

    :cond_5f
    iget v1, v0, LBk/a;->d:I

    aget-char v2, v6, v1

    const/16 v7, 0x3e

    if-ne v2, v7, :cond_1d

    add-int/2addr v1, v3

    iput v1, v0, LBk/a;->d:I

    goto :goto_1d

    :cond_6b
    const-string v1, "Expected \':\'"

    invoke-direct {v0, v1}, LBk/a;->a0(Ljava/lang/String;)V

    throw v5

    :cond_71
    if-ne v4, v10, :cond_b0

    iget-boolean v1, v0, LBk/a;->b:Z

    if-eqz v1, :cond_a7

    invoke-direct {v0, v3}, LBk/a;->w(Z)I

    iget v1, v0, LBk/a;->d:I

    sub-int/2addr v1, v3

    iput v1, v0, LBk/a;->d:I

    sget-object v2, LBk/a;->p:[C

    array-length v7, v2

    add-int/2addr v1, v7

    iget v7, v0, LBk/a;->e:I

    if-le v1, v7, :cond_8f

    array-length v1, v2

    invoke-direct {v0, v1}, LBk/a;->m(I)Z

    move-result v1

    if-nez v1, :cond_8f

    goto :goto_a7

    :cond_8f
    const/4 v1, 0x0

    :goto_90
    array-length v7, v2

    if-ge v1, v7, :cond_a1

    iget v7, v0, LBk/a;->d:I

    add-int/2addr v7, v1

    aget-char v7, v6, v7

    aget-char v5, v2, v1

    if-eq v7, v5, :cond_9d

    goto :goto_a7

    :cond_9d
    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    goto :goto_90

    :cond_a1
    iget v1, v0, LBk/a;->d:I

    array-length v2, v2

    add-int/2addr v1, v2

    iput v1, v0, LBk/a;->d:I

    :cond_a7
    :goto_a7
    iget-object v1, v0, LBk/a;->l:[I

    iget v2, v0, LBk/a;->m:I

    sub-int/2addr v2, v3

    aput v15, v1, v2

    goto/16 :goto_1d

    :cond_b0
    if-ne v4, v15, :cond_c8

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LBk/a;->w(Z)I

    move-result v2

    const/4 v5, -0x1

    if-ne v2, v5, :cond_bf

    const/16 v1, 0x11

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_bf
    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    iget v2, v0, LBk/a;->d:I

    sub-int/2addr v2, v3

    iput v2, v0, LBk/a;->d:I

    goto :goto_cd

    :cond_c8
    const/4 v1, 0x0

    const/16 v2, 0x8

    if-eq v4, v2, :cond_2b3

    :goto_cd
    invoke-direct {v0, v3}, LBk/a;->w(Z)I

    move-result v2

    const/16 v5, 0x22

    if-eq v2, v5, :cond_2ae

    const/16 v5, 0x27

    if-eq v2, v5, :cond_2a6

    if-eq v2, v13, :cond_28d

    if-eq v2, v12, :cond_28d

    const/16 v5, 0x5b

    if-eq v2, v5, :cond_289

    if-eq v2, v9, :cond_282

    const/16 v4, 0x7b

    if-eq v2, v4, :cond_27e

    iget v2, v0, LBk/a;->d:I

    sub-int/2addr v2, v3

    iput v2, v0, LBk/a;->d:I

    aget-char v2, v6, v2

    const/16 v4, 0x74

    if-eq v2, v4, :cond_117

    const/16 v4, 0x54

    if-ne v2, v4, :cond_f7

    goto :goto_117

    :cond_f7
    const/16 v4, 0x66

    if-eq v2, v4, :cond_111

    const/16 v4, 0x46

    if-ne v2, v4, :cond_100

    goto :goto_111

    :cond_100
    const/16 v4, 0x6e

    if-eq v2, v4, :cond_10b

    const/16 v4, 0x4e

    if-ne v2, v4, :cond_109

    goto :goto_10b

    :cond_109
    :goto_109
    const/4 v5, 0x0

    goto :goto_16a

    :cond_10b
    :goto_10b
    const-string v2, "null"

    const-string v4, "NULL"

    const/4 v5, 0x7

    goto :goto_11c

    :cond_111
    :goto_111
    const-string v2, "false"

    const-string v4, "FALSE"

    const/4 v5, 0x6

    goto :goto_11c

    :cond_117
    :goto_117
    const-string v2, "true"

    const-string v4, "TRUE"

    const/4 v5, 0x5

    :goto_11c
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v9, 0x1

    :goto_121
    if-ge v9, v7, :cond_148

    iget v12, v0, LBk/a;->d:I

    add-int/2addr v12, v9

    iget v13, v0, LBk/a;->e:I

    if-lt v12, v13, :cond_133

    add-int/lit8 v12, v9, 0x1

    invoke-direct {v0, v12}, LBk/a;->m(I)Z

    move-result v12

    if-nez v12, :cond_133

    goto :goto_109

    :cond_133
    iget v12, v0, LBk/a;->d:I

    add-int/2addr v12, v9

    aget-char v12, v6, v12

    invoke-virtual {v2, v9}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-eq v12, v13, :cond_145

    invoke-virtual {v4, v9}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-eq v12, v13, :cond_145

    goto :goto_109

    :cond_145
    add-int/lit8 v9, v9, 0x1

    goto :goto_121

    :cond_148
    iget v2, v0, LBk/a;->d:I

    add-int/2addr v2, v7

    iget v4, v0, LBk/a;->e:I

    if-lt v2, v4, :cond_157

    add-int/lit8 v2, v7, 0x1

    invoke-direct {v0, v2}, LBk/a;->m(I)Z

    move-result v2

    if-eqz v2, :cond_163

    :cond_157
    iget v2, v0, LBk/a;->d:I

    add-int/2addr v2, v7

    aget-char v2, v6, v2

    invoke-direct {v0, v2}, LBk/a;->n(C)Z

    move-result v2

    if-eqz v2, :cond_163

    goto :goto_109

    :cond_163
    iget v2, v0, LBk/a;->d:I

    add-int/2addr v2, v7

    iput v2, v0, LBk/a;->d:I

    iput v5, v0, LBk/a;->h:I

    :goto_16a
    if-eqz v5, :cond_16d

    return v5

    :cond_16d
    iget v2, v0, LBk/a;->d:I

    iget v4, v0, LBk/a;->e:I

    const-wide/16 v12, 0x0

    move-wide v10, v12

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x1

    const/16 v16, 0x0

    :goto_179
    add-int v1, v2, v7

    if-ne v1, v4, :cond_193

    array-length v1, v6

    if-ne v7, v1, :cond_183

    :cond_180
    :goto_180
    const/4 v14, 0x0

    goto/16 :goto_262

    :cond_183
    add-int/lit8 v1, v7, 0x1

    invoke-direct {v0, v1}, LBk/a;->m(I)Z

    move-result v1

    if-nez v1, :cond_18d

    goto/16 :goto_205

    :cond_18d
    iget v1, v0, LBk/a;->d:I

    iget v2, v0, LBk/a;->e:I

    move v4, v2

    move v2, v1

    :cond_193
    add-int v1, v2, v7

    aget-char v1, v6, v1

    const/16 v15, 0x2b

    if-eq v1, v15, :cond_254

    const/16 v15, 0x45

    if-eq v1, v15, :cond_24a

    const/16 v15, 0x65

    if-eq v1, v15, :cond_24a

    const/16 v15, 0x2d

    if-eq v1, v15, :cond_23d

    const/16 v15, 0x2e

    if-eq v1, v15, :cond_236

    const/16 v15, 0x30

    if-lt v1, v15, :cond_1ff

    const/16 v15, 0x39

    if-le v1, v15, :cond_1b4

    goto :goto_1ff

    :cond_1b4
    if-eq v5, v3, :cond_1b8

    if-nez v5, :cond_1bc

    :cond_1b8
    move/from16 v19, v4

    const/4 v3, 0x6

    goto :goto_1f8

    :cond_1bc
    if-ne v5, v14, :cond_1e7

    cmp-long v15, v10, v12

    if-nez v15, :cond_1c3

    goto :goto_180

    :cond_1c3
    const-wide/16 v17, 0xa

    mul-long v17, v17, v10

    add-int/lit8 v1, v1, -0x30

    move/from16 v19, v4

    int-to-long v3, v1

    sub-long v17, v17, v3

    const-wide v3, -0xcccccccccccccccL

    cmp-long v1, v10, v3

    if-gtz v1, :cond_1e0

    if-nez v1, :cond_1de

    cmp-long v1, v17, v10

    if-gez v1, :cond_1de

    goto :goto_1e0

    :cond_1de
    const/4 v1, 0x0

    goto :goto_1e1

    :cond_1e0
    :goto_1e0
    const/4 v1, 0x1

    :goto_1e1
    and-int/2addr v9, v1

    move-wide/from16 v10, v17

    const/4 v3, 0x6

    goto/16 :goto_25a

    :cond_1e7
    move/from16 v19, v4

    const/4 v1, 0x3

    if-ne v5, v1, :cond_1f0

    const/4 v3, 0x6

    const/4 v5, 0x4

    goto/16 :goto_25a

    :cond_1f0
    const/4 v3, 0x6

    if-eq v5, v8, :cond_1f5

    if-ne v5, v3, :cond_25a

    :cond_1f5
    const/4 v5, 0x7

    goto/16 :goto_25a

    :goto_1f8
    add-int/lit8 v1, v1, -0x30

    neg-int v1, v1

    int-to-long v10, v1

    const/4 v5, 0x2

    goto/16 :goto_25a

    :cond_1ff
    :goto_1ff
    invoke-direct {v0, v1}, LBk/a;->n(C)Z

    move-result v1

    if-nez v1, :cond_180

    :goto_205
    if-ne v5, v14, :cond_227

    if-eqz v9, :cond_227

    const-wide/high16 v1, -0x8000000000000000L

    cmp-long v3, v10, v1

    if-nez v3, :cond_211

    if-eqz v16, :cond_227

    :cond_211
    cmp-long v1, v10, v12

    if-nez v1, :cond_217

    if-nez v16, :cond_227

    :cond_217
    if-eqz v16, :cond_21a

    goto :goto_21b

    :cond_21a
    neg-long v10, v10

    :goto_21b
    iput-wide v10, v0, LBk/a;->i:J

    iget v1, v0, LBk/a;->d:I

    add-int/2addr v1, v7

    iput v1, v0, LBk/a;->d:I

    const/16 v14, 0xf

    iput v14, v0, LBk/a;->h:I

    goto :goto_262

    :cond_227
    if-eq v5, v14, :cond_22f

    const/4 v1, 0x4

    if-eq v5, v1, :cond_22f

    const/4 v1, 0x7

    if-ne v5, v1, :cond_180

    :cond_22f
    iput v7, v0, LBk/a;->j:I

    const/16 v14, 0x10

    iput v14, v0, LBk/a;->h:I

    goto :goto_262

    :cond_236
    move/from16 v19, v4

    const/4 v3, 0x6

    if-ne v5, v14, :cond_180

    const/4 v5, 0x3

    goto :goto_25a

    :cond_23d
    move/from16 v19, v4

    const/4 v3, 0x6

    if-nez v5, :cond_246

    const/4 v5, 0x1

    const/16 v16, 0x1

    goto :goto_25a

    :cond_246
    if-ne v5, v8, :cond_180

    :goto_248
    const/4 v5, 0x6

    goto :goto_25a

    :cond_24a
    move/from16 v19, v4

    const/4 v3, 0x6

    if-eq v5, v14, :cond_252

    const/4 v1, 0x4

    if-ne v5, v1, :cond_180

    :cond_252
    const/4 v5, 0x5

    goto :goto_25a

    :cond_254
    move/from16 v19, v4

    const/4 v3, 0x6

    if-ne v5, v8, :cond_180

    goto :goto_248

    :cond_25a
    :goto_25a
    add-int/lit8 v7, v7, 0x1

    move/from16 v4, v19

    const/4 v3, 0x1

    const/4 v15, 0x7

    goto/16 :goto_179

    :goto_262
    if-eqz v14, :cond_265

    return v14

    :cond_265
    iget v1, v0, LBk/a;->d:I

    aget-char v1, v6, v1

    invoke-direct {v0, v1}, LBk/a;->n(C)Z

    move-result v1

    if-eqz v1, :cond_277

    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    const/16 v1, 0xa

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_277
    const-string v1, "Expected value"

    invoke-direct {v0, v1}, LBk/a;->a0(Ljava/lang/String;)V

    const/4 v1, 0x0

    throw v1

    :cond_27e
    const/4 v1, 0x1

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_282
    const/4 v1, 0x1

    if-ne v4, v1, :cond_28e

    const/4 v2, 0x4

    iput v2, v0, LBk/a;->h:I

    return v2

    :cond_289
    const/4 v2, 0x3

    iput v2, v0, LBk/a;->h:I

    return v2

    :cond_28d
    const/4 v1, 0x1

    :cond_28e
    if-eq v4, v1, :cond_29a

    if-ne v4, v14, :cond_293

    goto :goto_29a

    :cond_293
    const-string v1, "Unexpected value"

    invoke-direct {v0, v1}, LBk/a;->a0(Ljava/lang/String;)V

    const/4 v1, 0x0

    throw v1

    :cond_29a
    :goto_29a
    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    iget v2, v0, LBk/a;->d:I

    sub-int/2addr v2, v1

    iput v2, v0, LBk/a;->d:I

    const/4 v1, 0x7

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_2a6
    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    const/16 v1, 0x8

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_2ae
    const/16 v1, 0x9

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_2b3
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "JsonReader is closed"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_2bb
    aput v3, v1, v2

    const/16 v1, 0x7d

    if-ne v4, v8, :cond_2d9

    const/4 v2, 0x1

    invoke-direct {v0, v2}, LBk/a;->w(Z)I

    move-result v3

    if-eq v3, v13, :cond_2d9

    if-eq v3, v12, :cond_2d6

    if-ne v3, v1, :cond_2cf

    iput v14, v0, LBk/a;->h:I

    return v14

    :cond_2cf
    const-string v1, "Unterminated object"

    invoke-direct {v0, v1}, LBk/a;->a0(Ljava/lang/String;)V

    const/4 v1, 0x0

    throw v1

    :cond_2d6
    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    :cond_2d9
    const/4 v2, 0x1

    invoke-direct {v0, v2}, LBk/a;->w(Z)I

    move-result v3

    const/16 v5, 0x22

    if-eq v3, v5, :cond_315

    const/16 v5, 0x27

    if-eq v3, v5, :cond_30d

    const-string v5, "Expected name"

    if-eq v3, v1, :cond_303

    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    iget v1, v0, LBk/a;->d:I

    sub-int/2addr v1, v2

    iput v1, v0, LBk/a;->d:I

    int-to-char v1, v3

    invoke-direct {v0, v1}, LBk/a;->n(C)Z

    move-result v1

    if-eqz v1, :cond_2fe

    const/16 v1, 0xe

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_2fe
    invoke-direct {v0, v5}, LBk/a;->a0(Ljava/lang/String;)V

    const/4 v1, 0x0

    throw v1

    :cond_303
    const/4 v1, 0x0

    if-eq v4, v8, :cond_309

    iput v14, v0, LBk/a;->h:I

    return v14

    :cond_309
    invoke-direct {v0, v5}, LBk/a;->a0(Ljava/lang/String;)V

    throw v1

    :cond_30d
    invoke-direct/range {p0 .. p0}, LBk/a;->c()V

    const/16 v1, 0xc

    iput v1, v0, LBk/a;->h:I

    return v1

    :cond_315
    const/16 v1, 0xd

    iput v1, v0, LBk/a;->h:I

    return v1
.end method

.method public getPath()Ljava/lang/String;
    .registers 6

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "$"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, LBk/a;->m:I

    const/4 v2, 0x0

    :goto_a
    if-ge v2, v1, :cond_43

    iget-object v3, p0, LBk/a;->l:[I

    aget v3, v3, v2

    const/4 v4, 0x1

    if-eq v3, v4, :cond_2f

    const/4 v4, 0x2

    if-eq v3, v4, :cond_2f

    const/4 v4, 0x3

    if-eq v3, v4, :cond_20

    const/4 v4, 0x4

    if-eq v3, v4, :cond_20

    const/4 v4, 0x5

    if-eq v3, v4, :cond_20

    goto :goto_40

    :cond_20
    const/16 v3, 0x2e

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v3, p0, LBk/a;->n:[Ljava/lang/String;

    aget-object v3, v3, v2

    if-eqz v3, :cond_40

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_40

    :cond_2f
    const/16 v3, 0x5b

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v3, p0, LBk/a;->o:[I

    aget v3, v3, v2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v3, 0x5d

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_40
    :goto_40
    add-int/lit8 v2, v2, 0x1

    goto :goto_a

    :cond_43
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public hasNext()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/4 v1, 0x2

    if-eq v0, v1, :cond_10

    const/4 v1, 0x4

    if-eq v0, v1, :cond_10

    const/4 v0, 0x1

    goto :goto_11

    :cond_10
    const/4 v0, 0x0

    :goto_11
    return v0
.end method

.method public final isLenient()Z
    .registers 2

    iget-boolean v0, p0, LBk/a;->b:Z

    return v0
.end method

.method public nextBoolean()Z
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v1, :cond_1a

    iput v2, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    sub-int/2addr v1, v3

    aget v2, v0, v1

    add-int/2addr v2, v3

    aput v2, v0, v1

    return v3

    :cond_1a
    const/4 v1, 0x6

    if-ne v0, v1, :cond_2a

    iput v2, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    sub-int/2addr v1, v3

    aget v4, v0, v1

    add-int/2addr v4, v3

    aput v4, v0, v1

    return v2

    :cond_2a
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected a boolean but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public nextDouble()D
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/16 v1, 0xf

    const/4 v2, 0x0

    if-ne v0, v1, :cond_1f

    iput v2, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v1, v1, -0x1

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    iget-wide v0, p0, LBk/a;->i:J

    long-to-double v0, v0

    return-wide v0

    :cond_1f
    const/16 v1, 0x10

    const/16 v3, 0xb

    if-ne v0, v1, :cond_3a

    new-instance v0, Ljava/lang/String;

    iget v1, p0, LBk/a;->d:I

    iget v4, p0, LBk/a;->j:I

    iget-object v5, p0, LBk/a;->c:[C

    invoke-direct {v0, v5, v1, v4}, Ljava/lang/String;-><init>([CII)V

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->j:I

    add-int/2addr v0, v1

    iput v0, p0, LBk/a;->d:I

    goto :goto_7d

    :cond_3a
    const/16 v1, 0x8

    if-eq v0, v1, :cond_70

    const/16 v4, 0x9

    if-ne v0, v4, :cond_43

    goto :goto_70

    :cond_43
    const/16 v1, 0xa

    if-ne v0, v1, :cond_4e

    invoke-direct {p0}, LBk/a;->N()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    goto :goto_7d

    :cond_4e
    if-ne v0, v3, :cond_51

    goto :goto_7d

    :cond_51
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected a double but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_70
    :goto_70
    if-ne v0, v1, :cond_75

    const/16 v0, 0x27

    goto :goto_77

    :cond_75
    const/16 v0, 0x22

    :goto_77
    invoke-direct {p0, v0}, LBk/a;->A(C)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    :goto_7d
    iput v3, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->k:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    iget-boolean v3, p0, LBk/a;->b:Z

    if-nez v3, :cond_b1

    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    move-result v3

    if-nez v3, :cond_96

    invoke-static {v0, v1}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v3

    if-nez v3, :cond_96

    goto :goto_b1

    :cond_96
    new-instance v2, LBk/d;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "JSON forbids NaN and infinities: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_b1
    :goto_b1
    const/4 v3, 0x0

    iput-object v3, p0, LBk/a;->k:Ljava/lang/String;

    iput v2, p0, LBk/a;->h:I

    iget-object v2, p0, LBk/a;->o:[I

    iget v3, p0, LBk/a;->m:I

    add-int/lit8 v3, v3, -0x1

    aget v4, v2, v3

    add-int/lit8 v4, v4, 0x1

    aput v4, v2, v3

    return-wide v0
.end method

.method public nextInt()I
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/16 v1, 0xf

    const/4 v2, 0x0

    const-string v3, "Expected an int but was "

    if-ne v0, v1, :cond_41

    iget-wide v0, p0, LBk/a;->i:J

    long-to-int v4, v0

    int-to-long v5, v4

    cmp-long v7, v0, v5

    if-nez v7, :cond_26

    iput v2, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v1, v1, -0x1

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    return v4

    :cond_26
    new-instance v0, Ljava/lang/NumberFormatException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v2, p0, LBk/a;->i:J

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_41
    const/16 v1, 0x10

    if-ne v0, v1, :cond_5a

    new-instance v0, Ljava/lang/String;

    iget v1, p0, LBk/a;->d:I

    iget v4, p0, LBk/a;->j:I

    iget-object v5, p0, LBk/a;->c:[C

    invoke-direct {v0, v5, v1, v4}, Ljava/lang/String;-><init>([CII)V

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->j:I

    add-int/2addr v0, v1

    iput v0, p0, LBk/a;->d:I

    goto :goto_b0

    :cond_5a
    const/16 v1, 0xa

    const/16 v4, 0x8

    if-eq v0, v4, :cond_84

    const/16 v5, 0x9

    if-eq v0, v5, :cond_84

    if-ne v0, v1, :cond_67

    goto :goto_84

    :cond_67
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_84
    :goto_84
    if-ne v0, v1, :cond_8d

    invoke-direct {p0}, LBk/a;->N()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    goto :goto_9a

    :cond_8d
    if-ne v0, v4, :cond_92

    const/16 v0, 0x27

    goto :goto_94

    :cond_92
    const/16 v0, 0x22

    :goto_94
    invoke-direct {p0, v0}, LBk/a;->A(C)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    :goto_9a
    :try_start_9a
    iget-object v0, p0, LBk/a;->k:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    iput v2, p0, LBk/a;->h:I

    iget-object v1, p0, LBk/a;->o:[I

    iget v4, p0, LBk/a;->m:I

    add-int/lit8 v4, v4, -0x1

    aget v5, v1, v4

    add-int/lit8 v5, v5, 0x1

    aput v5, v1, v4
    :try_end_ae
    .catch Ljava/lang/NumberFormatException; {:try_start_9a .. :try_end_ae} :catch_af

    return v0

    :catch_af
    nop

    :goto_b0
    const/16 v0, 0xb

    iput v0, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->k:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    double-to-int v4, v0

    int-to-double v5, v4

    cmpl-double v7, v5, v0

    if-nez v7, :cond_d2

    const/4 v0, 0x0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    iput v2, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v1, v1, -0x1

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    return v4

    :cond_d2
    new-instance v0, Ljava/lang/NumberFormatException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, LBk/a;->k:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public nextLong()J
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/16 v1, 0xf

    const/4 v2, 0x0

    if-ne v0, v1, :cond_1e

    iput v2, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v1, v1, -0x1

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    iget-wide v0, p0, LBk/a;->i:J

    return-wide v0

    :cond_1e
    const/16 v1, 0x10

    const-string v3, "Expected a long but was "

    if-ne v0, v1, :cond_39

    new-instance v0, Ljava/lang/String;

    iget v1, p0, LBk/a;->d:I

    iget v4, p0, LBk/a;->j:I

    iget-object v5, p0, LBk/a;->c:[C

    invoke-direct {v0, v5, v1, v4}, Ljava/lang/String;-><init>([CII)V

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    iget v0, p0, LBk/a;->d:I

    iget v1, p0, LBk/a;->j:I

    add-int/2addr v0, v1

    iput v0, p0, LBk/a;->d:I

    goto :goto_8f

    :cond_39
    const/16 v1, 0xa

    const/16 v4, 0x8

    if-eq v0, v4, :cond_63

    const/16 v5, 0x9

    if-eq v0, v5, :cond_63

    if-ne v0, v1, :cond_46

    goto :goto_63

    :cond_46
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_63
    :goto_63
    if-ne v0, v1, :cond_6c

    invoke-direct {p0}, LBk/a;->N()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    goto :goto_79

    :cond_6c
    if-ne v0, v4, :cond_71

    const/16 v0, 0x27

    goto :goto_73

    :cond_71
    const/16 v0, 0x22

    :goto_73
    invoke-direct {p0, v0}, LBk/a;->A(C)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    :goto_79
    :try_start_79
    iget-object v0, p0, LBk/a;->k:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    iput v2, p0, LBk/a;->h:I

    iget-object v4, p0, LBk/a;->o:[I

    iget v5, p0, LBk/a;->m:I

    add-int/lit8 v5, v5, -0x1

    aget v6, v4, v5

    add-int/lit8 v6, v6, 0x1

    aput v6, v4, v5
    :try_end_8d
    .catch Ljava/lang/NumberFormatException; {:try_start_79 .. :try_end_8d} :catch_8e

    return-wide v0

    :catch_8e
    nop

    :goto_8f
    const/16 v0, 0xb

    iput v0, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->k:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    double-to-long v4, v0

    long-to-double v6, v4

    cmpl-double v8, v6, v0

    if-nez v8, :cond_b1

    const/4 v0, 0x0

    iput-object v0, p0, LBk/a;->k:Ljava/lang/String;

    iput v2, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v1, v1, -0x1

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    return-wide v4

    :cond_b1
    new-instance v0, Ljava/lang/NumberFormatException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, LBk/a;->k:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public nextName()Ljava/lang/String;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/16 v1, 0xe

    if-ne v0, v1, :cond_11

    invoke-direct {p0}, LBk/a;->N()Ljava/lang/String;

    move-result-object v0

    goto :goto_26

    :cond_11
    const/16 v1, 0xc

    if-ne v0, v1, :cond_1c

    const/16 v0, 0x27

    invoke-direct {p0, v0}, LBk/a;->A(C)Ljava/lang/String;

    move-result-object v0

    goto :goto_26

    :cond_1c
    const/16 v1, 0xd

    if-ne v0, v1, :cond_32

    const/16 v0, 0x22

    invoke-direct {p0, v0}, LBk/a;->A(C)Ljava/lang/String;

    move-result-object v0

    :goto_26
    const/4 v1, 0x0

    iput v1, p0, LBk/a;->h:I

    iget-object v1, p0, LBk/a;->n:[Ljava/lang/String;

    iget v2, p0, LBk/a;->m:I

    add-int/lit8 v2, v2, -0x1

    aput-object v0, v1, v2

    return-object v0

    :cond_32
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected a name but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public nextNull()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/4 v1, 0x7

    if-ne v0, v1, :cond_1b

    const/4 v0, 0x0

    iput v0, p0, LBk/a;->h:I

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v1, v1, -0x1

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    return-void

    :cond_1b
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected null but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public nextString()Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    const/16 v1, 0xa

    if-ne v0, v1, :cond_11

    invoke-direct {p0}, LBk/a;->N()Ljava/lang/String;

    move-result-object v0

    goto :goto_52

    :cond_11
    const/16 v1, 0x8

    if-ne v0, v1, :cond_1c

    const/16 v0, 0x27

    invoke-direct {p0, v0}, LBk/a;->A(C)Ljava/lang/String;

    move-result-object v0

    goto :goto_52

    :cond_1c
    const/16 v1, 0x9

    if-ne v0, v1, :cond_27

    const/16 v0, 0x22

    invoke-direct {p0, v0}, LBk/a;->A(C)Ljava/lang/String;

    move-result-object v0

    goto :goto_52

    :cond_27
    const/16 v1, 0xb

    if-ne v0, v1, :cond_31

    iget-object v0, p0, LBk/a;->k:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object v1, p0, LBk/a;->k:Ljava/lang/String;

    goto :goto_52

    :cond_31
    const/16 v1, 0xf

    if-ne v0, v1, :cond_3c

    iget-wide v0, p0, LBk/a;->i:J

    invoke-static {v0, v1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    goto :goto_52

    :cond_3c
    const/16 v1, 0x10

    if-ne v0, v1, :cond_62

    new-instance v0, Ljava/lang/String;

    iget v1, p0, LBk/a;->d:I

    iget v2, p0, LBk/a;->j:I

    iget-object v3, p0, LBk/a;->c:[C

    invoke-direct {v0, v3, v1, v2}, Ljava/lang/String;-><init>([CII)V

    iget v1, p0, LBk/a;->d:I

    iget v2, p0, LBk/a;->j:I

    add-int/2addr v1, v2

    iput v1, p0, LBk/a;->d:I

    :goto_52
    const/4 v1, 0x0

    iput v1, p0, LBk/a;->h:I

    iget-object v1, p0, LBk/a;->o:[I

    iget v2, p0, LBk/a;->m:I

    add-int/lit8 v2, v2, -0x1

    aget v3, v1, v2

    add-int/lit8 v3, v3, 0x1

    aput v3, v1, v2

    return-object v0

    :cond_62
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected a string but was "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, LBk/a;->peek()LBk/b;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method final o()Ljava/lang/String;
    .registers 6

    iget v0, p0, LBk/a;->f:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, LBk/a;->d:I

    iget v2, p0, LBk/a;->g:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x1

    const-string v2, " at line "

    const-string v3, " column "

    const-string v4, " path "

    invoke-static {v2, v0, v3, v1, v4}, LS/a;->c(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, LBk/a;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public peek()LBk/b;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, LBk/a;->h:I

    if-nez v0, :cond_8

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v0

    :cond_8
    packed-switch v0, :pswitch_data_30

    new-instance v0, Ljava/lang/AssertionError;

    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    throw v0

    :pswitch_11
    sget-object v0, LBk/b;->END_DOCUMENT:LBk/b;

    return-object v0

    :pswitch_14
    sget-object v0, LBk/b;->NUMBER:LBk/b;

    return-object v0

    :pswitch_17
    sget-object v0, LBk/b;->NAME:LBk/b;

    return-object v0

    :pswitch_1a
    sget-object v0, LBk/b;->STRING:LBk/b;

    return-object v0

    :pswitch_1d
    sget-object v0, LBk/b;->NULL:LBk/b;

    return-object v0

    :pswitch_20
    sget-object v0, LBk/b;->BOOLEAN:LBk/b;

    return-object v0

    :pswitch_23
    sget-object v0, LBk/b;->END_ARRAY:LBk/b;

    return-object v0

    :pswitch_26
    sget-object v0, LBk/b;->BEGIN_ARRAY:LBk/b;

    return-object v0

    :pswitch_29
    sget-object v0, LBk/b;->END_OBJECT:LBk/b;

    return-object v0

    :pswitch_2c
    sget-object v0, LBk/b;->BEGIN_OBJECT:LBk/b;

    return-object v0

    nop

    :pswitch_data_30
    .packed-switch 0x1
        :pswitch_2c
        :pswitch_29
        :pswitch_26
        :pswitch_23
        :pswitch_20
        :pswitch_20
        :pswitch_1d
        :pswitch_1a
        :pswitch_1a
        :pswitch_1a
        :pswitch_1a
        :pswitch_17
        :pswitch_17
        :pswitch_17
        :pswitch_14
        :pswitch_14
        :pswitch_11
    .end packed-switch
.end method

.method public final setLenient(Z)V
    .registers 2

    iput-boolean p1, p0, LBk/a;->b:Z

    return-void
.end method

.method public skipValue()V
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    :cond_2
    iget v2, p0, LBk/a;->h:I

    if-nez v2, :cond_a

    invoke-virtual {p0}, LBk/a;->g()I

    move-result v2

    :cond_a
    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ne v2, v3, :cond_15

    invoke-direct {p0, v4}, LBk/a;->Q(I)V

    :goto_11
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_b2

    :cond_15
    if-ne v2, v4, :cond_1b

    invoke-direct {p0, v3}, LBk/a;->Q(I)V

    goto :goto_11

    :cond_1b
    const/4 v3, 0x4

    if-ne v2, v3, :cond_27

    iget v2, p0, LBk/a;->m:I

    sub-int/2addr v2, v4

    iput v2, p0, LBk/a;->m:I

    :goto_23
    add-int/lit8 v1, v1, -0x1

    goto/16 :goto_b2

    :cond_27
    const/4 v3, 0x2

    if-ne v2, v3, :cond_30

    iget v2, p0, LBk/a;->m:I

    sub-int/2addr v2, v4

    iput v2, p0, LBk/a;->m:I

    goto :goto_23

    :cond_30
    const/16 v3, 0xe

    const/16 v5, 0xd

    const/16 v6, 0x9

    const/16 v7, 0xc

    const/16 v8, 0xa

    if-eq v2, v3, :cond_63

    if-ne v2, v8, :cond_3f

    goto :goto_63

    :cond_3f
    const/16 v3, 0x8

    if-eq v2, v3, :cond_5d

    if-ne v2, v7, :cond_46

    goto :goto_5d

    :cond_46
    if-eq v2, v6, :cond_57

    if-ne v2, v5, :cond_4b

    goto :goto_57

    :cond_4b
    const/16 v3, 0x10

    if-ne v2, v3, :cond_b2

    iget v2, p0, LBk/a;->d:I

    iget v3, p0, LBk/a;->j:I

    add-int/2addr v2, v3

    iput v2, p0, LBk/a;->d:I

    goto :goto_b2

    :cond_57
    :goto_57
    const/16 v2, 0x22

    invoke-direct {p0, v2}, LBk/a;->U(C)V

    goto :goto_b2

    :cond_5d
    :goto_5d
    const/16 v2, 0x27

    invoke-direct {p0, v2}, LBk/a;->U(C)V

    goto :goto_b2

    :cond_63
    :goto_63
    const/4 v2, 0x0

    :goto_64
    iget v3, p0, LBk/a;->d:I

    add-int/2addr v3, v2

    iget v9, p0, LBk/a;->e:I

    if-ge v3, v9, :cond_aa

    iget-object v9, p0, LBk/a;->c:[C

    aget-char v3, v9, v3

    if-eq v3, v6, :cond_a4

    if-eq v3, v8, :cond_a4

    if-eq v3, v7, :cond_a4

    if-eq v3, v5, :cond_a4

    const/16 v9, 0x20

    if-eq v3, v9, :cond_a4

    const/16 v9, 0x23

    if-eq v3, v9, :cond_a1

    const/16 v9, 0x2c

    if-eq v3, v9, :cond_a4

    const/16 v9, 0x2f

    if-eq v3, v9, :cond_a1

    const/16 v9, 0x3d

    if-eq v3, v9, :cond_a1

    const/16 v9, 0x7b

    if-eq v3, v9, :cond_a4

    const/16 v9, 0x7d

    if-eq v3, v9, :cond_a4

    const/16 v9, 0x3a

    if-eq v3, v9, :cond_a4

    const/16 v9, 0x3b

    if-eq v3, v9, :cond_a1

    packed-switch v3, :pswitch_data_ca

    add-int/lit8 v2, v2, 0x1

    goto :goto_64

    :cond_a1
    :pswitch_a1
    invoke-direct {p0}, LBk/a;->c()V

    :cond_a4
    :pswitch_a4
    iget v3, p0, LBk/a;->d:I

    add-int/2addr v3, v2

    iput v3, p0, LBk/a;->d:I

    goto :goto_b2

    :cond_aa
    iput v3, p0, LBk/a;->d:I

    invoke-direct {p0, v4}, LBk/a;->m(I)Z

    move-result v2

    if-nez v2, :cond_63

    :cond_b2
    :goto_b2
    iput v0, p0, LBk/a;->h:I

    if-nez v1, :cond_2

    iget-object v0, p0, LBk/a;->o:[I

    iget v1, p0, LBk/a;->m:I

    add-int/lit8 v2, v1, -0x1

    aget v3, v0, v2

    add-int/2addr v3, v4

    aput v3, v0, v2

    iget-object v0, p0, LBk/a;->n:[Ljava/lang/String;

    sub-int/2addr v1, v4

    const-string v2, "null"

    aput-object v2, v0, v1

    return-void

    nop

    :pswitch_data_ca
    .packed-switch 0x5b
        :pswitch_a4
        :pswitch_a1
        :pswitch_a4
    .end packed-switch
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, LBk/a;->o()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
