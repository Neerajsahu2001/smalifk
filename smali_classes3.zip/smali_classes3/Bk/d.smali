.class public final LBk/d;
.super Ljava/io/IOException;
.source "MalformedJsonException.java"
