.class public final enum LBk/b;
.super Ljava/lang/Enum;
.source "JsonToken.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LBk/b;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LBk/b;

.field public static final enum BEGIN_ARRAY:LBk/b;

.field public static final enum BEGIN_OBJECT:LBk/b;

.field public static final enum BOOLEAN:LBk/b;

.field public static final enum END_ARRAY:LBk/b;

.field public static final enum END_DOCUMENT:LBk/b;

.field public static final enum END_OBJECT:LBk/b;

.field public static final enum NAME:LBk/b;

.field public static final enum NULL:LBk/b;

.field public static final enum NUMBER:LBk/b;

.field public static final enum STRING:LBk/b;


# direct methods
.method static constructor <clinit>()V
    .registers 16

    const/16 v0, 0x9

    const/16 v1, 0x8

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v10, LBk/b;

    const-string v11, "BEGIN_ARRAY"

    invoke-direct {v10, v11, v9}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, LBk/b;->BEGIN_ARRAY:LBk/b;

    new-instance v11, LBk/b;

    const-string v12, "END_ARRAY"

    invoke-direct {v11, v12, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, LBk/b;->END_ARRAY:LBk/b;

    new-instance v12, LBk/b;

    const-string v13, "BEGIN_OBJECT"

    invoke-direct {v12, v13, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v12, LBk/b;->BEGIN_OBJECT:LBk/b;

    new-instance v13, LBk/b;

    const-string v14, "END_OBJECT"

    invoke-direct {v13, v14, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v13, LBk/b;->END_OBJECT:LBk/b;

    new-instance v14, LBk/b;

    const-string v15, "NAME"

    invoke-direct {v14, v15, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v14, LBk/b;->NAME:LBk/b;

    new-instance v15, LBk/b;

    const-string v5, "STRING"

    invoke-direct {v15, v5, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v15, LBk/b;->STRING:LBk/b;

    new-instance v5, LBk/b;

    const-string v4, "NUMBER"

    invoke-direct {v5, v4, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, LBk/b;->NUMBER:LBk/b;

    new-instance v4, LBk/b;

    const-string v3, "BOOLEAN"

    invoke-direct {v4, v3, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, LBk/b;->BOOLEAN:LBk/b;

    new-instance v3, LBk/b;

    const-string v2, "NULL"

    invoke-direct {v3, v2, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, LBk/b;->NULL:LBk/b;

    new-instance v2, LBk/b;

    const-string v1, "END_DOCUMENT"

    invoke-direct {v2, v1, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, LBk/b;->END_DOCUMENT:LBk/b;

    const/16 v1, 0xa

    new-array v1, v1, [LBk/b;

    aput-object v10, v1, v9

    aput-object v11, v1, v8

    aput-object v12, v1, v7

    aput-object v13, v1, v6

    const/4 v6, 0x4

    aput-object v14, v1, v6

    const/4 v6, 0x5

    aput-object v15, v1, v6

    const/4 v6, 0x6

    aput-object v5, v1, v6

    const/4 v5, 0x7

    aput-object v4, v1, v5

    const/16 v4, 0x8

    aput-object v3, v1, v4

    aput-object v2, v1, v0

    sput-object v1, LBk/b;->$VALUES:[LBk/b;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)LBk/b;
    .registers 2

    const-class v0, LBk/b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LBk/b;

    return-object p0
.end method

.method public static values()[LBk/b;
    .registers 1

    sget-object v0, LBk/b;->$VALUES:[LBk/b;

    invoke-virtual {v0}, [LBk/b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LBk/b;

    return-object v0
.end method
