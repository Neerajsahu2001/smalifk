.class public Lbo/a;
.super Lao/a;
.source "JDK8PlatformImplementations.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lbo/a$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lao/a;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()Lio/c;
    .registers 3

    sget-object v0, Lbo/a$a;->a:Ljava/lang/Integer;

    if-eqz v0, :cond_13

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/16 v1, 0x22

    if-lt v0, v1, :cond_d

    goto :goto_13

    :cond_d
    new-instance v0, Lio/b;

    invoke-direct {v0}, Lio/b;-><init>()V

    goto :goto_18

    :cond_13
    :goto_13
    new-instance v0, Ljo/a;

    invoke-direct {v0}, Lio/c;-><init>()V

    :goto_18
    return-object v0
.end method
