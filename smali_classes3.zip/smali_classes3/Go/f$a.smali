.class final LGo/f$a;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaPackageFragmentProvider.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LGo/f;->e(LTo/c;)LHo/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LHo/m;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LGo/f;

.field final synthetic b:LKo/t;


# direct methods
.method constructor <init>(LGo/f;LKo/t;)V
    .registers 3

    iput-object p1, p0, LGo/f$a;->a:LGo/f;

    iput-object p2, p0, LGo/f$a;->b:LKo/t;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    new-instance v0, LHo/m;

    iget-object v1, p0, LGo/f$a;->a:LGo/f;

    invoke-static {v1}, LGo/f;->d(LGo/f;)LGo/g;

    move-result-object v1

    iget-object v2, p0, LGo/f$a;->b:LKo/t;

    invoke-direct {v0, v1, v2}, LHo/m;-><init>(LGo/g;LKo/t;)V

    return-object v0
.end method
