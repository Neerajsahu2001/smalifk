.class public final LGo/k$a;
.super Ljava/lang/Object;
.source "resolvers.kt"

# interfaces
.implements LGo/k;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LGo/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:LGo/k$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LGo/k$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LGo/k$a;->a:LGo/k$a;

    return-void
.end method


# virtual methods
.method public final a(LKo/x;)Luo/X;
    .registers 3

    const-string v0, "javaTypeParameter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method
