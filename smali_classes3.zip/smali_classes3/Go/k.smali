.class public interface abstract LGo/k;
.super Ljava/lang/Object;
.source "resolvers.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LGo/k$a;
    }
.end annotation


# virtual methods
.method public abstract a(LKo/x;)Luo/X;
.end method
