.class final LGo/e$a;
.super Lkotlin/jvm/internal/p;
.source "LazyJavaAnnotations.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LGo/e;-><init>(LGo/g;LKo/d;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LKo/a;",
        "Lvo/c;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LGo/e;


# direct methods
.method constructor <init>(LGo/e;)V
    .registers 2

    iput-object p1, p0, LGo/e$a;->a:LGo/e;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, LKo/a;

    const-string v0, "annotation"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget v0, LEo/d;->e:I

    iget-object v0, p0, LGo/e$a;->a:LGo/e;

    invoke-static {v0}, LGo/e;->b(LGo/e;)LGo/g;

    move-result-object v1

    invoke-static {v0}, LGo/e;->a(LGo/e;)Z

    move-result v0

    invoke-static {v1, p1, v0}, LEo/d;->e(LGo/g;LKo/a;Z)LFo/g;

    move-result-object p1

    return-object p1
.end method
