.class public final LGo/h;
.super Ljava/lang/Object;
.source "resolvers.kt"

# interfaces
.implements LGo/k;


# instance fields
.field private final a:LGo/g;

.field private final b:Luo/k;

.field private final c:I

.field private final d:Ljava/util/LinkedHashMap;

.field private final e:Ljp/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/i<",
            "LKo/x;",
            "LHo/A;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LGo/g;Luo/k;LKo/y;I)V
    .registers 6

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "containingDeclaration"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "typeParameterOwner"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGo/h;->a:LGo/g;

    iput-object p2, p0, LGo/h;->b:Luo/k;

    iput p4, p0, LGo/h;->c:I

    invoke-interface {p3}, LKo/y;->getTypeParameters()Ljava/util/ArrayList;

    move-result-object p1

    new-instance p2, Ljava/util/LinkedHashMap;

    invoke-direct {p2}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 p3, 0x0

    :goto_26
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_3b

    add-int/lit8 p4, p3, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-interface {p2, v0, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move p3, p4

    goto :goto_26

    :cond_3b
    iput-object p2, p0, LGo/h;->d:Ljava/util/LinkedHashMap;

    iget-object p1, p0, LGo/h;->a:LGo/g;

    invoke-virtual {p1}, LGo/g;->e()Ljp/n;

    move-result-object p1

    new-instance p2, LGo/h$a;

    invoke-direct {p2, p0}, LGo/h$a;-><init>(LGo/h;)V

    invoke-interface {p1, p2}, Ljp/n;->i(Leo/l;)Ljp/i;

    move-result-object p1

    iput-object p1, p0, LGo/h;->e:Ljp/i;

    return-void
.end method

.method public static final synthetic b(LGo/h;)LGo/g;
    .registers 1

    iget-object p0, p0, LGo/h;->a:LGo/g;

    return-object p0
.end method

.method public static final synthetic c(LGo/h;)Luo/k;
    .registers 1

    iget-object p0, p0, LGo/h;->b:Luo/k;

    return-object p0
.end method

.method public static final synthetic d(LGo/h;)Ljava/util/LinkedHashMap;
    .registers 1

    iget-object p0, p0, LGo/h;->d:Ljava/util/LinkedHashMap;

    return-object p0
.end method

.method public static final synthetic e(LGo/h;)I
    .registers 1

    iget p0, p0, LGo/h;->c:I

    return p0
.end method


# virtual methods
.method public final a(LKo/x;)Luo/X;
    .registers 3

    const-string v0, "javaTypeParameter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LGo/h;->e:Ljp/i;

    invoke-interface {v0, p1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LHo/A;

    if-eqz v0, :cond_10

    goto :goto_1a

    :cond_10
    iget-object v0, p0, LGo/h;->a:LGo/g;

    invoke-virtual {v0}, LGo/g;->f()LGo/k;

    move-result-object v0

    invoke-interface {v0, p1}, LGo/k;->a(LKo/x;)Luo/X;

    move-result-object v0

    :goto_1a
    return-object v0
.end method
