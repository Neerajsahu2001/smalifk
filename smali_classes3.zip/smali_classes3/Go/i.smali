.class public interface abstract LGo/i;
.super Ljava/lang/Object;
.source "ModuleClassResolver.kt"


# virtual methods
.method public abstract a(LKo/g;)Luo/e;
.end method
