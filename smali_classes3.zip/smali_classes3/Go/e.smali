.class public final LGo/e;
.super Ljava/lang/Object;
.source "LazyJavaAnnotations.kt"

# interfaces
.implements Lvo/h;


# instance fields
.field private final a:LGo/g;

.field private final b:LKo/d;

.field private final c:Z

.field private final d:Ljp/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/i<",
            "LKo/a;",
            "Lvo/c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LGo/g;LKo/d;Z)V
    .registers 5

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "annotationOwner"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGo/e;->a:LGo/g;

    iput-object p2, p0, LGo/e;->b:LKo/d;

    iput-boolean p3, p0, LGo/e;->c:Z

    invoke-virtual {p1}, LGo/g;->a()LGo/c;

    move-result-object p1

    invoke-virtual {p1}, LGo/c;->u()Ljp/n;

    move-result-object p1

    new-instance p2, LGo/e$a;

    invoke-direct {p2, p0}, LGo/e$a;-><init>(LGo/e;)V

    invoke-interface {p1, p2}, Ljp/n;->i(Leo/l;)Ljp/i;

    move-result-object p1

    iput-object p1, p0, LGo/e;->d:Ljp/i;

    return-void
.end method

.method public static final synthetic a(LGo/e;)Z
    .registers 1

    iget-boolean p0, p0, LGo/e;->c:Z

    return p0
.end method

.method public static final synthetic b(LGo/e;)LGo/g;
    .registers 1

    iget-object p0, p0, LGo/e;->a:LGo/g;

    return-object p0
.end method


# virtual methods
.method public final f(LTo/c;)Lvo/c;
    .registers 5

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LGo/e;->b:LKo/d;

    invoke-interface {v0, p1}, LKo/d;->f(LTo/c;)LKo/a;

    move-result-object v1

    if-eqz v1, :cond_17

    iget-object v2, p0, LGo/e;->d:Ljp/i;

    invoke-interface {v2, v1}, Leo/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lvo/c;

    if-nez v1, :cond_1f

    :cond_17
    sget v1, LEo/d;->e:I

    iget-object v1, p0, LGo/e;->a:LGo/g;

    invoke-static {p1, v0, v1}, LEo/d;->a(LTo/c;LKo/d;LGo/g;)LFo/g;

    move-result-object v1

    :cond_1f
    return-object v1
.end method

.method public final isEmpty()Z
    .registers 2

    iget-object v0, p0, LGo/e;->b:LKo/d;

    invoke-interface {v0}, LKo/d;->getAnnotations()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lvo/c;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LGo/e;->b:LKo/d;

    invoke-interface {v0}, LKo/d;->getAnnotations()Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/q;->j(Ljava/lang/Iterable;)Lkotlin/collections/w;

    move-result-object v1

    iget-object v2, p0, LGo/e;->d:Ljp/i;

    invoke-static {v1, v2}, Lup/k;->m(Lup/h;Leo/l;)Lup/z;

    move-result-object v1

    sget v2, LEo/d;->e:I

    sget-object v2, Lro/n$a;->m:LTo/c;

    iget-object v3, p0, LGo/e;->a:LGo/g;

    invoke-static {v2, v0, v3}, LEo/d;->a(LTo/c;LKo/d;LGo/g;)LFo/g;

    move-result-object v0

    invoke-static {v1, v0}, Lup/k;->p(Lup/z;Ljava/lang/Object;)Lup/f;

    move-result-object v0

    invoke-static {v0}, Lup/k;->g(Lup/h;)Lup/e;

    move-result-object v0

    invoke-virtual {v0}, Lup/e;->iterator()Ljava/util/Iterator;

    move-result-object v0

    return-object v0
.end method

.method public final r0(LTo/c;)Z
    .registers 2

    invoke-static {p0, p1}, Lvo/h$b;->b(Lvo/h;LTo/c;)Z

    move-result p1

    return p1
.end method
