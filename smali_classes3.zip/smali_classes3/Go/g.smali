.class public final LGo/g;
.super Ljava/lang/Object;
.source "context.kt"


# instance fields
.field private final a:LGo/c;

.field private final b:LGo/k;

.field private final c:LUn/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUn/e<",
            "LDo/A;",
            ">;"
        }
    .end annotation
.end field

.field private final d:LUn/e;

.field private final e:LIo/d;


# direct methods
.method public constructor <init>(LGo/c;LGo/k;LUn/e;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LGo/c;",
            "LGo/k;",
            "LUn/e<",
            "LDo/A;",
            ">;)V"
        }
    .end annotation

    const-string v0, "components"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "typeParameterResolver"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "delegateForDefaultTypeQualifiers"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGo/g;->a:LGo/c;

    iput-object p2, p0, LGo/g;->b:LGo/k;

    iput-object p3, p0, LGo/g;->c:LUn/e;

    iput-object p3, p0, LGo/g;->d:LUn/e;

    new-instance p1, LIo/d;

    invoke-direct {p1, p0, p2}, LIo/d;-><init>(LGo/g;LGo/k;)V

    iput-object p1, p0, LGo/g;->e:LIo/d;

    return-void
.end method


# virtual methods
.method public final a()LGo/c;
    .registers 2

    iget-object v0, p0, LGo/g;->a:LGo/c;

    return-object v0
.end method

.method public final b()LDo/A;
    .registers 2

    iget-object v0, p0, LGo/g;->d:LUn/e;

    invoke-interface {v0}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LDo/A;

    return-object v0
.end method

.method public final c()LUn/e;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUn/e<",
            "LDo/A;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, LGo/g;->c:LUn/e;

    return-object v0
.end method

.method public final d()Luo/B;
    .registers 2

    iget-object v0, p0, LGo/g;->a:LGo/c;

    invoke-virtual {v0}, LGo/c;->m()Luo/B;

    move-result-object v0

    return-object v0
.end method

.method public final e()Ljp/n;
    .registers 2

    iget-object v0, p0, LGo/g;->a:LGo/c;

    invoke-virtual {v0}, LGo/c;->u()Ljp/n;

    move-result-object v0

    return-object v0
.end method

.method public final f()LGo/k;
    .registers 2

    iget-object v0, p0, LGo/g;->b:LGo/k;

    return-object v0
.end method

.method public final g()LIo/d;
    .registers 2

    iget-object v0, p0, LGo/g;->e:LIo/d;

    return-object v0
.end method
