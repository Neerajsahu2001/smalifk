.class final LGo/h$a;
.super Lkotlin/jvm/internal/p;
.source "resolvers.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LGo/h;-><init>(LGo/g;Luo/k;LKo/y;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "LKo/x;",
        "LHo/A;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LGo/h;


# direct methods
.method constructor <init>(LGo/h;)V
    .registers 2

    iput-object p1, p0, LGo/h$a;->a:LGo/h;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    check-cast p1, LKo/x;

    const-string v0, "typeParameter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LGo/h$a;->a:LGo/h;

    invoke-static {v0}, LGo/h;->d(LGo/h;)Ljava/util/LinkedHashMap;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    if-eqz v1, :cond_4a

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    new-instance v2, LHo/A;

    invoke-static {v0}, LGo/h;->b(LGo/h;)LGo/g;

    move-result-object v3

    const-string v4, "<this>"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v4, LGo/g;

    invoke-virtual {v3}, LGo/g;->a()LGo/c;

    move-result-object v5

    invoke-virtual {v3}, LGo/g;->c()LUn/e;

    move-result-object v3

    invoke-direct {v4, v5, v0, v3}, LGo/g;-><init>(LGo/c;LGo/k;LUn/e;)V

    invoke-static {v0}, LGo/h;->c(LGo/h;)Luo/k;

    move-result-object v3

    invoke-interface {v3}, Lvo/a;->getAnnotations()Lvo/h;

    move-result-object v3

    invoke-static {v4, v3}, LGo/b;->c(LGo/g;Lvo/h;)LGo/g;

    move-result-object v3

    invoke-static {v0}, LGo/h;->e(LGo/h;)I

    move-result v4

    add-int/2addr v4, v1

    invoke-static {v0}, LGo/h;->c(LGo/h;)Luo/k;

    move-result-object v0

    invoke-direct {v2, v3, p1, v4, v0}, LHo/A;-><init>(LGo/g;LKo/x;ILuo/k;)V

    goto :goto_4b

    :cond_4a
    const/4 v2, 0x0

    :goto_4b
    return-object v2
.end method
