.class public final LGo/d$a;
.super Ljava/lang/Object;
.source "context.kt"

# interfaces
.implements LGo/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LGo/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:LGo/d$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LGo/d$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LGo/d$a;->a:LGo/d$a;

    return-void
.end method
