.class public interface abstract LGo/d;
.super Ljava/lang/Object;
.source "context.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LGo/d$a;
    }
.end annotation
