.class final LGo/b$a;
.super Lkotlin/jvm/internal/p;
.source "context.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LGo/b;->c(LGo/g;Lvo/h;)LGo/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "LDo/A;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LGo/g;

.field final synthetic b:Lvo/h;


# direct methods
.method constructor <init>(LGo/g;Lvo/h;)V
    .registers 3

    iput-object p1, p0, LGo/b$a;->a:LGo/g;

    iput-object p2, p0, LGo/b$a;->b:Lvo/h;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    const-string v0, "<this>"

    iget-object v1, p0, LGo/b$a;->a:LGo/g;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "additionalAnnotations"

    iget-object v2, p0, LGo/b$a;->b:Lvo/h;

    invoke-static {v2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->a()LDo/e;

    move-result-object v0

    invoke-virtual {v1}, LGo/g;->b()LDo/A;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, LDo/b;->b(LDo/A;Ljava/lang/Iterable;)LDo/A;

    move-result-object v0

    return-object v0
.end method
