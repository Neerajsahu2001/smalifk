.class public final LGo/f;
.super Ljava/lang/Object;
.source "LazyJavaPackageFragmentProvider.kt"

# interfaces
.implements Luo/H;


# instance fields
.field private final a:LGo/g;

.field private final b:Ljp/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/a<",
            "LTo/c;",
            "LHo/m;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LGo/c;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LGo/g;

    sget-object v1, LGo/k$a;->a:LGo/k$a;

    new-instance v2, LUn/b;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, LUn/b;-><init>(Ljava/lang/Object;)V

    invoke-direct {v0, p1, v1, v2}, LGo/g;-><init>(LGo/c;LGo/k;LUn/e;)V

    iput-object v0, p0, LGo/f;->a:LGo/g;

    invoke-virtual {v0}, LGo/g;->e()Ljp/n;

    move-result-object p1

    invoke-interface {p1}, Ljp/n;->a()Ljp/a;

    move-result-object p1

    iput-object p1, p0, LGo/f;->b:Ljp/a;

    return-void
.end method

.method public static final synthetic d(LGo/f;)LGo/g;
    .registers 1

    iget-object p0, p0, LGo/f;->a:LGo/g;

    return-object p0
.end method

.method private final e(LTo/c;)LHo/m;
    .registers 4

    iget-object v0, p0, LGo/f;->a:LGo/g;

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->d()LDo/r;

    move-result-object v0

    invoke-interface {v0, p1}, LDo/r;->c(LTo/c;)LAo/B;

    move-result-object v0

    new-instance v1, LGo/f$a;

    invoke-direct {v1, p0, v0}, LGo/f$a;-><init>(LGo/f;LKo/t;)V

    iget-object v0, p0, LGo/f;->b:Ljp/a;

    invoke-interface {v0, p1, v1}, Ljp/a;->a(Ljava/lang/Object;Leo/a;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LHo/m;

    return-object p1
.end method


# virtual methods
.method public final a(LTo/c;)Z
    .registers 3

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LGo/f;->a:LGo/g;

    invoke-virtual {v0}, LGo/g;->a()LGo/c;

    move-result-object v0

    invoke-virtual {v0}, LGo/c;->d()LDo/r;

    move-result-object v0

    invoke-interface {v0, p1}, LDo/r;->c(LTo/c;)LAo/B;

    const/4 p1, 0x0

    return p1
.end method

.method public final b(LTo/c;)Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LTo/c;",
            ")",
            "Ljava/util/List<",
            "LHo/m;",
            ">;"
        }
    .end annotation

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, LGo/f;->e(LTo/c;)LHo/m;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/q;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public final c(LTo/c;Ljava/util/ArrayList;)V
    .registers 4

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, LGo/f;->e(LTo/c;)LHo/m;

    move-result-object p1

    invoke-static {p1, p2}, Landroidx/core/util/g;->a(Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    return-void
.end method

.method public final n(LTo/c;Leo/l;)Ljava/util/Collection;
    .registers 4

    const-string v0, "fqName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameFilter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, LGo/f;->e(LTo/c;)LHo/m;

    move-result-object p1

    if-eqz p1, :cond_15

    invoke-virtual {p1}, LHo/m;->O0()Ljava/util/List;

    move-result-object p1

    goto :goto_16

    :cond_15
    const/4 p1, 0x0

    :goto_16
    if-nez p1, :cond_1a

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_1a
    check-cast p1, Ljava/util/Collection;

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "LazyJavaPackageFragmentProvider of module "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LGo/f;->a:LGo/g;

    invoke-virtual {v1}, LGo/g;->a()LGo/c;

    move-result-object v1

    invoke-virtual {v1}, LGo/c;->m()Luo/B;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
