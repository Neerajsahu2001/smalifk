.class public final LGo/j;
.super Ljava/lang/Object;
.source "ModuleClassResolver.kt"

# interfaces
.implements LGo/i;


# instance fields
.field public a:Lqj/o3;


# virtual methods
.method public final a(LKo/g;)Luo/e;
    .registers 3

    iget-object v0, p0, LGo/j;->a:Lqj/o3;

    if-eqz v0, :cond_9

    invoke-virtual {v0, p1}, Lqj/o3;->b(LKo/g;)Luo/e;

    move-result-object p1

    return-object p1

    :cond_9
    const-string p1, "resolver"

    invoke-static {p1}, Lkotlin/jvm/internal/n;->m(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1
.end method
