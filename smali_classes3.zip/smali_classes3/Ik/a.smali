.class public interface abstract LIk/a;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-mlkit-barcode-scanning@@17.0.0"

# interfaces
.implements Ljava/io/Closeable;
.implements Landroidx/lifecycle/z;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/io/Closeable;",
        "Landroidx/lifecycle/z;"
    }
.end annotation


# virtual methods
.method public abstract close()V
    .annotation runtime Landroidx/lifecycle/K;
        value = .enum Landroidx/lifecycle/q$a;->ON_DESTROY:Landroidx/lifecycle/q$a;
    .end annotation
.end method
