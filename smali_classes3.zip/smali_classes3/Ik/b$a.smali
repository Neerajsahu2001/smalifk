.class public final LIk/b$a;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-mlkit-barcode-scanning@@17.0.0"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LIk/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private a:I


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, LIk/b$a;->a:I

    return-void
.end method


# virtual methods
.method public final a()LIk/b;
    .registers 3

    new-instance v0, LIk/b;

    iget v1, p0, LIk/b$a;->a:I

    invoke-direct {v0, v1}, LIk/b;-><init>(I)V

    return-object v0
.end method

.method public final varargs b([I)V
    .registers 6
    .param p1    # [I
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param

    const/16 v0, 0x100

    iput v0, p0, LIk/b$a;->a:I

    array-length v0, p1

    const/4 v1, 0x0

    :goto_6
    if-ge v1, v0, :cond_12

    aget v2, p1, v1

    iget v3, p0, LIk/b$a;->a:I

    or-int/2addr v2, v3

    iput v2, p0, LIk/b$a;->a:I

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_12
    return-void
.end method
