.class public Lfp/a;
.super Ljava/lang/Object;
.source "SerializerExtensionProtocol.kt"


# instance fields
.field private final a:LUo/f;

.field private final b:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/c;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final c:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/b;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final d:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/h;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final e:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final f:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final g:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final h:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/f;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final i:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/m;",
            "LOo/a$b$c;",
            ">;"
        }
    .end annotation
.end field

.field private final j:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/t;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final k:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/p;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field

.field private final l:LUo/h$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LUo/h$f<",
            "LOo/r;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LUo/f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;LUo/h$f;)V
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUo/f;",
            "LUo/h$f<",
            "LOo/k;",
            "Ljava/lang/Integer;",
            ">;",
            "LUo/h$f<",
            "LOo/c;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/b;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/h;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/f;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/m;",
            "LOo/a$b$c;",
            ">;",
            "LUo/h$f<",
            "LOo/t;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/p;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;",
            "LUo/h$f<",
            "LOo/r;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lfp/a;->a:LUo/f;

    iput-object p3, p0, Lfp/a;->b:LUo/h$f;

    iput-object p4, p0, Lfp/a;->c:LUo/h$f;

    iput-object p5, p0, Lfp/a;->d:LUo/h$f;

    iput-object p6, p0, Lfp/a;->e:LUo/h$f;

    iput-object p7, p0, Lfp/a;->f:LUo/h$f;

    iput-object p8, p0, Lfp/a;->g:LUo/h$f;

    iput-object p9, p0, Lfp/a;->h:LUo/h$f;

    iput-object p10, p0, Lfp/a;->i:LUo/h$f;

    iput-object p11, p0, Lfp/a;->j:LUo/h$f;

    iput-object p12, p0, Lfp/a;->k:LUo/h$f;

    iput-object p13, p0, Lfp/a;->l:LUo/h$f;

    return-void
.end method


# virtual methods
.method public final a()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/b;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->c:LUo/h$f;

    return-object v0
.end method

.method public final b()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/m;",
            "LOo/a$b$c;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->i:LUo/h$f;

    return-object v0
.end method

.method public final c()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/c;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->b:LUo/h$f;

    return-object v0
.end method

.method public final d()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/f;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->h:LUo/h$f;

    return-object v0
.end method

.method public final e()LUo/f;
    .registers 2

    iget-object v0, p0, Lfp/a;->a:LUo/f;

    return-object v0
.end method

.method public final f()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/h;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->d:LUo/h$f;

    return-object v0
.end method

.method public final g()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/t;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->j:LUo/h$f;

    return-object v0
.end method

.method public final h()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->e:LUo/h$f;

    return-object v0
.end method

.method public final i()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->f:LUo/h$f;

    return-object v0
.end method

.method public final j()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/m;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->g:LUo/h$f;

    return-object v0
.end method

.method public final k()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/p;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->k:LUo/h$f;

    return-object v0
.end method

.method public final l()LUo/h$f;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LUo/h$f<",
            "LOo/r;",
            "Ljava/util/List<",
            "LOo/a;",
            ">;>;"
        }
    .end annotation

    iget-object v0, p0, Lfp/a;->l:LUo/h$f;

    return-object v0
.end method
