.class public final LEk/a;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"
