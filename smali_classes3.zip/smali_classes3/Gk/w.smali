.class public final synthetic LGk/w;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:LGk/k;

.field public final synthetic b:Lzj/l;


# direct methods
.method public synthetic constructor <init>(LGk/k;Lzj/l;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGk/w;->a:LGk/k;

    iput-object p2, p0, LGk/w;->b:Lzj/l;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, LGk/w;->a:LGk/k;

    iget-object v1, p0, LGk/w;->b:Lzj/l;

    invoke-virtual {v0, v1}, LGk/k;->g(Lzj/l;)V

    return-void
.end method
