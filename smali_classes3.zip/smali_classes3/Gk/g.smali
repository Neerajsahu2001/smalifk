.class public final LGk/g;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
.end annotation


# static fields
.field private static final b:Ljava/lang/Object;

.field private static c:LGk/g;


# instance fields
.field private a:Loj/a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LGk/g;->b:Ljava/lang/Object;

    return-void
.end method

.method public static a()LGk/g;
    .registers 4
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    sget-object v0, LGk/g;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    sget-object v1, LGk/g;->c:LGk/g;

    if-nez v1, :cond_28

    new-instance v1, Landroid/os/HandlerThread;

    const-string v2, "MLHandler"

    const/16 v3, 0x9

    invoke-direct {v1, v2, v3}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    new-instance v2, LGk/g;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    new-instance v3, Loj/a;

    invoke-direct {v3, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v3, v2, LGk/g;->a:Loj/a;

    sput-object v2, LGk/g;->c:LGk/g;

    goto :goto_28

    :catchall_26
    move-exception v1

    goto :goto_2c

    :cond_28
    :goto_28
    sget-object v1, LGk/g;->c:LGk/g;

    monitor-exit v0

    return-object v1

    :goto_2c
    monitor-exit v0
    :try_end_2d
    .catchall {:try_start_3 .. :try_end_2d} :catchall_26

    throw v1
.end method

.method public static b(Ljava/util/concurrent/Callable;)Lzj/k;
    .registers 3
    .param p0    # Ljava/util/concurrent/Callable;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    new-instance v0, Lzj/l;

    invoke-direct {v0}, Lzj/l;-><init>()V

    new-instance v1, LGk/q;

    invoke-direct {v1, p0, v0}, LGk/q;-><init>(Ljava/util/concurrent/Callable;Lzj/l;)V

    sget-object p0, LGk/r;->zza:LGk/r;

    invoke-virtual {p0, v1}, LGk/r;->execute(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Lzj/l;->a()Lzj/k;

    move-result-object p0

    return-object p0
.end method

.method public static c()Ljava/util/concurrent/Executor;
    .registers 1
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    sget-object v0, LGk/r;->zza:LGk/r;

    return-object v0
.end method

.method static bridge synthetic d(LGk/g;)Loj/a;
    .registers 1

    iget-object p0, p0, LGk/g;->a:Loj/a;

    return-object p0
.end method
