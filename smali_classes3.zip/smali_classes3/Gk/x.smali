.class public final synthetic LGk/x;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Ljava/util/concurrent/Executor;


# instance fields
.field public final synthetic a:Ljava/util/concurrent/Executor;

.field public final synthetic b:LN/d;

.field public final synthetic c:Lzj/a;

.field public final synthetic d:Lzj/l;


# direct methods
.method public synthetic constructor <init>(Ljava/util/concurrent/Executor;LN/d;Lzj/a;Lzj/l;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGk/x;->a:Ljava/util/concurrent/Executor;

    iput-object p2, p0, LGk/x;->b:LN/d;

    iput-object p3, p0, LGk/x;->c:Lzj/a;

    iput-object p4, p0, LGk/x;->d:Lzj/l;

    return-void
.end method


# virtual methods
.method public final execute(Ljava/lang/Runnable;)V
    .registers 3

    iget-object v0, p0, LGk/x;->a:Ljava/util/concurrent/Executor;

    :try_start_2
    invoke-interface {v0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_5
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_5} :catch_6

    return-void

    :catch_6
    move-exception p1

    iget-object v0, p0, LGk/x;->b:LN/d;

    invoke-virtual {v0}, LN/d;->a()Z

    move-result v0

    if-eqz v0, :cond_15

    iget-object v0, p0, LGk/x;->c:Lzj/a;

    invoke-virtual {v0}, Lzj/a;->a()V

    goto :goto_1a

    :cond_15
    iget-object v0, p0, LGk/x;->d:Lzj/l;

    invoke-virtual {v0, p1}, Lzj/l;->b(Ljava/lang/Exception;)V

    :goto_1a
    throw p1
.end method
