.class public final LGk/m;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
.end annotation


# instance fields
.field private final a:Ljava/lang/Object;

.field private b:Z

.field private final c:Ljava/util/ArrayDeque;

.field private final d:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/Thread;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LGk/m;->a:Ljava/lang/Object;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, LGk/m;->c:Ljava/util/ArrayDeque;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object v0, p0, LGk/m;->d:Ljava/util/concurrent/atomic/AtomicReference;

    return-void
.end method

.method static bridge synthetic b(LGk/m;)Ljava/util/concurrent/atomic/AtomicReference;
    .registers 1

    iget-object p0, p0, LGk/m;->d:Ljava/util/concurrent/atomic/AtomicReference;

    return-object p0
.end method

.method static bridge synthetic c(LGk/m;)V
    .registers 1

    invoke-direct {p0}, LGk/m;->d()V

    return-void
.end method

.method private final d()V
    .registers 3

    iget-object v0, p0, LGk/m;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, LGk/m;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_12

    const/4 v1, 0x0

    iput-boolean v1, p0, LGk/m;->b:Z

    monitor-exit v0

    return-void

    :catchall_10
    move-exception v1

    goto :goto_23

    :cond_12
    iget-object v1, p0, LGk/m;->c:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->remove()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LGk/A;

    monitor-exit v0
    :try_end_1b
    .catchall {:try_start_3 .. :try_end_1b} :catchall_10

    iget-object v0, v1, LGk/A;->a:Ljava/util/concurrent/Executor;

    iget-object v1, v1, LGk/A;->b:Ljava/lang/Runnable;

    invoke-direct {p0, v1, v0}, LGk/m;->e(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void

    :goto_23
    :try_start_23
    monitor-exit v0
    :try_end_24
    .catchall {:try_start_23 .. :try_end_24} :catchall_10

    throw v1
.end method

.method private final e(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    .registers 4

    new-instance v0, LGk/z;

    invoke-direct {v0, p0, p1}, LGk/z;-><init>(LGk/m;Ljava/lang/Runnable;)V

    :try_start_5
    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_8
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_5 .. :try_end_8} :catch_9

    return-void

    :catch_9
    invoke-direct {p0}, LGk/m;->d()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    .registers 6
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .param p2    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    iget-object v0, p0, LGk/m;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-boolean v1, p0, LGk/m;->b:Z

    if-eqz v1, :cond_15

    iget-object v1, p0, LGk/m;->c:Ljava/util/ArrayDeque;

    new-instance v2, LGk/A;

    invoke-direct {v2, p2, p1}, LGk/A;-><init>(Ljava/util/concurrent/Executor;Ljava/lang/Runnable;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :catchall_13
    move-exception p1

    goto :goto_1d

    :cond_15
    const/4 v1, 0x1

    iput-boolean v1, p0, LGk/m;->b:Z

    monitor-exit v0
    :try_end_19
    .catchall {:try_start_3 .. :try_end_19} :catchall_13

    invoke-direct {p0, p1, p2}, LGk/m;->e(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void

    :goto_1d
    :try_start_1d
    monitor-exit v0
    :try_end_1e
    .catchall {:try_start_1d .. :try_end_1e} :catchall_13

    throw p1
.end method
