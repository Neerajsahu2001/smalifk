.class public final synthetic LGk/q;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ljava/util/concurrent/Callable;

.field public final synthetic b:Lzj/l;


# direct methods
.method public synthetic constructor <init>(Ljava/util/concurrent/Callable;Lzj/l;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGk/q;->a:Ljava/util/concurrent/Callable;

    iput-object p2, p0, LGk/q;->b:Lzj/l;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, LGk/q;->a:Ljava/util/concurrent/Callable;

    iget-object v1, p0, LGk/q;->b:Lzj/l;

    :try_start_4
    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_8
    .catch LCk/a; {:try_start_4 .. :try_end_8} :catch_18
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_8} :catch_c

    invoke-virtual {v1, v0}, Lzj/l;->c(Ljava/lang/Object;)V

    return-void

    :catch_c
    move-exception v0

    new-instance v2, LCk/a;

    const-string v3, "Internal error has occurred when executing ML Kit tasks"

    invoke-direct {v2, v3, v0}, LCk/a;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Lzj/l;->b(Ljava/lang/Exception;)V

    return-void

    :catch_18
    move-exception v0

    invoke-virtual {v1, v0}, Lzj/l;->b(Ljava/lang/Exception;)V

    return-void
.end method
