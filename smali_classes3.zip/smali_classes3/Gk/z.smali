.class public final synthetic LGk/z;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:LGk/m;

.field public final synthetic b:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(LGk/m;Ljava/lang/Runnable;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGk/z;->a:LGk/m;

    iput-object p2, p0, LGk/z;->b:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, LGk/z;->b:Ljava/lang/Runnable;

    iget-object v1, p0, LGk/z;->a:LGk/m;

    invoke-static {v1}, LGk/m;->b(LGk/m;)Ljava/util/concurrent/atomic/AtomicReference;

    move-result-object v2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Thread;

    if-nez v2, :cond_16

    const/4 v2, 0x1

    goto :goto_17

    :cond_16
    const/4 v2, 0x0

    :goto_17
    invoke-static {v2}, Lcom/google/android/gms/common/internal/Preconditions;->checkState(Z)V

    const/4 v2, 0x0

    :try_start_1b
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_1e
    .catchall {:try_start_1b .. :try_end_1e} :catchall_29

    invoke-static {v1}, LGk/m;->b(LGk/m;)Ljava/util/concurrent/atomic/AtomicReference;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-static {v1}, LGk/m;->c(LGk/m;)V

    return-void

    :catchall_29
    move-exception v0

    :try_start_2a
    invoke-static {v1}, LGk/m;->b(LGk/m;)Ljava/util/concurrent/atomic/AtomicReference;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-static {v1}, LGk/m;->c(LGk/m;)V
    :try_end_34
    .catchall {:try_start_2a .. :try_end_34} :catchall_34

    :catchall_34
    throw v0
.end method
