.class public final synthetic LGk/o;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic a:LGk/o;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, LGk/o;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LGk/o;->a:LGk/o;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 1

    return-void
.end method
