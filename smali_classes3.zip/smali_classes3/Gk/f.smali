.class public abstract LGk/f;
.super LGk/k;
.source "com.google.mlkit:common@@17.5.0"


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "S::",
        "LGk/h;",
        ">",
        "LGk/k;"
    }
.end annotation


# virtual methods
.method public abstract h(LGk/h;)Ljava/util/List;
    .param p1    # LGk/h;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            LCk/a;
        }
    .end annotation
.end method
