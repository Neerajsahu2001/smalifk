.class public final synthetic LGk/v;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:LGk/k;

.field public final synthetic b:LN/d;

.field public final synthetic c:Lzj/a;

.field public final synthetic d:Ljava/util/concurrent/Callable;

.field public final synthetic e:Lzj/l;


# direct methods
.method public synthetic constructor <init>(LGk/k;LN/d;Lzj/a;Ljava/util/concurrent/Callable;Lzj/l;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LGk/v;->a:LGk/k;

    iput-object p2, p0, LGk/v;->b:LN/d;

    iput-object p3, p0, LGk/v;->c:Lzj/a;

    iput-object p4, p0, LGk/v;->d:Ljava/util/concurrent/Callable;

    iput-object p5, p0, LGk/v;->e:Lzj/l;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget-object v0, p0, LGk/v;->d:Ljava/util/concurrent/Callable;

    iget-object v1, p0, LGk/v;->e:Lzj/l;

    iget-object v2, p0, LGk/v;->a:LGk/k;

    iget-object v3, p0, LGk/v;->b:LN/d;

    iget-object v4, p0, LGk/v;->c:Lzj/a;

    invoke-virtual {v2, v3, v4, v0, v1}, LGk/k;->f(LN/d;Lzj/a;Ljava/util/concurrent/Callable;Lzj/l;)V

    return-void
.end method
