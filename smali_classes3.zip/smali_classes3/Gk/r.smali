.class final enum LGk/r;
.super Ljava/lang/Enum;
.source "com.google.mlkit:common@@17.5.0"

# interfaces
.implements Ljava/util/concurrent/Executor;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LGk/r;",
        ">;",
        "Ljava/util/concurrent/Executor;"
    }
.end annotation


# static fields
.field public static final enum zza:LGk/r;

.field private static final synthetic zzb:[LGk/r;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x0

    new-instance v1, LGk/r;

    const-string v2, "INSTANCE"

    invoke-direct {v1, v2, v0}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, LGk/r;->zza:LGk/r;

    const/4 v2, 0x1

    new-array v2, v2, [LGk/r;

    aput-object v1, v2, v0

    sput-object v2, LGk/r;->zzb:[LGk/r;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    const/4 p0, 0x0

    throw p0
.end method

.method public static values()[LGk/r;
    .registers 1

    sget-object v0, LGk/r;->zzb:[LGk/r;

    invoke-virtual {v0}, [LGk/r;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LGk/r;

    return-object v0
.end method


# virtual methods
.method public final execute(Ljava/lang/Runnable;)V
    .registers 3

    invoke-static {}, LGk/g;->a()LGk/g;

    move-result-object v0

    invoke-static {v0}, LGk/g;->d(LGk/g;)Loj/a;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
