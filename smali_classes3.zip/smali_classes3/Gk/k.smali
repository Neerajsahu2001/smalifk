.class public abstract LGk/k;
.super Ljava/lang/Object;
.source "com.google.mlkit:common@@17.5.0"


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
.end annotation


# instance fields
.field protected final a:LGk/m;
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field private final b:Ljava/util/concurrent/atomic/AtomicInteger;

.field private final c:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, LGk/k;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, LGk/k;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v0, LGk/m;

    invoke-direct {v0}, LGk/m;-><init>()V

    iput-object v0, p0, LGk/k;->a:LGk/m;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;LN/d;)Lzj/k;
    .registers 12
    .param p1    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .param p2    # Ljava/util/concurrent/Callable;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .param p3    # LN/d;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/RecentlyNonNull;
    .end annotation

    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/Executor;",
            "Ljava/util/concurrent/Callable<",
            "TT;>;",
            "LN/d;",
            ")",
            "Lzj/k<",
            "TT;>;"
        }
    .end annotation

    iget-object v0, p0, LGk/k;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    if-lez v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    invoke-static {v0}, Lcom/google/android/gms/common/internal/Preconditions;->checkState(Z)V

    invoke-virtual {p3}, LN/d;->a()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-static {}, Lzj/n;->d()Lzj/k;

    move-result-object p1

    return-object p1

    :cond_19
    new-instance v3, Lzj/a;

    invoke-direct {v3}, Lzj/a;-><init>()V

    new-instance v6, Lzj/l;

    invoke-virtual {v3}, Lzj/a;->b()LN/d;

    move-result-object v0

    invoke-direct {v6, v0}, Lzj/l;-><init>(LN/d;)V

    new-instance v7, LGk/x;

    invoke-direct {v7, p1, p3, v3, v6}, LGk/x;-><init>(Ljava/util/concurrent/Executor;LN/d;Lzj/a;Lzj/l;)V

    new-instance p1, LGk/v;

    move-object v0, p1

    move-object v1, p0

    move-object v2, p3

    move-object v4, p2

    move-object v5, v6

    invoke-direct/range {v0 .. v5}, LGk/v;-><init>(LGk/k;LN/d;Lzj/a;Ljava/util/concurrent/Callable;Lzj/l;)V

    iget-object p2, p0, LGk/k;->a:LGk/m;

    invoke-virtual {p2, p1, v7}, LGk/m;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    invoke-virtual {v6}, Lzj/l;->a()Lzj/k;

    move-result-object p1

    return-object p1
.end method

.method public abstract b()V
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            LCk/a;
        }
    .end annotation
.end method

.method public final c()V
    .registers 2
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    iget-object v0, p0, LGk/k;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    return-void
.end method

.method protected abstract d()V
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public final e(Ljava/util/concurrent/Executor;)V
    .registers 4
    .param p1    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/RecentlyNonNull;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation

    iget-object v0, p0, LGk/k;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    if-lez v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    invoke-static {v0}, Lcom/google/android/gms/common/internal/Preconditions;->checkState(Z)V

    new-instance v0, Lzj/l;

    invoke-direct {v0}, Lzj/l;-><init>()V

    new-instance v1, LGk/w;

    invoke-direct {v1, p0, v0}, LGk/w;-><init>(LGk/k;Lzj/l;)V

    iget-object v0, p0, LGk/k;->a:LGk/m;

    invoke-virtual {v0, v1, p1}, LGk/m;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method final synthetic f(LN/d;Lzj/a;Ljava/util/concurrent/Callable;Lzj/l;)V
    .registers 7

    invoke-virtual {p1}, LN/d;->a()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-virtual {p2}, Lzj/a;->a()V

    return-void

    :cond_a
    iget-object v0, p0, LGk/k;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    :try_start_c
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-nez v1, :cond_1e

    invoke-virtual {p0}, LGk/k;->b()V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    goto :goto_1e

    :catch_1a
    move-exception p3

    goto :goto_42

    :catch_1c
    move-exception p3

    goto :goto_3a

    :cond_1e
    :goto_1e
    invoke-virtual {p1}, LN/d;->a()Z

    move-result v0

    if-eqz v0, :cond_28

    invoke-virtual {p2}, Lzj/a;->a()V

    return-void

    :cond_28
    invoke-interface {p3}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object p3
    :try_end_2c
    .catch Ljava/lang/RuntimeException; {:try_start_c .. :try_end_2c} :catch_1c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_2c} :catch_1a

    :try_start_2c
    invoke-virtual {p1}, LN/d;->a()Z

    move-result v0

    if-eqz v0, :cond_36

    invoke-virtual {p2}, Lzj/a;->a()V

    return-void

    :cond_36
    invoke-virtual {p4, p3}, Lzj/l;->c(Ljava/lang/Object;)V

    return-void

    :goto_3a
    new-instance v0, LCk/a;

    const-string v1, "Internal error has occurred when executing ML Kit tasks"

    invoke-direct {v0, v1, p3}, LCk/a;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    throw v0
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_42} :catch_1a

    :goto_42
    invoke-virtual {p1}, LN/d;->a()Z

    move-result p1

    if-eqz p1, :cond_4c

    invoke-virtual {p2}, Lzj/a;->a()V

    return-void

    :cond_4c
    invoke-virtual {p4, p3}, Lzj/l;->b(Ljava/lang/Exception;)V

    return-void
.end method

.method final synthetic g(Lzj/l;)V
    .registers 5

    iget-object v0, p0, LGk/k;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v1, 0x0

    if-ltz v0, :cond_b

    const/4 v2, 0x1

    goto :goto_c

    :cond_b
    const/4 v2, 0x0

    :goto_c
    invoke-static {v2}, Lcom/google/android/gms/common/internal/Preconditions;->checkState(Z)V

    if-nez v0, :cond_19

    invoke-virtual {p0}, LGk/k;->d()V

    iget-object v0, p0, LGk/k;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_19
    invoke-static {}, Loj/t;->a()V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lzj/l;->c(Ljava/lang/Object;)V

    return-void
.end method
