.class public final Lcn/a$a;
.super Ljava/lang/Object;
.source "IFramePlayerOptions.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Lorg/json/JSONObject;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    iput-object v0, p0, Lcn/a$a;->a:Lorg/json/JSONObject;

    const/4 v1, 0x0

    const-string v2, "autoplay"

    invoke-direct {p0, v1, v2}, Lcn/a$a;->a(ILjava/lang/String;)V

    const-string v2, "controls"

    invoke-direct {p0, v1, v2}, Lcn/a$a;->a(ILjava/lang/String;)V

    const/4 v2, 0x1

    const-string v3, "enablejsapi"

    invoke-direct {p0, v2, v3}, Lcn/a$a;->a(ILjava/lang/String;)V

    const-string v3, "fs"

    invoke-direct {p0, v1, v3}, Lcn/a$a;->a(ILjava/lang/String;)V

    const-string v3, "origin"

    const-string v4, "https://www.youtube.com"

    :try_start_24
    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_27
    .catch Lorg/json/JSONException; {:try_start_24 .. :try_end_27} :catch_42

    const-string v0, "rel"

    invoke-direct {p0, v1, v0}, Lcn/a$a;->a(ILjava/lang/String;)V

    const-string v0, "showinfo"

    invoke-direct {p0, v1, v0}, Lcn/a$a;->a(ILjava/lang/String;)V

    const-string v0, "iv_load_policy"

    const/4 v3, 0x3

    invoke-direct {p0, v3, v0}, Lcn/a$a;->a(ILjava/lang/String;)V

    const-string v0, "modestbranding"

    invoke-direct {p0, v2, v0}, Lcn/a$a;->a(ILjava/lang/String;)V

    const-string v0, "cc_load_policy"

    invoke-direct {p0, v1, v0}, Lcn/a$a;->a(ILjava/lang/String;)V

    return-void

    :catch_42
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Illegal JSON value origin: https://www.youtube.com"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private final a(ILjava/lang/String;)V
    .registers 6

    :try_start_0
    iget-object v0, p0, Lcn/a$a;->a:Lorg/json/JSONObject;

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_5} :catch_6

    return-void

    :catch_6
    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Illegal JSON value "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ": "

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public final b()Lcn/a;
    .registers 3

    new-instance v0, Lcn/a;

    iget-object v1, p0, Lcn/a$a;->a:Lorg/json/JSONObject;

    invoke-direct {v0, v1}, Lcn/a;-><init>(Lorg/json/JSONObject;)V

    return-object v0
.end method

.method public final c()V
    .registers 3

    const/4 v0, 0x1

    const-string v1, "controls"

    invoke-direct {p0, v0, v1}, Lcn/a$a;->a(ILjava/lang/String;)V

    return-void
.end method
