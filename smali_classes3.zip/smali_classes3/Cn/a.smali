.class public final Lcn/a;
.super Ljava/lang/Object;
.source "IFramePlayerOptions.kt"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/a$a;
    }
.end annotation


# static fields
.field private static final b:Lcn/a;


# instance fields
.field private final a:Lorg/json/JSONObject;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcn/a$a;

    invoke-direct {v0}, Lcn/a$a;-><init>()V

    invoke-virtual {v0}, Lcn/a$a;->b()Lcn/a;

    move-result-object v0

    sput-object v0, Lcn/a;->b:Lcn/a;

    return-void
.end method

.method public constructor <init>(Lorg/json/JSONObject;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcn/a;->a:Lorg/json/JSONObject;

    return-void
.end method

.method public static final synthetic a()Lcn/a;
    .registers 1

    sget-object v0, Lcn/a;->b:Lcn/a;

    return-object v0
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lcn/a;->a:Lorg/json/JSONObject;

    const-string v1, "origin"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "playerOptions.getString(Builder.ORIGIN)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lcn/a;->a:Lorg/json/JSONObject;

    instance-of v1, v0, Lorg/json/JSONObject;

    if-nez v1, :cond_b

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_b
    invoke-static {v0}, Lcom/newrelic/agent/android/instrumentation/JSONObjectInstrumentation;->toString(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    :goto_f
    const-string v1, "playerOptions.toString()"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->b(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method
