.class public final LGn/c;
.super Ljava/lang/Object;
.source "RestAdapter.java"


# annotations
.annotation build Lcom/newrelic/agent/android/instrumentation/Instrumented;
.end annotation


# direct methods
.method public static a(Ljava/lang/String;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    new-instance v0, Lretrofit2/G$b;

    invoke-direct {v0}, Lretrofit2/G$b;-><init>()V

    invoke-virtual {v0, p0}, Lretrofit2/G$b;->c(Ljava/lang/String;)V

    invoke-static {}, Lretrofit2/converter/gson/GsonConverterFactory;->create()Lretrofit2/converter/gson/GsonConverterFactory;

    move-result-object p0

    invoke-virtual {v0, p0}, Lretrofit2/G$b;->b(Lretrofit2/j$a;)V

    new-instance p0, Lokhttp3/OkHttpClient$Builder;

    invoke-direct {p0}, Lokhttp3/OkHttpClient$Builder;-><init>()V

    new-instance v1, LGn/b;

    invoke-direct {v1, p2, p3}, LGn/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Lokhttp3/OkHttpClient$Builder;->addInterceptor(Lokhttp3/Interceptor;)Lokhttp3/OkHttpClient$Builder;

    invoke-virtual {p0}, Lokhttp3/OkHttpClient$Builder;->build()Lokhttp3/OkHttpClient;

    move-result-object p0

    invoke-virtual {v0, p0}, Lretrofit2/G$b;->g(Lokhttp3/OkHttpClient;)V

    invoke-virtual {v0}, Lretrofit2/G$b;->d()Lretrofit2/G;

    move-result-object p0

    invoke-virtual {p0, p1}, Lretrofit2/G;->b(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
