.class public interface abstract LGn/d;
.super Ljava/lang/Object;
.source "VerificationService.java"


# virtual methods
.method public abstract a(Ljava/lang/String;Ljava/lang/String;Lcom/truecaller/android/sdk/models/CreateInstallationModel;)Lretrofit2/b;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "appKey"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "fingerPrint"
        .end annotation
    .end param
    .param p3    # Lcom/truecaller/android/sdk/models/CreateInstallationModel;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "create"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/truecaller/android/sdk/models/CreateInstallationModel;",
            ")",
            "Lretrofit2/b<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract b(Ljava/lang/String;Ljava/lang/String;Lcom/truecaller/android/sdk/models/VerifyInstallationModel;)Lretrofit2/b;
    .param p1    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "appKey"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Laq/i;
            value = "fingerPrint"
        .end annotation
    .end param
    .param p3    # Lcom/truecaller/android/sdk/models/VerifyInstallationModel;
        .annotation runtime Laq/a;
        .end annotation
    .end param
    .annotation runtime Laq/o;
        value = "verify"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/truecaller/android/sdk/models/VerifyInstallationModel;",
            ")",
            "Lretrofit2/b<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end method
