.class final LEo/g$a;
.super Lkotlin/jvm/internal/p;
.source "JavaAnnotationMapper.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LEo/g;-><init>(LKo/a;LGo/g;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Map<",
        "LTo/f;",
        "+",
        "LYo/v;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final a:LEo/g$a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, LEo/g$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, LEo/g$a;->a:LEo/g$a;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    invoke-static {}, LEo/d;->b()LTo/f;

    move-result-object v0

    new-instance v1, LYo/v;

    const-string v2, "Deprecated in Java"

    invoke-direct {v1, v2}, LYo/g;-><init>(Ljava/lang/Object;)V

    new-instance v2, LUn/j;

    invoke-direct {v2, v0, v1}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v2}, Lkotlin/collections/J;->h(LUn/j;)Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method
