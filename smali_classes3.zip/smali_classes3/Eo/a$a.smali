.class final LEo/a$a;
.super Ljava/lang/Object;
.source "DescriptorResolverUtils.java"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LEo/a;->a(Luo/b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Leo/l<",
        "Luo/b;",
        "LUn/r;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LEo/a;


# direct methods
.method constructor <init>(LEo/a;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LEo/a$a;->a:LEo/a;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Luo/b;

    if-eqz p1, :cond_e

    iget-object v0, p0, LEo/a$a;->a:LEo/a;

    iget-object v0, v0, LEo/a;->a:Lgp/u;

    invoke-interface {v0, p1}, Lgp/u;->b(Luo/b;)V

    sget-object p1, LUn/r;->a:LUn/r;

    return-object p1

    :cond_e
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Argument for @NotNull parameter \'descriptor\' of kotlin/reflect/jvm/internal/impl/load/java/components/DescriptorResolverUtils$1$1.invoke must not be null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
