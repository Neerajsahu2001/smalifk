.class final LEo/c$a;
.super Lkotlin/jvm/internal/p;
.source "JavaAnnotationMapper.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LEo/c;-><init>(LGo/g;LKo/a;LTo/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Lkp/M;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:LGo/g;

.field final synthetic b:LEo/c;


# direct methods
.method constructor <init>(LGo/g;LEo/c;)V
    .registers 3

    iput-object p1, p0, LEo/c$a;->a:LGo/g;

    iput-object p2, p0, LEo/c$a;->b:LEo/c;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, LEo/c$a;->a:LGo/g;

    invoke-virtual {v0}, LGo/g;->d()Luo/B;

    move-result-object v0

    invoke-interface {v0}, Luo/B;->m()Lro/j;

    move-result-object v0

    iget-object v1, p0, LEo/c$a;->b:LEo/c;

    invoke-virtual {v1}, LEo/c;->c()LTo/c;

    move-result-object v1

    invoke-virtual {v0, v1}, Lro/j;->n(LTo/c;)Luo/e;

    move-result-object v0

    invoke-interface {v0}, Luo/e;->q()Lkp/M;

    move-result-object v0

    const-string v1, "c.module.builtIns.getBui\u2026qName(fqName).defaultType"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method
