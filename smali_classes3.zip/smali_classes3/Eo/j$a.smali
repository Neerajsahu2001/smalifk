.class final LEo/j$a;
.super Lkotlin/jvm/internal/p;
.source "JavaAnnotationMapper.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LEo/j;-><init>(LKo/a;LGo/g;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Map<",
        "LTo/f;",
        "+",
        "LYo/g<",
        "*>;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:LEo/j;


# direct methods
.method constructor <init>(LEo/j;)V
    .registers 2

    iput-object p1, p0, LEo/j$a;->a:LEo/j;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    sget v0, LEo/f;->c:I

    iget-object v0, p0, LEo/j$a;->a:LEo/j;

    invoke-virtual {v0}, LEo/c;->d()LKo/b;

    move-result-object v0

    invoke-static {v0}, LEo/f;->a(LKo/b;)LYo/j;

    move-result-object v0

    if-eqz v0, :cond_1c

    invoke-static {}, LEo/d;->c()LTo/f;

    move-result-object v1

    new-instance v2, LUn/j;

    invoke-direct {v2, v1, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v2}, Lkotlin/collections/J;->h(LUn/j;)Ljava/util/Map;

    move-result-object v0

    goto :goto_1d

    :cond_1c
    const/4 v0, 0x0

    :goto_1d
    if-nez v0, :cond_23

    invoke-static {}, Lkotlin/collections/J;->d()Ljava/util/Map;

    move-result-object v0

    :cond_23
    return-object v0
.end method
