.class public final LEo/h$a;
.super Ljava/lang/Object;
.source "JavaPropertyInitializerEvaluator.kt"

# interfaces
.implements LEo/h;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LEo/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:LEo/h$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, LEo/h$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LEo/h$a;->a:LEo/h$a;

    return-void
.end method


# virtual methods
.method public final a(LKo/n;Lxo/L;)V
    .registers 4

    const-string v0, "field"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "descriptor"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method
