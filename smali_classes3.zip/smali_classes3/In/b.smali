.class public final Lin/b;
.super Ljava/lang/Object;
.source "FadeViewHelper.kt"

# interfaces
.implements Lbn/d;


# instance fields
.field private a:Z

.field private b:Z

.field private c:Z

.field private d:Ljava/lang/Runnable;

.field private final e:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lin/b;->e:Landroid/view/View;

    const/4 p1, 0x1

    iput-boolean p1, p0, Lin/b;->c:Z

    new-instance p1, Lin/b$b;

    invoke-direct {p1, p0}, Lin/b$b;-><init>(Lin/b;)V

    iput-object p1, p0, Lin/b;->d:Ljava/lang/Runnable;

    return-void
.end method

.method public static final synthetic a(Lin/b;)V
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lin/b;->b(F)V

    return-void
.end method

.method private final b(F)V
    .registers 7

    iget-boolean v0, p0, Lin/b;->b:Z

    if-eqz v0, :cond_4b

    const/4 v0, 0x0

    cmpg-float v0, p1, v0

    if-eqz v0, :cond_b

    const/4 v0, 0x1

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    iput-boolean v0, p0, Lin/b;->c:Z

    const/high16 v0, 0x3f800000    # 1.0f

    iget-object v1, p0, Lin/b;->d:Ljava/lang/Runnable;

    iget-object v2, p0, Lin/b;->e:Landroid/view/View;

    cmpg-float v0, p1, v0

    if-nez v0, :cond_28

    iget-boolean v0, p0, Lin/b;->a:Z

    if-eqz v0, :cond_28

    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    move-result-object v0

    if-eqz v0, :cond_31

    const-wide/16 v3, 0xbb8

    invoke-virtual {v0, v1, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_31

    :cond_28
    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    move-result-object v0

    if-eqz v0, :cond_31

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_31
    :goto_31
    invoke-virtual {v2}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0x12c

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    new-instance v1, Lin/b$a;

    invoke-direct {v1, p0, p1}, Lin/b$a;-><init>(Lin/b;F)V

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_4b
    return-void
.end method


# virtual methods
.method public final c()Landroid/view/View;
    .registers 2

    iget-object v0, p0, Lin/b;->e:Landroid/view/View;

    return-object v0
.end method

.method public final d()V
    .registers 2

    iget-boolean v0, p0, Lin/b;->c:Z

    if-eqz v0, :cond_6

    const/4 v0, 0x0

    goto :goto_8

    :cond_6
    const/high16 v0, 0x3f800000    # 1.0f

    :goto_8
    invoke-direct {p0, v0}, Lin/b;->b(F)V

    return-void
.end method

.method public final onApiChange(Lan/e;)V
    .registers 3

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onCurrentSecond(Lan/e;F)V
    .registers 3

    const-string p2, "youTubePlayer"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onError(Lan/e;Lan/c;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "error"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onPlaybackQualityChange(Lan/e;Lan/a;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "playbackQuality"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onPlaybackRateChange(Lan/e;Lan/b;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "playbackRate"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onReady(Lan/e;)V
    .registers 3

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onStateChange(Lan/e;Lan/d;)V
    .registers 6

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "state"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, Lin/a;->a:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget p1, p1, v0

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eq p1, v0, :cond_23

    const/4 v2, 0x2

    if-eq p1, v2, :cond_20

    const/4 v2, 0x3

    if-eq p1, v2, :cond_1d

    goto :goto_25

    :cond_1d
    iput-boolean v0, p0, Lin/b;->a:Z

    goto :goto_25

    :cond_20
    iput-boolean v1, p0, Lin/b;->a:Z

    goto :goto_25

    :cond_23
    iput-boolean v1, p0, Lin/b;->a:Z

    :goto_25
    sget-object p1, Lin/a;->b:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget p1, p1, v2

    const/high16 v2, 0x3f800000    # 1.0f

    packed-switch p1, :pswitch_data_62

    goto :goto_60

    :pswitch_33
    invoke-direct {p0, v2}, Lin/b;->b(F)V

    goto :goto_60

    :pswitch_37
    invoke-direct {p0, v2}, Lin/b;->b(F)V

    goto :goto_60

    :pswitch_3b
    invoke-direct {p0, v2}, Lin/b;->b(F)V

    iput-boolean v1, p0, Lin/b;->b:Z

    goto :goto_60

    :pswitch_41
    iput-boolean v0, p0, Lin/b;->b:Z

    sget-object p1, Lan/d;->PLAYING:Lan/d;

    iget-object v0, p0, Lin/b;->d:Ljava/lang/Runnable;

    iget-object v1, p0, Lin/b;->e:Landroid/view/View;

    if-ne p2, p1, :cond_57

    invoke-virtual {v1}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    move-result-object p1

    if-eqz p1, :cond_60

    const-wide/16 v1, 0xbb8

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_60

    :cond_57
    invoke-virtual {v1}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    move-result-object p1

    if-eqz p1, :cond_60

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_60
    :goto_60
    return-void

    nop

    :pswitch_data_62
    .packed-switch 0x1
        :pswitch_41
        :pswitch_41
        :pswitch_41
        :pswitch_3b
        :pswitch_3b
        :pswitch_37
        :pswitch_33
    .end packed-switch
.end method

.method public final onVideoDuration(Lan/e;F)V
    .registers 3

    const-string p2, "youTubePlayer"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onVideoId(Lan/e;Ljava/lang/String;)V
    .registers 4

    const-string v0, "youTubePlayer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "videoId"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final onVideoLoadedFraction(Lan/e;F)V
    .registers 3

    const-string p2, "youTubePlayer"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method
