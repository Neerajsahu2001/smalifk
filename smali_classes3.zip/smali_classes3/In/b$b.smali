.class final Lin/b$b;
.super Ljava/lang/Object;
.source "FadeViewHelper.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lin/b;-><init>(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field final synthetic a:Lin/b;


# direct methods
.method constructor <init>(Lin/b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lin/b$b;->a:Lin/b;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lin/b$b;->a:Lin/b;

    invoke-static {v0}, Lin/b;->a(Lin/b;)V

    return-void
.end method
