.class final Ldp/n$a;
.super Lkotlin/jvm/internal/p;
.source "SubstitutingScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldp/n;-><init>(Ldp/i;Lkp/r0;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/Collection<",
        "+",
        "Luo/k;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ldp/n;


# direct methods
.method constructor <init>(Ldp/n;)V
    .registers 2

    iput-object p1, p0, Ldp/n$a;->a:Ldp/n;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    iget-object v0, p0, Ldp/n$a;->a:Ldp/n;

    invoke-static {v0}, Ldp/n;->h(Ldp/n;)Ldp/i;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v1, v2, v3}, Ldp/l$a;->a(Ldp/l;Ldp/d;I)Ljava/util/Collection;

    move-result-object v1

    invoke-static {v0, v1}, Ldp/n;->i(Ldp/n;Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v0

    return-object v0
.end method
