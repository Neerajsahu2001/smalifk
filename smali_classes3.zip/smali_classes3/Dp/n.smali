.class public final Ldp/n;
.super Ljava/lang/Object;
.source "SubstitutingScope.kt"

# interfaces
.implements Ldp/i;


# instance fields
.field private final b:Ldp/i;

.field private final c:Lkp/r0;

.field private d:Ljava/util/HashMap;

.field private final e:LUn/e;


# direct methods
.method public constructor <init>(Ldp/i;Lkp/r0;)V
    .registers 4

    const-string v0, "workerScope"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "givenSubstitutor"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldp/n;->b:Ldp/i;

    new-instance p1, Ldp/n$b;

    invoke-direct {p1, p2}, Ldp/n$b;-><init>(Lkp/r0;)V

    invoke-static {p1}, LUn/f;->b(Leo/a;)LUn/e;

    invoke-virtual {p2}, Lkp/r0;->h()Lkp/n0;

    move-result-object p1

    const-string p2, "givenSubstitutor.substitution"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, LXo/d;->c(Lkp/n0;)Lkp/n0;

    move-result-object p1

    invoke-static {p1}, Lkp/r0;->f(Lkp/n0;)Lkp/r0;

    move-result-object p1

    iput-object p1, p0, Ldp/n;->c:Lkp/r0;

    new-instance p1, Ldp/n$a;

    invoke-direct {p1, p0}, Ldp/n$a;-><init>(Ldp/n;)V

    invoke-static {p1}, LUn/f;->b(Leo/a;)LUn/e;

    move-result-object p1

    iput-object p1, p0, Ldp/n;->e:LUn/e;

    return-void
.end method

.method public static final synthetic h(Ldp/n;)Ldp/i;
    .registers 1

    iget-object p0, p0, Ldp/n;->b:Ldp/i;

    return-object p0
.end method

.method public static final synthetic i(Ldp/n;Ljava/util/Collection;)Ljava/util/Collection;
    .registers 2

    invoke-direct {p0, p1}, Ldp/n;->j(Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object p0

    return-object p0
.end method

.method private final j(Ljava/util/Collection;)Ljava/util/Collection;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<D::",
            "Luo/k;",
            ">(",
            "Ljava/util/Collection<",
            "+TD;>;)",
            "Ljava/util/Collection<",
            "TD;>;"
        }
    .end annotation

    iget-object v0, p0, Ldp/n;->c:Lkp/r0;

    invoke-virtual {v0}, Lkp/r0;->i()Z

    move-result v0

    if-eqz v0, :cond_9

    return-object p1

    :cond_9
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_10

    return-object p1

    :cond_10
    invoke-interface {p1}, Ljava/util/Collection;->size()I

    move-result v0

    invoke-static {v0}, Landroidx/core/util/g;->n(I)Ljava/util/LinkedHashSet;

    move-result-object v0

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1c
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_30

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Luo/k;

    invoke-direct {p0, v1}, Ldp/n;->k(Luo/k;)Luo/k;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_1c

    :cond_30
    return-object v0
.end method

.method private final k(Luo/k;)Luo/k;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<D::",
            "Luo/k;",
            ">(TD;)TD;"
        }
    .end annotation

    iget-object v0, p0, Ldp/n;->c:Lkp/r0;

    invoke-virtual {v0}, Lkp/r0;->i()Z

    move-result v1

    if-eqz v1, :cond_9

    return-object p1

    :cond_9
    iget-object v1, p0, Ldp/n;->d:Ljava/util/HashMap;

    if-nez v1, :cond_14

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Ldp/n;->d:Ljava/util/HashMap;

    :cond_14
    iget-object v1, p0, Ldp/n;->d:Ljava/util/HashMap;

    invoke-static {v1}, Lkotlin/jvm/internal/n;->c(Ljava/lang/Object;)V

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_61

    instance-of v2, p1, Luo/U;

    if-eqz v2, :cond_49

    move-object v2, p1

    check-cast v2, Luo/U;

    invoke-interface {v2, v0}, Luo/U;->b(Lkp/r0;)Luo/l;

    move-result-object v2

    if-eqz v2, :cond_30

    invoke-virtual {v1, p1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_61

    :cond_30
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "We expect that no conflict should happen while substitution is guaranteed to generate invariant projection, but "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " substitution fails"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/AssertionError;

    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    :cond_49
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unknown descriptor in scope: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_61
    :goto_61
    check-cast v2, Luo/k;

    return-object v2
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ldp/n;->b:Ldp/i;

    invoke-interface {v0}, Ldp/i;->a()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/n;->b:Ldp/i;

    invoke-interface {v0, p1, p2}, Ldp/i;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    invoke-direct {p0, p1}, Ldp/n;->j(Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/n;->b:Ldp/i;

    invoke-interface {v0, p1, p2}, Ldp/i;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    invoke-direct {p0, p1}, Ldp/n;->j(Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final d()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ldp/n;->b:Ldp/i;

    invoke-interface {v0}, Ldp/i;->d()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "nameFilter"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Ldp/n;->e:LUn/e;

    invoke-interface {p1}, LUn/e;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Collection;

    return-object p1
.end method

.method public final f()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ldp/n;->b:Ldp/i;

    invoke-interface {v0}, Ldp/i;->f()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/n;->b:Ldp/i;

    invoke-interface {v0, p1, p2}, Ldp/l;->g(LTo/f;LCo/c;)Luo/h;

    move-result-object p1

    if-eqz p1, :cond_19

    invoke-direct {p0, p1}, Ldp/n;->k(Luo/k;)Luo/k;

    move-result-object p1

    check-cast p1, Luo/h;

    goto :goto_1a

    :cond_19
    const/4 p1, 0x0

    :goto_1a
    return-object p1
.end method
