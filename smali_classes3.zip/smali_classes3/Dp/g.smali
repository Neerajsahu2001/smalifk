.class public final Ldp/g;
.super Ldp/j;
.source "InnerClassesScopeWrapper.kt"


# instance fields
.field private final b:Ldp/i;


# direct methods
.method public constructor <init>(Ldp/i;)V
    .registers 3

    const-string v0, "workerScope"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ldp/j;-><init>()V

    iput-object p1, p0, Ldp/g;->b:Ldp/i;

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ldp/g;->b:Ldp/i;

    invoke-interface {v0}, Ldp/i;->a()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final d()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ldp/g;->b:Ldp/i;

    invoke-interface {v0}, Ldp/i;->d()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 5

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameFilter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Ldp/d;->c()I

    move-result v0

    invoke-virtual {p1, v0}, Ldp/d;->n(I)Ldp/d;

    move-result-object p1

    if-nez p1, :cond_17

    sget-object p1, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    goto :goto_3b

    :cond_17
    iget-object v0, p0, Ldp/g;->b:Ldp/i;

    invoke-interface {v0, p1, p2}, Ldp/l;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_28
    :goto_28
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3a

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Luo/i;

    if-eqz v1, :cond_28

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_28

    :cond_3a
    move-object p1, p2

    :goto_3b
    check-cast p1, Ljava/util/Collection;

    return-object p1
.end method

.method public final f()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ldp/g;->b:Ldp/i;

    invoke-interface {v0}, Ldp/i;->f()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/g;->b:Ldp/i;

    invoke-interface {v0, p1, p2}, Ldp/l;->g(LTo/f;LCo/c;)Luo/h;

    move-result-object p1

    const/4 p2, 0x0

    if-eqz p1, :cond_27

    instance-of v0, p1, Luo/e;

    if-eqz v0, :cond_1b

    move-object v0, p1

    check-cast v0, Luo/e;

    goto :goto_1c

    :cond_1b
    move-object v0, p2

    :goto_1c
    if-eqz v0, :cond_20

    move-object p2, v0

    goto :goto_27

    :cond_20
    instance-of v0, p1, Luo/W;

    if-eqz v0, :cond_27

    move-object p2, p1

    check-cast p2, Luo/W;

    :cond_27
    :goto_27
    return-object p2
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Classes from "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Ldp/g;->b:Ldp/i;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
