.class public final Ldp/o;
.super Ldp/a;
.source "TypeIntersectionScope.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldp/o$a;
    }
.end annotation


# instance fields
.field private final b:Ldp/i;


# direct methods
.method public constructor <init>(Ldp/i;)V
    .registers 2

    invoke-direct {p0}, Ldp/a;-><init>()V

    iput-object p1, p0, Ldp/o;->b:Ldp/i;

    return-void
.end method


# virtual methods
.method public final b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1, p2}, Ldp/a;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    sget-object p2, Ldp/p;->a:Ldp/p;

    invoke-static {p1, p2}, LWo/u;->a(Ljava/util/Collection;Leo/l;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1, p2}, Ldp/a;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    sget-object p2, Ldp/q;->a:Ldp/q;

    invoke-static {p1, p2}, LWo/u;->a(Ljava/util/Collection;Leo/l;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameFilter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1, p2}, Ldp/a;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1e
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_37

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Luo/k;

    instance-of v2, v2, Luo/a;

    if-eqz v2, :cond_33

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    :cond_33
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    :cond_37
    new-instance p1, LUn/j;

    invoke-direct {p1, p2, v0}, LUn/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p1}, LUn/j;->a()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    invoke-virtual {p1}, LUn/j;->b()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    const-string v0, "null cannot be cast to non-null type kotlin.collections.Collection<org.jetbrains.kotlin.descriptors.CallableDescriptor>"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Ljava/util/Collection;

    sget-object v0, Ldp/o$b;->a:Ldp/o$b;

    invoke-static {p2, v0}, LWo/u;->a(Ljava/util/Collection;Leo/l;)Ljava/util/Collection;

    move-result-object p2

    check-cast p1, Ljava/lang/Iterable;

    invoke-static {p1, p2}, Lkotlin/collections/q;->L(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1
.end method

.method protected final i()Ldp/i;
    .registers 2

    iget-object v0, p0, Ldp/o;->b:Ldp/i;

    return-object v0
.end method
