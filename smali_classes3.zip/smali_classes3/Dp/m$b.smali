.class final Ldp/m$b;
.super Lkotlin/jvm/internal/p;
.source "StaticScopeForKotlinEnum.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldp/m;-><init>(Ljp/n;Luo/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "Luo/L;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ldp/m;


# direct methods
.method constructor <init>(Ldp/m;)V
    .registers 2

    iput-object p1, p0, Ldp/m$b;->a:Ldp/m;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Ldp/m$b;->a:Ldp/m;

    invoke-static {v0}, Ldp/m;->h(Ldp/m;)Luo/e;

    move-result-object v0

    invoke-static {v0}, LWo/h;->f(Luo/e;)Lxo/L;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/q;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
