.class public final Ldp/i$a;
.super Ljava/lang/Object;
.source "MemberScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field static final synthetic a:Ldp/i$a;

.field private static final b:Leo/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/l<",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ldp/i$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Ldp/i$a;->a:Ldp/i$a;

    sget-object v0, Ldp/i$a$a;->a:Ldp/i$a$a;

    sput-object v0, Ldp/i$a;->b:Leo/l;

    return-void
.end method

.method public static a()Leo/l;
    .registers 1

    sget-object v0, Ldp/i$a;->b:Leo/l;

    return-object v0
.end method
