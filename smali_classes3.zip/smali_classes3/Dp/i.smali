.class public interface abstract Ldp/i;
.super Ljava/lang/Object;
.source "MemberScope.kt"

# interfaces
.implements Ldp/l;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldp/i$a;,
        Ldp/i$b;
    }
.end annotation


# static fields
.field public static final a:Ldp/i$a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Ldp/i$a;->a:Ldp/i$a;

    sput-object v0, Ldp/i;->a:Ldp/i$a;

    return-void
.end method


# virtual methods
.method public abstract a()Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method

.method public abstract b(LTo/f;LCo/c;)Ljava/util/Collection;
.end method

.method public abstract c(LTo/f;LCo/c;)Ljava/util/Collection;
.end method

.method public abstract d()Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method

.method public abstract f()Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation
.end method
