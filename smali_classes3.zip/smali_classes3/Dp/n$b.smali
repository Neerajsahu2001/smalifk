.class final Ldp/n$b;
.super Lkotlin/jvm/internal/p;
.source "SubstitutingScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldp/n;-><init>(Ldp/i;Lkp/r0;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Lkp/r0;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkp/r0;


# direct methods
.method constructor <init>(Lkp/r0;)V
    .registers 2

    iput-object p1, p0, Ldp/n$b;->a:Lkp/r0;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Ldp/n$b;->a:Lkp/r0;

    invoke-virtual {v0}, Lkp/r0;->h()Lkp/n0;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Lkp/r0;->f(Lkp/n0;)Lkp/r0;

    move-result-object v0

    return-object v0
.end method
