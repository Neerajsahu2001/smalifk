.class public final Ldp/m;
.super Ldp/j;
.source "StaticScopeForKotlinEnum.kt"


# static fields
.field static final synthetic e:[Llo/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Llo/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final b:Luo/e;

.field private final c:Ljp/j;

.field private final d:Ljp/j;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    new-instance v0, Lkotlin/jvm/internal/x;

    const-class v1, Ldp/m;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v2

    const-string v3, "functions"

    const-string v4, "getFunctions()Ljava/util/List;"

    invoke-direct {v0, v2, v3, v4}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v0

    new-instance v2, Lkotlin/jvm/internal/x;

    invoke-static {v1}, Lkotlin/jvm/internal/E;->b(Ljava/lang/Class;)Llo/d;

    move-result-object v1

    const-string v3, "properties"

    const-string v4, "getProperties()Ljava/util/List;"

    invoke-direct {v2, v1, v3, v4}, Lkotlin/jvm/internal/x;-><init>(Llo/f;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/jvm/internal/E;->g(Lkotlin/jvm/internal/w;)Llo/l;

    move-result-object v1

    const/4 v2, 0x2

    new-array v2, v2, [Llo/m;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v0, 0x1

    aput-object v1, v2, v0

    sput-object v2, Ldp/m;->e:[Llo/m;

    return-void
.end method

.method public constructor <init>(Ljp/n;Luo/e;)V
    .registers 4

    const-string v0, "storageManager"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "containingClass"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ldp/j;-><init>()V

    iput-object p2, p0, Ldp/m;->b:Luo/e;

    invoke-interface {p2}, Luo/e;->h()Luo/f;

    new-instance p2, Ldp/m$a;

    invoke-direct {p2, p0}, Ldp/m$a;-><init>(Ldp/m;)V

    invoke-interface {p1, p2}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p2

    iput-object p2, p0, Ldp/m;->c:Ljp/j;

    new-instance p2, Ldp/m$b;

    invoke-direct {p2, p0}, Ldp/m$b;-><init>(Ldp/m;)V

    invoke-interface {p1, p2}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p1

    iput-object p1, p0, Ldp/m;->d:Ljp/j;

    return-void
.end method

.method public static final synthetic h(Ldp/m;)Luo/e;
    .registers 1

    iget-object p0, p0, Ldp/m;->b:Luo/e;

    return-object p0
.end method


# virtual methods
.method public final b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 6

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p2, Ldp/m;->e:[Llo/m;

    const/4 v0, 0x0

    aget-object p2, p2, v0

    iget-object v0, p0, Ldp/m;->c:Ljp/j;

    invoke-static {v0, p2}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    check-cast p2, Ljava/lang/Iterable;

    new-instance v0, Ltp/c;

    invoke-direct {v0}, Ltp/c;-><init>()V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_22
    :goto_22
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3d

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Luo/Q;

    invoke-interface {v2}, Luo/k;->getName()LTo/f;

    move-result-object v2

    invoke-static {v2, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_22

    invoke-virtual {v0, v1}, Ltp/c;->add(Ljava/lang/Object;)Z

    goto :goto_22

    :cond_3d
    return-object v0
.end method

.method public final c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 6

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p2, Ldp/m;->e:[Llo/m;

    const/4 v0, 0x1

    aget-object p2, p2, v0

    iget-object v0, p0, Ldp/m;->d:Ljp/j;

    invoke-static {v0, p2}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    check-cast p2, Ljava/lang/Iterable;

    new-instance v0, Ltp/c;

    invoke-direct {v0}, Ltp/c;-><init>()V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_22
    :goto_22
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3d

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Luo/L;

    invoke-interface {v2}, Luo/k;->getName()LTo/f;

    move-result-object v2

    invoke-static {v2, p1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_22

    invoke-virtual {v0, v1}, Ltp/c;->add(Ljava/lang/Object;)Z

    goto :goto_22

    :cond_3d
    return-object v0
.end method

.method public final e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 4

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "nameFilter"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    sget-object p2, Ldp/m;->e:[Llo/m;

    aget-object p1, p2, p1

    iget-object v0, p0, Ldp/m;->c:Ljp/j;

    invoke-static {v0, p1}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    check-cast p1, Ljava/util/Collection;

    const/4 v0, 0x1

    aget-object p2, p2, v0

    iget-object v0, p0, Ldp/m;->d:Ljp/j;

    invoke-static {v0, p2}, Ly2/f;->d(Ljp/j;Llo/m;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    check-cast p2, Ljava/lang/Iterable;

    invoke-static {p2, p1}, Lkotlin/collections/q;->L(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1
.end method

.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "location"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method
