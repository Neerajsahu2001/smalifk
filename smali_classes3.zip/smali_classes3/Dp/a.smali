.class public abstract Ldp/a;
.super Ljava/lang/Object;
.source "AbstractScopeAdapter.kt"

# interfaces
.implements Ldp/i;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    invoke-interface {v0}, Ldp/i;->a()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Ldp/i;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Ldp/i;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final d()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    invoke-interface {v0}, Ldp/i;->d()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameFilter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Ldp/l;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object p1

    return-object p1
.end method

.method public final f()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    invoke-interface {v0}, Ldp/i;->f()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 4

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Ldp/l;->g(LTo/f;LCo/c;)Luo/h;

    move-result-object p1

    return-object p1
.end method

.method public final h()Ldp/i;
    .registers 3

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    instance-of v0, v0, Ldp/a;

    if-eqz v0, :cond_18

    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type org.jetbrains.kotlin.resolve.scopes.AbstractScopeAdapter"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ldp/a;

    invoke-virtual {v0}, Ldp/a;->h()Ldp/i;

    move-result-object v0

    goto :goto_1c

    :cond_18
    invoke-virtual {p0}, Ldp/a;->i()Ldp/i;

    move-result-object v0

    :goto_1c
    return-object v0
.end method

.method protected abstract i()Ldp/i;
.end method
