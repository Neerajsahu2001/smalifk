.class final Ldp/e$a;
.super Lkotlin/jvm/internal/p;
.source "GivenFunctionsMemberScope.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldp/e;-><init>(Ljp/n;Luo/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ljava/util/List<",
        "+",
        "Luo/k;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ldp/e;


# direct methods
.method constructor <init>(Ldp/e;)V
    .registers 2

    iput-object p1, p0, Ldp/e$a;->a:Ldp/e;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Ldp/e$a;->a:Ldp/e;

    invoke-virtual {v0}, Ldp/e;->i()Ljava/util/List;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/util/Collection;

    invoke-static {v0, v1}, Ldp/e;->h(Ldp/e;Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0, v2}, Lkotlin/collections/q;->L(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v0

    return-object v0
.end method
