.class public final Ldp/i$b;
.super Ldp/j;
.source "MemberScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final b:Ldp/i$b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ldp/i$b;

    invoke-direct {v0}, Ldp/j;-><init>()V

    sput-object v0, Ldp/i$b;->b:Ldp/i$b;

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object v0
.end method

.method public final d()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object v0
.end method

.method public final f()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    sget-object v0, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    return-object v0
.end method
