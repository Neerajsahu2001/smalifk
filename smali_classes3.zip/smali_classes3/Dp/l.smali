.class public interface abstract Ldp/l;
.super Ljava/lang/Object;
.source "ResolutionScope.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldp/l$a;
    }
.end annotation


# virtual methods
.method public abstract e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation
.end method

.method public abstract g(LTo/f;LCo/c;)Luo/h;
.end method
