.class final Ldp/p;
.super Lkotlin/jvm/internal/p;
.source "TypeIntersectionScope.kt"

# interfaces
.implements Leo/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/l<",
        "Luo/Q;",
        "Luo/a;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Ldp/p;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ldp/p;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkotlin/jvm/internal/p;-><init>(I)V

    sput-object v0, Ldp/p;->a:Ldp/p;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Luo/Q;

    const-string v0, "$this$selectMostSpecificInEachOverridableGroup"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1
.end method
