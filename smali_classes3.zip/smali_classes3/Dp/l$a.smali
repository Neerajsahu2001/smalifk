.class public final Ldp/l$a;
.super Ljava/lang/Object;
.source "ResolutionScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Ldp/l;Ldp/d;I)Ljava/util/Collection;
    .registers 3

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    sget-object p1, Ldp/d;->m:Ldp/d;

    :cond_6
    sget-object p2, Ldp/i;->a:Ldp/i$a;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ldp/i$a;->a()Leo/l;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Ldp/l;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object p0

    return-object p0
.end method
