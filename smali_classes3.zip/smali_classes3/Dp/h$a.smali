.class final Ldp/h$a;
.super Lkotlin/jvm/internal/p;
.source "LazyScopeAdapter.kt"

# interfaces
.implements Leo/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldp/h;-><init>(Ljp/n;Leo/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/p;",
        "Leo/a<",
        "Ldp/i;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Leo/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Leo/a<",
            "Ldp/i;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Leo/a;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Leo/a<",
            "+",
            "Ldp/i;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldp/h$a;->a:Leo/a;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/p;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Ldp/h$a;->a:Leo/a;

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldp/i;

    instance-of v1, v0, Ldp/a;

    if-eqz v1, :cond_12

    check-cast v0, Ldp/a;

    invoke-virtual {v0}, Ldp/a;->h()Ldp/i;

    move-result-object v0

    :cond_12
    return-object v0
.end method
