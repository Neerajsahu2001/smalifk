.class public final Ldp/h;
.super Ldp/a;
.source "LazyScopeAdapter.kt"


# instance fields
.field private final b:Ljp/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljp/j<",
            "Ldp/i;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljp/n;Leo/a;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljp/n;",
            "Leo/a<",
            "+",
            "Ldp/i;",
            ">;)V"
        }
    .end annotation

    const-string v0, "storageManager"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ldp/a;-><init>()V

    new-instance v0, Ldp/h$a;

    invoke-direct {v0, p2}, Ldp/h$a;-><init>(Leo/a;)V

    invoke-interface {p1, v0}, Ljp/n;->e(Leo/a;)Ljp/j;

    move-result-object p1

    iput-object p1, p0, Ldp/h;->b:Ljp/j;

    return-void
.end method


# virtual methods
.method protected final i()Ldp/i;
    .registers 2

    iget-object v0, p0, Ldp/h;->b:Ljp/j;

    invoke-interface {v0}, Leo/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldp/i;

    return-object v0
.end method
