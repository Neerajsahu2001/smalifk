.class public final Ldp/b$a;
.super Ljava/lang/Object;
.source "ChainedMemberScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/lang/Iterable;Ljava/lang/String;)Ldp/i;
    .registers 5

    const-string v0, "debugName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ltp/c;

    invoke-direct {v0}, Ltp/c;-><init>()V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_e
    :goto_e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldp/i;

    sget-object v2, Ldp/i$b;->b:Ldp/i$b;

    if-eq v1, v2, :cond_e

    instance-of v2, v1, Ldp/b;

    if-eqz v2, :cond_37

    check-cast v1, Ldp/b;

    invoke-static {v1}, Ldp/b;->h(Ldp/b;)[Ldp/i;

    move-result-object v1

    const-string v2, "elements"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Lkotlin/collections/h;->c([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    goto :goto_e

    :cond_37
    invoke-virtual {v0, v1}, Ltp/c;->add(Ljava/lang/Object;)Z

    goto :goto_e

    :cond_3b
    invoke-virtual {v0}, Ltp/c;->size()I

    move-result p0

    if-eqz p0, :cond_5a

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eq p0, v1, :cond_53

    new-instance p0, Ldp/b;

    new-array v1, v2, [Ldp/i;

    invoke-virtual {v0, v1}, Ltp/c;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ldp/i;

    invoke-direct {p0, p1, v0}, Ldp/b;-><init>(Ljava/lang/String;[Ldp/i;)V

    goto :goto_5c

    :cond_53
    invoke-virtual {v0, v2}, Ltp/c;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldp/i;

    goto :goto_5c

    :cond_5a
    sget-object p0, Ldp/i$b;->b:Ldp/i$b;

    :goto_5c
    return-object p0
.end method
