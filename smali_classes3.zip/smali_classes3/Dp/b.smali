.class public final Ldp/b;
.super Ljava/lang/Object;
.source "ChainedMemberScope.kt"

# interfaces
.implements Ldp/i;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldp/b$a;
    }
.end annotation


# instance fields
.field private final b:Ljava/lang/String;

.field private final c:[Ldp/i;


# direct methods
.method public constructor <init>(Ljava/lang/String;[Ldp/i;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldp/b;->b:Ljava/lang/String;

    iput-object p2, p0, Ldp/b;->c:[Ldp/i;

    return-void
.end method

.method public static final synthetic h(Ldp/b;)[Ldp/i;
    .registers 1

    iget-object p0, p0, Ldp/b;->c:[Ldp/i;

    return-object p0
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Ldp/b;->c:[Ldp/i;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_9
    if-ge v3, v2, :cond_19

    aget-object v4, v1, v3

    invoke-interface {v4}, Ldp/i;->a()Ljava/util/Set;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4, v0}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_9

    :cond_19
    return-object v0
.end method

.method public final b(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 8

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/b;->c:[Ldp/i;

    array-length v1, v0

    if-eqz v1, :cond_30

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v1, v2, :cond_29

    array-length v1, v0

    const/4 v2, 0x0

    :goto_15
    if-ge v3, v1, :cond_24

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/i;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v4

    invoke-static {v2, v4}, Lsp/a;->a(Ljava/util/Collection;Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v2

    add-int/lit8 v3, v3, 0x1

    goto :goto_15

    :cond_24
    if-nez v2, :cond_32

    sget-object v2, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    goto :goto_32

    :cond_29
    aget-object v0, v0, v3

    invoke-interface {v0, p1, p2}, Ldp/i;->b(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v2

    goto :goto_32

    :cond_30
    sget-object v2, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_32
    :goto_32
    return-object v2
.end method

.method public final c(LTo/f;LCo/c;)Ljava/util/Collection;
    .registers 8

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/b;->c:[Ldp/i;

    array-length v1, v0

    if-eqz v1, :cond_30

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v1, v2, :cond_29

    array-length v1, v0

    const/4 v2, 0x0

    :goto_15
    if-ge v3, v1, :cond_24

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/i;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v4

    invoke-static {v2, v4}, Lsp/a;->a(Ljava/util/Collection;Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v2

    add-int/lit8 v3, v3, 0x1

    goto :goto_15

    :cond_24
    if-nez v2, :cond_32

    sget-object v2, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    goto :goto_32

    :cond_29
    aget-object v0, v0, v3

    invoke-interface {v0, p1, p2}, Ldp/i;->c(LTo/f;LCo/c;)Ljava/util/Collection;

    move-result-object v2

    goto :goto_32

    :cond_30
    sget-object v2, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_32
    :goto_32
    return-object v2
.end method

.method public final d()Ljava/util/Set;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Ldp/b;->c:[Ldp/i;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_9
    if-ge v3, v2, :cond_19

    aget-object v4, v1, v3

    invoke-interface {v4}, Ldp/i;->d()Ljava/util/Set;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4, v0}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_9

    :cond_19
    return-object v0
.end method

.method public final e(Ldp/d;Leo/l;)Ljava/util/Collection;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldp/d;",
            "Leo/l<",
            "-",
            "LTo/f;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/util/Collection<",
            "Luo/k;",
            ">;"
        }
    .end annotation

    const-string v0, "kindFilter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nameFilter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/b;->c:[Ldp/i;

    array-length v1, v0

    if-eqz v1, :cond_30

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v1, v2, :cond_29

    array-length v1, v0

    const/4 v2, 0x0

    :goto_15
    if-ge v3, v1, :cond_24

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/l;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object v4

    invoke-static {v2, v4}, Lsp/a;->a(Ljava/util/Collection;Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v2

    add-int/lit8 v3, v3, 0x1

    goto :goto_15

    :cond_24
    if-nez v2, :cond_32

    sget-object v2, Lkotlin/collections/C;->a:Lkotlin/collections/C;

    goto :goto_32

    :cond_29
    aget-object v0, v0, v3

    invoke-interface {v0, p1, p2}, Ldp/l;->e(Ldp/d;Leo/l;)Ljava/util/Collection;

    move-result-object v2

    goto :goto_32

    :cond_30
    sget-object v2, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    :cond_32
    :goto_32
    return-object v2
.end method

.method public final f()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "LTo/f;",
            ">;"
        }
    .end annotation

    const-string v0, "<this>"

    iget-object v1, p0, Ldp/b;->c:[Ldp/i;

    invoke-static {v1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v0, v1

    if-nez v0, :cond_d

    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    goto :goto_12

    :cond_d
    new-instance v0, Lkotlin/collections/m;

    invoke-direct {v0, v1}, Lkotlin/collections/m;-><init>([Ljava/lang/Object;)V

    :goto_12
    invoke-static {v0}, Ldp/k;->a(Ljava/lang/Iterable;)Ljava/util/HashSet;

    move-result-object v0

    return-object v0
.end method

.method public final g(LTo/f;LCo/c;)Luo/h;
    .registers 9

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "location"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ldp/b;->c:[Ldp/i;

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_f
    if-ge v3, v1, :cond_2f

    aget-object v4, v0, v3

    invoke-interface {v4, p1, p2}, Ldp/l;->g(LTo/f;LCo/c;)Luo/h;

    move-result-object v4

    if-eqz v4, :cond_2c

    instance-of v5, v4, Luo/i;

    if-eqz v5, :cond_2a

    move-object v5, v4

    check-cast v5, Luo/i;

    invoke-interface {v5}, Luo/z;->l0()Z

    move-result v5

    if-eqz v5, :cond_2a

    if-nez v2, :cond_2c

    move-object v2, v4

    goto :goto_2c

    :cond_2a
    move-object v2, v4

    goto :goto_2f

    :cond_2c
    :goto_2c
    add-int/lit8 v3, v3, 0x1

    goto :goto_f

    :cond_2f
    :goto_2f
    return-object v2
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ldp/b;->b:Ljava/lang/String;

    return-object v0
.end method
