.class public final Ldp/o$a;
.super Ljava/lang/Object;
.source "TypeIntersectionScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/lang/String;Ljava/util/Collection;)Ldp/i;
    .registers 5

    const-string v0, "message"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "types"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p1}, Lkotlin/collections/q;->l(Ljava/lang/Iterable;)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_19
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkp/E;

    invoke-virtual {v1}, Lkp/E;->p()Ldp/i;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_19

    :cond_2d
    invoke-static {v0}, Lsp/a;->b(Ljava/util/ArrayList;)Ltp/c;

    move-result-object p1

    invoke-virtual {p1}, Ltp/c;->size()I

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_51

    const/4 v2, 0x0

    if-eq v0, v1, :cond_49

    new-instance v0, Ldp/b;

    new-array v2, v2, [Ldp/i;

    invoke-virtual {p1, v2}, Ltp/c;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ldp/i;

    invoke-direct {v0, p0, v2}, Ldp/b;-><init>(Ljava/lang/String;[Ldp/i;)V

    goto :goto_53

    :cond_49
    invoke-virtual {p1, v2}, Ltp/c;->get(I)Ljava/lang/Object;

    move-result-object p0

    move-object v0, p0

    check-cast v0, Ldp/i;

    goto :goto_53

    :cond_51
    sget-object v0, Ldp/i$b;->b:Ldp/i$b;

    :goto_53
    invoke-virtual {p1}, Ltp/c;->size()I

    move-result p0

    if-gt p0, v1, :cond_5a

    return-object v0

    :cond_5a
    new-instance p0, Ldp/o;

    invoke-direct {p0, v0}, Ldp/o;-><init>(Ldp/i;)V

    return-object p0
.end method
