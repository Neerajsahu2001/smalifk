.class public final Ldp/d;
.super Ljava/lang/Object;
.source "MemberScope.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldp/d$a;
    }
.end annotation


# static fields
.field public static final c:Ldp/d$a;

.field private static d:I = 0x1

.field private static final e:I

.field private static final f:I

.field private static final g:I

.field private static final h:I

.field private static final i:I

.field private static final j:I

.field private static final k:I

.field private static final l:I

.field public static final m:Ldp/d;

.field public static final n:Ldp/d;

.field public static final o:Ldp/d;

.field public static final p:Ldp/d;

.field public static final q:Ldp/d;

.field private static final r:Ljava/util/ArrayList;

.field private static final s:Ljava/util/ArrayList;


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ldp/c;",
            ">;"
        }
    .end annotation
.end field

.field private final b:I


# direct methods
.method static constructor <clinit>()V
    .registers 11

    new-instance v0, Ldp/d$a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Ldp/d;->c:Ldp/d$a;

    invoke-static {v0}, Ldp/d$a;->a(Ldp/d$a;)I

    move-result v1

    sput v1, Ldp/d;->e:I

    invoke-static {v0}, Ldp/d$a;->a(Ldp/d$a;)I

    move-result v2

    sput v2, Ldp/d;->f:I

    invoke-static {v0}, Ldp/d$a;->a(Ldp/d$a;)I

    move-result v3

    sput v3, Ldp/d;->g:I

    invoke-static {v0}, Ldp/d$a;->a(Ldp/d$a;)I

    move-result v4

    sput v4, Ldp/d;->h:I

    invoke-static {v0}, Ldp/d$a;->a(Ldp/d$a;)I

    move-result v5

    sput v5, Ldp/d;->i:I

    invoke-static {v0}, Ldp/d$a;->a(Ldp/d$a;)I

    move-result v6

    sput v6, Ldp/d;->j:I

    invoke-static {v0}, Ldp/d$a;->a(Ldp/d$a;)I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    sput v0, Ldp/d;->k:I

    or-int v7, v1, v2

    or-int/2addr v7, v3

    sput v7, Ldp/d;->l:I

    or-int v8, v2, v5

    or-int/2addr v8, v6

    or-int v9, v5, v6

    new-instance v10, Ldp/d;

    invoke-direct {v10, v0}, Ldp/d;-><init>(I)V

    sput-object v10, Ldp/d;->m:Ldp/d;

    new-instance v0, Ldp/d;

    invoke-direct {v0, v9}, Ldp/d;-><init>(I)V

    sput-object v0, Ldp/d;->n:Ldp/d;

    new-instance v0, Ldp/d;

    invoke-direct {v0, v1}, Ldp/d;-><init>(I)V

    new-instance v0, Ldp/d;

    invoke-direct {v0, v2}, Ldp/d;-><init>(I)V

    new-instance v0, Ldp/d;

    invoke-direct {v0, v3}, Ldp/d;-><init>(I)V

    new-instance v0, Ldp/d;

    invoke-direct {v0, v7}, Ldp/d;-><init>(I)V

    sput-object v0, Ldp/d;->o:Ldp/d;

    new-instance v0, Ldp/d;

    invoke-direct {v0, v4}, Ldp/d;-><init>(I)V

    new-instance v0, Ldp/d;

    invoke-direct {v0, v5}, Ldp/d;-><init>(I)V

    sput-object v0, Ldp/d;->p:Ldp/d;

    new-instance v0, Ldp/d;

    invoke-direct {v0, v6}, Ldp/d;-><init>(I)V

    sput-object v0, Ldp/d;->q:Ldp/d;

    new-instance v0, Ldp/d;

    invoke-direct {v0, v8}, Ldp/d;-><init>(I)V

    const-class v0, Ldp/d;

    invoke-virtual {v0}, Ljava/lang/Class;->getFields()[Ljava/lang/reflect/Field;

    move-result-object v1

    const-string v2, "T::class.java.fields"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    array-length v4, v1

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_8c
    if-ge v6, v4, :cond_a0

    aget-object v7, v1, v6

    invoke-virtual {v7}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v8

    invoke-static {v8}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v8

    if-eqz v8, :cond_9d

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_9d
    add-int/lit8 v6, v6, 0x1

    goto :goto_8c

    :cond_a0
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_a9
    :goto_a9
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v6, 0x0

    const-string v7, "field.name"

    if-eqz v4, :cond_da

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/reflect/Field;

    invoke-virtual {v4, v6}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    instance-of v9, v8, Ldp/d;

    if-eqz v9, :cond_c3

    check-cast v8, Ldp/d;

    goto :goto_c4

    :cond_c3
    move-object v8, v6

    :goto_c4
    if-eqz v8, :cond_d4

    new-instance v6, Ldp/d$a$a;

    invoke-virtual {v4}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget v7, v8, Ldp/d;->b:I

    invoke-direct {v6, v7, v4}, Ldp/d$a$a;-><init>(ILjava/lang/String;)V

    :cond_d4
    if-eqz v6, :cond_a9

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_a9

    :cond_da
    sput-object v1, Ldp/d;->r:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/lang/Class;->getFields()[Ljava/lang/reflect/Field;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    array-length v2, v0

    :goto_e9
    if-ge v5, v2, :cond_fd

    aget-object v3, v0, v5

    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v4

    invoke-static {v4}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v4

    if-eqz v4, :cond_fa

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_fa
    add-int/lit8 v5, v5, 0x1

    goto :goto_e9

    :cond_fd
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_106
    :goto_106
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_123

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/lang/reflect/Field;

    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v3

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_106

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_106

    :cond_123
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_12c
    :goto_12c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_15f

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/reflect/Field;

    invoke-virtual {v2, v6}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const-string v4, "null cannot be cast to non-null type kotlin.Int"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    neg-int v4, v3

    and-int/2addr v4, v3

    if-ne v3, v4, :cond_158

    new-instance v4, Ldp/d$a$a;

    invoke-virtual {v2}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v7}, Lkotlin/jvm/internal/n;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v4, v3, v2}, Ldp/d$a$a;-><init>(ILjava/lang/String;)V

    goto :goto_159

    :cond_158
    move-object v4, v6

    :goto_159
    if-eqz v4, :cond_12c

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_12c

    :cond_15f
    sput-object v1, Ldp/d;->s:Ljava/util/ArrayList;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 3

    sget-object v0, Lkotlin/collections/A;->a:Lkotlin/collections/A;

    invoke-direct {p0, p1, v0}, Ldp/d;-><init>(ILjava/util/List;)V

    return-void
.end method

.method public constructor <init>(ILjava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "+",
            "Ldp/c;",
            ">;)V"
        }
    .end annotation

    const-string v0, "excludes"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/n;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ldp/d;->a:Ljava/util/List;

    check-cast p2, Ljava/lang/Iterable;

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_10
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldp/c;

    invoke-virtual {v0}, Ldp/c;->a()I

    move-result v0

    not-int v0, v0

    and-int/2addr p1, v0

    goto :goto_10

    :cond_23
    iput p1, p0, Ldp/d;->b:I

    return-void
.end method

.method public static final synthetic b()I
    .registers 1

    sget v0, Ldp/d;->k:I

    return v0
.end method

.method public static final synthetic c()I
    .registers 1

    sget v0, Ldp/d;->l:I

    return v0
.end method

.method public static final synthetic d()I
    .registers 1

    sget v0, Ldp/d;->i:I

    return v0
.end method

.method public static final synthetic e()I
    .registers 1

    sget v0, Ldp/d;->e:I

    return v0
.end method

.method public static final synthetic f()I
    .registers 1

    sget v0, Ldp/d;->d:I

    return v0
.end method

.method public static final synthetic g()I
    .registers 1

    sget v0, Ldp/d;->h:I

    return v0
.end method

.method public static final synthetic h()I
    .registers 1

    sget v0, Ldp/d;->f:I

    return v0
.end method

.method public static final synthetic i()I
    .registers 1

    sget v0, Ldp/d;->g:I

    return v0
.end method

.method public static final synthetic j()I
    .registers 1

    sget v0, Ldp/d;->j:I

    return v0
.end method

.method public static final synthetic k(I)V
    .registers 1

    sput p0, Ldp/d;->d:I

    return-void
.end method


# virtual methods
.method public final a(I)Z
    .registers 3

    iget v0, p0, Ldp/d;->b:I

    and-int/2addr p1, v0

    if-eqz p1, :cond_7

    const/4 p1, 0x1

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    if-eqz p1, :cond_b

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    goto :goto_c

    :cond_b
    const/4 v1, 0x0

    :goto_c
    const-class v2, Ldp/d;

    invoke-static {v2, v1}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_16

    return v2

    :cond_16
    const-string v1, "null cannot be cast to non-null type org.jetbrains.kotlin.resolve.scopes.DescriptorKindFilter"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/n;->d(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Ldp/d;

    iget-object v1, p0, Ldp/d;->a:Ljava/util/List;

    iget-object v3, p1, Ldp/d;->a:Ljava/util/List;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/n;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_28

    return v2

    :cond_28
    iget v1, p0, Ldp/d;->b:I

    iget p1, p1, Ldp/d;->b:I

    if-eq v1, p1, :cond_2f

    return v2

    :cond_2f
    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Ldp/d;->a:Ljava/util/List;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Ldp/d;->b:I

    add-int/2addr v0, v1

    return v0
.end method

.method public final l()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ldp/c;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Ldp/d;->a:Ljava/util/List;

    return-object v0
.end method

.method public final m()I
    .registers 2

    iget v0, p0, Ldp/d;->b:I

    return v0
.end method

.method public final n(I)Ldp/d;
    .registers 4

    iget v0, p0, Ldp/d;->b:I

    and-int/2addr p1, v0

    if-nez p1, :cond_7

    const/4 p1, 0x0

    return-object p1

    :cond_7
    new-instance v0, Ldp/d;

    iget-object v1, p0, Ldp/d;->a:Ljava/util/List;

    invoke-direct {v0, p1, v1}, Ldp/d;-><init>(ILjava/util/List;)V

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 10

    sget-object v0, Ldp/d;->r:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Ldp/d$a$a;

    invoke-virtual {v3}, Ldp/d$a$a;->a()I

    move-result v3

    iget v4, p0, Ldp/d;->b:I

    if-ne v3, v4, :cond_6

    goto :goto_1e

    :cond_1d
    move-object v1, v2

    :goto_1e
    check-cast v1, Ldp/d$a$a;

    if-eqz v1, :cond_27

    invoke-virtual {v1}, Ldp/d$a$a;->b()Ljava/lang/String;

    move-result-object v0

    goto :goto_28

    :cond_27
    move-object v0, v2

    :goto_28
    if-nez v0, :cond_62

    sget-object v0, Ldp/d;->s:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_35
    :goto_35
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_57

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldp/d$a$a;

    invoke-virtual {v1}, Ldp/d$a$a;->a()I

    move-result v4

    invoke-virtual {p0, v4}, Ldp/d;->a(I)Z

    move-result v4

    if-eqz v4, :cond_50

    invoke-virtual {v1}, Ldp/d$a$a;->b()Ljava/lang/String;

    move-result-object v1

    goto :goto_51

    :cond_50
    move-object v1, v2

    :goto_51
    if-eqz v1, :cond_35

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_35

    :cond_57
    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v4, " | "

    const/4 v5, 0x0

    const/16 v8, 0x3e

    invoke-static/range {v3 .. v8}, Lkotlin/collections/q;->z(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Leo/l;I)Ljava/lang/String;

    move-result-object v0

    :cond_62
    const-string v1, "DescriptorKindFilter("

    const-string v2, ", "

    invoke-static {v1, v0, v2}, Landroidx/activity/result/c;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Ldp/d;->a:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
