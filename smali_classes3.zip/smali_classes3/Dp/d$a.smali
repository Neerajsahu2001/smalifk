.class public final Ldp/d$a;
.super Ljava/lang/Object;
.source "MemberScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldp/d$a$a;
    }
.end annotation


# direct methods
.method public static final a(Ldp/d$a;)I
    .registers 2

    invoke-static {}, Ldp/d;->f()I

    move-result p0

    invoke-static {}, Ldp/d;->f()I

    move-result v0

    shl-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Ldp/d;->k(I)V

    return p0
.end method
