.class public final Ldp/c$b;
.super Ldp/c;
.source "MemberScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final a:Ldp/c$b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ldp/c$b;

    invoke-direct {v0}, Ldp/c;-><init>()V

    sput-object v0, Ldp/c$b;->a:Ldp/c$b;

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
