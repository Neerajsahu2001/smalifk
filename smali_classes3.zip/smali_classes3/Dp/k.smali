.class public final Ldp/k;
.super Ljava/lang/Object;
.source "MemberScope.kt"


# direct methods
.method public static final a(Ljava/lang/Iterable;)Ljava/util/HashSet;
    .registers 3

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_9
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_23

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldp/i;

    invoke-interface {v1}, Ldp/i;->f()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    if-nez v1, :cond_1f

    const/4 v0, 0x0

    goto :goto_23

    :cond_1f
    invoke-static {v1, v0}, Lkotlin/collections/q;->g(Ljava/lang/Iterable;Ljava/util/Collection;)V

    goto :goto_9

    :cond_23
    :goto_23
    return-object v0
.end method
