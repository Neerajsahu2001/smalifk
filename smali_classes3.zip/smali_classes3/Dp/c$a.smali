.class public final Ldp/c$a;
.super Ldp/c;
.source "MemberScope.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:Ldp/c$a;

.field private static final b:I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Ldp/c$a;

    invoke-direct {v0}, Ldp/c;-><init>()V

    sput-object v0, Ldp/c$a;->a:Ldp/c$a;

    sget-object v0, Ldp/d;->c:Ldp/d$a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ldp/d;->b()I

    move-result v1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ldp/d;->d()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ldp/d;->j()I

    move-result v0

    or-int/2addr v0, v2

    not-int v0, v0

    and-int/2addr v0, v1

    sput v0, Ldp/c$a;->b:I

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    sget v0, Ldp/c$a;->b:I

    return v0
.end method
