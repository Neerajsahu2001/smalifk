.class public final LEn/d;
.super LEn/e;
.source "MissedCallInstallationCallback.java"


# instance fields
.field f:Landroidx/media3/exoplayer/video/c;

.field private g:Landroid/os/Handler;

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;Lcom/truecaller/android/sdk/clients/f;Landroid/os/Handler;)V
    .registers 6

    const/4 v0, 0x3

    invoke-direct {p0, p1, p3, p2, v0}, LEn/e;-><init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;Lcom/truecaller/android/sdk/clients/f;Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;I)V

    iput-object p4, p0, LEn/d;->g:Landroid/os/Handler;

    return-void
.end method

.method public static synthetic d(LEn/d;)V
    .registers 2

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, LEn/d;->e(Z)V

    return-void
.end method


# virtual methods
.method final c(Ljava/util/Map;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const-string v0, "method"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "call"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60

    const-string v0, "pattern"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iput-object v0, p0, LEn/d;->h:Ljava/lang/String;

    const-string v0, "tokenTtl"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Double;

    if-nez v0, :cond_2a

    const-wide/high16 v0, 0x4044000000000000L    # 40.0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    :cond_2a
    new-instance v1, Lcom/truecaller/android/sdk/clients/e;

    invoke-direct {v1}, Lcom/truecaller/android/sdk/clients/e;-><init>()V

    const-string v2, "ttl"

    invoke-virtual {v0}, Ljava/lang/Double;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lcom/truecaller/android/sdk/clients/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v2, "requestNonce"

    invoke-interface {p1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {v1, v2, p1}, Lcom/truecaller/android/sdk/clients/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    iget-object p1, p0, LEn/a;->a:Lcom/truecaller/android/sdk/clients/VerificationCallback;

    iget v2, p0, LEn/a;->b:I

    invoke-interface {p1, v2, v1}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestSuccess(ILcom/truecaller/android/sdk/clients/e;)V

    new-instance p1, Landroidx/media3/exoplayer/video/c;

    const/4 v1, 0x4

    invoke-direct {p1, v1, p0}, Landroidx/media3/exoplayer/video/c;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LEn/d;->f:Landroidx/media3/exoplayer/video/c;

    iget-object v1, p0, LEn/d;->g:Landroid/os/Handler;

    invoke-virtual {v0}, Ljava/lang/Double;->longValue()J

    move-result-wide v2

    const-wide/16 v4, 0x3e8

    mul-long v2, v2, v4

    invoke-virtual {v1, p1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_63

    :cond_60
    invoke-super {p0, p1}, LEn/e;->c(Ljava/util/Map;)V

    :goto_63
    return-void
.end method

.method final e(Z)V
    .registers 10

    if-nez p1, :cond_6

    iget-object p1, p0, LEn/d;->h:Ljava/lang/String;

    if-eqz p1, :cond_59

    :cond_6
    iget-object p1, p0, LEn/e;->d:Lcom/truecaller/android/sdk/clients/f;

    invoke-interface {p1}, Lcom/truecaller/android/sdk/clients/f;->a()V

    invoke-interface {p1}, Lcom/truecaller/android/sdk/clients/f;->f()V

    iget-object v0, p0, LEn/d;->i:Ljava/lang/String;

    const/4 v1, 0x0

    if-eqz v0, :cond_4e

    iget-object v0, p0, LEn/d;->h:Ljava/lang/String;

    if-eqz v0, :cond_4e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, LEn/d;->h:Ljava/lang/String;

    const-string v3, ","

    invoke-virtual {v2, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    array-length v3, v2

    const/4 v4, 0x0

    :goto_26
    if-ge v4, v3, :cond_41

    aget-object v5, v2, v4

    iget-object v6, p0, LEn/d;->i:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    sub-int/2addr v7, v5

    add-int/lit8 v7, v7, -0x1

    invoke-virtual {v6, v7}, Ljava/lang/String;->charAt(I)C

    move-result v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_26

    :cond_41
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Lcom/truecaller/android/sdk/clients/f;->g(Ljava/lang/String;)V

    const/4 p1, 0x4

    iget-object v0, p0, LEn/a;->a:Lcom/truecaller/android/sdk/clients/VerificationCallback;

    invoke-interface {v0, p1, v1}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestSuccess(ILcom/truecaller/android/sdk/clients/e;)V

    :cond_4e
    iget-object p1, p0, LEn/d;->g:Landroid/os/Handler;

    if-eqz p1, :cond_59

    iget-object v0, p0, LEn/d;->f:Landroidx/media3/exoplayer/video/c;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-object v1, p0, LEn/d;->g:Landroid/os/Handler;

    :cond_59
    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .registers 4

    if-eqz p1, :cond_10

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_9

    goto :goto_10

    :cond_9
    iput-object p1, p0, LEn/d;->i:Ljava/lang/String;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, LEn/d;->e(Z)V

    goto :goto_29

    :cond_10
    :goto_10
    iget-object p1, p0, LEn/d;->g:Landroid/os/Handler;

    if-eqz p1, :cond_1c

    iget-object v0, p0, LEn/d;->f:Landroidx/media3/exoplayer/video/c;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 p1, 0x0

    iput-object p1, p0, LEn/d;->g:Landroid/os/Handler;

    :cond_1c
    new-instance p1, Lcom/truecaller/android/sdk/TrueException;

    const/4 v0, 0x4

    const-string v1, "Required permissions missing"

    invoke-direct {p1, v0, v1}, Lcom/truecaller/android/sdk/TrueException;-><init>(ILjava/lang/String;)V

    iget-object v1, p0, LEn/a;->a:Lcom/truecaller/android/sdk/clients/VerificationCallback;

    invoke-interface {v1, v0, p1}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestFailure(ILcom/truecaller/android/sdk/TrueException;)V

    :goto_29
    return-void
.end method
