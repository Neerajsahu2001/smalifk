.class public LEn/e;
.super LEn/a;
.source "OtpInstallationCallback.java"


# instance fields
.field protected final d:Lcom/truecaller/android/sdk/clients/f;

.field private final e:Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;


# direct methods
.method constructor <init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;Lcom/truecaller/android/sdk/clients/f;Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;I)V
    .registers 6

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0, p4}, LEn/a;-><init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;ZI)V

    iput-object p2, p0, LEn/e;->d:Lcom/truecaller/android/sdk/clients/f;

    iput-object p3, p0, LEn/e;->e:Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;

    return-void
.end method

.method public constructor <init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;Lcom/truecaller/android/sdk/clients/f;)V
    .registers 5

    const/4 v0, 0x1

    invoke-direct {p0, p1, p3, p2, v0}, LEn/e;-><init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;Lcom/truecaller/android/sdk/clients/f;Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;I)V

    return-void
.end method


# virtual methods
.method final bridge synthetic a()V
    .registers 1

    return-void
.end method

.method final b(Ljava/lang/Object;)V
    .registers 9

    check-cast p1, Ljava/util/Map;

    const-string v0, "status"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    const-wide/16 v3, 0x0

    iget-object v5, p0, LEn/e;->d:Lcom/truecaller/android/sdk/clients/f;

    cmpl-double v6, v1, v3

    if-nez v6, :cond_28

    const-string v0, "verificationToken"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    invoke-interface {v5, v0}, Lcom/truecaller/android/sdk/clients/f;->e(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, LEn/e;->c(Ljava/util/Map;)V

    goto :goto_55

    :cond_28
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    iget-object v4, p0, LEn/a;->a:Lcom/truecaller/android/sdk/clients/VerificationCallback;

    cmpl-double v6, v0, v2

    if-nez v6, :cond_48

    const-string v0, "accessToken"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "requestNonce"

    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-interface {v5, p1, v0, v4}, Lcom/truecaller/android/sdk/clients/f;->c(Ljava/lang/String;Ljava/lang/String;Lcom/truecaller/android/sdk/clients/VerificationCallback;)V

    goto :goto_55

    :cond_48
    new-instance p1, Lcom/truecaller/android/sdk/TrueException;

    const/4 v0, 0x1

    const-string v1, "Unknown error"

    invoke-direct {p1, v0, v1}, Lcom/truecaller/android/sdk/TrueException;-><init>(ILjava/lang/String;)V

    iget v0, p0, LEn/a;->b:I

    invoke-interface {v4, v0, p1}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestFailure(ILcom/truecaller/android/sdk/TrueException;)V

    :goto_55
    return-void
.end method

.method c(Ljava/util/Map;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const-string v0, "tokenTtl"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Double;

    if-nez v0, :cond_13

    const-wide v0, 0x4072c00000000000L    # 300.0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    :cond_13
    new-instance v1, Lcom/truecaller/android/sdk/clients/e;

    invoke-direct {v1}, Lcom/truecaller/android/sdk/clients/e;-><init>()V

    const-string v2, "ttl"

    invoke-virtual {v0}, Ljava/lang/Double;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Lcom/truecaller/android/sdk/clients/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v0, "requestNonce"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {v1, v0, p1}, Lcom/truecaller/android/sdk/clients/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 p1, 0x1

    iget-object v0, p0, LEn/a;->a:Lcom/truecaller/android/sdk/clients/VerificationCallback;

    invoke-interface {v0, p1, v1}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestSuccess(ILcom/truecaller/android/sdk/clients/e;)V

    iget-object p1, p0, LEn/e;->e:Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;

    invoke-virtual {p1, v0}, Lcom/truecaller/android/sdk/clients/otpVerification/SmsRetrieverClientHandler;->a(Lcom/truecaller/android/sdk/clients/VerificationCallback;)V

    return-void
.end method
