.class public final LEn/f;
.super LEn/a;
.source "VerifyInstallationCallback.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LEn/a<",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field private d:Lcom/truecaller/android/sdk/TrueProfile;

.field private e:Lcom/truecaller/android/sdk/clients/f;

.field private f:Ljava/lang/String;

.field private g:Lcom/truecaller/android/sdk/models/VerifyInstallationModel;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/truecaller/android/sdk/models/VerifyInstallationModel;Lcom/truecaller/android/sdk/clients/VerificationCallback;Lcom/truecaller/android/sdk/TrueProfile;Lcom/truecaller/android/sdk/clients/f;)V
    .registers 8

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p3, v0, v1}, LEn/a;-><init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;ZI)V

    iput-object p4, p0, LEn/f;->d:Lcom/truecaller/android/sdk/TrueProfile;

    iput-object p5, p0, LEn/f;->e:Lcom/truecaller/android/sdk/clients/f;

    iput-object p1, p0, LEn/f;->f:Ljava/lang/String;

    iput-object p2, p0, LEn/f;->g:Lcom/truecaller/android/sdk/models/VerifyInstallationModel;

    return-void
.end method


# virtual methods
.method final a()V
    .registers 4

    iget-object v0, p0, LEn/f;->f:Ljava/lang/String;

    iget-object v1, p0, LEn/f;->g:Lcom/truecaller/android/sdk/models/VerifyInstallationModel;

    iget-object v2, p0, LEn/f;->e:Lcom/truecaller/android/sdk/clients/f;

    invoke-interface {v2, v0, v1, p0}, Lcom/truecaller/android/sdk/clients/f;->h(Ljava/lang/String;Lcom/truecaller/android/sdk/models/VerifyInstallationModel;LEn/f;)V

    return-void
.end method

.method final b(Ljava/lang/Object;)V
    .registers 7

    check-cast p1, Ljava/util/Map;

    const-string v0, "accessToken"

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    iget v2, p0, LEn/a;->b:I

    iget-object v3, p0, LEn/a;->a:Lcom/truecaller/android/sdk/clients/VerificationCallback;

    if-eqz v1, :cond_32

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    new-instance v4, Lcom/truecaller/android/sdk/clients/e;

    invoke-direct {v4}, Lcom/truecaller/android/sdk/clients/e;-><init>()V

    invoke-virtual {v4, v0, v1}, Lcom/truecaller/android/sdk/clients/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v0, "requestNonce"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {v4, v0, p1}, Lcom/truecaller/android/sdk/clients/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-interface {v3, v2, v4}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestSuccess(ILcom/truecaller/android/sdk/clients/e;)V

    iget-object p1, p0, LEn/f;->e:Lcom/truecaller/android/sdk/clients/f;

    iget-object v0, p0, LEn/f;->d:Lcom/truecaller/android/sdk/TrueProfile;

    invoke-interface {p1, v1, v0}, Lcom/truecaller/android/sdk/clients/f;->i(Ljava/lang/String;Lcom/truecaller/android/sdk/TrueProfile;)V

    goto :goto_3d

    :cond_32
    new-instance p1, Lcom/truecaller/android/sdk/TrueException;

    const/4 v0, 0x1

    const-string v1, "Unknown error"

    invoke-direct {p1, v0, v1}, Lcom/truecaller/android/sdk/TrueException;-><init>(ILjava/lang/String;)V

    invoke-interface {v3, v2, p1}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestFailure(ILcom/truecaller/android/sdk/TrueException;)V

    :goto_3d
    return-void
.end method
