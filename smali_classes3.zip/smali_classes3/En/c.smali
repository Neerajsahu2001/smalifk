.class public final LEn/c;
.super LEn/a;
.source "FetchProfileCallback.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LEn/a<",
        "Lcom/truecaller/android/sdk/TrueProfile;",
        ">;"
    }
.end annotation


# instance fields
.field private d:Ljava/lang/String;

.field private e:Lcom/truecaller/android/sdk/clients/f;

.field private f:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/truecaller/android/sdk/clients/VerificationCallback;Lcom/truecaller/android/sdk/clients/f;)V
    .registers 7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p3, v0, v1}, LEn/a;-><init>(Lcom/truecaller/android/sdk/clients/VerificationCallback;ZI)V

    iput-object p2, p0, LEn/c;->d:Ljava/lang/String;

    iput-object p4, p0, LEn/c;->e:Lcom/truecaller/android/sdk/clients/f;

    iput-object p1, p0, LEn/c;->f:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method final a()V
    .registers 3

    iget-object v0, p0, LEn/c;->e:Lcom/truecaller/android/sdk/clients/f;

    iget-object v1, p0, LEn/c;->d:Ljava/lang/String;

    invoke-interface {v0, v1, p0}, Lcom/truecaller/android/sdk/clients/f;->d(Ljava/lang/String;LEn/c;)V

    return-void
.end method

.method final b(Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Lcom/truecaller/android/sdk/TrueProfile;

    iget-object v0, p0, LEn/c;->d:Ljava/lang/String;

    iput-object v0, p1, Lcom/truecaller/android/sdk/TrueProfile;->accessToken:Ljava/lang/String;

    iget-object v0, p0, LEn/c;->f:Ljava/lang/String;

    iput-object v0, p1, Lcom/truecaller/android/sdk/TrueProfile;->requestNonce:Ljava/lang/String;

    new-instance v0, Lcom/truecaller/android/sdk/clients/e;

    invoke-direct {v0}, Lcom/truecaller/android/sdk/clients/e;-><init>()V

    const-string v1, "profile"

    invoke-virtual {v0, v1, p1}, Lcom/truecaller/android/sdk/clients/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    iget-object p1, p0, LEn/a;->a:Lcom/truecaller/android/sdk/clients/VerificationCallback;

    iget v1, p0, LEn/a;->b:I

    invoke-interface {p1, v1, v0}, Lcom/truecaller/android/sdk/clients/VerificationCallback;->onRequestSuccess(ILcom/truecaller/android/sdk/clients/e;)V

    return-void
.end method
