.class public final LEn/b;
.super Ljava/lang/Object;
.source "CreateProfileCallback.java"

# interfaces
.implements Lretrofit2/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lretrofit2/d<",
        "Lorg/json/JSONObject;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Lcom/truecaller/android/sdk/TrueProfile;

.field private final c:Lcom/truecaller/android/sdk/clients/f;

.field public d:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/truecaller/android/sdk/TrueProfile;Lcom/truecaller/android/sdk/clients/f;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LEn/b;->a:Ljava/lang/String;

    iput-object p2, p0, LEn/b;->b:Lcom/truecaller/android/sdk/TrueProfile;

    iput-object p3, p0, LEn/b;->c:Lcom/truecaller/android/sdk/clients/f;

    const/4 p1, 0x1

    iput-boolean p1, p0, LEn/b;->d:Z

    return-void
.end method


# virtual methods
.method public final onFailure(Lretrofit2/b;Ljava/lang/Throwable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/b<",
            "Lorg/json/JSONObject;",
            ">;",
            "Ljava/lang/Throwable;",
            ")V"
        }
    .end annotation

    return-void
.end method

.method public final onResponse(Lretrofit2/b;Lretrofit2/F;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit2/b<",
            "Lorg/json/JSONObject;",
            ">;",
            "Lretrofit2/F<",
            "Lorg/json/JSONObject;",
            ">;)V"
        }
    .end annotation

    if-eqz p2, :cond_75

    invoke-virtual {p2}, Lretrofit2/F;->d()Lokhttp3/ResponseBody;

    move-result-object p1

    if-eqz p1, :cond_75

    invoke-virtual {p2}, Lretrofit2/F;->d()Lokhttp3/ResponseBody;

    move-result-object p1

    const-string p2, "errors"

    const-string v0, "message"

    const-string v1, "Unknown error"

    const/4 v2, 0x0

    :try_start_13
    new-instance v3, Lxk/j;

    invoke-direct {v3}, Lxk/j;-><init>()V

    invoke-virtual {p1}, Lokhttp3/ResponseBody;->charStream()Ljava/io/Reader;

    move-result-object p1

    const-class v4, Ljava/util/Map;

    invoke-static {v3, p1, v4}, Lcom/newrelic/agent/android/instrumentation/GsonInstrumentation;->fromJson(Lxk/j;Ljava/io/Reader;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    if-eqz p1, :cond_5e

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3a

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    instance-of p2, p1, Ljava/lang/String;

    if-eqz p2, :cond_5e

    check-cast p1, Ljava/lang/String;

    :goto_36
    move-object v1, p1

    goto :goto_5e

    :catch_38
    nop

    goto :goto_5e

    :cond_3a
    invoke-interface {p1, p2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5e

    invoke-interface {p1, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    instance-of p2, p1, Ljava/util/List;

    if-eqz p2, :cond_5e

    move-object p2, p1

    check-cast p2, Ljava/util/List;

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_5e

    check-cast p1, Ljava/util/List;

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    instance-of p2, p1, Ljava/lang/String;

    if-eqz p2, :cond_5e

    check-cast p1, Ljava/lang/String;
    :try_end_5d
    .catch Lxk/x; {:try_start_13 .. :try_end_5d} :catch_38
    .catch Lxk/q; {:try_start_13 .. :try_end_5d} :catch_38

    goto :goto_36

    :cond_5e
    :goto_5e
    iget-boolean p1, p0, LEn/b;->d:Z

    if-eqz p1, :cond_75

    const-string p1, "internal service error"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_75

    iput-boolean v2, p0, LEn/b;->d:Z

    iget-object p1, p0, LEn/b;->b:Lcom/truecaller/android/sdk/TrueProfile;

    iget-object p2, p0, LEn/b;->c:Lcom/truecaller/android/sdk/clients/f;

    iget-object v0, p0, LEn/b;->a:Ljava/lang/String;

    invoke-interface {p2, v0, p1, p0}, Lcom/truecaller/android/sdk/clients/f;->b(Ljava/lang/String;Lcom/truecaller/android/sdk/TrueProfile;LEn/b;)V

    :cond_75
    return-void
.end method
